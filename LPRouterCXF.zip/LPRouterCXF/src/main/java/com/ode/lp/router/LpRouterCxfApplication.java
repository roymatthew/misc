package com.ode.lp.router;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LpRouterCxfApplication {

	public static void main(String[] args) {
		SpringApplication.run(LpRouterCxfApplication.class, args);
	}

}
