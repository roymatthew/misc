package com.ode.lp.router.config;

import org.apache.camel.CamelContext;
import org.apache.camel.component.cxf.CxfComponent;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ode.lp.router.soap.service.AppInboundInterceptor;
import com.ode.lp.router.soap.service.StarTransportBindingImpl;

@Configuration
public class WebServiceConfig {

	
	@Bean
	public ServletRegistrationBean dispatcherServlet() {
        return new ServletRegistrationBean(new CXFServlet(), "/services/*");
    }
	
    @Bean(name=Bus.DEFAULT_BUS_ID)
    public SpringBus springBus() {    
    	SpringBus springBus = new SpringBus();
       	springBus.getInInterceptors().add(new AppInboundInterceptor());
    	//springBus.getOutInterceptors().add(new AppOutboundInterceptor());
    	return springBus;
    }	
/*    
    @Bean
    public Endpoint processMessageEndpoint() {
        EndpointImpl endpoint = new EndpointImpl(springBus(), new StarTransportBindingImpl());
        endpoint.getFeatures().add(new LoggingFeature());
        endpoint.publish("/loanprocessing");
        return endpoint;
    }*/
    
    @Bean
    public CxfEndpoint processMessageEndpoint(final CamelContext camelContext) {
      final CxfComponent cxfComponent = new CxfComponent(camelContext);
      final CxfEndpoint serviceEndpoint = new CxfEndpoint("", cxfComponent);
      serviceEndpoint.setServiceClass(new StarTransportBindingImpl());
      serviceEndpoint.setBus(springBus());
      serviceEndpoint.setAddress("/loanprocessing");
      serviceEndpoint.setWsdlURL("/wsdl/lpws.wsdl");
      serviceEndpoint.setServiceNameString("starTransportPortTypes");
      //serviceEndpoint.setServiceNameString("LPWebService");
      //serviceEndpoint.setEndpointNameString("processMessage");    
      return serviceEndpoint;
    }
    

}
