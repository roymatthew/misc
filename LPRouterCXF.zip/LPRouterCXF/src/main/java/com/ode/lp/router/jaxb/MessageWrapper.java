package com.ode.lp.router.jaxb;

import java.io.Serializable;

public class MessageWrapper implements Serializable {	

	private String operationName;
	private String requestXML;
	
	public String getOperationName() {
		return operationName;
	}
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	public String getRequestXML() {
		return requestXML;
	}
	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	

}
