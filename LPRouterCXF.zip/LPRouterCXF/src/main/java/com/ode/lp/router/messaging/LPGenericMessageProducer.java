package com.ode.lp.router.messaging;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component
public class LPGenericMessageProducer {
	
	
	@Autowired
	private JmsTemplate jmsTemplate;

	public void sendMessage(final Object rflInRequestVO) throws JMSException {
		
		jmsTemplate.convertAndSend("LPGENERIC", rflInRequestVO);

	}

}
