package com.ode.lp.router.processor;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.Holder;
import javax.xml.ws.WebServiceContext;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.binding.soap.SoapMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.starstandards.star.Content;
import org.starstandards.star.Payload;
import org.starstandards.star.PayloadManifest;
import org.starstandards.star.ProcessMessage;
import org.starstandards.star.ProcessMessageResponse;

import com.ode.lp.router.jaxb.MessageWrapper;
import com.ode.lp.router.messaging.LPGenericMessageProducer;
import com.ode.lp.router.soap.service.AppSessionObj;

@Component
public class LPWebServiceProcessor implements Processor {

	@Autowired
	private LPGenericMessageProducer messageProducer;

	@Override
	public void process(Exchange exchange) throws Exception {

		System.out.println("Entered process method of LPWebServiceProcessor");
		System.out.println("Exchange pattern: " + exchange.getPattern());

		/*
		 * final String fullRequestXML = (String) exchange.getIn().getBody();
		 * 
		 * System.out.println("*****FULL REQ XML START********");
		 * 
		 * System.out.println(fullRequestXML);
		 * 
		 * System.out.println("******FULL REQ XML END*******");
		 */

		Object[] args = exchange.getIn().getBody(Object[].class);
		
/*		for( int i=0; i<args.length; i++)
		{
			System.out.println("[" + i + " ]  " + args[i]);
		}*/

		exchange.getIn().getHeaders().keySet().stream().forEach(key -> {
			Object val = exchange.getIn().getHeaders().get(key);
			System.out.println("Item[" + key + "] " + val);
		});

		// Message cxfMessage =
		// exchange.getIn().getHeader(CxfConstants.CAMEL_CXF_MESSAGE, Message.class);

		// SoapMessage soapMessage =
		// (SoapMessage)exchange.getIn().getHeaders().get(CxfConstants.CAMEL_CXF_MESSAGE);
		// String fullXMLRequest = (String) ((Map<String, Object>)
		// cxfMessage).get("entireSoapMessage");
		// ByteArrayOutputStream out = new ByteArrayOutputStream();
		// soapMessage.writeTo(out);
		// String fullXMLRequest = out.toString();

/*		PayloadManifest processMessageInHeader = (PayloadManifest) args[0];
		ProcessMessage inBody = (ProcessMessage) args[1];
		Holder<PayloadManifest> processMessageOutHeader = (Holder<PayloadManifest>) args[2];
		Holder<ProcessMessageResponse> processMessageOutBody = (Holder<ProcessMessageResponse>) args[3];

		String operationName = "";

		if (processMessageInHeader instanceof PayloadManifest) {
			// PayloadManifest manifest = (PayloadManifest)obj;
			operationName = processMessageInHeader.getManifest().get(0).getElement().toString();
			System.out.println("LPWebServiceProcessor :: Operation name is " + operationName);

		}*/

/*		Payload payload = new Payload();
		Content content = new Content();
		content.setId("Content0");

		JAXBElement<String> jaxbElement = new JAXBElement(new QName("root-element"), String.class,
				"Received " + operationName);
		content.setAny(jaxbElement);
		payload.getContent().add(content);
		ProcessMessageResponse response = new ProcessMessageResponse();
		response.setPayload(payload);

		processMessageOutHeader.value = new PayloadManifest();
		processMessageOutBody.value = response;*/

		// MessageWrapper messageWrapper = new MessageWrapper();
		// messageWrapper.setRequestXML(fullXMLRequest);
		// messageWrapper.setOperationName(operationName);
		//Message cxfMessage = (Message)exchange.getIn().getHeaders().get(CxfConstants.CAMEL_CXF_MESSAGE);
		//Exchange msgexchange = cxfMessage.getExchange();
		//String fullXMLRequest = (String)cxfMessage.getHeader("entireSoapMessage");
		//String fullXMLRequest = (String)cxfMessage.getHeaders().get("entireSoapMessage");
		//String fullXMLRequest = (String) cxfMessage.getExchange().getProperty("entireSoapMessage");
		
		String fullXMLRequest =  (String)AppSessionObj.getInstance().getObjectFromSession("entireSoapMessage");
		messageProducer.sendMessage(fullXMLRequest);

		exchange.getOut().setBody("Success");

	}

}
