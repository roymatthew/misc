package com.ode.lp.router.routes;

import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ode.lp.router.processor.LPWebServiceProcessor;
import com.ode.lp.router.soap.service.StarTransportBindingImpl;

@Component
public class LPWebServiceRoute extends RouteBuilder {
	
	@Autowired
	private LPWebServiceProcessor processor;
	
    private String uri = "cxf:loanprocessing?serviceClass=" + StarTransportBindingImpl.class.getName();

	@Override
	public void configure() throws Exception {
		
		System.out.println("Enter LPWebServiceRoute :: configure");

        //from("cxf:bean:processMessageEndpoint")
        from(uri)
        .log("Calling LPWebServiceProcessor...")
        //.removeHeader("Content-Length")
        .process(processor)
        .split().body().choice().when(simple("${body} starts with 'ProcessCreditApplication'")).log("Writing to PCAQ")
        .when(simple("${body} starts with 'ProcessCreditDecision'")).log("Writing to PCDQ")
        .otherwise().log("writing to PCBQ")
        .log("Done with LPWebServiceProcessor...${body}")
        .end();

	}

}
