package com.ode.lp.router.soap.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.soap.SOAPMessage;

import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.common.util.StringUtils;
import org.apache.cxf.ext.logging.LoggingInInterceptor;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageContentsList;

public class AppInboundInterceptor extends LoggingInInterceptor {

	@Override
	public void handleMessage(Message message) throws Fault {
		processPayLoad(message);
		//super.handleMessage(message);
	}

	private void processPayLoad(Message message) {
		System.out.println("*** PROCESSING PAYLOAD AT IN-INTERCEPTOR **");
		String entireSoapMessage = "";
		CachedOutputStream cos = null;
		try {
			cos = message.getContent(CachedOutputStream.class);
			String encoding = (String) message.get(Message.ENCODING);
	        if (StringUtils.isEmpty(encoding)) {
	            encoding = StandardCharsets.UTF_8.name();
	        }
	        StringBuilder payload = new StringBuilder();
	        cos.writeCacheTo(payload, encoding, limit);
	        cos.close();
			AppSessionObj.getInstance().addObjectToSession("entireSoapMessage", payload.toString());
			
						
		} catch (Exception ex) {
			System.out.println("*** Exception when trying to get message.content() ***");
			// ex.printStackTrace();
		}

	}

}
