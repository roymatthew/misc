package com.ode.lp.router.soap.service;

import org.apache.cxf.ext.logging.LoggingInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;

public class AppOutboundInterceptor extends LoggingInInterceptor {
	
	@Override
	public void handleMessage(Message message) throws Fault {
		processPayLoad(message);
		super.handleMessage(message);
	}	

	private void processPayLoad(Message message) {
		System.out.println("*** PROCESSING PAYLOAD AT OUT-INTERCEPTOR **");
	}

}
