package com.ode.lp.router.soap.service;

import java.util.HashMap;
import java.util.Map;

public class AppSessionObj {

	private static final Map<String, Object> sessionMap = new HashMap<>();

	private static AppSessionObj appSessionObj;

	public Object getObjectFromSession(final String key) {
		Object sessionObj = null;
		if (sessionMap != null && !sessionMap.isEmpty()) {
			sessionObj = sessionMap.get(key);
		}
		return sessionObj;

	}

	public void addObjectToSession(final String key, final Object objToAdd) {
		sessionMap.put(key, objToAdd);

	}

	private AppSessionObj() {

	}

	public static AppSessionObj getInstance() {

		if (appSessionObj == null) {
			appSessionObj = new AppSessionObj();
		}
		return appSessionObj;
	}

}
