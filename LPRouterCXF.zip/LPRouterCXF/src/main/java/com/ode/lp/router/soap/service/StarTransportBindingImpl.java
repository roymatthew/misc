package com.ode.lp.router.soap.service;

import javax.jws.WebService;
import javax.xml.ws.Holder;

import org.starstandards.star.Content;
import org.starstandards.star.Payload;
import org.starstandards.star.PayloadManifest;
import org.starstandards.star.ProcessCreditDecision;
import org.starstandards.star.ProcessCreditDecisionResponse;
import org.starstandards.star.ProcessMessage;
import org.starstandards.star.ProcessMessageResponse;
import org.starstandards.star.PullMessage;
import org.starstandards.star.PullMessageResponse;
import org.starstandards.star.PutMessage;
import org.starstandards.star.PutMessageResponse;
import org.starstandards.star.bindings.StarTransportPortTypes;

@WebService(endpointInterface = "org.starstandards.star.bindings.StarTransportPortTypes",
targetNamespace = "org.starstandards.star/bindings", serviceName = "LPWebService",
portName = "StarTransportPort")
public class StarTransportBindingImpl implements StarTransportPortTypes {

	@Override
	public void pullMessage(PayloadManifest pullMessageInHeader, PullMessage pullMessageInBody,
			Holder<PayloadManifest> pullMessageOutHeader, Holder<PullMessageResponse> pullMessageOutBody) {
		// TODO Auto-generated method stub

	}

	@Override
	public void processMessage(PayloadManifest processMessageInHeader, ProcessMessage processMessageInBody,
			Holder<PayloadManifest> processMessageOutHeader, Holder<ProcessMessageResponse> processMessageOutBody) {
		
		System.out.println("StarTransportBindingImpl :: " + processMessageInBody.getPayload().getContent().toString());
		Payload payload = new Payload();
		Content content = new Content();
		content.setId("100");
		content.setAny("Recieved");
		payload.getContent().add(content);
		ProcessMessageResponse response = new ProcessMessageResponse();
		response.setPayload(payload);
		
		processMessageOutBody.value = response;

	}

	@Override
	public void putMessage(PayloadManifest putMessageInHeader, PutMessage putMessageInBody,
			Holder<PayloadManifest> putMessageOutHeader, Holder<PutMessageResponse> putMessageOutBody) {
		System.out.println("StarTransportBindingImpl :: " + putMessageInBody.getPayload().getContent().toString());
		Payload payload = new Payload();
		Content content = new Content();
		content.setId("100");
		content.setAny("Recieved");
		payload.getContent().add(content);
		PutMessageResponse response = new PutMessageResponse();
		
		putMessageOutBody.value = response;
	}

	@Override
	public void processCreditDecision(PayloadManifest processCreditDecisionInHeader,
			ProcessCreditDecision processCreditDecisionInBody,
			Holder<PayloadManifest> processCreditDecisionOutHeader,
			Holder<ProcessCreditDecisionResponse> processCreditDecisionOutBody) {
		
		
		System.out.println("StarTransportBindingImpl :: " + processCreditDecisionInBody.getApplicationArea().getSender().getSenderNameCode());
		Payload payload = new Payload();
		Content content = new Content();
		content.setId("100");
		content.setAny("Recieved");
		payload.getContent().add(content);
		ProcessCreditDecisionResponse response = new ProcessCreditDecisionResponse();
		response.setPayload(payload);
		
		processCreditDecisionOutBody.value = response;
		
	}

}
