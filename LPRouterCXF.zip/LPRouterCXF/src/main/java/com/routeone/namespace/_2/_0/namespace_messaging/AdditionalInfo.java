
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Any additional info associated with the message
 * 				type can be inserted as the any element. These can be independantly
 * 				decided upon through interaction with the partners that exchange
 * 				that message.
 * 
 * <p>Java class for AdditionalInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditApplicationInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CreditAppTextMessageInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSCreditApplicationDecisionInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}R1CreditApplicationDecisionInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DSPCreditApplicationInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditDecisionInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSCreditApplicationInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditContractInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneSupplementInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditCardApplicationInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditCardDecisionInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FaultInfo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CAStipulationDocumentsInfo"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalInfo", propOrder = {
    "routeOneCreditApplicationInfo",
    "creditAppTextMessageInfo",
    "fsCreditApplicationDecisionInfo",
    "r1CreditApplicationDecisionInfo",
    "dspCreditApplicationInfo",
    "routeOneCreditDecisionInfo",
    "fsCreditApplicationInfo",
    "routeOneCreditContractInfo",
    "routeOneSupplementInfo",
    "routeOneCreditCardApplicationInfo",
    "routeOneCreditCardDecisionInfo",
    "faultInfo",
    "caStipulationDocumentsInfo"
})
public class AdditionalInfo {

    @XmlElement(name = "RouteOneCreditApplicationInfo")
    protected RouteOneCreditApplicationInfo routeOneCreditApplicationInfo;
    @XmlElement(name = "CreditAppTextMessageInfo")
    protected CreditAppTextMessageInfo creditAppTextMessageInfo;
    @XmlElement(name = "FSCreditApplicationDecisionInfo")
    protected FSCreditApplicationDecisionInfo fsCreditApplicationDecisionInfo;
    @XmlElement(name = "R1CreditApplicationDecisionInfo")
    protected R1CreditApplicationDecisionInfo r1CreditApplicationDecisionInfo;
    @XmlElement(name = "DSPCreditApplicationInfo")
    protected DSPCreditApplicationInfo dspCreditApplicationInfo;
    @XmlElement(name = "RouteOneCreditDecisionInfo")
    protected RouteOneCreditDecisionInfo routeOneCreditDecisionInfo;
    @XmlElement(name = "FSCreditApplicationInfo")
    protected FSCreditApplicationInfo fsCreditApplicationInfo;
    @XmlElement(name = "RouteOneCreditContractInfo")
    protected RouteOneCreditContractInfo routeOneCreditContractInfo;
    @XmlElement(name = "RouteOneSupplementInfo")
    protected RouteOneSupplementInfo routeOneSupplementInfo;
    @XmlElement(name = "RouteOneCreditCardApplicationInfo")
    protected RouteOneCreditCardApplicationInfo routeOneCreditCardApplicationInfo;
    @XmlElement(name = "RouteOneCreditCardDecisionInfo")
    protected RouteOneCreditCardDecisionInfo routeOneCreditCardDecisionInfo;
    @XmlElement(name = "FaultInfo")
    protected FaultInfo faultInfo;
    @XmlElement(name = "CAStipulationDocumentsInfo")
    protected CAStipulationDocumentsInfo caStipulationDocumentsInfo;

    /**
     * Gets the value of the routeOneCreditApplicationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditApplicationInfo }
     *     
     */
    public RouteOneCreditApplicationInfo getRouteOneCreditApplicationInfo() {
        return routeOneCreditApplicationInfo;
    }

    /**
     * Sets the value of the routeOneCreditApplicationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditApplicationInfo }
     *     
     */
    public void setRouteOneCreditApplicationInfo(RouteOneCreditApplicationInfo value) {
        this.routeOneCreditApplicationInfo = value;
    }

    /**
     * Gets the value of the creditAppTextMessageInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CreditAppTextMessageInfo }
     *     
     */
    public CreditAppTextMessageInfo getCreditAppTextMessageInfo() {
        return creditAppTextMessageInfo;
    }

    /**
     * Sets the value of the creditAppTextMessageInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditAppTextMessageInfo }
     *     
     */
    public void setCreditAppTextMessageInfo(CreditAppTextMessageInfo value) {
        this.creditAppTextMessageInfo = value;
    }

    /**
     * Gets the value of the fsCreditApplicationDecisionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link FSCreditApplicationDecisionInfo }
     *     
     */
    public FSCreditApplicationDecisionInfo getFSCreditApplicationDecisionInfo() {
        return fsCreditApplicationDecisionInfo;
    }

    /**
     * Sets the value of the fsCreditApplicationDecisionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FSCreditApplicationDecisionInfo }
     *     
     */
    public void setFSCreditApplicationDecisionInfo(FSCreditApplicationDecisionInfo value) {
        this.fsCreditApplicationDecisionInfo = value;
    }

    /**
     * Gets the value of the r1CreditApplicationDecisionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link R1CreditApplicationDecisionInfo }
     *     
     */
    public R1CreditApplicationDecisionInfo getR1CreditApplicationDecisionInfo() {
        return r1CreditApplicationDecisionInfo;
    }

    /**
     * Sets the value of the r1CreditApplicationDecisionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link R1CreditApplicationDecisionInfo }
     *     
     */
    public void setR1CreditApplicationDecisionInfo(R1CreditApplicationDecisionInfo value) {
        this.r1CreditApplicationDecisionInfo = value;
    }

    /**
     * Gets the value of the dspCreditApplicationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link DSPCreditApplicationInfo }
     *     
     */
    public DSPCreditApplicationInfo getDSPCreditApplicationInfo() {
        return dspCreditApplicationInfo;
    }

    /**
     * Sets the value of the dspCreditApplicationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DSPCreditApplicationInfo }
     *     
     */
    public void setDSPCreditApplicationInfo(DSPCreditApplicationInfo value) {
        this.dspCreditApplicationInfo = value;
    }

    /**
     * Gets the value of the routeOneCreditDecisionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditDecisionInfo }
     *     
     */
    public RouteOneCreditDecisionInfo getRouteOneCreditDecisionInfo() {
        return routeOneCreditDecisionInfo;
    }

    /**
     * Sets the value of the routeOneCreditDecisionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditDecisionInfo }
     *     
     */
    public void setRouteOneCreditDecisionInfo(RouteOneCreditDecisionInfo value) {
        this.routeOneCreditDecisionInfo = value;
    }

    /**
     * Gets the value of the fsCreditApplicationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link FSCreditApplicationInfo }
     *     
     */
    public FSCreditApplicationInfo getFSCreditApplicationInfo() {
        return fsCreditApplicationInfo;
    }

    /**
     * Sets the value of the fsCreditApplicationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FSCreditApplicationInfo }
     *     
     */
    public void setFSCreditApplicationInfo(FSCreditApplicationInfo value) {
        this.fsCreditApplicationInfo = value;
    }

    /**
     * Gets the value of the routeOneCreditContractInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditContractInfo }
     *     
     */
    public RouteOneCreditContractInfo getRouteOneCreditContractInfo() {
        return routeOneCreditContractInfo;
    }

    /**
     * Sets the value of the routeOneCreditContractInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditContractInfo }
     *     
     */
    public void setRouteOneCreditContractInfo(RouteOneCreditContractInfo value) {
        this.routeOneCreditContractInfo = value;
    }

    /**
     * Gets the value of the routeOneSupplementInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneSupplementInfo }
     *     
     */
    public RouteOneSupplementInfo getRouteOneSupplementInfo() {
        return routeOneSupplementInfo;
    }

    /**
     * Sets the value of the routeOneSupplementInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneSupplementInfo }
     *     
     */
    public void setRouteOneSupplementInfo(RouteOneSupplementInfo value) {
        this.routeOneSupplementInfo = value;
    }

    /**
     * Gets the value of the routeOneCreditCardApplicationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditCardApplicationInfo }
     *     
     */
    public RouteOneCreditCardApplicationInfo getRouteOneCreditCardApplicationInfo() {
        return routeOneCreditCardApplicationInfo;
    }

    /**
     * Sets the value of the routeOneCreditCardApplicationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditCardApplicationInfo }
     *     
     */
    public void setRouteOneCreditCardApplicationInfo(RouteOneCreditCardApplicationInfo value) {
        this.routeOneCreditCardApplicationInfo = value;
    }

    /**
     * Gets the value of the routeOneCreditCardDecisionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditCardDecisionInfo }
     *     
     */
    public RouteOneCreditCardDecisionInfo getRouteOneCreditCardDecisionInfo() {
        return routeOneCreditCardDecisionInfo;
    }

    /**
     * Sets the value of the routeOneCreditCardDecisionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditCardDecisionInfo }
     *     
     */
    public void setRouteOneCreditCardDecisionInfo(RouteOneCreditCardDecisionInfo value) {
        this.routeOneCreditCardDecisionInfo = value;
    }

    /**
     * Gets the value of the faultInfo property.
     * 
     * @return
     *     possible object is
     *     {@link FaultInfo }
     *     
     */
    public FaultInfo getFaultInfo() {
        return faultInfo;
    }

    /**
     * Sets the value of the faultInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FaultInfo }
     *     
     */
    public void setFaultInfo(FaultInfo value) {
        this.faultInfo = value;
    }

    /**
     * Gets the value of the caStipulationDocumentsInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CAStipulationDocumentsInfo }
     *     
     */
    public CAStipulationDocumentsInfo getCAStipulationDocumentsInfo() {
        return caStipulationDocumentsInfo;
    }

    /**
     * Sets the value of the caStipulationDocumentsInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CAStipulationDocumentsInfo }
     *     
     */
    public void setCAStipulationDocumentsInfo(CAStipulationDocumentsInfo value) {
        this.caStipulationDocumentsInfo = value;
    }

}
