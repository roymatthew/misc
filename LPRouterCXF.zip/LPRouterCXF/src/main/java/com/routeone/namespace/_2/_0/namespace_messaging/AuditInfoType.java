
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AuditInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuditInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DealerPrivacyPolicyAccepted" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="Y"/&gt;
 *               &lt;enumeration value="N"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuditInfoType", propOrder = {
    "dealerPrivacyPolicyAccepted"
})
public class AuditInfoType {

    @XmlElement(name = "DealerPrivacyPolicyAccepted")
    protected String dealerPrivacyPolicyAccepted;

    /**
     * Gets the value of the dealerPrivacyPolicyAccepted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerPrivacyPolicyAccepted() {
        return dealerPrivacyPolicyAccepted;
    }

    /**
     * Sets the value of the dealerPrivacyPolicyAccepted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerPrivacyPolicyAccepted(String value) {
        this.dealerPrivacyPolicyAccepted = value;
    }

}
