
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This structure is used by finance sources that
 * 				subscribe to and utilize the RouteOne Finance Source AutoForward
 * 				feature. 
 * 
 * <p>Java class for AutoForwardInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AutoForwardInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="AutoForwardAllowed"&gt;
 *             &lt;simpleType&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                 &lt;enumeration value="N"/&gt;
 *                 &lt;enumeration value="Y"/&gt;
 *               &lt;/restriction&gt;
 *             &lt;/simpleType&gt;
 *           &lt;/element&gt;
 *           &lt;element name="EndpointList" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AutoForwardEndpointListType"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="DealerOptOut"&gt;
 *             &lt;simpleType&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                 &lt;enumeration value="N"/&gt;
 *                 &lt;enumeration value="Y"/&gt;
 *               &lt;/restriction&gt;
 *             &lt;/simpleType&gt;
 *           &lt;/element&gt;
 *         &lt;/sequence&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="OFSApplicationNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="OFSAliasName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AutoForwardInfoType", propOrder = {
    "autoForwardAllowed",
    "endpointList",
    "dealerOptOut",
    "ofsApplicationNumber",
    "ofsAliasName"
})
public class AutoForwardInfoType {

    @XmlElement(name = "AutoForwardAllowed")
    protected String autoForwardAllowed;
    @XmlElement(name = "EndpointList")
    protected AutoForwardEndpointListType endpointList;
    @XmlElement(name = "DealerOptOut")
    protected String dealerOptOut;
    @XmlElement(name = "OFSApplicationNumber")
    protected String ofsApplicationNumber;
    @XmlElement(name = "OFSAliasName")
    protected String ofsAliasName;

    /**
     * Gets the value of the autoForwardAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoForwardAllowed() {
        return autoForwardAllowed;
    }

    /**
     * Sets the value of the autoForwardAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoForwardAllowed(String value) {
        this.autoForwardAllowed = value;
    }

    /**
     * Gets the value of the endpointList property.
     * 
     * @return
     *     possible object is
     *     {@link AutoForwardEndpointListType }
     *     
     */
    public AutoForwardEndpointListType getEndpointList() {
        return endpointList;
    }

    /**
     * Sets the value of the endpointList property.
     * 
     * @param value
     *     allowed object is
     *     {@link AutoForwardEndpointListType }
     *     
     */
    public void setEndpointList(AutoForwardEndpointListType value) {
        this.endpointList = value;
    }

    /**
     * Gets the value of the dealerOptOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerOptOut() {
        return dealerOptOut;
    }

    /**
     * Sets the value of the dealerOptOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerOptOut(String value) {
        this.dealerOptOut = value;
    }

    /**
     * Gets the value of the ofsApplicationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOFSApplicationNumber() {
        return ofsApplicationNumber;
    }

    /**
     * Sets the value of the ofsApplicationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOFSApplicationNumber(String value) {
        this.ofsApplicationNumber = value;
    }

    /**
     * Gets the value of the ofsAliasName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOFSAliasName() {
        return ofsAliasName;
    }

    /**
     * Sets the value of the ofsAliasName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOFSAliasName(String value) {
        this.ofsAliasName = value;
    }

}
