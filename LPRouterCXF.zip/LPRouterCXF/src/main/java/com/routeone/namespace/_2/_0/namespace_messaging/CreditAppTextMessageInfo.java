
package com.routeone.namespace._2._0.namespace_messaging;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreditAppTextMessageInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditAppTextMessageInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSInfo2" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CaptiveUserID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PartnerSpecificAdditionalInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LenderApplicationNumber" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AlternateConversationID" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditAppTextMessageInfo", propOrder = {
    "fsInfo2",
    "captiveUserID",
    "partnerSpecificAdditionalInfo",
    "lenderApplicationNumber",
    "alternateConversationID"
})
public class CreditAppTextMessageInfo {

    @XmlElement(name = "FSInfo2")
    protected String fsInfo2;
    @XmlElement(name = "CaptiveUserID")
    protected String captiveUserID;
    @XmlElement(name = "PartnerSpecificAdditionalInfo")
    protected List<PartnerSpecificAdditionalInfo> partnerSpecificAdditionalInfo;
    @XmlElement(name = "LenderApplicationNumber")
    protected String lenderApplicationNumber;
    @XmlElement(name = "AlternateConversationID")
    protected String alternateConversationID;

    /**
     * Gets the value of the fsInfo2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFSInfo2() {
        return fsInfo2;
    }

    /**
     * Sets the value of the fsInfo2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFSInfo2(String value) {
        this.fsInfo2 = value;
    }

    /**
     * Gets the value of the captiveUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaptiveUserID() {
        return captiveUserID;
    }

    /**
     * Sets the value of the captiveUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaptiveUserID(String value) {
        this.captiveUserID = value;
    }

    /**
     * Gets the value of the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnerSpecificAdditionalInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerSpecificAdditionalInfo }
     * 
     * 
     */
    public List<PartnerSpecificAdditionalInfo> getPartnerSpecificAdditionalInfo() {
        if (partnerSpecificAdditionalInfo == null) {
            partnerSpecificAdditionalInfo = new ArrayList<PartnerSpecificAdditionalInfo>();
        }
        return this.partnerSpecificAdditionalInfo;
    }

    /**
     * Gets the value of the lenderApplicationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLenderApplicationNumber() {
        return lenderApplicationNumber;
    }

    /**
     * Sets the value of the lenderApplicationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLenderApplicationNumber(String value) {
        this.lenderApplicationNumber = value;
    }

    /**
     * Gets the value of the alternateConversationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternateConversationID() {
        return alternateConversationID;
    }

    /**
     * Sets the value of the alternateConversationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternateConversationID(String value) {
        this.alternateConversationID = value;
    }

}
