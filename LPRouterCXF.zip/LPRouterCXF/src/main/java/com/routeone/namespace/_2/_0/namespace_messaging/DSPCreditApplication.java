
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * DSP originated Credit Application
 * 			
 * 
 * <p>Java class for DSPCreditApplication complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DSPCreditApplication"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}R1DealerID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DSPDealerID" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DSPCreditApplication", propOrder = {
    "r1DealerID",
    "dspDealerID"
})
public class DSPCreditApplication {

    @XmlElement(name = "R1DealerID")
    protected String r1DealerID;
    @XmlElement(name = "DSPDealerID")
    protected String dspDealerID;
    @XmlAttribute(name = "type")
    protected String type;

    /**
     * Gets the value of the r1DealerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getR1DealerID() {
        return r1DealerID;
    }

    /**
     * Sets the value of the r1DealerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setR1DealerID(String value) {
        this.r1DealerID = value;
    }

    /**
     * Gets the value of the dspDealerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDSPDealerID() {
        return dspDealerID;
    }

    /**
     * Sets the value of the dspDealerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDSPDealerID(String value) {
        this.dspDealerID = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

}
