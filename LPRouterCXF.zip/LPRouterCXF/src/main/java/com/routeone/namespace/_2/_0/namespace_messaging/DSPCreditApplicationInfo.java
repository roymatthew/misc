
package com.routeone.namespace._2._0.namespace_messaging;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DSPCreditApplicationInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DSPCreditApplicationInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DSPUserID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DealerQualifier" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PartnerSpecificAdditionalInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SpecifiedSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EndpointList" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}EndpointListType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LeadType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}TradeInVehicleValueRefID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}ORSInfo" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AuditInfo" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FinanceSourceFederalDisclosures" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PayoffQuoteInquiry" minOccurs="0"/&gt;
 *         &lt;element name="AutoForwardInfo" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AutoForwardInfoType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AlternateConversationID" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DSPCreditApplicationInfo", propOrder = {
    "dspUserID",
    "dealerQualifier",
    "partnerSpecificAdditionalInfo",
    "specifiedSource",
    "endpointList",
    "leadType",
    "tradeInVehicleValueRefID",
    "orsInfo",
    "auditInfo",
    "financeSourceFederalDisclosures",
    "payoffQuoteInquiry",
    "autoForwardInfo",
    "alternateConversationID"
})
public class DSPCreditApplicationInfo {

    @XmlElement(name = "DSPUserID")
    protected String dspUserID;
    @XmlElement(name = "DealerQualifier")
    protected String dealerQualifier;
    @XmlElement(name = "PartnerSpecificAdditionalInfo")
    protected List<PartnerSpecificAdditionalInfo> partnerSpecificAdditionalInfo;
    @XmlElement(name = "SpecifiedSource")
    protected String specifiedSource;
    @XmlElement(name = "EndpointList")
    protected EndpointListType endpointList;
    @XmlElement(name = "LeadType")
    protected String leadType;
    @XmlElement(name = "TradeInVehicleValueRefID")
    protected String tradeInVehicleValueRefID;
    @XmlElement(name = "ORSInfo")
    protected ORSInfoType orsInfo;
    @XmlElement(name = "AuditInfo")
    protected AuditInfoType auditInfo;
    @XmlElement(name = "FinanceSourceFederalDisclosures")
    protected FinanceSourceFederalDisclosuresType financeSourceFederalDisclosures;
    @XmlElement(name = "PayoffQuoteInquiry")
    protected PayoffQuoteInquiryType payoffQuoteInquiry;
    @XmlElement(name = "AutoForwardInfo")
    protected AutoForwardInfoType autoForwardInfo;
    @XmlElement(name = "AlternateConversationID")
    protected String alternateConversationID;

    /**
     * Gets the value of the dspUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDSPUserID() {
        return dspUserID;
    }

    /**
     * Sets the value of the dspUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDSPUserID(String value) {
        this.dspUserID = value;
    }

    /**
     * Gets the value of the dealerQualifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerQualifier() {
        return dealerQualifier;
    }

    /**
     * Sets the value of the dealerQualifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerQualifier(String value) {
        this.dealerQualifier = value;
    }

    /**
     * Gets the value of the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnerSpecificAdditionalInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerSpecificAdditionalInfo }
     * 
     * 
     */
    public List<PartnerSpecificAdditionalInfo> getPartnerSpecificAdditionalInfo() {
        if (partnerSpecificAdditionalInfo == null) {
            partnerSpecificAdditionalInfo = new ArrayList<PartnerSpecificAdditionalInfo>();
        }
        return this.partnerSpecificAdditionalInfo;
    }

    /**
     * Gets the value of the specifiedSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecifiedSource() {
        return specifiedSource;
    }

    /**
     * Sets the value of the specifiedSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecifiedSource(String value) {
        this.specifiedSource = value;
    }

    /**
     * Gets the value of the endpointList property.
     * 
     * @return
     *     possible object is
     *     {@link EndpointListType }
     *     
     */
    public EndpointListType getEndpointList() {
        return endpointList;
    }

    /**
     * Sets the value of the endpointList property.
     * 
     * @param value
     *     allowed object is
     *     {@link EndpointListType }
     *     
     */
    public void setEndpointList(EndpointListType value) {
        this.endpointList = value;
    }

    /**
     * The partner's description of the type of lead
     * 						information contained within the message.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeadType() {
        return leadType;
    }

    /**
     * Sets the value of the leadType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeadType(String value) {
        this.leadType = value;
    }

    /**
     * The vehicle value OID of the previously stored
     * 						vehicle value response for a trade in vehicle through the storage
     * 						interface.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTradeInVehicleValueRefID() {
        return tradeInVehicleValueRefID;
    }

    /**
     * Sets the value of the tradeInVehicleValueRefID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTradeInVehicleValueRefID(String value) {
        this.tradeInVehicleValueRefID = value;
    }

    /**
     * Additional data used in ORS processing.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link ORSInfoType }
     *     
     */
    public ORSInfoType getORSInfo() {
        return orsInfo;
    }

    /**
     * Sets the value of the orsInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ORSInfoType }
     *     
     */
    public void setORSInfo(ORSInfoType value) {
        this.orsInfo = value;
    }

    /**
     * Auditing data used in ORS processing.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link AuditInfoType }
     *     
     */
    public AuditInfoType getAuditInfo() {
        return auditInfo;
    }

    /**
     * Sets the value of the auditInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuditInfoType }
     *     
     */
    public void setAuditInfo(AuditInfoType value) {
        this.auditInfo = value;
    }

    /**
     * Federal Disclosures acknowledged by the customer
     * 						used in ORS processing.
     * 
     * @return
     *     possible object is
     *     {@link FinanceSourceFederalDisclosuresType }
     *     
     */
    public FinanceSourceFederalDisclosuresType getFinanceSourceFederalDisclosures() {
        return financeSourceFederalDisclosures;
    }

    /**
     * Sets the value of the financeSourceFederalDisclosures property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinanceSourceFederalDisclosuresType }
     *     
     */
    public void setFinanceSourceFederalDisclosures(FinanceSourceFederalDisclosuresType value) {
        this.financeSourceFederalDisclosures = value;
    }

    /**
     * Additional data used in PayoffQuote processing.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link PayoffQuoteInquiryType }
     *     
     */
    public PayoffQuoteInquiryType getPayoffQuoteInquiry() {
        return payoffQuoteInquiry;
    }

    /**
     * Sets the value of the payoffQuoteInquiry property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayoffQuoteInquiryType }
     *     
     */
    public void setPayoffQuoteInquiry(PayoffQuoteInquiryType value) {
        this.payoffQuoteInquiry = value;
    }

    /**
     * Gets the value of the autoForwardInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AutoForwardInfoType }
     *     
     */
    public AutoForwardInfoType getAutoForwardInfo() {
        return autoForwardInfo;
    }

    /**
     * Sets the value of the autoForwardInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AutoForwardInfoType }
     *     
     */
    public void setAutoForwardInfo(AutoForwardInfoType value) {
        this.autoForwardInfo = value;
    }

    /**
     * Gets the value of the alternateConversationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternateConversationID() {
        return alternateConversationID;
    }

    /**
     * Sets the value of the alternateConversationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternateConversationID(String value) {
        this.alternateConversationID = value;
    }

}
