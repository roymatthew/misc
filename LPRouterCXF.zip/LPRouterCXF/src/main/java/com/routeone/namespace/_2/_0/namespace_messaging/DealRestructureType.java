
package com.routeone.namespace._2._0.namespace_messaging;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DealRestructureType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DealRestructureType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DownsellIncentiveAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="IncludedIncentiveAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="DefaultDealerRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DealRestructureType", propOrder = {
    "downsellIncentiveAmount",
    "includedIncentiveAmount",
    "defaultDealerRate"
})
public class DealRestructureType {

    @XmlElement(name = "DownsellIncentiveAmount")
    protected BigDecimal downsellIncentiveAmount;
    @XmlElement(name = "IncludedIncentiveAmount")
    protected BigDecimal includedIncentiveAmount;
    @XmlElement(name = "DefaultDealerRate")
    protected BigDecimal defaultDealerRate;

    /**
     * Gets the value of the downsellIncentiveAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDownsellIncentiveAmount() {
        return downsellIncentiveAmount;
    }

    /**
     * Sets the value of the downsellIncentiveAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDownsellIncentiveAmount(BigDecimal value) {
        this.downsellIncentiveAmount = value;
    }

    /**
     * Gets the value of the includedIncentiveAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getIncludedIncentiveAmount() {
        return includedIncentiveAmount;
    }

    /**
     * Sets the value of the includedIncentiveAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setIncludedIncentiveAmount(BigDecimal value) {
        this.includedIncentiveAmount = value;
    }

    /**
     * Gets the value of the defaultDealerRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDefaultDealerRate() {
        return defaultDealerRate;
    }

    /**
     * Sets the value of the defaultDealerRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDefaultDealerRate(BigDecimal value) {
        this.defaultDealerRate = value;
    }

}
