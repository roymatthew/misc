
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DocumentSignatureType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentSignatureType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ActorTypeCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FieldName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CaptureDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="DataFormat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CompressedDataInd" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="SignatureData" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentSignatureType", propOrder = {
    "actorTypeCode",
    "fieldName",
    "captureDateTime",
    "dataFormat",
    "compressedDataInd",
    "signatureData"
})
public class DocumentSignatureType {

    @XmlElement(name = "ActorTypeCode", required = true)
    protected String actorTypeCode;
    @XmlElement(name = "FieldName", required = true)
    protected String fieldName;
    @XmlElement(name = "CaptureDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar captureDateTime;
    @XmlElement(name = "DataFormat")
    protected String dataFormat;
    @XmlElement(name = "CompressedDataInd", required = true)
    protected String compressedDataInd;
    @XmlElement(name = "SignatureData", required = true)
    protected String signatureData;

    /**
     * Gets the value of the actorTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActorTypeCode() {
        return actorTypeCode;
    }

    /**
     * Sets the value of the actorTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActorTypeCode(String value) {
        this.actorTypeCode = value;
    }

    /**
     * Gets the value of the fieldName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * Sets the value of the fieldName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFieldName(String value) {
        this.fieldName = value;
    }

    /**
     * Gets the value of the captureDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCaptureDateTime() {
        return captureDateTime;
    }

    /**
     * Sets the value of the captureDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCaptureDateTime(XMLGregorianCalendar value) {
        this.captureDateTime = value;
    }

    /**
     * Gets the value of the dataFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFormat() {
        return dataFormat;
    }

    /**
     * Sets the value of the dataFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFormat(String value) {
        this.dataFormat = value;
    }

    /**
     * Gets the value of the compressedDataInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompressedDataInd() {
        return compressedDataInd;
    }

    /**
     * Sets the value of the compressedDataInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompressedDataInd(String value) {
        this.compressedDataInd = value;
    }

    /**
     * Gets the value of the signatureData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureData() {
        return signatureData;
    }

    /**
     * Sets the value of the signatureData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureData(String value) {
        this.signatureData = value;
    }

}
