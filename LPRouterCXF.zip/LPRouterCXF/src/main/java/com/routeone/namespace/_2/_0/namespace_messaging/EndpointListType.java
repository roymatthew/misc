
package com.routeone.namespace._2._0.namespace_messaging;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for EndpointListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EndpointListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Endpoint" maxOccurs="6"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="EndpointID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                   &lt;element name="Endpointparam" maxOccurs="unbounded" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;simpleContent&gt;
 *                         &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
 *                           &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                         &lt;/extension&gt;
 *                       &lt;/simpleContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="TierProcessingInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Descriptor" minOccurs="0"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="60"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PartnerSpecificAdditionalInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EndpointListType", propOrder = {
    "endpoint"
})
public class EndpointListType {

    @XmlElement(name = "Endpoint", required = true)
    protected List<EndpointListType.Endpoint> endpoint;

    /**
     * Gets the value of the endpoint property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the endpoint property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEndpoint().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EndpointListType.Endpoint }
     * 
     * 
     */
    public List<EndpointListType.Endpoint> getEndpoint() {
        if (endpoint == null) {
            endpoint = new ArrayList<EndpointListType.Endpoint>();
        }
        return this.endpoint;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="EndpointID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *         &lt;element name="Endpointparam" maxOccurs="unbounded" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;simpleContent&gt;
     *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
     *                 &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *               &lt;/extension&gt;
     *             &lt;/simpleContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="TierProcessingInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Descriptor" minOccurs="0"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="60"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PartnerSpecificAdditionalInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "endpointID",
        "endpointparam",
        "tierProcessingInd",
        "descriptor",
        "partnerSpecificAdditionalInfo"
    })
    public static class Endpoint {

        @XmlElement(name = "EndpointID", required = true)
        protected String endpointID;
        @XmlElement(name = "Endpointparam")
        protected List<EndpointListType.Endpoint.Endpointparam> endpointparam;
        @XmlElement(name = "TierProcessingInd")
        protected String tierProcessingInd;
        @XmlElement(name = "Descriptor")
        protected String descriptor;
        @XmlElement(name = "PartnerSpecificAdditionalInfo")
        protected List<PartnerSpecificAdditionalInfo> partnerSpecificAdditionalInfo;

        /**
         * Gets the value of the endpointID property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEndpointID() {
            return endpointID;
        }

        /**
         * Sets the value of the endpointID property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEndpointID(String value) {
            this.endpointID = value;
        }

        /**
         * Gets the value of the endpointparam property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the endpointparam property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEndpointparam().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link EndpointListType.Endpoint.Endpointparam }
         * 
         * 
         */
        public List<EndpointListType.Endpoint.Endpointparam> getEndpointparam() {
            if (endpointparam == null) {
                endpointparam = new ArrayList<EndpointListType.Endpoint.Endpointparam>();
            }
            return this.endpointparam;
        }

        /**
         * Gets the value of the tierProcessingInd property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTierProcessingInd() {
            return tierProcessingInd;
        }

        /**
         * Sets the value of the tierProcessingInd property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTierProcessingInd(String value) {
            this.tierProcessingInd = value;
        }

        /**
         * Gets the value of the descriptor property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDescriptor() {
            return descriptor;
        }

        /**
         * Sets the value of the descriptor property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDescriptor(String value) {
            this.descriptor = value;
        }

        /**
         * Gets the value of the partnerSpecificAdditionalInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the partnerSpecificAdditionalInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPartnerSpecificAdditionalInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PartnerSpecificAdditionalInfo }
         * 
         * 
         */
        public List<PartnerSpecificAdditionalInfo> getPartnerSpecificAdditionalInfo() {
            if (partnerSpecificAdditionalInfo == null) {
                partnerSpecificAdditionalInfo = new ArrayList<PartnerSpecificAdditionalInfo>();
            }
            return this.partnerSpecificAdditionalInfo;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;simpleContent&gt;
         *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
         *       &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
         *     &lt;/extension&gt;
         *   &lt;/simpleContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class Endpointparam {

            @XmlValue
            protected String value;
            @XmlAttribute(name = "name", required = true)
            protected String name;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setValue(String value) {
                this.value = value;
            }

            /**
             * Gets the value of the name property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getName() {
                return name;
            }

            /**
             * Sets the value of the name property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setName(String value) {
                this.name = value;
            }

        }

    }

}
