
package com.routeone.namespace._2._0.namespace_messaging;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The additional info element type for the Finance
 * 				Source originate Credit Application and Decision
 * 
 * <p>Java class for FSCreditApplicationDecisionInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FSCreditApplicationDecisionInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSInfo1" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSInfo2" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}Descriptor" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PartnerSpecificAdditionalInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LeadType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DealUpdateAllowed" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}OriginatingSource" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FSCreditApplicationDecisionInfo", propOrder = {
    "fsInfo1",
    "fsInfo2",
    "descriptor",
    "partnerSpecificAdditionalInfo",
    "leadType",
    "dealUpdateAllowed",
    "originatingSource"
})
public class FSCreditApplicationDecisionInfo {

    @XmlElement(name = "FSInfo1")
    protected String fsInfo1;
    @XmlElement(name = "FSInfo2")
    protected String fsInfo2;
    @XmlElement(name = "Descriptor")
    protected String descriptor;
    @XmlElement(name = "PartnerSpecificAdditionalInfo")
    protected List<PartnerSpecificAdditionalInfo> partnerSpecificAdditionalInfo;
    @XmlElement(name = "LeadType")
    protected String leadType;
    @XmlElement(name = "DealUpdateAllowed")
    protected String dealUpdateAllowed;
    @XmlElement(name = "OriginatingSource")
    protected String originatingSource;

    /**
     * Gets the value of the fsInfo1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFSInfo1() {
        return fsInfo1;
    }

    /**
     * Sets the value of the fsInfo1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFSInfo1(String value) {
        this.fsInfo1 = value;
    }

    /**
     * Gets the value of the fsInfo2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFSInfo2() {
        return fsInfo2;
    }

    /**
     * Sets the value of the fsInfo2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFSInfo2(String value) {
        this.fsInfo2 = value;
    }

    /**
     * Gets the value of the descriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescriptor() {
        return descriptor;
    }

    /**
     * Sets the value of the descriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescriptor(String value) {
        this.descriptor = value;
    }

    /**
     * Gets the value of the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnerSpecificAdditionalInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerSpecificAdditionalInfo }
     * 
     * 
     */
    public List<PartnerSpecificAdditionalInfo> getPartnerSpecificAdditionalInfo() {
        if (partnerSpecificAdditionalInfo == null) {
            partnerSpecificAdditionalInfo = new ArrayList<PartnerSpecificAdditionalInfo>();
        }
        return this.partnerSpecificAdditionalInfo;
    }

    /**
     * The partner's description of the type of lead
     * 						information contained within the message.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeadType() {
        return leadType;
    }

    /**
     * Sets the value of the leadType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeadType(String value) {
        this.leadType = value;
    }

    /**
     * Gets the value of the dealUpdateAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealUpdateAllowed() {
        return dealUpdateAllowed;
    }

    /**
     * Sets the value of the dealUpdateAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealUpdateAllowed(String value) {
        this.dealUpdateAllowed = value;
    }

    /**
     * Gets the value of the originatingSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingSource() {
        return originatingSource;
    }

    /**
     * Sets the value of the originatingSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingSource(String value) {
        this.originatingSource = value;
    }

}
