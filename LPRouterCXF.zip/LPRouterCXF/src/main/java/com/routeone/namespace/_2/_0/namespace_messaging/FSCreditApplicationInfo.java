
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FSCreditApplicationInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FSCreditApplicationInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EndpointList" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}EndpointListType" minOccurs="0"/&gt;
 *         &lt;element name="RestrictModification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LeadType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FSCreditApplicationInfo", propOrder = {
    "endpointList",
    "restrictModification",
    "leadType"
})
public class FSCreditApplicationInfo {

    @XmlElement(name = "EndpointList")
    protected EndpointListType endpointList;
    @XmlElement(name = "RestrictModification")
    protected String restrictModification;
    @XmlElement(name = "LeadType")
    protected String leadType;

    /**
     * Gets the value of the endpointList property.
     * 
     * @return
     *     possible object is
     *     {@link EndpointListType }
     *     
     */
    public EndpointListType getEndpointList() {
        return endpointList;
    }

    /**
     * Sets the value of the endpointList property.
     * 
     * @param value
     *     allowed object is
     *     {@link EndpointListType }
     *     
     */
    public void setEndpointList(EndpointListType value) {
        this.endpointList = value;
    }

    /**
     * Gets the value of the restrictModification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictModification() {
        return restrictModification;
    }

    /**
     * Sets the value of the restrictModification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictModification(String value) {
        this.restrictModification = value;
    }

    /**
     * The partner's description of the type of lead
     * 						information contained within the message.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeadType() {
        return leadType;
    }

    /**
     * Sets the value of the leadType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeadType(String value) {
        this.leadType = value;
    }

}
