
package com.routeone.namespace._2._0.namespace_messaging;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LTV complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LTV"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Actual" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="Maximum" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="Comment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LTVItem" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LTVColumn" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LTV", propOrder = {
    "actual",
    "maximum",
    "comment",
    "ltvItem",
    "ltvColumn"
})
public class LTV {

    @XmlElement(name = "Actual")
    protected BigDecimal actual;
    @XmlElement(name = "Maximum")
    protected BigDecimal maximum;
    @XmlElement(name = "Comment")
    protected String comment;
    @XmlElement(name = "LTVItem")
    protected List<LTVItem> ltvItem;
    @XmlElement(name = "LTVColumn")
    protected List<LTVColumn> ltvColumn;

    /**
     * Gets the value of the actual property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getActual() {
        return actual;
    }

    /**
     * Sets the value of the actual property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setActual(BigDecimal value) {
        this.actual = value;
    }

    /**
     * Gets the value of the maximum property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximum() {
        return maximum;
    }

    /**
     * Sets the value of the maximum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximum(BigDecimal value) {
        this.maximum = value;
    }

    /**
     * Gets the value of the comment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the value of the comment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComment(String value) {
        this.comment = value;
    }

    /**
     * Gets the value of the ltvItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ltvItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLTVItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LTVItem }
     * 
     * 
     */
    public List<LTVItem> getLTVItem() {
        if (ltvItem == null) {
            ltvItem = new ArrayList<LTVItem>();
        }
        return this.ltvItem;
    }

    /**
     * Gets the value of the ltvColumn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ltvColumn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLTVColumn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LTVColumn }
     * 
     * 
     */
    public List<LTVColumn> getLTVColumn() {
        if (ltvColumn == null) {
            ltvColumn = new ArrayList<LTVColumn>();
        }
        return this.ltvColumn;
    }

}
