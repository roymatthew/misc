
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LTVColumn complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LTVColumn"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Row1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row9" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Row10" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LTVColumn", propOrder = {
    "row1",
    "row2",
    "row3",
    "row4",
    "row5",
    "row6",
    "row7",
    "row8",
    "row9",
    "row10"
})
public class LTVColumn {

    @XmlElement(name = "Row1")
    protected String row1;
    @XmlElement(name = "Row2")
    protected String row2;
    @XmlElement(name = "Row3")
    protected String row3;
    @XmlElement(name = "Row4")
    protected String row4;
    @XmlElement(name = "Row5")
    protected String row5;
    @XmlElement(name = "Row6")
    protected String row6;
    @XmlElement(name = "Row7")
    protected String row7;
    @XmlElement(name = "Row8")
    protected String row8;
    @XmlElement(name = "Row9")
    protected String row9;
    @XmlElement(name = "Row10")
    protected String row10;

    /**
     * Gets the value of the row1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow1() {
        return row1;
    }

    /**
     * Sets the value of the row1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow1(String value) {
        this.row1 = value;
    }

    /**
     * Gets the value of the row2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow2() {
        return row2;
    }

    /**
     * Sets the value of the row2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow2(String value) {
        this.row2 = value;
    }

    /**
     * Gets the value of the row3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow3() {
        return row3;
    }

    /**
     * Sets the value of the row3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow3(String value) {
        this.row3 = value;
    }

    /**
     * Gets the value of the row4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow4() {
        return row4;
    }

    /**
     * Sets the value of the row4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow4(String value) {
        this.row4 = value;
    }

    /**
     * Gets the value of the row5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow5() {
        return row5;
    }

    /**
     * Sets the value of the row5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow5(String value) {
        this.row5 = value;
    }

    /**
     * Gets the value of the row6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow6() {
        return row6;
    }

    /**
     * Sets the value of the row6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow6(String value) {
        this.row6 = value;
    }

    /**
     * Gets the value of the row7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow7() {
        return row7;
    }

    /**
     * Sets the value of the row7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow7(String value) {
        this.row7 = value;
    }

    /**
     * Gets the value of the row8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow8() {
        return row8;
    }

    /**
     * Sets the value of the row8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow8(String value) {
        this.row8 = value;
    }

    /**
     * Gets the value of the row9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow9() {
        return row9;
    }

    /**
     * Sets the value of the row9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow9(String value) {
        this.row9 = value;
    }

    /**
     * Gets the value of the row10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRow10() {
        return row10;
    }

    /**
     * Sets the value of the row10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRow10(String value) {
        this.row10 = value;
    }

}
