
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Container for the message identifiers. The element
 * 				name itself will provide the name of the message type
 * 			
 * 
 * <p>Java class for MessageIdentifier complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageIdentifier"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="FSCreditApplicationDecision" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSCreditApplicationDecision"/&gt;
 *         &lt;element name="CreditAppTextMessage" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CreditAppTextMessage"/&gt;
 *         &lt;element name="RouteOneCreditApplication" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditApplication"/&gt;
 *         &lt;element name="RouteOneCreditDecision" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditDecision"/&gt;
 *         &lt;element name="DSPCreditApplication" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DSPCreditApplication"/&gt;
 *         &lt;element name="R1CreditApplicationDecision" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}R1CreditApplicationDecision"/&gt;
 *         &lt;element name="FSCreditApplication" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSCreditApplication"/&gt;
 *         &lt;element name="CreditCardApplication" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CreditCardApplication"/&gt;
 *         &lt;element name="CreditCardDecision" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CreditCardDecision"/&gt;
 *         &lt;element name="RouteOneCreditContract" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneCreditContract"/&gt;
 *         &lt;element name="RouteOneSupplement" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}RouteOneSupplement"/&gt;
 *         &lt;element name="PreApprovalRequest" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PreApprovalRequest"/&gt;
 *         &lt;element name="CAStipulationDocuments" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CAStipulationDocuments"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageIdentifier", propOrder = {
    "fsCreditApplicationDecision",
    "creditAppTextMessage",
    "routeOneCreditApplication",
    "routeOneCreditDecision",
    "dspCreditApplication",
    "r1CreditApplicationDecision",
    "fsCreditApplication",
    "creditCardApplication",
    "creditCardDecision",
    "routeOneCreditContract",
    "routeOneSupplement",
    "preApprovalRequest",
    "caStipulationDocuments"
})
public class MessageIdentifier {

    @XmlElement(name = "FSCreditApplicationDecision")
    protected FSCreditApplicationDecision fsCreditApplicationDecision;
    @XmlElement(name = "CreditAppTextMessage")
    protected CreditAppTextMessage creditAppTextMessage;
    @XmlElement(name = "RouteOneCreditApplication")
    protected RouteOneCreditApplication routeOneCreditApplication;
    @XmlElement(name = "RouteOneCreditDecision")
    protected RouteOneCreditDecision routeOneCreditDecision;
    @XmlElement(name = "DSPCreditApplication")
    protected DSPCreditApplication dspCreditApplication;
    @XmlElement(name = "R1CreditApplicationDecision")
    protected R1CreditApplicationDecision r1CreditApplicationDecision;
    @XmlElement(name = "FSCreditApplication")
    protected FSCreditApplication fsCreditApplication;
    @XmlElement(name = "CreditCardApplication")
    protected CreditCardApplication creditCardApplication;
    @XmlElement(name = "CreditCardDecision")
    protected CreditCardDecision creditCardDecision;
    @XmlElement(name = "RouteOneCreditContract")
    protected RouteOneCreditContract routeOneCreditContract;
    @XmlElement(name = "RouteOneSupplement")
    protected RouteOneSupplement routeOneSupplement;
    @XmlElement(name = "PreApprovalRequest")
    protected PreApprovalRequest preApprovalRequest;
    @XmlElement(name = "CAStipulationDocuments")
    protected CAStipulationDocuments caStipulationDocuments;

    /**
     * Gets the value of the fsCreditApplicationDecision property.
     * 
     * @return
     *     possible object is
     *     {@link FSCreditApplicationDecision }
     *     
     */
    public FSCreditApplicationDecision getFSCreditApplicationDecision() {
        return fsCreditApplicationDecision;
    }

    /**
     * Sets the value of the fsCreditApplicationDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link FSCreditApplicationDecision }
     *     
     */
    public void setFSCreditApplicationDecision(FSCreditApplicationDecision value) {
        this.fsCreditApplicationDecision = value;
    }

    /**
     * Gets the value of the creditAppTextMessage property.
     * 
     * @return
     *     possible object is
     *     {@link CreditAppTextMessage }
     *     
     */
    public CreditAppTextMessage getCreditAppTextMessage() {
        return creditAppTextMessage;
    }

    /**
     * Sets the value of the creditAppTextMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditAppTextMessage }
     *     
     */
    public void setCreditAppTextMessage(CreditAppTextMessage value) {
        this.creditAppTextMessage = value;
    }

    /**
     * Gets the value of the routeOneCreditApplication property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditApplication }
     *     
     */
    public RouteOneCreditApplication getRouteOneCreditApplication() {
        return routeOneCreditApplication;
    }

    /**
     * Sets the value of the routeOneCreditApplication property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditApplication }
     *     
     */
    public void setRouteOneCreditApplication(RouteOneCreditApplication value) {
        this.routeOneCreditApplication = value;
    }

    /**
     * Gets the value of the routeOneCreditDecision property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditDecision }
     *     
     */
    public RouteOneCreditDecision getRouteOneCreditDecision() {
        return routeOneCreditDecision;
    }

    /**
     * Sets the value of the routeOneCreditDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditDecision }
     *     
     */
    public void setRouteOneCreditDecision(RouteOneCreditDecision value) {
        this.routeOneCreditDecision = value;
    }

    /**
     * Gets the value of the dspCreditApplication property.
     * 
     * @return
     *     possible object is
     *     {@link DSPCreditApplication }
     *     
     */
    public DSPCreditApplication getDSPCreditApplication() {
        return dspCreditApplication;
    }

    /**
     * Sets the value of the dspCreditApplication property.
     * 
     * @param value
     *     allowed object is
     *     {@link DSPCreditApplication }
     *     
     */
    public void setDSPCreditApplication(DSPCreditApplication value) {
        this.dspCreditApplication = value;
    }

    /**
     * Gets the value of the r1CreditApplicationDecision property.
     * 
     * @return
     *     possible object is
     *     {@link R1CreditApplicationDecision }
     *     
     */
    public R1CreditApplicationDecision getR1CreditApplicationDecision() {
        return r1CreditApplicationDecision;
    }

    /**
     * Sets the value of the r1CreditApplicationDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link R1CreditApplicationDecision }
     *     
     */
    public void setR1CreditApplicationDecision(R1CreditApplicationDecision value) {
        this.r1CreditApplicationDecision = value;
    }

    /**
     * Gets the value of the fsCreditApplication property.
     * 
     * @return
     *     possible object is
     *     {@link FSCreditApplication }
     *     
     */
    public FSCreditApplication getFSCreditApplication() {
        return fsCreditApplication;
    }

    /**
     * Sets the value of the fsCreditApplication property.
     * 
     * @param value
     *     allowed object is
     *     {@link FSCreditApplication }
     *     
     */
    public void setFSCreditApplication(FSCreditApplication value) {
        this.fsCreditApplication = value;
    }

    /**
     * Gets the value of the creditCardApplication property.
     * 
     * @return
     *     possible object is
     *     {@link CreditCardApplication }
     *     
     */
    public CreditCardApplication getCreditCardApplication() {
        return creditCardApplication;
    }

    /**
     * Sets the value of the creditCardApplication property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardApplication }
     *     
     */
    public void setCreditCardApplication(CreditCardApplication value) {
        this.creditCardApplication = value;
    }

    /**
     * Gets the value of the creditCardDecision property.
     * 
     * @return
     *     possible object is
     *     {@link CreditCardDecision }
     *     
     */
    public CreditCardDecision getCreditCardDecision() {
        return creditCardDecision;
    }

    /**
     * Sets the value of the creditCardDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardDecision }
     *     
     */
    public void setCreditCardDecision(CreditCardDecision value) {
        this.creditCardDecision = value;
    }

    /**
     * Gets the value of the routeOneCreditContract property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneCreditContract }
     *     
     */
    public RouteOneCreditContract getRouteOneCreditContract() {
        return routeOneCreditContract;
    }

    /**
     * Sets the value of the routeOneCreditContract property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneCreditContract }
     *     
     */
    public void setRouteOneCreditContract(RouteOneCreditContract value) {
        this.routeOneCreditContract = value;
    }

    /**
     * Gets the value of the routeOneSupplement property.
     * 
     * @return
     *     possible object is
     *     {@link RouteOneSupplement }
     *     
     */
    public RouteOneSupplement getRouteOneSupplement() {
        return routeOneSupplement;
    }

    /**
     * Sets the value of the routeOneSupplement property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteOneSupplement }
     *     
     */
    public void setRouteOneSupplement(RouteOneSupplement value) {
        this.routeOneSupplement = value;
    }

    /**
     * Gets the value of the preApprovalRequest property.
     * 
     * @return
     *     possible object is
     *     {@link PreApprovalRequest }
     *     
     */
    public PreApprovalRequest getPreApprovalRequest() {
        return preApprovalRequest;
    }

    /**
     * Sets the value of the preApprovalRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link PreApprovalRequest }
     *     
     */
    public void setPreApprovalRequest(PreApprovalRequest value) {
        this.preApprovalRequest = value;
    }

    /**
     * Gets the value of the caStipulationDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link CAStipulationDocuments }
     *     
     */
    public CAStipulationDocuments getCAStipulationDocuments() {
        return caStipulationDocuments;
    }

    /**
     * Sets the value of the caStipulationDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link CAStipulationDocuments }
     *     
     */
    public void setCAStipulationDocuments(CAStipulationDocuments value) {
        this.caStipulationDocuments = value;
    }

}
