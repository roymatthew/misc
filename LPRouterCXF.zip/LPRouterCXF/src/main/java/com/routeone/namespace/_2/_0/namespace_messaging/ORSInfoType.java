
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ORSInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ORSInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IncentiveIndicator" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="Y"/&gt;
 *               &lt;enumeration value="N"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApplyDealerMarkupIndicator" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="Y"/&gt;
 *               &lt;enumeration value="N"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DealRestructure" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DealRestructureType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ORSInfoType", propOrder = {
    "incentiveIndicator",
    "applyDealerMarkupIndicator",
    "dealRestructure"
})
public class ORSInfoType {

    @XmlElement(name = "IncentiveIndicator")
    protected String incentiveIndicator;
    @XmlElement(name = "ApplyDealerMarkupIndicator")
    protected String applyDealerMarkupIndicator;
    @XmlElement(name = "DealRestructure")
    protected DealRestructureType dealRestructure;

    /**
     * Gets the value of the incentiveIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncentiveIndicator() {
        return incentiveIndicator;
    }

    /**
     * Sets the value of the incentiveIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncentiveIndicator(String value) {
        this.incentiveIndicator = value;
    }

    /**
     * Gets the value of the applyDealerMarkupIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplyDealerMarkupIndicator() {
        return applyDealerMarkupIndicator;
    }

    /**
     * Sets the value of the applyDealerMarkupIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplyDealerMarkupIndicator(String value) {
        this.applyDealerMarkupIndicator = value;
    }

    /**
     * Gets the value of the dealRestructure property.
     * 
     * @return
     *     possible object is
     *     {@link DealRestructureType }
     *     
     */
    public DealRestructureType getDealRestructure() {
        return dealRestructure;
    }

    /**
     * Sets the value of the dealRestructure property.
     * 
     * @param value
     *     allowed object is
     *     {@link DealRestructureType }
     *     
     */
    public void setDealRestructure(DealRestructureType value) {
        this.dealRestructure = value;
    }

}
