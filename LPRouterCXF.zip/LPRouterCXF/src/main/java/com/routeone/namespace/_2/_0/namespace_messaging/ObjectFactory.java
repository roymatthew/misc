
package com.routeone.namespace._2._0.namespace_messaging;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.routeone.namespace._2._0.namespace_messaging package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RouteOne_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOne");
    private final static QName _FSCreditApplicationDecisionInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FSCreditApplicationDecisionInfo");
    private final static QName _RouteOneCreditApplicationInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOneCreditApplicationInfo");
    private final static QName _RouteOneCreditDecisionInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOneCreditDecisionInfo");
    private final static QName _FSCreditApplicationInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FSCreditApplicationInfo");
    private final static QName _RouteOneCreditContractInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOneCreditContractInfo");
    private final static QName _RouteOneSupplementInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOneSupplementInfo");
    private final static QName _RouteOneCreditCardApplicationInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOneCreditCardApplicationInfo");
    private final static QName _RouteOneCreditCardDecisionInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "RouteOneCreditCardDecisionInfo");
    private final static QName _CoBuyerVersionNumber_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "CoBuyerVersionNumber");
    private final static QName _SequenceNo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "SequenceNo");
    private final static QName _R1FSID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "R1FSID");
    private final static QName _DSPDealerID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "DSPDealerID");
    private final static QName _FSDealerID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FSDealerID");
    private final static QName _R1DealerID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "R1DealerID");
    private final static QName _FSInfo1_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FSInfo1");
    private final static QName _FSInfo2_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FSInfo2");
    private final static QName _Descriptor_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "Descriptor");
    private final static QName _Ref2SequenceNo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "Ref2SequenceNo");
    private final static QName _CaptiveUserID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "CaptiveUserID");
    private final static QName _OriginalSourceID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "OriginalSourceID");
    private final static QName _CopyReason_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "CopyReason");
    private final static QName _DealerQualifier_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "DealerQualifier");
    private final static QName _CreditAppTextMessageInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "CreditAppTextMessageInfo");
    private final static QName _CAStipulationDocumentsInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "CAStipulationDocumentsInfo");
    private final static QName _R1CreditApplicationDecisionInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "R1CreditApplicationDecisionInfo");
    private final static QName _DSPCreditApplicationInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "DSPCreditApplicationInfo");
    private final static QName _DSPUserID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "DSPUserID");
    private final static QName _Reserve_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "Reserve");
    private final static QName _LTV_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "LTV");
    private final static QName _LTVItem_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "LTVItem");
    private final static QName _LTVColumn_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "LTVColumn");
    private final static QName _DealUpdateAllowed_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "DealUpdateAllowed");
    private final static QName _LenderApplicationNumber_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "LenderApplicationNumber");
    private final static QName _AlternateConversationID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "AlternateConversationID");
    private final static QName _LeadType_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "LeadType");
    private final static QName _TradeInVehicleValueRefID_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "TradeInVehicleValueRefID");
    private final static QName _FaultInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FaultInfo");
    private final static QName _ORSInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "ORSInfo");
    private final static QName _AuditInfo_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "AuditInfo");
    private final static QName _FinanceSourceFederalDisclosures_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "FinanceSourceFederalDisclosures");
    private final static QName _PayoffQuoteInquiry_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "PayoffQuoteInquiry");
    private final static QName _DocumentSignature_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "DocumentSignature");
    private final static QName _OriginatingSource_QNAME = new QName("http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", "OriginatingSource");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.routeone.namespace._2._0.namespace_messaging
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AutoForwardEndpointListType }
     * 
     */
    public AutoForwardEndpointListType createAutoForwardEndpointListType() {
        return new AutoForwardEndpointListType();
    }

    /**
     * Create an instance of {@link AutoForwardEndpointListType.Endpoint }
     * 
     */
    public AutoForwardEndpointListType.Endpoint createAutoForwardEndpointListTypeEndpoint() {
        return new AutoForwardEndpointListType.Endpoint();
    }

    /**
     * Create an instance of {@link EndpointListType }
     * 
     */
    public EndpointListType createEndpointListType() {
        return new EndpointListType();
    }

    /**
     * Create an instance of {@link EndpointListType.Endpoint }
     * 
     */
    public EndpointListType.Endpoint createEndpointListTypeEndpoint() {
        return new EndpointListType.Endpoint();
    }

    /**
     * Create an instance of {@link RouteOne }
     * 
     */
    public RouteOne createRouteOne() {
        return new RouteOne();
    }

    /**
     * Create an instance of {@link FSCreditApplicationDecisionInfo }
     * 
     */
    public FSCreditApplicationDecisionInfo createFSCreditApplicationDecisionInfo() {
        return new FSCreditApplicationDecisionInfo();
    }

    /**
     * Create an instance of {@link RouteOneCreditApplicationInfo }
     * 
     */
    public RouteOneCreditApplicationInfo createRouteOneCreditApplicationInfo() {
        return new RouteOneCreditApplicationInfo();
    }

    /**
     * Create an instance of {@link RouteOneCreditDecisionInfo }
     * 
     */
    public RouteOneCreditDecisionInfo createRouteOneCreditDecisionInfo() {
        return new RouteOneCreditDecisionInfo();
    }

    /**
     * Create an instance of {@link FSCreditApplicationInfo }
     * 
     */
    public FSCreditApplicationInfo createFSCreditApplicationInfo() {
        return new FSCreditApplicationInfo();
    }

    /**
     * Create an instance of {@link RouteOneCreditContractInfo }
     * 
     */
    public RouteOneCreditContractInfo createRouteOneCreditContractInfo() {
        return new RouteOneCreditContractInfo();
    }

    /**
     * Create an instance of {@link RouteOneSupplementInfo }
     * 
     */
    public RouteOneSupplementInfo createRouteOneSupplementInfo() {
        return new RouteOneSupplementInfo();
    }

    /**
     * Create an instance of {@link RouteOneCreditCardApplicationInfo }
     * 
     */
    public RouteOneCreditCardApplicationInfo createRouteOneCreditCardApplicationInfo() {
        return new RouteOneCreditCardApplicationInfo();
    }

    /**
     * Create an instance of {@link RouteOneCreditCardDecisionInfo }
     * 
     */
    public RouteOneCreditCardDecisionInfo createRouteOneCreditCardDecisionInfo() {
        return new RouteOneCreditCardDecisionInfo();
    }

    /**
     * Create an instance of {@link CreditAppTextMessageInfo }
     * 
     */
    public CreditAppTextMessageInfo createCreditAppTextMessageInfo() {
        return new CreditAppTextMessageInfo();
    }

    /**
     * Create an instance of {@link CAStipulationDocumentsInfo }
     * 
     */
    public CAStipulationDocumentsInfo createCAStipulationDocumentsInfo() {
        return new CAStipulationDocumentsInfo();
    }

    /**
     * Create an instance of {@link R1CreditApplicationDecisionInfo }
     * 
     */
    public R1CreditApplicationDecisionInfo createR1CreditApplicationDecisionInfo() {
        return new R1CreditApplicationDecisionInfo();
    }

    /**
     * Create an instance of {@link DSPCreditApplicationInfo }
     * 
     */
    public DSPCreditApplicationInfo createDSPCreditApplicationInfo() {
        return new DSPCreditApplicationInfo();
    }

    /**
     * Create an instance of {@link PartnerSpecificAdditionalInfo }
     * 
     */
    public PartnerSpecificAdditionalInfo createPartnerSpecificAdditionalInfo() {
        return new PartnerSpecificAdditionalInfo();
    }

    /**
     * Create an instance of {@link Reserve }
     * 
     */
    public Reserve createReserve() {
        return new Reserve();
    }

    /**
     * Create an instance of {@link LTV }
     * 
     */
    public LTV createLTV() {
        return new LTV();
    }

    /**
     * Create an instance of {@link LTVItem }
     * 
     */
    public LTVItem createLTVItem() {
        return new LTVItem();
    }

    /**
     * Create an instance of {@link LTVColumn }
     * 
     */
    public LTVColumn createLTVColumn() {
        return new LTVColumn();
    }

    /**
     * Create an instance of {@link FaultInfo }
     * 
     */
    public FaultInfo createFaultInfo() {
        return new FaultInfo();
    }

    /**
     * Create an instance of {@link ORSInfoType }
     * 
     */
    public ORSInfoType createORSInfoType() {
        return new ORSInfoType();
    }

    /**
     * Create an instance of {@link AuditInfoType }
     * 
     */
    public AuditInfoType createAuditInfoType() {
        return new AuditInfoType();
    }

    /**
     * Create an instance of {@link FinanceSourceFederalDisclosuresType }
     * 
     */
    public FinanceSourceFederalDisclosuresType createFinanceSourceFederalDisclosuresType() {
        return new FinanceSourceFederalDisclosuresType();
    }

    /**
     * Create an instance of {@link PayoffQuoteInquiryType }
     * 
     */
    public PayoffQuoteInquiryType createPayoffQuoteInquiryType() {
        return new PayoffQuoteInquiryType();
    }

    /**
     * Create an instance of {@link DocumentSignatureType }
     * 
     */
    public DocumentSignatureType createDocumentSignatureType() {
        return new DocumentSignatureType();
    }

    /**
     * Create an instance of {@link MessageIdentifier }
     * 
     */
    public MessageIdentifier createMessageIdentifier() {
        return new MessageIdentifier();
    }

    /**
     * Create an instance of {@link FSCreditApplication }
     * 
     */
    public FSCreditApplication createFSCreditApplication() {
        return new FSCreditApplication();
    }

    /**
     * Create an instance of {@link FSCreditApplicationDecision }
     * 
     */
    public FSCreditApplicationDecision createFSCreditApplicationDecision() {
        return new FSCreditApplicationDecision();
    }

    /**
     * Create an instance of {@link CreditAppTextMessage }
     * 
     */
    public CreditAppTextMessage createCreditAppTextMessage() {
        return new CreditAppTextMessage();
    }

    /**
     * Create an instance of {@link CAStipulationDocuments }
     * 
     */
    public CAStipulationDocuments createCAStipulationDocuments() {
        return new CAStipulationDocuments();
    }

    /**
     * Create an instance of {@link RouteOneCreditApplication }
     * 
     */
    public RouteOneCreditApplication createRouteOneCreditApplication() {
        return new RouteOneCreditApplication();
    }

    /**
     * Create an instance of {@link RouteOneCreditDecision }
     * 
     */
    public RouteOneCreditDecision createRouteOneCreditDecision() {
        return new RouteOneCreditDecision();
    }

    /**
     * Create an instance of {@link RouteOneCreditContract }
     * 
     */
    public RouteOneCreditContract createRouteOneCreditContract() {
        return new RouteOneCreditContract();
    }

    /**
     * Create an instance of {@link AdditionalInfo }
     * 
     */
    public AdditionalInfo createAdditionalInfo() {
        return new AdditionalInfo();
    }

    /**
     * Create an instance of {@link R1CreditApplicationDecision }
     * 
     */
    public R1CreditApplicationDecision createR1CreditApplicationDecision() {
        return new R1CreditApplicationDecision();
    }

    /**
     * Create an instance of {@link DSPCreditApplication }
     * 
     */
    public DSPCreditApplication createDSPCreditApplication() {
        return new DSPCreditApplication();
    }

    /**
     * Create an instance of {@link CreditCardApplication }
     * 
     */
    public CreditCardApplication createCreditCardApplication() {
        return new CreditCardApplication();
    }

    /**
     * Create an instance of {@link CreditCardDecision }
     * 
     */
    public CreditCardDecision createCreditCardDecision() {
        return new CreditCardDecision();
    }

    /**
     * Create an instance of {@link FinanceSourceFederalDisclosureType }
     * 
     */
    public FinanceSourceFederalDisclosureType createFinanceSourceFederalDisclosureType() {
        return new FinanceSourceFederalDisclosureType();
    }

    /**
     * Create an instance of {@link DealRestructureType }
     * 
     */
    public DealRestructureType createDealRestructureType() {
        return new DealRestructureType();
    }

    /**
     * Create an instance of {@link RouteOneSupplement }
     * 
     */
    public RouteOneSupplement createRouteOneSupplement() {
        return new RouteOneSupplement();
    }

    /**
     * Create an instance of {@link PreApprovalRequest }
     * 
     */
    public PreApprovalRequest createPreApprovalRequest() {
        return new PreApprovalRequest();
    }

    /**
     * Create an instance of {@link CreditApplicationGroupType }
     * 
     */
    public CreditApplicationGroupType createCreditApplicationGroupType() {
        return new CreditApplicationGroupType();
    }

    /**
     * Create an instance of {@link CreditApplicationType }
     * 
     */
    public CreditApplicationType createCreditApplicationType() {
        return new CreditApplicationType();
    }

    /**
     * Create an instance of {@link DocumentType }
     * 
     */
    public DocumentType createDocumentType() {
        return new DocumentType();
    }

    /**
     * Create an instance of {@link DocumentsType }
     * 
     */
    public DocumentsType createDocumentsType() {
        return new DocumentsType();
    }

    /**
     * Create an instance of {@link PayloadsType }
     * 
     */
    public PayloadsType createPayloadsType() {
        return new PayloadsType();
    }

    /**
     * Create an instance of {@link PayloadType }
     * 
     */
    public PayloadType createPayloadType() {
        return new PayloadType();
    }

    /**
     * Create an instance of {@link DocumentSignaturesType }
     * 
     */
    public DocumentSignaturesType createDocumentSignaturesType() {
        return new DocumentSignaturesType();
    }

    /**
     * Create an instance of {@link Attachments }
     * 
     */
    public Attachments createAttachments() {
        return new Attachments();
    }

    /**
     * Create an instance of {@link AutoForwardInfoType }
     * 
     */
    public AutoForwardInfoType createAutoForwardInfoType() {
        return new AutoForwardInfoType();
    }

    /**
     * Create an instance of {@link AutoForwardEndpointListType.Endpoint.Endpointparam }
     * 
     */
    public AutoForwardEndpointListType.Endpoint.Endpointparam createAutoForwardEndpointListTypeEndpointEndpointparam() {
        return new AutoForwardEndpointListType.Endpoint.Endpointparam();
    }

    /**
     * Create an instance of {@link EndpointListType.Endpoint.Endpointparam }
     * 
     */
    public EndpointListType.Endpoint.Endpointparam createEndpointListTypeEndpointEndpointparam() {
        return new EndpointListType.Endpoint.Endpointparam();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOne }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOne }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOne")
    public JAXBElement<RouteOne> createRouteOne(RouteOne value) {
        return new JAXBElement<RouteOne>(_RouteOne_QNAME, RouteOne.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FSCreditApplicationDecisionInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FSCreditApplicationDecisionInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FSCreditApplicationDecisionInfo")
    public JAXBElement<FSCreditApplicationDecisionInfo> createFSCreditApplicationDecisionInfo(FSCreditApplicationDecisionInfo value) {
        return new JAXBElement<FSCreditApplicationDecisionInfo>(_FSCreditApplicationDecisionInfo_QNAME, FSCreditApplicationDecisionInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOneCreditApplicationInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOneCreditApplicationInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOneCreditApplicationInfo")
    public JAXBElement<RouteOneCreditApplicationInfo> createRouteOneCreditApplicationInfo(RouteOneCreditApplicationInfo value) {
        return new JAXBElement<RouteOneCreditApplicationInfo>(_RouteOneCreditApplicationInfo_QNAME, RouteOneCreditApplicationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOneCreditDecisionInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOneCreditDecisionInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOneCreditDecisionInfo")
    public JAXBElement<RouteOneCreditDecisionInfo> createRouteOneCreditDecisionInfo(RouteOneCreditDecisionInfo value) {
        return new JAXBElement<RouteOneCreditDecisionInfo>(_RouteOneCreditDecisionInfo_QNAME, RouteOneCreditDecisionInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FSCreditApplicationInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FSCreditApplicationInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FSCreditApplicationInfo")
    public JAXBElement<FSCreditApplicationInfo> createFSCreditApplicationInfo(FSCreditApplicationInfo value) {
        return new JAXBElement<FSCreditApplicationInfo>(_FSCreditApplicationInfo_QNAME, FSCreditApplicationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOneCreditContractInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOneCreditContractInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOneCreditContractInfo")
    public JAXBElement<RouteOneCreditContractInfo> createRouteOneCreditContractInfo(RouteOneCreditContractInfo value) {
        return new JAXBElement<RouteOneCreditContractInfo>(_RouteOneCreditContractInfo_QNAME, RouteOneCreditContractInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOneSupplementInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOneSupplementInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOneSupplementInfo")
    public JAXBElement<RouteOneSupplementInfo> createRouteOneSupplementInfo(RouteOneSupplementInfo value) {
        return new JAXBElement<RouteOneSupplementInfo>(_RouteOneSupplementInfo_QNAME, RouteOneSupplementInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOneCreditCardApplicationInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOneCreditCardApplicationInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOneCreditCardApplicationInfo")
    public JAXBElement<RouteOneCreditCardApplicationInfo> createRouteOneCreditCardApplicationInfo(RouteOneCreditCardApplicationInfo value) {
        return new JAXBElement<RouteOneCreditCardApplicationInfo>(_RouteOneCreditCardApplicationInfo_QNAME, RouteOneCreditCardApplicationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteOneCreditCardDecisionInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteOneCreditCardDecisionInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "RouteOneCreditCardDecisionInfo")
    public JAXBElement<RouteOneCreditCardDecisionInfo> createRouteOneCreditCardDecisionInfo(RouteOneCreditCardDecisionInfo value) {
        return new JAXBElement<RouteOneCreditCardDecisionInfo>(_RouteOneCreditCardDecisionInfo_QNAME, RouteOneCreditCardDecisionInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "CoBuyerVersionNumber")
    public JAXBElement<String> createCoBuyerVersionNumber(String value) {
        return new JAXBElement<String>(_CoBuyerVersionNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "SequenceNo")
    public JAXBElement<Long> createSequenceNo(Long value) {
        return new JAXBElement<Long>(_SequenceNo_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "R1FSID")
    public JAXBElement<String> createR1FSID(String value) {
        return new JAXBElement<String>(_R1FSID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "DSPDealerID")
    public JAXBElement<String> createDSPDealerID(String value) {
        return new JAXBElement<String>(_DSPDealerID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FSDealerID")
    public JAXBElement<String> createFSDealerID(String value) {
        return new JAXBElement<String>(_FSDealerID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "R1DealerID")
    public JAXBElement<String> createR1DealerID(String value) {
        return new JAXBElement<String>(_R1DealerID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FSInfo1")
    public JAXBElement<String> createFSInfo1(String value) {
        return new JAXBElement<String>(_FSInfo1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FSInfo2")
    public JAXBElement<String> createFSInfo2(String value) {
        return new JAXBElement<String>(_FSInfo2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "Descriptor")
    public JAXBElement<String> createDescriptor(String value) {
        return new JAXBElement<String>(_Descriptor_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "Ref2SequenceNo")
    public JAXBElement<Long> createRef2SequenceNo(Long value) {
        return new JAXBElement<Long>(_Ref2SequenceNo_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "CaptiveUserID")
    public JAXBElement<String> createCaptiveUserID(String value) {
        return new JAXBElement<String>(_CaptiveUserID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "OriginalSourceID")
    public JAXBElement<String> createOriginalSourceID(String value) {
        return new JAXBElement<String>(_OriginalSourceID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "CopyReason")
    public JAXBElement<BigInteger> createCopyReason(BigInteger value) {
        return new JAXBElement<BigInteger>(_CopyReason_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "DealerQualifier")
    public JAXBElement<String> createDealerQualifier(String value) {
        return new JAXBElement<String>(_DealerQualifier_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditAppTextMessageInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreditAppTextMessageInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "CreditAppTextMessageInfo")
    public JAXBElement<CreditAppTextMessageInfo> createCreditAppTextMessageInfo(CreditAppTextMessageInfo value) {
        return new JAXBElement<CreditAppTextMessageInfo>(_CreditAppTextMessageInfo_QNAME, CreditAppTextMessageInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CAStipulationDocumentsInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CAStipulationDocumentsInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "CAStipulationDocumentsInfo")
    public JAXBElement<CAStipulationDocumentsInfo> createCAStipulationDocumentsInfo(CAStipulationDocumentsInfo value) {
        return new JAXBElement<CAStipulationDocumentsInfo>(_CAStipulationDocumentsInfo_QNAME, CAStipulationDocumentsInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link R1CreditApplicationDecisionInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link R1CreditApplicationDecisionInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "R1CreditApplicationDecisionInfo")
    public JAXBElement<R1CreditApplicationDecisionInfo> createR1CreditApplicationDecisionInfo(R1CreditApplicationDecisionInfo value) {
        return new JAXBElement<R1CreditApplicationDecisionInfo>(_R1CreditApplicationDecisionInfo_QNAME, R1CreditApplicationDecisionInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DSPCreditApplicationInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DSPCreditApplicationInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "DSPCreditApplicationInfo")
    public JAXBElement<DSPCreditApplicationInfo> createDSPCreditApplicationInfo(DSPCreditApplicationInfo value) {
        return new JAXBElement<DSPCreditApplicationInfo>(_DSPCreditApplicationInfo_QNAME, DSPCreditApplicationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "DSPUserID")
    public JAXBElement<String> createDSPUserID(String value) {
        return new JAXBElement<String>(_DSPUserID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Reserve }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Reserve }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "Reserve")
    public JAXBElement<Reserve> createReserve(Reserve value) {
        return new JAXBElement<Reserve>(_Reserve_QNAME, Reserve.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LTV }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LTV }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "LTV")
    public JAXBElement<LTV> createLTV(LTV value) {
        return new JAXBElement<LTV>(_LTV_QNAME, LTV.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LTVItem }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LTVItem }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "LTVItem")
    public JAXBElement<LTVItem> createLTVItem(LTVItem value) {
        return new JAXBElement<LTVItem>(_LTVItem_QNAME, LTVItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LTVColumn }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LTVColumn }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "LTVColumn")
    public JAXBElement<LTVColumn> createLTVColumn(LTVColumn value) {
        return new JAXBElement<LTVColumn>(_LTVColumn_QNAME, LTVColumn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "DealUpdateAllowed")
    public JAXBElement<String> createDealUpdateAllowed(String value) {
        return new JAXBElement<String>(_DealUpdateAllowed_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "LenderApplicationNumber")
    public JAXBElement<String> createLenderApplicationNumber(String value) {
        return new JAXBElement<String>(_LenderApplicationNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "AlternateConversationID")
    public JAXBElement<String> createAlternateConversationID(String value) {
        return new JAXBElement<String>(_AlternateConversationID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "LeadType")
    public JAXBElement<String> createLeadType(String value) {
        return new JAXBElement<String>(_LeadType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "TradeInVehicleValueRefID")
    public JAXBElement<String> createTradeInVehicleValueRefID(String value) {
        return new JAXBElement<String>(_TradeInVehicleValueRefID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaultInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FaultInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FaultInfo")
    public JAXBElement<FaultInfo> createFaultInfo(FaultInfo value) {
        return new JAXBElement<FaultInfo>(_FaultInfo_QNAME, FaultInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ORSInfoType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ORSInfoType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "ORSInfo")
    public JAXBElement<ORSInfoType> createORSInfo(ORSInfoType value) {
        return new JAXBElement<ORSInfoType>(_ORSInfo_QNAME, ORSInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuditInfoType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AuditInfoType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "AuditInfo")
    public JAXBElement<AuditInfoType> createAuditInfo(AuditInfoType value) {
        return new JAXBElement<AuditInfoType>(_AuditInfo_QNAME, AuditInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FinanceSourceFederalDisclosuresType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FinanceSourceFederalDisclosuresType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "FinanceSourceFederalDisclosures")
    public JAXBElement<FinanceSourceFederalDisclosuresType> createFinanceSourceFederalDisclosures(FinanceSourceFederalDisclosuresType value) {
        return new JAXBElement<FinanceSourceFederalDisclosuresType>(_FinanceSourceFederalDisclosures_QNAME, FinanceSourceFederalDisclosuresType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PayoffQuoteInquiryType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PayoffQuoteInquiryType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "PayoffQuoteInquiry")
    public JAXBElement<PayoffQuoteInquiryType> createPayoffQuoteInquiry(PayoffQuoteInquiryType value) {
        return new JAXBElement<PayoffQuoteInquiryType>(_PayoffQuoteInquiry_QNAME, PayoffQuoteInquiryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentSignatureType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DocumentSignatureType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "DocumentSignature")
    public JAXBElement<DocumentSignatureType> createDocumentSignature(DocumentSignatureType value) {
        return new JAXBElement<DocumentSignatureType>(_DocumentSignature_QNAME, DocumentSignatureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", name = "OriginatingSource")
    public JAXBElement<String> createOriginatingSource(String value) {
        return new JAXBElement<String>(_OriginatingSource_QNAME, String.class, null, value);
    }

}
