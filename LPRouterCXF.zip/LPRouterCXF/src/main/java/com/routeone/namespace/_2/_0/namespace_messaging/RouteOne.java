
package com.routeone.namespace._2._0.namespace_messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RouteOne complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RouteOne"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SenderID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="TargetID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ConversationID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="SentTimeStamp" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MessageType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}SequenceNo"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}Ref2SequenceNo" minOccurs="0"/&gt;
 *         &lt;element name="MessageIdentifier" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}MessageIdentifier"/&gt;
 *         &lt;element name="AdditionalInfo" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AdditionalInfo" minOccurs="0"/&gt;
 *         &lt;element name="Attachments" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}Attachments" minOccurs="0"/&gt;
 *         &lt;element name="R1DealJacketID" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}UUID" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="version" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RouteOne", propOrder = {
    "senderID",
    "targetID",
    "conversationID",
    "sentTimeStamp",
    "messageType",
    "sequenceNo",
    "ref2SequenceNo",
    "messageIdentifier",
    "additionalInfo",
    "attachments",
    "r1DealJacketID"
})
public class RouteOne {

    @XmlElement(name = "SenderID", required = true)
    protected String senderID;
    @XmlElement(name = "TargetID", required = true)
    protected String targetID;
    @XmlElement(name = "ConversationID", required = true)
    protected String conversationID;
    @XmlElement(name = "SentTimeStamp", required = true)
    protected String sentTimeStamp;
    @XmlElement(name = "MessageType", required = true)
    protected String messageType;
    @XmlElement(name = "SequenceNo")
    protected long sequenceNo;
    @XmlElement(name = "Ref2SequenceNo")
    protected Long ref2SequenceNo;
    @XmlElement(name = "MessageIdentifier", required = true)
    protected MessageIdentifier messageIdentifier;
    @XmlElement(name = "AdditionalInfo")
    protected AdditionalInfo additionalInfo;
    @XmlElement(name = "Attachments")
    protected Attachments attachments;
    @XmlElement(name = "R1DealJacketID")
    protected String r1DealJacketID;
    @XmlAttribute(name = "version")
    protected String version;

    /**
     * Gets the value of the senderID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderID() {
        return senderID;
    }

    /**
     * Sets the value of the senderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderID(String value) {
        this.senderID = value;
    }

    /**
     * Gets the value of the targetID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetID() {
        return targetID;
    }

    /**
     * Sets the value of the targetID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetID(String value) {
        this.targetID = value;
    }

    /**
     * Gets the value of the conversationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConversationID() {
        return conversationID;
    }

    /**
     * Sets the value of the conversationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConversationID(String value) {
        this.conversationID = value;
    }

    /**
     * Gets the value of the sentTimeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSentTimeStamp() {
        return sentTimeStamp;
    }

    /**
     * Sets the value of the sentTimeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSentTimeStamp(String value) {
        this.sentTimeStamp = value;
    }

    /**
     * Gets the value of the messageType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * Sets the value of the messageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageType(String value) {
        this.messageType = value;
    }

    /**
     * Gets the value of the sequenceNo property.
     * 
     */
    public long getSequenceNo() {
        return sequenceNo;
    }

    /**
     * Sets the value of the sequenceNo property.
     * 
     */
    public void setSequenceNo(long value) {
        this.sequenceNo = value;
    }

    /**
     * Gets the value of the ref2SequenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRef2SequenceNo() {
        return ref2SequenceNo;
    }

    /**
     * Sets the value of the ref2SequenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRef2SequenceNo(Long value) {
        this.ref2SequenceNo = value;
    }

    /**
     * Gets the value of the messageIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link MessageIdentifier }
     *     
     */
    public MessageIdentifier getMessageIdentifier() {
        return messageIdentifier;
    }

    /**
     * Sets the value of the messageIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageIdentifier }
     *     
     */
    public void setMessageIdentifier(MessageIdentifier value) {
        this.messageIdentifier = value;
    }

    /**
     * Gets the value of the additionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfo }
     *     
     */
    public AdditionalInfo getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Sets the value of the additionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfo }
     *     
     */
    public void setAdditionalInfo(AdditionalInfo value) {
        this.additionalInfo = value;
    }

    /**
     * Gets the value of the attachments property.
     * 
     * @return
     *     possible object is
     *     {@link Attachments }
     *     
     */
    public Attachments getAttachments() {
        return attachments;
    }

    /**
     * Sets the value of the attachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Attachments }
     *     
     */
    public void setAttachments(Attachments value) {
        this.attachments = value;
    }

    /**
     * Gets the value of the r1DealJacketID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getR1DealJacketID() {
        return r1DealJacketID;
    }

    /**
     * Sets the value of the r1DealJacketID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setR1DealJacketID(String value) {
        this.r1DealJacketID = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

}
