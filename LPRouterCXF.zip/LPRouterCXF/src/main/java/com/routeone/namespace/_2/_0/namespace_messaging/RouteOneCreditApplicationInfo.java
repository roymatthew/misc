
package com.routeone.namespace._2._0.namespace_messaging;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The additional info element type for RouteOne
 * 				originated Credit Applications
 * 
 * <p>Java class for RouteOneCreditApplicationInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RouteOneCreditApplicationInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}R1DealerID"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CaptiveUserID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSInfo1" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}FSInfo2" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}Descriptor" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}OriginalSourceID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}CopyReason" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}DealerQualifier" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}PartnerSpecificAdditionalInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}LenderApplicationNumber" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AlternateConversationID" minOccurs="0"/&gt;
 *         &lt;element name="AutoForwardInfo" type="{http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#}AutoForwardInfoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RouteOneCreditApplicationInfo", propOrder = {
    "r1DealerID",
    "captiveUserID",
    "fsInfo1",
    "fsInfo2",
    "descriptor",
    "originalSourceID",
    "copyReason",
    "dealerQualifier",
    "partnerSpecificAdditionalInfo",
    "lenderApplicationNumber",
    "alternateConversationID",
    "autoForwardInfo"
})
public class RouteOneCreditApplicationInfo {

    @XmlElement(name = "R1DealerID", required = true)
    protected String r1DealerID;
    @XmlElement(name = "CaptiveUserID")
    protected String captiveUserID;
    @XmlElement(name = "FSInfo1")
    protected String fsInfo1;
    @XmlElement(name = "FSInfo2")
    protected String fsInfo2;
    @XmlElement(name = "Descriptor")
    protected String descriptor;
    @XmlElement(name = "OriginalSourceID")
    protected String originalSourceID;
    @XmlElement(name = "CopyReason")
    protected BigInteger copyReason;
    @XmlElement(name = "DealerQualifier")
    protected String dealerQualifier;
    @XmlElement(name = "PartnerSpecificAdditionalInfo")
    protected List<PartnerSpecificAdditionalInfo> partnerSpecificAdditionalInfo;
    @XmlElement(name = "LenderApplicationNumber")
    protected String lenderApplicationNumber;
    @XmlElement(name = "AlternateConversationID")
    protected String alternateConversationID;
    @XmlElement(name = "AutoForwardInfo")
    protected AutoForwardInfoType autoForwardInfo;

    /**
     * Gets the value of the r1DealerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getR1DealerID() {
        return r1DealerID;
    }

    /**
     * Sets the value of the r1DealerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setR1DealerID(String value) {
        this.r1DealerID = value;
    }

    /**
     * Gets the value of the captiveUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaptiveUserID() {
        return captiveUserID;
    }

    /**
     * Sets the value of the captiveUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaptiveUserID(String value) {
        this.captiveUserID = value;
    }

    /**
     * Gets the value of the fsInfo1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFSInfo1() {
        return fsInfo1;
    }

    /**
     * Sets the value of the fsInfo1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFSInfo1(String value) {
        this.fsInfo1 = value;
    }

    /**
     * Gets the value of the fsInfo2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFSInfo2() {
        return fsInfo2;
    }

    /**
     * Sets the value of the fsInfo2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFSInfo2(String value) {
        this.fsInfo2 = value;
    }

    /**
     * Gets the value of the descriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescriptor() {
        return descriptor;
    }

    /**
     * Sets the value of the descriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescriptor(String value) {
        this.descriptor = value;
    }

    /**
     * Gets the value of the originalSourceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalSourceID() {
        return originalSourceID;
    }

    /**
     * Sets the value of the originalSourceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalSourceID(String value) {
        this.originalSourceID = value;
    }

    /**
     * Gets the value of the copyReason property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCopyReason() {
        return copyReason;
    }

    /**
     * Sets the value of the copyReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCopyReason(BigInteger value) {
        this.copyReason = value;
    }

    /**
     * Gets the value of the dealerQualifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerQualifier() {
        return dealerQualifier;
    }

    /**
     * Sets the value of the dealerQualifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerQualifier(String value) {
        this.dealerQualifier = value;
    }

    /**
     * Gets the value of the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnerSpecificAdditionalInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnerSpecificAdditionalInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerSpecificAdditionalInfo }
     * 
     * 
     */
    public List<PartnerSpecificAdditionalInfo> getPartnerSpecificAdditionalInfo() {
        if (partnerSpecificAdditionalInfo == null) {
            partnerSpecificAdditionalInfo = new ArrayList<PartnerSpecificAdditionalInfo>();
        }
        return this.partnerSpecificAdditionalInfo;
    }

    /**
     * This element contains the application number
     * 						supplied by the lender in a prior credit decision message.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLenderApplicationNumber() {
        return lenderApplicationNumber;
    }

    /**
     * Sets the value of the lenderApplicationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLenderApplicationNumber(String value) {
        this.lenderApplicationNumber = value;
    }

    /**
     * Gets the value of the alternateConversationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternateConversationID() {
        return alternateConversationID;
    }

    /**
     * Sets the value of the alternateConversationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternateConversationID(String value) {
        this.alternateConversationID = value;
    }

    /**
     * Gets the value of the autoForwardInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AutoForwardInfoType }
     *     
     */
    public AutoForwardInfoType getAutoForwardInfo() {
        return autoForwardInfo;
    }

    /**
     * Sets the value of the autoForwardInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AutoForwardInfoType }
     *     
     */
    public void setAutoForwardInfo(AutoForwardInfoType value) {
        this.autoForwardInfo = value;
    }

}
