@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.routeone.com/namespace/2/0/namespace.messaging.CreditApplication#", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.routeone.namespace._2._0.namespace_messaging;
