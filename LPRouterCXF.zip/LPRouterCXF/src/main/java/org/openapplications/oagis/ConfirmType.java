
package org.openapplications.oagis;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfirmType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ConfirmType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *     &lt;enumeration value="Always"/&gt;
 *     &lt;enumeration value="OnChange"/&gt;
 *     &lt;enumeration value="Never"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ConfirmType")
@XmlEnum
public enum ConfirmType {

    @XmlEnumValue("Always")
    ALWAYS("Always"),
    @XmlEnumValue("OnChange")
    ON_CHANGE("OnChange"),
    @XmlEnumValue("Never")
    NEVER("Never");
    private final String value;

    ConfirmType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ConfirmType fromValue(String v) {
        for (ConfirmType c: ConfirmType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
