
package org.openapplications.oagis;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Process complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Process"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;attribute name="confirm" type="{http://www.openapplications.org/oagis}ConfirmType" /&gt;
 *       &lt;attribute name="acknowledge" type="{http://www.openapplications.org/oagis}AcknowledgementType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Process")
public class Process {

    @XmlAttribute(name = "confirm")
    protected ConfirmType confirm;
    @XmlAttribute(name = "acknowledge")
    protected AcknowledgementType acknowledge;

    /**
     * Gets the value of the confirm property.
     * 
     * @return
     *     possible object is
     *     {@link ConfirmType }
     *     
     */
    public ConfirmType getConfirm() {
        return confirm;
    }

    /**
     * Sets the value of the confirm property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConfirmType }
     *     
     */
    public void setConfirm(ConfirmType value) {
        this.confirm = value;
    }

    /**
     * Gets the value of the acknowledge property.
     * 
     * @return
     *     possible object is
     *     {@link AcknowledgementType }
     *     
     */
    public AcknowledgementType getAcknowledge() {
        return acknowledge;
    }

    /**
     * Sets the value of the acknowledge property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcknowledgementType }
     *     
     */
    public void setAcknowledge(AcknowledgementType value) {
        this.acknowledge = value;
    }

}
