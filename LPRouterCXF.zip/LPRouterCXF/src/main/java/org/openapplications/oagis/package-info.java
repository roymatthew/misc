@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.openapplications.org/oagis")
package org.openapplications.oagis;
