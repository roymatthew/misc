
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountantParty complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountantParty"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.starstandards.org/STAR}PartyBase"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AlternatePartyIds" type="{http://www.starstandards.org/STAR}OrganizationalPartyAlternatePartyId" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AccountantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.starstandards.org/STAR}OrganizationAddress" minOccurs="0"/&gt;
 *         &lt;element name="Contact" type="{http://www.starstandards.org/STAR}OrganizationContact" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountantParty", propOrder = {
    "alternatePartyIds",
    "accountantName",
    "address",
    "contact"
})
public class AccountantParty
    extends PartyBase
{

    @XmlElement(name = "AlternatePartyIds")
    protected List<OrganizationalPartyAlternatePartyId> alternatePartyIds;
    @XmlElement(name = "AccountantName")
    protected String accountantName;
    @XmlElement(name = "Address")
    protected OrganizationAddress address;
    @XmlElement(name = "Contact")
    protected OrganizationContact contact;

    /**
     * Gets the value of the alternatePartyIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternatePartyIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternatePartyIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrganizationalPartyAlternatePartyId }
     * 
     * 
     */
    public List<OrganizationalPartyAlternatePartyId> getAlternatePartyIds() {
        if (alternatePartyIds == null) {
            alternatePartyIds = new ArrayList<OrganizationalPartyAlternatePartyId>();
        }
        return this.alternatePartyIds;
    }

    /**
     * Gets the value of the accountantName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountantName() {
        return accountantName;
    }

    /**
     * Sets the value of the accountantName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountantName(String value) {
        this.accountantName = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationAddress }
     *     
     */
    public OrganizationAddress getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationAddress }
     *     
     */
    public void setAddress(OrganizationAddress value) {
        this.address = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationContact }
     *     
     */
    public OrganizationContact getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationContact }
     *     
     */
    public void setContact(OrganizationContact value) {
        this.contact = value;
    }

}
