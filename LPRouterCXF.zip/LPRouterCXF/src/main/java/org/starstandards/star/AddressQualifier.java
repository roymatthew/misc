
package org.starstandards.star;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for addressQualifier.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="addressQualifier"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="HomeAddress"/&gt;
 *     &lt;enumeration value="PreviousAddress"/&gt;
 *     &lt;enumeration value="WorkAddress"/&gt;
 *     &lt;enumeration value="CountryOfCitizenship1"/&gt;
 *     &lt;enumeration value="CountryOfCitizenship2"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "addressQualifier")
@XmlEnum
public enum AddressQualifier {

    @XmlEnumValue("HomeAddress")
    HOME_ADDRESS("HomeAddress"),
    @XmlEnumValue("PreviousAddress")
    PREVIOUS_ADDRESS("PreviousAddress"),
    @XmlEnumValue("WorkAddress")
    WORK_ADDRESS("WorkAddress"),
    @XmlEnumValue("CountryOfCitizenship1")
    COUNTRY_OF_CITIZENSHIP_1("CountryOfCitizenship1"),
    @XmlEnumValue("CountryOfCitizenship2")
    COUNTRY_OF_CITIZENSHIP_2("CountryOfCitizenship2");
    private final String value;

    AddressQualifier(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AddressQualifier fromValue(String v) {
        for (AddressQualifier c: AddressQualifier.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
