
package org.starstandards.star;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ApplicationFinancing complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ApplicationFinancing"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FinanceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BalanceAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FinalAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResidualAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Term" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
 *                 &lt;attribute name="length" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaturityDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FinanceCompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DownPaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PurchasePrice" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApprovedInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="ApprovedAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ExpirationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="RatingIndex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ApplicationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeferredDownPayment" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DealerRebateAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ManufacturerRebateAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NetTradeAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InsuranceTotalExtendedWarrantyAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisabilityPremiumAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CreditLifePremiumAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SecurityDepositAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MiscellaneousNotes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AnnualPercentageRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="MSRPGuidePercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="ServiceContract" type="{http://www.starstandards.org/STAR}ServiceContractBase" minOccurs="0"/&gt;
 *         &lt;element name="Tax" type="{http://www.starstandards.org/STAR}Tax" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CostPerMile" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EstimatedAnnualMileage" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
 *                 &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}uom" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ExcessMilesPerYear" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
 *                 &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}uom" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SpecialPrograms" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Fee" type="{http://www.starstandards.org/STAR}Fee" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TradeIn" type="{http://www.starstandards.org/STAR}TradeInVehicleCredit" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OfferingType" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApprovedEquipmentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LeaseRatePercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="LeaseRateMoneyFactor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PreApprovedProgramName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SalesOrderNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetAmountFinanced" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasePaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TotalReductionsAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NetCapitalizedCostAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationFinancing", propOrder = {
    "financeType",
    "paymentAmount",
    "balanceAmount",
    "finalAmount",
    "residualAmount",
    "term",
    "maturityDate",
    "financeCompanyName",
    "downPaymentAmount",
    "purchasePrice",
    "approvedInd",
    "approvedAmount",
    "expirationDate",
    "ratingIndex",
    "applicationType",
    "deferredDownPayment",
    "dealerRebateAmount",
    "manufacturerRebateAmount",
    "netTradeAmount",
    "insuranceTotalExtendedWarrantyAmount",
    "disabilityPremiumAmount",
    "creditLifePremiumAmount",
    "securityDepositAmount",
    "miscellaneousNotes",
    "annualPercentageRate",
    "msrpGuidePercentage",
    "serviceContract",
    "tax",
    "costPerMile",
    "estimatedAnnualMileage",
    "excessMilesPerYear",
    "specialPrograms",
    "fee",
    "tradeIn",
    "offeringType",
    "approvedEquipmentAmount",
    "leaseRatePercentage",
    "leaseRateMoneyFactor",
    "preApprovedProgramName",
    "salesOrderNumber",
    "netAmountFinanced",
    "basePaymentAmount",
    "totalReductionsAmount",
    "netCapitalizedCostAmount"
})
public class ApplicationFinancing {

    @XmlElement(name = "FinanceType")
    protected String financeType;
    @XmlElement(name = "PaymentAmount")
    protected ApplicationFinancing.PaymentAmount paymentAmount;
    @XmlElement(name = "BalanceAmount")
    protected ApplicationFinancing.BalanceAmount balanceAmount;
    @XmlElement(name = "FinalAmount")
    protected ApplicationFinancing.FinalAmount finalAmount;
    @XmlElement(name = "ResidualAmount")
    protected ApplicationFinancing.ResidualAmount residualAmount;
    @XmlElement(name = "Term")
    protected ApplicationFinancing.Term term;
    @XmlElement(name = "MaturityDate")
    protected String maturityDate;
    @XmlElement(name = "FinanceCompanyName")
    protected String financeCompanyName;
    @XmlElement(name = "DownPaymentAmount")
    protected ApplicationFinancing.DownPaymentAmount downPaymentAmount;
    @XmlElement(name = "PurchasePrice")
    protected ApplicationFinancing.PurchasePrice purchasePrice;
    @XmlElement(name = "ApprovedInd")
    protected String approvedInd;
    @XmlElement(name = "ApprovedAmount")
    protected ApplicationFinancing.ApprovedAmount approvedAmount;
    @XmlElement(name = "ExpirationDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar expirationDate;
    @XmlElement(name = "RatingIndex")
    protected String ratingIndex;
    @XmlElement(name = "ApplicationType")
    protected String applicationType;
    @XmlElement(name = "DeferredDownPayment")
    protected ApplicationFinancing.DeferredDownPayment deferredDownPayment;
    @XmlElement(name = "DealerRebateAmount")
    protected ApplicationFinancing.DealerRebateAmount dealerRebateAmount;
    @XmlElement(name = "ManufacturerRebateAmount")
    protected ApplicationFinancing.ManufacturerRebateAmount manufacturerRebateAmount;
    @XmlElement(name = "NetTradeAmount")
    protected ApplicationFinancing.NetTradeAmount netTradeAmount;
    @XmlElement(name = "InsuranceTotalExtendedWarrantyAmount")
    protected ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount insuranceTotalExtendedWarrantyAmount;
    @XmlElement(name = "DisabilityPremiumAmount")
    protected ApplicationFinancing.DisabilityPremiumAmount disabilityPremiumAmount;
    @XmlElement(name = "CreditLifePremiumAmount")
    protected ApplicationFinancing.CreditLifePremiumAmount creditLifePremiumAmount;
    @XmlElement(name = "SecurityDepositAmount")
    protected ApplicationFinancing.SecurityDepositAmount securityDepositAmount;
    @XmlElement(name = "MiscellaneousNotes")
    protected String miscellaneousNotes;
    @XmlElement(name = "AnnualPercentageRate")
    protected BigDecimal annualPercentageRate;
    @XmlElement(name = "MSRPGuidePercentage")
    protected BigDecimal msrpGuidePercentage;
    @XmlElement(name = "ServiceContract")
    protected ServiceContractBase serviceContract;
    @XmlElement(name = "Tax")
    protected List<Tax> tax;
    @XmlElement(name = "CostPerMile")
    protected ApplicationFinancing.CostPerMile costPerMile;
    @XmlElement(name = "EstimatedAnnualMileage")
    protected ApplicationFinancing.EstimatedAnnualMileage estimatedAnnualMileage;
    @XmlElement(name = "ExcessMilesPerYear")
    protected ApplicationFinancing.ExcessMilesPerYear excessMilesPerYear;
    @XmlElement(name = "SpecialPrograms")
    protected List<String> specialPrograms;
    @XmlElement(name = "Fee")
    protected List<Fee> fee;
    @XmlElement(name = "TradeIn")
    protected List<TradeInVehicleCredit> tradeIn;
    @XmlElement(name = "OfferingType")
    protected ApplicationFinancing.OfferingType offeringType;
    @XmlElement(name = "ApprovedEquipmentAmount")
    protected ApplicationFinancing.ApprovedEquipmentAmount approvedEquipmentAmount;
    @XmlElement(name = "LeaseRatePercentage")
    protected BigDecimal leaseRatePercentage;
    @XmlElement(name = "LeaseRateMoneyFactor")
    protected String leaseRateMoneyFactor;
    @XmlElement(name = "PreApprovedProgramName")
    protected String preApprovedProgramName;
    @XmlElement(name = "SalesOrderNumber")
    protected String salesOrderNumber;
    @XmlElement(name = "NetAmountFinanced")
    protected ApplicationFinancing.NetAmountFinanced netAmountFinanced;
    @XmlElement(name = "BasePaymentAmount")
    protected ApplicationFinancing.BasePaymentAmount basePaymentAmount;
    @XmlElement(name = "TotalReductionsAmount")
    protected ApplicationFinancing.TotalReductionsAmount totalReductionsAmount;
    @XmlElement(name = "NetCapitalizedCostAmount")
    protected ApplicationFinancing.NetCapitalizedCostAmount netCapitalizedCostAmount;

    /**
     * Gets the value of the financeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinanceType() {
        return financeType;
    }

    /**
     * Sets the value of the financeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinanceType(String value) {
        this.financeType = value;
    }

    /**
     * Gets the value of the paymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.PaymentAmount }
     *     
     */
    public ApplicationFinancing.PaymentAmount getPaymentAmount() {
        return paymentAmount;
    }

    /**
     * Sets the value of the paymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.PaymentAmount }
     *     
     */
    public void setPaymentAmount(ApplicationFinancing.PaymentAmount value) {
        this.paymentAmount = value;
    }

    /**
     * Gets the value of the balanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.BalanceAmount }
     *     
     */
    public ApplicationFinancing.BalanceAmount getBalanceAmount() {
        return balanceAmount;
    }

    /**
     * Sets the value of the balanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.BalanceAmount }
     *     
     */
    public void setBalanceAmount(ApplicationFinancing.BalanceAmount value) {
        this.balanceAmount = value;
    }

    /**
     * Gets the value of the finalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.FinalAmount }
     *     
     */
    public ApplicationFinancing.FinalAmount getFinalAmount() {
        return finalAmount;
    }

    /**
     * Sets the value of the finalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.FinalAmount }
     *     
     */
    public void setFinalAmount(ApplicationFinancing.FinalAmount value) {
        this.finalAmount = value;
    }

    /**
     * Gets the value of the residualAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.ResidualAmount }
     *     
     */
    public ApplicationFinancing.ResidualAmount getResidualAmount() {
        return residualAmount;
    }

    /**
     * Sets the value of the residualAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.ResidualAmount }
     *     
     */
    public void setResidualAmount(ApplicationFinancing.ResidualAmount value) {
        this.residualAmount = value;
    }

    /**
     * Gets the value of the term property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.Term }
     *     
     */
    public ApplicationFinancing.Term getTerm() {
        return term;
    }

    /**
     * Sets the value of the term property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.Term }
     *     
     */
    public void setTerm(ApplicationFinancing.Term value) {
        this.term = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaturityDate(String value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the financeCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinanceCompanyName() {
        return financeCompanyName;
    }

    /**
     * Sets the value of the financeCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinanceCompanyName(String value) {
        this.financeCompanyName = value;
    }

    /**
     * Gets the value of the downPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.DownPaymentAmount }
     *     
     */
    public ApplicationFinancing.DownPaymentAmount getDownPaymentAmount() {
        return downPaymentAmount;
    }

    /**
     * Sets the value of the downPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.DownPaymentAmount }
     *     
     */
    public void setDownPaymentAmount(ApplicationFinancing.DownPaymentAmount value) {
        this.downPaymentAmount = value;
    }

    /**
     * Gets the value of the purchasePrice property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.PurchasePrice }
     *     
     */
    public ApplicationFinancing.PurchasePrice getPurchasePrice() {
        return purchasePrice;
    }

    /**
     * Sets the value of the purchasePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.PurchasePrice }
     *     
     */
    public void setPurchasePrice(ApplicationFinancing.PurchasePrice value) {
        this.purchasePrice = value;
    }

    /**
     * Gets the value of the approvedInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovedInd() {
        return approvedInd;
    }

    /**
     * Sets the value of the approvedInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovedInd(String value) {
        this.approvedInd = value;
    }

    /**
     * Gets the value of the approvedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.ApprovedAmount }
     *     
     */
    public ApplicationFinancing.ApprovedAmount getApprovedAmount() {
        return approvedAmount;
    }

    /**
     * Sets the value of the approvedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.ApprovedAmount }
     *     
     */
    public void setApprovedAmount(ApplicationFinancing.ApprovedAmount value) {
        this.approvedAmount = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpirationDate(XMLGregorianCalendar value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the ratingIndex property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRatingIndex() {
        return ratingIndex;
    }

    /**
     * Sets the value of the ratingIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRatingIndex(String value) {
        this.ratingIndex = value;
    }

    /**
     * Gets the value of the applicationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationType() {
        return applicationType;
    }

    /**
     * Sets the value of the applicationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationType(String value) {
        this.applicationType = value;
    }

    /**
     * Gets the value of the deferredDownPayment property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.DeferredDownPayment }
     *     
     */
    public ApplicationFinancing.DeferredDownPayment getDeferredDownPayment() {
        return deferredDownPayment;
    }

    /**
     * Sets the value of the deferredDownPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.DeferredDownPayment }
     *     
     */
    public void setDeferredDownPayment(ApplicationFinancing.DeferredDownPayment value) {
        this.deferredDownPayment = value;
    }

    /**
     * Gets the value of the dealerRebateAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.DealerRebateAmount }
     *     
     */
    public ApplicationFinancing.DealerRebateAmount getDealerRebateAmount() {
        return dealerRebateAmount;
    }

    /**
     * Sets the value of the dealerRebateAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.DealerRebateAmount }
     *     
     */
    public void setDealerRebateAmount(ApplicationFinancing.DealerRebateAmount value) {
        this.dealerRebateAmount = value;
    }

    /**
     * Gets the value of the manufacturerRebateAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.ManufacturerRebateAmount }
     *     
     */
    public ApplicationFinancing.ManufacturerRebateAmount getManufacturerRebateAmount() {
        return manufacturerRebateAmount;
    }

    /**
     * Sets the value of the manufacturerRebateAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.ManufacturerRebateAmount }
     *     
     */
    public void setManufacturerRebateAmount(ApplicationFinancing.ManufacturerRebateAmount value) {
        this.manufacturerRebateAmount = value;
    }

    /**
     * Gets the value of the netTradeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.NetTradeAmount }
     *     
     */
    public ApplicationFinancing.NetTradeAmount getNetTradeAmount() {
        return netTradeAmount;
    }

    /**
     * Sets the value of the netTradeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.NetTradeAmount }
     *     
     */
    public void setNetTradeAmount(ApplicationFinancing.NetTradeAmount value) {
        this.netTradeAmount = value;
    }

    /**
     * Gets the value of the insuranceTotalExtendedWarrantyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount }
     *     
     */
    public ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount getInsuranceTotalExtendedWarrantyAmount() {
        return insuranceTotalExtendedWarrantyAmount;
    }

    /**
     * Sets the value of the insuranceTotalExtendedWarrantyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount }
     *     
     */
    public void setInsuranceTotalExtendedWarrantyAmount(ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount value) {
        this.insuranceTotalExtendedWarrantyAmount = value;
    }

    /**
     * Gets the value of the disabilityPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.DisabilityPremiumAmount }
     *     
     */
    public ApplicationFinancing.DisabilityPremiumAmount getDisabilityPremiumAmount() {
        return disabilityPremiumAmount;
    }

    /**
     * Sets the value of the disabilityPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.DisabilityPremiumAmount }
     *     
     */
    public void setDisabilityPremiumAmount(ApplicationFinancing.DisabilityPremiumAmount value) {
        this.disabilityPremiumAmount = value;
    }

    /**
     * Gets the value of the creditLifePremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.CreditLifePremiumAmount }
     *     
     */
    public ApplicationFinancing.CreditLifePremiumAmount getCreditLifePremiumAmount() {
        return creditLifePremiumAmount;
    }

    /**
     * Sets the value of the creditLifePremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.CreditLifePremiumAmount }
     *     
     */
    public void setCreditLifePremiumAmount(ApplicationFinancing.CreditLifePremiumAmount value) {
        this.creditLifePremiumAmount = value;
    }

    /**
     * Gets the value of the securityDepositAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.SecurityDepositAmount }
     *     
     */
    public ApplicationFinancing.SecurityDepositAmount getSecurityDepositAmount() {
        return securityDepositAmount;
    }

    /**
     * Sets the value of the securityDepositAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.SecurityDepositAmount }
     *     
     */
    public void setSecurityDepositAmount(ApplicationFinancing.SecurityDepositAmount value) {
        this.securityDepositAmount = value;
    }

    /**
     * Gets the value of the miscellaneousNotes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiscellaneousNotes() {
        return miscellaneousNotes;
    }

    /**
     * Sets the value of the miscellaneousNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiscellaneousNotes(String value) {
        this.miscellaneousNotes = value;
    }

    /**
     * Gets the value of the annualPercentageRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAnnualPercentageRate() {
        return annualPercentageRate;
    }

    /**
     * Sets the value of the annualPercentageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAnnualPercentageRate(BigDecimal value) {
        this.annualPercentageRate = value;
    }

    /**
     * Gets the value of the msrpGuidePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMSRPGuidePercentage() {
        return msrpGuidePercentage;
    }

    /**
     * Sets the value of the msrpGuidePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMSRPGuidePercentage(BigDecimal value) {
        this.msrpGuidePercentage = value;
    }

    /**
     * Gets the value of the serviceContract property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceContractBase }
     *     
     */
    public ServiceContractBase getServiceContract() {
        return serviceContract;
    }

    /**
     * Sets the value of the serviceContract property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceContractBase }
     *     
     */
    public void setServiceContract(ServiceContractBase value) {
        this.serviceContract = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the costPerMile property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.CostPerMile }
     *     
     */
    public ApplicationFinancing.CostPerMile getCostPerMile() {
        return costPerMile;
    }

    /**
     * Sets the value of the costPerMile property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.CostPerMile }
     *     
     */
    public void setCostPerMile(ApplicationFinancing.CostPerMile value) {
        this.costPerMile = value;
    }

    /**
     * Gets the value of the estimatedAnnualMileage property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.EstimatedAnnualMileage }
     *     
     */
    public ApplicationFinancing.EstimatedAnnualMileage getEstimatedAnnualMileage() {
        return estimatedAnnualMileage;
    }

    /**
     * Sets the value of the estimatedAnnualMileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.EstimatedAnnualMileage }
     *     
     */
    public void setEstimatedAnnualMileage(ApplicationFinancing.EstimatedAnnualMileage value) {
        this.estimatedAnnualMileage = value;
    }

    /**
     * Gets the value of the excessMilesPerYear property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.ExcessMilesPerYear }
     *     
     */
    public ApplicationFinancing.ExcessMilesPerYear getExcessMilesPerYear() {
        return excessMilesPerYear;
    }

    /**
     * Sets the value of the excessMilesPerYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.ExcessMilesPerYear }
     *     
     */
    public void setExcessMilesPerYear(ApplicationFinancing.ExcessMilesPerYear value) {
        this.excessMilesPerYear = value;
    }

    /**
     * Gets the value of the specialPrograms property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specialPrograms property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecialPrograms().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getSpecialPrograms() {
        if (specialPrograms == null) {
            specialPrograms = new ArrayList<String>();
        }
        return this.specialPrograms;
    }

    /**
     * Gets the value of the fee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Fee }
     * 
     * 
     */
    public List<Fee> getFee() {
        if (fee == null) {
            fee = new ArrayList<Fee>();
        }
        return this.fee;
    }

    /**
     * Gets the value of the tradeIn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tradeIn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTradeIn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TradeInVehicleCredit }
     * 
     * 
     */
    public List<TradeInVehicleCredit> getTradeIn() {
        if (tradeIn == null) {
            tradeIn = new ArrayList<TradeInVehicleCredit>();
        }
        return this.tradeIn;
    }

    /**
     * Gets the value of the offeringType property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.OfferingType }
     *     
     */
    public ApplicationFinancing.OfferingType getOfferingType() {
        return offeringType;
    }

    /**
     * Sets the value of the offeringType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.OfferingType }
     *     
     */
    public void setOfferingType(ApplicationFinancing.OfferingType value) {
        this.offeringType = value;
    }

    /**
     * Gets the value of the approvedEquipmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.ApprovedEquipmentAmount }
     *     
     */
    public ApplicationFinancing.ApprovedEquipmentAmount getApprovedEquipmentAmount() {
        return approvedEquipmentAmount;
    }

    /**
     * Sets the value of the approvedEquipmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.ApprovedEquipmentAmount }
     *     
     */
    public void setApprovedEquipmentAmount(ApplicationFinancing.ApprovedEquipmentAmount value) {
        this.approvedEquipmentAmount = value;
    }

    /**
     * Gets the value of the leaseRatePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLeaseRatePercentage() {
        return leaseRatePercentage;
    }

    /**
     * Sets the value of the leaseRatePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLeaseRatePercentage(BigDecimal value) {
        this.leaseRatePercentage = value;
    }

    /**
     * Gets the value of the leaseRateMoneyFactor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeaseRateMoneyFactor() {
        return leaseRateMoneyFactor;
    }

    /**
     * Sets the value of the leaseRateMoneyFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeaseRateMoneyFactor(String value) {
        this.leaseRateMoneyFactor = value;
    }

    /**
     * Gets the value of the preApprovedProgramName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreApprovedProgramName() {
        return preApprovedProgramName;
    }

    /**
     * Sets the value of the preApprovedProgramName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreApprovedProgramName(String value) {
        this.preApprovedProgramName = value;
    }

    /**
     * Gets the value of the salesOrderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesOrderNumber() {
        return salesOrderNumber;
    }

    /**
     * Sets the value of the salesOrderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesOrderNumber(String value) {
        this.salesOrderNumber = value;
    }

    /**
     * Gets the value of the netAmountFinanced property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.NetAmountFinanced }
     *     
     */
    public ApplicationFinancing.NetAmountFinanced getNetAmountFinanced() {
        return netAmountFinanced;
    }

    /**
     * Sets the value of the netAmountFinanced property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.NetAmountFinanced }
     *     
     */
    public void setNetAmountFinanced(ApplicationFinancing.NetAmountFinanced value) {
        this.netAmountFinanced = value;
    }

    /**
     * Gets the value of the basePaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.BasePaymentAmount }
     *     
     */
    public ApplicationFinancing.BasePaymentAmount getBasePaymentAmount() {
        return basePaymentAmount;
    }

    /**
     * Sets the value of the basePaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.BasePaymentAmount }
     *     
     */
    public void setBasePaymentAmount(ApplicationFinancing.BasePaymentAmount value) {
        this.basePaymentAmount = value;
    }

    /**
     * Gets the value of the totalReductionsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.TotalReductionsAmount }
     *     
     */
    public ApplicationFinancing.TotalReductionsAmount getTotalReductionsAmount() {
        return totalReductionsAmount;
    }

    /**
     * Sets the value of the totalReductionsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.TotalReductionsAmount }
     *     
     */
    public void setTotalReductionsAmount(ApplicationFinancing.TotalReductionsAmount value) {
        this.totalReductionsAmount = value;
    }

    /**
     * Gets the value of the netCapitalizedCostAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing.NetCapitalizedCostAmount }
     *     
     */
    public ApplicationFinancing.NetCapitalizedCostAmount getNetCapitalizedCostAmount() {
        return netCapitalizedCostAmount;
    }

    /**
     * Sets the value of the netCapitalizedCostAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing.NetCapitalizedCostAmount }
     *     
     */
    public void setNetCapitalizedCostAmount(ApplicationFinancing.NetCapitalizedCostAmount value) {
        this.netCapitalizedCostAmount = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ApprovedAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ApprovedEquipmentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency")
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BalanceAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BasePaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CostPerMile {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency")
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CreditLifePremiumAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DealerRebateAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DeferredDownPayment {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DisabilityPremiumAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DownPaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
     *       &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}uom" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class EstimatedAnnualMileage {

        @XmlValue
        protected BigInteger value;
        @XmlAttribute(name = "uom")
        protected Uom uom;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setValue(BigInteger value) {
            this.value = value;
        }

        /**
         * Gets the value of the uom property.
         * 
         * @return
         *     possible object is
         *     {@link Uom }
         *     
         */
        public Uom getUom() {
            return uom;
        }

        /**
         * Sets the value of the uom property.
         * 
         * @param value
         *     allowed object is
         *     {@link Uom }
         *     
         */
        public void setUom(Uom value) {
            this.uom = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
     *       &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}uom" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ExcessMilesPerYear {

        @XmlValue
        protected BigInteger value;
        @XmlAttribute(name = "uom")
        protected Uom uom;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setValue(BigInteger value) {
            this.value = value;
        }

        /**
         * Gets the value of the uom property.
         * 
         * @return
         *     possible object is
         *     {@link Uom }
         *     
         */
        public Uom getUom() {
            return uom;
        }

        /**
         * Sets the value of the uom property.
         * 
         * @param value
         *     allowed object is
         *     {@link Uom }
         *     
         */
        public void setUom(Uom value) {
            this.uom = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FinalAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class InsuranceTotalExtendedWarrantyAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ManufacturerRebateAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class NetAmountFinanced {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class NetCapitalizedCostAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class NetTradeAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class OfferingType {

        @XmlValue
        protected String value;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PurchasePrice {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ResidualAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class SecurityDepositAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
     *       &lt;attribute name="length" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class Term {

        @XmlValue
        protected BigInteger value;
        @XmlAttribute(name = "length", required = true)
        protected String length;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setValue(BigInteger value) {
            this.value = value;
        }

        /**
         * Gets the value of the length property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLength() {
            return length;
        }

        /**
         * Sets the value of the length property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLength(String value) {
            this.length = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class TotalReductionsAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
