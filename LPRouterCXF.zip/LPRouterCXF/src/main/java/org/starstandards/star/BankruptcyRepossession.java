
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for BankruptcyRepossession complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankruptcyRepossession"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BankruptcyInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="BankruptcyDate" type="{http://www.w3.org/2001/XMLSchema}date" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RepossessionInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="RepossessionDate" type="{http://www.w3.org/2001/XMLSchema}date" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankruptcyRepossession", propOrder = {
    "bankruptcyInd",
    "bankruptcyDate",
    "repossessionInd",
    "repossessionDate"
})
public class BankruptcyRepossession {

    @XmlElement(name = "BankruptcyInd")
    protected String bankruptcyInd;
    @XmlElement(name = "BankruptcyDate")
    @XmlSchemaType(name = "date")
    protected List<XMLGregorianCalendar> bankruptcyDate;
    @XmlElement(name = "RepossessionInd")
    protected String repossessionInd;
    @XmlElement(name = "RepossessionDate")
    @XmlSchemaType(name = "date")
    protected List<XMLGregorianCalendar> repossessionDate;

    /**
     * Gets the value of the bankruptcyInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankruptcyInd() {
        return bankruptcyInd;
    }

    /**
     * Sets the value of the bankruptcyInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankruptcyInd(String value) {
        this.bankruptcyInd = value;
    }

    /**
     * Gets the value of the bankruptcyDate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bankruptcyDate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBankruptcyDate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link XMLGregorianCalendar }
     * 
     * 
     */
    public List<XMLGregorianCalendar> getBankruptcyDate() {
        if (bankruptcyDate == null) {
            bankruptcyDate = new ArrayList<XMLGregorianCalendar>();
        }
        return this.bankruptcyDate;
    }

    /**
     * Gets the value of the repossessionInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepossessionInd() {
        return repossessionInd;
    }

    /**
     * Sets the value of the repossessionInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepossessionInd(String value) {
        this.repossessionInd = value;
    }

    /**
     * Gets the value of the repossessionDate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the repossessionDate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRepossessionDate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link XMLGregorianCalendar }
     * 
     * 
     */
    public List<XMLGregorianCalendar> getRepossessionDate() {
        if (repossessionDate == null) {
            repossessionDate = new ArrayList<XMLGregorianCalendar>();
        }
        return this.repossessionDate;
    }

}
