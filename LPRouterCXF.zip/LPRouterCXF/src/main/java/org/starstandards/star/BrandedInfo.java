
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for BrandedInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BrandedInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BrandedTitleInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="BrandedTitleDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="BrandingStateCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BrandingStateReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BrandingSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BrandedInfo", propOrder = {
    "brandedTitleInd",
    "brandedTitleDate",
    "brandingStateCode",
    "brandingStateReference",
    "brandingSource"
})
public class BrandedInfo {

    @XmlElement(name = "BrandedTitleInd")
    protected String brandedTitleInd;
    @XmlElement(name = "BrandedTitleDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar brandedTitleDate;
    @XmlElement(name = "BrandingStateCode")
    protected String brandingStateCode;
    @XmlElement(name = "BrandingStateReference")
    protected String brandingStateReference;
    @XmlElement(name = "BrandingSource")
    protected String brandingSource;

    /**
     * Gets the value of the brandedTitleInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrandedTitleInd() {
        return brandedTitleInd;
    }

    /**
     * Sets the value of the brandedTitleInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrandedTitleInd(String value) {
        this.brandedTitleInd = value;
    }

    /**
     * Gets the value of the brandedTitleDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBrandedTitleDate() {
        return brandedTitleDate;
    }

    /**
     * Sets the value of the brandedTitleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBrandedTitleDate(XMLGregorianCalendar value) {
        this.brandedTitleDate = value;
    }

    /**
     * Gets the value of the brandingStateCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrandingStateCode() {
        return brandingStateCode;
    }

    /**
     * Sets the value of the brandingStateCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrandingStateCode(String value) {
        this.brandingStateCode = value;
    }

    /**
     * Gets the value of the brandingStateReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrandingStateReference() {
        return brandingStateReference;
    }

    /**
     * Sets the value of the brandingStateReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrandingStateReference(String value) {
        this.brandingStateReference = value;
    }

    /**
     * Gets the value of the brandingSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrandingSource() {
        return brandingSource;
    }

    /**
     * Sets the value of the brandingSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrandingSource(String value) {
        this.brandingSource = value;
    }

}
