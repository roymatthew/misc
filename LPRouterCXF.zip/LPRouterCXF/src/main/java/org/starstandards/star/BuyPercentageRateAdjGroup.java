
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Communicates any adjustments to the buy rate
 * 
 * <p>Java class for BuyPercentageRateAdjGroup complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BuyPercentageRateAdjGroup"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BuyPercentageRateAdjustment" type="{http://www.starstandards.org/STAR}BuyPercentageRateAdjustment" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BuyPercentageRateAdjGroup", propOrder = {
    "buyPercentageRateAdjustment"
})
public class BuyPercentageRateAdjGroup {

    @XmlElement(name = "BuyPercentageRateAdjustment", required = true)
    protected List<BuyPercentageRateAdjustment> buyPercentageRateAdjustment;

    /**
     * Gets the value of the buyPercentageRateAdjustment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the buyPercentageRateAdjustment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBuyPercentageRateAdjustment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BuyPercentageRateAdjustment }
     * 
     * 
     */
    public List<BuyPercentageRateAdjustment> getBuyPercentageRateAdjustment() {
        if (buyPercentageRateAdjustment == null) {
            buyPercentageRateAdjustment = new ArrayList<BuyPercentageRateAdjustment>();
        }
        return this.buyPercentageRateAdjustment;
    }

}
