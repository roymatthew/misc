
package org.starstandards.star;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BuyPercentageRateAdjTypeCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BuyPercentageRateAdjTypeCode"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Addition"/&gt;
 *     &lt;enumeration value="Subtraction"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "BuyPercentageRateAdjTypeCode")
@XmlEnum
public enum BuyPercentageRateAdjTypeCode {


    /**
     * Indicates an addition to be made to the buy rate.
     * 
     */
    @XmlEnumValue("Addition")
    ADDITION("Addition"),

    /**
     * Indicates a subtraction to be made to the buy rate.
     * 
     */
    @XmlEnumValue("Subtraction")
    SUBTRACTION("Subtraction");
    private final String value;

    BuyPercentageRateAdjTypeCode(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BuyPercentageRateAdjTypeCode fromValue(String v) {
        for (BuyPercentageRateAdjTypeCode c: BuyPercentageRateAdjTypeCode.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
