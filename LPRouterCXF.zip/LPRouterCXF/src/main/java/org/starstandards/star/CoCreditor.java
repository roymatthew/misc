
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Co-Creditor complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Co-Creditor"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="AlternatePartyIds" type="{http://www.starstandards.org/STAR}OrganizationalPartyAlternatePartyId" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.starstandards.org/STAR}OrganizationAddress" minOccurs="0"/&gt;
 *         &lt;element name="DBAName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Contact" type="{http://www.starstandards.org/STAR}OrganizationContact" minOccurs="0"/&gt;
 *         &lt;element name="Co-CreditorFinancing" type="{http://www.starstandards.org/STAR}Co-CreditorFinancing" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Co-Creditor", propOrder = {
    "partyId",
    "alternatePartyIds",
    "name",
    "address",
    "dbaName",
    "contact",
    "coCreditorFinancing"
})
public class CoCreditor {

    @XmlElement(name = "PartyId", required = true)
    protected String partyId;
    @XmlElement(name = "AlternatePartyIds")
    protected List<OrganizationalPartyAlternatePartyId> alternatePartyIds;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Address")
    protected OrganizationAddress address;
    @XmlElement(name = "DBAName")
    protected String dbaName;
    @XmlElement(name = "Contact")
    protected OrganizationContact contact;
    @XmlElement(name = "Co-CreditorFinancing")
    protected CoCreditorFinancing coCreditorFinancing;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the alternatePartyIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternatePartyIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternatePartyIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrganizationalPartyAlternatePartyId }
     * 
     * 
     */
    public List<OrganizationalPartyAlternatePartyId> getAlternatePartyIds() {
        if (alternatePartyIds == null) {
            alternatePartyIds = new ArrayList<OrganizationalPartyAlternatePartyId>();
        }
        return this.alternatePartyIds;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationAddress }
     *     
     */
    public OrganizationAddress getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationAddress }
     *     
     */
    public void setAddress(OrganizationAddress value) {
        this.address = value;
    }

    /**
     * Gets the value of the dbaName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDBAName() {
        return dbaName;
    }

    /**
     * Sets the value of the dbaName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDBAName(String value) {
        this.dbaName = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationContact }
     *     
     */
    public OrganizationContact getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationContact }
     *     
     */
    public void setContact(OrganizationContact value) {
        this.contact = value;
    }

    /**
     * Gets the value of the coCreditorFinancing property.
     * 
     * @return
     *     possible object is
     *     {@link CoCreditorFinancing }
     *     
     */
    public CoCreditorFinancing getCoCreditorFinancing() {
        return coCreditorFinancing;
    }

    /**
     * Sets the value of the coCreditorFinancing property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoCreditorFinancing }
     *     
     */
    public void setCoCreditorFinancing(CoCreditorFinancing value) {
        this.coCreditorFinancing = value;
    }

}
