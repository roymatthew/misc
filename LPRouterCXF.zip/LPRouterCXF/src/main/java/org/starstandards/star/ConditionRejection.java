
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConditionRejection complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConditionRejection"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConditionRejectionReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ConditionRejectionText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConditionRejection", propOrder = {
    "conditionRejectionReasonCode",
    "conditionRejectionText"
})
public class ConditionRejection {

    @XmlElement(name = "ConditionRejectionReasonCode")
    protected String conditionRejectionReasonCode;
    @XmlElement(name = "ConditionRejectionText")
    protected String conditionRejectionText;

    /**
     * Gets the value of the conditionRejectionReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConditionRejectionReasonCode() {
        return conditionRejectionReasonCode;
    }

    /**
     * Sets the value of the conditionRejectionReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConditionRejectionReasonCode(String value) {
        this.conditionRejectionReasonCode = value;
    }

    /**
     * Gets the value of the conditionRejectionText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConditionRejectionText() {
        return conditionRejectionText;
    }

    /**
     * Sets the value of the conditionRejectionText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConditionRejectionText(String value) {
        this.conditionRejectionText = value;
    }

}
