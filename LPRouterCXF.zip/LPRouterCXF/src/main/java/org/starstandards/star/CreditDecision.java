
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreditDecision complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditDecision"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Header" type="{http://www.starstandards.org/STAR}CreditDecisionHeader"/&gt;
 *         &lt;element name="Detail" type="{http://www.starstandards.org/STAR}CreditDecisionDetail"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditDecision", propOrder = {
    "header",
    "detail"
})
public class CreditDecision {

    @XmlElement(name = "Header", required = true)
    protected CreditDecisionHeader header;
    @XmlElement(name = "Detail", required = true)
    protected CreditDecisionDetail detail;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link CreditDecisionHeader }
     *     
     */
    public CreditDecisionHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditDecisionHeader }
     *     
     */
    public void setHeader(CreditDecisionHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the detail property.
     * 
     * @return
     *     possible object is
     *     {@link CreditDecisionDetail }
     *     
     */
    public CreditDecisionDetail getDetail() {
        return detail;
    }

    /**
     * Sets the value of the detail property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditDecisionDetail }
     *     
     */
    public void setDetail(CreditDecisionDetail value) {
        this.detail = value;
    }

}
