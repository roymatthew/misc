
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreditDecisionDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditDecisionDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CreditVehicle" type="{http://www.starstandards.org/STAR}CreditVehicle" minOccurs="0"/&gt;
 *         &lt;element name="IndividualApplicant" type="{http://www.starstandards.org/STAR}IndividualApplicantPartyExtended" minOccurs="0"/&gt;
 *         &lt;element name="Co-Applicant" type="{http://www.starstandards.org/STAR}Co-ApplicantPartyExtended" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OrganizationalApplicant" type="{http://www.starstandards.org/STAR}OrganizationalApplicantPartyExtended" minOccurs="0"/&gt;
 *         &lt;element name="PrimaryDriver" type="{http://www.starstandards.org/STAR}CreditPrimaryDriver" minOccurs="0"/&gt;
 *         &lt;element name="Financing" type="{http://www.starstandards.org/STAR}ApplicationFinancing" minOccurs="0"/&gt;
 *         &lt;element name="Decision" type="{http://www.starstandards.org/STAR}Decision"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditDecisionDetail", propOrder = {
    "creditVehicle",
    "individualApplicant",
    "coApplicant",
    "organizationalApplicant",
    "primaryDriver",
    "financing",
    "decision"
})
public class CreditDecisionDetail {

    @XmlElement(name = "CreditVehicle")
    protected CreditVehicle creditVehicle;
    @XmlElement(name = "IndividualApplicant")
    protected IndividualApplicantPartyExtended individualApplicant;
    @XmlElement(name = "Co-Applicant")
    protected List<CoApplicantPartyExtended> coApplicant;
    @XmlElement(name = "OrganizationalApplicant")
    protected OrganizationalApplicantPartyExtended organizationalApplicant;
    @XmlElement(name = "PrimaryDriver")
    protected CreditPrimaryDriver primaryDriver;
    @XmlElement(name = "Financing")
    protected ApplicationFinancing financing;
    @XmlElement(name = "Decision", required = true)
    protected Decision decision;

    /**
     * Gets the value of the creditVehicle property.
     * 
     * @return
     *     possible object is
     *     {@link CreditVehicle }
     *     
     */
    public CreditVehicle getCreditVehicle() {
        return creditVehicle;
    }

    /**
     * Sets the value of the creditVehicle property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditVehicle }
     *     
     */
    public void setCreditVehicle(CreditVehicle value) {
        this.creditVehicle = value;
    }

    /**
     * Gets the value of the individualApplicant property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantPartyExtended }
     *     
     */
    public IndividualApplicantPartyExtended getIndividualApplicant() {
        return individualApplicant;
    }

    /**
     * Sets the value of the individualApplicant property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantPartyExtended }
     *     
     */
    public void setIndividualApplicant(IndividualApplicantPartyExtended value) {
        this.individualApplicant = value;
    }

    /**
     * Gets the value of the coApplicant property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coApplicant property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoApplicant().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoApplicantPartyExtended }
     * 
     * 
     */
    public List<CoApplicantPartyExtended> getCoApplicant() {
        if (coApplicant == null) {
            coApplicant = new ArrayList<CoApplicantPartyExtended>();
        }
        return this.coApplicant;
    }

    /**
     * Gets the value of the organizationalApplicant property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationalApplicantPartyExtended }
     *     
     */
    public OrganizationalApplicantPartyExtended getOrganizationalApplicant() {
        return organizationalApplicant;
    }

    /**
     * Sets the value of the organizationalApplicant property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationalApplicantPartyExtended }
     *     
     */
    public void setOrganizationalApplicant(OrganizationalApplicantPartyExtended value) {
        this.organizationalApplicant = value;
    }

    /**
     * Gets the value of the primaryDriver property.
     * 
     * @return
     *     possible object is
     *     {@link CreditPrimaryDriver }
     *     
     */
    public CreditPrimaryDriver getPrimaryDriver() {
        return primaryDriver;
    }

    /**
     * Sets the value of the primaryDriver property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditPrimaryDriver }
     *     
     */
    public void setPrimaryDriver(CreditPrimaryDriver value) {
        this.primaryDriver = value;
    }

    /**
     * Gets the value of the financing property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationFinancing }
     *     
     */
    public ApplicationFinancing getFinancing() {
        return financing;
    }

    /**
     * Sets the value of the financing property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationFinancing }
     *     
     */
    public void setFinancing(ApplicationFinancing value) {
        this.financing = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link Decision }
     *     
     */
    public Decision getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link Decision }
     *     
     */
    public void setDecision(Decision value) {
        this.decision = value;
    }

}
