
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreditDecisionHeader complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditDecisionHeader"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DocumentDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SecondaryPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SecondaryDealerNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DocumentId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FinanceCompany" type="{http://www.starstandards.org/STAR}ExpandedFinanceParty"/&gt;
 *         &lt;element name="Dealer" type="{http://www.starstandards.org/STAR}DealerParty" minOccurs="0"/&gt;
 *         &lt;element name="ApplicationStatus" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ApplicationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ApplicationSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Privacy" type="{http://www.starstandards.org/STAR}Privacy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DecisionId" type="{http://www.starstandards.org/STAR}DecisionId" minOccurs="0"/&gt;
 *         &lt;element name="ApplicationStatusDetail" type="{http://www.starstandards.org/STAR}ApplicationStatusDetail" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditDecisionHeader", propOrder = {
    "documentDateTime",
    "secondaryPassword",
    "secondaryDealerNumber",
    "documentId",
    "financeCompany",
    "dealer",
    "applicationStatus",
    "applicationNumber",
    "applicationSource",
    "privacy",
    "decisionId",
    "applicationStatusDetail"
})
public class CreditDecisionHeader {

    @XmlElement(name = "DocumentDateTime")
    protected String documentDateTime;
    @XmlElement(name = "SecondaryPassword")
    protected String secondaryPassword;
    @XmlElement(name = "SecondaryDealerNumber")
    protected String secondaryDealerNumber;
    @XmlElement(name = "DocumentId", required = true)
    protected String documentId;
    @XmlElement(name = "FinanceCompany", required = true)
    protected ExpandedFinanceParty financeCompany;
    @XmlElement(name = "Dealer")
    protected DealerParty dealer;
    @XmlElement(name = "ApplicationStatus", required = true)
    protected String applicationStatus;
    @XmlElement(name = "ApplicationNumber")
    protected String applicationNumber;
    @XmlElement(name = "ApplicationSource")
    protected String applicationSource;
    @XmlElement(name = "Privacy")
    protected List<Privacy> privacy;
    @XmlElement(name = "DecisionId")
    protected String decisionId;
    @XmlElement(name = "ApplicationStatusDetail")
    protected String applicationStatusDetail;

    /**
     * Gets the value of the documentDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentDateTime() {
        return documentDateTime;
    }

    /**
     * Sets the value of the documentDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentDateTime(String value) {
        this.documentDateTime = value;
    }

    /**
     * Gets the value of the secondaryPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondaryPassword() {
        return secondaryPassword;
    }

    /**
     * Sets the value of the secondaryPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondaryPassword(String value) {
        this.secondaryPassword = value;
    }

    /**
     * Gets the value of the secondaryDealerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondaryDealerNumber() {
        return secondaryDealerNumber;
    }

    /**
     * Sets the value of the secondaryDealerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondaryDealerNumber(String value) {
        this.secondaryDealerNumber = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentId(String value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the financeCompany property.
     * 
     * @return
     *     possible object is
     *     {@link ExpandedFinanceParty }
     *     
     */
    public ExpandedFinanceParty getFinanceCompany() {
        return financeCompany;
    }

    /**
     * Sets the value of the financeCompany property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpandedFinanceParty }
     *     
     */
    public void setFinanceCompany(ExpandedFinanceParty value) {
        this.financeCompany = value;
    }

    /**
     * Gets the value of the dealer property.
     * 
     * @return
     *     possible object is
     *     {@link DealerParty }
     *     
     */
    public DealerParty getDealer() {
        return dealer;
    }

    /**
     * Sets the value of the dealer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DealerParty }
     *     
     */
    public void setDealer(DealerParty value) {
        this.dealer = value;
    }

    /**
     * Gets the value of the applicationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStatus() {
        return applicationStatus;
    }

    /**
     * Sets the value of the applicationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStatus(String value) {
        this.applicationStatus = value;
    }

    /**
     * Gets the value of the applicationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationNumber() {
        return applicationNumber;
    }

    /**
     * Sets the value of the applicationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationNumber(String value) {
        this.applicationNumber = value;
    }

    /**
     * Gets the value of the applicationSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationSource() {
        return applicationSource;
    }

    /**
     * Sets the value of the applicationSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationSource(String value) {
        this.applicationSource = value;
    }

    /**
     * Gets the value of the privacy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the privacy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrivacy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Privacy }
     * 
     * 
     */
    public List<Privacy> getPrivacy() {
        if (privacy == null) {
            privacy = new ArrayList<Privacy>();
        }
        return this.privacy;
    }

    /**
     * Gets the value of the decisionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionId() {
        return decisionId;
    }

    /**
     * Sets the value of the decisionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionId(String value) {
        this.decisionId = value;
    }

    /**
     * Gets the value of the applicationStatusDetail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStatusDetail() {
        return applicationStatusDetail;
    }

    /**
     * Sets the value of the applicationStatusDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStatusDetail(String value) {
        this.applicationStatusDetail = value;
    }

}
