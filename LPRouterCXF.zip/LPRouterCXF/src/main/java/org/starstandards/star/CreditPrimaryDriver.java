
package org.starstandards.star;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreditPrimaryDriver complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditPrimaryDriver"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="AlternatePartyIds" type="{http://www.starstandards.org/STAR}IndividualPartyAlternatePartyId" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PersonName" type="{http://www.starstandards.org/STAR}IndividualApplicantPersonName" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.starstandards.org/STAR}IndividualApplicantAddress" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Contact" type="{http://www.starstandards.org/STAR}IndividualApplicantContact" minOccurs="0"/&gt;
 *         &lt;element name="RelationshipCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RelationshipDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Privacy" type="{http://www.starstandards.org/STAR}Privacy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PrimaryDriverInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="EstimatedUsage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditPrimaryDriver", propOrder = {
    "partyId",
    "alternatePartyIds",
    "personName",
    "address",
    "contact",
    "relationshipCode",
    "relationshipDescription",
    "privacy",
    "primaryDriverInd",
    "estimatedUsage"
})
public class CreditPrimaryDriver {

    @XmlElement(name = "PartyId", required = true)
    protected String partyId;
    @XmlElement(name = "AlternatePartyIds")
    protected List<IndividualPartyAlternatePartyId> alternatePartyIds;
    @XmlElement(name = "PersonName")
    protected IndividualApplicantPersonName personName;
    @XmlElement(name = "Address")
    protected List<IndividualApplicantAddress> address;
    @XmlElement(name = "Contact")
    protected IndividualApplicantContact contact;
    @XmlElement(name = "RelationshipCode")
    protected String relationshipCode;
    @XmlElement(name = "RelationshipDescription")
    protected String relationshipDescription;
    @XmlElement(name = "Privacy")
    protected List<Privacy> privacy;
    @XmlElement(name = "PrimaryDriverInd")
    protected String primaryDriverInd;
    @XmlElement(name = "EstimatedUsage")
    protected BigDecimal estimatedUsage;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the alternatePartyIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternatePartyIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternatePartyIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IndividualPartyAlternatePartyId }
     * 
     * 
     */
    public List<IndividualPartyAlternatePartyId> getAlternatePartyIds() {
        if (alternatePartyIds == null) {
            alternatePartyIds = new ArrayList<IndividualPartyAlternatePartyId>();
        }
        return this.alternatePartyIds;
    }

    /**
     * Gets the value of the personName property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantPersonName }
     *     
     */
    public IndividualApplicantPersonName getPersonName() {
        return personName;
    }

    /**
     * Sets the value of the personName property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantPersonName }
     *     
     */
    public void setPersonName(IndividualApplicantPersonName value) {
        this.personName = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IndividualApplicantAddress }
     * 
     * 
     */
    public List<IndividualApplicantAddress> getAddress() {
        if (address == null) {
            address = new ArrayList<IndividualApplicantAddress>();
        }
        return this.address;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantContact }
     *     
     */
    public IndividualApplicantContact getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantContact }
     *     
     */
    public void setContact(IndividualApplicantContact value) {
        this.contact = value;
    }

    /**
     * Gets the value of the relationshipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * Sets the value of the relationshipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipCode(String value) {
        this.relationshipCode = value;
    }

    /**
     * Gets the value of the relationshipDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipDescription() {
        return relationshipDescription;
    }

    /**
     * Sets the value of the relationshipDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipDescription(String value) {
        this.relationshipDescription = value;
    }

    /**
     * Gets the value of the privacy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the privacy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrivacy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Privacy }
     * 
     * 
     */
    public List<Privacy> getPrivacy() {
        if (privacy == null) {
            privacy = new ArrayList<Privacy>();
        }
        return this.privacy;
    }

    /**
     * Gets the value of the primaryDriverInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryDriverInd() {
        return primaryDriverInd;
    }

    /**
     * Sets the value of the primaryDriverInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryDriverInd(String value) {
        this.primaryDriverInd = value;
    }

    /**
     * Gets the value of the estimatedUsage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEstimatedUsage() {
        return estimatedUsage;
    }

    /**
     * Sets the value of the estimatedUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEstimatedUsage(BigDecimal value) {
        this.estimatedUsage = value;
    }

}
