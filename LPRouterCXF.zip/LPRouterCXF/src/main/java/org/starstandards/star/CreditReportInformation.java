
package org.starstandards.star;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for CreditReportInformation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditReportInformation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CreditReportSource" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="TU"/&gt;
 *               &lt;enumeration value="EX"/&gt;
 *               &lt;enumeration value="EQ"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CreditReportRiskModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CreditReportDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="CreditReportScore" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/&gt;
 *         &lt;element name="CreditReportReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CreditReportUsedForDecisionInd" type="{http://www.starstandards.org/STAR}Indicator" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditReportInformation", propOrder = {
    "creditReportSource",
    "creditReportRiskModel",
    "creditReportDate",
    "creditReportScore",
    "creditReportReasonCode",
    "creditReportUsedForDecisionInd"
})
public class CreditReportInformation {

    @XmlElement(name = "CreditReportSource")
    protected String creditReportSource;
    @XmlElement(name = "CreditReportRiskModel")
    protected String creditReportRiskModel;
    @XmlElement(name = "CreditReportDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar creditReportDate;
    @XmlElement(name = "CreditReportScore")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger creditReportScore;
    @XmlElement(name = "CreditReportReasonCode")
    protected List<String> creditReportReasonCode;
    @XmlElement(name = "CreditReportUsedForDecisionInd")
    protected List<String> creditReportUsedForDecisionInd;

    /**
     * Gets the value of the creditReportSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditReportSource() {
        return creditReportSource;
    }

    /**
     * Sets the value of the creditReportSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditReportSource(String value) {
        this.creditReportSource = value;
    }

    /**
     * Gets the value of the creditReportRiskModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditReportRiskModel() {
        return creditReportRiskModel;
    }

    /**
     * Sets the value of the creditReportRiskModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditReportRiskModel(String value) {
        this.creditReportRiskModel = value;
    }

    /**
     * Gets the value of the creditReportDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreditReportDate() {
        return creditReportDate;
    }

    /**
     * Sets the value of the creditReportDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreditReportDate(XMLGregorianCalendar value) {
        this.creditReportDate = value;
    }

    /**
     * Gets the value of the creditReportScore property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCreditReportScore() {
        return creditReportScore;
    }

    /**
     * Sets the value of the creditReportScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCreditReportScore(BigInteger value) {
        this.creditReportScore = value;
    }

    /**
     * Gets the value of the creditReportReasonCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditReportReasonCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditReportReasonCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCreditReportReasonCode() {
        if (creditReportReasonCode == null) {
            creditReportReasonCode = new ArrayList<String>();
        }
        return this.creditReportReasonCode;
    }

    /**
     * Gets the value of the creditReportUsedForDecisionInd property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditReportUsedForDecisionInd property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditReportUsedForDecisionInd().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCreditReportUsedForDecisionInd() {
        if (creditReportUsedForDecisionInd == null) {
            creditReportUsedForDecisionInd = new ArrayList<String>();
        }
        return this.creditReportUsedForDecisionInd;
    }

}
