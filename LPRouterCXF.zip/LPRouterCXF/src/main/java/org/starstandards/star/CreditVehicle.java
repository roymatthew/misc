
package org.starstandards.star;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for CreditVehicle complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditVehicle"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Model" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ModelYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ModelDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Make" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SaleClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Condition" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CertifiedPreownedInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="VehicleNote" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="VIN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeliveryMileage" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
 *                 &lt;attribute name="uom" use="required" type="{http://www.starstandards.org/STAR}uom" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VehicleStock" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TrimCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DoorsQuantity" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/&gt;
 *         &lt;element name="BodyStyle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InteriorColor" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExteriorColor" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TransmissionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OdometerStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NonUSVehicleInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="VehicleDemoInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="LicenseNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BrandedInfo" type="{http://www.starstandards.org/STAR}BrandedInfo" minOccurs="0"/&gt;
 *         &lt;element name="RestrictionInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="RestrictionDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TelematicsServiceInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="Option" type="{http://www.starstandards.org/STAR}ExpandedOption" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Pricing" type="{http://www.starstandards.org/STAR}VehiclePricing" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CollateralType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NumberOfEngineCylinders" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/&gt;
 *         &lt;element name="VanConversionPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="VanConversionCost" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AuctionInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleWeight" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="VehicleUse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NumberOfUnits" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/&gt;
 *         &lt;element name="VehicleId" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
 *                 &lt;attribute name="source" use="required"&gt;
 *                   &lt;simpleType&gt;
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                       &lt;enumeration value="BB"/&gt;
 *                       &lt;enumeration value="CHROME"/&gt;
 *                       &lt;enumeration value="KBB"/&gt;
 *                       &lt;enumeration value="NADA"/&gt;
 *                     &lt;/restriction&gt;
 *                   &lt;/simpleType&gt;
 *                 &lt;/attribute&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditVehicle", propOrder = {
    "model",
    "modelYear",
    "modelDescription",
    "make",
    "saleClass",
    "condition",
    "certifiedPreownedInd",
    "vehicleNote",
    "vin",
    "deliveryMileage",
    "vehicleStock",
    "trimCode",
    "doorsQuantity",
    "bodyStyle",
    "interiorColor",
    "exteriorColor",
    "transmissionType",
    "odometerStatus",
    "nonUSVehicleInd",
    "vehicleDemoInd",
    "licenseNumber",
    "brandedInfo",
    "restrictionInd",
    "restrictionDescription",
    "telematicsServiceInd",
    "option",
    "pricing",
    "collateralType",
    "numberOfEngineCylinders",
    "vanConversionPercentage",
    "vanConversionCost",
    "auctionInd",
    "invoiceNumber",
    "vehicleWeight",
    "vehicleUse",
    "numberOfUnits",
    "vehicleId"
})
public class CreditVehicle {

    @XmlElement(name = "Model")
    protected String model;
    @XmlElement(name = "ModelYear")
    protected String modelYear;
    @XmlElement(name = "ModelDescription")
    protected String modelDescription;
    @XmlElement(name = "Make")
    protected String make;
    @XmlElement(name = "SaleClass")
    protected String saleClass;
    @XmlElement(name = "Condition")
    protected String condition;
    @XmlElement(name = "CertifiedPreownedInd")
    protected String certifiedPreownedInd;
    @XmlElement(name = "VehicleNote")
    protected List<String> vehicleNote;
    @XmlElement(name = "VIN")
    protected String vin;
    @XmlElement(name = "DeliveryMileage")
    protected CreditVehicle.DeliveryMileage deliveryMileage;
    @XmlElement(name = "VehicleStock")
    protected String vehicleStock;
    @XmlElement(name = "TrimCode")
    protected String trimCode;
    @XmlElement(name = "DoorsQuantity")
    protected BigInteger doorsQuantity;
    @XmlElement(name = "BodyStyle")
    protected String bodyStyle;
    @XmlElement(name = "InteriorColor")
    protected List<String> interiorColor;
    @XmlElement(name = "ExteriorColor")
    protected List<String> exteriorColor;
    @XmlElement(name = "TransmissionType")
    protected String transmissionType;
    @XmlElement(name = "OdometerStatus")
    protected String odometerStatus;
    @XmlElement(name = "NonUSVehicleInd")
    protected String nonUSVehicleInd;
    @XmlElement(name = "VehicleDemoInd")
    protected String vehicleDemoInd;
    @XmlElement(name = "LicenseNumber")
    protected String licenseNumber;
    @XmlElement(name = "BrandedInfo")
    protected BrandedInfo brandedInfo;
    @XmlElement(name = "RestrictionInd")
    protected String restrictionInd;
    @XmlElement(name = "RestrictionDescription")
    protected String restrictionDescription;
    @XmlElement(name = "TelematicsServiceInd")
    protected String telematicsServiceInd;
    @XmlElement(name = "Option")
    protected List<ExpandedOption> option;
    @XmlElement(name = "Pricing")
    protected List<VehiclePricing> pricing;
    @XmlElement(name = "CollateralType")
    protected String collateralType;
    @XmlElement(name = "NumberOfEngineCylinders")
    protected BigInteger numberOfEngineCylinders;
    @XmlElement(name = "VanConversionPercentage")
    protected BigDecimal vanConversionPercentage;
    @XmlElement(name = "VanConversionCost")
    protected CreditVehicle.VanConversionCost vanConversionCost;
    @XmlElement(name = "AuctionInd")
    protected String auctionInd;
    @XmlElement(name = "InvoiceNumber")
    protected String invoiceNumber;
    @XmlElement(name = "VehicleWeight")
    protected BigDecimal vehicleWeight;
    @XmlElement(name = "VehicleUse")
    protected String vehicleUse;
    @XmlElement(name = "NumberOfUnits")
    protected BigInteger numberOfUnits;
    @XmlElement(name = "VehicleId")
    protected List<CreditVehicle.VehicleId> vehicleId;

    /**
     * Gets the value of the model property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the value of the model property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModel(String value) {
        this.model = value;
    }

    /**
     * Gets the value of the modelYear property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the value of the modelYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelYear(String value) {
        this.modelYear = value;
    }

    /**
     * Gets the value of the modelDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelDescription() {
        return modelDescription;
    }

    /**
     * Sets the value of the modelDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelDescription(String value) {
        this.modelDescription = value;
    }

    /**
     * Gets the value of the make property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMake() {
        return make;
    }

    /**
     * Sets the value of the make property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMake(String value) {
        this.make = value;
    }

    /**
     * Gets the value of the saleClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaleClass() {
        return saleClass;
    }

    /**
     * Sets the value of the saleClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaleClass(String value) {
        this.saleClass = value;
    }

    /**
     * Gets the value of the condition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCondition() {
        return condition;
    }

    /**
     * Sets the value of the condition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCondition(String value) {
        this.condition = value;
    }

    /**
     * Gets the value of the certifiedPreownedInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCertifiedPreownedInd() {
        return certifiedPreownedInd;
    }

    /**
     * Sets the value of the certifiedPreownedInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCertifiedPreownedInd(String value) {
        this.certifiedPreownedInd = value;
    }

    /**
     * Gets the value of the vehicleNote property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the vehicleNote property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVehicleNote().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getVehicleNote() {
        if (vehicleNote == null) {
            vehicleNote = new ArrayList<String>();
        }
        return this.vehicleNote;
    }

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

    /**
     * Gets the value of the deliveryMileage property.
     * 
     * @return
     *     possible object is
     *     {@link CreditVehicle.DeliveryMileage }
     *     
     */
    public CreditVehicle.DeliveryMileage getDeliveryMileage() {
        return deliveryMileage;
    }

    /**
     * Sets the value of the deliveryMileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditVehicle.DeliveryMileage }
     *     
     */
    public void setDeliveryMileage(CreditVehicle.DeliveryMileage value) {
        this.deliveryMileage = value;
    }

    /**
     * Gets the value of the vehicleStock property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleStock() {
        return vehicleStock;
    }

    /**
     * Sets the value of the vehicleStock property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleStock(String value) {
        this.vehicleStock = value;
    }

    /**
     * Gets the value of the trimCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrimCode() {
        return trimCode;
    }

    /**
     * Sets the value of the trimCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrimCode(String value) {
        this.trimCode = value;
    }

    /**
     * Gets the value of the doorsQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDoorsQuantity() {
        return doorsQuantity;
    }

    /**
     * Sets the value of the doorsQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDoorsQuantity(BigInteger value) {
        this.doorsQuantity = value;
    }

    /**
     * Gets the value of the bodyStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBodyStyle() {
        return bodyStyle;
    }

    /**
     * Sets the value of the bodyStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBodyStyle(String value) {
        this.bodyStyle = value;
    }

    /**
     * Gets the value of the interiorColor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the interiorColor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInteriorColor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getInteriorColor() {
        if (interiorColor == null) {
            interiorColor = new ArrayList<String>();
        }
        return this.interiorColor;
    }

    /**
     * Gets the value of the exteriorColor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exteriorColor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExteriorColor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getExteriorColor() {
        if (exteriorColor == null) {
            exteriorColor = new ArrayList<String>();
        }
        return this.exteriorColor;
    }

    /**
     * Gets the value of the transmissionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransmissionType() {
        return transmissionType;
    }

    /**
     * Sets the value of the transmissionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransmissionType(String value) {
        this.transmissionType = value;
    }

    /**
     * Gets the value of the odometerStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOdometerStatus() {
        return odometerStatus;
    }

    /**
     * Sets the value of the odometerStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOdometerStatus(String value) {
        this.odometerStatus = value;
    }

    /**
     * Gets the value of the nonUSVehicleInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonUSVehicleInd() {
        return nonUSVehicleInd;
    }

    /**
     * Sets the value of the nonUSVehicleInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonUSVehicleInd(String value) {
        this.nonUSVehicleInd = value;
    }

    /**
     * Gets the value of the vehicleDemoInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleDemoInd() {
        return vehicleDemoInd;
    }

    /**
     * Sets the value of the vehicleDemoInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleDemoInd(String value) {
        this.vehicleDemoInd = value;
    }

    /**
     * Gets the value of the licenseNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicenseNumber() {
        return licenseNumber;
    }

    /**
     * Sets the value of the licenseNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicenseNumber(String value) {
        this.licenseNumber = value;
    }

    /**
     * Gets the value of the brandedInfo property.
     * 
     * @return
     *     possible object is
     *     {@link BrandedInfo }
     *     
     */
    public BrandedInfo getBrandedInfo() {
        return brandedInfo;
    }

    /**
     * Sets the value of the brandedInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link BrandedInfo }
     *     
     */
    public void setBrandedInfo(BrandedInfo value) {
        this.brandedInfo = value;
    }

    /**
     * Gets the value of the restrictionInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictionInd() {
        return restrictionInd;
    }

    /**
     * Sets the value of the restrictionInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictionInd(String value) {
        this.restrictionInd = value;
    }

    /**
     * Gets the value of the restrictionDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictionDescription() {
        return restrictionDescription;
    }

    /**
     * Sets the value of the restrictionDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictionDescription(String value) {
        this.restrictionDescription = value;
    }

    /**
     * Gets the value of the telematicsServiceInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelematicsServiceInd() {
        return telematicsServiceInd;
    }

    /**
     * Sets the value of the telematicsServiceInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelematicsServiceInd(String value) {
        this.telematicsServiceInd = value;
    }

    /**
     * Gets the value of the option property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the option property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOption().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExpandedOption }
     * 
     * 
     */
    public List<ExpandedOption> getOption() {
        if (option == null) {
            option = new ArrayList<ExpandedOption>();
        }
        return this.option;
    }

    /**
     * Gets the value of the pricing property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pricing property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPricing().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VehiclePricing }
     * 
     * 
     */
    public List<VehiclePricing> getPricing() {
        if (pricing == null) {
            pricing = new ArrayList<VehiclePricing>();
        }
        return this.pricing;
    }

    /**
     * Gets the value of the collateralType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollateralType() {
        return collateralType;
    }

    /**
     * Sets the value of the collateralType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollateralType(String value) {
        this.collateralType = value;
    }

    /**
     * Gets the value of the numberOfEngineCylinders property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfEngineCylinders() {
        return numberOfEngineCylinders;
    }

    /**
     * Sets the value of the numberOfEngineCylinders property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfEngineCylinders(BigInteger value) {
        this.numberOfEngineCylinders = value;
    }

    /**
     * Gets the value of the vanConversionPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getVanConversionPercentage() {
        return vanConversionPercentage;
    }

    /**
     * Sets the value of the vanConversionPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setVanConversionPercentage(BigDecimal value) {
        this.vanConversionPercentage = value;
    }

    /**
     * Gets the value of the vanConversionCost property.
     * 
     * @return
     *     possible object is
     *     {@link CreditVehicle.VanConversionCost }
     *     
     */
    public CreditVehicle.VanConversionCost getVanConversionCost() {
        return vanConversionCost;
    }

    /**
     * Sets the value of the vanConversionCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditVehicle.VanConversionCost }
     *     
     */
    public void setVanConversionCost(CreditVehicle.VanConversionCost value) {
        this.vanConversionCost = value;
    }

    /**
     * Gets the value of the auctionInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuctionInd() {
        return auctionInd;
    }

    /**
     * Sets the value of the auctionInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuctionInd(String value) {
        this.auctionInd = value;
    }

    /**
     * Gets the value of the invoiceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * Sets the value of the invoiceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceNumber(String value) {
        this.invoiceNumber = value;
    }

    /**
     * Gets the value of the vehicleWeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getVehicleWeight() {
        return vehicleWeight;
    }

    /**
     * Sets the value of the vehicleWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setVehicleWeight(BigDecimal value) {
        this.vehicleWeight = value;
    }

    /**
     * Gets the value of the vehicleUse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleUse() {
        return vehicleUse;
    }

    /**
     * Sets the value of the vehicleUse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleUse(String value) {
        this.vehicleUse = value;
    }

    /**
     * Gets the value of the numberOfUnits property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfUnits() {
        return numberOfUnits;
    }

    /**
     * Sets the value of the numberOfUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfUnits(BigInteger value) {
        this.numberOfUnits = value;
    }

    /**
     * Gets the value of the vehicleId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the vehicleId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVehicleId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditVehicle.VehicleId }
     * 
     * 
     */
    public List<CreditVehicle.VehicleId> getVehicleId() {
        if (vehicleId == null) {
            vehicleId = new ArrayList<CreditVehicle.VehicleId>();
        }
        return this.vehicleId;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
     *       &lt;attribute name="uom" use="required" type="{http://www.starstandards.org/STAR}uom" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DeliveryMileage {

        @XmlValue
        protected BigInteger value;
        @XmlAttribute(name = "uom", required = true)
        protected Uom uom;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setValue(BigInteger value) {
            this.value = value;
        }

        /**
         * Gets the value of the uom property.
         * 
         * @return
         *     possible object is
         *     {@link Uom }
         *     
         */
        public Uom getUom() {
            return uom;
        }

        /**
         * Sets the value of the uom property.
         * 
         * @param value
         *     allowed object is
         *     {@link Uom }
         *     
         */
        public void setUom(Uom value) {
            this.uom = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class VanConversionCost {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
     *       &lt;attribute name="source" use="required"&gt;
     *         &lt;simpleType&gt;
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *             &lt;enumeration value="BB"/&gt;
     *             &lt;enumeration value="CHROME"/&gt;
     *             &lt;enumeration value="KBB"/&gt;
     *             &lt;enumeration value="NADA"/&gt;
     *           &lt;/restriction&gt;
     *         &lt;/simpleType&gt;
     *       &lt;/attribute&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class VehicleId {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "source", required = true)
        protected String source;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the source property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSource() {
            return source;
        }

        /**
         * Sets the value of the source property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSource(String value) {
            this.source = value;
        }

    }

}
