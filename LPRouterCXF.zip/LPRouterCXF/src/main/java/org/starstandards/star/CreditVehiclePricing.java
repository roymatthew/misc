
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreditVehiclePricing complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditVehiclePricing"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="VehiclePrice" type="{http://www.starstandards.org/STAR}VehiclePrice"/&gt;
 *         &lt;element name="PriceExplanation" type="{http://www.starstandards.org/STAR}PriceExplanation" minOccurs="0"/&gt;
 *         &lt;element name="VehiclePricingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PricingTypeSource" type="{http://www.starstandards.org/STAR}PricingTypeSource" minOccurs="0"/&gt;
 *         &lt;element name="VehiclePricingTypeSource" type="{http://www.starstandards.org/STAR}VehiclePricingTypeSource" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditVehiclePricing", propOrder = {
    "vehiclePrice",
    "priceExplanation",
    "vehiclePricingType",
    "pricingTypeSource",
    "vehiclePricingTypeSource"
})
public class CreditVehiclePricing {

    @XmlElement(name = "VehiclePrice", required = true)
    protected VehiclePrice vehiclePrice;
    @XmlElement(name = "PriceExplanation")
    protected String priceExplanation;
    @XmlElement(name = "VehiclePricingType")
    protected String vehiclePricingType;
    @XmlElement(name = "PricingTypeSource")
    protected String pricingTypeSource;
    @XmlElement(name = "VehiclePricingTypeSource")
    protected VehiclePricingTypeSource vehiclePricingTypeSource;

    /**
     * Gets the value of the vehiclePrice property.
     * 
     * @return
     *     possible object is
     *     {@link VehiclePrice }
     *     
     */
    public VehiclePrice getVehiclePrice() {
        return vehiclePrice;
    }

    /**
     * Sets the value of the vehiclePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehiclePrice }
     *     
     */
    public void setVehiclePrice(VehiclePrice value) {
        this.vehiclePrice = value;
    }

    /**
     * Gets the value of the priceExplanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriceExplanation() {
        return priceExplanation;
    }

    /**
     * Sets the value of the priceExplanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriceExplanation(String value) {
        this.priceExplanation = value;
    }

    /**
     * Gets the value of the vehiclePricingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehiclePricingType() {
        return vehiclePricingType;
    }

    /**
     * Sets the value of the vehiclePricingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehiclePricingType(String value) {
        this.vehiclePricingType = value;
    }

    /**
     * Gets the value of the pricingTypeSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPricingTypeSource() {
        return pricingTypeSource;
    }

    /**
     * Sets the value of the pricingTypeSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPricingTypeSource(String value) {
        this.pricingTypeSource = value;
    }

    /**
     * Gets the value of the vehiclePricingTypeSource property.
     * 
     * @return
     *     possible object is
     *     {@link VehiclePricingTypeSource }
     *     
     */
    public VehiclePricingTypeSource getVehiclePricingTypeSource() {
        return vehiclePricingTypeSource;
    }

    /**
     * Sets the value of the vehiclePricingTypeSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehiclePricingTypeSource }
     *     
     */
    public void setVehiclePricingTypeSource(VehiclePricingTypeSource value) {
        this.vehiclePricingTypeSource = value;
    }

}
