
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Decision complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Decision"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConditionRejection" type="{http://www.starstandards.org/STAR}ConditionRejection" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UpdateHistory" type="{http://www.starstandards.org/STAR}UpdateHistory" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SubmittedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="DecisionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="ElapsedTimeToDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ElectronicApprovalInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="EvaluationInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="LeaseMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ContractPurchaseDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="Financing" type="{http://www.starstandards.org/STAR}DecisionFinancing" minOccurs="0"/&gt;
 *         &lt;element name="CreditAnalyst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CreditAnalystInitials" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CreditAnalystComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CreditSupervisorComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BranchManagerComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BranchOperationManagerComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DealerComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Tier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TierDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SubprimeSendInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="TransferOfObligation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Stipulations" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="28" minOccurs="0"/&gt;
 *         &lt;element name="NonFinancialRequirements" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DecisionComments" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DecisionVehicle" type="{http://www.starstandards.org/STAR}DecisionVehicle" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Decision", propOrder = {
    "conditionRejection",
    "updateHistory",
    "submittedDateTime",
    "decisionDateTime",
    "elapsedTimeToDecision",
    "electronicApprovalInd",
    "evaluationInd",
    "leaseMessage",
    "contractPurchaseDate",
    "financing",
    "creditAnalyst",
    "creditAnalystInitials",
    "creditAnalystComments",
    "creditSupervisorComments",
    "branchManagerComments",
    "branchOperationManagerComments",
    "dealerComments",
    "tier",
    "tierDescription",
    "subprimeSendInd",
    "transferOfObligation",
    "stipulations",
    "nonFinancialRequirements",
    "decisionComments",
    "decisionVehicle"
})
public class Decision {

    @XmlElement(name = "ConditionRejection")
    protected List<ConditionRejection> conditionRejection;
    @XmlElement(name = "UpdateHistory")
    protected List<UpdateHistory> updateHistory;
    @XmlElement(name = "SubmittedDateTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar submittedDateTime;
    @XmlElement(name = "DecisionDateTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar decisionDateTime;
    @XmlElement(name = "ElapsedTimeToDecision")
    protected String elapsedTimeToDecision;
    @XmlElement(name = "ElectronicApprovalInd")
    protected String electronicApprovalInd;
    @XmlElement(name = "EvaluationInd")
    protected String evaluationInd;
    @XmlElement(name = "LeaseMessage")
    protected String leaseMessage;
    @XmlElement(name = "ContractPurchaseDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar contractPurchaseDate;
    @XmlElement(name = "Financing")
    protected DecisionFinancing financing;
    @XmlElement(name = "CreditAnalyst")
    protected String creditAnalyst;
    @XmlElement(name = "CreditAnalystInitials")
    protected String creditAnalystInitials;
    @XmlElement(name = "CreditAnalystComments")
    protected String creditAnalystComments;
    @XmlElement(name = "CreditSupervisorComments")
    protected String creditSupervisorComments;
    @XmlElement(name = "BranchManagerComments")
    protected String branchManagerComments;
    @XmlElement(name = "BranchOperationManagerComments")
    protected String branchOperationManagerComments;
    @XmlElement(name = "DealerComments")
    protected String dealerComments;
    @XmlElement(name = "Tier")
    protected String tier;
    @XmlElement(name = "TierDescription")
    protected String tierDescription;
    @XmlElement(name = "SubprimeSendInd")
    protected String subprimeSendInd;
    @XmlElement(name = "TransferOfObligation")
    protected String transferOfObligation;
    @XmlElement(name = "Stipulations")
    protected List<String> stipulations;
    @XmlElement(name = "NonFinancialRequirements")
    protected String nonFinancialRequirements;
    @XmlElement(name = "DecisionComments")
    protected List<String> decisionComments;
    @XmlElement(name = "DecisionVehicle")
    protected DecisionVehicle decisionVehicle;

    /**
     * Gets the value of the conditionRejection property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the conditionRejection property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConditionRejection().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConditionRejection }
     * 
     * 
     */
    public List<ConditionRejection> getConditionRejection() {
        if (conditionRejection == null) {
            conditionRejection = new ArrayList<ConditionRejection>();
        }
        return this.conditionRejection;
    }

    /**
     * Gets the value of the updateHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the updateHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUpdateHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UpdateHistory }
     * 
     * 
     */
    public List<UpdateHistory> getUpdateHistory() {
        if (updateHistory == null) {
            updateHistory = new ArrayList<UpdateHistory>();
        }
        return this.updateHistory;
    }

    /**
     * Gets the value of the submittedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSubmittedDateTime() {
        return submittedDateTime;
    }

    /**
     * Sets the value of the submittedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSubmittedDateTime(XMLGregorianCalendar value) {
        this.submittedDateTime = value;
    }

    /**
     * Gets the value of the decisionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDecisionDateTime() {
        return decisionDateTime;
    }

    /**
     * Sets the value of the decisionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDecisionDateTime(XMLGregorianCalendar value) {
        this.decisionDateTime = value;
    }

    /**
     * Gets the value of the elapsedTimeToDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElapsedTimeToDecision() {
        return elapsedTimeToDecision;
    }

    /**
     * Sets the value of the elapsedTimeToDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElapsedTimeToDecision(String value) {
        this.elapsedTimeToDecision = value;
    }

    /**
     * Gets the value of the electronicApprovalInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElectronicApprovalInd() {
        return electronicApprovalInd;
    }

    /**
     * Sets the value of the electronicApprovalInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElectronicApprovalInd(String value) {
        this.electronicApprovalInd = value;
    }

    /**
     * Gets the value of the evaluationInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEvaluationInd() {
        return evaluationInd;
    }

    /**
     * Sets the value of the evaluationInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEvaluationInd(String value) {
        this.evaluationInd = value;
    }

    /**
     * Gets the value of the leaseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeaseMessage() {
        return leaseMessage;
    }

    /**
     * Sets the value of the leaseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeaseMessage(String value) {
        this.leaseMessage = value;
    }

    /**
     * Gets the value of the contractPurchaseDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getContractPurchaseDate() {
        return contractPurchaseDate;
    }

    /**
     * Sets the value of the contractPurchaseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setContractPurchaseDate(XMLGregorianCalendar value) {
        this.contractPurchaseDate = value;
    }

    /**
     * Gets the value of the financing property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing }
     *     
     */
    public DecisionFinancing getFinancing() {
        return financing;
    }

    /**
     * Sets the value of the financing property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing }
     *     
     */
    public void setFinancing(DecisionFinancing value) {
        this.financing = value;
    }

    /**
     * Gets the value of the creditAnalyst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAnalyst() {
        return creditAnalyst;
    }

    /**
     * Sets the value of the creditAnalyst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAnalyst(String value) {
        this.creditAnalyst = value;
    }

    /**
     * Gets the value of the creditAnalystInitials property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAnalystInitials() {
        return creditAnalystInitials;
    }

    /**
     * Sets the value of the creditAnalystInitials property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAnalystInitials(String value) {
        this.creditAnalystInitials = value;
    }

    /**
     * Gets the value of the creditAnalystComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAnalystComments() {
        return creditAnalystComments;
    }

    /**
     * Sets the value of the creditAnalystComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAnalystComments(String value) {
        this.creditAnalystComments = value;
    }

    /**
     * Gets the value of the creditSupervisorComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditSupervisorComments() {
        return creditSupervisorComments;
    }

    /**
     * Sets the value of the creditSupervisorComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditSupervisorComments(String value) {
        this.creditSupervisorComments = value;
    }

    /**
     * Gets the value of the branchManagerComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchManagerComments() {
        return branchManagerComments;
    }

    /**
     * Sets the value of the branchManagerComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchManagerComments(String value) {
        this.branchManagerComments = value;
    }

    /**
     * Gets the value of the branchOperationManagerComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchOperationManagerComments() {
        return branchOperationManagerComments;
    }

    /**
     * Sets the value of the branchOperationManagerComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchOperationManagerComments(String value) {
        this.branchOperationManagerComments = value;
    }

    /**
     * Gets the value of the dealerComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerComments() {
        return dealerComments;
    }

    /**
     * Sets the value of the dealerComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerComments(String value) {
        this.dealerComments = value;
    }

    /**
     * Gets the value of the tier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTier() {
        return tier;
    }

    /**
     * Sets the value of the tier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTier(String value) {
        this.tier = value;
    }

    /**
     * Gets the value of the tierDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTierDescription() {
        return tierDescription;
    }

    /**
     * Sets the value of the tierDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTierDescription(String value) {
        this.tierDescription = value;
    }

    /**
     * Gets the value of the subprimeSendInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubprimeSendInd() {
        return subprimeSendInd;
    }

    /**
     * Sets the value of the subprimeSendInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubprimeSendInd(String value) {
        this.subprimeSendInd = value;
    }

    /**
     * Gets the value of the transferOfObligation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferOfObligation() {
        return transferOfObligation;
    }

    /**
     * Sets the value of the transferOfObligation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferOfObligation(String value) {
        this.transferOfObligation = value;
    }

    /**
     * Gets the value of the stipulations property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stipulations property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStipulations().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getStipulations() {
        if (stipulations == null) {
            stipulations = new ArrayList<String>();
        }
        return this.stipulations;
    }

    /**
     * Gets the value of the nonFinancialRequirements property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonFinancialRequirements() {
        return nonFinancialRequirements;
    }

    /**
     * Sets the value of the nonFinancialRequirements property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonFinancialRequirements(String value) {
        this.nonFinancialRequirements = value;
    }

    /**
     * Gets the value of the decisionComments property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the decisionComments property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDecisionComments().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDecisionComments() {
        if (decisionComments == null) {
            decisionComments = new ArrayList<String>();
        }
        return this.decisionComments;
    }

    /**
     * Gets the value of the decisionVehicle property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionVehicle }
     *     
     */
    public DecisionVehicle getDecisionVehicle() {
        return decisionVehicle;
    }

    /**
     * Sets the value of the decisionVehicle property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionVehicle }
     *     
     */
    public void setDecisionVehicle(DecisionVehicle value) {
        this.decisionVehicle = value;
    }

}
