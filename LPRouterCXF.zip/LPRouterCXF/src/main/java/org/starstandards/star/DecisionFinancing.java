
package org.starstandards.star;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DecisionFinancing complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DecisionFinancing"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FinanceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BalanceAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FinalAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResidualAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Term" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
 *                 &lt;attribute name="length" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaturityDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FinanceCompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DownPaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PurchasePrice" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApprovedInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="ApprovedAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ExpirationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="RatingIndex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ApplicationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeferredDownPayment" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DealerRebateAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ManufacturerRebateAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NetTradeAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InsuranceTotalExtendedWarrantyAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisabilityPremiumAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CreditLifePremiumAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SecurityDepositAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MiscellaneousNotes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AnnualPercentageRate" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MSRPGuidePercentage" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Tax" type="{http://www.starstandards.org/STAR}Tax" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TotalContractAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumberOfPayments" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/&gt;
 *         &lt;element name="FirstPaymentDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="OfferStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LeaseRateMoneyFactor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Fee" type="{http://www.starstandards.org/STAR}Fee" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FICOScore" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetCapitalizedCostAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PreApprovedProgramName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BaseBuyPercentageRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="BuyPercentageRateAdjGroup" type="{http://www.starstandards.org/STAR}BuyPercentageRateAdjGroup" minOccurs="0"/&gt;
 *         &lt;element name="BuyPercentageRate" type="{http://www.starstandards.org/STAR}BuyPercentageRate" minOccurs="0"/&gt;
 *         &lt;element name="MaxTerm" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="MaxMonthlyPaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxDebtToIncomePercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="MaxUnpaidBalanceAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MinimumDownPaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DownPaymentPercentage" type="{http://www.starstandards.org/STAR}DownpaymentPercentage" minOccurs="0"/&gt;
 *         &lt;element name="DiscountPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="MaxFinancedAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Participation" type="{http://www.starstandards.org/STAR}ParticipationType" minOccurs="0"/&gt;
 *         &lt;element name="ReserveGroup" type="{http://www.starstandards.org/STAR}ReserveGroupType" minOccurs="0"/&gt;
 *         &lt;element name="MinAnnualPercentageRate" type="{http://www.starstandards.org/STAR}MinAnnualPercentageRate" minOccurs="0"/&gt;
 *         &lt;element name="MaxContractRate" type="{http://www.starstandards.org/STAR}MaxContractRate" minOccurs="0"/&gt;
 *         &lt;element name="LoanToValue" type="{http://www.starstandards.org/STAR}LoanToValueType" minOccurs="0"/&gt;
 *         &lt;element name="FinanceProgramGroup" type="{http://www.starstandards.org/STAR}FinanceProgramGroupType" minOccurs="0"/&gt;
 *         &lt;element name="MaxPaymentToIncomePercentage" type="{http://www.starstandards.org/STAR}MaxPaymentToIncomePercentage" minOccurs="0"/&gt;
 *         &lt;element name="MinAmountPaidToDealer" type="{http://www.starstandards.org/STAR}MinAmountPaidToDealer" minOccurs="0"/&gt;
 *         &lt;element name="MaximumServiceContractAmount" type="{http://www.starstandards.org/STAR}MaximumServiceContractAmount" minOccurs="0"/&gt;
 *         &lt;element name="MaximumGapAmount" type="{http://www.starstandards.org/STAR}MaximumGapAmount" minOccurs="0"/&gt;
 *         &lt;element name="StatedIncomeGroup" type="{http://www.starstandards.org/STAR}StatedIncomeGroupType" minOccurs="0"/&gt;
 *         &lt;element name="Amortization" type="{http://www.starstandards.org/STAR}Amortization" minOccurs="0"/&gt;
 *         &lt;element name="CashDownPaymentAmount" type="{http://www.starstandards.org/STAR}CashDownPaymentAmount" minOccurs="0"/&gt;
 *         &lt;element name="ContractRate" type="{http://www.starstandards.org/STAR}ContractRate" minOccurs="0"/&gt;
 *         &lt;element name="FrontEndAdvanceAmount" type="{http://www.starstandards.org/STAR}FrontEndAdvanceAmount" minOccurs="0"/&gt;
 *         &lt;element name="FrontEndAdvancePercentage" type="{http://www.starstandards.org/STAR}FrontEndAdvancePercentage" minOccurs="0"/&gt;
 *         &lt;element name="MaxFrontEndAdvanceAmount" type="{http://www.starstandards.org/STAR}MaxFrontEndAdvanceAmount" minOccurs="0"/&gt;
 *         &lt;element name="MaxFrontEndAdvancePercentage" type="{http://www.starstandards.org/STAR}MaxFrontEndAdvancePercentage" minOccurs="0"/&gt;
 *         &lt;element name="MaxBackEndAmount" type="{http://www.starstandards.org/STAR}MaxBackEndAmount" minOccurs="0"/&gt;
 *         &lt;element name="MaxBackEndPercentage" type="{http://www.starstandards.org/STAR}MaxBackEndPercentage" minOccurs="0"/&gt;
 *         &lt;element name="TotalBackEndAmount" type="{http://www.starstandards.org/STAR}TotalBackEndAmount" minOccurs="0"/&gt;
 *         &lt;element name="MinimumCashDownAmount" type="{http://www.starstandards.org/STAR}MinimumCashDownAmount" minOccurs="0"/&gt;
 *         &lt;element name="ReplacementInsuranceAmount" type="{http://www.starstandards.org/STAR}ReplacementInsuranceAmount" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DecisionFinancing", propOrder = {
    "financeType",
    "paymentAmount",
    "balanceAmount",
    "finalAmount",
    "residualAmount",
    "term",
    "maturityDate",
    "financeCompanyName",
    "downPaymentAmount",
    "purchasePrice",
    "approvedInd",
    "approvedAmount",
    "expirationDate",
    "ratingIndex",
    "applicationType",
    "deferredDownPayment",
    "dealerRebateAmount",
    "manufacturerRebateAmount",
    "netTradeAmount",
    "insuranceTotalExtendedWarrantyAmount",
    "disabilityPremiumAmount",
    "creditLifePremiumAmount",
    "securityDepositAmount",
    "miscellaneousNotes",
    "annualPercentageRate",
    "msrpGuidePercentage",
    "tax",
    "totalContractAmount",
    "numberOfPayments",
    "firstPaymentDate",
    "offerStatusCode",
    "leaseRateMoneyFactor",
    "fee",
    "ficoScore",
    "netCapitalizedCostAmount",
    "preApprovedProgramName",
    "baseBuyPercentageRate",
    "buyPercentageRateAdjGroup",
    "buyPercentageRate",
    "maxTerm",
    "maxMonthlyPaymentAmount",
    "maxDebtToIncomePercentage",
    "maxUnpaidBalanceAmount",
    "minimumDownPaymentAmount",
    "downPaymentPercentage",
    "discountPercentage",
    "maxFinancedAmount",
    "participation",
    "reserveGroup",
    "minAnnualPercentageRate",
    "maxContractRate",
    "loanToValue",
    "financeProgramGroup",
    "maxPaymentToIncomePercentage",
    "minAmountPaidToDealer",
    "maximumServiceContractAmount",
    "maximumGapAmount",
    "statedIncomeGroup",
    "amortization",
    "cashDownPaymentAmount",
    "contractRate",
    "frontEndAdvanceAmount",
    "frontEndAdvancePercentage",
    "maxFrontEndAdvanceAmount",
    "maxFrontEndAdvancePercentage",
    "maxBackEndAmount",
    "maxBackEndPercentage",
    "totalBackEndAmount",
    "minimumCashDownAmount",
    "replacementInsuranceAmount"
})
public class DecisionFinancing {

    @XmlElement(name = "FinanceType")
    protected String financeType;
    @XmlElement(name = "PaymentAmount")
    protected DecisionFinancing.PaymentAmount paymentAmount;
    @XmlElement(name = "BalanceAmount")
    protected DecisionFinancing.BalanceAmount balanceAmount;
    @XmlElement(name = "FinalAmount")
    protected DecisionFinancing.FinalAmount finalAmount;
    @XmlElement(name = "ResidualAmount")
    protected DecisionFinancing.ResidualAmount residualAmount;
    @XmlElement(name = "Term")
    protected DecisionFinancing.Term term;
    @XmlElement(name = "MaturityDate")
    protected String maturityDate;
    @XmlElement(name = "FinanceCompanyName")
    protected String financeCompanyName;
    @XmlElement(name = "DownPaymentAmount")
    protected DecisionFinancing.DownPaymentAmount downPaymentAmount;
    @XmlElement(name = "PurchasePrice")
    protected DecisionFinancing.PurchasePrice purchasePrice;
    @XmlElement(name = "ApprovedInd")
    protected String approvedInd;
    @XmlElement(name = "ApprovedAmount")
    protected DecisionFinancing.ApprovedAmount approvedAmount;
    @XmlElement(name = "ExpirationDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar expirationDate;
    @XmlElement(name = "RatingIndex")
    protected String ratingIndex;
    @XmlElement(name = "ApplicationType")
    protected String applicationType;
    @XmlElement(name = "DeferredDownPayment")
    protected DecisionFinancing.DeferredDownPayment deferredDownPayment;
    @XmlElement(name = "DealerRebateAmount")
    protected DecisionFinancing.DealerRebateAmount dealerRebateAmount;
    @XmlElement(name = "ManufacturerRebateAmount")
    protected DecisionFinancing.ManufacturerRebateAmount manufacturerRebateAmount;
    @XmlElement(name = "NetTradeAmount")
    protected DecisionFinancing.NetTradeAmount netTradeAmount;
    @XmlElement(name = "InsuranceTotalExtendedWarrantyAmount")
    protected DecisionFinancing.InsuranceTotalExtendedWarrantyAmount insuranceTotalExtendedWarrantyAmount;
    @XmlElement(name = "DisabilityPremiumAmount")
    protected DecisionFinancing.DisabilityPremiumAmount disabilityPremiumAmount;
    @XmlElement(name = "CreditLifePremiumAmount")
    protected DecisionFinancing.CreditLifePremiumAmount creditLifePremiumAmount;
    @XmlElement(name = "SecurityDepositAmount")
    protected DecisionFinancing.SecurityDepositAmount securityDepositAmount;
    @XmlElement(name = "MiscellaneousNotes")
    protected String miscellaneousNotes;
    @XmlElement(name = "AnnualPercentageRate")
    protected DecisionFinancing.AnnualPercentageRate annualPercentageRate;
    @XmlElement(name = "MSRPGuidePercentage")
    protected DecisionFinancing.MSRPGuidePercentage msrpGuidePercentage;
    @XmlElement(name = "Tax")
    protected List<Tax> tax;
    @XmlElement(name = "TotalContractAmount")
    protected DecisionFinancing.TotalContractAmount totalContractAmount;
    @XmlElement(name = "NumberOfPayments")
    protected BigInteger numberOfPayments;
    @XmlElement(name = "FirstPaymentDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar firstPaymentDate;
    @XmlElement(name = "OfferStatusCode")
    protected String offerStatusCode;
    @XmlElement(name = "LeaseRateMoneyFactor")
    protected String leaseRateMoneyFactor;
    @XmlElement(name = "Fee")
    protected List<Fee> fee;
    @XmlElement(name = "FICOScore")
    protected String ficoScore;
    @XmlElement(name = "NetCapitalizedCostAmount")
    protected DecisionFinancing.NetCapitalizedCostAmount netCapitalizedCostAmount;
    @XmlElement(name = "PreApprovedProgramName")
    protected String preApprovedProgramName;
    @XmlElement(name = "BaseBuyPercentageRate")
    protected BigDecimal baseBuyPercentageRate;
    @XmlElement(name = "BuyPercentageRateAdjGroup")
    protected BuyPercentageRateAdjGroup buyPercentageRateAdjGroup;
    @XmlElement(name = "BuyPercentageRate")
    protected BuyPercentageRate buyPercentageRate;
    @XmlElement(name = "MaxTerm")
    protected Integer maxTerm;
    @XmlElement(name = "MaxMonthlyPaymentAmount")
    protected DecisionFinancing.MaxMonthlyPaymentAmount maxMonthlyPaymentAmount;
    @XmlElement(name = "MaxDebtToIncomePercentage")
    protected BigDecimal maxDebtToIncomePercentage;
    @XmlElement(name = "MaxUnpaidBalanceAmount")
    protected DecisionFinancing.MaxUnpaidBalanceAmount maxUnpaidBalanceAmount;
    @XmlElement(name = "MinimumDownPaymentAmount")
    protected DecisionFinancing.MinimumDownPaymentAmount minimumDownPaymentAmount;
    @XmlElement(name = "DownPaymentPercentage")
    protected DownpaymentPercentage downPaymentPercentage;
    @XmlElement(name = "DiscountPercentage")
    protected BigDecimal discountPercentage;
    @XmlElement(name = "MaxFinancedAmount")
    protected DecisionFinancing.MaxFinancedAmount maxFinancedAmount;
    @XmlElement(name = "Participation")
    protected ParticipationType participation;
    @XmlElement(name = "ReserveGroup")
    protected ReserveGroupType reserveGroup;
    @XmlElement(name = "MinAnnualPercentageRate")
    protected MinAnnualPercentageRate minAnnualPercentageRate;
    @XmlElement(name = "MaxContractRate")
    protected MaxContractRate maxContractRate;
    @XmlElement(name = "LoanToValue")
    protected LoanToValueType loanToValue;
    @XmlElement(name = "FinanceProgramGroup")
    protected FinanceProgramGroupType financeProgramGroup;
    @XmlElement(name = "MaxPaymentToIncomePercentage")
    protected MaxPaymentToIncomePercentage maxPaymentToIncomePercentage;
    @XmlElement(name = "MinAmountPaidToDealer")
    protected MinAmountPaidToDealer minAmountPaidToDealer;
    @XmlElement(name = "MaximumServiceContractAmount")
    protected MaximumServiceContractAmount maximumServiceContractAmount;
    @XmlElement(name = "MaximumGapAmount")
    protected MaximumGapAmount maximumGapAmount;
    @XmlElement(name = "StatedIncomeGroup")
    protected StatedIncomeGroupType statedIncomeGroup;
    @XmlElement(name = "Amortization")
    protected Amortization amortization;
    @XmlElement(name = "CashDownPaymentAmount")
    protected CashDownPaymentAmount cashDownPaymentAmount;
    @XmlElement(name = "ContractRate")
    protected ContractRate contractRate;
    @XmlElement(name = "FrontEndAdvanceAmount")
    protected FrontEndAdvanceAmount frontEndAdvanceAmount;
    @XmlElement(name = "FrontEndAdvancePercentage")
    protected FrontEndAdvancePercentage frontEndAdvancePercentage;
    @XmlElement(name = "MaxFrontEndAdvanceAmount")
    protected MaxFrontEndAdvanceAmount maxFrontEndAdvanceAmount;
    @XmlElement(name = "MaxFrontEndAdvancePercentage")
    protected MaxFrontEndAdvancePercentage maxFrontEndAdvancePercentage;
    @XmlElement(name = "MaxBackEndAmount")
    protected MaxBackEndAmount maxBackEndAmount;
    @XmlElement(name = "MaxBackEndPercentage")
    protected MaxBackEndPercentage maxBackEndPercentage;
    @XmlElement(name = "TotalBackEndAmount")
    protected TotalBackEndAmount totalBackEndAmount;
    @XmlElement(name = "MinimumCashDownAmount")
    protected MinimumCashDownAmount minimumCashDownAmount;
    @XmlElement(name = "ReplacementInsuranceAmount")
    protected ReplacementInsuranceAmount replacementInsuranceAmount;

    /**
     * Gets the value of the financeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinanceType() {
        return financeType;
    }

    /**
     * Sets the value of the financeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinanceType(String value) {
        this.financeType = value;
    }

    /**
     * Gets the value of the paymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.PaymentAmount }
     *     
     */
    public DecisionFinancing.PaymentAmount getPaymentAmount() {
        return paymentAmount;
    }

    /**
     * Sets the value of the paymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.PaymentAmount }
     *     
     */
    public void setPaymentAmount(DecisionFinancing.PaymentAmount value) {
        this.paymentAmount = value;
    }

    /**
     * Gets the value of the balanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.BalanceAmount }
     *     
     */
    public DecisionFinancing.BalanceAmount getBalanceAmount() {
        return balanceAmount;
    }

    /**
     * Sets the value of the balanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.BalanceAmount }
     *     
     */
    public void setBalanceAmount(DecisionFinancing.BalanceAmount value) {
        this.balanceAmount = value;
    }

    /**
     * Gets the value of the finalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.FinalAmount }
     *     
     */
    public DecisionFinancing.FinalAmount getFinalAmount() {
        return finalAmount;
    }

    /**
     * Sets the value of the finalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.FinalAmount }
     *     
     */
    public void setFinalAmount(DecisionFinancing.FinalAmount value) {
        this.finalAmount = value;
    }

    /**
     * Gets the value of the residualAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.ResidualAmount }
     *     
     */
    public DecisionFinancing.ResidualAmount getResidualAmount() {
        return residualAmount;
    }

    /**
     * Sets the value of the residualAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.ResidualAmount }
     *     
     */
    public void setResidualAmount(DecisionFinancing.ResidualAmount value) {
        this.residualAmount = value;
    }

    /**
     * Gets the value of the term property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.Term }
     *     
     */
    public DecisionFinancing.Term getTerm() {
        return term;
    }

    /**
     * Sets the value of the term property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.Term }
     *     
     */
    public void setTerm(DecisionFinancing.Term value) {
        this.term = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaturityDate(String value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the financeCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinanceCompanyName() {
        return financeCompanyName;
    }

    /**
     * Sets the value of the financeCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinanceCompanyName(String value) {
        this.financeCompanyName = value;
    }

    /**
     * Gets the value of the downPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.DownPaymentAmount }
     *     
     */
    public DecisionFinancing.DownPaymentAmount getDownPaymentAmount() {
        return downPaymentAmount;
    }

    /**
     * Sets the value of the downPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.DownPaymentAmount }
     *     
     */
    public void setDownPaymentAmount(DecisionFinancing.DownPaymentAmount value) {
        this.downPaymentAmount = value;
    }

    /**
     * Gets the value of the purchasePrice property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.PurchasePrice }
     *     
     */
    public DecisionFinancing.PurchasePrice getPurchasePrice() {
        return purchasePrice;
    }

    /**
     * Sets the value of the purchasePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.PurchasePrice }
     *     
     */
    public void setPurchasePrice(DecisionFinancing.PurchasePrice value) {
        this.purchasePrice = value;
    }

    /**
     * Gets the value of the approvedInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovedInd() {
        return approvedInd;
    }

    /**
     * Sets the value of the approvedInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovedInd(String value) {
        this.approvedInd = value;
    }

    /**
     * Gets the value of the approvedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.ApprovedAmount }
     *     
     */
    public DecisionFinancing.ApprovedAmount getApprovedAmount() {
        return approvedAmount;
    }

    /**
     * Sets the value of the approvedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.ApprovedAmount }
     *     
     */
    public void setApprovedAmount(DecisionFinancing.ApprovedAmount value) {
        this.approvedAmount = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpirationDate(XMLGregorianCalendar value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the ratingIndex property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRatingIndex() {
        return ratingIndex;
    }

    /**
     * Sets the value of the ratingIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRatingIndex(String value) {
        this.ratingIndex = value;
    }

    /**
     * Gets the value of the applicationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationType() {
        return applicationType;
    }

    /**
     * Sets the value of the applicationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationType(String value) {
        this.applicationType = value;
    }

    /**
     * Gets the value of the deferredDownPayment property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.DeferredDownPayment }
     *     
     */
    public DecisionFinancing.DeferredDownPayment getDeferredDownPayment() {
        return deferredDownPayment;
    }

    /**
     * Sets the value of the deferredDownPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.DeferredDownPayment }
     *     
     */
    public void setDeferredDownPayment(DecisionFinancing.DeferredDownPayment value) {
        this.deferredDownPayment = value;
    }

    /**
     * Gets the value of the dealerRebateAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.DealerRebateAmount }
     *     
     */
    public DecisionFinancing.DealerRebateAmount getDealerRebateAmount() {
        return dealerRebateAmount;
    }

    /**
     * Sets the value of the dealerRebateAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.DealerRebateAmount }
     *     
     */
    public void setDealerRebateAmount(DecisionFinancing.DealerRebateAmount value) {
        this.dealerRebateAmount = value;
    }

    /**
     * Gets the value of the manufacturerRebateAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.ManufacturerRebateAmount }
     *     
     */
    public DecisionFinancing.ManufacturerRebateAmount getManufacturerRebateAmount() {
        return manufacturerRebateAmount;
    }

    /**
     * Sets the value of the manufacturerRebateAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.ManufacturerRebateAmount }
     *     
     */
    public void setManufacturerRebateAmount(DecisionFinancing.ManufacturerRebateAmount value) {
        this.manufacturerRebateAmount = value;
    }

    /**
     * Gets the value of the netTradeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.NetTradeAmount }
     *     
     */
    public DecisionFinancing.NetTradeAmount getNetTradeAmount() {
        return netTradeAmount;
    }

    /**
     * Sets the value of the netTradeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.NetTradeAmount }
     *     
     */
    public void setNetTradeAmount(DecisionFinancing.NetTradeAmount value) {
        this.netTradeAmount = value;
    }

    /**
     * Gets the value of the insuranceTotalExtendedWarrantyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.InsuranceTotalExtendedWarrantyAmount }
     *     
     */
    public DecisionFinancing.InsuranceTotalExtendedWarrantyAmount getInsuranceTotalExtendedWarrantyAmount() {
        return insuranceTotalExtendedWarrantyAmount;
    }

    /**
     * Sets the value of the insuranceTotalExtendedWarrantyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.InsuranceTotalExtendedWarrantyAmount }
     *     
     */
    public void setInsuranceTotalExtendedWarrantyAmount(DecisionFinancing.InsuranceTotalExtendedWarrantyAmount value) {
        this.insuranceTotalExtendedWarrantyAmount = value;
    }

    /**
     * Gets the value of the disabilityPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.DisabilityPremiumAmount }
     *     
     */
    public DecisionFinancing.DisabilityPremiumAmount getDisabilityPremiumAmount() {
        return disabilityPremiumAmount;
    }

    /**
     * Sets the value of the disabilityPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.DisabilityPremiumAmount }
     *     
     */
    public void setDisabilityPremiumAmount(DecisionFinancing.DisabilityPremiumAmount value) {
        this.disabilityPremiumAmount = value;
    }

    /**
     * Gets the value of the creditLifePremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.CreditLifePremiumAmount }
     *     
     */
    public DecisionFinancing.CreditLifePremiumAmount getCreditLifePremiumAmount() {
        return creditLifePremiumAmount;
    }

    /**
     * Sets the value of the creditLifePremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.CreditLifePremiumAmount }
     *     
     */
    public void setCreditLifePremiumAmount(DecisionFinancing.CreditLifePremiumAmount value) {
        this.creditLifePremiumAmount = value;
    }

    /**
     * Gets the value of the securityDepositAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.SecurityDepositAmount }
     *     
     */
    public DecisionFinancing.SecurityDepositAmount getSecurityDepositAmount() {
        return securityDepositAmount;
    }

    /**
     * Sets the value of the securityDepositAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.SecurityDepositAmount }
     *     
     */
    public void setSecurityDepositAmount(DecisionFinancing.SecurityDepositAmount value) {
        this.securityDepositAmount = value;
    }

    /**
     * Gets the value of the miscellaneousNotes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiscellaneousNotes() {
        return miscellaneousNotes;
    }

    /**
     * Sets the value of the miscellaneousNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiscellaneousNotes(String value) {
        this.miscellaneousNotes = value;
    }

    /**
     * Gets the value of the annualPercentageRate property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.AnnualPercentageRate }
     *     
     */
    public DecisionFinancing.AnnualPercentageRate getAnnualPercentageRate() {
        return annualPercentageRate;
    }

    /**
     * Sets the value of the annualPercentageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.AnnualPercentageRate }
     *     
     */
    public void setAnnualPercentageRate(DecisionFinancing.AnnualPercentageRate value) {
        this.annualPercentageRate = value;
    }

    /**
     * Gets the value of the msrpGuidePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.MSRPGuidePercentage }
     *     
     */
    public DecisionFinancing.MSRPGuidePercentage getMSRPGuidePercentage() {
        return msrpGuidePercentage;
    }

    /**
     * Sets the value of the msrpGuidePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.MSRPGuidePercentage }
     *     
     */
    public void setMSRPGuidePercentage(DecisionFinancing.MSRPGuidePercentage value) {
        this.msrpGuidePercentage = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tax }
     * 
     * 
     */
    public List<Tax> getTax() {
        if (tax == null) {
            tax = new ArrayList<Tax>();
        }
        return this.tax;
    }

    /**
     * Gets the value of the totalContractAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.TotalContractAmount }
     *     
     */
    public DecisionFinancing.TotalContractAmount getTotalContractAmount() {
        return totalContractAmount;
    }

    /**
     * Sets the value of the totalContractAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.TotalContractAmount }
     *     
     */
    public void setTotalContractAmount(DecisionFinancing.TotalContractAmount value) {
        this.totalContractAmount = value;
    }

    /**
     * Gets the value of the numberOfPayments property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumberOfPayments() {
        return numberOfPayments;
    }

    /**
     * Sets the value of the numberOfPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumberOfPayments(BigInteger value) {
        this.numberOfPayments = value;
    }

    /**
     * Gets the value of the firstPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFirstPaymentDate() {
        return firstPaymentDate;
    }

    /**
     * Sets the value of the firstPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFirstPaymentDate(XMLGregorianCalendar value) {
        this.firstPaymentDate = value;
    }

    /**
     * Gets the value of the offerStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferStatusCode() {
        return offerStatusCode;
    }

    /**
     * Sets the value of the offerStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferStatusCode(String value) {
        this.offerStatusCode = value;
    }

    /**
     * Gets the value of the leaseRateMoneyFactor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeaseRateMoneyFactor() {
        return leaseRateMoneyFactor;
    }

    /**
     * Sets the value of the leaseRateMoneyFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeaseRateMoneyFactor(String value) {
        this.leaseRateMoneyFactor = value;
    }

    /**
     * Gets the value of the fee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Fee }
     * 
     * 
     */
    public List<Fee> getFee() {
        if (fee == null) {
            fee = new ArrayList<Fee>();
        }
        return this.fee;
    }

    /**
     * Gets the value of the ficoScore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFICOScore() {
        return ficoScore;
    }

    /**
     * Sets the value of the ficoScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFICOScore(String value) {
        this.ficoScore = value;
    }

    /**
     * Gets the value of the netCapitalizedCostAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.NetCapitalizedCostAmount }
     *     
     */
    public DecisionFinancing.NetCapitalizedCostAmount getNetCapitalizedCostAmount() {
        return netCapitalizedCostAmount;
    }

    /**
     * Sets the value of the netCapitalizedCostAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.NetCapitalizedCostAmount }
     *     
     */
    public void setNetCapitalizedCostAmount(DecisionFinancing.NetCapitalizedCostAmount value) {
        this.netCapitalizedCostAmount = value;
    }

    /**
     * Gets the value of the preApprovedProgramName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreApprovedProgramName() {
        return preApprovedProgramName;
    }

    /**
     * Sets the value of the preApprovedProgramName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreApprovedProgramName(String value) {
        this.preApprovedProgramName = value;
    }

    /**
     * Gets the value of the baseBuyPercentageRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBaseBuyPercentageRate() {
        return baseBuyPercentageRate;
    }

    /**
     * Sets the value of the baseBuyPercentageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBaseBuyPercentageRate(BigDecimal value) {
        this.baseBuyPercentageRate = value;
    }

    /**
     * Gets the value of the buyPercentageRateAdjGroup property.
     * 
     * @return
     *     possible object is
     *     {@link BuyPercentageRateAdjGroup }
     *     
     */
    public BuyPercentageRateAdjGroup getBuyPercentageRateAdjGroup() {
        return buyPercentageRateAdjGroup;
    }

    /**
     * Sets the value of the buyPercentageRateAdjGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link BuyPercentageRateAdjGroup }
     *     
     */
    public void setBuyPercentageRateAdjGroup(BuyPercentageRateAdjGroup value) {
        this.buyPercentageRateAdjGroup = value;
    }

    /**
     * Gets the value of the buyPercentageRate property.
     * 
     * @return
     *     possible object is
     *     {@link BuyPercentageRate }
     *     
     */
    public BuyPercentageRate getBuyPercentageRate() {
        return buyPercentageRate;
    }

    /**
     * Sets the value of the buyPercentageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BuyPercentageRate }
     *     
     */
    public void setBuyPercentageRate(BuyPercentageRate value) {
        this.buyPercentageRate = value;
    }

    /**
     * Gets the value of the maxTerm property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxTerm() {
        return maxTerm;
    }

    /**
     * Sets the value of the maxTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxTerm(Integer value) {
        this.maxTerm = value;
    }

    /**
     * Gets the value of the maxMonthlyPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.MaxMonthlyPaymentAmount }
     *     
     */
    public DecisionFinancing.MaxMonthlyPaymentAmount getMaxMonthlyPaymentAmount() {
        return maxMonthlyPaymentAmount;
    }

    /**
     * Sets the value of the maxMonthlyPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.MaxMonthlyPaymentAmount }
     *     
     */
    public void setMaxMonthlyPaymentAmount(DecisionFinancing.MaxMonthlyPaymentAmount value) {
        this.maxMonthlyPaymentAmount = value;
    }

    /**
     * Gets the value of the maxDebtToIncomePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaxDebtToIncomePercentage() {
        return maxDebtToIncomePercentage;
    }

    /**
     * Sets the value of the maxDebtToIncomePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaxDebtToIncomePercentage(BigDecimal value) {
        this.maxDebtToIncomePercentage = value;
    }

    /**
     * Gets the value of the maxUnpaidBalanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.MaxUnpaidBalanceAmount }
     *     
     */
    public DecisionFinancing.MaxUnpaidBalanceAmount getMaxUnpaidBalanceAmount() {
        return maxUnpaidBalanceAmount;
    }

    /**
     * Sets the value of the maxUnpaidBalanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.MaxUnpaidBalanceAmount }
     *     
     */
    public void setMaxUnpaidBalanceAmount(DecisionFinancing.MaxUnpaidBalanceAmount value) {
        this.maxUnpaidBalanceAmount = value;
    }

    /**
     * Gets the value of the minimumDownPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.MinimumDownPaymentAmount }
     *     
     */
    public DecisionFinancing.MinimumDownPaymentAmount getMinimumDownPaymentAmount() {
        return minimumDownPaymentAmount;
    }

    /**
     * Sets the value of the minimumDownPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.MinimumDownPaymentAmount }
     *     
     */
    public void setMinimumDownPaymentAmount(DecisionFinancing.MinimumDownPaymentAmount value) {
        this.minimumDownPaymentAmount = value;
    }

    /**
     * Gets the value of the downPaymentPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link DownpaymentPercentage }
     *     
     */
    public DownpaymentPercentage getDownPaymentPercentage() {
        return downPaymentPercentage;
    }

    /**
     * Sets the value of the downPaymentPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DownpaymentPercentage }
     *     
     */
    public void setDownPaymentPercentage(DownpaymentPercentage value) {
        this.downPaymentPercentage = value;
    }

    /**
     * Gets the value of the discountPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDiscountPercentage() {
        return discountPercentage;
    }

    /**
     * Sets the value of the discountPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDiscountPercentage(BigDecimal value) {
        this.discountPercentage = value;
    }

    /**
     * Gets the value of the maxFinancedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DecisionFinancing.MaxFinancedAmount }
     *     
     */
    public DecisionFinancing.MaxFinancedAmount getMaxFinancedAmount() {
        return maxFinancedAmount;
    }

    /**
     * Sets the value of the maxFinancedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DecisionFinancing.MaxFinancedAmount }
     *     
     */
    public void setMaxFinancedAmount(DecisionFinancing.MaxFinancedAmount value) {
        this.maxFinancedAmount = value;
    }

    /**
     * Gets the value of the participation property.
     * 
     * @return
     *     possible object is
     *     {@link ParticipationType }
     *     
     */
    public ParticipationType getParticipation() {
        return participation;
    }

    /**
     * Sets the value of the participation property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParticipationType }
     *     
     */
    public void setParticipation(ParticipationType value) {
        this.participation = value;
    }

    /**
     * Gets the value of the reserveGroup property.
     * 
     * @return
     *     possible object is
     *     {@link ReserveGroupType }
     *     
     */
    public ReserveGroupType getReserveGroup() {
        return reserveGroup;
    }

    /**
     * Sets the value of the reserveGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReserveGroupType }
     *     
     */
    public void setReserveGroup(ReserveGroupType value) {
        this.reserveGroup = value;
    }

    /**
     * Gets the value of the minAnnualPercentageRate property.
     * 
     * @return
     *     possible object is
     *     {@link MinAnnualPercentageRate }
     *     
     */
    public MinAnnualPercentageRate getMinAnnualPercentageRate() {
        return minAnnualPercentageRate;
    }

    /**
     * Sets the value of the minAnnualPercentageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinAnnualPercentageRate }
     *     
     */
    public void setMinAnnualPercentageRate(MinAnnualPercentageRate value) {
        this.minAnnualPercentageRate = value;
    }

    /**
     * Gets the value of the maxContractRate property.
     * 
     * @return
     *     possible object is
     *     {@link MaxContractRate }
     *     
     */
    public MaxContractRate getMaxContractRate() {
        return maxContractRate;
    }

    /**
     * Sets the value of the maxContractRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxContractRate }
     *     
     */
    public void setMaxContractRate(MaxContractRate value) {
        this.maxContractRate = value;
    }

    /**
     * Gets the value of the loanToValue property.
     * 
     * @return
     *     possible object is
     *     {@link LoanToValueType }
     *     
     */
    public LoanToValueType getLoanToValue() {
        return loanToValue;
    }

    /**
     * Sets the value of the loanToValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoanToValueType }
     *     
     */
    public void setLoanToValue(LoanToValueType value) {
        this.loanToValue = value;
    }

    /**
     * Gets the value of the financeProgramGroup property.
     * 
     * @return
     *     possible object is
     *     {@link FinanceProgramGroupType }
     *     
     */
    public FinanceProgramGroupType getFinanceProgramGroup() {
        return financeProgramGroup;
    }

    /**
     * Sets the value of the financeProgramGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinanceProgramGroupType }
     *     
     */
    public void setFinanceProgramGroup(FinanceProgramGroupType value) {
        this.financeProgramGroup = value;
    }

    /**
     * Gets the value of the maxPaymentToIncomePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link MaxPaymentToIncomePercentage }
     *     
     */
    public MaxPaymentToIncomePercentage getMaxPaymentToIncomePercentage() {
        return maxPaymentToIncomePercentage;
    }

    /**
     * Sets the value of the maxPaymentToIncomePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxPaymentToIncomePercentage }
     *     
     */
    public void setMaxPaymentToIncomePercentage(MaxPaymentToIncomePercentage value) {
        this.maxPaymentToIncomePercentage = value;
    }

    /**
     * Gets the value of the minAmountPaidToDealer property.
     * 
     * @return
     *     possible object is
     *     {@link MinAmountPaidToDealer }
     *     
     */
    public MinAmountPaidToDealer getMinAmountPaidToDealer() {
        return minAmountPaidToDealer;
    }

    /**
     * Sets the value of the minAmountPaidToDealer property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinAmountPaidToDealer }
     *     
     */
    public void setMinAmountPaidToDealer(MinAmountPaidToDealer value) {
        this.minAmountPaidToDealer = value;
    }

    /**
     * Gets the value of the maximumServiceContractAmount property.
     * 
     * @return
     *     possible object is
     *     {@link MaximumServiceContractAmount }
     *     
     */
    public MaximumServiceContractAmount getMaximumServiceContractAmount() {
        return maximumServiceContractAmount;
    }

    /**
     * Sets the value of the maximumServiceContractAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaximumServiceContractAmount }
     *     
     */
    public void setMaximumServiceContractAmount(MaximumServiceContractAmount value) {
        this.maximumServiceContractAmount = value;
    }

    /**
     * Gets the value of the maximumGapAmount property.
     * 
     * @return
     *     possible object is
     *     {@link MaximumGapAmount }
     *     
     */
    public MaximumGapAmount getMaximumGapAmount() {
        return maximumGapAmount;
    }

    /**
     * Sets the value of the maximumGapAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaximumGapAmount }
     *     
     */
    public void setMaximumGapAmount(MaximumGapAmount value) {
        this.maximumGapAmount = value;
    }

    /**
     * Gets the value of the statedIncomeGroup property.
     * 
     * @return
     *     possible object is
     *     {@link StatedIncomeGroupType }
     *     
     */
    public StatedIncomeGroupType getStatedIncomeGroup() {
        return statedIncomeGroup;
    }

    /**
     * Sets the value of the statedIncomeGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatedIncomeGroupType }
     *     
     */
    public void setStatedIncomeGroup(StatedIncomeGroupType value) {
        this.statedIncomeGroup = value;
    }

    /**
     * Gets the value of the amortization property.
     * 
     * @return
     *     possible object is
     *     {@link Amortization }
     *     
     */
    public Amortization getAmortization() {
        return amortization;
    }

    /**
     * Sets the value of the amortization property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amortization }
     *     
     */
    public void setAmortization(Amortization value) {
        this.amortization = value;
    }

    /**
     * Gets the value of the cashDownPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link CashDownPaymentAmount }
     *     
     */
    public CashDownPaymentAmount getCashDownPaymentAmount() {
        return cashDownPaymentAmount;
    }

    /**
     * Sets the value of the cashDownPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashDownPaymentAmount }
     *     
     */
    public void setCashDownPaymentAmount(CashDownPaymentAmount value) {
        this.cashDownPaymentAmount = value;
    }

    /**
     * Gets the value of the contractRate property.
     * 
     * @return
     *     possible object is
     *     {@link ContractRate }
     *     
     */
    public ContractRate getContractRate() {
        return contractRate;
    }

    /**
     * Sets the value of the contractRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContractRate }
     *     
     */
    public void setContractRate(ContractRate value) {
        this.contractRate = value;
    }

    /**
     * Gets the value of the frontEndAdvanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FrontEndAdvanceAmount }
     *     
     */
    public FrontEndAdvanceAmount getFrontEndAdvanceAmount() {
        return frontEndAdvanceAmount;
    }

    /**
     * Sets the value of the frontEndAdvanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FrontEndAdvanceAmount }
     *     
     */
    public void setFrontEndAdvanceAmount(FrontEndAdvanceAmount value) {
        this.frontEndAdvanceAmount = value;
    }

    /**
     * Gets the value of the frontEndAdvancePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link FrontEndAdvancePercentage }
     *     
     */
    public FrontEndAdvancePercentage getFrontEndAdvancePercentage() {
        return frontEndAdvancePercentage;
    }

    /**
     * Sets the value of the frontEndAdvancePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link FrontEndAdvancePercentage }
     *     
     */
    public void setFrontEndAdvancePercentage(FrontEndAdvancePercentage value) {
        this.frontEndAdvancePercentage = value;
    }

    /**
     * Gets the value of the maxFrontEndAdvanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link MaxFrontEndAdvanceAmount }
     *     
     */
    public MaxFrontEndAdvanceAmount getMaxFrontEndAdvanceAmount() {
        return maxFrontEndAdvanceAmount;
    }

    /**
     * Sets the value of the maxFrontEndAdvanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxFrontEndAdvanceAmount }
     *     
     */
    public void setMaxFrontEndAdvanceAmount(MaxFrontEndAdvanceAmount value) {
        this.maxFrontEndAdvanceAmount = value;
    }

    /**
     * Gets the value of the maxFrontEndAdvancePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link MaxFrontEndAdvancePercentage }
     *     
     */
    public MaxFrontEndAdvancePercentage getMaxFrontEndAdvancePercentage() {
        return maxFrontEndAdvancePercentage;
    }

    /**
     * Sets the value of the maxFrontEndAdvancePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxFrontEndAdvancePercentage }
     *     
     */
    public void setMaxFrontEndAdvancePercentage(MaxFrontEndAdvancePercentage value) {
        this.maxFrontEndAdvancePercentage = value;
    }

    /**
     * Gets the value of the maxBackEndAmount property.
     * 
     * @return
     *     possible object is
     *     {@link MaxBackEndAmount }
     *     
     */
    public MaxBackEndAmount getMaxBackEndAmount() {
        return maxBackEndAmount;
    }

    /**
     * Sets the value of the maxBackEndAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxBackEndAmount }
     *     
     */
    public void setMaxBackEndAmount(MaxBackEndAmount value) {
        this.maxBackEndAmount = value;
    }

    /**
     * Gets the value of the maxBackEndPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link MaxBackEndPercentage }
     *     
     */
    public MaxBackEndPercentage getMaxBackEndPercentage() {
        return maxBackEndPercentage;
    }

    /**
     * Sets the value of the maxBackEndPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxBackEndPercentage }
     *     
     */
    public void setMaxBackEndPercentage(MaxBackEndPercentage value) {
        this.maxBackEndPercentage = value;
    }

    /**
     * Gets the value of the totalBackEndAmount property.
     * 
     * @return
     *     possible object is
     *     {@link TotalBackEndAmount }
     *     
     */
    public TotalBackEndAmount getTotalBackEndAmount() {
        return totalBackEndAmount;
    }

    /**
     * Sets the value of the totalBackEndAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link TotalBackEndAmount }
     *     
     */
    public void setTotalBackEndAmount(TotalBackEndAmount value) {
        this.totalBackEndAmount = value;
    }

    /**
     * Gets the value of the minimumCashDownAmount property.
     * 
     * @return
     *     possible object is
     *     {@link MinimumCashDownAmount }
     *     
     */
    public MinimumCashDownAmount getMinimumCashDownAmount() {
        return minimumCashDownAmount;
    }

    /**
     * Sets the value of the minimumCashDownAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinimumCashDownAmount }
     *     
     */
    public void setMinimumCashDownAmount(MinimumCashDownAmount value) {
        this.minimumCashDownAmount = value;
    }

    /**
     * Gets the value of the replacementInsuranceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link ReplacementInsuranceAmount }
     *     
     */
    public ReplacementInsuranceAmount getReplacementInsuranceAmount() {
        return replacementInsuranceAmount;
    }

    /**
     * Sets the value of the replacementInsuranceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReplacementInsuranceAmount }
     *     
     */
    public void setReplacementInsuranceAmount(ReplacementInsuranceAmount value) {
        this.replacementInsuranceAmount = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class AnnualPercentageRate {

        @XmlValue
        protected BigDecimal value;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ApprovedAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BalanceAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CreditLifePremiumAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DealerRebateAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DeferredDownPayment {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DisabilityPremiumAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DownPaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FinalAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class InsuranceTotalExtendedWarrantyAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MSRPGuidePercentage {

        @XmlValue
        protected BigDecimal value;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ManufacturerRebateAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MaxFinancedAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MaxMonthlyPaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MaxUnpaidBalanceAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MinimumDownPaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class NetCapitalizedCostAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class NetTradeAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PurchasePrice {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ResidualAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class SecurityDepositAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
     *       &lt;attribute name="length" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class Term {

        @XmlValue
        protected BigInteger value;
        @XmlAttribute(name = "length", required = true)
        protected String length;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setValue(BigInteger value) {
            this.value = value;
        }

        /**
         * Gets the value of the length property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLength() {
            return length;
        }

        /**
         * Sets the value of the length property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLength(String value) {
            this.length = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class TotalContractAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
