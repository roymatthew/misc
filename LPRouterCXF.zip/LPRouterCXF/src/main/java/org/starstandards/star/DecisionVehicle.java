
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DecisionVehicle complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DecisionVehicle"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Model" type="{http://www.starstandards.org/STAR}Model"/&gt;
 *         &lt;element name="ModelYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ModelDescription" type="{http://www.starstandards.org/STAR}ModelDescription" minOccurs="0"/&gt;
 *         &lt;element name="Make" type="{http://www.starstandards.org/STAR}Make"/&gt;
 *         &lt;element name="BodyStyle" type="{http://www.starstandards.org/STAR}BodyStyle" minOccurs="0"/&gt;
 *         &lt;element name="DeliveryMileage" type="{http://www.starstandards.org/STAR}DeliveryMileage" minOccurs="0"/&gt;
 *         &lt;element name="MaximumMileage" type="{http://www.starstandards.org/STAR}MaximumMileage" minOccurs="0"/&gt;
 *         &lt;element name="Pricing" type="{http://www.starstandards.org/STAR}CreditVehiclePricing" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SaleClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleStock" type="{http://www.starstandards.org/STAR}VehicleStock" minOccurs="0"/&gt;
 *         &lt;element name="VIN" type="{http://www.starstandards.org/STAR}VIN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DecisionVehicle", propOrder = {
    "model",
    "modelYear",
    "modelDescription",
    "make",
    "bodyStyle",
    "deliveryMileage",
    "maximumMileage",
    "pricing",
    "saleClass",
    "vehicleStock",
    "vin"
})
public class DecisionVehicle {

    @XmlElement(name = "Model", required = true)
    protected String model;
    @XmlElement(name = "ModelYear")
    protected String modelYear;
    @XmlElement(name = "ModelDescription")
    protected String modelDescription;
    @XmlElement(name = "Make", required = true)
    protected String make;
    @XmlElement(name = "BodyStyle")
    protected String bodyStyle;
    @XmlElement(name = "DeliveryMileage")
    protected DeliveryMileage deliveryMileage;
    @XmlElement(name = "MaximumMileage")
    protected MaximumMileage maximumMileage;
    @XmlElement(name = "Pricing")
    protected List<CreditVehiclePricing> pricing;
    @XmlElement(name = "SaleClass")
    protected String saleClass;
    @XmlElement(name = "VehicleStock")
    protected String vehicleStock;
    @XmlElement(name = "VIN")
    protected String vin;

    /**
     * Gets the value of the model property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the value of the model property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModel(String value) {
        this.model = value;
    }

    /**
     * Gets the value of the modelYear property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the value of the modelYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelYear(String value) {
        this.modelYear = value;
    }

    /**
     * Gets the value of the modelDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelDescription() {
        return modelDescription;
    }

    /**
     * Sets the value of the modelDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelDescription(String value) {
        this.modelDescription = value;
    }

    /**
     * Gets the value of the make property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMake() {
        return make;
    }

    /**
     * Sets the value of the make property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMake(String value) {
        this.make = value;
    }

    /**
     * Gets the value of the bodyStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBodyStyle() {
        return bodyStyle;
    }

    /**
     * Sets the value of the bodyStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBodyStyle(String value) {
        this.bodyStyle = value;
    }

    /**
     * Gets the value of the deliveryMileage property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryMileage }
     *     
     */
    public DeliveryMileage getDeliveryMileage() {
        return deliveryMileage;
    }

    /**
     * Sets the value of the deliveryMileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryMileage }
     *     
     */
    public void setDeliveryMileage(DeliveryMileage value) {
        this.deliveryMileage = value;
    }

    /**
     * Gets the value of the maximumMileage property.
     * 
     * @return
     *     possible object is
     *     {@link MaximumMileage }
     *     
     */
    public MaximumMileage getMaximumMileage() {
        return maximumMileage;
    }

    /**
     * Sets the value of the maximumMileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaximumMileage }
     *     
     */
    public void setMaximumMileage(MaximumMileage value) {
        this.maximumMileage = value;
    }

    /**
     * Gets the value of the pricing property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pricing property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPricing().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditVehiclePricing }
     * 
     * 
     */
    public List<CreditVehiclePricing> getPricing() {
        if (pricing == null) {
            pricing = new ArrayList<CreditVehiclePricing>();
        }
        return this.pricing;
    }

    /**
     * Gets the value of the saleClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaleClass() {
        return saleClass;
    }

    /**
     * Sets the value of the saleClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaleClass(String value) {
        this.saleClass = value;
    }

    /**
     * Gets the value of the vehicleStock property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleStock() {
        return vehicleStock;
    }

    /**
     * Sets the value of the vehicleStock property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleStock(String value) {
        this.vehicleStock = value;
    }

    /**
     * Gets the value of the vin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * Sets the value of the vin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

}
