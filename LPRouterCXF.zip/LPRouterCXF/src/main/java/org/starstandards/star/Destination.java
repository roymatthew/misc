
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Destination complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Destination"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DestinationNameCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DestinationURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *         &lt;element name="DestinationSoftwareCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DestinationSoftware" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DealerNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="StoreNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AreaNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DealerCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Destination", propOrder = {
    "destinationNameCode",
    "destinationURI",
    "destinationSoftwareCode",
    "destinationSoftware",
    "dealerNumber",
    "storeNumber",
    "areaNumber",
    "dealerCountry"
})
public class Destination {

    @XmlElement(name = "DestinationNameCode")
    protected String destinationNameCode;
    @XmlElement(name = "DestinationURI")
    @XmlSchemaType(name = "anyURI")
    protected String destinationURI;
    @XmlElement(name = "DestinationSoftwareCode")
    protected String destinationSoftwareCode;
    @XmlElement(name = "DestinationSoftware")
    protected String destinationSoftware;
    @XmlElement(name = "DealerNumber")
    protected String dealerNumber;
    @XmlElement(name = "StoreNumber")
    protected String storeNumber;
    @XmlElement(name = "AreaNumber")
    protected String areaNumber;
    @XmlElement(name = "DealerCountry")
    protected String dealerCountry;

    /**
     * Gets the value of the destinationNameCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationNameCode() {
        return destinationNameCode;
    }

    /**
     * Sets the value of the destinationNameCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationNameCode(String value) {
        this.destinationNameCode = value;
    }

    /**
     * Gets the value of the destinationURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationURI() {
        return destinationURI;
    }

    /**
     * Sets the value of the destinationURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationURI(String value) {
        this.destinationURI = value;
    }

    /**
     * Gets the value of the destinationSoftwareCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationSoftwareCode() {
        return destinationSoftwareCode;
    }

    /**
     * Sets the value of the destinationSoftwareCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationSoftwareCode(String value) {
        this.destinationSoftwareCode = value;
    }

    /**
     * Gets the value of the destinationSoftware property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationSoftware() {
        return destinationSoftware;
    }

    /**
     * Sets the value of the destinationSoftware property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationSoftware(String value) {
        this.destinationSoftware = value;
    }

    /**
     * Gets the value of the dealerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerNumber() {
        return dealerNumber;
    }

    /**
     * Sets the value of the dealerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerNumber(String value) {
        this.dealerNumber = value;
    }

    /**
     * Gets the value of the storeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoreNumber() {
        return storeNumber;
    }

    /**
     * Sets the value of the storeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoreNumber(String value) {
        this.storeNumber = value;
    }

    /**
     * Gets the value of the areaNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaNumber() {
        return areaNumber;
    }

    /**
     * Sets the value of the areaNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaNumber(String value) {
        this.areaNumber = value;
    }

    /**
     * Gets the value of the dealerCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerCountry() {
        return dealerCountry;
    }

    /**
     * Sets the value of the dealerCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerCountry(String value) {
        this.dealerCountry = value;
    }

}
