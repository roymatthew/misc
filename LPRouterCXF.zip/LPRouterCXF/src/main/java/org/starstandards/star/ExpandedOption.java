
package org.starstandards.star;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for ExpandedOption complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExpandedOption"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OptionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OptionStockNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Manufacturer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OptionPrice" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OptionSecurityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ManufacturerInstalledInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="OptionCost" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OptionMSRP" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OptionOrigin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OptionSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ItemId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PartType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OptionNotes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DealerInstallationInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="MiscellaneousCode" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OptionPackageId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OptionSalesCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExpandedOption", propOrder = {
    "optionName",
    "optionStockNumber",
    "manufacturer",
    "optionPrice",
    "optionSecurityCode",
    "manufacturerInstalledInd",
    "optionCost",
    "optionMSRP",
    "optionOrigin",
    "optionSerialNumber",
    "itemId",
    "partType",
    "optionNotes",
    "dealerInstallationInd",
    "miscellaneousCode",
    "optionPackageId",
    "optionSalesCode"
})
public class ExpandedOption {

    @XmlElement(name = "OptionName")
    protected String optionName;
    @XmlElement(name = "OptionStockNumber")
    protected String optionStockNumber;
    @XmlElement(name = "Manufacturer")
    protected String manufacturer;
    @XmlElement(name = "OptionPrice")
    protected ExpandedOption.OptionPrice optionPrice;
    @XmlElement(name = "OptionSecurityCode")
    protected String optionSecurityCode;
    @XmlElement(name = "ManufacturerInstalledInd")
    protected String manufacturerInstalledInd;
    @XmlElement(name = "OptionCost")
    protected ExpandedOption.OptionCost optionCost;
    @XmlElement(name = "OptionMSRP")
    protected ExpandedOption.OptionMSRP optionMSRP;
    @XmlElement(name = "OptionOrigin")
    protected String optionOrigin;
    @XmlElement(name = "OptionSerialNumber")
    protected String optionSerialNumber;
    @XmlElement(name = "ItemId")
    protected String itemId;
    @XmlElement(name = "PartType")
    protected String partType;
    @XmlElement(name = "OptionNotes")
    protected String optionNotes;
    @XmlElement(name = "DealerInstallationInd")
    protected String dealerInstallationInd;
    @XmlElement(name = "MiscellaneousCode")
    protected List<String> miscellaneousCode;
    @XmlElement(name = "OptionPackageId")
    protected String optionPackageId;
    @XmlElement(name = "OptionSalesCode")
    protected String optionSalesCode;

    /**
     * Gets the value of the optionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionName() {
        return optionName;
    }

    /**
     * Sets the value of the optionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionName(String value) {
        this.optionName = value;
    }

    /**
     * Gets the value of the optionStockNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionStockNumber() {
        return optionStockNumber;
    }

    /**
     * Sets the value of the optionStockNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionStockNumber(String value) {
        this.optionStockNumber = value;
    }

    /**
     * Gets the value of the manufacturer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManufacturer() {
        return manufacturer;
    }

    /**
     * Sets the value of the manufacturer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManufacturer(String value) {
        this.manufacturer = value;
    }

    /**
     * Gets the value of the optionPrice property.
     * 
     * @return
     *     possible object is
     *     {@link ExpandedOption.OptionPrice }
     *     
     */
    public ExpandedOption.OptionPrice getOptionPrice() {
        return optionPrice;
    }

    /**
     * Sets the value of the optionPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpandedOption.OptionPrice }
     *     
     */
    public void setOptionPrice(ExpandedOption.OptionPrice value) {
        this.optionPrice = value;
    }

    /**
     * Gets the value of the optionSecurityCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionSecurityCode() {
        return optionSecurityCode;
    }

    /**
     * Sets the value of the optionSecurityCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionSecurityCode(String value) {
        this.optionSecurityCode = value;
    }

    /**
     * Gets the value of the manufacturerInstalledInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManufacturerInstalledInd() {
        return manufacturerInstalledInd;
    }

    /**
     * Sets the value of the manufacturerInstalledInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManufacturerInstalledInd(String value) {
        this.manufacturerInstalledInd = value;
    }

    /**
     * Gets the value of the optionCost property.
     * 
     * @return
     *     possible object is
     *     {@link ExpandedOption.OptionCost }
     *     
     */
    public ExpandedOption.OptionCost getOptionCost() {
        return optionCost;
    }

    /**
     * Sets the value of the optionCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpandedOption.OptionCost }
     *     
     */
    public void setOptionCost(ExpandedOption.OptionCost value) {
        this.optionCost = value;
    }

    /**
     * Gets the value of the optionMSRP property.
     * 
     * @return
     *     possible object is
     *     {@link ExpandedOption.OptionMSRP }
     *     
     */
    public ExpandedOption.OptionMSRP getOptionMSRP() {
        return optionMSRP;
    }

    /**
     * Sets the value of the optionMSRP property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpandedOption.OptionMSRP }
     *     
     */
    public void setOptionMSRP(ExpandedOption.OptionMSRP value) {
        this.optionMSRP = value;
    }

    /**
     * Gets the value of the optionOrigin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionOrigin() {
        return optionOrigin;
    }

    /**
     * Sets the value of the optionOrigin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionOrigin(String value) {
        this.optionOrigin = value;
    }

    /**
     * Gets the value of the optionSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionSerialNumber() {
        return optionSerialNumber;
    }

    /**
     * Sets the value of the optionSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionSerialNumber(String value) {
        this.optionSerialNumber = value;
    }

    /**
     * Gets the value of the itemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemId(String value) {
        this.itemId = value;
    }

    /**
     * Gets the value of the partType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartType() {
        return partType;
    }

    /**
     * Sets the value of the partType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartType(String value) {
        this.partType = value;
    }

    /**
     * Gets the value of the optionNotes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionNotes() {
        return optionNotes;
    }

    /**
     * Sets the value of the optionNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionNotes(String value) {
        this.optionNotes = value;
    }

    /**
     * Gets the value of the dealerInstallationInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerInstallationInd() {
        return dealerInstallationInd;
    }

    /**
     * Sets the value of the dealerInstallationInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerInstallationInd(String value) {
        this.dealerInstallationInd = value;
    }

    /**
     * Gets the value of the miscellaneousCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miscellaneousCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiscellaneousCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMiscellaneousCode() {
        if (miscellaneousCode == null) {
            miscellaneousCode = new ArrayList<String>();
        }
        return this.miscellaneousCode;
    }

    /**
     * Gets the value of the optionPackageId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionPackageId() {
        return optionPackageId;
    }

    /**
     * Sets the value of the optionPackageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionPackageId(String value) {
        this.optionPackageId = value;
    }

    /**
     * Gets the value of the optionSalesCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionSalesCode() {
        return optionSalesCode;
    }

    /**
     * Sets the value of the optionSalesCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionSalesCode(String value) {
        this.optionSalesCode = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class OptionCost {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency")
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class OptionMSRP {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency")
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class OptionPrice {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency")
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
