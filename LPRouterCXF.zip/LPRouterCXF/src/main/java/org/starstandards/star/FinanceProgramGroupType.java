
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The FinanceProgramGroup component represents information related to the finance source approved programs.
 * 
 * <p>Java class for FinanceProgramGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinanceProgramGroupType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FinanceProgram" type="{http://www.starstandards.org/STAR}FinanceProgramType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinanceProgramGroupType", propOrder = {
    "financeProgram"
})
public class FinanceProgramGroupType {

    @XmlElement(name = "FinanceProgram", required = true)
    protected List<FinanceProgramType> financeProgram;

    /**
     * Gets the value of the financeProgram property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the financeProgram property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFinanceProgram().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FinanceProgramType }
     * 
     * 
     */
    public List<FinanceProgramType> getFinanceProgram() {
        if (financeProgram == null) {
            financeProgram = new ArrayList<FinanceProgramType>();
        }
        return this.financeProgram;
    }

}
