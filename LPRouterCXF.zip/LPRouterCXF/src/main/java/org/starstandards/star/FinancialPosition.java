
package org.starstandards.star;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for FinancialPosition complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialPosition"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CurrentAssetsAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IntangibleAssetsAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FixedAssetsAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TotalAssetsAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CurrentLiabilitiesAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LongTermDirectLiabilitiesAmt" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TotalLiabilitiesAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CapitalAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EarnedSurplusAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AnnualSalesAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="GrossProfitAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NetProfitAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WorkingCapitalAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TotalNetWorthAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebtNetWorthRatio" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="CurrentAssetsLiabilitiesRatio" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialPosition", propOrder = {
    "currentAssetsAmount",
    "intangibleAssetsAmount",
    "fixedAssetsAmount",
    "totalAssetsAmount",
    "currentLiabilitiesAmount",
    "longTermDirectLiabilitiesAmt",
    "totalLiabilitiesAmount",
    "capitalAmount",
    "earnedSurplusAmount",
    "annualSalesAmount",
    "grossProfitAmount",
    "netProfitAmount",
    "workingCapitalAmount",
    "totalNetWorthAmount",
    "debtNetWorthRatio",
    "currentAssetsLiabilitiesRatio"
})
public class FinancialPosition {

    @XmlElement(name = "CurrentAssetsAmount")
    protected FinancialPosition.CurrentAssetsAmount currentAssetsAmount;
    @XmlElement(name = "IntangibleAssetsAmount")
    protected FinancialPosition.IntangibleAssetsAmount intangibleAssetsAmount;
    @XmlElement(name = "FixedAssetsAmount")
    protected FinancialPosition.FixedAssetsAmount fixedAssetsAmount;
    @XmlElement(name = "TotalAssetsAmount")
    protected FinancialPosition.TotalAssetsAmount totalAssetsAmount;
    @XmlElement(name = "CurrentLiabilitiesAmount")
    protected FinancialPosition.CurrentLiabilitiesAmount currentLiabilitiesAmount;
    @XmlElement(name = "LongTermDirectLiabilitiesAmt")
    protected FinancialPosition.LongTermDirectLiabilitiesAmt longTermDirectLiabilitiesAmt;
    @XmlElement(name = "TotalLiabilitiesAmount")
    protected FinancialPosition.TotalLiabilitiesAmount totalLiabilitiesAmount;
    @XmlElement(name = "CapitalAmount")
    protected FinancialPosition.CapitalAmount capitalAmount;
    @XmlElement(name = "EarnedSurplusAmount")
    protected FinancialPosition.EarnedSurplusAmount earnedSurplusAmount;
    @XmlElement(name = "AnnualSalesAmount")
    protected FinancialPosition.AnnualSalesAmount annualSalesAmount;
    @XmlElement(name = "GrossProfitAmount")
    protected FinancialPosition.GrossProfitAmount grossProfitAmount;
    @XmlElement(name = "NetProfitAmount")
    protected FinancialPosition.NetProfitAmount netProfitAmount;
    @XmlElement(name = "WorkingCapitalAmount")
    protected FinancialPosition.WorkingCapitalAmount workingCapitalAmount;
    @XmlElement(name = "TotalNetWorthAmount")
    protected FinancialPosition.TotalNetWorthAmount totalNetWorthAmount;
    @XmlElement(name = "DebtNetWorthRatio")
    protected BigDecimal debtNetWorthRatio;
    @XmlElement(name = "CurrentAssetsLiabilitiesRatio")
    protected BigDecimal currentAssetsLiabilitiesRatio;

    /**
     * Gets the value of the currentAssetsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.CurrentAssetsAmount }
     *     
     */
    public FinancialPosition.CurrentAssetsAmount getCurrentAssetsAmount() {
        return currentAssetsAmount;
    }

    /**
     * Sets the value of the currentAssetsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.CurrentAssetsAmount }
     *     
     */
    public void setCurrentAssetsAmount(FinancialPosition.CurrentAssetsAmount value) {
        this.currentAssetsAmount = value;
    }

    /**
     * Gets the value of the intangibleAssetsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.IntangibleAssetsAmount }
     *     
     */
    public FinancialPosition.IntangibleAssetsAmount getIntangibleAssetsAmount() {
        return intangibleAssetsAmount;
    }

    /**
     * Sets the value of the intangibleAssetsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.IntangibleAssetsAmount }
     *     
     */
    public void setIntangibleAssetsAmount(FinancialPosition.IntangibleAssetsAmount value) {
        this.intangibleAssetsAmount = value;
    }

    /**
     * Gets the value of the fixedAssetsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.FixedAssetsAmount }
     *     
     */
    public FinancialPosition.FixedAssetsAmount getFixedAssetsAmount() {
        return fixedAssetsAmount;
    }

    /**
     * Sets the value of the fixedAssetsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.FixedAssetsAmount }
     *     
     */
    public void setFixedAssetsAmount(FinancialPosition.FixedAssetsAmount value) {
        this.fixedAssetsAmount = value;
    }

    /**
     * Gets the value of the totalAssetsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.TotalAssetsAmount }
     *     
     */
    public FinancialPosition.TotalAssetsAmount getTotalAssetsAmount() {
        return totalAssetsAmount;
    }

    /**
     * Sets the value of the totalAssetsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.TotalAssetsAmount }
     *     
     */
    public void setTotalAssetsAmount(FinancialPosition.TotalAssetsAmount value) {
        this.totalAssetsAmount = value;
    }

    /**
     * Gets the value of the currentLiabilitiesAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.CurrentLiabilitiesAmount }
     *     
     */
    public FinancialPosition.CurrentLiabilitiesAmount getCurrentLiabilitiesAmount() {
        return currentLiabilitiesAmount;
    }

    /**
     * Sets the value of the currentLiabilitiesAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.CurrentLiabilitiesAmount }
     *     
     */
    public void setCurrentLiabilitiesAmount(FinancialPosition.CurrentLiabilitiesAmount value) {
        this.currentLiabilitiesAmount = value;
    }

    /**
     * Gets the value of the longTermDirectLiabilitiesAmt property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.LongTermDirectLiabilitiesAmt }
     *     
     */
    public FinancialPosition.LongTermDirectLiabilitiesAmt getLongTermDirectLiabilitiesAmt() {
        return longTermDirectLiabilitiesAmt;
    }

    /**
     * Sets the value of the longTermDirectLiabilitiesAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.LongTermDirectLiabilitiesAmt }
     *     
     */
    public void setLongTermDirectLiabilitiesAmt(FinancialPosition.LongTermDirectLiabilitiesAmt value) {
        this.longTermDirectLiabilitiesAmt = value;
    }

    /**
     * Gets the value of the totalLiabilitiesAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.TotalLiabilitiesAmount }
     *     
     */
    public FinancialPosition.TotalLiabilitiesAmount getTotalLiabilitiesAmount() {
        return totalLiabilitiesAmount;
    }

    /**
     * Sets the value of the totalLiabilitiesAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.TotalLiabilitiesAmount }
     *     
     */
    public void setTotalLiabilitiesAmount(FinancialPosition.TotalLiabilitiesAmount value) {
        this.totalLiabilitiesAmount = value;
    }

    /**
     * Gets the value of the capitalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.CapitalAmount }
     *     
     */
    public FinancialPosition.CapitalAmount getCapitalAmount() {
        return capitalAmount;
    }

    /**
     * Sets the value of the capitalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.CapitalAmount }
     *     
     */
    public void setCapitalAmount(FinancialPosition.CapitalAmount value) {
        this.capitalAmount = value;
    }

    /**
     * Gets the value of the earnedSurplusAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.EarnedSurplusAmount }
     *     
     */
    public FinancialPosition.EarnedSurplusAmount getEarnedSurplusAmount() {
        return earnedSurplusAmount;
    }

    /**
     * Sets the value of the earnedSurplusAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.EarnedSurplusAmount }
     *     
     */
    public void setEarnedSurplusAmount(FinancialPosition.EarnedSurplusAmount value) {
        this.earnedSurplusAmount = value;
    }

    /**
     * Gets the value of the annualSalesAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.AnnualSalesAmount }
     *     
     */
    public FinancialPosition.AnnualSalesAmount getAnnualSalesAmount() {
        return annualSalesAmount;
    }

    /**
     * Sets the value of the annualSalesAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.AnnualSalesAmount }
     *     
     */
    public void setAnnualSalesAmount(FinancialPosition.AnnualSalesAmount value) {
        this.annualSalesAmount = value;
    }

    /**
     * Gets the value of the grossProfitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.GrossProfitAmount }
     *     
     */
    public FinancialPosition.GrossProfitAmount getGrossProfitAmount() {
        return grossProfitAmount;
    }

    /**
     * Sets the value of the grossProfitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.GrossProfitAmount }
     *     
     */
    public void setGrossProfitAmount(FinancialPosition.GrossProfitAmount value) {
        this.grossProfitAmount = value;
    }

    /**
     * Gets the value of the netProfitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.NetProfitAmount }
     *     
     */
    public FinancialPosition.NetProfitAmount getNetProfitAmount() {
        return netProfitAmount;
    }

    /**
     * Sets the value of the netProfitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.NetProfitAmount }
     *     
     */
    public void setNetProfitAmount(FinancialPosition.NetProfitAmount value) {
        this.netProfitAmount = value;
    }

    /**
     * Gets the value of the workingCapitalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.WorkingCapitalAmount }
     *     
     */
    public FinancialPosition.WorkingCapitalAmount getWorkingCapitalAmount() {
        return workingCapitalAmount;
    }

    /**
     * Sets the value of the workingCapitalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.WorkingCapitalAmount }
     *     
     */
    public void setWorkingCapitalAmount(FinancialPosition.WorkingCapitalAmount value) {
        this.workingCapitalAmount = value;
    }

    /**
     * Gets the value of the totalNetWorthAmount property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition.TotalNetWorthAmount }
     *     
     */
    public FinancialPosition.TotalNetWorthAmount getTotalNetWorthAmount() {
        return totalNetWorthAmount;
    }

    /**
     * Sets the value of the totalNetWorthAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition.TotalNetWorthAmount }
     *     
     */
    public void setTotalNetWorthAmount(FinancialPosition.TotalNetWorthAmount value) {
        this.totalNetWorthAmount = value;
    }

    /**
     * Gets the value of the debtNetWorthRatio property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDebtNetWorthRatio() {
        return debtNetWorthRatio;
    }

    /**
     * Sets the value of the debtNetWorthRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDebtNetWorthRatio(BigDecimal value) {
        this.debtNetWorthRatio = value;
    }

    /**
     * Gets the value of the currentAssetsLiabilitiesRatio property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentAssetsLiabilitiesRatio() {
        return currentAssetsLiabilitiesRatio;
    }

    /**
     * Sets the value of the currentAssetsLiabilitiesRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentAssetsLiabilitiesRatio(BigDecimal value) {
        this.currentAssetsLiabilitiesRatio = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class AnnualSalesAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CapitalAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CurrentAssetsAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CurrentLiabilitiesAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class EarnedSurplusAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FixedAssetsAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class GrossProfitAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class IntangibleAssetsAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class LongTermDirectLiabilitiesAmt {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class NetProfitAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class TotalAssetsAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class TotalLiabilitiesAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class TotalNetWorthAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class WorkingCapitalAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
