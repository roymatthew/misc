
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * This is a reduction of the Holdback Reserve set aside by the Finance Source in the Dealer's Reserve Account, used when the Dealer chooses to write the contract at an APR higher than the buy rate in the decision.
 * 
 * <p>Java class for HoldbackCreditAmount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HoldbackCreditAmount"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.starstandards.org/STAR&gt;Amount"&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HoldbackCreditAmount")
public class HoldbackCreditAmount
    extends Amount
{


}
