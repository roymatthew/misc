
package org.starstandards.star;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for IndividualApplicantPartyExtended complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IndividualApplicantPartyExtended"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="AlternatePartyIds" type="{http://www.starstandards.org/STAR}IndividualPartyAlternatePartyId" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PersonName" type="{http://www.starstandards.org/STAR}IndividualApplicantPersonName" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.starstandards.org/STAR}IndividualApplicantAddress" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Contact" type="{http://www.starstandards.org/STAR}IndividualApplicantContact" minOccurs="0"/&gt;
 *         &lt;element name="RelationshipCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RelationshipDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Demographics" type="{http://www.starstandards.org/STAR}ApplicantDemographics" minOccurs="0"/&gt;
 *         &lt;element name="MarketingMailInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="Employer" type="{http://www.starstandards.org/STAR}EmployerParty" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="NearestRelative" type="{http://www.starstandards.org/STAR}NearestRelative" minOccurs="0"/&gt;
 *         &lt;element name="Bank" type="{http://www.starstandards.org/STAR}Bank" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Co-Creditor" type="{http://www.starstandards.org/STAR}Co-Creditor" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BankruptcyRepossession" type="{http://www.starstandards.org/STAR}BankruptcyRepossession" minOccurs="0"/&gt;
 *         &lt;element name="MfgDealerInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="PrimaryDriverInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="PaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MortgageBalance" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OtherIncome" type="{http://www.starstandards.org/STAR}OtherIncome" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Privacy" type="{http://www.starstandards.org/STAR}Privacy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EstimatedUsage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="CreditReportInformation" type="{http://www.starstandards.org/STAR}CreditReportInformation" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IndividualApplicantPartyExtended", propOrder = {
    "partyId",
    "alternatePartyIds",
    "personName",
    "address",
    "contact",
    "relationshipCode",
    "relationshipDescription",
    "demographics",
    "marketingMailInd",
    "employer",
    "nearestRelative",
    "bank",
    "coCreditor",
    "bankruptcyRepossession",
    "mfgDealerInd",
    "primaryDriverInd",
    "paymentAmount",
    "mortgageBalance",
    "otherIncome",
    "privacy",
    "estimatedUsage",
    "creditReportInformation"
})
public class IndividualApplicantPartyExtended {

    @XmlElement(name = "PartyId", required = true)
    protected String partyId;
    @XmlElement(name = "AlternatePartyIds")
    protected List<IndividualPartyAlternatePartyId> alternatePartyIds;
    @XmlElement(name = "PersonName")
    protected IndividualApplicantPersonName personName;
    @XmlElement(name = "Address")
    protected List<IndividualApplicantAddress> address;
    @XmlElement(name = "Contact")
    protected IndividualApplicantContact contact;
    @XmlElement(name = "RelationshipCode")
    protected String relationshipCode;
    @XmlElement(name = "RelationshipDescription")
    protected String relationshipDescription;
    @XmlElement(name = "Demographics")
    protected ApplicantDemographics demographics;
    @XmlElement(name = "MarketingMailInd")
    protected String marketingMailInd;
    @XmlElement(name = "Employer")
    protected List<EmployerParty> employer;
    @XmlElement(name = "NearestRelative")
    protected NearestRelative nearestRelative;
    @XmlElement(name = "Bank")
    protected List<Bank> bank;
    @XmlElement(name = "Co-Creditor")
    protected List<CoCreditor> coCreditor;
    @XmlElement(name = "BankruptcyRepossession")
    protected BankruptcyRepossession bankruptcyRepossession;
    @XmlElement(name = "MfgDealerInd")
    protected String mfgDealerInd;
    @XmlElement(name = "PrimaryDriverInd")
    protected String primaryDriverInd;
    @XmlElement(name = "PaymentAmount")
    protected IndividualApplicantPartyExtended.PaymentAmount paymentAmount;
    @XmlElement(name = "MortgageBalance")
    protected IndividualApplicantPartyExtended.MortgageBalance mortgageBalance;
    @XmlElement(name = "OtherIncome")
    protected List<OtherIncome> otherIncome;
    @XmlElement(name = "Privacy")
    protected List<Privacy> privacy;
    @XmlElement(name = "EstimatedUsage")
    protected BigDecimal estimatedUsage;
    @XmlElement(name = "CreditReportInformation")
    protected List<CreditReportInformation> creditReportInformation;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the alternatePartyIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternatePartyIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternatePartyIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IndividualPartyAlternatePartyId }
     * 
     * 
     */
    public List<IndividualPartyAlternatePartyId> getAlternatePartyIds() {
        if (alternatePartyIds == null) {
            alternatePartyIds = new ArrayList<IndividualPartyAlternatePartyId>();
        }
        return this.alternatePartyIds;
    }

    /**
     * Gets the value of the personName property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantPersonName }
     *     
     */
    public IndividualApplicantPersonName getPersonName() {
        return personName;
    }

    /**
     * Sets the value of the personName property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantPersonName }
     *     
     */
    public void setPersonName(IndividualApplicantPersonName value) {
        this.personName = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IndividualApplicantAddress }
     * 
     * 
     */
    public List<IndividualApplicantAddress> getAddress() {
        if (address == null) {
            address = new ArrayList<IndividualApplicantAddress>();
        }
        return this.address;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantContact }
     *     
     */
    public IndividualApplicantContact getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantContact }
     *     
     */
    public void setContact(IndividualApplicantContact value) {
        this.contact = value;
    }

    /**
     * Gets the value of the relationshipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * Sets the value of the relationshipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipCode(String value) {
        this.relationshipCode = value;
    }

    /**
     * Gets the value of the relationshipDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipDescription() {
        return relationshipDescription;
    }

    /**
     * Sets the value of the relationshipDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipDescription(String value) {
        this.relationshipDescription = value;
    }

    /**
     * Gets the value of the demographics property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicantDemographics }
     *     
     */
    public ApplicantDemographics getDemographics() {
        return demographics;
    }

    /**
     * Sets the value of the demographics property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicantDemographics }
     *     
     */
    public void setDemographics(ApplicantDemographics value) {
        this.demographics = value;
    }

    /**
     * Gets the value of the marketingMailInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingMailInd() {
        return marketingMailInd;
    }

    /**
     * Sets the value of the marketingMailInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingMailInd(String value) {
        this.marketingMailInd = value;
    }

    /**
     * Gets the value of the employer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the employer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmployer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmployerParty }
     * 
     * 
     */
    public List<EmployerParty> getEmployer() {
        if (employer == null) {
            employer = new ArrayList<EmployerParty>();
        }
        return this.employer;
    }

    /**
     * Gets the value of the nearestRelative property.
     * 
     * @return
     *     possible object is
     *     {@link NearestRelative }
     *     
     */
    public NearestRelative getNearestRelative() {
        return nearestRelative;
    }

    /**
     * Sets the value of the nearestRelative property.
     * 
     * @param value
     *     allowed object is
     *     {@link NearestRelative }
     *     
     */
    public void setNearestRelative(NearestRelative value) {
        this.nearestRelative = value;
    }

    /**
     * Gets the value of the bank property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bank property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBank().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Bank }
     * 
     * 
     */
    public List<Bank> getBank() {
        if (bank == null) {
            bank = new ArrayList<Bank>();
        }
        return this.bank;
    }

    /**
     * Gets the value of the coCreditor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coCreditor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoCreditor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoCreditor }
     * 
     * 
     */
    public List<CoCreditor> getCoCreditor() {
        if (coCreditor == null) {
            coCreditor = new ArrayList<CoCreditor>();
        }
        return this.coCreditor;
    }

    /**
     * Gets the value of the bankruptcyRepossession property.
     * 
     * @return
     *     possible object is
     *     {@link BankruptcyRepossession }
     *     
     */
    public BankruptcyRepossession getBankruptcyRepossession() {
        return bankruptcyRepossession;
    }

    /**
     * Sets the value of the bankruptcyRepossession property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankruptcyRepossession }
     *     
     */
    public void setBankruptcyRepossession(BankruptcyRepossession value) {
        this.bankruptcyRepossession = value;
    }

    /**
     * Gets the value of the mfgDealerInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgDealerInd() {
        return mfgDealerInd;
    }

    /**
     * Sets the value of the mfgDealerInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgDealerInd(String value) {
        this.mfgDealerInd = value;
    }

    /**
     * Gets the value of the primaryDriverInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryDriverInd() {
        return primaryDriverInd;
    }

    /**
     * Sets the value of the primaryDriverInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryDriverInd(String value) {
        this.primaryDriverInd = value;
    }

    /**
     * Gets the value of the paymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantPartyExtended.PaymentAmount }
     *     
     */
    public IndividualApplicantPartyExtended.PaymentAmount getPaymentAmount() {
        return paymentAmount;
    }

    /**
     * Sets the value of the paymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantPartyExtended.PaymentAmount }
     *     
     */
    public void setPaymentAmount(IndividualApplicantPartyExtended.PaymentAmount value) {
        this.paymentAmount = value;
    }

    /**
     * Gets the value of the mortgageBalance property.
     * 
     * @return
     *     possible object is
     *     {@link IndividualApplicantPartyExtended.MortgageBalance }
     *     
     */
    public IndividualApplicantPartyExtended.MortgageBalance getMortgageBalance() {
        return mortgageBalance;
    }

    /**
     * Sets the value of the mortgageBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualApplicantPartyExtended.MortgageBalance }
     *     
     */
    public void setMortgageBalance(IndividualApplicantPartyExtended.MortgageBalance value) {
        this.mortgageBalance = value;
    }

    /**
     * Gets the value of the otherIncome property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the otherIncome property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOtherIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OtherIncome }
     * 
     * 
     */
    public List<OtherIncome> getOtherIncome() {
        if (otherIncome == null) {
            otherIncome = new ArrayList<OtherIncome>();
        }
        return this.otherIncome;
    }

    /**
     * Gets the value of the privacy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the privacy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrivacy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Privacy }
     * 
     * 
     */
    public List<Privacy> getPrivacy() {
        if (privacy == null) {
            privacy = new ArrayList<Privacy>();
        }
        return this.privacy;
    }

    /**
     * Gets the value of the estimatedUsage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEstimatedUsage() {
        return estimatedUsage;
    }

    /**
     * Sets the value of the estimatedUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEstimatedUsage(BigDecimal value) {
        this.estimatedUsage = value;
    }

    /**
     * Gets the value of the creditReportInformation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditReportInformation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditReportInformation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditReportInformation }
     * 
     * 
     */
    public List<CreditReportInformation> getCreditReportInformation() {
        if (creditReportInformation == null) {
            creditReportInformation = new ArrayList<CreditReportInformation>();
        }
        return this.creditReportInformation;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MortgageBalance {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
