
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The LoanToValue component represents information related to the loan to value percentages and loan to value amounts.
 * 
 * <p>Java class for LoanToValueType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanToValueType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LTVPercentage" type="{http://www.starstandards.org/STAR}LTVPercentage" minOccurs="0"/&gt;
 *         &lt;element name="LTVAmount" type="{http://www.starstandards.org/STAR}LTVAmount" minOccurs="0"/&gt;
 *         &lt;element name="LTVType" type="{http://www.starstandards.org/STAR}LTVType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanToValueType", propOrder = {
    "ltvPercentage",
    "ltvAmount",
    "ltvType"
})
public class LoanToValueType {

    @XmlElement(name = "LTVPercentage")
    protected LTVPercentage ltvPercentage;
    @XmlElement(name = "LTVAmount")
    protected LTVAmount ltvAmount;
    @XmlElement(name = "LTVType")
    protected String ltvType;

    /**
     * Gets the value of the ltvPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link LTVPercentage }
     *     
     */
    public LTVPercentage getLTVPercentage() {
        return ltvPercentage;
    }

    /**
     * Sets the value of the ltvPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link LTVPercentage }
     *     
     */
    public void setLTVPercentage(LTVPercentage value) {
        this.ltvPercentage = value;
    }

    /**
     * Gets the value of the ltvAmount property.
     * 
     * @return
     *     possible object is
     *     {@link LTVAmount }
     *     
     */
    public LTVAmount getLTVAmount() {
        return ltvAmount;
    }

    /**
     * Sets the value of the ltvAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link LTVAmount }
     *     
     */
    public void setLTVAmount(LTVAmount value) {
        this.ltvAmount = value;
    }

    /**
     * Gets the value of the ltvType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTVType() {
        return ltvType;
    }

    /**
     * Sets the value of the ltvType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTVType(String value) {
        this.ltvType = value;
    }

}
