
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * RouteOne: TBD
 * 
 * <p>Java class for MaxBackEndAmount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MaxBackEndAmount"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.starstandards.org/STAR&gt;Amount"&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MaxBackEndAmount")
public class MaxBackEndAmount
    extends Amount
{


}
