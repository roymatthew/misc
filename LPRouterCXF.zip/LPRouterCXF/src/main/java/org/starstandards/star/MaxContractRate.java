
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * Maximum Contract Rate the dealer can agree to with the Buyer.
 * 
 * <p>Java class for MaxContractRate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MaxContractRate"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.starstandards.org/STAR&gt;Percent"&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MaxContractRate")
public class MaxContractRate
    extends Percent
{


}
