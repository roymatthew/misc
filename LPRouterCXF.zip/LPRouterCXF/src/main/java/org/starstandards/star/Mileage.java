
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * Mileage definition
 * 
 * <p>Java class for Mileage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Mileage"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.starstandards.org/STAR&gt;Count"&gt;
 *       &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}MileageMeasure" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Mileage")
@XmlSeeAlso({
    DeliveryMileage.class,
    MaximumMileage.class
})
public class Mileage
    extends Count
{

    @XmlAttribute(name = "uom")
    protected MileageMeasure uom;

    /**
     * Gets the value of the uom property.
     * 
     * @return
     *     possible object is
     *     {@link MileageMeasure }
     *     
     */
    public MileageMeasure getUom() {
        return uom;
    }

    /**
     * Sets the value of the uom property.
     * 
     * @param value
     *     allowed object is
     *     {@link MileageMeasure }
     *     
     */
    public void setUom(MileageMeasure value) {
        this.uom = value;
    }

}
