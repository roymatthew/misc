
package org.starstandards.star;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.starstandards.star package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ProcessCreditDecision_QNAME = new QName("http://www.starstandards.org/STAR", "ProcessCreditDecision");
    private final static QName _Attachment_QNAME = new QName("http://www.starstandards.org/STAR", "attachment");
    private final static QName _PayloadManifest_QNAME = new QName("http://www.starstandards.org/STAR", "payloadManifest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.starstandards.star
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OrganizationalApplicantPartyAddress }
     * 
     */
    public OrganizationalApplicantPartyAddress createOrganizationalApplicantPartyAddress() {
        return new OrganizationalApplicantPartyAddress();
    }

    /**
     * Create an instance of {@link FinancialPosition }
     * 
     */
    public FinancialPosition createFinancialPosition() {
        return new FinancialPosition();
    }

    /**
     * Create an instance of {@link PrincipalParty }
     * 
     */
    public PrincipalParty createPrincipalParty() {
        return new PrincipalParty();
    }

    /**
     * Create an instance of {@link DecisionFinancing }
     * 
     */
    public DecisionFinancing createDecisionFinancing() {
        return new DecisionFinancing();
    }

    /**
     * Create an instance of {@link VehiclePricing }
     * 
     */
    public VehiclePricing createVehiclePricing() {
        return new VehiclePricing();
    }

    /**
     * Create an instance of {@link ExpandedOption }
     * 
     */
    public ExpandedOption createExpandedOption() {
        return new ExpandedOption();
    }

    /**
     * Create an instance of {@link CreditVehicle }
     * 
     */
    public CreditVehicle createCreditVehicle() {
        return new CreditVehicle();
    }

    /**
     * Create an instance of {@link ApplicationArea }
     * 
     */
    public ApplicationArea createApplicationArea() {
        return new ApplicationArea();
    }

    /**
     * Create an instance of {@link Pricing }
     * 
     */
    public Pricing createPricing() {
        return new Pricing();
    }

    /**
     * Create an instance of {@link Option }
     * 
     */
    public Option createOption() {
        return new Option();
    }

    /**
     * Create an instance of {@link TradeInFinancing }
     * 
     */
    public TradeInFinancing createTradeInFinancing() {
        return new TradeInFinancing();
    }

    /**
     * Create an instance of {@link TradeInVehicleCredit }
     * 
     */
    public TradeInVehicleCredit createTradeInVehicleCredit() {
        return new TradeInVehicleCredit();
    }

    /**
     * Create an instance of {@link Fee }
     * 
     */
    public Fee createFee() {
        return new Fee();
    }

    /**
     * Create an instance of {@link Tax }
     * 
     */
    public Tax createTax() {
        return new Tax();
    }

    /**
     * Create an instance of {@link ServiceContractBase }
     * 
     */
    public ServiceContractBase createServiceContractBase() {
        return new ServiceContractBase();
    }

    /**
     * Create an instance of {@link ApplicationFinancing }
     * 
     */
    public ApplicationFinancing createApplicationFinancing() {
        return new ApplicationFinancing();
    }

    /**
     * Create an instance of {@link OrganizationalApplicantPartyExtended }
     * 
     */
    public OrganizationalApplicantPartyExtended createOrganizationalApplicantPartyExtended() {
        return new OrganizationalApplicantPartyExtended();
    }

    /**
     * Create an instance of {@link CoApplicantPartyExtended }
     * 
     */
    public CoApplicantPartyExtended createCoApplicantPartyExtended() {
        return new CoApplicantPartyExtended();
    }

    /**
     * Create an instance of {@link IndividualApplicantPartyExtended }
     * 
     */
    public IndividualApplicantPartyExtended createIndividualApplicantPartyExtended() {
        return new IndividualApplicantPartyExtended();
    }

    /**
     * Create an instance of {@link OtherIncome }
     * 
     */
    public OtherIncome createOtherIncome() {
        return new OtherIncome();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing }
     * 
     */
    public CoCreditorFinancing createCoCreditorFinancing() {
        return new CoCreditorFinancing();
    }

    /**
     * Create an instance of {@link BankAccount }
     * 
     */
    public BankAccount createBankAccount() {
        return new BankAccount();
    }

    /**
     * Create an instance of {@link EmployerParty }
     * 
     */
    public EmployerParty createEmployerParty() {
        return new EmployerParty();
    }

    /**
     * Create an instance of {@link IndividualApplicantContact }
     * 
     */
    public IndividualApplicantContact createIndividualApplicantContact() {
        return new IndividualApplicantContact();
    }

    /**
     * Create an instance of {@link IndividualApplicantAddress }
     * 
     */
    public IndividualApplicantAddress createIndividualApplicantAddress() {
        return new IndividualApplicantAddress();
    }

    /**
     * Create an instance of {@link ProcessCreditDecision }
     * 
     */
    public ProcessCreditDecision createProcessCreditDecision() {
        return new ProcessCreditDecision();
    }

    /**
     * Create an instance of {@link Attachment }
     * 
     */
    public Attachment createAttachment() {
        return new Attachment();
    }

    /**
     * Create an instance of {@link PayloadManifest }
     * 
     */
    public PayloadManifest createPayloadManifest() {
        return new PayloadManifest();
    }

    /**
     * Create an instance of {@link ProcessMessage }
     * 
     */
    public ProcessMessage createProcessMessage() {
        return new ProcessMessage();
    }

    /**
     * Create an instance of {@link Payload }
     * 
     */
    public Payload createPayload() {
        return new Payload();
    }

    /**
     * Create an instance of {@link ProcessMessageResponse }
     * 
     */
    public ProcessMessageResponse createProcessMessageResponse() {
        return new ProcessMessageResponse();
    }

    /**
     * Create an instance of {@link ProcessCreditDecisionResponse }
     * 
     */
    public ProcessCreditDecisionResponse createProcessCreditDecisionResponse() {
        return new ProcessCreditDecisionResponse();
    }

    /**
     * Create an instance of {@link PutMessage }
     * 
     */
    public PutMessage createPutMessage() {
        return new PutMessage();
    }

    /**
     * Create an instance of {@link PutMessageResponse }
     * 
     */
    public PutMessageResponse createPutMessageResponse() {
        return new PutMessageResponse();
    }

    /**
     * Create an instance of {@link PullMessage }
     * 
     */
    public PullMessage createPullMessage() {
        return new PullMessage();
    }

    /**
     * Create an instance of {@link PullMessageResponse }
     * 
     */
    public PullMessageResponse createPullMessageResponse() {
        return new PullMessageResponse();
    }

    /**
     * Create an instance of {@link IndividualApplicantPersonName }
     * 
     */
    public IndividualApplicantPersonName createIndividualApplicantPersonName() {
        return new IndividualApplicantPersonName();
    }

    /**
     * Create an instance of {@link IndividualPartyAlternatePartyId }
     * 
     */
    public IndividualPartyAlternatePartyId createIndividualPartyAlternatePartyId() {
        return new IndividualPartyAlternatePartyId();
    }

    /**
     * Create an instance of {@link ApplicantDemographics }
     * 
     */
    public ApplicantDemographics createApplicantDemographics() {
        return new ApplicantDemographics();
    }

    /**
     * Create an instance of {@link Dependents }
     * 
     */
    public Dependents createDependents() {
        return new Dependents();
    }

    /**
     * Create an instance of {@link CreditReportInformation }
     * 
     */
    public CreditReportInformation createCreditReportInformation() {
        return new CreditReportInformation();
    }

    /**
     * Create an instance of {@link OrganizationalPartyAlternatePartyId }
     * 
     */
    public OrganizationalPartyAlternatePartyId createOrganizationalPartyAlternatePartyId() {
        return new OrganizationalPartyAlternatePartyId();
    }

    /**
     * Create an instance of {@link OrganizationAddress }
     * 
     */
    public OrganizationAddress createOrganizationAddress() {
        return new OrganizationAddress();
    }

    /**
     * Create an instance of {@link OrganizationContact }
     * 
     */
    public OrganizationContact createOrganizationContact() {
        return new OrganizationContact();
    }

    /**
     * Create an instance of {@link OrganizationContactPersonName }
     * 
     */
    public OrganizationContactPersonName createOrganizationContactPersonName() {
        return new OrganizationContactPersonName();
    }

    /**
     * Create an instance of {@link NearestRelative }
     * 
     */
    public NearestRelative createNearestRelative() {
        return new NearestRelative();
    }

    /**
     * Create an instance of {@link Bank }
     * 
     */
    public Bank createBank() {
        return new Bank();
    }

    /**
     * Create an instance of {@link CoCreditor }
     * 
     */
    public CoCreditor createCoCreditor() {
        return new CoCreditor();
    }

    /**
     * Create an instance of {@link BankruptcyRepossession }
     * 
     */
    public BankruptcyRepossession createBankruptcyRepossession() {
        return new BankruptcyRepossession();
    }

    /**
     * Create an instance of {@link Privacy }
     * 
     */
    public Privacy createPrivacy() {
        return new Privacy();
    }

    /**
     * Create an instance of {@link CreditPrimaryDriver }
     * 
     */
    public CreditPrimaryDriver createCreditPrimaryDriver() {
        return new CreditPrimaryDriver();
    }

    /**
     * Create an instance of {@link ProcessCreditDecisionDataArea }
     * 
     */
    public ProcessCreditDecisionDataArea createProcessCreditDecisionDataArea() {
        return new ProcessCreditDecisionDataArea();
    }

    /**
     * Create an instance of {@link Sender }
     * 
     */
    public Sender createSender() {
        return new Sender();
    }

    /**
     * Create an instance of {@link Destination }
     * 
     */
    public Destination createDestination() {
        return new Destination();
    }

    /**
     * Create an instance of {@link CreditDecision }
     * 
     */
    public CreditDecision createCreditDecision() {
        return new CreditDecision();
    }

    /**
     * Create an instance of {@link CreditDecisionHeader }
     * 
     */
    public CreditDecisionHeader createCreditDecisionHeader() {
        return new CreditDecisionHeader();
    }

    /**
     * Create an instance of {@link ExpandedFinanceParty }
     * 
     */
    public ExpandedFinanceParty createExpandedFinanceParty() {
        return new ExpandedFinanceParty();
    }

    /**
     * Create an instance of {@link DealerParty }
     * 
     */
    public DealerParty createDealerParty() {
        return new DealerParty();
    }

    /**
     * Create an instance of {@link BrandedInfo }
     * 
     */
    public BrandedInfo createBrandedInfo() {
        return new BrandedInfo();
    }

    /**
     * Create an instance of {@link CreditDecisionDetail }
     * 
     */
    public CreditDecisionDetail createCreditDecisionDetail() {
        return new CreditDecisionDetail();
    }

    /**
     * Create an instance of {@link Telephone }
     * 
     */
    public Telephone createTelephone() {
        return new Telephone();
    }

    /**
     * Create an instance of {@link Decision }
     * 
     */
    public Decision createDecision() {
        return new Decision();
    }

    /**
     * Create an instance of {@link Vehicle }
     * 
     */
    public Vehicle createVehicle() {
        return new Vehicle();
    }

    /**
     * Create an instance of {@link ConditionRejection }
     * 
     */
    public ConditionRejection createConditionRejection() {
        return new ConditionRejection();
    }

    /**
     * Create an instance of {@link UpdateHistory }
     * 
     */
    public UpdateHistory createUpdateHistory() {
        return new UpdateHistory();
    }

    /**
     * Create an instance of {@link PartyBase }
     * 
     */
    public PartyBase createPartyBase() {
        return new PartyBase();
    }

    /**
     * Create an instance of {@link AccountantParty }
     * 
     */
    public AccountantParty createAccountantParty() {
        return new AccountantParty();
    }

    /**
     * Create an instance of {@link BuyPercentageRateAdjGroup }
     * 
     */
    public BuyPercentageRateAdjGroup createBuyPercentageRateAdjGroup() {
        return new BuyPercentageRateAdjGroup();
    }

    /**
     * Create an instance of {@link BuyPercentageRateAdjustment }
     * 
     */
    public BuyPercentageRateAdjustment createBuyPercentageRateAdjustment() {
        return new BuyPercentageRateAdjustment();
    }

    /**
     * Create an instance of {@link BuyPercentageRateAdjPercent }
     * 
     */
    public BuyPercentageRateAdjPercent createBuyPercentageRateAdjPercent() {
        return new BuyPercentageRateAdjPercent();
    }

    /**
     * Create an instance of {@link BuyPercentageRate }
     * 
     */
    public BuyPercentageRate createBuyPercentageRate() {
        return new BuyPercentageRate();
    }

    /**
     * Create an instance of {@link DownpaymentPercentage }
     * 
     */
    public DownpaymentPercentage createDownpaymentPercentage() {
        return new DownpaymentPercentage();
    }

    /**
     * Create an instance of {@link ParticipationType }
     * 
     */
    public ParticipationType createParticipationType() {
        return new ParticipationType();
    }

    /**
     * Create an instance of {@link ReserveGroupType }
     * 
     */
    public ReserveGroupType createReserveGroupType() {
        return new ReserveGroupType();
    }

    /**
     * Create an instance of {@link MaxParticipationPercentage }
     * 
     */
    public MaxParticipationPercentage createMaxParticipationPercentage() {
        return new MaxParticipationPercentage();
    }

    /**
     * Create an instance of {@link org.starstandards.star.MaxMonthlyPaymentAmount }
     * 
     */
    public org.starstandards.star.MaxMonthlyPaymentAmount createMaxMonthlyPaymentAmount() {
        return new org.starstandards.star.MaxMonthlyPaymentAmount();
    }

    /**
     * Create an instance of {@link LoanToValueType }
     * 
     */
    public LoanToValueType createLoanToValueType() {
        return new LoanToValueType();
    }

    /**
     * Create an instance of {@link FinanceProgramGroupType }
     * 
     */
    public FinanceProgramGroupType createFinanceProgramGroupType() {
        return new FinanceProgramGroupType();
    }

    /**
     * Create an instance of {@link StatedIncomeType }
     * 
     */
    public StatedIncomeType createStatedIncomeType() {
        return new StatedIncomeType();
    }

    /**
     * Create an instance of {@link MinAmountPaidToDealer }
     * 
     */
    public MinAmountPaidToDealer createMinAmountPaidToDealer() {
        return new MinAmountPaidToDealer();
    }

    /**
     * Create an instance of {@link MaximumServiceContractAmount }
     * 
     */
    public MaximumServiceContractAmount createMaximumServiceContractAmount() {
        return new MaximumServiceContractAmount();
    }

    /**
     * Create an instance of {@link MaximumGapAmount }
     * 
     */
    public MaximumGapAmount createMaximumGapAmount() {
        return new MaximumGapAmount();
    }

    /**
     * Create an instance of {@link StatedIncomeGroupType }
     * 
     */
    public StatedIncomeGroupType createStatedIncomeGroupType() {
        return new StatedIncomeGroupType();
    }

    /**
     * Create an instance of {@link Amortization }
     * 
     */
    public Amortization createAmortization() {
        return new Amortization();
    }

    /**
     * Create an instance of {@link CashDownPaymentAmount }
     * 
     */
    public CashDownPaymentAmount createCashDownPaymentAmount() {
        return new CashDownPaymentAmount();
    }

    /**
     * Create an instance of {@link ContractRate }
     * 
     */
    public ContractRate createContractRate() {
        return new ContractRate();
    }

    /**
     * Create an instance of {@link FrontEndAdvanceAmount }
     * 
     */
    public FrontEndAdvanceAmount createFrontEndAdvanceAmount() {
        return new FrontEndAdvanceAmount();
    }

    /**
     * Create an instance of {@link FrontEndAdvancePercentage }
     * 
     */
    public FrontEndAdvancePercentage createFrontEndAdvancePercentage() {
        return new FrontEndAdvancePercentage();
    }

    /**
     * Create an instance of {@link MaxFrontEndAdvanceAmount }
     * 
     */
    public MaxFrontEndAdvanceAmount createMaxFrontEndAdvanceAmount() {
        return new MaxFrontEndAdvanceAmount();
    }

    /**
     * Create an instance of {@link MaxFrontEndAdvancePercentage }
     * 
     */
    public MaxFrontEndAdvancePercentage createMaxFrontEndAdvancePercentage() {
        return new MaxFrontEndAdvancePercentage();
    }

    /**
     * Create an instance of {@link MaxBackEndAmount }
     * 
     */
    public MaxBackEndAmount createMaxBackEndAmount() {
        return new MaxBackEndAmount();
    }

    /**
     * Create an instance of {@link MaxBackEndPercentage }
     * 
     */
    public MaxBackEndPercentage createMaxBackEndPercentage() {
        return new MaxBackEndPercentage();
    }

    /**
     * Create an instance of {@link TotalBackEndAmount }
     * 
     */
    public TotalBackEndAmount createTotalBackEndAmount() {
        return new TotalBackEndAmount();
    }

    /**
     * Create an instance of {@link MinimumCashDownAmount }
     * 
     */
    public MinimumCashDownAmount createMinimumCashDownAmount() {
        return new MinimumCashDownAmount();
    }

    /**
     * Create an instance of {@link ReplacementInsuranceAmount }
     * 
     */
    public ReplacementInsuranceAmount createReplacementInsuranceAmount() {
        return new ReplacementInsuranceAmount();
    }

    /**
     * Create an instance of {@link Percent }
     * 
     */
    public Percent createPercent() {
        return new Percent();
    }

    /**
     * Create an instance of {@link Amount }
     * 
     */
    public Amount createAmount() {
        return new Amount();
    }

    /**
     * Create an instance of {@link IncomeAmount }
     * 
     */
    public IncomeAmount createIncomeAmount() {
        return new IncomeAmount();
    }

    /**
     * Create an instance of {@link MaxParticipationAmount }
     * 
     */
    public MaxParticipationAmount createMaxParticipationAmount() {
        return new MaxParticipationAmount();
    }

    /**
     * Create an instance of {@link ParticipationSplitPercentage }
     * 
     */
    public ParticipationSplitPercentage createParticipationSplitPercentage() {
        return new ParticipationSplitPercentage();
    }

    /**
     * Create an instance of {@link HoldbackAmount }
     * 
     */
    public HoldbackAmount createHoldbackAmount() {
        return new HoldbackAmount();
    }

    /**
     * Create an instance of {@link HoldbackCreditAmount }
     * 
     */
    public HoldbackCreditAmount createHoldbackCreditAmount() {
        return new HoldbackCreditAmount();
    }

    /**
     * Create an instance of {@link HoldbackAmountSpecific }
     * 
     */
    public HoldbackAmountSpecific createHoldbackAmountSpecific() {
        return new HoldbackAmountSpecific();
    }

    /**
     * Create an instance of {@link ReserveType }
     * 
     */
    public ReserveType createReserveType() {
        return new ReserveType();
    }

    /**
     * Create an instance of {@link DealerReserveAmount }
     * 
     */
    public DealerReserveAmount createDealerReserveAmount() {
        return new DealerReserveAmount();
    }

    /**
     * Create an instance of {@link DealerReservePercentage }
     * 
     */
    public DealerReservePercentage createDealerReservePercentage() {
        return new DealerReservePercentage();
    }

    /**
     * Create an instance of {@link MinAnnualPercentageRate }
     * 
     */
    public MinAnnualPercentageRate createMinAnnualPercentageRate() {
        return new MinAnnualPercentageRate();
    }

    /**
     * Create an instance of {@link MaxContractRate }
     * 
     */
    public MaxContractRate createMaxContractRate() {
        return new MaxContractRate();
    }

    /**
     * Create an instance of {@link LTVPercentage }
     * 
     */
    public LTVPercentage createLTVPercentage() {
        return new LTVPercentage();
    }

    /**
     * Create an instance of {@link LTVAmount }
     * 
     */
    public LTVAmount createLTVAmount() {
        return new LTVAmount();
    }

    /**
     * Create an instance of {@link FinanceProgramType }
     * 
     */
    public FinanceProgramType createFinanceProgramType() {
        return new FinanceProgramType();
    }

    /**
     * Create an instance of {@link FinanceProgramDescription }
     * 
     */
    public FinanceProgramDescription createFinanceProgramDescription() {
        return new FinanceProgramDescription();
    }

    /**
     * Create an instance of {@link Description }
     * 
     */
    public Description createDescription() {
        return new Description();
    }

    /**
     * Create an instance of {@link MaxPaymentToIncomePercentage }
     * 
     */
    public MaxPaymentToIncomePercentage createMaxPaymentToIncomePercentage() {
        return new MaxPaymentToIncomePercentage();
    }

    /**
     * Create an instance of {@link Count }
     * 
     */
    public Count createCount() {
        return new Count();
    }

    /**
     * Create an instance of {@link VehiclePricingTypeSource }
     * 
     */
    public VehiclePricingTypeSource createVehiclePricingTypeSource() {
        return new VehiclePricingTypeSource();
    }

    /**
     * Create an instance of {@link CodeType }
     * 
     */
    public CodeType createCodeType() {
        return new CodeType();
    }

    /**
     * Create an instance of {@link DecisionVehicle }
     * 
     */
    public DecisionVehicle createDecisionVehicle() {
        return new DecisionVehicle();
    }

    /**
     * Create an instance of {@link org.starstandards.star.DeliveryMileage }
     * 
     */
    public org.starstandards.star.DeliveryMileage createDeliveryMileage() {
        return new org.starstandards.star.DeliveryMileage();
    }

    /**
     * Create an instance of {@link Mileage }
     * 
     */
    public Mileage createMileage() {
        return new Mileage();
    }

    /**
     * Create an instance of {@link MaximumMileage }
     * 
     */
    public MaximumMileage createMaximumMileage() {
        return new MaximumMileage();
    }

    /**
     * Create an instance of {@link CreditVehiclePricing }
     * 
     */
    public CreditVehiclePricing createCreditVehiclePricing() {
        return new CreditVehiclePricing();
    }

    /**
     * Create an instance of {@link org.starstandards.star.VehiclePrice }
     * 
     */
    public org.starstandards.star.VehiclePrice createVehiclePrice() {
        return new org.starstandards.star.VehiclePrice();
    }

    /**
     * Create an instance of {@link Content }
     * 
     */
    public Content createContent() {
        return new Content();
    }

    /**
     * Create an instance of {@link Manifest }
     * 
     */
    public Manifest createManifest() {
        return new Manifest();
    }

    /**
     * Create an instance of {@link OrganizationalApplicantPartyAddress.PeriodOfResidence }
     * 
     */
    public OrganizationalApplicantPartyAddress.PeriodOfResidence createOrganizationalApplicantPartyAddressPeriodOfResidence() {
        return new OrganizationalApplicantPartyAddress.PeriodOfResidence();
    }

    /**
     * Create an instance of {@link FinancialPosition.CurrentAssetsAmount }
     * 
     */
    public FinancialPosition.CurrentAssetsAmount createFinancialPositionCurrentAssetsAmount() {
        return new FinancialPosition.CurrentAssetsAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.IntangibleAssetsAmount }
     * 
     */
    public FinancialPosition.IntangibleAssetsAmount createFinancialPositionIntangibleAssetsAmount() {
        return new FinancialPosition.IntangibleAssetsAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.FixedAssetsAmount }
     * 
     */
    public FinancialPosition.FixedAssetsAmount createFinancialPositionFixedAssetsAmount() {
        return new FinancialPosition.FixedAssetsAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.TotalAssetsAmount }
     * 
     */
    public FinancialPosition.TotalAssetsAmount createFinancialPositionTotalAssetsAmount() {
        return new FinancialPosition.TotalAssetsAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.CurrentLiabilitiesAmount }
     * 
     */
    public FinancialPosition.CurrentLiabilitiesAmount createFinancialPositionCurrentLiabilitiesAmount() {
        return new FinancialPosition.CurrentLiabilitiesAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.LongTermDirectLiabilitiesAmt }
     * 
     */
    public FinancialPosition.LongTermDirectLiabilitiesAmt createFinancialPositionLongTermDirectLiabilitiesAmt() {
        return new FinancialPosition.LongTermDirectLiabilitiesAmt();
    }

    /**
     * Create an instance of {@link FinancialPosition.TotalLiabilitiesAmount }
     * 
     */
    public FinancialPosition.TotalLiabilitiesAmount createFinancialPositionTotalLiabilitiesAmount() {
        return new FinancialPosition.TotalLiabilitiesAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.CapitalAmount }
     * 
     */
    public FinancialPosition.CapitalAmount createFinancialPositionCapitalAmount() {
        return new FinancialPosition.CapitalAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.EarnedSurplusAmount }
     * 
     */
    public FinancialPosition.EarnedSurplusAmount createFinancialPositionEarnedSurplusAmount() {
        return new FinancialPosition.EarnedSurplusAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.AnnualSalesAmount }
     * 
     */
    public FinancialPosition.AnnualSalesAmount createFinancialPositionAnnualSalesAmount() {
        return new FinancialPosition.AnnualSalesAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.GrossProfitAmount }
     * 
     */
    public FinancialPosition.GrossProfitAmount createFinancialPositionGrossProfitAmount() {
        return new FinancialPosition.GrossProfitAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.NetProfitAmount }
     * 
     */
    public FinancialPosition.NetProfitAmount createFinancialPositionNetProfitAmount() {
        return new FinancialPosition.NetProfitAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.WorkingCapitalAmount }
     * 
     */
    public FinancialPosition.WorkingCapitalAmount createFinancialPositionWorkingCapitalAmount() {
        return new FinancialPosition.WorkingCapitalAmount();
    }

    /**
     * Create an instance of {@link FinancialPosition.TotalNetWorthAmount }
     * 
     */
    public FinancialPosition.TotalNetWorthAmount createFinancialPositionTotalNetWorthAmount() {
        return new FinancialPosition.TotalNetWorthAmount();
    }

    /**
     * Create an instance of {@link PrincipalParty.Income }
     * 
     */
    public PrincipalParty.Income createPrincipalPartyIncome() {
        return new PrincipalParty.Income();
    }

    /**
     * Create an instance of {@link PrincipalParty.PeriodOfOwnership }
     * 
     */
    public PrincipalParty.PeriodOfOwnership createPrincipalPartyPeriodOfOwnership() {
        return new PrincipalParty.PeriodOfOwnership();
    }

    /**
     * Create an instance of {@link PrincipalParty.PeriodAsPrincipal }
     * 
     */
    public PrincipalParty.PeriodAsPrincipal createPrincipalPartyPeriodAsPrincipal() {
        return new PrincipalParty.PeriodAsPrincipal();
    }

    /**
     * Create an instance of {@link DecisionFinancing.PaymentAmount }
     * 
     */
    public DecisionFinancing.PaymentAmount createDecisionFinancingPaymentAmount() {
        return new DecisionFinancing.PaymentAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.BalanceAmount }
     * 
     */
    public DecisionFinancing.BalanceAmount createDecisionFinancingBalanceAmount() {
        return new DecisionFinancing.BalanceAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.FinalAmount }
     * 
     */
    public DecisionFinancing.FinalAmount createDecisionFinancingFinalAmount() {
        return new DecisionFinancing.FinalAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.ResidualAmount }
     * 
     */
    public DecisionFinancing.ResidualAmount createDecisionFinancingResidualAmount() {
        return new DecisionFinancing.ResidualAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.Term }
     * 
     */
    public DecisionFinancing.Term createDecisionFinancingTerm() {
        return new DecisionFinancing.Term();
    }

    /**
     * Create an instance of {@link DecisionFinancing.DownPaymentAmount }
     * 
     */
    public DecisionFinancing.DownPaymentAmount createDecisionFinancingDownPaymentAmount() {
        return new DecisionFinancing.DownPaymentAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.PurchasePrice }
     * 
     */
    public DecisionFinancing.PurchasePrice createDecisionFinancingPurchasePrice() {
        return new DecisionFinancing.PurchasePrice();
    }

    /**
     * Create an instance of {@link DecisionFinancing.ApprovedAmount }
     * 
     */
    public DecisionFinancing.ApprovedAmount createDecisionFinancingApprovedAmount() {
        return new DecisionFinancing.ApprovedAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.DeferredDownPayment }
     * 
     */
    public DecisionFinancing.DeferredDownPayment createDecisionFinancingDeferredDownPayment() {
        return new DecisionFinancing.DeferredDownPayment();
    }

    /**
     * Create an instance of {@link DecisionFinancing.DealerRebateAmount }
     * 
     */
    public DecisionFinancing.DealerRebateAmount createDecisionFinancingDealerRebateAmount() {
        return new DecisionFinancing.DealerRebateAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.ManufacturerRebateAmount }
     * 
     */
    public DecisionFinancing.ManufacturerRebateAmount createDecisionFinancingManufacturerRebateAmount() {
        return new DecisionFinancing.ManufacturerRebateAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.NetTradeAmount }
     * 
     */
    public DecisionFinancing.NetTradeAmount createDecisionFinancingNetTradeAmount() {
        return new DecisionFinancing.NetTradeAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.InsuranceTotalExtendedWarrantyAmount }
     * 
     */
    public DecisionFinancing.InsuranceTotalExtendedWarrantyAmount createDecisionFinancingInsuranceTotalExtendedWarrantyAmount() {
        return new DecisionFinancing.InsuranceTotalExtendedWarrantyAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.DisabilityPremiumAmount }
     * 
     */
    public DecisionFinancing.DisabilityPremiumAmount createDecisionFinancingDisabilityPremiumAmount() {
        return new DecisionFinancing.DisabilityPremiumAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.CreditLifePremiumAmount }
     * 
     */
    public DecisionFinancing.CreditLifePremiumAmount createDecisionFinancingCreditLifePremiumAmount() {
        return new DecisionFinancing.CreditLifePremiumAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.SecurityDepositAmount }
     * 
     */
    public DecisionFinancing.SecurityDepositAmount createDecisionFinancingSecurityDepositAmount() {
        return new DecisionFinancing.SecurityDepositAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.AnnualPercentageRate }
     * 
     */
    public DecisionFinancing.AnnualPercentageRate createDecisionFinancingAnnualPercentageRate() {
        return new DecisionFinancing.AnnualPercentageRate();
    }

    /**
     * Create an instance of {@link DecisionFinancing.MSRPGuidePercentage }
     * 
     */
    public DecisionFinancing.MSRPGuidePercentage createDecisionFinancingMSRPGuidePercentage() {
        return new DecisionFinancing.MSRPGuidePercentage();
    }

    /**
     * Create an instance of {@link DecisionFinancing.TotalContractAmount }
     * 
     */
    public DecisionFinancing.TotalContractAmount createDecisionFinancingTotalContractAmount() {
        return new DecisionFinancing.TotalContractAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.NetCapitalizedCostAmount }
     * 
     */
    public DecisionFinancing.NetCapitalizedCostAmount createDecisionFinancingNetCapitalizedCostAmount() {
        return new DecisionFinancing.NetCapitalizedCostAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.MaxMonthlyPaymentAmount }
     * 
     */
    public DecisionFinancing.MaxMonthlyPaymentAmount createDecisionFinancingMaxMonthlyPaymentAmount() {
        return new DecisionFinancing.MaxMonthlyPaymentAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.MaxUnpaidBalanceAmount }
     * 
     */
    public DecisionFinancing.MaxUnpaidBalanceAmount createDecisionFinancingMaxUnpaidBalanceAmount() {
        return new DecisionFinancing.MaxUnpaidBalanceAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.MinimumDownPaymentAmount }
     * 
     */
    public DecisionFinancing.MinimumDownPaymentAmount createDecisionFinancingMinimumDownPaymentAmount() {
        return new DecisionFinancing.MinimumDownPaymentAmount();
    }

    /**
     * Create an instance of {@link DecisionFinancing.MaxFinancedAmount }
     * 
     */
    public DecisionFinancing.MaxFinancedAmount createDecisionFinancingMaxFinancedAmount() {
        return new DecisionFinancing.MaxFinancedAmount();
    }

    /**
     * Create an instance of {@link VehiclePricing.VehiclePrice }
     * 
     */
    public VehiclePricing.VehiclePrice createVehiclePricingVehiclePrice() {
        return new VehiclePricing.VehiclePrice();
    }

    /**
     * Create an instance of {@link ExpandedOption.OptionPrice }
     * 
     */
    public ExpandedOption.OptionPrice createExpandedOptionOptionPrice() {
        return new ExpandedOption.OptionPrice();
    }

    /**
     * Create an instance of {@link ExpandedOption.OptionCost }
     * 
     */
    public ExpandedOption.OptionCost createExpandedOptionOptionCost() {
        return new ExpandedOption.OptionCost();
    }

    /**
     * Create an instance of {@link ExpandedOption.OptionMSRP }
     * 
     */
    public ExpandedOption.OptionMSRP createExpandedOptionOptionMSRP() {
        return new ExpandedOption.OptionMSRP();
    }

    /**
     * Create an instance of {@link CreditVehicle.DeliveryMileage }
     * 
     */
    public CreditVehicle.DeliveryMileage createCreditVehicleDeliveryMileage() {
        return new CreditVehicle.DeliveryMileage();
    }

    /**
     * Create an instance of {@link CreditVehicle.VanConversionCost }
     * 
     */
    public CreditVehicle.VanConversionCost createCreditVehicleVanConversionCost() {
        return new CreditVehicle.VanConversionCost();
    }

    /**
     * Create an instance of {@link CreditVehicle.VehicleId }
     * 
     */
    public CreditVehicle.VehicleId createCreditVehicleVehicleId() {
        return new CreditVehicle.VehicleId();
    }

    /**
     * Create an instance of {@link ApplicationArea.Signature }
     * 
     */
    public ApplicationArea.Signature createApplicationAreaSignature() {
        return new ApplicationArea.Signature();
    }

    /**
     * Create an instance of {@link Pricing.VehiclePrice }
     * 
     */
    public Pricing.VehiclePrice createPricingVehiclePrice() {
        return new Pricing.VehiclePrice();
    }

    /**
     * Create an instance of {@link Option.OptionPrice }
     * 
     */
    public Option.OptionPrice createOptionOptionPrice() {
        return new Option.OptionPrice();
    }

    /**
     * Create an instance of {@link TradeInFinancing.PaymentAmount }
     * 
     */
    public TradeInFinancing.PaymentAmount createTradeInFinancingPaymentAmount() {
        return new TradeInFinancing.PaymentAmount();
    }

    /**
     * Create an instance of {@link TradeInFinancing.BalanceAmount }
     * 
     */
    public TradeInFinancing.BalanceAmount createTradeInFinancingBalanceAmount() {
        return new TradeInFinancing.BalanceAmount();
    }

    /**
     * Create an instance of {@link TradeInFinancing.FinalAmount }
     * 
     */
    public TradeInFinancing.FinalAmount createTradeInFinancingFinalAmount() {
        return new TradeInFinancing.FinalAmount();
    }

    /**
     * Create an instance of {@link TradeInFinancing.ResidualAmount }
     * 
     */
    public TradeInFinancing.ResidualAmount createTradeInFinancingResidualAmount() {
        return new TradeInFinancing.ResidualAmount();
    }

    /**
     * Create an instance of {@link TradeInFinancing.Term }
     * 
     */
    public TradeInFinancing.Term createTradeInFinancingTerm() {
        return new TradeInFinancing.Term();
    }

    /**
     * Create an instance of {@link TradeInFinancing.WholesaleValueAmount }
     * 
     */
    public TradeInFinancing.WholesaleValueAmount createTradeInFinancingWholesaleValueAmount() {
        return new TradeInFinancing.WholesaleValueAmount();
    }

    /**
     * Create an instance of {@link TradeInFinancing.NetTradeAllowanceAmount }
     * 
     */
    public TradeInFinancing.NetTradeAllowanceAmount createTradeInFinancingNetTradeAllowanceAmount() {
        return new TradeInFinancing.NetTradeAllowanceAmount();
    }

    /**
     * Create an instance of {@link TradeInFinancing.GrossTradeIn }
     * 
     */
    public TradeInFinancing.GrossTradeIn createTradeInFinancingGrossTradeIn() {
        return new TradeInFinancing.GrossTradeIn();
    }

    /**
     * Create an instance of {@link TradeInFinancing.PriorCreditOrLeaseOwedOnTrade }
     * 
     */
    public TradeInFinancing.PriorCreditOrLeaseOwedOnTrade createTradeInFinancingPriorCreditOrLeaseOwedOnTrade() {
        return new TradeInFinancing.PriorCreditOrLeaseOwedOnTrade();
    }

    /**
     * Create an instance of {@link TradeInFinancing.TradeInSalesTaxCredit }
     * 
     */
    public TradeInFinancing.TradeInSalesTaxCredit createTradeInFinancingTradeInSalesTaxCredit() {
        return new TradeInFinancing.TradeInSalesTaxCredit();
    }

    /**
     * Create an instance of {@link TradeInVehicleCredit.DeliveryMileage }
     * 
     */
    public TradeInVehicleCredit.DeliveryMileage createTradeInVehicleCreditDeliveryMileage() {
        return new TradeInVehicleCredit.DeliveryMileage();
    }

    /**
     * Create an instance of {@link Fee.FeeAmount }
     * 
     */
    public Fee.FeeAmount createFeeFeeAmount() {
        return new Fee.FeeAmount();
    }

    /**
     * Create an instance of {@link Tax.TaxAmount }
     * 
     */
    public Tax.TaxAmount createTaxTaxAmount() {
        return new Tax.TaxAmount();
    }

    /**
     * Create an instance of {@link Tax.UnitSalesTaxAmount }
     * 
     */
    public Tax.UnitSalesTaxAmount createTaxUnitSalesTaxAmount() {
        return new Tax.UnitSalesTaxAmount();
    }

    /**
     * Create an instance of {@link Tax.TotalTaxableAmount }
     * 
     */
    public Tax.TotalTaxableAmount createTaxTotalTaxableAmount() {
        return new Tax.TotalTaxableAmount();
    }

    /**
     * Create an instance of {@link Tax.NonTaxableAmount }
     * 
     */
    public Tax.NonTaxableAmount createTaxNonTaxableAmount() {
        return new Tax.NonTaxableAmount();
    }

    /**
     * Create an instance of {@link ServiceContractBase.Term }
     * 
     */
    public ServiceContractBase.Term createServiceContractBaseTerm() {
        return new ServiceContractBase.Term();
    }

    /**
     * Create an instance of {@link ServiceContractBase.ContractDeductible }
     * 
     */
    public ServiceContractBase.ContractDeductible createServiceContractBaseContractDeductible() {
        return new ServiceContractBase.ContractDeductible();
    }

    /**
     * Create an instance of {@link ServiceContractBase.ContractStartMileage }
     * 
     */
    public ServiceContractBase.ContractStartMileage createServiceContractBaseContractStartMileage() {
        return new ServiceContractBase.ContractStartMileage();
    }

    /**
     * Create an instance of {@link ServiceContractBase.ContractTermMileage }
     * 
     */
    public ServiceContractBase.ContractTermMileage createServiceContractBaseContractTermMileage() {
        return new ServiceContractBase.ContractTermMileage();
    }

    /**
     * Create an instance of {@link ServiceContractBase.TotalContractAmount }
     * 
     */
    public ServiceContractBase.TotalContractAmount createServiceContractBaseTotalContractAmount() {
        return new ServiceContractBase.TotalContractAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.PaymentAmount }
     * 
     */
    public ApplicationFinancing.PaymentAmount createApplicationFinancingPaymentAmount() {
        return new ApplicationFinancing.PaymentAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.BalanceAmount }
     * 
     */
    public ApplicationFinancing.BalanceAmount createApplicationFinancingBalanceAmount() {
        return new ApplicationFinancing.BalanceAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.FinalAmount }
     * 
     */
    public ApplicationFinancing.FinalAmount createApplicationFinancingFinalAmount() {
        return new ApplicationFinancing.FinalAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.ResidualAmount }
     * 
     */
    public ApplicationFinancing.ResidualAmount createApplicationFinancingResidualAmount() {
        return new ApplicationFinancing.ResidualAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.Term }
     * 
     */
    public ApplicationFinancing.Term createApplicationFinancingTerm() {
        return new ApplicationFinancing.Term();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.DownPaymentAmount }
     * 
     */
    public ApplicationFinancing.DownPaymentAmount createApplicationFinancingDownPaymentAmount() {
        return new ApplicationFinancing.DownPaymentAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.PurchasePrice }
     * 
     */
    public ApplicationFinancing.PurchasePrice createApplicationFinancingPurchasePrice() {
        return new ApplicationFinancing.PurchasePrice();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.ApprovedAmount }
     * 
     */
    public ApplicationFinancing.ApprovedAmount createApplicationFinancingApprovedAmount() {
        return new ApplicationFinancing.ApprovedAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.DeferredDownPayment }
     * 
     */
    public ApplicationFinancing.DeferredDownPayment createApplicationFinancingDeferredDownPayment() {
        return new ApplicationFinancing.DeferredDownPayment();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.DealerRebateAmount }
     * 
     */
    public ApplicationFinancing.DealerRebateAmount createApplicationFinancingDealerRebateAmount() {
        return new ApplicationFinancing.DealerRebateAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.ManufacturerRebateAmount }
     * 
     */
    public ApplicationFinancing.ManufacturerRebateAmount createApplicationFinancingManufacturerRebateAmount() {
        return new ApplicationFinancing.ManufacturerRebateAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.NetTradeAmount }
     * 
     */
    public ApplicationFinancing.NetTradeAmount createApplicationFinancingNetTradeAmount() {
        return new ApplicationFinancing.NetTradeAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount }
     * 
     */
    public ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount createApplicationFinancingInsuranceTotalExtendedWarrantyAmount() {
        return new ApplicationFinancing.InsuranceTotalExtendedWarrantyAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.DisabilityPremiumAmount }
     * 
     */
    public ApplicationFinancing.DisabilityPremiumAmount createApplicationFinancingDisabilityPremiumAmount() {
        return new ApplicationFinancing.DisabilityPremiumAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.CreditLifePremiumAmount }
     * 
     */
    public ApplicationFinancing.CreditLifePremiumAmount createApplicationFinancingCreditLifePremiumAmount() {
        return new ApplicationFinancing.CreditLifePremiumAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.SecurityDepositAmount }
     * 
     */
    public ApplicationFinancing.SecurityDepositAmount createApplicationFinancingSecurityDepositAmount() {
        return new ApplicationFinancing.SecurityDepositAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.CostPerMile }
     * 
     */
    public ApplicationFinancing.CostPerMile createApplicationFinancingCostPerMile() {
        return new ApplicationFinancing.CostPerMile();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.EstimatedAnnualMileage }
     * 
     */
    public ApplicationFinancing.EstimatedAnnualMileage createApplicationFinancingEstimatedAnnualMileage() {
        return new ApplicationFinancing.EstimatedAnnualMileage();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.ExcessMilesPerYear }
     * 
     */
    public ApplicationFinancing.ExcessMilesPerYear createApplicationFinancingExcessMilesPerYear() {
        return new ApplicationFinancing.ExcessMilesPerYear();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.OfferingType }
     * 
     */
    public ApplicationFinancing.OfferingType createApplicationFinancingOfferingType() {
        return new ApplicationFinancing.OfferingType();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.ApprovedEquipmentAmount }
     * 
     */
    public ApplicationFinancing.ApprovedEquipmentAmount createApplicationFinancingApprovedEquipmentAmount() {
        return new ApplicationFinancing.ApprovedEquipmentAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.NetAmountFinanced }
     * 
     */
    public ApplicationFinancing.NetAmountFinanced createApplicationFinancingNetAmountFinanced() {
        return new ApplicationFinancing.NetAmountFinanced();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.BasePaymentAmount }
     * 
     */
    public ApplicationFinancing.BasePaymentAmount createApplicationFinancingBasePaymentAmount() {
        return new ApplicationFinancing.BasePaymentAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.TotalReductionsAmount }
     * 
     */
    public ApplicationFinancing.TotalReductionsAmount createApplicationFinancingTotalReductionsAmount() {
        return new ApplicationFinancing.TotalReductionsAmount();
    }

    /**
     * Create an instance of {@link ApplicationFinancing.NetCapitalizedCostAmount }
     * 
     */
    public ApplicationFinancing.NetCapitalizedCostAmount createApplicationFinancingNetCapitalizedCostAmount() {
        return new ApplicationFinancing.NetCapitalizedCostAmount();
    }

    /**
     * Create an instance of {@link OrganizationalApplicantPartyExtended.PaymentAmount }
     * 
     */
    public OrganizationalApplicantPartyExtended.PaymentAmount createOrganizationalApplicantPartyExtendedPaymentAmount() {
        return new OrganizationalApplicantPartyExtended.PaymentAmount();
    }

    /**
     * Create an instance of {@link OrganizationalApplicantPartyExtended.MortgageBalance }
     * 
     */
    public OrganizationalApplicantPartyExtended.MortgageBalance createOrganizationalApplicantPartyExtendedMortgageBalance() {
        return new OrganizationalApplicantPartyExtended.MortgageBalance();
    }

    /**
     * Create an instance of {@link CoApplicantPartyExtended.PaymentAmount }
     * 
     */
    public CoApplicantPartyExtended.PaymentAmount createCoApplicantPartyExtendedPaymentAmount() {
        return new CoApplicantPartyExtended.PaymentAmount();
    }

    /**
     * Create an instance of {@link CoApplicantPartyExtended.MortgageBalance }
     * 
     */
    public CoApplicantPartyExtended.MortgageBalance createCoApplicantPartyExtendedMortgageBalance() {
        return new CoApplicantPartyExtended.MortgageBalance();
    }

    /**
     * Create an instance of {@link IndividualApplicantPartyExtended.PaymentAmount }
     * 
     */
    public IndividualApplicantPartyExtended.PaymentAmount createIndividualApplicantPartyExtendedPaymentAmount() {
        return new IndividualApplicantPartyExtended.PaymentAmount();
    }

    /**
     * Create an instance of {@link IndividualApplicantPartyExtended.MortgageBalance }
     * 
     */
    public IndividualApplicantPartyExtended.MortgageBalance createIndividualApplicantPartyExtendedMortgageBalance() {
        return new IndividualApplicantPartyExtended.MortgageBalance();
    }

    /**
     * Create an instance of {@link OtherIncome.OtherIncomeAmount }
     * 
     */
    public OtherIncome.OtherIncomeAmount createOtherIncomeOtherIncomeAmount() {
        return new OtherIncome.OtherIncomeAmount();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.PaymentAmount }
     * 
     */
    public CoCreditorFinancing.PaymentAmount createCoCreditorFinancingPaymentAmount() {
        return new CoCreditorFinancing.PaymentAmount();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.BalanceAmount }
     * 
     */
    public CoCreditorFinancing.BalanceAmount createCoCreditorFinancingBalanceAmount() {
        return new CoCreditorFinancing.BalanceAmount();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.FinalAmount }
     * 
     */
    public CoCreditorFinancing.FinalAmount createCoCreditorFinancingFinalAmount() {
        return new CoCreditorFinancing.FinalAmount();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.ResidualAmount }
     * 
     */
    public CoCreditorFinancing.ResidualAmount createCoCreditorFinancingResidualAmount() {
        return new CoCreditorFinancing.ResidualAmount();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.Term }
     * 
     */
    public CoCreditorFinancing.Term createCoCreditorFinancingTerm() {
        return new CoCreditorFinancing.Term();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.WholesaleValueAmount }
     * 
     */
    public CoCreditorFinancing.WholesaleValueAmount createCoCreditorFinancingWholesaleValueAmount() {
        return new CoCreditorFinancing.WholesaleValueAmount();
    }

    /**
     * Create an instance of {@link CoCreditorFinancing.TradeAllowanceAmount }
     * 
     */
    public CoCreditorFinancing.TradeAllowanceAmount createCoCreditorFinancingTradeAllowanceAmount() {
        return new CoCreditorFinancing.TradeAllowanceAmount();
    }

    /**
     * Create an instance of {@link BankAccount.AccountBalanceAmount }
     * 
     */
    public BankAccount.AccountBalanceAmount createBankAccountAccountBalanceAmount() {
        return new BankAccount.AccountBalanceAmount();
    }

    /**
     * Create an instance of {@link EmployerParty.Income }
     * 
     */
    public EmployerParty.Income createEmployerPartyIncome() {
        return new EmployerParty.Income();
    }

    /**
     * Create an instance of {@link EmployerParty.PeriodOfEmployment }
     * 
     */
    public EmployerParty.PeriodOfEmployment createEmployerPartyPeriodOfEmployment() {
        return new EmployerParty.PeriodOfEmployment();
    }

    /**
     * Create an instance of {@link IndividualApplicantContact.EMailAddress }
     * 
     */
    public IndividualApplicantContact.EMailAddress createIndividualApplicantContactEMailAddress() {
        return new IndividualApplicantContact.EMailAddress();
    }

    /**
     * Create an instance of {@link IndividualApplicantContact.Fax }
     * 
     */
    public IndividualApplicantContact.Fax createIndividualApplicantContactFax() {
        return new IndividualApplicantContact.Fax();
    }

    /**
     * Create an instance of {@link IndividualApplicantAddress.PeriodOfResidence }
     * 
     */
    public IndividualApplicantAddress.PeriodOfResidence createIndividualApplicantAddressPeriodOfResidence() {
        return new IndividualApplicantAddress.PeriodOfResidence();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessCreditDecision }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ProcessCreditDecision }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.starstandards.org/STAR", name = "ProcessCreditDecision")
    public JAXBElement<ProcessCreditDecision> createProcessCreditDecision(ProcessCreditDecision value) {
        return new JAXBElement<ProcessCreditDecision>(_ProcessCreditDecision_QNAME, ProcessCreditDecision.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Attachment }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Attachment }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.starstandards.org/STAR", name = "attachment")
    public JAXBElement<Attachment> createAttachment(Attachment value) {
        return new JAXBElement<Attachment>(_Attachment_QNAME, Attachment.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PayloadManifest }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PayloadManifest }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.starstandards.org/STAR", name = "payloadManifest")
    public JAXBElement<PayloadManifest> createPayloadManifest(PayloadManifest value) {
        return new JAXBElement<PayloadManifest>(_PayloadManifest_QNAME, PayloadManifest.class, null, value);
    }

}
