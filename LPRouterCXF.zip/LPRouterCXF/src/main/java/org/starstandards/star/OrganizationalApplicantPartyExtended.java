
package org.starstandards.star;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for OrganizationalApplicantPartyExtended complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrganizationalApplicantPartyExtended"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="AlternatePartyIds" type="{http://www.starstandards.org/STAR}OrganizationalPartyAlternatePartyId" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address" type="{http://www.starstandards.org/STAR}OrganizationalApplicantPartyAddress" minOccurs="0"/&gt;
 *         &lt;element name="DBAName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Contact" type="{http://www.starstandards.org/STAR}OrganizationContact" minOccurs="0"/&gt;
 *         &lt;element name="MarketingMailInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="OrganizationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RelationshipCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Bank" type="{http://www.starstandards.org/STAR}Bank" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Co-Creditor" type="{http://www.starstandards.org/STAR}Co-Creditor" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BankruptcyRepossession" type="{http://www.starstandards.org/STAR}BankruptcyRepossession" minOccurs="0"/&gt;
 *         &lt;element name="MfgDealerInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="PrimaryDriverInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="YearsInBusines" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/&gt;
 *         &lt;element name="Privacy" type="{http://www.starstandards.org/STAR}Privacy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EstimatedUsage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="RelationshipDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IndustryType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DateOfIncorporation" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="StateOfIncorporation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InsuranceCompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Principal" type="{http://www.starstandards.org/STAR}PrincipalParty" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Accountant" type="{http://www.starstandards.org/STAR}AccountantParty" minOccurs="0"/&gt;
 *         &lt;element name="FinancialPosition" type="{http://www.starstandards.org/STAR}FinancialPosition" minOccurs="0"/&gt;
 *         &lt;element name="ResidenceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentAmount" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MortgageBalance" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrganizationalApplicantPartyExtended", propOrder = {
    "partyId",
    "alternatePartyIds",
    "name",
    "address",
    "dbaName",
    "contact",
    "marketingMailInd",
    "organizationType",
    "relationshipCode",
    "bank",
    "coCreditor",
    "bankruptcyRepossession",
    "mfgDealerInd",
    "primaryDriverInd",
    "yearsInBusines",
    "privacy",
    "estimatedUsage",
    "relationshipDescription",
    "industryType",
    "dateOfIncorporation",
    "stateOfIncorporation",
    "insuranceCompanyName",
    "principal",
    "accountant",
    "financialPosition",
    "residenceType",
    "paymentAmount",
    "mortgageBalance"
})
public class OrganizationalApplicantPartyExtended {

    @XmlElement(name = "PartyId", required = true)
    protected String partyId;
    @XmlElement(name = "AlternatePartyIds")
    protected List<OrganizationalPartyAlternatePartyId> alternatePartyIds;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Address")
    protected OrganizationalApplicantPartyAddress address;
    @XmlElement(name = "DBAName")
    protected String dbaName;
    @XmlElement(name = "Contact")
    protected OrganizationContact contact;
    @XmlElement(name = "MarketingMailInd")
    protected String marketingMailInd;
    @XmlElement(name = "OrganizationType")
    protected String organizationType;
    @XmlElement(name = "RelationshipCode")
    protected String relationshipCode;
    @XmlElement(name = "Bank")
    protected List<Bank> bank;
    @XmlElement(name = "Co-Creditor")
    protected List<CoCreditor> coCreditor;
    @XmlElement(name = "BankruptcyRepossession")
    protected BankruptcyRepossession bankruptcyRepossession;
    @XmlElement(name = "MfgDealerInd")
    protected String mfgDealerInd;
    @XmlElement(name = "PrimaryDriverInd")
    protected String primaryDriverInd;
    @XmlElement(name = "YearsInBusines")
    protected BigInteger yearsInBusines;
    @XmlElement(name = "Privacy")
    protected List<Privacy> privacy;
    @XmlElement(name = "EstimatedUsage")
    protected BigDecimal estimatedUsage;
    @XmlElement(name = "RelationshipDescription")
    protected String relationshipDescription;
    @XmlElement(name = "IndustryType")
    protected String industryType;
    @XmlElement(name = "DateOfIncorporation")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfIncorporation;
    @XmlElement(name = "StateOfIncorporation")
    protected String stateOfIncorporation;
    @XmlElement(name = "InsuranceCompanyName")
    protected String insuranceCompanyName;
    @XmlElement(name = "Principal")
    protected List<PrincipalParty> principal;
    @XmlElement(name = "Accountant")
    protected AccountantParty accountant;
    @XmlElement(name = "FinancialPosition")
    protected FinancialPosition financialPosition;
    @XmlElement(name = "ResidenceType")
    protected String residenceType;
    @XmlElement(name = "PaymentAmount")
    protected OrganizationalApplicantPartyExtended.PaymentAmount paymentAmount;
    @XmlElement(name = "MortgageBalance")
    protected OrganizationalApplicantPartyExtended.MortgageBalance mortgageBalance;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the alternatePartyIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternatePartyIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternatePartyIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrganizationalPartyAlternatePartyId }
     * 
     * 
     */
    public List<OrganizationalPartyAlternatePartyId> getAlternatePartyIds() {
        if (alternatePartyIds == null) {
            alternatePartyIds = new ArrayList<OrganizationalPartyAlternatePartyId>();
        }
        return this.alternatePartyIds;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationalApplicantPartyAddress }
     *     
     */
    public OrganizationalApplicantPartyAddress getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationalApplicantPartyAddress }
     *     
     */
    public void setAddress(OrganizationalApplicantPartyAddress value) {
        this.address = value;
    }

    /**
     * Gets the value of the dbaName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDBAName() {
        return dbaName;
    }

    /**
     * Sets the value of the dbaName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDBAName(String value) {
        this.dbaName = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationContact }
     *     
     */
    public OrganizationContact getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationContact }
     *     
     */
    public void setContact(OrganizationContact value) {
        this.contact = value;
    }

    /**
     * Gets the value of the marketingMailInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingMailInd() {
        return marketingMailInd;
    }

    /**
     * Sets the value of the marketingMailInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingMailInd(String value) {
        this.marketingMailInd = value;
    }

    /**
     * Gets the value of the organizationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationType() {
        return organizationType;
    }

    /**
     * Sets the value of the organizationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationType(String value) {
        this.organizationType = value;
    }

    /**
     * Gets the value of the relationshipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * Sets the value of the relationshipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipCode(String value) {
        this.relationshipCode = value;
    }

    /**
     * Gets the value of the bank property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bank property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBank().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Bank }
     * 
     * 
     */
    public List<Bank> getBank() {
        if (bank == null) {
            bank = new ArrayList<Bank>();
        }
        return this.bank;
    }

    /**
     * Gets the value of the coCreditor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coCreditor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoCreditor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoCreditor }
     * 
     * 
     */
    public List<CoCreditor> getCoCreditor() {
        if (coCreditor == null) {
            coCreditor = new ArrayList<CoCreditor>();
        }
        return this.coCreditor;
    }

    /**
     * Gets the value of the bankruptcyRepossession property.
     * 
     * @return
     *     possible object is
     *     {@link BankruptcyRepossession }
     *     
     */
    public BankruptcyRepossession getBankruptcyRepossession() {
        return bankruptcyRepossession;
    }

    /**
     * Sets the value of the bankruptcyRepossession property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankruptcyRepossession }
     *     
     */
    public void setBankruptcyRepossession(BankruptcyRepossession value) {
        this.bankruptcyRepossession = value;
    }

    /**
     * Gets the value of the mfgDealerInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgDealerInd() {
        return mfgDealerInd;
    }

    /**
     * Sets the value of the mfgDealerInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgDealerInd(String value) {
        this.mfgDealerInd = value;
    }

    /**
     * Gets the value of the primaryDriverInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryDriverInd() {
        return primaryDriverInd;
    }

    /**
     * Sets the value of the primaryDriverInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryDriverInd(String value) {
        this.primaryDriverInd = value;
    }

    /**
     * Gets the value of the yearsInBusines property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getYearsInBusines() {
        return yearsInBusines;
    }

    /**
     * Sets the value of the yearsInBusines property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setYearsInBusines(BigInteger value) {
        this.yearsInBusines = value;
    }

    /**
     * Gets the value of the privacy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the privacy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrivacy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Privacy }
     * 
     * 
     */
    public List<Privacy> getPrivacy() {
        if (privacy == null) {
            privacy = new ArrayList<Privacy>();
        }
        return this.privacy;
    }

    /**
     * Gets the value of the estimatedUsage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEstimatedUsage() {
        return estimatedUsage;
    }

    /**
     * Sets the value of the estimatedUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEstimatedUsage(BigDecimal value) {
        this.estimatedUsage = value;
    }

    /**
     * Gets the value of the relationshipDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipDescription() {
        return relationshipDescription;
    }

    /**
     * Sets the value of the relationshipDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipDescription(String value) {
        this.relationshipDescription = value;
    }

    /**
     * Gets the value of the industryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndustryType() {
        return industryType;
    }

    /**
     * Sets the value of the industryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndustryType(String value) {
        this.industryType = value;
    }

    /**
     * Gets the value of the dateOfIncorporation property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfIncorporation() {
        return dateOfIncorporation;
    }

    /**
     * Sets the value of the dateOfIncorporation property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfIncorporation(XMLGregorianCalendar value) {
        this.dateOfIncorporation = value;
    }

    /**
     * Gets the value of the stateOfIncorporation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStateOfIncorporation() {
        return stateOfIncorporation;
    }

    /**
     * Sets the value of the stateOfIncorporation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStateOfIncorporation(String value) {
        this.stateOfIncorporation = value;
    }

    /**
     * Gets the value of the insuranceCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsuranceCompanyName() {
        return insuranceCompanyName;
    }

    /**
     * Sets the value of the insuranceCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsuranceCompanyName(String value) {
        this.insuranceCompanyName = value;
    }

    /**
     * Gets the value of the principal property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the principal property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrincipal().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PrincipalParty }
     * 
     * 
     */
    public List<PrincipalParty> getPrincipal() {
        if (principal == null) {
            principal = new ArrayList<PrincipalParty>();
        }
        return this.principal;
    }

    /**
     * Gets the value of the accountant property.
     * 
     * @return
     *     possible object is
     *     {@link AccountantParty }
     *     
     */
    public AccountantParty getAccountant() {
        return accountant;
    }

    /**
     * Sets the value of the accountant property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountantParty }
     *     
     */
    public void setAccountant(AccountantParty value) {
        this.accountant = value;
    }

    /**
     * Gets the value of the financialPosition property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialPosition }
     *     
     */
    public FinancialPosition getFinancialPosition() {
        return financialPosition;
    }

    /**
     * Sets the value of the financialPosition property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialPosition }
     *     
     */
    public void setFinancialPosition(FinancialPosition value) {
        this.financialPosition = value;
    }

    /**
     * Gets the value of the residenceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidenceType() {
        return residenceType;
    }

    /**
     * Sets the value of the residenceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidenceType(String value) {
        this.residenceType = value;
    }

    /**
     * Gets the value of the paymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationalApplicantPartyExtended.PaymentAmount }
     *     
     */
    public OrganizationalApplicantPartyExtended.PaymentAmount getPaymentAmount() {
        return paymentAmount;
    }

    /**
     * Sets the value of the paymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationalApplicantPartyExtended.PaymentAmount }
     *     
     */
    public void setPaymentAmount(OrganizationalApplicantPartyExtended.PaymentAmount value) {
        this.paymentAmount = value;
    }

    /**
     * Gets the value of the mortgageBalance property.
     * 
     * @return
     *     possible object is
     *     {@link OrganizationalApplicantPartyExtended.MortgageBalance }
     *     
     */
    public OrganizationalApplicantPartyExtended.MortgageBalance getMortgageBalance() {
        return mortgageBalance;
    }

    /**
     * Sets the value of the mortgageBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganizationalApplicantPartyExtended.MortgageBalance }
     *     
     */
    public void setMortgageBalance(OrganizationalApplicantPartyExtended.MortgageBalance value) {
        this.mortgageBalance = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MortgageBalance {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PaymentAmount {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
