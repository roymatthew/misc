
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The Participation component represents information about the buy rate charged to the buyer versus the lender approved approved buy rate and the dealer's associated reserve dollar amount.
 * 
 * <p>Java class for ParticipationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ParticipationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MaxParticipationPercentage" type="{http://www.starstandards.org/STAR}MaxParticipationPercentage" minOccurs="0"/&gt;
 *         &lt;element name="MaxParticipationAmount" type="{http://www.starstandards.org/STAR}MaxParticipationAmount" minOccurs="0"/&gt;
 *         &lt;element name="ParticipationSplitPercentage" type="{http://www.starstandards.org/STAR}ParticipationSplitPercentage" minOccurs="0"/&gt;
 *         &lt;element name="HoldbackAmount" type="{http://www.starstandards.org/STAR}HoldbackAmount" minOccurs="0"/&gt;
 *         &lt;element name="HoldbackCreditAmount" type="{http://www.starstandards.org/STAR}HoldbackCreditAmount" minOccurs="0"/&gt;
 *         &lt;element name="HoldbackAmountSpecific" type="{http://www.starstandards.org/STAR}HoldbackAmountSpecific" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParticipationType", propOrder = {
    "maxParticipationPercentage",
    "maxParticipationAmount",
    "participationSplitPercentage",
    "holdbackAmount",
    "holdbackCreditAmount",
    "holdbackAmountSpecific"
})
public class ParticipationType {

    @XmlElement(name = "MaxParticipationPercentage")
    protected MaxParticipationPercentage maxParticipationPercentage;
    @XmlElement(name = "MaxParticipationAmount")
    protected MaxParticipationAmount maxParticipationAmount;
    @XmlElement(name = "ParticipationSplitPercentage")
    protected ParticipationSplitPercentage participationSplitPercentage;
    @XmlElement(name = "HoldbackAmount")
    protected HoldbackAmount holdbackAmount;
    @XmlElement(name = "HoldbackCreditAmount")
    protected HoldbackCreditAmount holdbackCreditAmount;
    @XmlElement(name = "HoldbackAmountSpecific")
    protected HoldbackAmountSpecific holdbackAmountSpecific;

    /**
     * Gets the value of the maxParticipationPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link MaxParticipationPercentage }
     *     
     */
    public MaxParticipationPercentage getMaxParticipationPercentage() {
        return maxParticipationPercentage;
    }

    /**
     * Sets the value of the maxParticipationPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxParticipationPercentage }
     *     
     */
    public void setMaxParticipationPercentage(MaxParticipationPercentage value) {
        this.maxParticipationPercentage = value;
    }

    /**
     * Gets the value of the maxParticipationAmount property.
     * 
     * @return
     *     possible object is
     *     {@link MaxParticipationAmount }
     *     
     */
    public MaxParticipationAmount getMaxParticipationAmount() {
        return maxParticipationAmount;
    }

    /**
     * Sets the value of the maxParticipationAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link MaxParticipationAmount }
     *     
     */
    public void setMaxParticipationAmount(MaxParticipationAmount value) {
        this.maxParticipationAmount = value;
    }

    /**
     * Gets the value of the participationSplitPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link ParticipationSplitPercentage }
     *     
     */
    public ParticipationSplitPercentage getParticipationSplitPercentage() {
        return participationSplitPercentage;
    }

    /**
     * Sets the value of the participationSplitPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParticipationSplitPercentage }
     *     
     */
    public void setParticipationSplitPercentage(ParticipationSplitPercentage value) {
        this.participationSplitPercentage = value;
    }

    /**
     * Gets the value of the holdbackAmount property.
     * 
     * @return
     *     possible object is
     *     {@link HoldbackAmount }
     *     
     */
    public HoldbackAmount getHoldbackAmount() {
        return holdbackAmount;
    }

    /**
     * Sets the value of the holdbackAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link HoldbackAmount }
     *     
     */
    public void setHoldbackAmount(HoldbackAmount value) {
        this.holdbackAmount = value;
    }

    /**
     * Gets the value of the holdbackCreditAmount property.
     * 
     * @return
     *     possible object is
     *     {@link HoldbackCreditAmount }
     *     
     */
    public HoldbackCreditAmount getHoldbackCreditAmount() {
        return holdbackCreditAmount;
    }

    /**
     * Sets the value of the holdbackCreditAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link HoldbackCreditAmount }
     *     
     */
    public void setHoldbackCreditAmount(HoldbackCreditAmount value) {
        this.holdbackCreditAmount = value;
    }

    /**
     * Gets the value of the holdbackAmountSpecific property.
     * 
     * @return
     *     possible object is
     *     {@link HoldbackAmountSpecific }
     *     
     */
    public HoldbackAmountSpecific getHoldbackAmountSpecific() {
        return holdbackAmountSpecific;
    }

    /**
     * Sets the value of the holdbackAmountSpecific property.
     * 
     * @param value
     *     allowed object is
     *     {@link HoldbackAmountSpecific }
     *     
     */
    public void setHoldbackAmountSpecific(HoldbackAmountSpecific value) {
        this.holdbackAmountSpecific = value;
    }

}
