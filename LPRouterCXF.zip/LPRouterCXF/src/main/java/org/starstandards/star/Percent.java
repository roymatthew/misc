
package org.starstandards.star;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * Percent
 * 
 * <p>Java class for Percent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Percent"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Percent", propOrder = {
    "value"
})
@XmlSeeAlso({
    MaxParticipationPercentage.class,
    ContractRate.class,
    FrontEndAdvancePercentage.class,
    MaxFrontEndAdvancePercentage.class,
    MaxBackEndPercentage.class,
    ParticipationSplitPercentage.class,
    DealerReservePercentage.class,
    MinAnnualPercentageRate.class,
    MaxContractRate.class,
    LTVPercentage.class,
    MaxPaymentToIncomePercentage.class
})
public class Percent {

    @XmlValue
    protected BigDecimal value;

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValue(BigDecimal value) {
        this.value = value;
    }

}
