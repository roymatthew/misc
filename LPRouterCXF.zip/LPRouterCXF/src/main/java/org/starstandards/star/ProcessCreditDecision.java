
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for ProcessCreditDecision complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProcessCreditDecision"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ApplicationArea" type="{http://www.starstandards.org/STAR}ApplicationArea"/&gt;
 *         &lt;element name="DataArea" type="{http://www.starstandards.org/STAR}ProcessCreditDecisionDataArea"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="revision" type="{http://www.w3.org/2001/XMLSchema}string" default="1.0" /&gt;
 *       &lt;attribute name="release" type="{http://www.w3.org/2001/XMLSchema}string" default="8.1" /&gt;
 *       &lt;attribute name="environment" type="{http://www.w3.org/2001/XMLSchema}string" default="Production" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}language" default="en-US" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProcessCreditDecision", propOrder = {
    "applicationArea",
    "dataArea"
})
public class ProcessCreditDecision {

    @XmlElement(name = "ApplicationArea", required = true)
    protected ApplicationArea applicationArea;
    @XmlElement(name = "DataArea", required = true)
    protected ProcessCreditDecisionDataArea dataArea;
    @XmlAttribute(name = "revision")
    protected String revision;
    @XmlAttribute(name = "release")
    protected String release;
    @XmlAttribute(name = "environment")
    protected String environment;
    @XmlAttribute(name = "lang")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String lang;

    /**
     * Gets the value of the applicationArea property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationArea }
     *     
     */
    public ApplicationArea getApplicationArea() {
        return applicationArea;
    }

    /**
     * Sets the value of the applicationArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationArea }
     *     
     */
    public void setApplicationArea(ApplicationArea value) {
        this.applicationArea = value;
    }

    /**
     * Gets the value of the dataArea property.
     * 
     * @return
     *     possible object is
     *     {@link ProcessCreditDecisionDataArea }
     *     
     */
    public ProcessCreditDecisionDataArea getDataArea() {
        return dataArea;
    }

    /**
     * Sets the value of the dataArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessCreditDecisionDataArea }
     *     
     */
    public void setDataArea(ProcessCreditDecisionDataArea value) {
        this.dataArea = value;
    }

    /**
     * Gets the value of the revision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevision() {
        if (revision == null) {
            return "1.0";
        } else {
            return revision;
        }
    }

    /**
     * Sets the value of the revision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevision(String value) {
        this.revision = value;
    }

    /**
     * Gets the value of the release property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelease() {
        if (release == null) {
            return "8.1";
        } else {
            return release;
        }
    }

    /**
     * Sets the value of the release property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelease(String value) {
        this.release = value;
    }

    /**
     * Gets the value of the environment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnvironment() {
        if (environment == null) {
            return "Production";
        } else {
            return environment;
        }
    }

    /**
     * Sets the value of the environment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnvironment(String value) {
        this.environment = value;
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        if (lang == null) {
            return "en-US";
        } else {
            return lang;
        }
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

}
