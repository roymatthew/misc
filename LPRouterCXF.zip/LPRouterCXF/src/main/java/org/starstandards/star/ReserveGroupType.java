
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The Reserve Group component represents information related to the Dealer's Reserve.
 * 
 * <p>Java class for ReserveGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReserveGroupType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Reserve" type="{http://www.starstandards.org/STAR}ReserveType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReserveGroupType", propOrder = {
    "reserve"
})
public class ReserveGroupType {

    @XmlElement(name = "Reserve", required = true)
    protected List<ReserveType> reserve;

    /**
     * Gets the value of the reserve property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reserve property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReserve().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReserveType }
     * 
     * 
     */
    public List<ReserveType> getReserve() {
        if (reserve == null) {
            reserve = new ArrayList<ReserveType>();
        }
        return this.reserve;
    }

}
