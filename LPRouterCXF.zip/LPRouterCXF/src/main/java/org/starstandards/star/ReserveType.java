
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The Reserve component represents information related to the Dealer's Reserve.
 * 
 * <p>Java class for ReserveType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReserveType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DealerReserveAmount" type="{http://www.starstandards.org/STAR}DealerReserveAmount" minOccurs="0"/&gt;
 *         &lt;element name="DealerReservePercentage" type="{http://www.starstandards.org/STAR}DealerReservePercentage" minOccurs="0"/&gt;
 *         &lt;element name="DealerReserveType" type="{http://www.starstandards.org/STAR}DealerReserveType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReserveType", propOrder = {
    "dealerReserveAmount",
    "dealerReservePercentage",
    "dealerReserveType"
})
public class ReserveType {

    @XmlElement(name = "DealerReserveAmount")
    protected DealerReserveAmount dealerReserveAmount;
    @XmlElement(name = "DealerReservePercentage")
    protected DealerReservePercentage dealerReservePercentage;
    @XmlElement(name = "DealerReserveType")
    protected String dealerReserveType;

    /**
     * Gets the value of the dealerReserveAmount property.
     * 
     * @return
     *     possible object is
     *     {@link DealerReserveAmount }
     *     
     */
    public DealerReserveAmount getDealerReserveAmount() {
        return dealerReserveAmount;
    }

    /**
     * Sets the value of the dealerReserveAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DealerReserveAmount }
     *     
     */
    public void setDealerReserveAmount(DealerReserveAmount value) {
        this.dealerReserveAmount = value;
    }

    /**
     * Gets the value of the dealerReservePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link DealerReservePercentage }
     *     
     */
    public DealerReservePercentage getDealerReservePercentage() {
        return dealerReservePercentage;
    }

    /**
     * Sets the value of the dealerReservePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DealerReservePercentage }
     *     
     */
    public void setDealerReservePercentage(DealerReservePercentage value) {
        this.dealerReservePercentage = value;
    }

    /**
     * Gets the value of the dealerReserveType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealerReserveType() {
        return dealerReserveType;
    }

    /**
     * Sets the value of the dealerReserveType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealerReserveType(String value) {
        this.dealerReserveType = value;
    }

}
