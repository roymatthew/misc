
package org.starstandards.star;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The StatedIncome component represents information about the stated income of the buyer from an original credit application.
 * 
 * <p>Java class for StatedIncomeGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatedIncomeGroupType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="StatedIncome" type="{http://www.starstandards.org/STAR}StatedIncomeType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatedIncomeGroupType", propOrder = {
    "statedIncome"
})
public class StatedIncomeGroupType {

    @XmlElement(name = "StatedIncome", required = true)
    protected List<StatedIncomeType> statedIncome;

    /**
     * Gets the value of the statedIncome property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statedIncome property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatedIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatedIncomeType }
     * 
     * 
     */
    public List<StatedIncomeType> getStatedIncome() {
        if (statedIncome == null) {
            statedIncome = new ArrayList<StatedIncomeType>();
        }
        return this.statedIncome;
    }

}
