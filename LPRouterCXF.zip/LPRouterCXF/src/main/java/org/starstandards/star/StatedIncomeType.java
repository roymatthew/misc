
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The StatedIncome component represents information about the stated income of the buyer from an original credit application.
 * 
 * <p>Java class for StatedIncomeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatedIncomeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IncomeType" type="{http://www.starstandards.org/STAR}IncomeType" minOccurs="0"/&gt;
 *         &lt;element name="IncomeAmount" type="{http://www.starstandards.org/STAR}IncomeAmount" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatedIncomeType", propOrder = {
    "incomeType",
    "incomeAmount"
})
public class StatedIncomeType {

    @XmlElement(name = "IncomeType")
    protected String incomeType;
    @XmlElement(name = "IncomeAmount")
    protected IncomeAmount incomeAmount;

    /**
     * Gets the value of the incomeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeType() {
        return incomeType;
    }

    /**
     * Sets the value of the incomeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeType(String value) {
        this.incomeType = value;
    }

    /**
     * Gets the value of the incomeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link IncomeAmount }
     *     
     */
    public IncomeAmount getIncomeAmount() {
        return incomeAmount;
    }

    /**
     * Sets the value of the incomeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link IncomeAmount }
     *     
     */
    public void setIncomeAmount(IncomeAmount value) {
        this.incomeAmount = value;
    }

}
