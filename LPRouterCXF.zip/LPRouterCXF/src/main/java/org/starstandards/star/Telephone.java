
package org.starstandards.star;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for Telephone complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Telephone"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
 *       &lt;attribute name="desc" use="required" type="{http://www.starstandards.org/STAR}telephoneDescription" /&gt;
 *       &lt;attribute name="exten" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Telephone", propOrder = {
    "value"
})
public class Telephone {

    @XmlValue
    protected String value;
    @XmlAttribute(name = "desc", required = true)
    protected TelephoneDescription desc;
    @XmlAttribute(name = "exten")
    protected String exten;

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the value of the desc property.
     * 
     * @return
     *     possible object is
     *     {@link TelephoneDescription }
     *     
     */
    public TelephoneDescription getDesc() {
        return desc;
    }

    /**
     * Sets the value of the desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link TelephoneDescription }
     *     
     */
    public void setDesc(TelephoneDescription value) {
        this.desc = value;
    }

    /**
     * Gets the value of the exten property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExten() {
        return exten;
    }

    /**
     * Sets the value of the exten property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExten(String value) {
        this.exten = value;
    }

}
