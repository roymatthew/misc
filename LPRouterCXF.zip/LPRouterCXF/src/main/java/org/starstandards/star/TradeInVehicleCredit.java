
package org.starstandards.star;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TradeInVehicleCredit complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TradeInVehicleCredit"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Model" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ModelYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ModelDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Make" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SaleClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SalespersonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TradeInInd" type="{http://www.starstandards.org/STAR}Indicator" minOccurs="0"/&gt;
 *         &lt;element name="PurchaseDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="TradeInFinancing" type="{http://www.starstandards.org/STAR}TradeInFinancing" minOccurs="0"/&gt;
 *         &lt;element name="OwnedType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SalesStockNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Option" type="{http://www.starstandards.org/STAR}Option" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Pricing" type="{http://www.starstandards.org/STAR}Pricing" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DeliveryMileage" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
 *                 &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}uom" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BodyStyle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TradeInVehicleCredit", propOrder = {
    "model",
    "modelYear",
    "modelDescription",
    "make",
    "saleClass",
    "salespersonName",
    "tradeInInd",
    "purchaseDate",
    "tradeInFinancing",
    "ownedType",
    "salesStockNumber",
    "option",
    "pricing",
    "deliveryMileage",
    "bodyStyle"
})
public class TradeInVehicleCredit {

    @XmlElement(name = "Model")
    protected String model;
    @XmlElement(name = "ModelYear")
    protected String modelYear;
    @XmlElement(name = "ModelDescription")
    protected String modelDescription;
    @XmlElement(name = "Make")
    protected String make;
    @XmlElement(name = "SaleClass")
    protected String saleClass;
    @XmlElement(name = "SalespersonName")
    protected String salespersonName;
    @XmlElement(name = "TradeInInd")
    protected String tradeInInd;
    @XmlElement(name = "PurchaseDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar purchaseDate;
    @XmlElement(name = "TradeInFinancing")
    protected TradeInFinancing tradeInFinancing;
    @XmlElement(name = "OwnedType")
    protected String ownedType;
    @XmlElement(name = "SalesStockNumber")
    protected String salesStockNumber;
    @XmlElement(name = "Option")
    protected List<Option> option;
    @XmlElement(name = "Pricing")
    protected List<Pricing> pricing;
    @XmlElement(name = "DeliveryMileage")
    protected TradeInVehicleCredit.DeliveryMileage deliveryMileage;
    @XmlElement(name = "BodyStyle")
    protected String bodyStyle;

    /**
     * Gets the value of the model property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the value of the model property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModel(String value) {
        this.model = value;
    }

    /**
     * Gets the value of the modelYear property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the value of the modelYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelYear(String value) {
        this.modelYear = value;
    }

    /**
     * Gets the value of the modelDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelDescription() {
        return modelDescription;
    }

    /**
     * Sets the value of the modelDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelDescription(String value) {
        this.modelDescription = value;
    }

    /**
     * Gets the value of the make property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMake() {
        return make;
    }

    /**
     * Sets the value of the make property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMake(String value) {
        this.make = value;
    }

    /**
     * Gets the value of the saleClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaleClass() {
        return saleClass;
    }

    /**
     * Sets the value of the saleClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaleClass(String value) {
        this.saleClass = value;
    }

    /**
     * Gets the value of the salespersonName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalespersonName() {
        return salespersonName;
    }

    /**
     * Sets the value of the salespersonName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalespersonName(String value) {
        this.salespersonName = value;
    }

    /**
     * Gets the value of the tradeInInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTradeInInd() {
        return tradeInInd;
    }

    /**
     * Sets the value of the tradeInInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTradeInInd(String value) {
        this.tradeInInd = value;
    }

    /**
     * Gets the value of the purchaseDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPurchaseDate() {
        return purchaseDate;
    }

    /**
     * Sets the value of the purchaseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPurchaseDate(XMLGregorianCalendar value) {
        this.purchaseDate = value;
    }

    /**
     * Gets the value of the tradeInFinancing property.
     * 
     * @return
     *     possible object is
     *     {@link TradeInFinancing }
     *     
     */
    public TradeInFinancing getTradeInFinancing() {
        return tradeInFinancing;
    }

    /**
     * Sets the value of the tradeInFinancing property.
     * 
     * @param value
     *     allowed object is
     *     {@link TradeInFinancing }
     *     
     */
    public void setTradeInFinancing(TradeInFinancing value) {
        this.tradeInFinancing = value;
    }

    /**
     * Gets the value of the ownedType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwnedType() {
        return ownedType;
    }

    /**
     * Sets the value of the ownedType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwnedType(String value) {
        this.ownedType = value;
    }

    /**
     * Gets the value of the salesStockNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesStockNumber() {
        return salesStockNumber;
    }

    /**
     * Sets the value of the salesStockNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesStockNumber(String value) {
        this.salesStockNumber = value;
    }

    /**
     * Gets the value of the option property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the option property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOption().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Option }
     * 
     * 
     */
    public List<Option> getOption() {
        if (option == null) {
            option = new ArrayList<Option>();
        }
        return this.option;
    }

    /**
     * Gets the value of the pricing property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pricing property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPricing().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Pricing }
     * 
     * 
     */
    public List<Pricing> getPricing() {
        if (pricing == null) {
            pricing = new ArrayList<Pricing>();
        }
        return this.pricing;
    }

    /**
     * Gets the value of the deliveryMileage property.
     * 
     * @return
     *     possible object is
     *     {@link TradeInVehicleCredit.DeliveryMileage }
     *     
     */
    public TradeInVehicleCredit.DeliveryMileage getDeliveryMileage() {
        return deliveryMileage;
    }

    /**
     * Sets the value of the deliveryMileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link TradeInVehicleCredit.DeliveryMileage }
     *     
     */
    public void setDeliveryMileage(TradeInVehicleCredit.DeliveryMileage value) {
        this.deliveryMileage = value;
    }

    /**
     * Gets the value of the bodyStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBodyStyle() {
        return bodyStyle;
    }

    /**
     * Sets the value of the bodyStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBodyStyle(String value) {
        this.bodyStyle = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;integer"&gt;
     *       &lt;attribute name="uom" type="{http://www.starstandards.org/STAR}uom" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DeliveryMileage {

        @XmlValue
        protected BigInteger value;
        @XmlAttribute(name = "uom")
        protected Uom uom;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setValue(BigInteger value) {
            this.value = value;
        }

        /**
         * Gets the value of the uom property.
         * 
         * @return
         *     possible object is
         *     {@link Uom }
         *     
         */
        public Uom getUom() {
            return uom;
        }

        /**
         * Sets the value of the uom property.
         * 
         * @param value
         *     allowed object is
         *     {@link Uom }
         *     
         */
        public void setUom(Uom value) {
            this.uom = value;
        }

    }

}
