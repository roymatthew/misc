
package org.starstandards.star;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for VehiclePricing complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VehiclePricing"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="VehiclePrice"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
 *                 &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PriceExplanation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehiclePricingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PricingTypeSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehiclePricingTypeSource" type="{http://www.starstandards.org/STAR}VehiclePricingTypeSource" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehiclePricing", propOrder = {
    "vehiclePrice",
    "priceExplanation",
    "vehiclePricingType",
    "pricingTypeSource",
    "vehiclePricingTypeSource"
})
public class VehiclePricing {

    @XmlElement(name = "VehiclePrice", required = true)
    protected VehiclePricing.VehiclePrice vehiclePrice;
    @XmlElement(name = "PriceExplanation")
    protected String priceExplanation;
    @XmlElement(name = "VehiclePricingType")
    protected String vehiclePricingType;
    @XmlElement(name = "PricingTypeSource")
    protected String pricingTypeSource;
    @XmlElement(name = "VehiclePricingTypeSource")
    protected VehiclePricingTypeSource vehiclePricingTypeSource;

    /**
     * Gets the value of the vehiclePrice property.
     * 
     * @return
     *     possible object is
     *     {@link VehiclePricing.VehiclePrice }
     *     
     */
    public VehiclePricing.VehiclePrice getVehiclePrice() {
        return vehiclePrice;
    }

    /**
     * Sets the value of the vehiclePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehiclePricing.VehiclePrice }
     *     
     */
    public void setVehiclePrice(VehiclePricing.VehiclePrice value) {
        this.vehiclePrice = value;
    }

    /**
     * Gets the value of the priceExplanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriceExplanation() {
        return priceExplanation;
    }

    /**
     * Sets the value of the priceExplanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriceExplanation(String value) {
        this.priceExplanation = value;
    }

    /**
     * Gets the value of the vehiclePricingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehiclePricingType() {
        return vehiclePricingType;
    }

    /**
     * Sets the value of the vehiclePricingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehiclePricingType(String value) {
        this.vehiclePricingType = value;
    }

    /**
     * Gets the value of the pricingTypeSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPricingTypeSource() {
        return pricingTypeSource;
    }

    /**
     * Sets the value of the pricingTypeSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPricingTypeSource(String value) {
        this.pricingTypeSource = value;
    }

    /**
     * Gets the value of the vehiclePricingTypeSource property.
     * 
     * @return
     *     possible object is
     *     {@link VehiclePricingTypeSource }
     *     
     */
    public VehiclePricingTypeSource getVehiclePricingTypeSource() {
        return vehiclePricingTypeSource;
    }

    /**
     * Sets the value of the vehiclePricingTypeSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehiclePricingTypeSource }
     *     
     */
    public void setVehiclePricingTypeSource(VehiclePricingTypeSource value) {
        this.vehiclePricingTypeSource = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;decimal"&gt;
     *       &lt;attribute name="currency" use="required" type="{http://www.starstandards.org/STAR}currency" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class VehiclePrice {

        @XmlValue
        protected BigDecimal value;
        @XmlAttribute(name = "currency", required = true)
        protected Currency currency;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setValue(BigDecimal value) {
            this.value = value;
        }

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link Currency }
         *     
         */
        public Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link Currency }
         *     
         */
        public void setCurrency(Currency value) {
            this.currency = value;
        }

    }

}
