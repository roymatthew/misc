@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.starstandards.org/STAR", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.starstandards.star;
