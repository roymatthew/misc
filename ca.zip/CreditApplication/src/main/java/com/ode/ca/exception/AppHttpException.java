package com.ode.ca.exception;


public class AppHttpException extends AppException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Holds the error stream if the connection failed 
	// but the server sent useful data
	String soapFaultMsg = null;
	int statusCode;
		
	public AppHttpException(String msg, String context, String pgm) {
		super(msg, context, pgm);
	}

	/**
	 * @param msg
	 * @param e
	 * @param context
	 * @param pgm
	 * @param tracemesg
	 */
	public AppHttpException(String str1, Exception e, String str2, String pgm, String str3) {
		super(str1, e, str2, pgm, str3);
	}
	
	public AppHttpException(String msg, Exception e, String context, String pgm, String tracemsg,String faultmsg) {
		super(msg, e, context, pgm, tracemsg);
		soapFaultMsg=faultmsg;
	}
	/**
	 * @return Returns the soapFaultMsgStream.
	 */
	public String getSoapFaultMsg() {
		return soapFaultMsg;
	}
	/**
	 * @param soapFaultMsgStream The soapFaultMsgStream to set.
	 */
/*	public void setSoapFaultMsg(InputStream soapFaultMsgStream) {
		this.soapFaultMsgStream = soapFaultMsgStream;
	}*/
	/**
	 * @return Returns the statusCode.
	 */
	public int getStatusCode() {
		return statusCode;
	}
	/**
	 * @param statusCode The statusCode to set.
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
}