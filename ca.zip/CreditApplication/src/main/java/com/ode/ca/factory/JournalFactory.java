/**
 * 
 */
package com.ode.ca.factory;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.ca.util.Constants;
import com.ode.ca.vo.JournalObjectVO;
import com.ode.ca.vo.CaContextVO;
import com.ode.dlr.util.AppMessage;
import com.ode.dlr.util.EncryptionException;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.vo.AuditJournalVO;
import com.ode.persistence.vo.CreditJournalVO;

/**
 * @author rmathew
 *
 */
public class JournalFactory {

	private static final Logger logger = LogManager.getLogger(JournalFactory.class);

	private JournalFactory() {
		super();
	}

	public static JournalObjectVO createJournalObject(final String transType, final AppMessage appMessage,
			final String xmlString) {
		JournalObjectVO journalObject = new JournalObjectVO();
		journalObject.setTransType(transType);
		journalObject.setTimestamp((new java.sql.Timestamp(new Date().getTime())));
		journalObject.setXmlData(xmlString);
		journalObject.setAppMsg(appMessage);
		return journalObject;
	}

	/**
	 * @param journalObject
	 * @param contractValidation
	 * @return
	 * @throws EncryptionException
	 */
	public static CreditJournalVO createCreditJournal(final JournalObjectVO journalObject,
			final CaContextVO caContextVO) throws EncryptionException {

		logger.debug(
				"Enter createCreditJournal() method of JournalFactory. Transtype: " + journalObject.getTransType());

		CreditJournalVO creditJournalVO = new CreditJournalVO();
		String crDataXml = journalObject.getXmlData();
		String keyId = "";
		List<String> encryptedItems = EncryptionUtils.encryptText(crDataXml);
		keyId = encryptedItems.get(0);
		String encryptedXML = encryptedItems.get(1);
		String auditData = journalObject.getAppMessage().getMessageID() + " - "
				+ journalObject.getAppMessage().getMessage();
		if (auditData.length() > 200) {
			auditData = auditData.substring(0, 199);
		}

		String transType = journalObject.getTransType();
		String transactionId = caContextVO.getRoKey() != null ? caContextVO.getRoKey()
				: caContextVO.getDocumentId() == null ? "" : caContextVO.getDocumentId();
		String userId = caContextVO.getUserId() != null ? caContextVO.getUserId() : "";
		String deliverySource = caContextVO.getDeliverySource() == null ? ""
				: caContextVO.getDeliverySource();
		String applicationSource = caContextVO.getApplicationSource().length() > 2
				? caContextVO.getApplicationSource().substring(0, 2)
				: caContextVO.getApplicationSource();
		String financeType = caContextVO.getFinanceType() == null ? "" : caContextVO.getFinanceType();
		String appDealNumber = caContextVO.getAdpDealNo() == null ? "" : caContextVO.getAdpDealNo();
		String dmsId = caContextVO.getDealerInfo().getDspId() == null ? ""
				: caContextVO.getDealerInfo().getDspId();

		if (caContextVO.getTransType() != null) {
			if (caContextVO.getTransType().equals(Constants.TRANS_TYPE_ID_IN)
					&& transType.equals(Constants.TRANS_TYPE_APP_OUT)) {
				transType = Constants.TRANS_TYPE_ID_OUT;
			}
			if (caContextVO.getTransType().equals(Constants.TRANS_TYPE_ID_IN)
					&& transType.equals(Constants.TRANS_TYPE_APP_CONF_IN)) {
				transType = Constants.TRANS_TYPE_ID_CONF_IN;
			}
			if (caContextVO.getTransType().equals(Constants.TRANS_TYPE_ID_IN)
					&& transType.equals(Constants.TRANS_TYPE_APP_CONF_OUT)) {
				transType = Constants.TRANS_TYPE_ID_CONF_OUT;
			}
		}

		String sequenceNo = "";

		creditJournalVO.setSystemId(caContextVO.getDealerInfo().getSystemId());
		creditJournalVO.setDealerId(caContextVO.getDealerInfo().getDealerId());
		creditJournalVO.setPartnerId(caContextVO.getPartnerInfo().getLenderId());
		creditJournalVO.setTransDateTime(journalObject.getTimestamp());
		creditJournalVO.setTransType(transType);
		// TODO set transflag dynamically
		creditJournalVO.setTransFlag("N");
		creditJournalVO.setPartnerDealNo(
				caContextVO.getPartnerDealNumber() == null ? "" : caContextVO.getPartnerDealNumber());
		creditJournalVO.setCrDataXml(encryptedXML);
		creditJournalVO.setAccountId(caContextVO.getPartnerInfo().getLenderAccountId());
		creditJournalVO.setTransactionId(transactionId);
		creditJournalVO.setUserId(userId);
		// delivery source
		creditJournalVO.setDeliverySource(deliverySource);
		// application source
		creditJournalVO.setApplicationSource(applicationSource);
		// creditJournalVO.setApplType(caContextVO.getContractValidation().getApplicationType());
		creditJournalVO.setApplType(financeType);
		// finance type
		creditJournalVO.setFinanceInstitution(financeType);
		// adp deal no
		creditJournalVO.setAdpDealNo(appDealNumber);
		// dspid
		creditJournalVO.setDspId(caContextVO.getDealerInfo().getDspId());
		// sequence no
		creditJournalVO.setSequenceNo(sequenceNo);
		// dealid
		creditJournalVO.setDealId(caContextVO.getContractValidation().getDealId());
		// sequence id
		creditJournalVO.setSequenceId(caContextVO.getContractValidation().getSequenceId());
		//
		creditJournalVO.setAuditData(auditData);
		// keyid
		creditJournalVO.setEncryptionKeyId(keyId);

		return creditJournalVO;

	}


}
