package com.ode.ca.factory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;
import org.w3c.dom.Document;

import com.ode.ca.vo.CreditDecisionDetailVO;
import com.ode.persistence.vo.CreditDecisionVO;

/**
 * @author rmathew
 *
 */
@Component
@PropertySource("classpath:cdxpath.properties")
public class VOFactory {

	private static final Logger logger = LogManager.getLogger(VOFactory.class);

	@Autowired
	private Environment env;

	/**
	 * @param pccDoc
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws TransformerException
	 */
	public CreditDecisionDetailVO createCreditDecisionDetailVO(final Document pccDoc)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, TransformerException {

		logger.debug("Entered createCreditDecisionDetailVO() method of VOFactory class");
		CreditDecisionDetailVO creditDecisionVO = new CreditDecisionDetailVO();
		Method[] methods = ReflectionUtils.getAllDeclaredMethods(CreditDecisionDetailVO.class);
		int len = methods.length;
		for (int i = 0; i < len; i++) {
			String setterProperty = null;
			if (methods[i].getName().startsWith("set")) {
				String parameterType = methods[i].getParameterTypes()[0].getTypeName();
				setterProperty = methods[i].getName().substring(3).toLowerCase();
				logger.debug("setterProperty = {},  type = {}", setterProperty, parameterType);
				Object obj = evaluateXpathValue(pccDoc, setterProperty);
				if (null != obj) {
					String xpathValue = (String) obj;
					if (StringUtils.isNotBlank(xpathValue)) {
						xpathValue = xpathValue.trim();
						if ("java.lang.String".equals(parameterType)) {
							methods[i].invoke(creditDecisionVO, xpathValue);
						} else if ("java.math.BigDecimal".equals(parameterType)) {
							BigDecimal val = new BigDecimal(xpathValue);
							methods[i].invoke(creditDecisionVO, val);
						} else if ("short".equals(parameterType)) {
							short val = Short.parseShort(xpathValue);
							methods[i].invoke(creditDecisionVO, val);
						} else if ("java.sql.Timestamp".equals(parameterType)) {
							Timestamp ts = null;
							if (StringUtils.isNumeric(xpathValue)) {
								ts = new Timestamp(Long.valueOf(xpathValue).longValue());
							} else {
								try {
									Date date = DateUtils.parseDate(xpathValue, Locale.US,
											new String[] { "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy/MM/dd'T'HH:mm:ss",
													"dd/MM/yyyy'T'HH:mm:ss" });
									ts = new Timestamp(date.getTime());
								} catch (final ParseException e) {
									logger.debug("Caught exception when parsing date: {}", xpathValue, e);
								}
							}
							methods[i].invoke(creditDecisionVO, ts);
						} else if ("boolean".equals(parameterType)) {
							short val = Short.parseShort(xpathValue);
							boolean booleanVal = val == 0 ? false : true;
							methods[i].invoke(creditDecisionVO, booleanVal);
						}
					}
				}

			}
		}

		creditDecisionVO.setCreatedTs(new Timestamp(System.currentTimeMillis()));
		logger.debug("Exiting reateCreditDecisionDetailVO() method of VOFactory class");

		return creditDecisionVO;
	}

	/**
	 * @param pccDoc
	 * @param setterProperty
	 * @return
	 * @throws TransformerException
	 */
	private Object evaluateXpathValue(final Document pccDoc, final String setterProperty) throws TransformerException {
		logger.debug("Entered evaluateXpathValue method of VOFactory class. setterProperty: {}", setterProperty);
		String xpath = env.getProperty(setterProperty);
		if (null == setterProperty || null == xpath) {
			logger.debug("Could not find xpath for setterProperty: {}", setterProperty);
			return null;
		}
		String xpathValue = XPathAPI.eval(pccDoc, xpath).toString();
		logger.debug("XPath: {}, Value: {}", xpath, xpathValue);
		return xpathValue;
	}

	/**
	 * @param creditDecisionDetailVO
	 * @param pccDoc
	 * @return
	 * @throws TransformerException
	 */
	public CreditDecisionVO createCreditDecisionVO(final CreditDecisionDetailVO creditDecisionDetailVO,
			final Document pccDoc) throws TransformerException {
		logger.debug("Entered createCreditDecisionVO() method of VOFactory class. creditDecisionDetailVO: {}", creditDecisionDetailVO);
		CreditDecisionVO creditDecisionVO = new CreditDecisionVO();
		String buyerDobStr = (String) evaluateXpathValue(pccDoc, "buyerdob");
		if (StringUtils.isNotBlank(buyerDobStr)) {
			try {
				Date dob = DateUtils.parseDate(buyerDobStr, "yyyy-MM-dd");
				creditDecisionVO.setBuyerDob(dob);
			} catch (final Exception e) {
				logger.debug("Exception when trying to parse buyer DOB. Given DOB: {}", buyerDobStr, e);
			}
		}

		// convert string dob to date
		// set dob to creditDecisionVO
		creditDecisionVO.setAmountFinanced(creditDecisionDetailVO.getAmountFinanced());
		creditDecisionVO.setApplicationNumber(creditDecisionDetailVO.getApplicationNumber());
		creditDecisionVO.setApplicationStatus(creditDecisionDetailVO.getApplicationStatus());
		creditDecisionVO.setApplicationType(creditDecisionDetailVO.getApplicationType());
		creditDecisionVO.setBuyerFirstName(creditDecisionDetailVO.getBuyerFirstName());
		creditDecisionVO.setBuyerLastName(creditDecisionDetailVO.getBuyerLastName());
		// creditDecisionVO.setBuyerMiddleName(buyerMiddleName);
		creditDecisionVO.setBuyerSSN(creditDecisionDetailVO.getBuyerSSN() == null? null : creditDecisionDetailVO.getBuyerSSN().getBytes());
		// creditDecisionVO.setCaExpirationDate(caExpirationDate);
		// creditDecisionVO.setCdKey(cdKey);
		creditDecisionVO.setCobuyer1FirstName(creditDecisionDetailVO.getCoBuyerFirstName());
		creditDecisionVO.setCobuyer1LastName(creditDecisionDetailVO.getCoBuyerLastName());
		// creditDecisionVO.setCobuyer1MiddleName(cobuyer1MiddleName);
		creditDecisionVO.setCobuyer1SSN(creditDecisionDetailVO.getCoBuyerSSN() == null ? null : creditDecisionDetailVO.getCoBuyerSSN().getBytes());
		creditDecisionVO.setContractTerm(creditDecisionDetailVO.getTerm() == null ? "" : String.valueOf(creditDecisionDetailVO.getTerm()));
		creditDecisionVO.setCreatedBy(String.valueOf(creditDecisionDetailVO.getCreatedBy()));
		creditDecisionVO.setCreateTs(creditDecisionDetailVO.getCreatedTs());
		// creditDecisionVO.setDealerBuyRate(creditDecisionDetailVO.get);
		creditDecisionVO.setDecisionDt(creditDecisionDetailVO.getDecisionTs());
		creditDecisionVO.setDownPaymentAmount(creditDecisionDetailVO.getDownpaymentAmount());
		// creditDecisionVO.setEncryptionKeyId(encryptionKeyId);
		creditDecisionVO.setFinType(creditDecisionDetailVO.getFinanceType());
		// creditDecisionVO.setInvoiceAmount(creditDecisionDetailVO.get);
		if (StringUtils.isNotBlank(creditDecisionDetailVO.getLtv())) {
			BigDecimal ltv = new BigDecimal(creditDecisionDetailVO.getLtv());
			creditDecisionVO.setLoanToValue(ltv);
		}
		// creditDecisionVO.setMaxMarkup(maxMarkup);
		creditDecisionVO.setNetTradeAmount(creditDecisionDetailVO.getNetTradeAmount());
		String strCountCoApplicant = (String) evaluateXpathValue(pccDoc, "countofcoapplicants");
		if (StringUtils.isNotBlank(strCountCoApplicant) && NumberUtils.isDigits(strCountCoApplicant)) {
			try {
				int count = Integer.parseInt(strCountCoApplicant);
				creditDecisionVO.setNoOfCobuyer(count);
			} catch (NumberFormatException e) {
				logger.error("Could not obtain count of co-applicants. Count evaluated from document: "
						+ strCountCoApplicant);
			}
		}

		creditDecisionVO.setPaymentAmount(creditDecisionDetailVO.getPaymentAmount());
		creditDecisionVO.setVehMake(creditDecisionDetailVO.getMake());
		creditDecisionVO.setVehModel(creditDecisionDetailVO.getModel());
		creditDecisionVO.setVehSaleClass(creditDecisionDetailVO.getSalesClass());
		creditDecisionVO.setVehYear(creditDecisionDetailVO.getModelYear());
		creditDecisionVO.setVin(creditDecisionDetailVO.getVin());
		return creditDecisionVO;

	}

}
