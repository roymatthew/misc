package com.ode.ca.messaging;

import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.ode.ca.service.CaDecisionExportService;
import com.ode.ca.vo.CreditDecisionWrapperVO;

public class CAMessageListener implements MessageListener {

	private static final Logger logger = LogManager.getLogger(CAMessageListener.class);

	@Autowired
	private CaDecisionExportService caDecisionExportService;

	@Override
	public void onMessage(Message message) {
		ThreadContext.put("uuid", UUID.randomUUID().toString());
		logger.debug("Entered onMessage()..Received Message: " + message);
		final TextMessage textMessage = (TextMessage) message;
		String xmlString = null;
		try {
			xmlString = textMessage.getText();
			if (StringUtils.isNotBlank(xmlString)) {
				logger.debug("Extracted XML String from the message. XML received: {}", xmlString);
			}
			textMessage.acknowledge();
		} catch (JMSException e) {
			logger.error(e);
		}
		try {
			logger.debug("Calling CaDecisionExportService passing XML String.");
			CreditDecisionWrapperVO CreditDecisionWrapperVO = caDecisionExportService
					.processCaDecisionExport(xmlString);
		} catch (final Exception e) {
			logger.error(e);
		} finally {
			ThreadContext.clearAll();
		}
	}

}
