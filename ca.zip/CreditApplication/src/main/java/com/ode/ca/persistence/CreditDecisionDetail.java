package com.ode.ca.persistence;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rmathew
 *
 */
@Entity
@Table(name = "[CreditDecision]")
public class CreditDecisionDetail implements Serializable {
	
	/**
	 * Generated Serial ID.
	 */
	private static final long serialVersionUID = -1323736811443930524L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private BigInteger creditDecisionId;
	@Column(name = "DmsDealerId")
	private String dmsDealerId;
	@Column(name = "LenderDealerId")
	private String lenderDealerId;
	@Column(name = "DmsDealNum")
	private String dmsDealNum;
	@Column(name = "LenderId")
	private String lenderId;
	@Column(name = "DeDealId")
	private String deDealId;
	@Column(name = "SequenceId")
	private String sequenceId;
	@Column(name = "R1lenderId")
	private String r1lenderId;
	@Column(name = "ConversationId")
	private String conversationId;
	@Column(name = "R1SequenceNum")
	private String r1SequenceNum;
	@Column(name = "StatusTs")
	private Timestamp statusTs;
	@Column(name = "SubmittedTs")
	private Timestamp submittedTs;
	@Column(name = "DecisionTs")
	private Timestamp decisionTs;
	@Column(name = "VIN")
	private String  vin;
	@Column(name = "BuyerSSN")
	private String buyerSSN;
	@Column(name = "BuyerFirstName")
	private String buyerFirstName;
	@Column(name = "BuyerLastName")
	private String buyerLastName;
	@Column(name = "BuyerApplicationAddressLine")
	private String buyerApplicationAddressLine;
	@Column(name = "BuyerApplicationAddressCity")
	private String buyerApplicationAddressCity;
	@Column(name = "BuyerApplicationAddressState")
	private String buyerApplicationAddressState;
	@Column(name = "BuyerApplicationAddressZipCode")
	private String buyerApplicationAddressZipCode;
	@Column(name = "CoBuyerSSN")
	private String coBuyerSSN;
	@Column(name = "CobuyerFirstName")
	private String coBuyerFirstName;
	@Column(name = "CobuyerLastName")
	private String coBuyerLastName;
	@Column(name = "CobuyerApplicationAddressLine")
	private String coBuyerApplicationAddressLine;
	@Column(name = "CobuyerApplicationAddressCity")
	private String coBuyerApplicationAddressCity;
	@Column(name = "CobuyerApplicationAddressState")
	private String coBuyerApplicationAddressState;
	@Column(name = "CobuyerApplicationAddressZipcode")
	private String coBuyerApplicationAddressZipcode;
	@Column(name = "ApplicationStatus")
	private String applicationStatus;
	@Column(name = "ApplicationNumber")
	private String applicationNumber;
	@Column(name = "Model")
	private String model;
	@Column(name = "ModelYear")
	private short modelYear;
	@Column(name = "AmountFinanced")
	private BigDecimal amountFinanced;
	@Column(name = "LTV")
	private String ltv;
	@Column(name = "ApplicationType")
	private String applicationType;
	@Column(name = "ModelDescription")
	private String modelDescription;
	@Column(name = "Make")
	private String make;
	@Column(name = "SalesClass")
	private String salesClass;
	@Column(name = "CertifiedPreOwned")
	private boolean certifiedPreOwned;
	@Column(name = "DeliveryMileage")
	private BigDecimal deliveryMileage;
	@Column(name = "VehicleStock")
	private String vehicleStock;
	@Column(name = "BodyStyle")
	private String bodyStyle;
	@Column(name = "FinanceType")
	private String financeType;
	@Column(name = "PaymentAmount")
	private BigDecimal paymentAmount;
	@Column(name = "BalanceAmount")
	private BigDecimal balanceAmount;
	@Column(name = "ResidualAmount")
	private BigDecimal residualAmount;
	@Column(name = "PurchasePrice")
	private BigDecimal purchasePrice;
	@Column(name = "Term")
	private BigDecimal term;
	@Column(name = "DownpaymentAmount")
	private BigDecimal downpaymentAmount;
	@Column(name = "ManufacturerRebateAmount")
	private BigDecimal manufacturerRebateAmount;
	@Column(name = "AnnualPercentageRate")
	private BigDecimal annualPercentageRate;
	@Column(name = "NetTradeAmount")
	private BigDecimal netTradeAmount;
	@Column(name = "InsuranceTotalExtendedWarrantyAmount")
	private BigDecimal insuranceTotalExtendedWarrantyAmount;
	@Column(name = "DisabilityPremiumAmount")
	private BigDecimal disabilityPremiumAmount;
	@Column(name = "CreditLifePremiumAmount")
	private BigDecimal creditLifePremiumAmount;
	@Column(name = "SecurityDepositAmount")
	private BigDecimal securityDepositAmount;
	@Column(name = "Tier")
	private String tier;
	@Column(name = "Stipulations")
	private String stipulations;
	@Column(name = "CreatedBy")
	private short createdBy;
	@Column(name = "CreatedTs")
	private Timestamp createdTs;
	@Column(name = "ModifiedBy")
	private short modifiedBy;
	@Column(name = "ModifiedTs")
	private Timestamp modifiedTs;
	
	
	public BigInteger getCreditDecisionId() {
		return creditDecisionId;
	}
	public void setCreditDecisionId(BigInteger creditDecisionId) {
		this.creditDecisionId = creditDecisionId;
	}
	public String getDmsDealerId() {
		return dmsDealerId;
	}
	public void setDmsDealerId(String dmsDealerId) {
		this.dmsDealerId = dmsDealerId;
	}
	public String getLenderDealerId() {
		return lenderDealerId;
	}
	public void setLenderDealerId(String lenderDealerId) {
		this.lenderDealerId = lenderDealerId;
	}
	public String getDmsDealNum() {
		return dmsDealNum;
	}
	public void setDmsDealNum(String dmsDealNum) {
		this.dmsDealNum = dmsDealNum;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}
	public String getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}
	public String getR1lenderId() {
		return r1lenderId;
	}
	public void setR1lenderId(String r1lenderId) {
		this.r1lenderId = r1lenderId;
	}
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public String getR1SequenceNum() {
		return r1SequenceNum;
	}
	public void setR1SequenceNum(String r1SequenceNum) {
		this.r1SequenceNum = r1SequenceNum;
	}
	public Timestamp getStatusTs() {
		return statusTs;
	}
	public void setStatusTs(Timestamp statusTs) {
		this.statusTs = statusTs;
	}
	public Timestamp getSubmittedTs() {
		return submittedTs;
	}
	public void setSubmittedTs(Timestamp submittedTs) {
		this.submittedTs = submittedTs;
	}
	public Timestamp getDecisionTs() {
		return decisionTs;
	}
	public void setDecisionTs(Timestamp decisionTs) {
		this.decisionTs = decisionTs;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getBuyerSSN() {
		return buyerSSN;
	}
	public void setBuyerSSN(String buyerSSN) {
		this.buyerSSN = buyerSSN;
	}
	public String getBuyerFirstName() {
		return buyerFirstName;
	}
	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}
	public String getBuyerLastName() {
		return buyerLastName;
	}
	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}
	public String getBuyerApplicationAddressLine() {
		return buyerApplicationAddressLine;
	}
	public void setBuyerApplicationAddressLine(String buyerApplicationAddressLine) {
		this.buyerApplicationAddressLine = buyerApplicationAddressLine;
	}
	public String getBuyerApplicationAddressCity() {
		return buyerApplicationAddressCity;
	}
	public void setBuyerApplicationAddressCity(String buyerApplicationAddressCity) {
		this.buyerApplicationAddressCity = buyerApplicationAddressCity;
	}
	public String getBuyerApplicationAddressState() {
		return buyerApplicationAddressState;
	}
	public void setBuyerApplicationAddressState(String buyerApplicationAddressState) {
		this.buyerApplicationAddressState = buyerApplicationAddressState;
	}
	public String getBuyerApplicationAddressZipCode() {
		return buyerApplicationAddressZipCode;
	}
	public void setBuyerApplicationAddressZipCode(String buyerApplicationAddressZipCode) {
		this.buyerApplicationAddressZipCode = buyerApplicationAddressZipCode;
	}
	public String getCoBuyerSSN() {
		return coBuyerSSN;
	}
	public void setCoBuyerSSN(String coBuyerSSN) {
		this.coBuyerSSN = coBuyerSSN;
	}
	public String getCoBuyerFirstName() {
		return coBuyerFirstName;
	}
	public void setCoBuyerFirstName(String coBuyerFirstName) {
		this.coBuyerFirstName = coBuyerFirstName;
	}
	public String getCoBuyerLastName() {
		return coBuyerLastName;
	}
	public void setCoBuyerLastName(String coBuyerLastName) {
		this.coBuyerLastName = coBuyerLastName;
	}
	public String getCoBuyerApplicationAddressLine() {
		return coBuyerApplicationAddressLine;
	}
	public void setCoBuyerApplicationAddressLine(String coBuyerApplicationAddressLine) {
		this.coBuyerApplicationAddressLine = coBuyerApplicationAddressLine;
	}
	public String getCoBuyerApplicationAddressCity() {
		return coBuyerApplicationAddressCity;
	}
	public void setCoBuyerApplicationAddressCity(String coBuyerApplicationAddressCity) {
		this.coBuyerApplicationAddressCity = coBuyerApplicationAddressCity;
	}
	public String getCoBuyerApplicationAddressState() {
		return coBuyerApplicationAddressState;
	}
	public void setCoBuyerApplicationAddressState(String coBuyerApplicationAddressState) {
		this.coBuyerApplicationAddressState = coBuyerApplicationAddressState;
	}
	public String getCoBuyerApplicationAddressZipcode() {
		return coBuyerApplicationAddressZipcode;
	}
	public void setCoBuyerApplicationAddressZipcode(String coBuyerApplicationAddressZipcode) {
		this.coBuyerApplicationAddressZipcode = coBuyerApplicationAddressZipcode;
	}
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	public String getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public short getModelYear() {
		return modelYear;
	}
	public void setModelYear(short modelYear) {
		this.modelYear = modelYear;
	}
	public BigDecimal getAmountFinanced() {
		return amountFinanced;
	}
	public void setAmountFinanced(BigDecimal amountFinanced) {
		this.amountFinanced = amountFinanced;
	}
	public String getLtv() {
		return ltv;
	}
	public void setLtv(String ltv) {
		this.ltv = ltv;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getModelDescription() {
		return modelDescription;
	}
	public void setModelDescription(String modelDescription) {
		this.modelDescription = modelDescription;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getSalesClass() {
		return salesClass;
	}
	public void setSalesClass(String salesClass) {
		this.salesClass = salesClass;
	}
	public boolean isCertifiedPreOwned() {
		return certifiedPreOwned;
	}
	public void setCertifiedPreOwned(boolean certifiedPreOwned) {
		this.certifiedPreOwned = certifiedPreOwned;
	}
	public BigDecimal getDeliveryMileage() {
		return deliveryMileage;
	}
	public void setDeliveryMileage(BigDecimal deliveryMileage) {
		this.deliveryMileage = deliveryMileage;
	}
	public String getVehicleStock() {
		return vehicleStock;
	}
	public void setVehicleStock(String vehicleStock) {
		this.vehicleStock = vehicleStock;
	}
	public String getBodyStyle() {
		return bodyStyle;
	}
	public void setBodyStyle(String bodyStyle) {
		this.bodyStyle = bodyStyle;
	}
	public String getFinanceType() {
		return financeType;
	}
	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public BigDecimal getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(BigDecimal balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	public BigDecimal getResidualAmount() {
		return residualAmount;
	}
	public void setResidualAmount(BigDecimal residualAmount) {
		this.residualAmount = residualAmount;
	}
	public BigDecimal getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(BigDecimal purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public BigDecimal getTerm() {
		return term;
	}
	public void setTerm(BigDecimal term) {
		this.term = term;
	}
	public BigDecimal getDownpaymentAmount() {
		return downpaymentAmount;
	}
	public void setDownpaymentAmount(BigDecimal downpaymentAmount) {
		this.downpaymentAmount = downpaymentAmount;
	}
	public BigDecimal getManufacturerRebateAmount() {
		return manufacturerRebateAmount;
	}
	public void setManufacturerRebateAmount(BigDecimal manufacturerRebateAmount) {
		this.manufacturerRebateAmount = manufacturerRebateAmount;
	}
	public BigDecimal getAnnualPercentageRate() {
		return annualPercentageRate;
	}
	public void setAnnualPercentageRate(BigDecimal annualPercentageRate) {
		this.annualPercentageRate = annualPercentageRate;
	}
	public BigDecimal getNetTradeAmount() {
		return netTradeAmount;
	}
	public void setNetTradeAmount(BigDecimal netTradeAmount) {
		this.netTradeAmount = netTradeAmount;
	}
	public BigDecimal getInsuranceTotalExtendedWarrantyAmount() {
		return insuranceTotalExtendedWarrantyAmount;
	}
	public void setInsuranceTotalExtendedWarrantyAmount(BigDecimal insuranceTotalExtendedWarrantyAmount) {
		this.insuranceTotalExtendedWarrantyAmount = insuranceTotalExtendedWarrantyAmount;
	}
	public BigDecimal getDisabilityPremiumAmount() {
		return disabilityPremiumAmount;
	}
	public void setDisabilityPremiumAmount(BigDecimal disabilityPremiumAmount) {
		this.disabilityPremiumAmount = disabilityPremiumAmount;
	}
	public BigDecimal getCreditLifePremiumAmount() {
		return creditLifePremiumAmount;
	}
	public void setCreditLifePremiumAmount(BigDecimal creditLifePremiumAmount) {
		this.creditLifePremiumAmount = creditLifePremiumAmount;
	}
	public BigDecimal getSecurityDepositAmount() {
		return securityDepositAmount;
	}
	public void setSecurityDepositAmount(BigDecimal securityDepositAmount) {
		this.securityDepositAmount = securityDepositAmount;
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getStipulations() {
		return stipulations;
	}
	public void setStipulations(String stipulations) {
		this.stipulations = stipulations;
	}
	public short getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(short createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}
	public short getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(short modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	@Override
	public String toString() {
		return "CreditDecisionDetail [creditDecisionId=" + creditDecisionId + ", dmsDealerId=" + dmsDealerId
				+ ", lenderDealerId=" + lenderDealerId + ", dmsDealNum=" + dmsDealNum + ", lenderId=" + lenderId
				+ ", deDealId=" + deDealId + ", sequenceId=" + sequenceId + ", r1lenderId=" + r1lenderId
				+ ", conversationId=" + conversationId + ", r1SequenceNum=" + r1SequenceNum + ", statusTs=" + statusTs
				+ ", submittedTs=" + submittedTs + ", decisionTs=" + decisionTs + ", vin=" + vin + ", buyerSSN="
				+ buyerSSN + ", buyerFirstName=" + buyerFirstName + ", buyerLastName=" + buyerLastName
				+ ", buyerApplicationAddressLine=" + buyerApplicationAddressLine + ", buyerApplicationAddressCity="
				+ buyerApplicationAddressCity + ", buyerApplicationAddressState=" + buyerApplicationAddressState
				+ ", buyerApplicationAddressZipCode=" + buyerApplicationAddressZipCode + ", coBuyerSSN=" + coBuyerSSN
				+ ", coBuyerFirstName=" + coBuyerFirstName + ", coBuyerLastName=" + coBuyerLastName
				+ ", coBuyerApplicationAddressLine=" + coBuyerApplicationAddressLine
				+ ", coBuyerApplicationAddressCity=" + coBuyerApplicationAddressCity
				+ ", coBuyerApplicationAddressState=" + coBuyerApplicationAddressState
				+ ", coBuyerApplicationAddressZipcode=" + coBuyerApplicationAddressZipcode + ", applicationStatus="
				+ applicationStatus + ", applicationNumber=" + applicationNumber + ", model=" + model + ", modelYear="
				+ modelYear + ", amountFinanced=" + amountFinanced + ", ltv=" + ltv + ", applicationType="
				+ applicationType + ", modelDescription=" + modelDescription + ", make=" + make + ", salesClass="
				+ salesClass + ", certifiedPreOwned=" + certifiedPreOwned + ", deliveryMileage=" + deliveryMileage
				+ ", vehicleStock=" + vehicleStock + ", bodyStyle=" + bodyStyle + ", financeType=" + financeType
				+ ", paymentAmount=" + paymentAmount + ", balanceAmount=" + balanceAmount + ", residualAmount="
				+ residualAmount + ", purchasePrice=" + purchasePrice + ", term=" + term + ", downpaymentAmount="
				+ downpaymentAmount + ", manufacturerRebateAmount=" + manufacturerRebateAmount
				+ ", annualPercentageRate=" + annualPercentageRate + ", netTradeAmount=" + netTradeAmount
				+ ", insuranceTotalExtendedWarrantyAmount=" + insuranceTotalExtendedWarrantyAmount
				+ ", disabilityPremiumAmount=" + disabilityPremiumAmount + ", creditLifePremiumAmount="
				+ creditLifePremiumAmount + ", securityDepositAmount=" + securityDepositAmount + ", tier=" + tier
				+ ", stipulations=" + stipulations + ", createdBy=" + createdBy + ", createdTs=" + createdTs
				+ ", modifiedBy=" + modifiedBy + ", modifiedTs=" + modifiedTs + "]";
	}
	
	

}

