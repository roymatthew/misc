/**
 * 
 */
package com.ode.ca.persistence;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author snimma
 *
 */
@Repository
public interface CreditDecisionDetailRepo extends JpaRepository<CreditDecisionDetail, BigInteger>{

}
