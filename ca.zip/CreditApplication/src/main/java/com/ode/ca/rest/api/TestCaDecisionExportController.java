package com.ode.ca.rest.api;

import javax.jms.JMSException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.ca.messaging.CAMessageProducer;
import com.ode.ca.service.CaDecisionExportService;
import com.ode.ca.vo.CreditDecisionWrapperVO;

/**
 * @author rmathew
 * ***********This class is meant for testing purposes only**************
 */
@RestController
@Profile({"dev"})
public class TestCaDecisionExportController {
	
	private static final Logger log = LogManager.getLogger(TestCaDecisionExportController.class);
	
	@Autowired
	private CaDecisionExportService caDecisionExportService;
	
	@Autowired
	private CAMessageProducer messageProducer;
	
	@PostMapping(value="/cade/process")	
	public ResponseEntity<Object> processCaDecisionExport(@RequestBody final String caDecisionXml) throws Exception
	{
		log.debug("Entered processCaDecisionExport() method of CaDecisionExportController class");
		CreditDecisionWrapperVO result = null;
		result = caDecisionExportService.processCaDecisionExport(caDecisionXml);
		ResponseEntity<Object> response = new ResponseEntity<Object>("Credit decision export failed!", HttpStatus.OK);
		if (null != result)
		{
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return response;		
	}	

	
	@PutMapping(value = "/cade/add/message")
	public void writeMessageToQueue(@RequestBody final String message) throws JMSException
	{
		log.debug("Enter writeMessageToQueue");
		messageProducer.sendMessage(message);
	}

}
