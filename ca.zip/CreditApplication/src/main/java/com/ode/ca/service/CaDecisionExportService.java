/**
 * 
 */
package com.ode.ca.service;

import com.ode.ca.vo.CreditDecisionDetailVO;
import com.ode.ca.vo.CreditDecisionWrapperVO;

/**
 * @author rmathew
 *
 */
public interface CaDecisionExportService {
	
	CreditDecisionWrapperVO processCaDecisionExport(final String caDecisionXml) throws Exception;

}
