/**
 * 
 */
package com.ode.ca.service;

import java.io.OutputStream;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import com.ode.ca.factory.VOFactory;
import com.ode.ca.util.CaEventHandler;
import com.ode.ca.util.CadeXmlParser;
import com.ode.ca.vo.CreditDecisionDetailVO;
import com.ode.ca.vo.CreditDecisionWrapperVO;
import com.ode.persistence.service.CreditJournalRepoService;
import com.ode.persistence.service.DeDealRepoService;
import com.ode.persistence.vo.CreditDecisionVO;

/**
 * @author rmathew
 *
 */
@Service
public class CaDecisionExportServiceImpl implements CaDecisionExportService {

	private static final Logger log = LogManager.getLogger(CaDecisionExportServiceImpl.class);

	@Autowired
	private DeDealRepoService deDealRepoService;

	@Autowired
	private CaEventHandler caEventHandler;

	@Autowired
	private CadeXmlParser cadeXmlParser;

	@Autowired
	private CreditJournalRepoService creditJournalRepoService;

	@Autowired
	private CaDecisionPersistenceService creditDecisionPersistenceService;

	@Autowired
	private VOFactory voFactory;

	@Value("${creditdecisionBackupFlag}")
	private String cdBackupFlag;

	@Value("${creditdecisionBackupLocation}")
	private String cdBackupLocation;

	@Override
	public CreditDecisionWrapperVO processCaDecisionExport(final String caDecisionXml) throws Exception {

		final LocalDateTime start = LocalDateTime.now();
		log.debug("Entered processCaDecisionExport() method of CaDecisionExportServiceImpl class");
		log.debug("***** Start processing CA Decision Export at: " + start + " *****");

		CreditDecisionWrapperVO wrapperVO = null;
		CreditDecisionDetailVO creditDecisionDetailVO = null;
		CreditDecisionVO creditDecisionVO = null;
		
		Document processCreditDecisionDoc = cadeXmlParser.getProcessCreditDecisionDocument(caDecisionXml);
		creditDecisionDetailVO = voFactory.createCreditDecisionDetailVO(processCreditDecisionDoc);
		creditDecisionVO = voFactory.createCreditDecisionVO(creditDecisionDetailVO, processCreditDecisionDoc);

		if (StringUtils.isNotEmpty(caDecisionXml)) {

			if ("true".equalsIgnoreCase(cdBackupFlag)) {

				FileSystemResource resource = null;
				OutputStream out = null;

				try {
					String fileName = cdBackupLocation + "/" + creditDecisionDetailVO.getDmsDealerId() + "_"
							+ creditDecisionDetailVO.getLenderId() + "_" + System.currentTimeMillis() + ".xml";
					resource = new FileSystemResource(fileName);
					out = resource.getOutputStream();
					out.write(caDecisionXml.getBytes());
					log.debug("Saved a copy of incoming decision on the server.");
				} catch (final Exception e) {
					log.error("Could not write incoming decision to the backup location", e);
				} finally {
					if (null != out) {
						try {
							out.close();
						} catch (Exception e) {
							//
						}
					}
				}
			}

		}	

		wrapperVO = new CreditDecisionWrapperVO(creditDecisionDetailVO, creditDecisionVO);
		wrapperVO = creditDecisionPersistenceService.saveCreditDecisionAndCreditDecisionDetail(wrapperVO);
		
		final LocalDateTime end = LocalDateTime.now();
		log.debug("***** End processing CA Decision Export at: " + end + " *****");
		log.debug("CA Decision Export took " + ChronoUnit.MILLIS.between(start, end) + " milliseconds");
		return wrapperVO;
	}

}
