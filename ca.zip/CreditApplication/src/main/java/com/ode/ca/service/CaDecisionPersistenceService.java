/**
 * 
 */
package com.ode.ca.service;

import com.ode.ca.vo.CreditDecisionDetailVO;
import com.ode.ca.vo.CreditDecisionWrapperVO;
import com.ode.persistence.vo.CreditDecisionVO;

/**
 * @author rmathew
 *
 */
public interface CaDecisionPersistenceService {

	/**
	 * @param wrapperVO
	 * @return
	 * @throws Exception
	 */
	CreditDecisionWrapperVO saveCreditDecisionAndCreditDecisionDetail(final CreditDecisionWrapperVO wrapperVO) throws Exception;
	/**
	 * @param cdDetailVO
	 * @return
	 */
	CreditDecisionDetailVO saveCreditDecisionDetail(final CreditDecisionDetailVO cdDetailVO);
	/**
	 * @param cdDetailVO
	 * @return
	 * @throws Exception
	 */
	CreditDecisionVO saveCreditDecision(final CreditDecisionVO cdDetailVO) throws Exception;

}
