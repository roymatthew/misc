/**
 * 
 */
package com.ode.ca.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.ca.persistence.CreditDecisionDetail;
import com.ode.ca.persistence.CreditDecisionDetailRepo;
import com.ode.ca.vo.CreditDecisionDetailVO;
import com.ode.ca.vo.CreditDecisionWrapperVO;
import com.ode.persistence.service.CreditDecisionRepoService;
import com.ode.persistence.vo.CreditDecisionVO;

/**
 * @author rmathew
 *
 */
@Service
public class CaDecisionPersistenceServiceImpl implements CaDecisionPersistenceService {
	
	private static final Logger log = LogManager.getLogger(CaDecisionPersistenceServiceImpl.class);
	
	@Autowired
	private CreditDecisionRepoService creditDecisionRepoService;
	
	@Autowired
	private CreditDecisionDetailRepo creditDecisionDetailRepo;
	
	@Autowired
	private ModelMapper modelMapper;
 
	@Override
	public CreditDecisionWrapperVO saveCreditDecisionAndCreditDecisionDetail(final CreditDecisionWrapperVO wrapperVO) throws Exception {
		
		log.debug("Entered saveCreditDecision() method of CreditDecisionPersistenceServiceImpl class");
		CreditDecisionDetailVO creditDecisionDetailVO = saveCreditDecisionDetail(wrapperVO.getCreditDecisionDetailVO());
		CreditDecisionVO creditDecisionVO = saveCreditDecision(wrapperVO.getCreditDecisionVO());
		if (null != creditDecisionDetailVO && null != creditDecisionVO)
		{
			return new CreditDecisionWrapperVO(creditDecisionDetailVO, creditDecisionVO);
		}
		return null;
	}

	@Override
	@Transactional(value = "sqlServerTransactionManager")
	public CreditDecisionDetailVO saveCreditDecisionDetail(final CreditDecisionDetailVO cdDetailVO) {
		log.debug("Entered saveCreditDecisionDetailVO() method of CreditDecisionPersistenceServiceImpl class, CreditDecisionDetailVO: {}", cdDetailVO);
		CreditDecisionDetail creditDecisionDetail = creditDecisionDetailRepo.save(modelMapper.map(cdDetailVO, CreditDecisionDetail.class));
		if (null != creditDecisionDetail && null != creditDecisionDetail.getCreditDecisionId())
		{
			return modelMapper.map(creditDecisionDetail, CreditDecisionDetailVO.class);
		}
		return null;
	}

	@Override
	@Transactional(value = "transactionManager")
	public CreditDecisionVO saveCreditDecision(final CreditDecisionVO cdDetailVO) throws Exception {
		log.debug("Entered saveCreditDecisionVO() method of CreditDecisionPersistenceServiceImpl class. CreditDecisionVO: {}", cdDetailVO);
		return creditDecisionRepoService.saveOrUpdate(cdDetailVO);
	}

}
