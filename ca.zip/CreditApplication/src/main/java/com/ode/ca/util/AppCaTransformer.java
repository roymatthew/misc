/*
 * Created on Apr 8, 2010
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.ca.util;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * @author mariappb
 *
 *         To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Style - Code Templates
 */
public abstract class AppCaTransformer implements Constants {

	private static final Logger logger = LogManager.getLogger(AppCaTransformer.class);

	@Value("${environment}")
	private String environment;
	@Value("${nounFailure}")
	private String nounFailure;
	@Value("${bodFailure}")
	private String bodFailure;
	@Value("${sourceConfBod}")
	private String sourceConfBod;
	@Value("${contractApplicationNumber}")
	private String contractApplicationNumber;
	@Value("${funderComments}")
	private String funderComments;
	@Value("${fundingStatus}")
	private String fundingStatus;
	@Value("${documentId}")
	private String documentId;
	@Value("${validationDescription}")
	private String validationDescription;
	@Value("${validationResults}")
	private String validationResults;
	
	// For Generic Credit Contract transactions
/*	private String XPath_GenericCreditContract_VehicleMake;
	private String XPath_GenericCreditContract_VehicleModel;
	private String XPath_GenericCreditContract_SaleClass;
	private String XPath_GenericCreditContract_ApplicantFirstName;
	private String XPath_GenericCreditContract_ApplicantLastName;
	private String XPath_GenericCreditContract_ApplicantAddress;
	private String XPath_GenericCreditContract_CoApplicantFirstName;
	private String XPath_GenericCreditContract_CoApplicantLastName;
	private String XPath_GenericCreditContract_CoApplicantAddress;
	private String XPath_GenericCreditContract_BusinessAddress;
	private String XPath_GenericCreditContract_OrganizationName;
	private String XPath_GenericCreditContract_FinanceType;
	private String XPath_GenericCreditContract_ApplicationType;
	private String XPath_GenericCreditContract_Term;*/
	@Value("${XPath_GenericCreditContract_dealerName}")
	private String XPath_GenericCreditContract_DealerName;
	@Value("${XPath_GenericCreditContract_dealerAddress}")
	private String XPath_GenericCreditContract_DealerAddress;
	@Value("${XPath_GenericCreditContract_dealerCity}")
	private String XPath_GenericCreditContract_DealerCity;
	@Value("${XPath_GenericCreditContract_dealerState}")
	private String XPath_GenericCreditContract_DealerState;
	@Value("${XPath_GenericCreditContract_dealerZip}")
	private String XPath_GenericCreditContract_DealerZip;
	@Value("${XPath_GenericCreditContract_productType}")
	private String XPath_GenericCreditContract_ProductType;
	@Value("${XPath_GenericCreditContract_contractFormNumber}")
	private String XPath_GenericCreditContract_ContractFormNumber;
	@Value("${XPath_GenericCreditContract_contractExecState}")
	private String XPath_GenericCreditContract_ContractExecState;
	
	@Value("${dealerName}")
	private String dealerName;
	@Value("${dealerAddress}")
	private String dealerAddress;
	@Value("${dealerState}")
	private String dealerState;
	@Value("${dealerCity}")
	private String dealerCity;
	@Value("${dealerZip}")
	private String dealerZip;
	@Value("${productType}")
	private String productType;
	@Value("${contractFormNumber}")
	private String contractFormNumber;
	@Value("${contractExecState}")
	private String contractExecState;
	@Value("${contractFormRevisionDate}")
	private String contractFormRevisionDate;

	public String getNounFailure() {
		return nounFailure;
	}

	public String getBodFailure() {
		return bodFailure;
	}

	public String getSourceConfBod() {
		return sourceConfBod;
	}

	public String getContractApplicationNumber() {
		return contractApplicationNumber;
	}

	public String getFunderComments() {
		return funderComments;
	}

	public String getFundingStatus() {
		return fundingStatus;
	}

	public String getDocumentId() {
		return documentId;
	}

	public String getValidationDescription() {
		return validationDescription;
	}

	public String getValidationResults() {
		return validationResults;
	}

	public String getDealerName() {
		return dealerName;
	}

	public String getDealerAddress() {
		return dealerAddress;
	}

	public String getDealerState() {
		return dealerState;
	}

	public String getDealerCity() {
		return dealerCity;
	}

	public String getDealerZip() {
		return dealerZip;
	}

	public String getProductType() {
		return productType;
	}

	public String getContractFormNumber() {
		return contractFormNumber;
	}

	public String getContractExecState() {
		return contractExecState;
	}

	public String getContractFormRevisionDate() {
		return contractFormRevisionDate;
	}

	public void setNounFailure(String nounFailure) {
		this.nounFailure = nounFailure;
	}

	public void setContractApplicationNumber(String contractApplicationNumber) {
		this.contractApplicationNumber = contractApplicationNumber;
	}

	public void setFunderComments(String funderComments) {
		this.funderComments = funderComments;
	}

	public void setFundingStatus(String fundingStatus) {
		this.fundingStatus = fundingStatus;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public void setValidationDescription(String validationDescription) {
		this.validationDescription = validationDescription;
	}

	public void setValidationResults(String validationResults) {
		this.validationResults = validationResults;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public void setDealerAddress(String dealerAddress) {
		this.dealerAddress = dealerAddress;
	}

	public void setDealerState(String dealerState) {
		this.dealerState = dealerState;
	}

	public void setDealerCity(String dealerCity) {
		this.dealerCity = dealerCity;
	}

	public void setDealerZip(String dealerZip) {
		this.dealerZip = dealerZip;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public void setContractFormNumber(String contractFormNumber) {
		this.contractFormNumber = contractFormNumber;
	}

	public void setContractExecState(String contractExecState) {
		this.contractExecState = contractExecState;
	}

	public void setContractFormRevisionDate(String contractFormRevisionDate) {
		this.contractFormRevisionDate = contractFormRevisionDate;
	}




	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	protected Document getDocument(String xml) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));
		try {
			return docBuilder.parse(is);
		} catch (SAXException e) {
			logger.error("Invalid Document in method getDocument");
			logger.error("", e);
			throw e;
		}
	}

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	protected Document getNamespaceAwareDocument(String xml) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));
		try {
			return docBuilder.parse(is);
		} catch (SAXException e) {
			logger.error("Invalid Document in method getDocument");
			logger.error("", e);
			throw e;
		}
	}

	public void setnounFailure(String nounFailure) {
		this.nounFailure = nounFailure;
	}

	public String getXPath_NounFailure() {
		return nounFailure;
	}

	public void setBodFailure(String bodFailure) {
		this.bodFailure = bodFailure;
	}

	public String getXPath_BodFailure() {
		return bodFailure;
	}

	public void setSourceConfBod(String sourceConfBod) {
		this.sourceConfBod = sourceConfBod;
	}

	public String getXPath_SourceConfBod() {
		return sourceConfBod;
	}
	
	public String getXPath_ContractApplicationNumber() {
		return contractApplicationNumber;
	}
	
	public String getXPath_ValidationDescription() {
		return validationDescription;
	}

	public String getXPath_DocumentId() {
		return documentId;
	}

	public String getXPath_FundingStatus() {
		return fundingStatus;
	}

	public String getXPath_FunderComments() {
		return funderComments;
	}

/*	public String getXPath_GenericCreditContract_VehicleMake() {
		return XPath_GenericCreditContract_VehicleMake;
	}

	public void setXPath_GenericCreditContract_VehicleMake(String xPath_GenericCreditContract_VehicleMake) {
		XPath_GenericCreditContract_VehicleMake = xPath_GenericCreditContract_VehicleMake;
	}

	public String getXPath_GenericCreditContract_VehicleModel() {
		return XPath_GenericCreditContract_VehicleModel;
	}

	public void setXPath_GenericCreditContract_VehicleModel(String xPath_GenericCreditContract_VehicleModel) {
		XPath_GenericCreditContract_VehicleModel = xPath_GenericCreditContract_VehicleModel;
	}

	public String getXPath_GenericCreditContract_SaleClass() {
		return XPath_GenericCreditContract_SaleClass;
	}

	public void setXPath_GenericCreditContract_SaleClass(String xPath_GenericCreditContract_SaleClass) {
		XPath_GenericCreditContract_SaleClass = xPath_GenericCreditContract_SaleClass;
	}

	public String getXPath_GenericCreditContract_ApplicantFirstName() {
		return XPath_GenericCreditContract_ApplicantFirstName;
	}

	public void setXPath_GenericCreditContract_ApplicantFirstName(String xPath_GenericCreditContract_ApplicantFirstName) {
		XPath_GenericCreditContract_ApplicantFirstName = xPath_GenericCreditContract_ApplicantFirstName;
	}

	public String getXPath_GenericCreditContract_ApplicantLastName() {
		return XPath_GenericCreditContract_ApplicantLastName;
	}

	public void setXPath_GenericCreditContract_ApplicantLastName(String xPath_GenericCreditContract_ApplicantLastName) {
		XPath_GenericCreditContract_ApplicantLastName = xPath_GenericCreditContract_ApplicantLastName;
	}

	public String getXPath_GenericCreditContract_ApplicantAddress() {
		return XPath_GenericCreditContract_ApplicantAddress;
	}

	public void setXPath_GenericCreditContract_ApplicantAddress(String xPath_GenericCreditContract_ApplicantAddress) {
		XPath_GenericCreditContract_ApplicantAddress = xPath_GenericCreditContract_ApplicantAddress;
	}

	public String getXPath_GenericCreditContract_CoApplicantFirstName() {
		return XPath_GenericCreditContract_CoApplicantFirstName;
	}

	public void setXPath_GenericCreditContract_CoApplicantFirstName(
			String xPath_GenericCreditContract_CoApplicantFirstName) {
		XPath_GenericCreditContract_CoApplicantFirstName = xPath_GenericCreditContract_CoApplicantFirstName;
	}

	public String getXPath_GenericCreditContract_CoApplicantLastName() {
		return XPath_GenericCreditContract_CoApplicantLastName;
	}

	public void setXPath_GenericCreditContract_CoApplicantLastName(String xPath_GenericCreditContract_CoApplicantLastName) {
		XPath_GenericCreditContract_CoApplicantLastName = xPath_GenericCreditContract_CoApplicantLastName;
	}

	public String getXPath_GenericCreditContract_CoApplicantAddress() {
		return XPath_GenericCreditContract_CoApplicantAddress;
	}

	public void setXPath_GenericCreditContract_CoApplicantAddress(String xPath_GenericCreditContract_CoApplicantAddress) {
		XPath_GenericCreditContract_CoApplicantAddress = xPath_GenericCreditContract_CoApplicantAddress;
	}

	public String getXPath_GenericCreditContract_BusinessAddress() {
		return XPath_GenericCreditContract_BusinessAddress;
	}

	public void setXPath_GenericCreditContract_BusinessAddress(String xPath_GenericCreditContract_BusinessAddress) {
		XPath_GenericCreditContract_BusinessAddress = xPath_GenericCreditContract_BusinessAddress;
	}

	public String getXPath_GenericCreditContract_OrganizationName() {
		return XPath_GenericCreditContract_OrganizationName;
	}

	public void setXPath_GenericCreditContract_OrganizationName(String xPath_GenericCreditContract_OrganizationName) {
		XPath_GenericCreditContract_OrganizationName = xPath_GenericCreditContract_OrganizationName;
	}

	public String getXPath_GenericCreditContract_FinanceType() {
		return XPath_GenericCreditContract_FinanceType;
	}

	public void setXPath_GenericCreditContract_FinanceType(String xPath_GenericCreditContract_FinanceType) {
		XPath_GenericCreditContract_FinanceType = xPath_GenericCreditContract_FinanceType;
	}

	public String getXPath_GenericCreditContract_ApplicationType() {
		return XPath_GenericCreditContract_ApplicationType;
	}

	public void setXPath_GenericCreditContract_ApplicationType(String xPath_GenericCreditContract_ApplicationType) {
		XPath_GenericCreditContract_ApplicationType = xPath_GenericCreditContract_ApplicationType;
	}

	public String getXPath_GenericCreditContract_Term() {
		return XPath_GenericCreditContract_Term;
	}

	public void setXPath_GenericCreditContract_Term(String xPath_GenericCreditContract_Term) {
		XPath_GenericCreditContract_Term = xPath_GenericCreditContract_Term;
	}*/

	public String getXPath_GenericCreditContract_DealerName() {
		return XPath_GenericCreditContract_DealerName;
	}

	public void setXPath_GenericCreditContract_DealerName(String xPath_GenericCreditContract_DealerName) {
		XPath_GenericCreditContract_DealerName = xPath_GenericCreditContract_DealerName;
	}

	public String getXPath_GenericCreditContract_DealerAddress() {
		return XPath_GenericCreditContract_DealerAddress;
	}

	public void setXPath_GenericCreditContract_DealerAddress(String xPath_GenericCreditContract_DealerAddress) {
		XPath_GenericCreditContract_DealerAddress = xPath_GenericCreditContract_DealerAddress;
	}

	public String getXPath_GenericCreditContract_DealerCity() {
		return XPath_GenericCreditContract_DealerCity;
	}

	public void setXPath_GenericCreditContract_DealerCity(String xPath_GenericCreditContract_DealerCity) {
		XPath_GenericCreditContract_DealerCity = xPath_GenericCreditContract_DealerCity;
	}

	public String getXPath_GenericCreditContract_DealerState() {
		return XPath_GenericCreditContract_DealerState;
	}

	public void setXPath_GenericCreditContract_DealerState(String xPath_GenericCreditContract_DealerState) {
		XPath_GenericCreditContract_DealerState = xPath_GenericCreditContract_DealerState;
	}

	public String getXPath_GenericCreditContract_DealerZip() {
		return XPath_GenericCreditContract_DealerZip;
	}

	public void setXPath_GenericCreditContract_DealerZip(String xPath_GenericCreditContract_DealerZip) {
		XPath_GenericCreditContract_DealerZip = xPath_GenericCreditContract_DealerZip;
	}

	public String getXPath_GenericCreditContract_ProductType() {
		return XPath_GenericCreditContract_ProductType;
	}

	public void setXPath_GenericCreditContract_ProductType(String xPath_GenericCreditContract_ProductType) {
		XPath_GenericCreditContract_ProductType = xPath_GenericCreditContract_ProductType;
	}

	public String getXPath_GenericCreditContract_ContractFormNumber() {
		return XPath_GenericCreditContract_ContractFormNumber;
	}

	public void setXPath_GenericCreditContract_ContractFormNumber(String xPath_GenericCreditContract_ContractFormNumber) {
		XPath_GenericCreditContract_ContractFormNumber = xPath_GenericCreditContract_ContractFormNumber;
	}

	public String getXPath_GenericCreditContract_ContractExecState() {
		return XPath_GenericCreditContract_ContractExecState;
	}

	public void setXPath_GenericCreditContract_ContractExecState(String xPath_GenericCreditContract_ContractExecState) {
		XPath_GenericCreditContract_ContractExecState = xPath_GenericCreditContract_ContractExecState;
	}
	

	

	
}
