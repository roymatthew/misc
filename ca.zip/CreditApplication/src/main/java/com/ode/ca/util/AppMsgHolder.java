/*
 * Created on Apr 19, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.ca.util;

import java.io.FileInputStream;
import java.net.SocketException;
import java.util.Hashtable;
import java.util.List;
import java.util.ListIterator;

import javax.jms.JMSException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Component;

import com.ode.ca.exception.AppException;
import com.ode.ca.util.schema.appmessages.Messages;
import com.ode.ca.util.schema.appmessages.Messages.Message;
import com.ode.ca.util.schema.appmessages.Messages.Message.Description;
import com.ode.dlr.util.AppMessage;

/**
 * @author rmathew Original Source: LP Application Refactored for package
 *         structuring
 */
@Component
public class AppMsgHolder {

	public Hashtable msgHashtable;

	/**
	 * @param inStream
	 * @throws Exception
	 */
	protected void initialize(final FileInputStream inStream) throws Exception {

		msgHashtable = new Hashtable();
		JAXBContext jc = JAXBContext.newInstance("com.ode.ca.util.schema.appmessages");
		// create an Unmarshaller
		Unmarshaller u = jc.createUnmarshaller();
		Messages root = (Messages) u.unmarshal(inStream);
		List msgList = root.getMessage();
		ListIterator msgIterator = msgList.listIterator();

		Message jaxbmsg = null;
		AppMessage appMsg = null;
		String enmsg = null;
		String frmsg = " ";
		boolean overrideIndicator = false;
		boolean eventViewerIndicator = false;
		boolean traceIndicator = false;
		while (msgIterator.hasNext()) {
			jaxbmsg = (Message) msgIterator.next();
			Description description = jaxbmsg.getDescription();
			if ("en".equalsIgnoreCase(description.getLang())) {
				enmsg = description.getValue();
			} else {
				frmsg = description.getValue();
			}

			overrideIndicator = "true".equalsIgnoreCase(jaxbmsg.getOverrideind()) ? true : false;
			eventViewerIndicator = "true".equalsIgnoreCase(jaxbmsg.getEventviewerind()) ? true : false;
			traceIndicator = "true".equalsIgnoreCase(jaxbmsg.getTraceind()) ? true : false;

			appMsg = new AppMessage(jaxbmsg.getId(), enmsg, frmsg, jaxbmsg.getLoggingtype(), overrideIndicator,
					eventViewerIndicator, traceIndicator);
			msgHashtable.put(jaxbmsg.getName(), appMsg);
		}

	}

	protected AppMessage getAppMessage(Throwable msgID) {
		String errClassName = getClassName(msgID);
		AppMessage m = (AppMessage) msgHashtable.get(errClassName);
		if (m == null) {
			m = new AppMessage("E9999", "System Error", "System Error", "error", false, false, true);
			msgHashtable.put(errClassName, m);
		}
		return m;
	}

	protected AppMessage getAppMessage(String msgID) {
		AppMessage m = (AppMessage) msgHashtable.get(msgID);
		if (m == null) {
			m = new AppMessage("E9999", "System Error", "System Error", "trace", true, true, true);
			msgHashtable.put(msgID, m);
		}
		return m;
	}

	private String getClassName(Throwable e) {
		String className = e.getClass().getName();
		String errId = className;

		if (e instanceof JMSException)
			errId = "JMSException";
		if (e instanceof java.net.SocketTimeoutException)
			errId = "SocketTimeOut";
		if (e instanceof SocketException || e instanceof java.net.MalformedURLException
				|| e instanceof java.net.UnknownHostException || e instanceof java.net.UnknownServiceException
				|| e instanceof java.net.ProtocolException || e instanceof java.net.URISyntaxException)
			errId = "NetException";
		if (e instanceof AppException) {
			int i = className.lastIndexOf('.');
			errId = className.substring(i + 1);
		}
		return errId;
	}
}
