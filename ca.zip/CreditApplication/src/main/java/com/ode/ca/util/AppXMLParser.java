package com.ode.ca.util;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 * @author rmathew
 *
 */
public abstract class AppXMLParser implements Constants {

	private static final Logger logger = LogManager.getLogger(AppXMLParser.class);

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	protected Document getDocument(final String xml) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));
		return docBuilder.parse(is);
	}
	


}
