/*
 * Created on Apr 20, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.ca.util;

/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;

import com.ode.ca.exception.AppException;
import com.ode.dlr.util.AppMessage;
import com.ode.dlr.util.AppSQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author rmathew
 *
 */
@Component
public class CaEventHandler implements EventHandler {

	private static final Logger logger = LogManager.getLogger(CaEventHandler.class);
	private CaMsgHolder msgHolder = new CaMsgHolder();

	/**
	 * @param refvalue
	 * @param e
	 * @param tracemsg
	 * @return
	 */
	public AppMessage handleException(String refvalue, Throwable e, String tracemsg) {
		AppMessage msg = msgHolder.getAppMessage(e);
		logger.error("", e);
		return msg;
	}

	/**
	 * @param e
	 * @return
	 */
	public AppMessage handleException(final Throwable e) {

		String detailMsg = null;
		String excepTraceMsg = "N/A";
		Throwable causeException = null;
		String tracemsg = null;

		AppMessage msg = msgHolder.getAppMessage(e);

		if (e instanceof AppException) {

			excepTraceMsg = ((AppException) e).getTraceMsg();
			causeException = e.getCause();
			if (e instanceof AppSQLException) {
				detailMsg = detailMsg + "\r\n<SQLErrorCode>" + ((AppSQLException) e).getSqlCode() + "</SQLErrorCode>"
						+ "\r\n<SQLState>" + ((AppSQLException) e).getSqlState() + "</SQLState>";
			}
		}

		if (msg.isTraceind()) {
			if (e instanceof AppSQLException) {
				SQLException sq = (SQLException) e.getCause();
				logger.trace(detailMsg);
				logger.trace(tracemsg);
				SQLException sqe1 = null;
				while ((sqe1 = sq.getNextException()) != null) {
					logger.trace(detailMsg);
					logger.trace(tracemsg);
					sq = sqe1;
				}
			} else {
				logger.trace(detailMsg);
				logger.trace(tracemsg);
				if (causeException != null) {
					// ApplpLogger.totrace(detailMsg + DOT + "\n Application Trace" +tracemsg + "\n
					// Root Exception Trace"+ DOT+ excepTraceMsg,causeException);
					logger.trace(detailMsg);
					logger.trace(tracemsg);
					logger.trace("", causeException);
				}
			}
		}
		if (msg.isEventvieweron()) {
			logger.debug(detailMsg);
			logger.debug("", e);
		}
		if (msg.getLoggingtype().equalsIgnoreCase("error")) {
			logger.error(detailMsg);
			logger.error(tracemsg);
		} else {
			if (msg.getLoggingtype().equalsIgnoreCase("info")) {
				logger.info(detailMsg);
				logger.info(tracemsg);
			}
		} // else-if
		return msg;

	}

	/*
	 * This is a dummy function need to be removed once the EventHandler is adjusted
	 */
	public AppMessage handleEvents(String refvalue, String context, String eventname, String tracemsg) {
		AppMessage msg = msgHolder.getAppMessage(eventname);
		return msg;
	}

	/**
	 * @param eventname
	 * @return
	 */
	public AppMessage handleEvents(String eventname) {
		return msgHolder.getAppMessage(eventname);
	}

	/**
	 * Returns the IP of Local Host
	 * 
	 * @return String
	 */
	public String getSystemIp() {
		String localHostIP = "";
		try {
			localHostIP = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException uhe) {
			// NOP
		}
		return localHostIP;
	}

	/**
	 * @param msgHolder The msgHolder to set.
	 */
	public void setMsgHolder(final CaMsgHolder msgHolder) {
		this.msgHolder = msgHolder;
	}
}