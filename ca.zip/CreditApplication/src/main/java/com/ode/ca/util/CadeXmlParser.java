/**
 * 
 */
package com.ode.ca.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author rmathew
 *
 */
@Component
public class CadeXmlParser extends AppXMLParser {

	private static final Logger logger = LogManager.getLogger(CadeXmlParser.class);

	@Value("classpath:removeNameSpace.xslt")
	private Resource removeNameSpaceStyleSheet;

	/**
	 * @param originalDocument
	 * @return
	 * @throws Exception
	 */
	public Document getProcessCreditDecisionDocument(final String inputXml) throws Exception {
		logger.debug("Entered getProcessCreditDecisionDocument method of CadeXmlParser class");
		String xmlWithoutNameSpaces = removeSchemaPrefixIfAny(inputXml);
		Document originalDocument = getDocument(xmlWithoutNameSpaces);
		NodeList nodeList = originalDocument.getElementsByTagName("Body");
		Node bodyNode = nodeList.item(0);
		String processCDXML = getStringFromNode(bodyNode);
		final Document pccDoc = getDocument(processCDXML);
		return pccDoc;
	}

	/**
	 * @param node
	 * @return
	 * @throws TransformerException
	 * @throws IOException
	 */
	public String getStringFromNode(final Node node) throws TransformerException, IOException {

		logger.debug("Entered getStringFromNode method of CadeXmlParser class");
		DOMSource domSource = new DOMSource(node);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		return writer.toString();
	}

	/**
	 * @param xmlString
	 * @return
	 * @throws TransformerException
	 * @throws IOException
	 */
	public String removeSchemaPrefixIfAny(final String xmlString) throws TransformerException, IOException {
		logger.debug("Entered removeSchemaPrefixIfAny method of CadeXmlParser class");
		Source transformerSource = new StreamSource(removeNameSpaceStyleSheet.getInputStream());
		StringReader reader = new StringReader(xmlString);
		Source xmlSource = new StreamSource(reader);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
				org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
		Transformer transformer = tf.newTransformer(transformerSource);
		transformer.transform(xmlSource, result);
		return writer.toString();
	}

}
