package com.ode.ca.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * @author rmathew
 *
 */
public class MailSender {

	private static final Logger logger = LogManager.getLogger(MailSender.class);

	private JavaMailSenderImpl mailSender;
	private String from = "";
	private String supportEmail = "";
	private String environment = "";

	/**
	 * @param email
	 * @param lenderDealerId
	 * @param userId
	 * @param dealNumber
	 * @param applicationNumber
	 * @param validationResults
	 * @param validationMessage
	 */
	public void sendEcackoutStatus(String email, String lenderDealerId, String userId, String dealNumber,
			String applicationNumber, String validationResults, String validationMessage) {
		StringBuilder sb = new StringBuilder();
		sb.append(lenderDealerId);
		sb.append(" / ");
		sb.append(userId);
		sb.append(" / ");
		sb.append(dealNumber);
		String subject = sb.toString();

		sb.setLength(0); // clear the buffer
		sb.append("Deal: ");
		sb.append(dealNumber);
		sb.append("\n App: ");
		sb.append(applicationNumber);
		sb.append("\n ");
		sb.append(validationResults);
		sb.append("\n ");
		sb.append(validationMessage);
		String body = sb.toString();

		sendEmail(subject, body, email);
	}

	public void sendEmail(String subject, String body, String email) {
		logger.entry();
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(email);
		message.setFrom(from);
		message.setSubject(getEnvironment() + ": " + subject);
		message.setText(body);
		try {
			mailSender.send(message);
		} catch (Exception e) {
			logger.error("could not send email", e);
		}
		logger.exit();
	}


	public void sendEncryptionEmail(String message) {
		String subject = environment + ": alert for key rotation";

		String body = "An error occured with keys.xml file. \n" + message;

		sendEmail(subject, body, supportEmail);
	}

	public JavaMailSenderImpl getMailSender() {
		return mailSender;
	}

	public void setMailSender(JavaMailSenderImpl mailSender) {
		this.mailSender = mailSender;
	}

	public String getSupportEmail() {
		return supportEmail;
	}

	public void setSupportEmail(String supportEmail) {
		this.supportEmail = supportEmail;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getEnvironment() {
		if ("development".equals(environment))
			return "DEV";
		if ("staging".equals(environment))
			return "STAGE";
		if ("qa".equals(environment))
			return "QA";
		if ("production".equals(environment))
			return "PROD";
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

}
