/*
 * Created on Mar 5, 2009
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.ca.util;

import java.util.Arrays;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;

/**
 * @author biswass
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RequestMessage {
	
	private String requestXml = null;
	private Header[] requestHeader = null;
	private String destinationURL = null;
	/**
	 * @return Returns the requestXml.
	 */
	public String getRequestXml() {
		return requestXml;
	}
	/**
	 * @param requestXml The requestXml to set.
	 */
	public void setRequestXml(String requestXml) {
		this.requestXml = requestXml;
	}	
	/**
	 * @return Returns the destinationURL.
	 */
	public String getDestinationURL() {
		return destinationURL;
	}
	/**
	 * @param destinationURL The destinationURL to set.
	 */
	public void setDestinationURL(String destinationURL) {
		this.destinationURL = destinationURL;
	}
	/**
	 * @return Returns the requestHeader.
	 */
	public Header[] getRequestHeader() {
		return requestHeader;
	}
	/**
	 * @param requestHeader The requestHeader to set.
	 */
	public void setRequestHeader(Header[] requestHeader) {
		this.requestHeader = requestHeader;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RequestMessage [");
		if (requestHeader != null) {
			builder.append("requestHeader=");
			builder.append(Arrays.toString(requestHeader));
			builder.append(", ");
		}
		if (destinationURL != null) {
			builder.append("destinationURL=");
			builder.append(destinationURL);
			builder.append(", ");
		}
		if (requestXml != null) {
			builder.append("requestXml=");
			builder.append(requestXml.replaceAll("[\r\n]+", " "));
		}
		builder.append("]");
		return builder.toString();
	}
	
}
