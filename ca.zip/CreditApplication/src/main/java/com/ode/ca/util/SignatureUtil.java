package com.ode.ca.util;

import java.io.FileInputStream;
import java.io.StringReader;
import java.security.KeyStore;

import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * @author rmathew
 *
 */
public class SignatureUtil {

	private static final Logger logger = LogManager.getLogger(SignatureUtil.class);

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	public static boolean verifySignature(String xml) throws Exception {
		logger.entry();
		if (xml == null || xml.isEmpty()) {
			throw new Exception("xml is null or empty - cannot verify signature");
		}

		Document doc = getNamespaceAwareDocument(xml);

		setIdAttributeForAllMatchingElements(doc, "id");
		setIdAttributeForAllMatchingElements(doc, "ID");
		setIdAttributeForAllMatchingElements(doc, "iD");
		setIdAttributeForAllMatchingElements(doc, "Id");

		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		if (nl.getLength() == 0) {
			throw new Exception("Cannot find Signature element");
		}
		KeyStore ks = KeyStore.getInstance(Constants.TRUST_KEY_STORE_TYPE);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(Constants.TRUST_KEY_STORE_FILE);
			// Load keystore
			ks.load(fis, Constants.TRUST_KEY_STORE_PASS.toCharArray());
		} catch (final Exception e) {

		} finally {
			try {
				fis.close();
			} catch (final Exception e) {
				logger.debug("Exception trying to close FileInputStream");
			}
		}
		DOMValidateContext valContext = new DOMValidateContext(new X509KeySelector(ks), nl.item(0));

		XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");

		XMLSignature signature = factory.unmarshalXMLSignature(valContext);

		return logger.exit(signature.validate(valContext));
	}

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	private static Document getNamespaceAwareDocument(String xml) throws Exception {
		logger.entry();

		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		docBuilderFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));

		return logger.exit(docBuilder.parse(is));
	}

	/**
	 * @param doc
	 * @param idAttributeName
	 * @throws XPathExpressionException
	 */
	private static void setIdAttributeForAllMatchingElements(Document doc, String idAttributeName)
			throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList nodeList = (NodeList) xpath.evaluate("//*[@" + idAttributeName + "]", doc, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				logger.debug("setting {} on element:{}", idAttributeName, element.getLocalName());
				element.setIdAttribute(idAttributeName, true);
			}
		}
	}
}