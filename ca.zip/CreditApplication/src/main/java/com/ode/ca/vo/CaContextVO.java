/**
 * 
 */
package com.ode.ca.vo;

import java.util.ArrayList;
import java.util.List;

import com.ode.ca.vo.DealerInfoVO;
import com.ode.ca.vo.JournalObjectVO;
import com.ode.ca.vo.PartnerInfoVO;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public class CaContextVO {
	
	private List<JournalObjectVO> listOfJournalObjects;
	private DeDealVO deal;
	private DeContractValidationVO contractValidation;
	private String roKey = null;
	private String documentId;
	private String userId;
	private String applicationSource;
	private String deliverySource;
	private String financeType;
	private String adpDealNo;
	private PartnerInfoVO partnerInfo;
	private DealerInfoVO dealerInfo;
	private String transType;
	private String partnerDealNumber;
	private String reResponseXml;
	
	
	public String getReResponseXml() {
		return reResponseXml;
	}

	public void setReResponseXml(String reResponseXml) {
		this.reResponseXml = reResponseXml;
	}

	public String getPartnerDealNumber() {
		return partnerDealNumber;
	}

	public void setPartnerDealNumber(String partnerDealNumber) {
		this.partnerDealNumber = partnerDealNumber;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public PartnerInfoVO getPartnerInfo() {
		return partnerInfo;
	}

	public void setPartnerInfo(PartnerInfoVO partnerInfo) {
		this.partnerInfo = partnerInfo;
	}

	public DealerInfoVO getDealerInfo() {
		return dealerInfo;
	}

	public void setDealerInfo(DealerInfoVO dealerInfo) {
		this.dealerInfo = dealerInfo;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public String getAdpDealNo() {
		return adpDealNo;
	}

	public void setAdpDealNo(String adpDealNo) {
		this.adpDealNo = adpDealNo;
	}

	public String getApplicationSource() {
		return applicationSource;
	}

	public void setApplicationSource(String applicationSource) {
		this.applicationSource = applicationSource;
	}

	public String getDeliverySource() {
		return deliverySource;
	}

	public void setDeliverySource(String deliverySource) {
		this.deliverySource = deliverySource;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoKey() {
		return roKey;
	}

	public void setRoKey(String roKey) {
		this.roKey = roKey;
	}

	public DeDealVO getDeal() {
		return deal;
	}	

	public DeContractValidationVO getContractValidation() {
		return contractValidation;
	}

	public void setContractValidation(DeContractValidationVO contractValidation) {
		this.contractValidation = contractValidation;
	}

	public void setDeal(final DeDealVO deal) {
		this.deal = deal;
	}

	public List<JournalObjectVO> getListOfJournalObjects() {
		return listOfJournalObjects;
	}

	public void setListOfJournalObjects(final List<JournalObjectVO> listOfJournalObjects) {
		this.listOfJournalObjects = listOfJournalObjects;
	}
	
	public void addToListOfJournalObjects(final JournalObjectVO journalObject) {
		if (this.listOfJournalObjects == null) {
			this.listOfJournalObjects = new ArrayList<>();
		}
		this.listOfJournalObjects.add(journalObject);
	}
	

}
