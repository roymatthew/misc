/**
 * 
 */
package com.ode.ca.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * @author rmathew
 *
 */
public class CreditDecisionDetailVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1849148798981457514L;
	
	private BigInteger creditDecisionId;
	private String dmsDealerId;
	private String lenderDealerId;
	private String dmsDealNum;
	private String lenderId;
	private String deDealId;
	private String sequenceId;
	private String r1lenderId;
	private String conversationId;
	private String r1SequenceNum;
	private Timestamp statusTs;
	private Timestamp submittedTs;
	private Timestamp decisionTs;
	private String  vin;
	private String buyerSSN;
	private String buyerFirstName;
	private String buyerLastName;
	private String buyerApplicationAddressLine;
	private String buyerApplicationAddressCity;
	private String buyerApplicationAddressState;
	private String buyerApplicationAddressZipCode;
	private String coBuyerSSN;
	private String coBuyerFirstName;
	private String coBuyerLastName;
	private String coBuyerApplicationAddressLine;
	private String coBuyerApplicationAddressCity;
	private String coBuyerApplicationAddressState;
	private String coBuyerApplicationAddressZipcode;
	private String applicationStatus;
	private String applicationNumber;
	private String model;
	private short modelYear;
	private BigDecimal amountFinanced;
	private String ltv;
	private String applicationType;
	private String modelDescription;
	private String make;
	private String salesClass;
	private boolean certifiedPreOwned;
	private BigDecimal deliveryMileage;
	private String vehicleStock;
	private String bodyStyle;
	private String financeType;
	private BigDecimal paymentAmount;
	private BigDecimal balanceAmount;
	private BigDecimal residualAmount;
	private BigDecimal purchasePrice;
	private BigDecimal term;
	private BigDecimal downpaymentAmount;
	private BigDecimal manufacturerRebateAmount;
	private BigDecimal annualPercentageRate;
	private BigDecimal netTradeAmount;
	private BigDecimal insuranceTotalExtendedWarrantyAmount;
	private BigDecimal disabilityPremiumAmount;
	private BigDecimal creditLifePremiumAmount;
	private BigDecimal securityDepositAmount;
	private String tier;
	private String stipulations;
	private short createdBy;
	private Timestamp createdTs;
	private short modifiedBy;
	private Timestamp modifiedTs;
	
	public BigInteger getCreditDecisionId() {
		return creditDecisionId;
	}
	public void setCreditDecisionId(BigInteger creditDecisionId) {
		this.creditDecisionId = creditDecisionId;
	}
	public String getDmsDealerId() {
		return dmsDealerId;
	}
	public void setDmsDealerId(String dmsDealerId) {
		this.dmsDealerId = dmsDealerId;
	}
	public String getLenderDealerId() {
		return lenderDealerId;
	}
	public void setLenderDealerId(String lenderDealerId) {
		this.lenderDealerId = lenderDealerId;
	}
	public String getDmsDealNum() {
		return dmsDealNum;
	}
	public void setDmsDealNum(String dmsDealNum) {
		this.dmsDealNum = dmsDealNum;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}
	public String getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}
	public String getR1lenderId() {
		return r1lenderId;
	}
	public void setR1lenderId(String r1lenderId) {
		this.r1lenderId = r1lenderId;
	}
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public String getR1SequenceNum() {
		return r1SequenceNum;
	}
	public void setR1SequenceNum(String r1SequenceNum) {
		this.r1SequenceNum = r1SequenceNum;
	}
	public Timestamp getStatusTs() {
		return statusTs;
	}
	public void setStatusTs(Timestamp statusTs) {
		this.statusTs = statusTs;
	}
	public Timestamp getSubmittedTs() {
		return submittedTs;
	}
	public void setSubmittedTs(Timestamp submittedTs) {
		this.submittedTs = submittedTs;
	}
	public Timestamp getDecisionTs() {
		return decisionTs;
	}
	public void setDecisionTs(Timestamp decisionTs) {
		this.decisionTs = decisionTs;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getBuyerSSN() {
		return buyerSSN;
	}
	public void setBuyerSSN(String buyerSSN) {
		this.buyerSSN = buyerSSN;
	}
	public String getBuyerFirstName() {
		return buyerFirstName;
	}
	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}
	public String getBuyerLastName() {
		return buyerLastName;
	}
	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}
	public String getBuyerApplicationAddressLine() {
		return buyerApplicationAddressLine;
	}
	public void setBuyerApplicationAddressLine(String buyerApplicationAddressLine) {
		this.buyerApplicationAddressLine = buyerApplicationAddressLine;
	}
	public String getBuyerApplicationAddressCity() {
		return buyerApplicationAddressCity;
	}
	public void setBuyerApplicationAddressCity(String buyerApplicationAddressCity) {
		this.buyerApplicationAddressCity = buyerApplicationAddressCity;
	}
	public String getBuyerApplicationAddressState() {
		return buyerApplicationAddressState;
	}
	public void setBuyerApplicationAddressState(String buyerApplicationAddressState) {
		this.buyerApplicationAddressState = buyerApplicationAddressState;
	}
	public String getBuyerApplicationAddressZipCode() {
		return buyerApplicationAddressZipCode;
	}
	public void setBuyerApplicationAddressZipCode(String buyerApplicationAddressZipCode) {
		this.buyerApplicationAddressZipCode = buyerApplicationAddressZipCode;
	}
	public String getCoBuyerSSN() {
		return coBuyerSSN;
	}
	public void setCoBuyerSSN(String coBuyerSSN) {
		this.coBuyerSSN = coBuyerSSN;
	}
	public String getCoBuyerFirstName() {
		return coBuyerFirstName;
	}
	public void setCoBuyerFirstName(String coBuyerFirstName) {
		this.coBuyerFirstName = coBuyerFirstName;
	}
	public String getCoBuyerLastName() {
		return coBuyerLastName;
	}
	public void setCoBuyerLastName(String coBuyerLastName) {
		this.coBuyerLastName = coBuyerLastName;
	}
	public String getCoBuyerApplicationAddressLine() {
		return coBuyerApplicationAddressLine;
	}
	public void setCoBuyerApplicationAddressLine(String coBuyerApplicationAddressLine) {
		this.coBuyerApplicationAddressLine = coBuyerApplicationAddressLine;
	}
	public String getCoBuyerApplicationAddressCity() {
		return coBuyerApplicationAddressCity;
	}
	public void setCoBuyerApplicationAddressCity(String coBuyerApplicationAddressCity) {
		this.coBuyerApplicationAddressCity = coBuyerApplicationAddressCity;
	}
	public String getCoBuyerApplicationAddressState() {
		return coBuyerApplicationAddressState;
	}
	public void setCoBuyerApplicationAddressState(String coBuyerApplicationAddressState) {
		this.coBuyerApplicationAddressState = coBuyerApplicationAddressState;
	}
	public String getCoBuyerApplicationAddressZipcode() {
		return coBuyerApplicationAddressZipcode;
	}
	public void setCoBuyerApplicationAddressZipcode(String coBuyerApplicationAddressZipcode) {
		this.coBuyerApplicationAddressZipcode = coBuyerApplicationAddressZipcode;
	}
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	public String getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public short getModelYear() {
		return modelYear;
	}
	public void setModelYear(short modelYear) {
		this.modelYear = modelYear;
	}
	public BigDecimal getAmountFinanced() {
		return amountFinanced;
	}
	public void setAmountFinanced(BigDecimal amountFinanced) {
		this.amountFinanced = amountFinanced;
	}
	public String getLtv() {
		return ltv;
	}
	public void setLtv(String ltv) {
		this.ltv = ltv;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getModelDescription() {
		return modelDescription;
	}
	public void setModelDescription(String modelDescription) {
		this.modelDescription = modelDescription;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getSalesClass() {
		return salesClass;
	}
	public void setSalesClass(String salesClass) {
		this.salesClass = salesClass;
	}
	public boolean isCertifiedPreOwned() {
		return certifiedPreOwned;
	}
	public void setCertifiedPreOwned(boolean certifiedPreOwned) {
		this.certifiedPreOwned = certifiedPreOwned;
	}
	public BigDecimal getDeliveryMileage() {
		return deliveryMileage;
	}
	public void setDeliveryMileage(BigDecimal deliveryMileage) {
		this.deliveryMileage = deliveryMileage;
	}
	public String getVehicleStock() {
		return vehicleStock;
	}
	public void setVehicleStock(String vehicleStock) {
		this.vehicleStock = vehicleStock;
	}
	public String getBodyStyle() {
		return bodyStyle;
	}
	public void setBodyStyle(String bodyStyle) {
		this.bodyStyle = bodyStyle;
	}
	public String getFinanceType() {
		return financeType;
	}
	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public BigDecimal getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(BigDecimal balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	public BigDecimal getResidualAmount() {
		return residualAmount;
	}
	public void setResidualAmount(BigDecimal residualAmount) {
		this.residualAmount = residualAmount;
	}
	public BigDecimal getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(BigDecimal purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public BigDecimal getTerm() {
		return term;
	}
	public void setTerm(BigDecimal term) {
		this.term = term;
	}
	public BigDecimal getDownpaymentAmount() {
		return downpaymentAmount;
	}
	public void setDownpaymentAmount(BigDecimal downpaymentAmount) {
		this.downpaymentAmount = downpaymentAmount;
	}
	public BigDecimal getManufacturerRebateAmount() {
		return manufacturerRebateAmount;
	}
	public void setManufacturerRebateAmount(BigDecimal manufacturerRebateAmount) {
		this.manufacturerRebateAmount = manufacturerRebateAmount;
	}
	public BigDecimal getAnnualPercentageRate() {
		return annualPercentageRate;
	}
	public void setAnnualPercentageRate(BigDecimal annualPercentageRate) {
		this.annualPercentageRate = annualPercentageRate;
	}
	public BigDecimal getNetTradeAmount() {
		return netTradeAmount;
	}
	public void setNetTradeAmount(BigDecimal netTradeAmount) {
		this.netTradeAmount = netTradeAmount;
	}
	public BigDecimal getInsuranceTotalExtendedWarrantyAmount() {
		return insuranceTotalExtendedWarrantyAmount;
	}
	public void setInsuranceTotalExtendedWarrantyAmount(BigDecimal insuranceTotalExtendedWarrantyAmount) {
		this.insuranceTotalExtendedWarrantyAmount = insuranceTotalExtendedWarrantyAmount;
	}
	public BigDecimal getDisabilityPremiumAmount() {
		return disabilityPremiumAmount;
	}
	public void setDisabilityPremiumAmount(BigDecimal disabilityPremiumAmount) {
		this.disabilityPremiumAmount = disabilityPremiumAmount;
	}
	public BigDecimal getCreditLifePremiumAmount() {
		return creditLifePremiumAmount;
	}
	public void setCreditLifePremiumAmount(BigDecimal creditLifePremiumAmount) {
		this.creditLifePremiumAmount = creditLifePremiumAmount;
	}
	public BigDecimal getSecurityDepositAmount() {
		return securityDepositAmount;
	}
	public void setSecurityDepositAmount(BigDecimal securityDepositAmount) {
		this.securityDepositAmount = securityDepositAmount;
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getStipulations() {
		return stipulations;
	}
	public void setStipulations(String stipulations) {
		this.stipulations = stipulations;
	}
	public short getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(short createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}
	public short getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(short modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	@Override
	public String toString() {
		return "CreditDecisionVO [creditDecisionId=" + creditDecisionId + ", dmsDealerId=" + dmsDealerId
				+ ", lenderDealerId=" + lenderDealerId + ", dmsDealNum=" + dmsDealNum + ", lenderId=" + lenderId
				+ ", deDealId=" + deDealId + ", sequenceId=" + sequenceId + ", r1lenderId=" + r1lenderId
				+ ", conversationId=" + conversationId + ", r1SequenceNum=" + r1SequenceNum + ", statusTs=" + statusTs
				+ ", submittedTs=" + submittedTs + ", decisionTs=" + decisionTs + ", vin=" + vin + ", buyerSSN="
				+ buyerSSN + ", buyerFirstName=" + buyerFirstName + ", buyerLastName=" + buyerLastName
				+ ", buyerApplicationtAddressLine=" + buyerApplicationAddressLine + ", buyerApplicationtAddressCity="
				+ buyerApplicationAddressCity + ", buyerApplicationtAddressState=" + buyerApplicationAddressState
				+ ", buyerApplicationtAddressZipCode=" + buyerApplicationAddressZipCode + ", coBuyerSSN=" + coBuyerSSN
				+ ", coBuyerFirstName=" + coBuyerFirstName + ", coBuyerLastName=" + coBuyerLastName
				+ ", coBuyerApplicationtAddressLine=" + coBuyerApplicationAddressLine
				+ ", coBuyerApplicationtAddressCity=" + coBuyerApplicationAddressCity
				+ ", coBuyerApplicationtAddressState=" + coBuyerApplicationAddressState
				+ ", coBuyerApplicationtAddressZipcode=" + coBuyerApplicationAddressZipcode + ", applicationStatus="
				+ applicationStatus + ", applicationNumber=" + applicationNumber + ", model=" + model + ", modelYear="
				+ modelYear + ", amountFinanced=" + amountFinanced + ", ltv=" + ltv + ", applicationType="
				+ applicationType + ", modelDescription=" + modelDescription + ", make=" + make + ", salesClass="
				+ salesClass + ", certifiedPreOwned=" + certifiedPreOwned + ", deliveryMileage=" + deliveryMileage
				+ ", vehicleStock=" + vehicleStock + ", bodyStyle=" + bodyStyle + ", financeType=" + financeType
				+ ", paymentAmount=" + paymentAmount + ", balanceAmount=" + balanceAmount + ", residualAmount="
				+ residualAmount + ", purchasePrice=" + purchasePrice + ", term=" + term + ", downpaymentAmount="
				+ downpaymentAmount + ", manufacturerRebateAmount=" + manufacturerRebateAmount
				+ ", annualPercentageRate=" + annualPercentageRate + ", netTradeAmount=" + netTradeAmount
				+ ", insuranceTotalExtendedWarrantyAmount=" + insuranceTotalExtendedWarrantyAmount
				+ ", disabilityPremiumAmount=" + disabilityPremiumAmount + ", creditLifePremiumAmount="
				+ creditLifePremiumAmount + ", securityDepositAmount=" + securityDepositAmount + ", tier=" + tier
				+ ", stipulations=" + stipulations + ", createdBy=" + createdBy + ", createdTs=" + createdTs
				+ ", modifiedBy=" + modifiedBy + ", modifiedTs=" + modifiedTs + "]";
	}
	
	

}
