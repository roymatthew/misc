/**
 * 
 */
package com.ode.ca.vo;

import java.io.Serializable;

import com.ode.persistence.vo.CreditDecisionVO;

/**
 * @author rmathew
 *
 */
public class CreditDecisionWrapperVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3153194339295525515L;

	private CreditDecisionDetailVO creditDecisionDetailVO;
	private CreditDecisionVO creditDecisionVO;

	public CreditDecisionWrapperVO(final CreditDecisionDetailVO creditDecisionDetailVO,
			final CreditDecisionVO creditDecisionVO) {
		super();
		this.creditDecisionDetailVO = creditDecisionDetailVO;
		this.creditDecisionVO = creditDecisionVO;
	}

	public CreditDecisionDetailVO getCreditDecisionDetailVO() {
		return creditDecisionDetailVO;
	}

	public void setCreditDecisionDetailVO(CreditDecisionDetailVO creditDecisionDetailVO) {
		this.creditDecisionDetailVO = creditDecisionDetailVO;
	}

	public CreditDecisionVO getCreditDecisionVO() {
		return creditDecisionVO;
	}

	public void setCreditDecisionVO(CreditDecisionVO creditDecisionVO) {
		this.creditDecisionVO = creditDecisionVO;
	}

	@Override
	public String toString() {
		return "CreditDecisionWrapperVO [creditDecisionDetailVO=" + creditDecisionDetailVO + ", creditDecisionVO="
				+ creditDecisionVO + "]";
	}

}
