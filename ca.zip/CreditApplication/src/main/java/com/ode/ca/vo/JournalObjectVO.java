/*
 * Created on Mar 26, 2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.ca.vo;

import java.io.Serializable;
import java.sql.Timestamp;

import com.ode.dlr.util.AppMessage;
import com.ode.persistence.vo.CreditJournalVO;

/**
 * @author mariappb
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class JournalObjectVO implements Serializable{

	private String xmlData;
	private Timestamp timestamp;
	private AppMessage appMessage;
	private static final long serialVersionUID = 002;
	private String transType;
	private CreditJournalVO creditJournal;
	
	public JournalObjectVO(){
		this.setTransType(transType);
		this.setTimestamp((new com.ode.dlr.util.Timestamp()).getJDBCTimestamp());  //get a unique timestamp upto microseconds
		this.setXmlData(xmlData);
	}
	public void setTransType(String tt){
		transType = tt;
	}
	
	public String getTransType(){
		return transType;
	}
	
	public void setXmlData(String xml){
		xmlData = xml;
	}
	
	public String getXmlData(){
		return xmlData;
	}
	
	public void setTimestamp(Timestamp ts){
		timestamp = ts;
	}
	
	public Timestamp getTimestamp(){
		return timestamp;
	}
	
	public void setAppMsg(AppMessage am){
		appMessage = am;
	}
	
	public AppMessage getAppMessage(){
		return appMessage;
	}
	public CreditJournalVO getCreditJournal() {
		return creditJournal;
	}
	public void setCreditJournal(CreditJournalVO creditJournal) {
		this.creditJournal = creditJournal;
	}
	
	
}
