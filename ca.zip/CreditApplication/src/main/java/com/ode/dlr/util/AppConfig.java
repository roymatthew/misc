/*
 * Created on Apr 14, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.dlr.util;

/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.util.Properties;


public class AppConfig {


	public static final String TransType_String = "TRANSTYPE";

	/**
	 * DBConfig constructor.
	 */
	public AppConfig() {
	}

	protected  Properties initializeValues(String loc) throws Exception{
		Properties props = new Properties();
		props.load(getClass().getResourceAsStream(loc));
		return  props;
	} //initializeValues

}
