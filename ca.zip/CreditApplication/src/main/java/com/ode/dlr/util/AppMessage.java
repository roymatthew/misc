/*
 * Created on Aug 9, 2004
 *
 */
package com.ode.dlr.util;

import java.io.Serializable;

/**
 *
 * This class is a place holder for Application Messages. This class is used by 
 * AppMessageHolder to convert Application Messages into Java Object.
 * 
 * @author rsubramani
 */
public class AppMessage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String messageID = null;
	private String message = null;
	private String messageFR = null;

	private boolean overriderInd = false;
	private boolean eventviewerInd = true;
	private String loggingType = null;
	private boolean traceInd = true;
	
	

	/**
	 * private constructor to avoid creating an empty object  
	 */
	private AppMessage() {
	}

	/**
	 * This is the only constructor to be used to create the object
	 * @param msgID - Message ID for the Message
	 * @param localMsg - Local Message Description
	 * @param localMsgFR - Local Message Description in French
	 * @param dtlMsg - Detailed Message Description
	 */
	public AppMessage(String msgID, String description, String descriptionFR,String logtype,boolean overrideind, boolean eventind, boolean trace) {
		messageID = msgID;
		message = description;
		overriderInd = overrideind;
		eventviewerInd = eventind;
		loggingType =logtype;
		traceInd = trace;
		
	}
	
	
	public String getMessage() {
		return message;
	}

	/**
	 * @return String Local Message in French
	 */
	public String getMessageFR() {
		return messageFR;
	}

	/**
	 * @return String MessageID
	 */
	public String getMessageID() {
		return messageID;
	}

	public java.lang.String getLoggingtype(){
		return loggingType;
	}

    
    /**
     * Gets the value of the traceind property.
     * 
     */
    public boolean isTraceind(){
    	return traceInd;
    }

    
    /**
     * Gets the value of the contextind property.
     * 
     */
    public boolean isEventvieweron(){
    	return eventviewerInd;
    }

    /**
     * Gets the value of the contextind property.
     * 
     */
    public boolean isOverrideron(){
    	return overriderInd;
    }

	/**
	 * @param message The message to set.
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}
	
}
