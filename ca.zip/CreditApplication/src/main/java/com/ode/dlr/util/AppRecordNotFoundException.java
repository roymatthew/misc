/*
 * Created on Apr 20, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.dlr.util;

/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AppRecordNotFoundException extends AppException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AppRecordNotFoundException (String msg,String context,String pgm){
		super(msg,context,pgm);
	}

}
