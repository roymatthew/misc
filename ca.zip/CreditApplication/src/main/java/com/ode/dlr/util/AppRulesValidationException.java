package com.ode.dlr.util;


public class AppRulesValidationException extends AppException {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AppRulesValidationException(String msg, String context, String pgm) {
		super(msg, context, pgm);
	}

	/**
	 * @param msg
	 * @param e
	 * @param context
	 * @param pgm
	 * @param tracemesg
	 */
	public AppRulesValidationException(String str1, Exception e, String str2, String pgm, String str3) {
		super(str1, e, str2, pgm, str3);
	}
	
}