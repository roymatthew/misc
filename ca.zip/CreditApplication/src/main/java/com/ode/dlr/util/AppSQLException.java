/*
 * Created on Apr 17, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.dlr.util;

/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.sql.SQLException;
import java.sql.SQLWarning;

public class AppSQLException extends AppException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean warning = false;
	private int sqlCode;
	private String sqlState;
	private String delimitedData= null;
	
	public AppSQLException(SQLException exp,String context,String pgm){
		super(exp.getMessage(), exp, context,pgm);
		initializeVars( exp);
	}
	
	/**
	 * 
	 * @param exp
	 * @param context
	 * @param pgm
	 * @param delimitedData
	 */
	public AppSQLException(SQLException exp, String context, String pgm, String delimData){
		super(exp.getMessage(), exp, context,pgm);
		initializeVars( exp);
        delimitedData= delimData;
	}
	
	private void initializeVars( SQLException exp) {
		if (exp instanceof SQLWarning) {
			warning = true;
		}		
		sqlCode = exp.getErrorCode();
		sqlState = exp.getSQLState();
		
		if (sqlState == null ) {
			SQLException tempSql = exp.getNextException();
			if (tempSql != null){
				sqlCode = tempSql.getErrorCode();
				sqlState = tempSql.getSQLState();
			}
		}
	}
	
	public boolean isSQLWarning(){
		return warning;
	}
	
	public int getSqlCode(){
		return sqlCode;
	}
	
	public String getSqlState(){
		return sqlState;
	}

	public String getDelimitedData(){
		return delimitedData;
	}
}
