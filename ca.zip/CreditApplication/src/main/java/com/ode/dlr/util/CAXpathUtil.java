/**
 * 
 */
package com.ode.dlr.util;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * @author rmathew
 *
 */
public class CAXpathUtil {

	private static final Logger log = LogManager.getLogger(CAXpathUtil.class);

	private static final String PATH_TO_OPERATION_HEADER = "/Envelope/Header/payloadManifest/manifest";
	private static final String PATH_TO_CONTRACT_ELEMENT = "/payload/content";

	private CAXpathUtil() {
		super();
	}

	public static String getContractName(final String inputXML) {
		System.out.println("Entered getContractName() of CVXpathUtil");
		String operationName = "";
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		Node elementNode = null;
		try {
			DocumentBuilder docBuilder = factory.newDocumentBuilder();
			final Document document = docBuilder.parse(new InputSource(new StringReader(inputXML)));
			Node node = XPathAPI.selectSingleNode(document, PATH_TO_CONTRACT_ELEMENT);
			System.out.println("Node Name: " + node.getNodeName());
			operationName = node.getChildNodes().item(1).getNodeName();
			System.out.println("OperationName: " + operationName);
/*			for (int i = 0; i < node.getChildNodes().getLength(); i++)
			{
				Node child = node.getChildNodes().item(i);
				System.out.println("Child Node Name: " + child.getNodeName());
			}*/

			//log.debug("OperationName: " + operationName);
		} catch (ParserConfigurationException e) {
			log.error(e);
		} catch (SAXException e) {
			log.error(e);
		} catch (IOException e) {
			log.error(e);
		} catch (TransformerException e) {
			log.error(e);
		}
		return operationName;

	}
	
	
	public static String getOperationName(final String inputXML) {
		log.debug("Entered getOperationName() of CVXpathUtil");
		String operationName = "";
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		Node elementNode = null;
		try {
			DocumentBuilder docBuilder = factory.newDocumentBuilder();
			final Document document = docBuilder.parse(new InputSource(new StringReader(inputXML)));
			//String operation = XPathAPI.eval(document, PATH_TO_OPERATION_HEADER).toString();
			Node node = XPathAPI.selectSingleNode(document, PATH_TO_OPERATION_HEADER);
			NamedNodeMap map = node.getAttributes();
			elementNode = map.getNamedItem("element");
			operationName = elementNode.getNodeValue();
			log.debug("OperationName: " + operationName);
		} catch (ParserConfigurationException e) {
			log.error(e);
		} catch (SAXException e) {
			log.error(e);
		} catch (IOException e) {
			log.error(e);
		} catch (TransformerException e) {
			log.error(e);
		}
		return operationName;

	}

}
