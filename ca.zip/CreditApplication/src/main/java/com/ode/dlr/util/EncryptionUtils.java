package com.ode.dlr.util;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.ca.util.MailSender;

/**
 * Encryption utility that uses 128-bit RC4 encryption to encrypt and decrypt
 * text.
 * 
 * @author Robert Roeser Code modfied on 04-09-2009 to avoid thread safe issue
 *         Static base64encoder is moved into the function and added
 *         synchronized to make it thread safe
 */
public final class EncryptionUtils {
	private static final String pgm = EncryptionUtils.class.getName();
	private static final Logger logger = LogManager.getLogger(EncryptionUtils.class);

	private static final String HARDCODED_KEYID = "000";
	private static final String HARDCODED_KEYSTRING = "6s1l2c7gv3k209ii5ilgw";
	private static final String HARDCODED_ALGORITHM = "PBEWithSHA1AndRC4_128";
	private static final String DEFAULT_KEYID = "001";

	private static List<Keys> keyInfo;
	static {
		keyInfo = Keys.getKeyInfo();
	}

	private static final int count = 20;
	private static final byte[] salt = { (byte) 0xc7, (byte) 0x7d, (byte) 0x21, (byte) 0x8c, (byte) 0x7e, (byte) 0xc8,
			(byte) 0xee, (byte) 0x96 };
	private static final byte[] IV = { (byte) 0x93, (byte) 0xCE, (byte) 0xA9, (byte) 0x7E, (byte) 0x83, (byte) 0xAE,
			(byte) 0x72, (byte) 0xAB, (byte) 0x0B, (byte) 0x39, (byte) 0xDF, (byte) 0x7E, (byte) 0x43, (byte) 0x5B,
			(byte) 0x86, (byte) 0x0C };

	/**
	 * Takes in text data, and returns a the data as base64 encoded string.
	 * 
	 * @param dataToEncrypt The text data to encrypt
	 * @param password      The password
	 * @return Base64 encoded encrypted text
	 * 
	 * @throws EncryptionException
	 */
	public synchronized static final List<String> encryptText(String dataToEncrypt) throws EncryptionException {
		logger.debug("Entered encryptText()");
		// BASE64Encoder base64Encoder = new BASE64Encoder();
		Encoder base64Encoder = Base64.getEncoder();
		List<String> encryptedText = new ArrayList<String>();

		String keyId = HARDCODED_KEYID;
		String password = HARDCODED_KEYSTRING;
		String algorithm = HARDCODED_ALGORITHM;
		Date now = new Date();
		boolean matchFound = false;

		for (Keys key : keyInfo) {
			// get active key with current system timestamp
			if (key.getEffectiveDate().before(now) && key.getExpiryDate().after(now)) {
				keyId = key.getKeyId();
				password = key.getKeyString();
				algorithm = key.getAlgorithm();
				matchFound = true;
				break;
			}
		}

		if (!keyInfo.isEmpty() && !matchFound) {
			logger.error("could not find an active key, will use default key: " + DEFAULT_KEYID);
			new MailSender()
					.sendEncryptionEmail("could not find an active key, will use default key: " + DEFAULT_KEYID);
			keyId = DEFAULT_KEYID;
			for (Keys key : keyInfo) {
				if (key.getKeyId().equals(keyId)) {
					password = key.getKeyString();
					algorithm = key.getAlgorithm();
					matchFound = true;
					break;
				}
			}
		}

		if (!matchFound) {
			logger.error("could not find an active key, will use default key: " + HARDCODED_KEYID);
			new MailSender()
					.sendEncryptionEmail("could not find an active key, will use default key: " + HARDCODED_KEYID);
		}

		try {
			logger.debug("keyId:{}", keyId);
			logger.debug("algorithm:{}", algorithm);

			PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
			PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, count, new IvParameterSpec(IV));
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
			SecretKey key = keyFactory.generateSecret(keySpec);

			Cipher cipher = Cipher.getInstance(algorithm);
			cipher.init(Cipher.ENCRYPT_MODE, key, parameterSpec);

			byte[] encryptedBytes = cipher.doFinal(dataToEncrypt.getBytes());
			encryptedText.add(0, keyId);
			encryptedText.add(1, String.valueOf(base64Encoder.encode(encryptedBytes)));

			return encryptedText;
		} catch (Exception e) {
			logger.error("Exception while encrypting", e);
			throw new EncryptionException("Exception while encrypting", e, "encryptText", pgm);
		}

	}

	/**
	 * Takes in encrypted text data as a base64 encoded string, and returns
	 * enecrypted data.
	 * 
	 * @param dataToDecrypt The data to decrypt
	 * @param password      The password
	 * @return Encrypted text data
	 * 
	 * @throws EncryptionException
	 */
	public synchronized static final String decryptText(String dataToDecrypt, String keyId) throws Exception {
		
		logger.debug("Entered decryptText()");
		//BASE64Decoder base64Decoder = new BASE64Decoder();
		Decoder base64Decoder = Base64.getDecoder();

		String password = "";
		String algorithm = "";
		boolean matchFound = false;
		if (keyId != null && keyId.equals(HARDCODED_KEYID)) {
			password = HARDCODED_KEYSTRING;
			algorithm = HARDCODED_ALGORITHM;
		} else {
			if (keyInfo.isEmpty()) {
				new MailSender().sendEncryptionEmail("No data from keys.xml available. Cannot decrypt xml.");
				throw new Exception("No data from keys.xml available. Cannot decrypt xml.");
			}
			if (keyId == null) {
				keyId = DEFAULT_KEYID;
			}
			for (Keys key : keyInfo) {
				// look up password with the data associated keyId
				if (key.getKeyId().equals(keyId)) {
					password = key.getKeyString();
					algorithm = key.getAlgorithm();
					matchFound = true;
					break;
				}
			}
			if (!matchFound) {
				logger.error("could not find a matching key in keys.xml - cannot decrypt xml");
				new MailSender().sendEncryptionEmail("could not find a matching key in keys.xml - cannot decrypt xml");
				throw new Exception("could not find a matching key in keys.xml - cannot decrypt xml");
			}
		}

		try {
			logger.debug("keyId:{}", keyId);
			logger.debug("algorithm:{}", algorithm);

			PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, 20, 32);
			PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, count, new IvParameterSpec(IV));

			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
			SecretKey key = keyFactory.generateSecret(keySpec);

			Cipher cipher = Cipher.getInstance(algorithm);
			cipher.init(Cipher.DECRYPT_MODE, key, parameterSpec);

			byte[] encryptedBytes = base64Decoder.decode(dataToDecrypt);
			byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

			return new String(decryptedBytes);

		} catch (Exception e) {
			logger.error("Exception while decrypting", e);
			throw new EncryptionException("Exception while decrypting", e, "decryptText", pgm);
		}

	}
}
