/*
 * Created on Apr 20, 2006
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.dlr.util;


/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface EventHandler {

	public  final String DOT = " : ";
	public  final String errorCode = "Error Code :";
	public  final String sqlState  = "SQL State :";
	public  final String error ="error";
	public  final String trace = "trace";
	public  final String info  = "info";
	public  final String warn  = "warn";

}
