package com.ode.ca;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.ode.ca.factory.VOFactoryTest;
import com.ode.ca.service.CaDecisionExportServiceTest;
import com.ode.ca.util.CadeXmlParserSpringTest;
import com.ode.ca.vo.CreditDecisionDetailVOTest;
import com.ode.ca.vo.CreditDecisionWrapperVOTest;

@RunWith(Suite.class)
@SuiteClasses({ VOFactoryTest.class, CaDecisionExportServiceTest.class, CadeXmlParserSpringTest.class,
		CreditDecisionDetailVOTest.class, CreditDecisionWrapperVOTest.class })
public class AllTests {

}
