/**
 * 
 */
package com.ode.ca.factory;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import com.ode.ca.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;

import org.junit.Ignore;
import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for JournalFactory
 *
 * @see com.ode.ca.factory.JournalFactory
 * @author rmathew
 */
public class JournalFactoryTest {

	/**
	 * Parasoft Jtest UTA: Test for createJournalObject(String, AppMessage, String)
	 *
	 * @see com.ode.ca.factory.JournalFactory#createJournalObject(String, AppMessage, String)
	 * @author rmathew
	 */
	@Ignore
	@Test(timeout = 2000)
	public void testCreateJournalObject() throws Throwable {
		// When
		String transType = ""; // UTA: default value
		AppMessage appMessage = mockAppMessage();
		String xmlString = ""; // UTA: default value
		JournalObjectVO result = JournalFactory.createJournalObject(transType, appMessage, xmlString);

		// Then
		// assertNotNull(result);
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of AppMessage
	 */
	private static AppMessage mockAppMessage() throws Throwable {
		AppMessage appMessage = mock(AppMessage.class);
		return appMessage;
	}
}