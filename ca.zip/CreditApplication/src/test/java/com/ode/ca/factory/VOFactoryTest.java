package com.ode.ca.factory;

import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;

import com.ode.ca.CreditApplication;
import com.ode.ca.util.CadeXmlParser;
import com.ode.ca.vo.CreditDecisionDetailVO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = CreditApplication.class)
public class VOFactoryTest {
	
	private static final String EDOCIN_XML_FILE = "CreditDecisionTest1.xml";
	
	@Autowired
	private CadeXmlParser cadeXMLParser;
	
	@Autowired
	private VOFactory voFactory;

	@Ignore
	@Test
	public void testCreateCreditDecisionVO() throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		final Document document = docBuilder
				.parse(ClassLoader.getSystemClassLoader().getResourceAsStream(EDOCIN_XML_FILE));
		String caDecisionXml = getStringFromDocument(document);
		Document processCreditDecisionDoc = cadeXMLParser.getProcessCreditDecisionDocument(caDecisionXml);
		CreditDecisionDetailVO creditDecisionVO = voFactory.createCreditDecisionDetailVO(processCreditDecisionDoc);
		
		Assert.assertNotNull(creditDecisionVO.getConversationId());
		Assert.assertNotNull(creditDecisionVO.getLenderId());
		Assert.assertNotNull(creditDecisionVO.getModel());
	}
	
	private static String getStringFromDocument(Document doc) throws TransformerException {
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		return writer.toString();
	}

}
