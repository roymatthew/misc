/**
 * 
 */
package com.ode.ca.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import com.ode.dlr.util.AppMessage;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

/**
 * Parasoft Jtest UTA: Test class for CaMsgHolder
 *
 * @see com.ode.ca.util.CaMsgHolder
 * @author rmathew
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@DirtiesContext // Parasoft Jtest UTA: Reset context for each test run
public class CaMsgHolderSpringTest {

	@Mock
	private AppMsgHolder component;

	/**
	 * Parasoft Jtest UTA: Test for getAppMessage(Throwable)
	 *
	 * @see com.ode.ca.util.CaMsgHolder#getAppMessage(Throwable)
	 * @author rmathew
	 */
	@Ignore
	@Test(timeout = 1000)
	public void testGetAppMessage() throws Throwable {
		// When
		Throwable msgID = mockThrowable();
		AppMessage appMsg = new AppMessage("test", "test", "test", "test", false, false, false);
		Mockito.doReturn(appMsg).when(component).getAppMessage(msgID);
		AppMessage result = component.getAppMessage(msgID);

		// Then
		assertNotNull(result);
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of Throwable
	 */
	private static Throwable mockThrowable() throws Throwable {
		Throwable msgID = mock(Throwable.class);
		return msgID;
	}
}