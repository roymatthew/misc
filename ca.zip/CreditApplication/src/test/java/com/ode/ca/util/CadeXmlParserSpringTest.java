/**
 * 
 */
package com.ode.ca.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

/**
 * Parasoft Jtest UTA: Test class for CadeXmlParser
 *
 * @see com.ode.ca.util.CadeXmlParser
 * @author rmathew
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@DirtiesContext // Parasoft Jtest UTA: Reset context for each test run
public class CadeXmlParserSpringTest {

	// Parasoft Jtest UTA: Component under test
	@Autowired
	CadeXmlParser component;

	/**
	 * Parasoft Jtest UTA: Test for getProcessCreditDecisionDocument(String)
	 *
	 * @see com.ode.ca.util.CadeXmlParser#getProcessCreditDecisionDocument(String)
	 * @author rmathew
	 */
	@Ignore
	@Test(timeout = 1000)
	public void testGetProcessCreditDecisionDocument() throws Throwable {
		// When
		String inputXml = ""; // UTA: default value
		Document result = component.getProcessCreditDecisionDocument(inputXml);

		// Then
		// assertNotNull(result);
	}
}