package com.ode.ca.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.xpath.XPathAPI;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ode.ca.CreditApplication;
import com.ode.ca.vo.CreditDecisionDetailVO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = CreditApplication.class)
@TestPropertySource("classpath:cdxpath.properties")
public class CreditDecisionUtilTest {

	private static final String EDOCIN_XML_FILE = "CreditDecisionTest1.xml";

	@Autowired
	private Environment env;

	@Ignore
	@Test
	public void testExtractElementValue() throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		final Document document = docBuilder
				.parse(ClassLoader.getSystemClassLoader().getResourceAsStream(EDOCIN_XML_FILE));
		String conversationId = getElementValue(document, "A:ConversationID");
		System.out.println("A:ConversationID -> " + conversationId);
	}

	private String getElementValue(Document document, String tagname) {
		Node node = document.getElementsByTagName(tagname).item(0);
		return node.getTextContent();
	}

	@Ignore
	@Test
	public void testXpathEval() throws TransformerException, ParserConfigurationException, SAXException, IOException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		final Document document = docBuilder
				.parse(ClassLoader.getSystemClassLoader().getResourceAsStream(EDOCIN_XML_FILE));
		NodeList nodeList = document.getElementsByTagName("D:Body");
		Node bodyNode = nodeList.item(0);
		String processCDXML = getStringFromNode(bodyNode);
		factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		docBuilder = factory.newDocumentBuilder();
		final Document pccDoc = docBuilder.parse(new InputSource(new StringReader(processCDXML)));
		// String xpath = "/Body/RouteOne/ConversationID";

		CreditDecisionDetailVO creditDecisionVO = loadCDFromDocument(pccDoc);
		Assert.assertNotNull(creditDecisionVO.getConversationId());
		Assert.assertNotNull(creditDecisionVO.getLenderId());
		Assert.assertNotNull(creditDecisionVO.getModel());

		System.out.println(creditDecisionVO);

	}
	
	@Ignore
	@Test
	public void testCountOfCoBuyers() throws ParserConfigurationException, TransformerException, SAXException, IOException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		final Document document = docBuilder
				.parse(ClassLoader.getSystemClassLoader().getResourceAsStream(EDOCIN_XML_FILE));
		NodeList nodeList = document.getElementsByTagName("D:Body");
		Node bodyNode = nodeList.item(0);
		String processCDXML = getStringFromNode(bodyNode);
		factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		docBuilder = factory.newDocumentBuilder();
		final Document pccDoc = docBuilder.parse(new InputSource(new StringReader(processCDXML)));
		
		Object countObj = evaluateXpathValue(pccDoc, "countofcoapplicants");
		System.out.println((String)countObj);
		String buyerSsn = (String)evaluateXpathValue(pccDoc, "buyerssn");
		String coBuyerSsn = (String)evaluateXpathValue(pccDoc, "cobuyerssn");
		System.out.println("buyerssn= " + buyerSsn + " cobuyerssn= " + coBuyerSsn);
	}

	private CreditDecisionDetailVO loadCDFromDocument(Document pccDoc)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, TransformerException {

		CreditDecisionDetailVO creditDecisionVO = new CreditDecisionDetailVO();
		Method[] methods = ReflectionUtils.getAllDeclaredMethods(CreditDecisionDetailVO.class);
		int len = methods.length;
		for (int i = 0; i < len; i++) {
			String setterProperty = null;
			if (methods[i].getName().startsWith("set")) {
				String parameterType = methods[i].getParameterTypes()[0].getTypeName();
				setterProperty = methods[i].getName().substring(3).toLowerCase();
				System.out.println("setterProperty = " + setterProperty + ", type = " + parameterType);
				Object obj = evaluateXpathValue(pccDoc, setterProperty);
				if (null != obj) {
					String xpathValue = (String) obj;
					xpathValue = xpathValue.trim();
					if ("java.lang.String".equals(parameterType)) {
						methods[i].invoke(creditDecisionVO, xpathValue);
					} else if ("java.math.BigDecimal".equals(parameterType)) {
						BigDecimal val = new BigDecimal(xpathValue);
						methods[i].invoke(creditDecisionVO, val);
					} else if ("short".equals(parameterType)) {
						short val = Short.parseShort(xpathValue);
						methods[i].invoke(creditDecisionVO, val);
					} else if ("java.sql.Timestamp".equals(parameterType)) {
						Timestamp val = new Timestamp(Long.valueOf(xpathValue).longValue());
						methods[i].invoke(creditDecisionVO, val);
					} else if ("boolean".equals(parameterType)) {
						short val = Short.parseShort(xpathValue);
						boolean booleanVal = val == 0 ? false : true;
						methods[i].invoke(creditDecisionVO, booleanVal);
					}
				}

			}
		}

		return creditDecisionVO;
	}

	private Object evaluateXpathValue(final Document pccDoc, final String setterProperty) throws TransformerException {

		String xpath = env.getProperty(setterProperty);
		if (null == setterProperty || null == xpath) {
			return null;
		}
		System.out.println("setterProperty = " + setterProperty);
		String xpathValue = XPathAPI.eval(pccDoc, xpath).toString();
		System.out.println("xpath = " + xpath + " -> value = " + xpathValue);
		return xpathValue;
	}

	@Ignore
	@Test
	public void testDocCreation()
			throws ParserConfigurationException, SAXException, IOException, JAXBException, TransformerException {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		final Document document = docBuilder
				.parse(ClassLoader.getSystemClassLoader().getResourceAsStream(EDOCIN_XML_FILE));
		// document.getTextContent();
		Assert.assertNotNull(document);
		NodeList nodeList = document.getElementsByTagName("B:ProcessCreditDecision");
		Assert.assertNotNull(nodeList);
		Assert.assertTrue(nodeList.getLength() > 0);
		System.out.println("NodeList length: " + nodeList.getLength());
		Node processCreditDecisionNode = nodeList.item(0);
		NodeList childNodes = processCreditDecisionNode.getChildNodes();

		String processCDXML = getStringFromNode(processCreditDecisionNode);

		// System.out.println(processCDXML);

		factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		docBuilder = factory.newDocumentBuilder();
		final Document pccDoc = docBuilder.parse(new InputSource(new StringReader(processCDXML)));

		nodeList = pccDoc.getElementsByTagName("ProcessCreditDecision");
		Assert.assertNotNull(nodeList);
		Assert.assertTrue(nodeList.getLength() > 0);
		System.out.println("NodeList length: " + nodeList.getLength());
		processCreditDecisionNode = nodeList.item(0);
		childNodes = processCreditDecisionNode.getChildNodes();
		for (int i = 0; i < childNodes.getLength(); i++) {
			System.out.println(childNodes.item(i).getNodeName());
		}

		/*
		 * JAXBContext jc = JAXBContext.newInstance("org.starstandards.star");
		 * Unmarshaller unmarshaller = jc.createUnmarshaller(); //ProcessCreditDecision
		 * root = (ProcessCreditDecision)
		 * unmarshaller.unmarshal(processCreditDecisionNode); //JAXBElement root =
		 * (JAXBElement) unmarshaller.unmarshal(pccDoc);
		 * JAXBElement<ProcessCreditDecision> root =
		 * unmarshaller.unmarshal(processCreditDecisionNode,
		 * ProcessCreditDecision.class); System.out.println(root.getDeclaredType() +
		 * " ---> " + root.getName()); ProcessCreditDecision pcc = root.getValue();
		 * ApplicationArea applicationArea = pcc.getApplicationArea();
		 * ProcessCreditDecisionDataArea dataArea = pcc.getDataArea();
		 * Assert.assertNotNull(applicationArea); Assert.assertNotNull(dataArea);
		 */

	}

	public static String getStringFromDocument(Document doc) throws TransformerException {
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		return writer.toString();
	}

	public static String getStringFromNode(Node node) throws TransformerException, FileNotFoundException {

		File file = ResourceUtils.getFile("classpath:removeNameSpace.xslt");
		Source source = new StreamSource(file);
		DOMSource domSource = new DOMSource(node);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer(source);
		transformer.transform(domSource, result);
		return writer.toString();
	}
	

}
