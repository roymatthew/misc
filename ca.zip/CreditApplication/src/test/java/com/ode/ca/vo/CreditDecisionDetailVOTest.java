/**
 * 
 */
package com.ode.ca.vo;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import org.junit.Ignore;
import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for CreditDecisionDetailVO
 *
 * @see com.ode.ca.vo.CreditDecisionDetailVO
 * @author rmathew
 */
public class CreditDecisionDetailVOTest {

	/**
	 * Parasoft Jtest UTA: Test for getAmountFinanced()
	 *
	 * @see com.ode.ca.vo.CreditDecisionDetailVO#getAmountFinanced()
	 * @author rmathew
	 */
	@Ignore
	@Test(timeout = 1000)
	public void testGetAmountFinanced() throws Throwable {
		// Given
		CreditDecisionDetailVO underTest = new CreditDecisionDetailVO();
		underTest.setAmountFinanced(new BigDecimal("1000.00"));

		// When
		BigDecimal result = underTest.getAmountFinanced();

		// Then
		assertNotNull(result);
	}
}