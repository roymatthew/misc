/**
 * 
 */
package com.ode.ca.vo;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import com.ode.persistence.vo.CreditDecisionVO;

import org.junit.Ignore;
import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for CreditDecisionWrapperVO
 *
 * @see com.ode.ca.vo.CreditDecisionWrapperVO
 * @author rmathew
 */
public class CreditDecisionWrapperVOTest {

	/**
	 * Parasoft Jtest UTA: Test for getCreditDecisionDetailVO()
	 *
	 * @see com.ode.ca.vo.CreditDecisionWrapperVO#getCreditDecisionDetailVO()
	 * @author rmathew
	 */
	@Ignore
	@Test(timeout = 2000)
	public void testGetCreditDecisionDetailVO() throws Throwable {
		// Given
		CreditDecisionDetailVO creditDecisionDetailVO = mock(CreditDecisionDetailVO.class);
		CreditDecisionVO creditDecisionVO = mock(CreditDecisionVO.class);
		CreditDecisionWrapperVO underTest = new CreditDecisionWrapperVO(creditDecisionDetailVO, creditDecisionVO);

		// When
		CreditDecisionDetailVO result = underTest.getCreditDecisionDetailVO();

		// Then
		assertNotNull(result);
	}
}