package com.ode.edocs;

import com.ode.edocs.db.entity.DeContractValidation;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.service.IDeContractValidationDAOService;
import com.ode.edocs.service.IDeLenderDAOService;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ode.edocs.service.DealServiceImplementation;

@Component
public class DistributionCheckHandler {

    private static final Logger logger = LogManager.getLogger(DistributionCheckHandler.class);

    @Autowired
    public IDeLenderDAOService deLenderService;

    @Autowired
    public IDeContractValidationDAOService deContractValidationService;
    
    @Autowired
    public DealServiceImplementation dealService;

    @Value("${sequenceNumberCheck}")
    private String sequenceNumberCheck;


    /**
     * Funding status validations for all lenders excluding VCI.
     *
     * At the time of distribution, check the deal funding status, if the deal
     * status is [Received/Booked], hault the distribution and send an error
     * back to DMS.
     *
     * @param deDeal
     * @throws Exception
     */
    public void validateFundingStatus(DeDeal deDeal, ErrorDetail errorDetail) throws Exception {
        logger.debug("Entered validateFundingStatus(DeDeal deDeal, ErrorDetail errorDetail) method");
        String fundingStatus = deDeal.getFundingStatus();
        boolean statusCheck = AppConstants.FUNDING_STATUS_RECEIVED.equalsIgnoreCase(fundingStatus)
            || AppConstants.FUNDING_STATUS_BOOKED.equalsIgnoreCase(fundingStatus);

        if (statusCheck) {
            throw new ApplicationException(errorDetail.add(AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_MESSAGE,
                AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_CODE));
        }

    }

    /**
     * Fetch the latest CV for the deDeal, then check the CV status. If not
     * passed, error.
     *
     * @param deDeal
     * @param sequenceNumber
     * @return
     * @throws Exception
     */
    public DeContractValidation retrievePassedCVForCDKJPM(DeDeal deDeal, ErrorDetail errorDetail) throws Exception {
        logger.debug("Entered retrievePassedCVForCDKJPM(DeDeal deDeal, ErrorDetail errorDetail) method > DMS Deal: {}, Lender ID: {}", deDeal.getDmsDealNum(), deDeal.getLenderId());
        DeContractValidation cv = deContractValidationService.findMostRecent(deDeal.getDealId());

        // If no CV exists, or if CV exists and status isn't passed, throw error.
        if (cv == null || null != cv && !AppConstants.CV_STATUS_PASSED_FOR_CHASE.equalsIgnoreCase(cv.getStatus())) {
            throw new ApplicationException(errorDetail.add(AppConstants.PASSED_CV_DOESNT_EXIST_MESSAGE, AppConstants.PASSED_CV_DOESNT_EXIST_CODE));
        }

        return cv;
    }

    /**
     * Fetch the latest passed CV first using the sequenceNum (if available). If
     * not found, use the deDealId.
     *
     * @param deDeal
     * @param sequenceNumber
     * @return
     * @throws Exception
     */
    public DeContractValidation retrievePassedCV(DeDeal deDeal, String sequenceNumber) throws Exception {
        logger.debug("Entered retrievePassedCV(DeDeal deDeal, String sequenceNumber) method > DMS Deal: {}, Lender ID: {}, Sequence Id: {}", deDeal.getDmsDealNum(), deDeal.getLenderId(), sequenceNumber);
        DeContractValidation cv = null;

        if (null != sequenceNumber && !sequenceNumber.isEmpty()) {
            logger.info("Using lender sequence number to get the CV");
            cv = deContractValidationService.findMostRecentWithStatusAndLenderSequenceNumber(deDeal.getDealId(),
                AppConstants.CV_STATUSES_PASSED, sequenceNumber);
        } else {
            logger.info("Received null/empty lender sequence number for this deal");
        }
        // if no cv found or sequenceNum is blank, get the latest cv of the deal
        if (cv == null) {
            logger.info("No CV found with the lender sequence number {}. Getting the latest Passed CV", sequenceNumber);
            cv = deContractValidationService.findMostRecentWithStatus(deDeal.getDealId(), AppConstants.CV_STATUSES_PASSED);
        }

        return cv;
    }
    
	public void ifStatusSubmitted(DeDeal deDeal) throws ApplicationException {
		logger.entry("DMS Deal:" + deDeal.getDmsDealNum());
		if (AppConstants.DISTRIBUTION_STATUS_SUBMITTED.equalsIgnoreCase(deDeal.getLatestDistributionStatus())) {
			throw new ApplicationException(AppConstants.LATEST_DISTRIBUTION_STATUS_NOT_SUBMITTED_MESSAGE,
					AppConstants.LATEST_DISTRIBUTION_STATUS_NOT_SUBMITTED_CODE);
		} else {
			deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_SUBMITTED);
			try {
				dealService.saveOrUpdate(deDeal);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error("Error while updating the database", e);
			}
		}
		logger.exit();
	}
}
