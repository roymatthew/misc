package com.ode.edocs;

import com.ode.edocs.db.dao.ErrorLogDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.ErrorLog;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.service.ICreditJournalService;
import com.ode.edocs.service.IDealService;
import com.ode.edocs.service.IDistributionService;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.MailSender;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DistributionErrorHandler {

	private static final Logger logger = LogManager.getLogger(DistributionErrorHandler.class);

    @Autowired
    private ErrorLogDAO errorLogDAO;

    @Autowired
    private MailSender mailSender;
    
    @Autowired
    private IDistributionService distributionService;

    @Autowired
    private ICreditJournalService creditJournalService;

    @Autowired
    private IDealService dealService;

    /**
     * @param e
     * @param distributionProcessingVO
     * @param deal
     * @param errorDetail
     * @throws Exception
     */
    public void handleDistributionError(final Exception e, final DistributionProcessingVO distributionProcessingVO,
        final DeDeal deal) throws Exception {

        logger.debug("Enter handleDistributionError");
        ApplicationException applicationException;
        DcDistribution distribution = null;
        ErrorDetail errorDetail = null;
        String responseMessage = null;
        if (e instanceof ApplicationException) {
            applicationException = (ApplicationException) e;
            distribution = applicationException.getDistribution();
            errorDetail = applicationException.getErrorDetail();
        } else {
            applicationException = new ApplicationException(e, null, e.getMessage(),
                AppConstants.UNEXPECTED_ERROR_CODE);
        }

        if (null != distribution) {
            try {
                distribution.setDist_status(AppConstants.DISTRIBUTION_STATUS_FAILED);
                distributionService.saveOrUpdate(distribution);
            } catch (Exception ex) {
                logger.error("Error saving/updating dcDistribution while handling application exception", ex);
            }
        }

        //mailSender.sendAlertEmail(applicationException);
        //logger.debug("Sent alert email");
        if (null != applicationException.getMessage()) {
            responseMessage = applicationException.getMessage();
        }
        if (null != applicationException.getCode()) {
            responseMessage = applicationException.getCode() + "-" + (responseMessage != null ? responseMessage : "");
        }

        // Log the failure in table for trouble shooting
        insertDistributionFailure(distributionProcessingVO, distribution, deal, responseMessage, errorDetail);

        if (null != distributionProcessingVO.geteDocIn()) {
            try {
            	if (distribution == null) distribution = new DcDistribution();
                final BigInteger edocAckOutCjKey = creditJournalService
                    .writeEDOCACKOUT(distributionProcessingVO.geteDocIn(), responseMessage, new Date(), distribution);
                logger.debug("EDOCACKOUT CJKEY: {}", edocAckOutCjKey);
            } catch (final Exception ex) {
                logger.error("Error saving EDOCACKOUT.", ex);
            }
        }
        if (null != deal) {
        	String distributionStatus = AppConstants.DISTRIBUTION_FAILED;
        	
        	// If the error code is E9020, then do not update the distribution status as 'Distribution Failed', but preserve the existing distribution status
        	if (AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_CODE.equals(applicationException.getCode())) {
        		String status = distributionProcessingVO.getPreviousDistributionStatus();
        		logger.debug(">> Replacing previous distribution status of [{}] in DE_DEAL due to E9020 error", status);
        		distributionStatus = status;
        	}
            dealService.updateRecordState(deal.getDealId(), distributionStatus, AppConstants.RECORD_STATE_UPDATE_COMPLETE, AppConstants.EDOCS_APP);
        }
        logger.debug("Exit handleDistributionError, throwing ApplicationException back.");
        throw applicationException;

    }

    /**
     * @param eDocIn
     * @param distribution
     * @param responseMessage
     * @param errorDetail
     */
    public void insertDistributionFailure(final DistributionProcessingVO distributionProcessingVO,
        final DcDistribution distribution, final DeDeal deDeal, String responseMessage, ErrorDetail errorDetail) {

        logger.debug("Enter insertDistributionFailure");

        try {
            String dealerId = null;
            String dmsDealNum = null;
            String partnerId = null;
            String deDealId = "";
            String transactionId = null;
            String transactionType = AppConstants.TRANS_TYPE_EDOCIN;
            String errorCode = null;
            String errorMessage = null;
            if (errorDetail == null || "".equals(errorDetail.getDealId())) {
                dealerId = distributionProcessingVO.getDealerId();
                dmsDealNum = distributionProcessingVO.getDmsDealNumber();
                partnerId = distributionProcessingVO.getPartyId();
                if (null != deDeal) {
                    deDealId = deDeal.getDealId();
                }
                if (null != errorDetail) {
                    errorCode = errorDetail.getCode();
                    errorMessage = errorDetail.getMessage();
                }
            } else {
                dealerId = errorDetail.getDealerId();
                deDealId = errorDetail.getDealId();
                dmsDealNum = errorDetail.getDmsDealNum();
                partnerId = errorDetail.getLenderId();
                transactionId = errorDetail.getTransactionId();
                if (!"".equals(errorDetail.getTransactionType())) {
                    transactionType = errorDetail.getTransactionType();
                }
                errorCode = errorDetail.getCode();
                errorMessage = errorDetail.getMessage();
            }
            if (errorMessage == null || "".equals(errorMessage)) {
                errorMessage = responseMessage;
            }
            
            if (errorCode == null || "".equals(errorCode)) {
            	if (errorMessage == null) errorMessage = "";
            	logger.info("Error code not found. Trying to fetch error code from message '" + errorMessage + "'");
            	if ((errorMessage.startsWith("E")) && errorMessage.substring(5, 6).matches("-")) {
            		errorCode = errorMessage.substring(0, 5);
            	}
            }
            if (errorCode == null) errorCode = "";
            logger.info("Error code -> " + errorCode);
            ErrorLog log = new ErrorLog();
            log.setLenderId(partnerId);
            log.setTransactionType(transactionType);
            log.setDealId(deDealId);
            log.setDmsDealNum(dmsDealNum);
            log.setSequenceId(distribution != null ? distribution.getId().getSequenceId() : null);
            log.setErrorCode(errorCode);
            if (! StringUtils.isEmpty(errorMessage)) {
            	if (errorMessage.length() > 500) {
            	  log.setErrorMessage(errorMessage.substring(0,500));
            	} else {
            	  log.setErrorMessage(errorMessage);	
            	}
            }           
            log.setTransactionId(transactionId);
            log.setDmsDealerId(dealerId);
            Calendar calendar = Calendar.getInstance();
            Date now = calendar.getTime();
            log.setCreatedBy(AppConstants.APPLICATION_EDOCS);
            log.setCreatedTs(new Timestamp(now.getTime()));
            errorLogDAO.saveOrUpdate(log);

        } catch (Exception e) {
            logger.error("Error updating error log table: ", e);
        }

        logger.debug("Exit insertDistributionFailure");
    }

}
