package com.ode.edocs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jdom2.Document;

import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DcDocType;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DmsDocType;
import com.ode.edocs.db.entity.LenDocType;

public class File {

	private String filename;
	private String formType;
	private byte[] contents;
	private DcDocument dcDocument;
	private List<DcDocData> docData = new ArrayList<DcDocData>();
	private DmsDocType dmsDocType = new DmsDocType();
	private LenDocType lenDocType = new LenDocType();
	private List<DcForm> dcForms;
	private Document ancillaryData;
	private List<DcDocField> fields;
	private String requiredForm;
	private String lenderDocName;
	private DcDocType dcDocType;
	private String eSigned;
	private String eForm;
	private String fileExtension;
	private String formattedFileName;
	private boolean isContract;
	private List<DeDataElement> metaDataFields;

	public String getRequiredForm() {
		return requiredForm;
	}

	public void setRequiredForm(String requiredForm) {
		this.requiredForm = requiredForm;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public byte[] getContents() {
		return contents;
	}

	public void setContents(byte[] contents) {
		this.contents = contents;
	}

	public DcDocument getDcDocument() {
		return dcDocument;
	}

	public void setDcDocument(DcDocument dcDocument) {
		this.dcDocument = dcDocument;
	}

	public List<DcDocData> getDocData() {
		return docData;
	}

	public void setDocData(List<DcDocData> docData) {
		this.docData = docData;
	}

	public LenDocType getLenDocType() {
		return lenDocType;
	}

	public void setLenDocType(LenDocType lenDocType) {
		this.lenDocType = lenDocType;
	}

	public DmsDocType getDmsDocType() {
		return dmsDocType;
	}

	public void setDmsDocType(DmsDocType dmsDocType) {
		this.dmsDocType = dmsDocType;
	}

	public List<DcForm> getDcForms() {
		return dcForms;
	}

	public void setDcForms(List<DcForm> dcForms) {
		this.dcForms = dcForms;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}

	public Document getAncillaryData() {
		return ancillaryData;
	}

	public void setAncillaryData(Document ancillaryData) {
		this.ancillaryData = ancillaryData;
	}

	public List<DcDocField> getFields() {
		return fields;
	}

	public void setFields(List<DcDocField> fields) {
		this.fields = fields;
	}

	public String getLenderDocName() {
		return lenderDocName;
	}

	public void setLenderDocName(String lenderDocName) {
		this.lenderDocName = lenderDocName;
	}

	public DcDocType getDcDocType() {
		return dcDocType;
	}

	public void setDcDocType(DcDocType dcDocType) {
		this.dcDocType = dcDocType;
	}

	public List<DeDataElement> getMetaDataFields() {
		return metaDataFields;
	}

	public void setMetaDataFields(List<DeDataElement> metaDataFields) {
		this.metaDataFields = metaDataFields;
	}

	public boolean isContract() {
		return isContract;
	}

	public void setContract(boolean isContract) {
		this.isContract = isContract;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ancillaryData == null) ? 0 : ancillaryData.hashCode());
		result = prime * result + Arrays.hashCode(contents);
		result = prime * result + ((dcDocType == null) ? 0 : dcDocType.hashCode());
		result = prime * result + ((dcDocument == null) ? 0 : dcDocument.hashCode());
		result = prime * result + ((dcForms == null) ? 0 : dcForms.hashCode());
		result = prime * result + ((dmsDocType == null) ? 0 : dmsDocType.hashCode());
		result = prime * result + ((docData == null) ? 0 : docData.hashCode());
		result = prime * result + ((eForm == null) ? 0 : eForm.hashCode());
		result = prime * result + ((eSigned == null) ? 0 : eSigned.hashCode());
		result = prime * result + ((fields == null) ? 0 : fields.hashCode());
		result = prime * result + ((fileExtension == null) ? 0 : fileExtension.hashCode());
		result = prime * result + ((filename == null) ? 0 : filename.hashCode());
		result = prime * result + ((formType == null) ? 0 : formType.hashCode());
		result = prime * result + ((formattedFileName == null) ? 0 : formattedFileName.hashCode());
		result = prime * result + (isContract ? 1231 : 1237);
		result = prime * result + ((lenDocType == null) ? 0 : lenDocType.hashCode());
		result = prime * result + ((lenderDocName == null) ? 0 : lenderDocName.hashCode());
		result = prime * result + ((metaDataFields == null) ? 0 : metaDataFields.hashCode());
		result = prime * result + ((requiredForm == null) ? 0 : requiredForm.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		File other = (File) obj;
		if (ancillaryData == null) {
			if (other.ancillaryData != null)
				return false;
		} else if (!ancillaryData.equals(other.ancillaryData))
			return false;
		if (!Arrays.equals(contents, other.contents))
			return false;
		if (dcDocType == null) {
			if (other.dcDocType != null)
				return false;
		} else if (!dcDocType.equals(other.dcDocType))
			return false;
		if (dcDocument == null) {
			if (other.dcDocument != null)
				return false;
		} else if (!dcDocument.equals(other.dcDocument))
			return false;
		if (dcForms == null) {
			if (other.dcForms != null)
				return false;
		} else if (!dcForms.equals(other.dcForms))
			return false;
		if (dmsDocType == null) {
			if (other.dmsDocType != null)
				return false;
		} else if (!dmsDocType.equals(other.dmsDocType))
			return false;
		if (docData == null) {
			if (other.docData != null)
				return false;
		} else if (!docData.equals(other.docData))
			return false;
		if (eForm == null) {
			if (other.eForm != null)
				return false;
		} else if (!eForm.equals(other.eForm))
			return false;
		if (eSigned == null) {
			if (other.eSigned != null)
				return false;
		} else if (!eSigned.equals(other.eSigned))
			return false;
		if (fields == null) {
			if (other.fields != null)
				return false;
		} else if (!fields.equals(other.fields))
			return false;
		if (fileExtension == null) {
			if (other.fileExtension != null)
				return false;
		} else if (!fileExtension.equals(other.fileExtension))
			return false;
		if (filename == null) {
			if (other.filename != null)
				return false;
		} else if (!filename.equals(other.filename))
			return false;
		if (formType == null) {
			if (other.formType != null)
				return false;
		} else if (!formType.equals(other.formType))
			return false;
		if (formattedFileName == null) {
			if (other.formattedFileName != null)
				return false;
		} else if (!formattedFileName.equals(other.formattedFileName))
			return false;
		if (isContract != other.isContract)
			return false;
		if (lenDocType == null) {
			if (other.lenDocType != null)
				return false;
		} else if (!lenDocType.equals(other.lenDocType))
			return false;
		if (lenderDocName == null) {
			if (other.lenderDocName != null)
				return false;
		} else if (!lenderDocName.equals(other.lenderDocName))
			return false;
		if (metaDataFields == null) {
			if (other.metaDataFields != null)
				return false;
		} else if (!metaDataFields.equals(other.metaDataFields))
			return false;
		if (requiredForm == null) {
			if (other.requiredForm != null)
				return false;
		} else if (!requiredForm.equals(other.requiredForm))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "File [filename=" + filename + ", formType=" + formType + ", contents=" + Arrays.toString(contents)
				+ ", dcDocument=" + dcDocument + ", docData=" + docData + ", dmsDocType=" + dmsDocType + ", lenDocType="
				+ lenDocType + ", dcForms=" + dcForms + ", ancillaryData=" + ancillaryData + ", fields=" + fields
				+ ", requiredForm=" + requiredForm + ", lenderDocName=" + lenderDocName + ", dcDocType=" + dcDocType
				+ ", eSigned=" + eSigned + ", eForm=" + eForm + ", fileExtension=" + fileExtension
				+ ", formattedFileName=" + formattedFileName + ", isContract=" + isContract + ", metaDataFields="
				+ metaDataFields + "]";
	}

	public String geteSigned() {
		return eSigned;
	}

	public void seteSigned(String eSigned) {
		this.eSigned = eSigned;
	}

	public String geteForm() {
		return eForm;
	}

	public void seteForm(String eForm) {
		this.eForm = eForm;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFormattedFileName() {
		return formattedFileName;
	}

	public void setFormattedFileName(String formattedFileName) {
		this.formattedFileName = formattedFileName;
	}

}