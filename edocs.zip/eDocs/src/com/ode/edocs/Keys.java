package com.ode.edocs;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Keys{
	private String keyId;
	private String keyString;
	private String algorithm;
	private Date effectiveDate;
	private Date expiryDate;
	
	private static String keyFileLocation = "/data/ode/keys/keys.xml";
	
	public String getKeyId() {
		return keyId;
	}
	
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	
	public String getKeyString() {
		return keyString;
	}
	
	public void setKeyString(String keyString) {
		this.keyString = keyString;
	}
	
	public String getAlgorithm() {
		return algorithm;
	}
	
	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}
	
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	public Date getExpiryDate() {
		return expiryDate;
	}
	
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
	    builder.append("Keys [keyId=");
	    builder.append(keyId);
	    builder.append(", keyString=");
	    builder.append(keyString);
	    builder.append(", algorithm=");
	    builder.append(algorithm);
	    builder.append(", effectiveDate=");
	    builder.append(effectiveDate);
	    builder.append(", expiryDate=");
	    builder.append(expiryDate);
	    builder.append("]");
	    return builder.toString();
	}
	
	public static List<Keys> getKeyInfo() {
		Document document = null;
		List<Keys> keyInfo = new ArrayList<Keys>();
		try {
			File keyFile = new File(keyFileLocation);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			document = dBuilder.parse(keyFile);
			document.getDocumentElement().normalize();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			
			NodeList nList = document.getElementsByTagName("key");
			for(int i = 0; i < nList.getLength(); i++) {
				Node node = nList.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					Keys keyObject = new Keys();
					keyObject.setKeyId(element.getElementsByTagName("keyId").item(0).getTextContent());
					keyObject.setKeyString(element.getElementsByTagName("keyString").item(0).getTextContent());
					keyObject.setAlgorithm(element.getElementsByTagName("algorithm").item(0).getTextContent());
					keyObject.setEffectiveDate(sdf.parse(element.getElementsByTagName("effectiveDate").item(0).getTextContent()));
					keyObject.setExpiryDate(sdf.parse(element.getElementsByTagName("expiryDate").item(0).getTextContent()));
					keyInfo.add(keyObject);
				}
			}
		} catch (Exception e) {
			System.out.println("could not parse keys.xml returning blank list");
			e.printStackTrace();
		} 
		return keyInfo;
	}
}
