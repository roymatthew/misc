package com.ode.edocs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDataElementXpath;
import com.ode.edocs.db.entity.DeFormElement;
import com.ode.edocs.db.entity.DeFormElementItem;
import com.ode.edocs.rest.entity.FormElementKey;
import com.ode.edocs.service.IDeFormElementDAOService;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.HandlerUtils;

@Component
public class MetaDataHandler {
	private static final Logger logger = LogManager.getLogger(MetaDataHandler.class);

	@Autowired
	private IDeFormElementDAOService deFormElementService;

	// create key by dcDocTypeId, lenderId and stateId
	// use key to retrieve value in the metaDataMap
	public FormElementKey buildElementKey(Integer dcDocTypeId, String lenderId, String stateId) {
		logger.debug("Entered buildElementKey(Integer dcDocTypeId, String lenderId, String stateId) method");
		FormElementKey key = new FormElementKey();
		key.setLenderId(lenderId);
		key.setDcDocTypeId(dcDocTypeId);
		key.setStateId(stateId);

		return key;
	}

	// get records from DeDataElement table based on key value
	public List<DeDataElement> getMetaDataFields(FormElementKey key) throws Exception {
		logger.debug("Entered getMetaDataFields(FormElementKey key) method");
		List<DeDataElement> deDataElement = new ArrayList<DeDataElement>();
		DeFormElement deFormElement = deFormElementService.getDeFormElement(key);
		if (null != deFormElement) {
			List<DeFormElementItem> deFormElementItem = deFormElement.getDeFormElementItems();
			for (DeFormElementItem item : deFormElementItem) {
				DeDataElement element = item.getDeDataElement();
				deDataElement.add(element);
			}
		}
		return deDataElement;
	}

	// get records from DeDataElement table for given lender and state
	public Map<String, List<DeDataElement>> getMetaDataFieldsAsMap(final FormElementKey key,
			final List<Integer> docTypeIdList) throws Exception {
		logger.debug("Entered getMetaDataFieldsAsMap(FormElementKey key) method");

		final Map<String, List<DeDataElement>> deDataElementsMap = new HashMap<>();
		final List<DeFormElement> deFormElementList = deFormElementService.getDeFormElementsCollection(key,
				docTypeIdList);
		for (DeFormElement deFormElement : deFormElementList) {
			final List<DeDataElement> dataElementsList = new ArrayList<DeDataElement>();
			final List<DeFormElementItem> deFormElementItems = deFormElement.getDeFormElementItems();
			for (DeFormElementItem item : deFormElementItems) {
				DeDataElement element = item.getDeDataElement();
				dataElementsList.add(element);
			}
			final String aKey = String.valueOf(deFormElement.getDcDocTypeId());
			final List<DeDataElement> aList = deDataElementsMap.get(aKey);
			if (aList != null) {
				aList.addAll(dataElementsList);
			} else {
				deDataElementsMap.put(aKey, dataElementsList);
			}
		}

		return deDataElementsMap;
	}

	// filter fields based on financeType and applicationType
	public List<DeDataElement> metaDataFieldsFilter(List<DeDataElement> fields, String financeType,
			String applicationType) {
		logger.debug("Entered metaDataFieldsFilter method");
		List<DeDataElement> metaDataFields = new ArrayList<DeDataElement>();

		if (fields != null) {
			for (DeDataElement element : fields) {
				boolean proceed = false;
				if ("R".equals(financeType)) {
					proceed = "Y".equals(element.getFinanceRetail());
				} else if ("L".equals(financeType)) {
					proceed = "Y".equals(element.getFinanceLease());
				} else if ("B".equals(financeType)) {
					proceed = "Y".equals(element.getFinanceBalloon());
				}
				if (proceed) {
					if ("BU".equals(applicationType)) {
						proceed = "Y".equals(element.getAppBusiness());
					} else if ("BC".equals(applicationType)) {
						proceed = "Y".equals(element.getAppBusinessCobuyer());
					} else if ("BG".equals(applicationType)) {
						proceed = "Y".equals(element.getAppBusinessGuarantor());
					} else if ("IN".equals(applicationType)) {
						proceed = "Y".equals(element.getAppIndividual());
					} else if ("IC".equals(applicationType)) {
						proceed = "Y".equals(element.getAppIndividualCobuyer());
					} else if ("IJ".equals(applicationType)) {
						proceed = "Y".equals(element.getAppIndividualGuarantor());
					}
					if (proceed) {
						metaDataFields.add(element);
					} else {
						logger.info(
								"Application type of deal is {}, which is not enabled for element {}, hence dropping this field",
								applicationType, element.getElementName());
					}
				} else {
					logger.info(
							"Finance type of deal is {}, which is not enabled for element {}, hence dropping this field",
							financeType, element.getElementName());
				}
			}
		}

		return metaDataFields;
	}

	// Get the meta data value from either ancillary XML/ from database
	public void getMetaDataValue(File file, List<DeDataElement> dataElements, DeDataElement metaDataField,
			List<DcDocData> dcDocData, StringBuilder ancillaryValue, String dmsId) {

		logger.debug("Entered getMetaDataValue method");
		try {
			String metaDataElementId = (metaDataField != null && metaDataField.getDeDocumentReview() != null ? metaDataField.getDeDocumentReview().getMetaDataElements() : "");
			logger.info("metaDataElementId> {}", metaDataElementId);

			// Get the meta data element value from DC_DOC_DATA table
			if (null != dataElements) {
				if (metaDataElementId.contains("|")) {
					String[] multiIds = metaDataElementId.split("\\|");
					for (String id : multiIds) {
						if (null != id && !"".equals(id)) {
							if (null != file) {
								getMetaDataValueFromAncillaryXML(dataElements, ancillaryValue, id,
										file.getAncillaryData(), dmsId); // Flow
								// from
								// distribution
							} else {
								getMetaDataValueFromTable(dataElements, dcDocData, ancillaryValue, id); // Document
								// review
								// from
								// DE
								// UI
							}
						}
					}
				} else {
					if (null != metaDataElementId && !"".equals(metaDataElementId)) {
						if (null != file) {
							getMetaDataValueFromAncillaryXML(dataElements, ancillaryValue, metaDataElementId,
									file.getAncillaryData(), dmsId); // Flow
							// from
							// distribution
						} else {
							getMetaDataValueFromTable(dataElements, dcDocData, ancillaryValue, metaDataElementId);
							// Document
							// review
							// from
							// DE
							// UI
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("An error occured while getting metadata value: ", e);
		}
	}

	// Get the meta data value corresponding to
	public void getMetaDataValueFromAncillaryXML(List<DeDataElement> dataElements, StringBuilder sb,
			String deDataElementId, Document ancillaryData, String dmsId) {
		logger.debug("Entered getMetaDataValueFromAncillaryXML method");
		try {
			String id = deDataElementId.trim();
			DeDataElement field = dataElements.stream().filter(p -> p.getId().equals(Integer.parseInt(id))).findFirst()
					.orElse(null);
			if (null != field) {
				if (null != field.getDeDataElementXpaths()) {
					DeDataElementXpath deDataElementXpath = field.getDeDataElementXpaths().stream()
							.filter(p -> dmsId.equals(p.getDmsId())).findFirst().orElse(null);
					if (null != deDataElementXpath && null != deDataElementXpath.getXpath()
							&& !"".equals(deDataElementXpath.getXpath())) {
						String ancillaryFieldValue = HandlerUtils.evaluateExpression(ancillaryData,
								deDataElementXpath.getXpath());
						if (null != ancillaryFieldValue && !"".equals(ancillaryFieldValue)) {
							if (sb.length() > 0) {
								sb.append(AppConstants.BLANK_SPACE);
							}
							sb.append(ancillaryFieldValue);
						}
					} else {
						logger.info("No XPath defined for DeDataElement id > {}, DMS id > {} hence "
								+ "cannot get the value from ancillary XML", deDataElementId, dmsId);
					}
				} else {
					logger.info(
							"No XPath defined for DeDataElement id {}, hence cannot get the value from ancillary XML",
							deDataElementId);
				}
			} else {
				logger.info("Did not find a DeDataElement with id {}", deDataElementId);
			}
		} catch (Exception e) {
			logger.error("Error occured while getting ancillary XML value: ", e);
		}
	}

	// Get the meta data value corresponding to
	public void getMetaDataValueFromTable(List<DeDataElement> dataElements, List<DcDocData> dcDocData, StringBuilder sb,
			String deDataElementId) {
		logger.debug("Entered getMetaDataValueFromTable method");
		try {
			String id = deDataElementId.trim();
			DeDataElement field = dataElements.stream().filter(p -> p.getId().equals(Integer.parseInt(id))).findFirst()
					.orElse(null);
			if (null != field) {
				DcDocData data = null;
				if (dcDocData != null) {
					data = dcDocData.stream().filter(p -> p.getDataName().equals(field.getElementName())).findFirst().orElse(null);
				}
						
				if (null != data && null != data.getDataValue() && !"".equals(data.getDataValue())) {
					if (sb.length() > 0) {
						sb.append(AppConstants.BLANK_SPACE);
					}
					sb.append(data.getDataValue());
				}
			} else {
				logger.info("Did not find a data element with id > {}", deDataElementId);
			}
		} catch (Exception e) {
			logger.error("Error occured while getting ancillary value: ", e);
		}
	}
}
