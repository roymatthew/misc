package com.ode.edocs;

public class ReCVData {

    private String autoCvOut;
    private String autoCvValidationStatus = "";
    private String transactionId;

    public String getAutoCvOut() {
        return autoCvOut;
    }

    public void setAutoCvOut(String autoCvOut) {
        this.autoCvOut = autoCvOut;
    }

    public String getAutoCvValidationStatus() {
        return autoCvValidationStatus;
    }

    public void setAutoCvValidationStatus(String autoCvValidationStatus) {
        this.autoCvValidationStatus = autoCvValidationStatus;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

}
