package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.enums.DmsEnum;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import java.util.List;
import org.jdom2.Document;

public abstract class AbstractDmsBO implements DmsBO {

    /**
     * Enum that holds the Id and Name of the real world DMS.
     */
    protected DmsEnum dms = null;

    protected String sequenceNumber;

    protected IValidationUtil validationUtil;

    @Override
    public void init(final Document doc) {
        // do nothing
    }

    /**
     * Getter for DMS.
     *
     * @return
     */
    public DmsEnum getDms() {
        return dms;
    }

    /**
     * Setter for DMS.
     *
     * @param dms
     */
    public void setDms(DmsEnum dms) {
        this.dms = dms;
    }

    /**
     * Getter for sequenceNumber.
     *
     * @return sequenceNumber
     */
    @Override
    public String getSequenceNumber() {
        return sequenceNumber;
    }

    /**
     * Setter for sequenceNumber.
     *
     * @return sequenceNumber
     */
    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DeDeal validateVaultedContract(final Document eDocIn, final DeLender lender, final DeDeal deal, final ErrorDetail errorDetail, boolean isRouteOneTransaction) throws Exception {
        return deal;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkContractInForms(final DeDeal deal, final List<File> files, final FormsDAO formsDao,
        final ErrorDetail errorDetail, final LenderBO lenderBO) throws ApplicationException {
        // do nothing
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail, final LenderBO lenderBO)
        throws ApplicationException {
        // do nothing
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContractStatus(final DeDeal deal, final VaultRegisterDocumentDAO vaultRegisterDocumentDAO,
        final boolean distributionHasContract, final AttachmentProcessingVO attachmentProcessingVO,
        final LenderBO lenderBO, final ErrorDetail errorDetail) throws ApplicationException, Exception {
        // do nothing
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContract(final LenderBO lenderBO, final List<DcDistribution> distributions,
        final String vaultIndicator, final List<File> files, final DeDeal deal, final String lenderId,
        final ErrorDetail errorDetail) throws Exception {

        // do nothing here
        // check ReynoldsDmsBO/CdkDmsBO for implementation.

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateLender(final LenderBO lenderBO, final DeDeal deal, final String lenderId,
        final String partyId, final String vaultIndicator, final ErrorDetail errorDetail) throws Exception {
        // do nothing here
        // check ReynoldsDmsBO for implementation.

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DeContractValidation getContractValidation(final LenderBO lenderBO, final DeDeal deal, final ErrorDetail errorDetail)
        throws Exception {

        return lenderBO.getContractValidation(deal, errorDetail);

    }

    /**
     * Getter for validationUtil.
     *
     * @return
     */
    public IValidationUtil getValidationUtil() {
        return validationUtil;
    }

    /**
     * Setter for validationUtil.
     */
    public void setValidationUtil(final IValidationUtil validationUtil) {
            this.validationUtil = validationUtil;
    }

    @Override
    public void validateEconStatus(final LenderBO lenderBo, final DeDeal deal) throws ApplicationException {
        // do nothing here.
    }

}
