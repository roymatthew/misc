package com.ode.edocs.bo;

import com.ode.edocs.DistributionCheckHandler;
import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.enums.LenderEnum;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Namespace;
import org.w3c.dom.Document;

public abstract class AbstractLenderBO implements LenderBO {

    private static final Logger logger = LogManager.getLogger(AbstractLenderBO.class);
    public static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");

    protected DmsBO dms = null;
    protected LenderEnum lender = null;
    protected String lenderId;
    protected String partyId;
    protected String lenderOrganization = null;
    protected IValidationUtil validationUtil;
    protected DistributionCheckHandler distributionCheckHandler;

    public AbstractLenderBO(final DmsBO dms, final LenderEnum lender) {
        super();
        this.dms = dms;
        this.lender = lender;
        setLenderId(lender.getLenderId());
        setLenderOrganization(lenderOrganization);
    }

    public AbstractLenderBO(final DmsBO dms) {
        super();
        this.dms = dms;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DeContractValidation getContractValidation(final DeDeal deal, final ErrorDetail errorDetail) throws Exception {
        return distributionCheckHandler.retrievePassedCV(deal, dms.getSequenceNumber());
    }

    /**
     * {@inheritDoc}
     */
    public void checkContractInForms(final DeDeal deal, final List<File> files, final FormsDAO formsDao) {

        // do nothing here.

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContractStatus(final DeDeal deal, final VaultRegisterDocumentDAO vaultRegisterDocumentDAO,
        boolean distributionHasContract, final AttachmentProcessingVO attachmentProcessingVO,
        final ErrorDetail errorDetail) throws ApplicationException, Exception {
        // do nothing here.
    }

    /**
     * This method needs to be executed for only Non VCI lenders
     *
     * @param distributionCheckHandler
     * @param distributions
     * @param files
     * @param deal
     * @param lenderId
     * @param errorDetail
     * @throws Exception
     */
    @Override
    public void validateContract(final List<DcDistribution> distributions, final List<File> files, final DeDeal deal,
        final String lenderId, final ErrorDetail errorDetail) throws Exception {

        logger.debug("Enter validateContract");

        if (!getValidationUtil().previousDistributionExists(distributions)) {

            logger.debug("This is a Non-VCI lender and no previous distributions. Executing validateContractForRR");
            // Validate Contract
            // distributionCheckHandler.validateContractForRR(files, deal, lenderId, errorDetail);
            validationUtil.validateContractForARAndRR(files, deal, lenderId);
        }

        logger.debug("Exit validateContract");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContractXml(final List<DcDistribution> distributions, final List<File> files, final ErrorDetail errorDetail) throws Exception {

        // do nothing here.

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateLender(final DeDeal deal, final String lenderId, final String partyId, final ErrorDetail errorDetail)
        throws ApplicationException {

        logger.debug("Enter validateLender for lenderId:" + lenderId);

        validationUtil.validateLender(deal, lenderId, partyId, errorDetail);

        logger.debug("Exit validateLender for lenderId:" + lenderId);

    }

    @Override
    public void validateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail) throws ApplicationException {
        logger.debug(
            "Entering AbstractLenderBO - ValidateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail) method");

        String fundingStatus = deal.getFundingStatus();
        boolean statusCheck = AppConstants.FUNDING_STATUS_RECEIVED.equalsIgnoreCase(fundingStatus)
            || AppConstants.FUNDING_STATUS_BOOKED.equalsIgnoreCase(fundingStatus);

        if (statusCheck) {
            throw new ApplicationException(errorDetail.add(AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_MESSAGE,
                AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_CODE));
        }

    }

    public IValidationUtil getValidationUtil() {
        return validationUtil;
    }

    @Override
    public void setValidationUtil(final IValidationUtil validationUtil) {
        this.validationUtil = validationUtil;
    }

    public DistributionCheckHandler getDistributionCheckHandler() {
        return distributionCheckHandler;
    }

    @Override
    public void setDistributionCheckHandler(final DistributionCheckHandler distributionCheckHandler) {
        this.distributionCheckHandler = distributionCheckHandler;
    }

    @Override
    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(final String lenderId) {
        this.lenderId = lenderId;
    }

    public String getLenderOrganization() {
        return lenderOrganization;
    }

    public void setLenderOrganization(final String lenderOrganization) {
        this.lenderOrganization = lenderOrganization;
    }

    public String getPartyId() {
        return partyId;
    }

    @Override
    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    @Override
    public void validateEconStatus(final DeDeal deal) throws ApplicationException {
        // call validation util validateEconStatus()
        validationUtil.validateEconStatus(deal);
    }
    
    /* (non-Javadoc)
     * @see com.ode.cv.bo.ILenderBO#isEcoutChangesRequired()
     */
    public Boolean isEDocoutChangesRequired()
    {
        return Boolean.FALSE;
    }
    
    /**
     * @param creditContractVO
     * @param inEcout
     * @return
     */
	@Override
    public Document makeChangesToEDocOut(final String documentId, final Document document, final Map<String, String> webSvcFeatures)
    {
    	logger.debug("Entered makeChangesToEDocOut() method of AbstractLenderBO.class.");
    	logger.debug("No custom changes are required for this lender. Returning document as is..");
		return document;
    	
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public void checkContractInForms(final DeDeal deal, final List<File> files, final ErrorDetail errorDetail,
        final FormsDAO formsDao) throws ApplicationException {
        logger.debug("Enter checkContractInForms");
/*        do nothing. Specific implementation must be done in
        overridden method is concrete implementation.*/
        logger.debug("Exit checkContractInForms");
    }


}
