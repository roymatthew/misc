package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.XMLConstants;
import com.ode.edocs.util.enums.DmsEnum;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;

public class CdkDmsBO extends AbstractDmsBO {

    private static final Logger logger = LogManager.getLogger(CdkDmsBO.class);

    @Override
    public String toString() {
        return "CdkBO [dms=" + dms + "]";
    }

    /**
     * @param eDocIn
     */
    @Override
    public void init(final Document eDocIn) {
        String aSequenceNumber;
        try {
            aSequenceNumber = EdocsXmlUtils.getTextFromXpath(eDocIn, XMLConstants.starBodIdPath);
            setSequenceNumber(aSequenceNumber);
        } catch (final Exception e) {
            logger.debug("Exception when extracting sequence number from document. " + e.getMessage());
        }
    }

    /**
     * Constructor.
     */
    public CdkDmsBO() {
        super();
    }

    /**
     * Constructor.
     */
    public CdkDmsBO(final DmsEnum anEnum) {
        super();
        super.dms = anEnum;
    }

    /**
     * Constructor.
     */
    public CdkDmsBO(final DmsEnum anEnum, final IValidationUtil validationUtil) {
        super();
        super.setDms(anEnum);
        super.setValidationUtil(validationUtil);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDmsId() {
        return super.dms.getDmsId();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContract(final LenderBO lenderBO, final List<DcDistribution> distributions,
        final String vaultIndicator, final List<File> files, final DeDeal deal, final String lenderId,
        final ErrorDetail errorDetail) throws Exception {
    	
        logger.debug("Enter validateContract");
        lenderBO.validateContractXml(distributions, files, errorDetail);
        logger.debug("Exit validateContract");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DeDeal validateVaultedContract(final Document eDocIn, final DeLender lender, final DeDeal deDeal,
        final ErrorDetail errorDetail, boolean isRouteOneTransaction) throws Exception {
        return validationUtil.validateVaultedContractForCDK(eDocIn, lender, deDeal);
    }
}
