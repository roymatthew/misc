package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.enums.DmsEnum;
import com.ode.edocs.util.enums.LenderEnum;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ChaseLenderBO extends AbstractLenderBO {

    private static final Logger logger = LogManager.getLogger(ChaseLenderBO.class);

    /**
     * Constructor.
     *
     * @param dms DmsBO.
     */
    public ChaseLenderBO(final DmsBO dms) {
        super(dms);
    }

    /**
     * Constructor.
     *
     * @param dms
     * @param lenderEnum
     */
    public ChaseLenderBO(final DmsBO dms, final LenderEnum lenderEnum) {
        super(dms, lenderEnum);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DeContractValidation getContractValidation(final DeDeal deal, final ErrorDetail errorDetail) throws Exception {

        logger.debug("Enter getContractValidation");

        if (DmsEnum.AD.getDmsId().equals(super.dms.getDmsId()) || DmsEnum.CDK.getDmsId().equals(super.dms.getDmsId())) {
            errorDetail.setDealId(deal.getDealId());
            return getDistributionCheckHandler().retrievePassedCVForCDKJPM(deal, errorDetail);
        }
        return getDistributionCheckHandler().retrievePassedCV(deal, this.dms.getSequenceNumber());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkContractInForms(final DeDeal deal, final List<File> files, final ErrorDetail errorDetail,
        final FormsDAO formsDao) throws ApplicationException {
        logger.debug("Enter checkContractInForms");
        // RR Upon a distribution, ODE will check the distributed Contract against an approved forms
        // list
        // This is temporary solution until RR implement this on their end
        final boolean isContractInApprovedFormList = getValidationUtil().isContractInApprovedFormList(files, formsDao, partyId);

        if (!isContractInApprovedFormList) {
            logger.error(
                "Form name and revision date in the Contract.xml DOES NOT match a DSP Form Name and DSP revision date  "
                    + deal.getDmsDealerId() + " DMS deal number: " + deal.getDmsDealNum());
            throw new ApplicationException(errorDetail.add(AppConstants.RR_CHASE_DSP_FORM_ERROR_MESSAGE,
                AppConstants.RR_CHASE_DSP_FORM_ERROR_CODE));
        }

        logger.debug("Exit checkContractInForms");
    }

}
