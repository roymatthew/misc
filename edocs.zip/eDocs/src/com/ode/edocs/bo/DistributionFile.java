package com.ode.edocs.bo;

import com.ode.edocs.File;
import java.util.List;

public class DistributionFile {

    private List<File> files;
    private List<String> ancillaries;

    public List<File> getFiles() {
        return files;
    }

    public void setFiles(List<File> files) {
        this.files = files;
    }

    public List<String> getAncillaries() {
        return ancillaries;
    }

    public void setAncillaries(List<String> ancillaries) {
        this.ancillaries = ancillaries;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DistributionFile [files=");
        builder.append(files);
        builder.append(", ancillaries=");
        builder.append(ancillaries);
        builder.append("]");
        return builder.toString();
    }

}
