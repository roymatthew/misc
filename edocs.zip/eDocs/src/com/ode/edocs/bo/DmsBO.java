package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import java.util.List;
import org.jdom2.Document;

public interface DmsBO {

    String getDmsId();

    String getSequenceNumber();

    /**
     * Do required initial setup.
     *
     * @param doc
     */
    void init(final Document doc);

    /**
     * @param distributionCheckHandler
     * @param eDocIn
     * @param lender
     * @param deDeal
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DeDeal validateVaultedContract(final Document eDocIn, final DeLender lender, final DeDeal deDeal,
        final ErrorDetail errorDetail, boolean isRouteOneTransaction) throws Exception;

    /**
     * @param deal
     * @param files
     * @param formsDao
     * @param errorDetail
     * @param lenderBO
     * @throws ApplicationException
     */
    void checkContractInForms(final DeDeal deal, final List<File> files, final FormsDAO formsDao,
        final ErrorDetail errorDetail, final LenderBO lenderBO) throws ApplicationException;

    /**
     * @param deal
     * @param errorDetail
     * @param lenderBO
     * @throws ApplicationException
     */
    void validateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail, final LenderBO lenderBO)
        throws ApplicationException;

    /**
     * @param deal
     * @param vaultRegisterDocumentDAO
     * @param distributionHasContract
     * @param attachmentProcessingVO
     * @param lenderBO
     * @param errorDetail
     * @throws ApplicationException
     * @throws Exception
     */
    void validateContractStatus(final DeDeal deal, final VaultRegisterDocumentDAO vaultRegisterDocumentDAO,
        final boolean distributionHasContract, final AttachmentProcessingVO attachmentProcessingVO,
        final LenderBO lenderBO, final ErrorDetail errorDetail) throws ApplicationException, Exception;

    /**
     *
     * This method needs to be implemented in LenderBO. For now only Non-VCI lenders need the logic. You can see the
     * implemented logic in AbstractLenderBO. VCILenderBO implementation would do nothing.
     *
     * @param lenderBO
     * @param distributionCheckHandler
     * @param distributions
     * @param vaultIndicator String
     * @param files
     * @param deal
     * @param lenderId
     * @param errorDetail
     * @throws Exception
     */
    void validateContract(final LenderBO lenderBO, final List<DcDistribution> distributions,
        final String vaultIndicator, final List<File> files, final DeDeal deal, final String lenderId,
        final ErrorDetail errorDetail) throws Exception;

    /**
     * @param lenderBO
     * @param distributionCheckHandler
     * @param deal
     * @param lenderId
     * @param vaultIndicator
     * @param errorDetail
     * @throws Exception
     */
    void validateLender(final LenderBO lenderBO, final DeDeal deal, final String lenderId, final String partyId, final String vaultIndicator,
        final ErrorDetail errorDetail) throws Exception;

    /**
     * @param deal
     * @param distributionCheckHandler
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DeContractValidation getContractValidation(final LenderBO lenderBO, final DeDeal deal, final ErrorDetail errorDetail)
        throws Exception;

    void validateEconStatus(final LenderBO lenderBO, final DeDeal deal) throws ApplicationException;
}
