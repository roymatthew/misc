package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.enums.LenderEnum;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GenericLenderBO extends AbstractLenderBO {

	private static final Logger logger = LogManager.getLogger(GenericLenderBO.class);

    /**
     * Constructor.
     *
     * @param dms
     */
    public GenericLenderBO(final DmsBO dms) {
        super(dms);
    }

    /**
     * Constructor.
     *
     * @param dms
     * @param lenderEnum
     */
    public GenericLenderBO(final DmsBO dms, final LenderEnum lenderEnum) {
        super(dms, lenderEnum);
        setLenderId(lenderEnum.getLenderId());
        setLenderOrganization(lenderEnum.getOrganization());
    }

    /**
     * Constructor.
     *
     * @param dms
     * @param lenderId
     */
    public GenericLenderBO(final DmsBO dms, final String lenderId) {
        super(dms, LenderEnum.GENERIC);
        setLenderId(lenderId);
        setLenderOrganization(LenderEnum.GENERIC.getOrganization());
    }

    @Override
    public void checkContractInForms(DeDeal deal, List<File> files, ErrorDetail errorDetail, FormsDAO formsDao)
        throws ApplicationException {
        // do nothing
    }
}
