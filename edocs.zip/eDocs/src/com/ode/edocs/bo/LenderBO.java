package com.ode.edocs.bo;

import com.ode.edocs.DistributionCheckHandler;
import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;


public interface LenderBO {

    /**
     * @return lenderId String.
     */
    String getLenderId();

    /**
     * @param deal
     * @param distributionCheckHandler
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DeContractValidation getContractValidation(final DeDeal deal, final ErrorDetail errorDetail) throws Exception;

    /**
     * @param deal
     * @param files
     * @param errorDetail
     * @param formsDao
     * @throws ApplicationException
     */
    void checkContractInForms(final DeDeal deal, final List<File> files, final ErrorDetail errorDetail,
        final FormsDAO formsDao) throws ApplicationException;

    /**
     * @param deal
     * @param errorDetail
     * @throws ApplicationException
     */
    void validateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail) throws ApplicationException;

    /**
     * @param distributions
     * @param files
     * @param deal
     * @param lenderId
     * @param errorDetail
     * @throws Exception
     */
    void validateContract(final List<DcDistribution> distributions, final List<File> files, final DeDeal deal,
        final String lenderId, final ErrorDetail errorDetail) throws Exception;

    /**
     * @param files
     * @param errorDetail
     * @throws Exception
     */
    public void validateContractXml(final List<DcDistribution> distributions, final List<File> files, final ErrorDetail errorDetail) throws Exception;

    /**
     * @param deal
     * @param lenderId
     * @param vaultIndicator
     * @param errorDetail
     * @throws ApplicationException
     */
    void validateLender(final DeDeal deal, final String lenderId, final String partyId, final ErrorDetail errorDetail)
        throws ApplicationException;

    /**
     * @param deal
     * @param vaultRegisterDocumentDAO
     * @param distributionHasContract
     * @param attachmentProcessingVO
     * @param errorDetail
     * @throws ApplicationException
     * @throws Exception
     */
    void validateContractStatus(final DeDeal deal, final VaultRegisterDocumentDAO vaultRegisterDocumentDAO,
        boolean distributionHasContract, final AttachmentProcessingVO attachmentProcessingVO,
        final ErrorDetail errorDetail) throws ApplicationException, Exception;

    /**
     * Setter for validationUtil.
     *
     * @param validationUtil
     */
    void setValidationUtil(final IValidationUtil validationUtil);

    /**
     * @param distributionCheckHandler
     */
    void setDistributionCheckHandler(final DistributionCheckHandler distributionCheckHandler);

    void setPartyId(final String partyId);

    /**
     * @param deal
     * @throws ApplicationException
     */
    void validateEconStatus(final DeDeal deal) throws ApplicationException;   

   
    /**
     * @return
     */
    Boolean isEDocoutChangesRequired();
    
    /**
     * @param creditContractVO
     * @param inEcout
     * @return
     */

	Document makeChangesToEDocOut(final String documentId, final Document document, final Map<String, String> webSvcFeatures);

}
