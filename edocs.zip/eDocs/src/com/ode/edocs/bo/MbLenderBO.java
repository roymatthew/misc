package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.enums.LenderEnum;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MbLenderBO extends AbstractLenderBO {

	private static final Logger logger = LogManager.getLogger(MbLenderBO.class);

    /**
     * Constructor.
     *
     * @param dms
     */
    public MbLenderBO(final DmsBO dms) {
        super(dms);
    }

    /**
     * Constructor.
     * 
     * @param dms
     * @param lenderEnum
     */
    public MbLenderBO(final DmsBO dms, final LenderEnum lenderEnum) {
        super(dms, lenderEnum);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkContractInForms(final DeDeal deal, final List<File> files, final ErrorDetail errorDetail,
        final FormsDAO formsDao) throws ApplicationException {
    }
}
