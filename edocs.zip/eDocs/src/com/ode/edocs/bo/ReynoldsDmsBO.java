package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.enums.DmsEnum;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ReynoldsDmsBO extends AbstractDmsBO {

    private static final Logger logger = LogManager.getLogger(ReynoldsDmsBO.class);

    /**
     * Constructor.
     */
    public ReynoldsDmsBO() {
        super();
    }

    /**
     * Constructor.
     */
    public ReynoldsDmsBO(final DmsEnum anEnum) {
        super();
        super.dms = anEnum;
    }

    /**
     * Constructor.
     */
    public ReynoldsDmsBO(final DmsEnum anEnum, final IValidationUtil validationUtil) {
        super();
        super.setDms(anEnum);
        super.setValidationUtil(validationUtil);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDmsId() {
        return super.dms.getDmsId();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkContractInForms(final DeDeal deal, final List<File> files, final FormsDAO formsDao,
        final ErrorDetail errorDetail, final LenderBO lenderBO) throws ApplicationException {
        lenderBO.checkContractInForms(deal, files, errorDetail, formsDao);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail, final LenderBO lenderBO)
        throws ApplicationException {
        lenderBO.validateFundingStatus(deal, errorDetail);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContractStatus(final DeDeal deal, final VaultRegisterDocumentDAO vaultRegisterDocumentDAO,
        final boolean distributionHasContract, final AttachmentProcessingVO attachmentProcessingVO,
        final LenderBO lenderBO, final ErrorDetail errorDetail) throws ApplicationException, Exception {
        lenderBO.validateContractStatus(deal, vaultRegisterDocumentDAO, distributionHasContract, attachmentProcessingVO,
            errorDetail);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContract(final LenderBO lenderBO, final List<DcDistribution> distributions,
        final String vaultIndicator, final List<File> files, final DeDeal deal, final String lenderId,
        final ErrorDetail errorDetail) throws Exception {
        logger.debug("Enter validateContract");
        // only non vci lenders would execute logic. We would override VCI lender method and do nothing
        // there.
        if (AppConstants.YES.equalsIgnoreCase(vaultIndicator)) {
            lenderBO.validateContract(distributions, files, deal, lenderId, errorDetail);
        }
        logger.debug("Exit validateContract");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateLender(final LenderBO lenderBO, final DeDeal deal, final String lenderId,
        final String partyId, final String vaultIndicator, final ErrorDetail errorDetail) throws Exception {
        logger.debug("Enter validateLender");
        // only non vci lenders would execute logic. We would override VCI lender method and do nothing
        // there.
        if (AppConstants.YES.equalsIgnoreCase(vaultIndicator)) {
            lenderBO.validateLender(deal, lenderId, partyId, errorDetail);
        }
        logger.debug("Exit validateLender");

    }

    @Override
    public void validateEconStatus(final LenderBO lenderBO, final DeDeal deal) throws ApplicationException {

        lenderBO.validateEconStatus(deal);
    }

}
