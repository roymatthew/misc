package com.ode.edocs.bo;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.XMLConstants;
import com.ode.edocs.util.enums.LenderEnum;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import com.ode.vault.db.entity.VaultRegisterDocument;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;

/**
 * Lender specific implementation for VCI.
 */
public class VciLenderBO extends AbstractLenderBO {

    private static final Logger logger = LogManager.getLogger(VciLenderBO.class);

    /**
     * Constructor with argument.
     *
     * @param dms DmsBO.
     */
    public VciLenderBO(final DmsBO dms) {
        super(dms);
    }

    public VciLenderBO(final DmsBO dms, final LenderEnum lenderEnum) {
        super(dms, lenderEnum);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateLender(final DeDeal deal, final String lenderId, final String partyId,
        final ErrorDetail errorDetail) throws ApplicationException {

        // do nothing here.

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkContractInForms(DeDeal deal, List<File> files, ErrorDetail errorDetail, FormsDAO formsDao)
        throws ApplicationException {
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateFundingStatus(final DeDeal deal, final ErrorDetail errorDetail) throws ApplicationException {

        logger.entry(deal);

        final String fundingStatus = deal.getFundingStatus();
        boolean statusCheck = AppConstants.FUNDING_STATUS_BOOKED.equalsIgnoreCase(fundingStatus);

        if (statusCheck) {
            throw new ApplicationException(errorDetail.add(AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_MESSAGE,
                AppConstants.DE_DEAL_WRONG_FUNDING_STATUS_CODE));
        }

        logger.exit();

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContractStatus(final DeDeal deal, final VaultRegisterDocumentDAO vaultRegisterDocumentDAO,
        boolean distributionHasContract, final AttachmentProcessingVO attachmentProcessingVO,
        final ErrorDetail errorDetail) throws Exception {

        String status = deal.getEconStatus();
        if (distributionHasContract) {
            // Check if the distribution request has contract xml file
            if (getValidationUtil()
                .doesDistributionHasAncillaryContractFile(attachmentProcessingVO.getAncillaryFiles())) {

                Document ancillaryContractDataFile = HandlerUtils
                    .getAncillaryContractDataForVCI(attachmentProcessingVO.getFiles());

                String documentName = HandlerUtils.evaluateExpression(ancillaryContractDataFile,
                    XMLConstants.ancillaryformDataDocNamePath);

                // If the EconStatus from DeDeal table is null or empty, check if any vault action is done
                // from VaultRegisterDocument table.

                if ((status == null || status.isEmpty()) && documentName.startsWith("E-")) {
                    VaultRegisterDocument vaultDocRecord = vaultRegisterDocumentDAO
                        .findVaultDocId(deal.getDmsDealerId(), deal.getDealId());
                    getValidationUtil().checkVaultStatus(deal, vaultDocRecord, errorDetail);
                } else if ("Assigned".equalsIgnoreCase(status)) {
                    if (!documentName.startsWith("E-")) {
                        logger.error("Distribution does not have the Assigned Contract");
                        throw new ApplicationException(
                            errorDetail.add(AppConstants.NO_ASSIGNED_CONTRACT_IN_DISTRIBUTION_ERROR_MESSAGE,
                                AppConstants.NO_ASSIGNED_CONTRACT_IN_DISTRIBUTION_CODE));
                    }
                }
            } else { // If the Contract xml doesn't exist
                if ("Assigned".equalsIgnoreCase(status)) {
                    logger.error("Distribution does not have the Assigned Contract");
                    throw new ApplicationException(
                        errorDetail.add(AppConstants.NO_ASSIGNED_CONTRACT_IN_DISTRIBUTION_ERROR_MESSAGE,
                            AppConstants.NO_ASSIGNED_CONTRACT_IN_DISTRIBUTION_CODE));
                }
            }

        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContract(final List<DcDistribution> distributions, final List<File> files, final DeDeal deal,
        final String lenderId, final ErrorDetail errorDetail) throws Exception {

        // do nothing here.

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateContractXml(final List<DcDistribution> distributions, final List<File> files, final ErrorDetail errorDetail) throws Exception {

        File contractFile = null;

        //On initial distribution only
        if (!getValidationUtil().previousDistributionExists(distributions)) {
            for (File file : files) {
                String fileName = file.getFilename();
                String docName = file.getFilename().substring(0, fileName.lastIndexOf('.'));

                boolean isContract = getValidationUtil().isVCIContract(docName);

                if(isContract) {
                    contractFile = file;
                }
            }

            if(contractFile == null)  {
                //No contract file exists in the initial distribution. ODE must error back to the DMS.
                throw new ApplicationException(errorDetail.add(AppConstants.CONTRACT_NAME_NOT_ASSIGNED_MESSAGE, AppConstants.CONTRACT_NAME_NOT_ASSIGNED_CODE));
            }
        }
    }

    @Override
    public void validateEconStatus(final DeDeal deal) {
        // do nothing here.
    }


}
