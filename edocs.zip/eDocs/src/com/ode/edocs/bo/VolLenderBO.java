/**
 * 
 */
package com.ode.edocs.bo;

import java.time.Instant;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.enums.LenderEnum;

/**
 * @author rmathew
 *
 */
public class VolLenderBO extends AbstractLenderBO {

	private static final Logger logger = LogManager.getLogger(VolLenderBO.class);

	/**
	 * Constructor.
	 *
	 * @param dms DmsBO.
	 */
	public VolLenderBO(final DmsBO dms) {
		super(dms);
	}

	public VolLenderBO(final DmsBO dms, final LenderEnum lenderEnum) {
		super(dms, lenderEnum);
	}

	/**
	 * {@inheritDoc}
	 */
	public Boolean isEDocoutChangesRequired() {
		return Boolean.TRUE;
	}

	@Override
	public Document makeChangesToEDocOut(final String documentId, final Document document,
			final Map<String, String> webSvcFeatures) {

		logger.debug("Entered makeChangesToEcout() method of VolLenderBO class");
		
		if (null == webSvcFeatures || webSvcFeatures.isEmpty())
		{
			logger.error("Could not find feature configurations for VOL! Please check DB configuration.");
			logger.debug("Returning document as is.");
			return document;
		}
		
		NodeList soapHeaderNodeList = document.getElementsByTagName("soap:Header");
		if (null == soapHeaderNodeList || soapHeaderNodeList.getLength() == 0) {
			logger.debug("Element soap:Header not found! Looking up element Header instead");
			soapHeaderNodeList = document.getElementsByTagName("Header");
		}
		if (null != soapHeaderNodeList && soapHeaderNodeList.getLength() > 0) {
			Node soapHeaderNode = soapHeaderNodeList.item(0);
			Element fASServiceControlElement = document.createElement(AppConstants.SOAP_HEADER_FA_SVC_CNTRL);
			fASServiceControlElement.setAttribute(AppConstants.NS_PREFIX_XMLNS_H_NAME, AppConstants.NS_XMLNS_H_VALUE);
			fASServiceControlElement.setAttribute(AppConstants.NS_PREFIX_XMLNS_NAME, AppConstants.NS_XMLNS_H_VALUE);
			fASServiceControlElement.setAttribute(AppConstants.NS_PREFIX_XMLNS_XSD_NAME, AppConstants.NS_XMLNS_XSD_VALUE);
			fASServiceControlElement.setAttribute(AppConstants.NS_PREFIX_XMLNS_XSI_NAME, AppConstants.NS_XMLNS_XSI_VALUE);
			Element languageCodeElement = document.createElement(AppConstants.SOAP_HEADER_MSG_LANG_CODE);
			languageCodeElement.setTextContent(webSvcFeatures.get(AppConstants.SOAP_HEADER_MSG_LANG_CODE));
			Element senderIdElement = document.createElement(AppConstants.SOAP_HEADER_SENDER_ID);
			senderIdElement.setTextContent(webSvcFeatures.get(AppConstants.SOAP_HEADER_SENDER_ID));
			Element timeStampElement = document.createElement(AppConstants.SOAP_HEADER_SENT_TS);
			timeStampElement.setTextContent(Instant.now().toString());
			Element targetIDElement = document.createElement(AppConstants.SOAP_HEADER_TARGET_ID);
			targetIDElement.setTextContent(webSvcFeatures.get(AppConstants.SOAP_HEADER_TARGET_ID));
			Element correlationID = document.createElement(AppConstants.SOAP_HEADER_CORRELATION_ID);
			correlationID.setTextContent(documentId);
			Element messageType = document.createElement(AppConstants.SOAP_HEADER_MESSAGE_TYPE);
			messageType.setTextContent(webSvcFeatures.get(AppConstants.SOAP_HEADER_MESSAGE_TYPE));

			fASServiceControlElement.appendChild(languageCodeElement);
			fASServiceControlElement.appendChild(senderIdElement);
			fASServiceControlElement.appendChild(timeStampElement);
			fASServiceControlElement.appendChild(targetIDElement);
			fASServiceControlElement.appendChild(correlationID);
			fASServiceControlElement.appendChild(messageType);

			if (soapHeaderNode instanceof Element) {
				Element soapHeaderElement = (Element) soapHeaderNode;
				soapHeaderElement.appendChild(fASServiceControlElement);
				NodeList payloadManifestNodeList = document
						.getElementsByTagName(AppConstants.TAG_NAME_PAYLOAD_MANIFEST);
				if (null != payloadManifestNodeList && payloadManifestNodeList.getLength() > 0) {
					soapHeaderElement
							.removeChild(document.getElementsByTagName(AppConstants.TAG_NAME_PAYLOAD_MANIFEST).item(0));
				}
			}
			
			return restructureSoapBody(document, webSvcFeatures);
		}
		
		return document;
		
	}

	/**
	 * @param document
	 * @return
	 */
	private Document restructureSoapBody(final Document document, final Map<String, String> webSvcFeatures) {
		logger.debug("Entered restructureSoapBody() method of VolLenderBO class");
		NodeList soapBodyNodeList = document.getElementsByTagName(com.ode.edocs.util.AppConstants.TAG_NAME_SOAP_BODY);
		if (null == soapBodyNodeList || soapBodyNodeList.getLength() == 0)
		{
			soapBodyNodeList = document.getElementsByTagName("soapenv:Body");
		}
		if (null != soapBodyNodeList && soapBodyNodeList.getLength() > 0) {
			Node soapBodyNode = soapBodyNodeList.item(0);
			if (soapBodyNode instanceof Element) {
				Element soapBodyElement = (Element) soapBodyNode;
				Element putRequestElement = document.createElement(com.ode.edocs.util.AppConstants.TAG_NAME_PUT_REQUEST);
				putRequestElement.setAttribute(AppConstants.NS_PREFIX_XMLNS_NAME, webSvcFeatures.get(AppConstants.PUT_REQUEST_XMLNS));
				Element messageElement = document.createElement("message");
				putRequestElement.appendChild(messageElement);
				final NodeList pccNodeList = document.getElementsByTagName(AppConstants.TAG_NAME_PCC);
				if (null != pccNodeList && pccNodeList.getLength() > 0) {
					Node pccNode = pccNodeList.item(0);
					if (pccNode instanceof Element) {
						Element pccElement = (Element) pccNode;
						messageElement.appendChild(pccElement);
					}
				}
				soapBodyElement.appendChild(putRequestElement);
				NodeList putMessageNodeList = document
						.getElementsByTagName(AppConstants.TAG_NAME_PUT_MESSAGE);
				if (null != putMessageNodeList && putMessageNodeList.getLength() > 0)
				{
					soapBodyElement.removeChild(document.getElementsByTagName(com.ode.edocs.util.AppConstants.TAG_NAME_PUT_MESSAGE).item(0));
				}
			}
		}

		return document;
	}

}
