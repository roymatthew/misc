package com.ode.edocs.bo.factory;

import com.ode.edocs.bo.CdkDmsBO;
import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.bo.ReynoldsDmsBO;
import com.ode.edocs.bo.AdventDmsBO;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.enums.DmsEnum;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DmsBOFactory {

    @Autowired
    private IValidationUtil validationUtil;

    private static final Logger logger = LogManager.getLogger(DmsBOFactory.class);

    /**
     * Returns an instance of DMSBO that corresponds to the given dmsId.
     *
     * @param dmsId String
     * @return dms DmsBO
     */
    public DmsBO createDMS(final String dmsId) throws Exception {
        logger.debug("Enter createDMS");
        DmsEnum dmsEnum = null;

        dmsEnum = DmsEnum.getDmsEnumByDmsId(dmsId);

        if (dmsEnum == null) {
            throw new ApplicationException("Could not create a DMS with dmsId: " + dmsId);
        }

        DmsBO dms = null;
		switch (dmsEnum) {
			case AR:
				dms = new AdventDmsBO(DmsEnum.AR, validationUtil);
				break;
			case CDK:
				dms = new CdkDmsBO(DmsEnum.CDK, validationUtil);
				break;
			case AD:
				dms = new CdkDmsBO(DmsEnum.AD, validationUtil);
				break;
			case RR:
				dms = new ReynoldsDmsBO(DmsEnum.RR, validationUtil);
			default:
				break;
		}

        logger.debug("Created a DMS with dmsID: " + (dms.getDmsId() != null ? dms.getDmsId() : ""));
        return dms;
    }

}
