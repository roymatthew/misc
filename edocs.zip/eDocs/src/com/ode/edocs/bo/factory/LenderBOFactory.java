package com.ode.edocs.bo.factory;

import com.ode.edocs.DistributionCheckHandler;
import com.ode.edocs.bo.ChaseLenderBO;
import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.bo.GenericLenderBO;
import com.ode.edocs.bo.LenderBO;
import com.ode.edocs.bo.MbLenderBO;
import com.ode.edocs.bo.VciLenderBO;
import com.ode.edocs.bo.VolLenderBO;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.enums.LenderEnum;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LenderBOFactory {

    @Autowired
    private IValidationUtil validationUtil;

    @Autowired
    private DistributionCheckHandler distributionCheckHandler;

    private static final Logger logger = LogManager.getLogger(LenderBOFactory.class);

    /**
     * Returns an instance of LenderBO that corresponds to the given lenderId.
     *
     * @param lenderId String
     * @param dms DmsBO
     * @return LenderBO
     */
    public LenderBO createLender(final String lenderId, final String partyId, final DmsBO dms) throws ApplicationException {
        logger.debug("Enter createLender() method of LenderBOFactory.class");
        LenderBO lender = null;
        LenderEnum lenderEnum = null;

        try {
            lenderEnum = LenderEnum.getLenderEnum(lenderId);
        } catch (final Exception e) {
        	lenderEnum = LenderEnum.GENERIC;
            throw new ApplicationException("Invalid lenderId provided");
        }

        switch (lenderEnum) {
            case VCI:
                lender = new VciLenderBO(dms, lenderEnum);
                break;
            case VOL:
                lender = new VolLenderBO(dms, lenderEnum);
                break;
            case JPM:
                lender = new ChaseLenderBO(dms, lenderEnum);
                break;
            case SMF:
                lender = new ChaseLenderBO(dms, lenderEnum);
                break; 
            default:
                if (!lenderId.equals(lenderEnum.getLenderId())) {
                    lender = new GenericLenderBO(dms, lenderId);
                } else {
                    lender = new GenericLenderBO(dms, lenderEnum);
                }
                break;
        }
        lender.setValidationUtil(validationUtil);
        lender.setDistributionCheckHandler(distributionCheckHandler);
        lender.setPartyId(partyId);
        logger.debug("Created a Lender with lenderID: " + lender.getLenderId());
        return lender;
    }

}
