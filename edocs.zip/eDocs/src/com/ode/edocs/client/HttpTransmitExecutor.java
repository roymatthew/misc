package com.ode.edocs.client;

import java.io.IOException;

import org.apache.http.HttpException;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class HttpTransmitExecutor {
	
	private static final Logger logger = LogManager.getLogger(HttpTransmitExecutor.class);

	public HttpResponse executePost(HttpPost post) throws HttpException, IOException {
		logger.debug(post);
		
		HttpClient client = getHttpClient();
		HttpResponse httpResponse = client.execute(post);
			
		return httpResponse;
	}
	
	public HttpResponse executeDelete(HttpDelete delete) throws HttpException, IOException {
		logger.debug(delete);
		
		HttpClient client = getHttpClient();
		HttpResponse httpResponse = client.execute(delete);
			
		return httpResponse;
	}
	
	private HttpClient getHttpClient() {
		return HttpClientBuilder.create().build();
	}
}