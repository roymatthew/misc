package com.ode.edocs.client;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.db.entity.FeatureConfiguration;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.service.IDealService;
import com.ode.edocs.service.IFeatureConfigurationDAOService;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.EdocsSecureTransmissionUtil;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.IServicesUtil;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.vo.CommonsUtilNvpVO;
import com.ode.edocs.vo.OdeTokenResponseVO;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.net.ssl.SSLContext;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.PrivateKeyDetails;
import org.apache.http.ssl.PrivateKeyStrategy;
import org.apache.http.ssl.SSLContexts;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * Class that takes care of transmitting data to lender.
 */
@Component
public class LenderTransmitClient {

    private static final Logger logger = LogManager.getLogger(LenderTransmitClient.class);

    @Autowired
    private IFeatureConfigurationDAOService featureConfigurationService;

    @Autowired
    private IDealService dealService;

    @Autowired
    private IServicesUtil servicesUtil;
    
    @Autowired
    private IValidationUtil validationUtil;
    
    @Value("${defiTokenServiceUrl}")
    private String defiTokenServiceUrl;

    /**
     * @param outgoingXml
     * @param lenderId
     * @param lender
     * @param lenderDest
     * @param isDistribute
     * @param deDeal
     * @param sequenceId
     * @param errorDetail
     * @param vaultDocId
     * @return
     * @throws Exception
     */
    public String sendToLender(String outgoingXml, String lenderId, DeLender lender, DeLenderDestination lenderDest,
            boolean isDistribute, DeDeal deDeal, String sequenceId, ErrorDetail errorDetail, String vaultDocId, boolean isRouteOne)
            throws Exception {

        logger.debug("Entered sendToLender method");
        String lenderResponse = null;
        List<FeatureConfiguration> featureConfigurations = featureConfigurationService.getConfiguration(lenderId);
        if (null != featureConfigurations && !featureConfigurations.isEmpty()) {
            lenderResponse = sendToLenderViaSecureChannel(featureConfigurations, outgoingXml, lenderId, lender, lenderDest, isDistribute, deDeal,
                sequenceId, errorDetail, vaultDocId, isRouteOne);
        } else {
            lenderResponse = sendToLenderNormally(outgoingXml, lenderId, lender, lenderDest, isDistribute, deDeal,
                    sequenceId, errorDetail, vaultDocId, isRouteOne);
        }

        logger.debug("Exit sendToLender method");
        return lenderResponse;
    }

    /**
     * @param featureConfigurations 
     * @param outgoingXml
     * @param lenderId
     * @param lender
     * @param lenderDest
     * @param isDistribute
     * @param deDeal
     * @param sequenceId
     * @param errorDetail
     * @param vaultDocId
     * @param isRouteOne
     * @return
     * @throws Exception 
     */
    public String sendToLenderViaSecureChannel(List<FeatureConfiguration> featureConfigurations, String outgoingXml,
        String lenderId, DeLender lender, DeLenderDestination lenderDest, boolean isDistribute, DeDeal deDeal,
        String sequenceId, ErrorDetail errorDetail, String vaultDocId, boolean isRouteOne) throws Exception {
        
        logger.debug("Entered sendToLenderViaSecureChannel() method of LenderTransmitClient class");
        
        String destUrl = lenderDest.getDestination_url();
        if (destUrl == null || destUrl.isEmpty()) {
            logger.error("Destination not found for lender: {}", lenderId);
            throw new ApplicationException(
                    errorDetail.add(AppConstants.LENDER_DESTINATION_NOT_FOUND_MESSAGE + ": " + lenderId,
                            AppConstants.LENDER_DESTINATION_NOT_FOUND_CODE));
        }
        logger.debug("destUrl: {}", destUrl);

        List<FeatureConfiguration> listOfWebServiceFeatureConfigurations = new ArrayList<>();
        boolean twoWaySSLRequiredForLender = false;
        ResponseEntity<String> responseEntity = null;
        String response = "";

        if (null != featureConfigurations && !featureConfigurations.isEmpty()) {
            for (FeatureConfiguration featureConfiguration : featureConfigurations)
                if (AppConstants.PRODUCT_EDOCS.equals(featureConfiguration.getProduct())
                    && AppConstants.FEATURE_NAME_TWO_WAY_SSL.equals(featureConfiguration.getFeatureName())) {
                    twoWaySSLRequiredForLender = true;
                    break;
                } else if (AppConstants.PRODUCT_WEBSVC.equals(featureConfiguration.getProduct())) {
                    listOfWebServiceFeatureConfigurations.add(featureConfiguration);
                }
        }

        if (twoWaySSLRequiredForLender) {
            logger.debug("Entered twoWaySSLRequiredForLender block");
            return sendToLenderWithTwoWaySSL(outgoingXml, lenderId, lender, lenderDest, isDistribute, deDeal,
                sequenceId, errorDetail, vaultDocId, isRouteOne);
        }

        List<CommonsUtilNvpVO> listOfWebServiceFeatures = getWebServiceFeaturesForLender(
            listOfWebServiceFeatureConfigurations);
        try {
            RestTemplate restTemplate = null;
            try {
                restTemplate = EdocsSecureTransmissionUtil.getRestTemplate(listOfWebServiceFeatures);
            } catch (Exception e) {
                
                logger.debug("Exception from EdocsSecureTransmissionUtil.getRestTemplate", e);
                restTemplate = new RestTemplate();
            }
            MultiValueMap<String, String> headers = getLenderSpecificHeaders(lenderDest);
            HttpEntity<String> requestEntity = new HttpEntity<String>(outgoingXml, headers);
            responseEntity = restTemplate.exchange(lenderDest.getDestination_url(), HttpMethod.POST, requestEntity,
                String.class);

            if (null != responseEntity) {
                response = responseEntity.getBody();
                int statusCode = responseEntity.getStatusCode().value();
                logger.debug("StatusCode: {}", statusCode);
                if (responseEntity.getStatusCode() == HttpStatus.OK
                    || responseEntity.getStatusCode() == HttpStatus.ACCEPTED) {
                    if (isDistribute) {
                        logger.debug("**** Successfully sent distribution to Lender. statusCode: {} ****",
                            responseEntity.getStatusCode().toString());
                        logger.debug("Response from Lender: {} ", responseEntity.getBody().replaceAll("[\r\n]+", " "));
                    } else {
                        logger.debug("Successfully sent Spot ReCv to lender.");
                    }
                }
                if (!isHttpSuccess(statusCode)) {
                    String errorDescription = null;
                    if (isDistribute) {
                        errorDescription = "Error sending xml to lender at: " + destUrl + ". Response code is " + statusCode;
                        logger.error(errorDescription);
                        
                        // Call withdraw process only for CDK
                        if (validationUtil.isCDKDeal(deDeal.getDmsId())) {
                            if (!isRouteOne) {
                                logger.debug("HTTP Failure to lender, trying to call withdraw process for CDK");
                                callWithDrawProcess(deDeal, vaultDocId);
                            } else {
                                logger.debug("RouteOne transaction, not calling withdraw process");
                            }
                        } else {
                            if (!isRouteOne) { 
                                logger.debug("HTTP Failure to lender, Bypassing withdraw process for non CDK deal"); 
                            }
                            // For RR, just update the distribution status and proceed
                            deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_LENDER_FAILURE);
                            deDeal.setDistributionTs(new Date());
                            dealService.saveOrUpdate(deDeal);
                        }
                    } else {
                        errorDescription = "Error sending Spot ReCV request to lender at: " + destUrl + ". Response code is " + statusCode;
                        logger.error(errorDescription);
                    }
                    
                    ApplicationException ae = new ApplicationException(lenderId, errorDescription, AppConstants.DISTRIBUTION_LENDER_FAILURE_STATUS_ERROR_CODE);
                    ae.setErrorDetail(errorDetail);
                    throw ae;
                }
            }
        } catch (final Exception e) {
            logger.error("Error sending distribution request to lender at: {}", destUrl);
            ApplicationException ae = new ApplicationException(AppConstants.DISTRIBUTE_LENDER_FAILURE, AppConstants.DISTRIBUTE_FAILURE_CODE, e);
            ae.setErrorDetail(errorDetail);
            throw ae;
        }
        logger.debug("Exit sendToLenderViaSecureChannel() method of LenderTransmitClient class");
        return response;
    }
    
    /**
     * @param lenderDestination
     * @return
     */
    private MultiValueMap<String, String> getLenderSpecificHeaders(final DeLenderDestination lenderDestination) {
        logger.debug("Entered getLenderSpecificHeaders method in LenderTransmitClient.");
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        if (AppConstants.AUTH_TYPE_LDAP.equals(lenderDestination.getWs_auth_type())) {
            String base64LdapAuth = new String(Base64.encodeBase64(lenderDestination.getWs_username().getBytes()));
            headers.add(AppConstants.HEADER_AUTH_LABEL, AppConstants.AUTH_HEADER_TYPE_BASIC + base64LdapAuth);
            headers.add(AppConstants.HEADER_COOKIE_LABEL, lenderDestination.getWs_password());
        } else if (AppConstants.AUTH_TYPE_OAUTH2.equals(lenderDestination.getWs_auth_type())) {
            String token = getOauth2Token(lenderDestination.getDe_lender_id());
            if (StringUtils.isNotBlank(token)) {
                headers.add(AppConstants.HEADER_AUTH_LABEL, AppConstants.AUTH_HEADER_TYPE_BEARER + token);
                logger.debug("Added Authorization token to request header.");
            }
            else
            {
                logger.debug("Failed to add Authorization token to request header.");
            }
        }

        if (StringUtils.isNotEmpty(lenderDestination.getWs_content_type())) {
            String contentType = lenderDestination.getWs_content_type();
            headers.add(AppConstants.HEADER_CONTENT_LABEL, contentType);
            logger.debug("Added Content-Type header with value of {}", contentType);
        }

        if (StringUtils.isNotEmpty(lenderDestination.getWs_soap_action())) {
            String soapAction = lenderDestination.getWs_soap_action();
            headers.add(AppConstants.HTTP_HEADERS_SOAP_ACTION_LABEL, soapAction);
            logger.debug("Added SOAPAction header with value of {}", soapAction);
        }

        return headers;
    }
    
    /**
    *
    * @param lenderId
    * @return
    */
   private String getOauth2Token(final String lenderId) {
       logger.debug("Entered getOauth2Token method in LenderTransmitClient. LenderID: {}", lenderId);
       String tokenUrl = "";
       String token = "";
       if (AppConstants.LENDER_VOL.equals(lenderId) || AppConstants.LENDER_VCF.equals(lenderId)) {
           tokenUrl = this.defiTokenServiceUrl;
       }
       try {
           RestTemplate restTemplate = new RestTemplate();
           logger.debug("URL to get Token for LenderId {} is {}",lenderId, tokenUrl);
           ResponseEntity<OdeTokenResponseVO> response = restTemplate.getForEntity(tokenUrl, OdeTokenResponseVO.class);
           token = response.getBody().getToken();
           logger.debug("Received token from Common Service.");
       } catch (Exception e) {
           logger.debug("Could not retrieve token", e);
       }
       return token;
   }

    /**
     * @param featureConfigurations
     * @return
     */
    private static List<CommonsUtilNvpVO> getWebServiceFeaturesForLender(List<FeatureConfiguration> featureConfigurations) {
        logger.debug("Entered getWebServiceFeaturesForLender method of LenderTransmitClient");
        List<CommonsUtilNvpVO> listOfWebServiceFeatures = new ArrayList<>();
        featureConfigurations.stream().forEach(featureConfig -> {
            CommonsUtilNvpVO nvpVO = new CommonsUtilNvpVO();
            nvpVO.setName(featureConfig.getFeatureName());
            nvpVO.setValue(featureConfig.getFeatureValue());
            listOfWebServiceFeatures.add(nvpVO);
        });
        logger.debug(
            "Exit getWebServiceFeaturesForLender method of LenderTransmitClient. listOfWebServiceFeatures contains {} items",
            listOfWebServiceFeatures.size());
        return listOfWebServiceFeatures;
    }

    /**
     * @param outgoingXml
     * @param lenderId
     * @param lender
     * @param lenderDest
     * @param isDistribute
     * @param deDeal
     * @param sequenceId
     * @param errorDetail
     * @param vaultDocId
     * @return
     * @throws Exception
     */
    public String sendToLenderNormally(String outgoingXml, String lenderId, DeLender lender,
            DeLenderDestination lenderDest, boolean isDistribute, DeDeal deDeal, String sequenceId,
            ErrorDetail errorDetail, String vaultDocId, boolean isRouteOne) throws Exception {

        logger.debug("Entered sendToLenderNormally method");

        // Get Destination URL
        String destUrl = lenderDest.getDestination_url();
        if (destUrl == null || destUrl.isEmpty()) {
            logger.error("Destination not found for lender: {}", lenderId);
            throw new ApplicationException(
                    errorDetail.add(AppConstants.LENDER_DESTINATION_NOT_FOUND_MESSAGE + ": " + lenderId,
                            AppConstants.LENDER_DESTINATION_NOT_FOUND_CODE));
        }
        logger.debug("destUrl: {}", destUrl);

        List<Header> headers = buildHeaders(lenderDest);

        PostMethod mPost = new PostMethod(destUrl);
        HttpClient httpClient = new HttpClient();
        String responseBody = "";
        int statusCode = 0;

        try {
            // Setting RequestEntity if RequestXml is not null
            if (null != outgoingXml && outgoingXml.trim().length() != 0) {
                mPost.setRequestEntity(HandlerUtils.getRequestEntity(outgoingXml));
            }

            if (null != headers && !headers.isEmpty()) {
                for (Header header : headers) {
                    mPost.setRequestHeader(header);
                }
            }

            // Executing send request
            statusCode = httpClient.executeMethod(mPost);
            logger.debug("statusCode: {}", statusCode);
            // Setting Status code in ResponseMessage

            // Read the response body.
            if (null != mPost.getResponseBody()) {
                responseBody = new String(mPost.getResponseBody());
                logger.debug("response body: {}", responseBody);
            }

            // Read Cookies
            if (null != httpClient.getState() && null != httpClient.getState().getCookies()) {
                httpClient.getState().getCookies();
            }

            if (isHttpSuccess(statusCode)) {
                if (isDistribute) logger.debug("Successfully sent distribution to lender.");
                else logger.debug("Successfully sent Spot ReCv to lender.");
            } else {
                String errorDescription = null;
                if (isDistribute) {
                    errorDescription = "Error sending document to lender at: " + destUrl + ". Response code is " + statusCode;
                    logger.error(errorDescription);
                    
                    // Call withdraw process only for CDK
                    if (validationUtil.isCDKDeal(deDeal.getDmsId())) {
                        if (!isRouteOne) {
                            logger.debug("HTTP Failure to lender, trying to call withdraw process for CDK");
                            callWithDrawProcess(deDeal, vaultDocId);
                        } else {
                            logger.debug("RouteOne transaction, not calling withdraw process");
                        }
                    } else {
                        if (!isRouteOne) { 
                            logger.debug("HTTP Failure to lender, Bypassing withdraw process for non CDK deal"); 
                        }
                        // For RR, just update the distribution status and proceed
                        deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_LENDER_FAILURE);
                        deDeal.setDistributionTs(new Date());
                        dealService.saveOrUpdate(deDeal);
                    }
                } else {
                    errorDescription = "Error sending Spot ReCV request to lender at: " + destUrl + ". Response code is " + statusCode;
                    logger.error(errorDescription);
                }

                ApplicationException ae = new ApplicationException(lenderId, errorDescription, AppConstants.DISTRIBUTION_LENDER_FAILURE_STATUS_ERROR_CODE);
                ae.setErrorDetail(errorDetail);
                throw ae;
            }

        } catch (Exception e) {
            logger.error("Error sending tranaction to lender at: {}", destUrl, e);
            ApplicationException ae = new ApplicationException(AppConstants.DISTRIBUTE_LENDER_FAILURE, AppConstants.DISTRIBUTE_FAILURE_CODE, e);
            ae.setErrorDetail(errorDetail);
            throw ae;
        } finally {
            try {
                if (null != mPost) {
                    mPost.releaseConnection();
                }
            } catch (Exception e) {
                logger.error("Error releasing PostMethod connection.", e);
                ApplicationException ae = new ApplicationException(e, "Error releasing PostMethod connection.");
                ae.setErrorDetail(errorDetail);
                throw ae;
            }
        }

        logger.debug("Exited sendToLenderNormally method");
        return responseBody;
    }

    /**
     * @param outgoingXml
     * @param lenderId
     * @param lender
     * @param lenderDest
     * @param isDistribute
     * @param deDeal
     * @param sequenceId
     * @param errorDetail
     * @param vaultDocId
     * @param isRouteOne
     * @return
     * @throws Exception
     */
    public String sendToLenderWithTwoWaySSL(String outgoingXml, String lenderId, DeLender lender,
            DeLenderDestination lenderDest, boolean isDistribute, DeDeal deDeal, String sequenceId,
            ErrorDetail errorDetail, String vaultDocId, boolean isRouteOne) throws Exception {

        logger.debug("Entered sendToLenderWithTwoWaySSL method");

        int statusCode = 0;
        String responseBody = "";

        // Get Destination URL
        String destUrl = lenderDest.getDestination_url();
        if (destUrl == null || destUrl.isEmpty()) {
            logger.error("Destination not found for lender: {}", lenderId);
            throw new ApplicationException(
                    errorDetail.add(AppConstants.LENDER_DESTINATION_NOT_FOUND_MESSAGE + ": " + lenderId,
                            AppConstants.LENDER_DESTINATION_NOT_FOUND_CODE));
        }
        logger.debug("destUrl: {}", destUrl);

        try {
            KeyStore identityKeyStore = KeyStore.getInstance(AppConstants.IDENTITY_KEY_STORE_TYPE);
            FileInputStream identityKeyStoreFile = new FileInputStream(
                    new java.io.File(AppConstants.IDENTITY_KEY_STORE_FILE));
            identityKeyStore.load(identityKeyStoreFile, AppConstants.IDENTITY_KEY_STORE_PASS.toCharArray());

            KeyStore trustKeyStore = KeyStore.getInstance(AppConstants.TRUST_KEY_STORE_TYPE);
            FileInputStream trustKeyStoreFile = new FileInputStream(
                    new java.io.File(AppConstants.TRUST_KEY_STORE_FILE));
            trustKeyStore.load(trustKeyStoreFile, AppConstants.TRUST_KEY_STORE_PASS.toCharArray());

            PrivateKeyStrategy privateKeyStrategy = new PrivateKeyStrategy() {
                @Override
                public String chooseAlias(Map<String, PrivateKeyDetails> aliases, Socket socket) {
                    return AppConstants.CERT_ALIAS;
                }
            };

            SSLContext sslContext = SSLContexts.custom()
                    // load identity keystore
                    .loadKeyMaterial(identityKeyStore, AppConstants.IDENTITY_KEY_STORE_PASS.toCharArray(),
                            privateKeyStrategy)
                    // load trust keystore
                    .loadTrustMaterial(trustKeyStore, null).build();

            SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,
                    new String[] { "TLSv1.2" }, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory)
                    .build();

            HttpPost post = new HttpPost(destUrl);

            List<Header> headers = buildHeaders(lenderDest);

            if (null != headers && !headers.isEmpty()) {
                for (Header header : headers) {
                    if (null != header && null != header.getName() && null != header.getValue()) {
                        post.setHeader(header.getName(), header.getValue());
                    }
                }
            }

            // Setting RequestEntity if RequestXml is not null
            if (null != outgoingXml && outgoingXml.trim().length() != 0) {
                StringEntity entity = new StringEntity(outgoingXml);
                post.setEntity(entity);
            }

            HttpResponse response = httpClient.execute(post);
            statusCode = response.getStatusLine().getStatusCode();
            logger.debug("statusCode: {}", statusCode);

            // Read the response body.
            try (BufferedReader buffer = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))) {
                responseBody = buffer.lines().collect(Collectors.joining(" "));
                logger.debug("response body: {}", responseBody);
            }

            if (!isHttpSuccess(statusCode)) {
                String errorDescription = null;
                if (isDistribute) {
                    errorDescription = "Error sending document to lender at: " + destUrl + ". Response code is " + statusCode;
                    logger.error(errorDescription);
                    
                    // Call withdraw process only for CDK
                    if (validationUtil.isCDKDeal(deDeal.getDmsId())) {
                        if (!isRouteOne) {
                            logger.debug("HTTP Failure to lender, trying to call withdraw process for CDK");
                            callWithDrawProcess(deDeal, vaultDocId);
                        } else {
                            logger.debug("RouteOne transaction, not calling withdraw process");
                        }
                    } else {
                        if (!isRouteOne) { 
                            logger.debug("HTTP Failure to lender, Bypassing withdraw process for non CDK deal"); 
                        }
                        // For RR, just update the distribution status and proceed
                        deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_LENDER_FAILURE);
                        deDeal.setDistributionTs(new Date());
                        dealService.saveOrUpdate(deDeal);
                    }
                } else {
                    errorDescription = "Error sending Spot ReCV request to lender at: " + destUrl + ". Response code is " + statusCode;
                    logger.error(errorDescription);
                }
                
                ApplicationException ae = new ApplicationException(lenderId, errorDescription, AppConstants.DISTRIBUTION_LENDER_FAILURE_STATUS_ERROR_CODE);
                ae.setErrorDetail(errorDetail);
                throw ae;
            } else {
                if (isDistribute) logger.debug("Successfully sent distribution to lender.");
                else logger.debug("Successfully sent Spot ReCv to lender.");
            }
        } catch (Exception e) {
            logger.error("Error sending transaction to lender at: {}", destUrl, e);
            ApplicationException ae = new ApplicationException(AppConstants.DISTRIBUTE_LENDER_FAILURE, AppConstants.DISTRIBUTE_FAILURE_CODE, e);
            ae.setErrorDetail(errorDetail);
            throw ae;
        }

        logger.debug("Exited sendToLenderWithTwoWaySSL method");

        return responseBody;
    }

    /**
     * @param lenderDest
     * @return
     */
    public List<Header> buildHeaders(final DeLenderDestination lenderDest) {
        // START Build Headers
        final List<Header> headers = new ArrayList<Header>();
        List<Header> authHeaders = null;
        final String authType = lenderDest.getWs_auth_type();
        if (null != authType && !authType.isEmpty()) {
            if (authType.equalsIgnoreCase("CookieAuth") || authType.equalsIgnoreCase("LDAP")) {

                authHeaders = new ArrayList<Header>();
                String auth = lenderDest.getWs_username();
                String cookie = lenderDest.getWs_password();
                String base64LdapAuth = new String(Base64.encodeBase64(auth.getBytes()));
                authHeaders.add(new Header("Authorization", "Basic " + base64LdapAuth));
                authHeaders.add(new Header("Cookie", cookie));
            } else if (authType.equalsIgnoreCase("HTTP")) {
                authHeaders = new ArrayList<Header>();
                String auth = lenderDest.getWs_username() + ":" + lenderDest.getWs_password();
                String base64LdapAuth = new String(Base64.encodeBase64(auth.getBytes()));
                authHeaders.add(new Header("Authorization", "Basic " + base64LdapAuth));
            }
        }
        if (null != authHeaders) {
            headers.addAll(authHeaders);
        }

        List<Header> contentTypeHeaders = null;
        final String contentType = lenderDest.getWs_content_type();
        if (null != contentType && !contentType.isEmpty()) {
            contentTypeHeaders = new ArrayList<Header>();
            contentTypeHeaders.add(new Header("Content-type", contentType));
        }
        if (null != contentTypeHeaders) {
            headers.addAll(contentTypeHeaders);
        }

        List<Header> soapActionHeaders = null;
        String soapAction = lenderDest.getWs_soap_action();
        if (null != soapAction && !soapAction.isEmpty()) {
            soapActionHeaders = new ArrayList<Header>();
            soapActionHeaders.add(new Header("SOAPAction", soapAction));
        }
        if (null != soapActionHeaders) {
            headers.addAll(soapActionHeaders);
        }
        // END Build Headers
        return headers;
    }

    /**
     * @param statusCode
     * @return
     */
    private boolean isHttpSuccess(int statusCode) {
        logger.debug("Entered isHttpSuccess(int statusCode) method");
        if (Arrays.asList(AppConstants.HTTP_SUCCESS_CODES).contains(new Integer(statusCode).toString())) {
            return true;
        }
        return false;
    }

    /**
     * @param deDeal
     * @param vaultId
     * @throws Exception
     */
    public void callWithDrawProcess(final DeDeal deDeal, final String vaultId) throws Exception {

        logger.debug("Enter callWithDrawProcess >> dmsDealId: {}, deDealId: {}, vaultDocumentId: {}", deDeal.getDmsDealNum(), deDeal.getDealId(), vaultId);

        Date timestamp = new Date();
        if (vaultId != null && !"".equals(vaultId)) {
            logger.debug("Calling VaultWS withdrawDocument operation with vault document id > {}", vaultId);
            String withDrawResponse = servicesUtil.withdrawDocument(vaultId, deDeal);
            if (AppConstants.VAULT_WITHDRAW_RESPONSE_SUCCESS.equals(withDrawResponse)) {
                deDeal.setEconStatus(AppConstants.ACTIVE_STATUS);
            } else {
                deDeal.setEconStatus(AppConstants.WITHDRAW_FAILED);
            }
        } else {
            logger.debug("No Vault document id received, *not* calling VaultWS withdraw operation");
            deDeal.setEconStatus(AppConstants.WITHDRAW_FAILED);
        }
        deDeal.setFundingStatus(AppConstants.DISTRIBUTION_FAILED);
        deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_LENDER_FAILURE);
        deDeal.setDistributionTs(timestamp);
        deDeal.setEconStatusTs(timestamp);
        deDeal.setFundingStatusTs(timestamp);
        dealService.saveOrUpdate(deDeal);

        logger.debug("Exit callWithDrawProcess()");

    }

}
