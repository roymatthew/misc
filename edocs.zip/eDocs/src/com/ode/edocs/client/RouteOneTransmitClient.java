package com.ode.edocs.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.xml.sax.InputSource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DePartnerDestination;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.rest.entity.RouteOneHeaderRequest;
import com.ode.edocs.rest.entity.RouteOneHeaderResponse;
import com.ode.edocs.rest.entity.RouteOneErrorResponse;
import com.ode.edocs.service.IDealService;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.HttpTransmitUtil;

@Component
public class RouteOneTransmitClient {

	private static final Logger logger = LogManager.getLogger(RouteOneTransmitClient.class);
	
	@Autowired
	HttpTransmitExecutor httpTransmitExecutor;
	
	@Autowired
	private IDealService dealService;
	
	@Value("${r1DealerId}")
	private String r1DealerId;
	
	@Value("${commonServiceURL}")
	private String commonServiceUrl;
	
	private List<HttpMessageConverter<?>> messageConverters;
	
	private RestTemplate restTemplate;
	
	public RouteOneTransmitClient() {
		super();
		messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate = new RestTemplate(messageConverters);
	}
	
	public String postWithHMACAuth(String content, DeDeal deDeal, DePartnerDestination dePartnerDestination, Map<String, String> input, ErrorDetail errorDetail) throws ApplicationException {
		logger.debug(dePartnerDestination);
		
		String routeOneURL = "";
		int statusCode = 0;
		HttpPost post = null;
		String responseBody = "";
		String detailedErrorMessage = "";
		try {
			// The R1 end point for initial/ trailing distribution is different. Consider the distribution as initial, if the funding status is not "Held"
			boolean isInitial = !AppConstants.FUNDING_STATUS_HELD.equalsIgnoreCase(deDeal.getFundingStatus());
			logger.info("isInitial : {}", isInitial);
			routeOneURL = HttpTransmitUtil.getFinalRouteOneURL(dePartnerDestination.getDestinationUrl(), input.get("contractID"), isInitial);
			post = new HttpPost(routeOneURL);
			StringEntity data = new StringEntity(content);
			post.setEntity(data);
			
			// Get HMAC Headers from CommonService
			String url = commonServiceUrl + "/routeoneHMACHeaders";
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			
			ParameterizedTypeReference<RouteOneHeaderResponse> typeRef = new ParameterizedTypeReference<RouteOneHeaderResponse>() {};
			
			// Request
			RouteOneHeaderRequest request = new RouteOneHeaderRequest();
			request.setXml(content);
			request.setURL(post.getURI().getPath());
			request.setDealerId(deDeal.getDmsDealerId());
			request.setPartnerId(deDeal.getLenderId());
			request.setDealerProductId("DC");
			request.setPartnerProductId("eDoc");
			request.setDmsId(deDeal.getDmsId());
			request.setAuthorizationId(input.get("authorizationId"));
			request.setVerb(post.getMethod());
			logger.debug("Getting HMAC headers from CommonService at: " + url);
			
			ResponseEntity<RouteOneHeaderResponse> responseEntity = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(request), typeRef);
			RouteOneHeaderResponse response = responseEntity.getBody();
			Map<String, String> hmacHeaders = response.getHeaders();
			
			logger.debug(">>>>> Received headers, Adding HMAC Headers to RouteOne request and sending ..");
			if (hmacHeaders.isEmpty()) {
				logger.debug("No headers received from Commons Service");
			}
			Set entrySet = hmacHeaders.entrySet();
			Iterator it = entrySet.iterator();
			String key = null;
			String value = null;
			while(it.hasNext()) {
				Map.Entry entry = (Map.Entry) it.next();
				key = (String) entry.getKey();
				value = (String) entry.getValue();
				logger.debug("--> " + key + " : " + value);
				post.addHeader(new BasicHeader(key, value));
			}
			
			HttpResponse httpResponse = httpTransmitExecutor.executePost(post);
			
			logger.debug(">>>>> RouteOne Distribution Post Response <<<<<");
			
			statusCode = httpResponse.getStatusLine().getStatusCode();
			logger.debug("StatusCode: {}", statusCode);
			
			try (BufferedReader buffer = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()))) {
				responseBody = buffer.lines().collect(Collectors.joining(" "));
				
				logger.debug("Response body: {}", responseBody);
			}
			
			if (!isHttpSuccess(statusCode)) {
				logger.error("HTTP Error in sending document to lender at: {}, with status: {}", routeOneURL, statusCode);
				
				deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_LENDER_FAILURE);
				deDeal.setDistributionTs(new Date());
				dealService.saveOrUpdate(deDeal);
				
				try {
					String messageType = getMsgType(responseBody);
					if ("JSON".equalsIgnoreCase(messageType)) {
						Gson gson = new Gson();
						RouteOneErrorResponse errorResponseJSONObject = gson.fromJson(responseBody,
								RouteOneErrorResponse.class);
						detailedErrorMessage = errorResponseJSONObject.getErrorMessage()
								+ errorResponseJSONObject.getDeveloperMessage();
					} else if ("XML".equalsIgnoreCase(messageType)) {
						int indexOfErrorMessage = responseBody.indexOf("<errorMessage>");
						int indexOfDeveloperMessage = responseBody.indexOf("<developerMessage>");
						if (-1 != indexOfErrorMessage) {
							detailedErrorMessage = responseBody.substring(indexOfErrorMessage + 14, responseBody.indexOf("</errorMessage>"));
						}
						if (-1 != indexOfDeveloperMessage) {
							if (!detailedErrorMessage.isEmpty()) {
								detailedErrorMessage = detailedErrorMessage + ", " + responseBody.substring(indexOfDeveloperMessage + 18, responseBody.indexOf("</developerMessage>"));
							} else {
								detailedErrorMessage = responseBody.substring(indexOfDeveloperMessage + 18, responseBody.indexOf("</developerMessage>"));
							}
						}
					}
				} catch (Exception e) {
					logger.debug("Error determining the msgType", e);
				}
				
				ApplicationException ae = new ApplicationException(input.get("lenderId"), "Error sending document to RouteOne", AppConstants.DISTRIBUTE_FAILURE_CODE);
				ae.setErrorDetail(errorDetail);
				throw ae;
			}
			logger.debug("RouteOne transaction is SUCCESS");
		} catch (Exception e) {
			logger.error("Error sending document to lender at: {}", routeOneURL, e);
			ApplicationException ae = new ApplicationException("Error sending document to lender at:" + routeOneURL + ", lender response code is: " + statusCode + ", R1 Response: [" + detailedErrorMessage + "]", AppConstants.DISTRIBUTE_FAILURE_CODE, e);
			ae.setErrorDetail(errorDetail);
			throw ae;
		} finally {
			try {
				if (post != null) {
					post.releaseConnection();
				}
			} catch (Exception e) {
				logger.error("Error releasing PostMethod connection.", e);
			}
		}
		return responseBody;
	}
	
	private boolean isHttpSuccess(int statusCode) {
		if (Arrays.asList(AppConstants.HTTP_SUCCESS_CODES).contains(new Integer(statusCode).toString())) {
			return true;
		}
		return false;
	}
	
	public String getMsgType(String message) {
	    try {
	        new ObjectMapper().readTree(message);
	        logger.info("Message is valid JSON.");
	        return "JSON";
	    } catch (IOException e) {
	        logger.info("Message is not valid JSON.");
	    }

	    try {
	        DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(message)));
	        logger.info("Message is valid XML.");
	        return "XML";
	    } catch (Exception e) {
	        logger.info("Message is not valid XML.");
	    }

	    return null;
	}
}