package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.AuditJournal;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class AuditJournalDAO {
    private static final Logger logger = LogManager.getLogger(AuditJournalDAO.class);

    @Autowired
    private SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public AuditJournal saveOrUpdate(AuditJournal auditJournal) throws Exception {
        logger.debug("Entered saveOrUpdate(AuditJournal auditJournal) method");
        getCurrentSession().saveOrUpdate(auditJournal);
        return auditJournal;
    }
}
