package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.CreditJournal;
import java.math.BigInteger;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class CreditJournalDAO {

    private static final Logger logger = LogManager.getLogger(CreditJournalDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public BigInteger saveOrUpdate(CreditJournal creditJournal) throws Exception {
        logger.debug("Entered saveOrUpdate(CreditJournal creditJournal) method");
        BigInteger cjKey = null;
        Object o = getCurrentSession().save(creditJournal);
        if(o instanceof BigInteger){
            cjKey = (BigInteger) o;
            logger.debug("cjKey is:{}", cjKey);
        }

        return cjKey;
    }

    public void saveOrUpdateRecord(CreditJournal creditJournal) throws Exception {
        logger.debug("Entered saveOrUpdateRecord(CreditJournal creditJournal) method");
        getCurrentSession().saveOrUpdate(creditJournal);

    }

    @SuppressWarnings("unchecked")
    public CreditJournal findLatestAccr(String dmsDealNo, String transType, String dealerId, String partnerId) throws Exception {
        logger.debug("Entered findLatestAccr(String dmsDealNo, String transType, String dealerId, String partnerId) method");
        List<CreditJournal> records = null;
        CreditJournal cj = null;
        Criteria cr = getCurrentSession().createCriteria(CreditJournal.class);
        cr.add(Restrictions.eq("adpDealNumber", dmsDealNo));
        cr.add(Restrictions.eq("transType", transType));
        cr.add(Restrictions.eq("dealerId", dealerId));
        cr.add(Restrictions.eq("partnerId", partnerId));
        cr.add(Restrictions.ne("sequenceNumber", ""));
        cr.addOrder(Order.desc("transDateTime"));
        records = cr.list();
        if(records!=null && !records.isEmpty()){
            cj = records.get(0);
        }
        return cj;
    }

    @SuppressWarnings("unchecked")
    public CreditJournal findMostRecentByTransactionId(String transactionId, String dealerId, String partnerId, String[] transTypes ) throws Exception {
        logger.debug("Entered findMostRecentByTransactionId(String transactionId, String dealerId, String partnerId, String[] transTypes )method");
        List<CreditJournal> records = null;
        CreditJournal cj = null;
        Criteria cr = getCurrentSession().createCriteria(CreditJournal.class);
        cr.add(Restrictions.eq("transactionId", transactionId));
        cr.add(Restrictions.in("transType", transTypes));
        cr.add(Restrictions.eq("dealerId", dealerId));
        cr.add(Restrictions.eq("partnerId", partnerId));
        cr.addOrder(Order.desc("transDateTime"));
        records = cr.list();
        if(records!=null && !records.isEmpty()){
            cj = records.get(0);
        }
        return cj;
    }

    @SuppressWarnings("unchecked")
    public CreditJournal findByDeDealIdAndSequenceId(String deDealId, String sequenceId, String dealerId, String transType) throws Exception {
        logger.debug("Entered findByDeDealIdAndSequenceId method. DeDealId: {}, SequenceId:{}, DealerId:{}, TransType: {}", deDealId, sequenceId, dealerId, transType);
        List<CreditJournal> records = null;
        CreditJournal cj = null;
        Criteria cr = getCurrentSession().createCriteria(CreditJournal.class);
        cr.add(Restrictions.eq("dealId", deDealId));
        cr.add(Restrictions.eq("sequenceId", sequenceId));
        cr.add(Restrictions.eq("dealerId", dealerId));
        cr.add(Restrictions.eq("transType", transType));
        cr.addOrder(Order.desc("transDateTime"));
        records = cr.list();
        if(records!=null && !records.isEmpty()){
            cj = records.get(0);
            logger.debug(cj.toString());
        }
        return cj;
    }

    public CreditJournal findCreditJournalByCjKey(BigInteger cjKey, String transType) throws Exception {
        logger.debug("Entered findCreditJournalByCjKey(BigInteger cjKey, String transType)  method");
        CreditJournal cj = null;
        Criteria cr = getCurrentSession().createCriteria(CreditJournal.class);
        cr.add(Restrictions.eq("cjKey", cjKey));
        cr.add(Restrictions.eq("transType", transType));
        cj = (CreditJournal)cr.uniqueResult();
        return cj;
    }

    public void deleteCreditJournal(final BigInteger creditJournalKey) {
        logger.debug("Entered deleteCreditJournal()");
        CreditJournal creditJournal = null;
        Criteria cr = getCurrentSession().createCriteria(CreditJournal.class);
        cr.add(Restrictions.eq("cjKey", creditJournalKey));
        creditJournal = (CreditJournal) cr.uniqueResult();
        getCurrentSession().delete(creditJournal);
        getCurrentSession().flush();

    }

    @SuppressWarnings("unchecked")
    public CreditJournal findMostRecentByDeDealId(String deDealId, String dealerId, String partnerId,
        String[] transTypes) throws Exception {
        logger.entry(deDealId, transTypes);

        List<CreditJournal> records = null;
        CreditJournal cj = null;
        Criteria cr = getCurrentSession().createCriteria(CreditJournal.class);
        cr.add(Restrictions.eq("dealId", deDealId));
        cr.add(Restrictions.eq("dealerId", dealerId));
        cr.add(Restrictions.eq("partnerId", partnerId));
        cr.add(Restrictions.in("transType", transTypes));
        cr.addOrder(Order.desc("transDateTime"));
        records = cr.list();
        if (records != null && !records.isEmpty()) {
            cj = records.get(0);
        }
        return logger.exit(cj);
    }
}