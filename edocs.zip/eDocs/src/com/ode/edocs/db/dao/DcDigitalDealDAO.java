package com.ode.edocs.db.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DcDigitalDeal;

@Component
@Transactional
public class DcDigitalDealDAO {
	
	private static final Logger logger = LogManager.getLogger(DcDigitalDealDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public void saveOrUpdate(DcDigitalDeal DcDigitalDeal) {
		logger.debug("Entered saveOrUpdate(DcDigitalDeal DcDigitalDeal) method");
		getCurrentSession().saveOrUpdate(DcDigitalDeal);
		//
	}
	
	public DcDigitalDeal getDcDigitalDeal(String dealerId, String partnerId, String sequenceNo) throws Exception {
		logger.debug("Entered getDcDigitalDeal(String dealerId, String partnerId, String sequenceNo)  method");
		DcDigitalDeal dcDigitalDeal = null;
		Criteria cr = getCurrentSession().createCriteria(DcDigitalDeal.class);
		cr.add(Restrictions.eq("partnerId", partnerId));
		cr.add(Restrictions.eq("sequenceNo", sequenceNo));
		cr.add(Restrictions.eq("dealerId", dealerId));
		dcDigitalDeal = (DcDigitalDeal) cr.uniqueResult();
		
		return dcDigitalDeal;
	}
}