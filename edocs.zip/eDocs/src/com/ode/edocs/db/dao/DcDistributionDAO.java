package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DcDistribution;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DcDistributionDAO {

    private static final Logger logger = LogManager.getLogger(DcDistributionDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public DcDistribution.DcDistributionId save(DcDistribution dcDistribution) throws Exception {
        logger.debug("Entered  save(DcDistribution dcDistribution) method");
        DcDistribution.DcDistributionId id = null;
        Object o = getCurrentSession().save(dcDistribution);
        if(o instanceof DcDistribution.DcDistributionId){
            id = (DcDistribution.DcDistributionId) o;
            logger.debug("id is:{}", id);
        }
        return id;
    }

    public void saveOrUpdate(DcDistribution dcDistribution) throws Exception {
        logger.debug("Entered saveOrUpdate(DcDistribution dcDistribution)  method");
        getCurrentSession().saveOrUpdate(dcDistribution);

    }

    @SuppressWarnings("unchecked")
    public List<DcDistribution> find(String deDealId) throws Exception {
        logger.debug("Entered find(String deDealId)method");
        List<DcDistribution> records = null;
        try {
            Criteria cr = getCurrentSession().createCriteria(DcDistribution.class);
            cr.add(Restrictions.eq("id.dealId", deDealId));
            cr.addOrder(Order.desc("createdByTs"));
            records = cr.list();
        } catch(Exception e) {
            logger.error("Error retrieving DcDistribution records from DB. ", e);
            throw e;
        }
        return records;
    }

    public DcDistribution find(String deDealId, String sequenceId) throws Exception {
        logger.debug("Entered find(String deDealId, String sequenceId) method");
        DcDistribution record = null;
        try {
            Criteria cr = getCurrentSession().createCriteria(DcDistribution.class);
            cr.add(Restrictions.eq("id.dealId", deDealId));
            cr.add(Restrictions.eq("id.sequenceId", sequenceId));
            record = (DcDistribution) cr.uniqueResult();
        } catch(Exception e) {
            logger.error("Error retrieving DcDistribution record from DB. ", e);
            throw e;
        }
        return record;
    }
}