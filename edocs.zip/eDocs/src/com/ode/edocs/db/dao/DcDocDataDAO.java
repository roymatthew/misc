package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DcDocData;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DcDocDataDAO {

    private static final Logger logger = LogManager.getLogger(DcDocDataDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public DcDocData save(DcDocData dcDocData) throws Exception {
        logger.debug("Entered save(DcDocData dcDocData) method");
        Object o = getCurrentSession().save(dcDocData);
        if(o instanceof Integer){
            Integer pk = (Integer) o;
            dcDocData.setDcDocDataId(pk);
        }
        return dcDocData;
    }

    public void saveOrUpdate(DcDocData dcDocData) throws Exception {
        logger.debug("Entered saveOrUpdate(DcDocData dcDocData) method");
        getCurrentSession().saveOrUpdate(dcDocData);
        
    }

    @SuppressWarnings("unchecked")
    public List<DcDocData> findDataByDcDocumentId(Integer dcDocumentId) {
        logger.debug("Entered findDataByDcDocumentId(Integer dcDocumentId) method");
        List<DcDocData> data = null;
        Criteria cr = getCurrentSession().createCriteria(DcDocData.class);
        cr.add(Restrictions.eq("dcDocumentId", dcDocumentId));
        data = cr.list();

        return data;
    }
}