package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DcDocField;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DcDocFieldDAO {

    private static final Logger logger = LogManager.getLogger(DcDocFieldDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public void saveOrUpdate(DcDocField dcDocField) throws Exception {
        logger.debug("Entered saveOrUpdate(DcDocField dcDocField) method");
        getCurrentSession().saveOrUpdate(dcDocField);
        
    }

    @SuppressWarnings("unchecked")
    public List<DcDocField> findByDcDocTypeId(Integer dcDocTypeId) throws Exception {
        logger.debug("Entered findByDcDocTypeId(Integer dcDocTypeId)  method");
        List<DcDocField> fields = null;
        Criteria cr = getCurrentSession().createCriteria(DcDocField.class);
        cr.add(Restrictions.eq("dcDocTypeId", dcDocTypeId));
        fields = cr.list();

        return fields;
    }

    @SuppressWarnings("unchecked")
    public List<DcDocField> findByDmsDocTypeId(Integer dmsDocTypeId) throws Exception {
        logger.debug("Entered findByDmsDocTypeId(Integer dmsDocTypeId) method");
        List<DcDocField> fields = null;
        Criteria cr = getCurrentSession().createCriteria(DcDocField.class);
        cr.add(Restrictions.eq("dmsDocTypeId", dmsDocTypeId));
        fields = cr.list();

        return fields;
    }

    @SuppressWarnings("unchecked")
    public List<DcDocField> findByDmsDocTypeIdAndSection(Integer dmsDocTypeId, String section) throws Exception {
        List<DcDocField> fields = null;
        Criteria cr = getCurrentSession().createCriteria(DcDocField.class);
        cr.add(Restrictions.eq("dmsDocTypeId", dmsDocTypeId));
        cr.add(Restrictions.eq("section", section));
        fields = cr.list();

        return fields;
    }
}