package com.ode.edocs.db.dao;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.service.IDcDocumentBatchDAOService;

@Component
public class DcDocumentBatchDAO implements IDcDocumentBatchDAO{

	private static final Logger logger = LogManager.getLogger(DcDocumentBatchDAO.class);

	@Autowired
	public SessionFactory sessionFactory;

	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@Transactional
	@Override
	public void doBatchInsertDocData(final File file) {

		logger.debug("Entered doBatchInsertDocData() for file: " + file.getFormattedFileName());

		final LocalDateTime start = LocalDateTime.now();

		int count = 0;

		Session session = getCurrentSession();

		for (final DcDocData docData : file.getDocData()) {
			count++;
			session.save(docData);

			if (count % 20 == 0) {
				session.flush();
				session.clear();
			}
		}

		final LocalDateTime end = LocalDateTime.now();

		logger.debug("Added " + file.getDocData().size() + " DcDocData records for " + file.getFormattedFileName()
				+ " in " + ChronoUnit.SECONDS.between(start, end) + " seconds");

	}

}