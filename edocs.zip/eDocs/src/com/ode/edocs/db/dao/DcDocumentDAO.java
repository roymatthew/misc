package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DcDocument;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DcDocumentDAO {

    private static final Logger logger = LogManager.getLogger(DcDocumentDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public DcDocument save(DcDocument dcDocument) throws Exception {
        logger.debug(dcDocument);


        Object o = getCurrentSession().save(dcDocument);
        if(o instanceof Integer){
            Integer pk = (Integer) o;
            dcDocument.setId(pk);
        }

        return dcDocument;
    }

    public DcDocument saveOrUpdate(DcDocument dcDocument) throws Exception {
        logger.debug(dcDocument);
        getCurrentSession().saveOrUpdate(dcDocument);
        return dcDocument;
    }

    @SuppressWarnings("unchecked")
    public DcDocument getDcDocument(String dealId, String docName) throws Exception {
        logger.debug(dealId, docName);

        List<DcDocument> records = null;
        DcDocument dcDocument = null;

        Criteria cr = getCurrentSession().createCriteria(DcDocument.class);
        cr.add(Restrictions.eq("dealId", dealId));
        cr.add(Restrictions.eq("lenderDocName", docName));
        cr.addOrder(Order.desc("createdBy"));
        records = cr.list();
        if(records!=null && !records.isEmpty()){
            dcDocument = records.get(0);
        }

        return dcDocument;
    }

    public DcDocument getDcDocument(String dealId, String sequenceId, String docName) throws Exception {
        logger.debug(dealId, sequenceId, docName);

        DcDocument dcDocument = null;

        Criteria cr = getCurrentSession().createCriteria(DcDocument.class);
        cr.add(Restrictions.eq("dealId", dealId));
        cr.add(Restrictions.eq("sequenceId", sequenceId));
        cr.add(Restrictions.eq("dmsDocName", docName));
        dcDocument = (DcDocument) cr.uniqueResult();

        return dcDocument;
    }

    public DcDocument getDcDocument(Integer dcDocumentId) throws Exception {
        logger.debug(dcDocumentId);

        DcDocument dcDocument = null;

        Criteria cr = getCurrentSession().createCriteria(DcDocument.class);
        cr.add(Restrictions.eq("id", dcDocumentId));
        dcDocument = (DcDocument) cr.uniqueResult();

        return dcDocument;
    }

    @SuppressWarnings("unchecked")
    public List<DcDocument> getDcDocumentList(String dealId, String sequenceId) throws Exception {
        logger.debug(dealId, sequenceId);

        List<DcDocument> documents = null;

        try {
            Criteria cr = getCurrentSession().createCriteria(DcDocument.class);
            cr.add(Restrictions.eq("dealId", dealId));
            cr.add(Restrictions.eq("sequenceId", sequenceId));
            documents = cr.list();
        } catch(Exception e) {
            logger.error("Error retrieving DcDocument records from DB. ", e);
            throw e;
        }
        return documents;
    }
}