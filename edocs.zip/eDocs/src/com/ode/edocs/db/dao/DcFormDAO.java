package com.ode.edocs.db.dao;

import java.math.BigInteger;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DcForm;

@Component
@Transactional
public class DcFormDAO {

	private static final Logger logger = LogManager.getLogger(DcFormDAO.class);

	@Autowired
	public SessionFactory sessionFactory;

	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public BigInteger saveOrUpdate(DcForm dcForm) throws Exception {
		logger.debug(dcForm);

		if (dcForm == null) {
			return null;
		}
		BigInteger id = null;

		if (dcForm.getDcFormId() != null) {
			id = dcForm.getDcFormId();
			getCurrentSession().saveOrUpdate(dcForm);
		} else {
			Object o = getCurrentSession().save(dcForm);
			if (o instanceof BigInteger) {
				id = (BigInteger) o;
			}
		}
		return id;
	}

	@SuppressWarnings("unchecked")
	public List<DcForm> findOutstandingForms(String deDealId, String formName) throws Exception {
		logger.debug(deDealId, formName);

		List<DcForm> records = null;
		Criteria cr = getCurrentSession().createCriteria(DcForm.class);
		cr.add(Restrictions.eq("deDealId", deDealId));
		cr.add(Restrictions.eq("formName", formName));
		cr.add(Restrictions.isNull("transferredDate"));
		cr.addOrder(Order.desc("createdTs"));
		records = cr.list();
		return records;
	}

	@SuppressWarnings("unchecked")
	public List<DcForm> findForms(String deDealId, String formName) throws Exception {
		logger.debug(deDealId);

		List<DcForm> records = null;
		Criteria cr = getCurrentSession().createCriteria(DcForm.class);
		cr.add(Restrictions.eq("deDealId", deDealId));
		cr.add(Restrictions.eq("formName", formName));
		cr.addOrder(Order.desc("createdTs"));
		records = cr.list();
		return records;
	}
}