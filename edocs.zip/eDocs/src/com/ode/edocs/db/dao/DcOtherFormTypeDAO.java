package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DcOtherFormType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component
@Transactional
public class DcOtherFormTypeDAO {
	
	private static final Logger logger = LogManager.getLogger(DcOtherFormTypeDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public void saveOrUpdate(DcOtherFormType dcOtherFormType) throws Exception {
		logger.debug("Entered saveOrUpdate(DcOtherFormType dcOtherFormType) method");
		getCurrentSession().saveOrUpdate(dcOtherFormType);
	}

	public List<DcOtherFormType> getDcOtherFormTypesByDeDealId(String deDealId) {
		logger.debug("Entered getDcOtherFormTypesByDeDealId({}) method in DcOtherFormTypeDAO", deDealId);
		List<DcOtherFormType> dcOtherFormTypes = new ArrayList<>();

		try {
			Criteria cr = getCurrentSession().createCriteria(DcOtherFormType.class);
			cr.add(Restrictions.eq("deDealId", deDealId));
			cr.addOrder(Order.desc("createdTs"));
			dcOtherFormTypes = cr.list();
		} catch (Exception e) {
			logger.error("Error retrieving DcOtherFormType records from DB. ", e);
		}
		return dcOtherFormTypes;
	}
}