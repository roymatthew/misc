package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DeContractValidation;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DeContractValidationDAO {
    private static final Logger logger = LogManager.getLogger(DeContractValidationDAO.class);

    @Autowired
    private SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    @SuppressWarnings("unchecked")
    public DeContractValidation findMostRecentWithStatus(String deDealId, String[] statuses) throws Exception {
        logger.debug(deDealId, Arrays.toString(statuses));

        List<DeContractValidation> records = null;
        DeContractValidation record = null;
        try {
            Criteria cr = getCurrentSession().createCriteria(DeContractValidation.class);
            cr.add(Restrictions.eq("id.dealId", deDealId));
            cr.add(Restrictions.in("status", statuses));
            cr.addOrder(Order.desc("id.sequenceId"));
            records = cr.list();
            if (null != records && !records.isEmpty()) {
                record = records.get(0);
            }
        } catch (Exception e) {
            logger.error("Error retrieving DeContractValidation record from DB. ", e);
        }
        return record;
    }

    @SuppressWarnings("unchecked")
    public DeContractValidation findMostRecentWithStatusAndLenderSequenceNumber(String deDealId, String[] statuses,
        String sequenceNumber) throws Exception {
        logger.debug(deDealId, Arrays.toString(statuses));

        List<DeContractValidation> records = null;
        DeContractValidation record = null;
        try {
            Criteria cr = getCurrentSession().createCriteria(DeContractValidation.class);
            cr.add(Restrictions.eq("id.dealId", deDealId));
            cr.add(Restrictions.eq("lenderSeqNum", sequenceNumber));
            cr.add(Restrictions.in("status", statuses));
            cr.addOrder(Order.desc("id.sequenceId"));
            records = cr.list();
            if (null != records && !records.isEmpty()) {
                record = records.get(0);
            }
        } catch (Exception e) {
            logger.error("Error retrieving DeContractValidation record from DB. ", e);
        }
        return record;
    }

    @SuppressWarnings("unchecked")
    public DeContractValidation findMostRecent(String deDealId) throws Exception {
        logger.debug(deDealId);

        List<DeContractValidation> records = null;
        DeContractValidation record = null;
        try {
            Criteria cr = getCurrentSession().createCriteria(DeContractValidation.class);
            cr.add(Restrictions.eq("id.dealId", deDealId));
            cr.addOrder(Order.desc("id.sequenceId"));
            records = cr.list();
            if (null != records && !records.isEmpty()) {
                record = records.get(0);
            }
        } catch (Exception e) {
            logger.error("Error retrieving DeContractValidation record from DB. ", e);
        }
        return record;
    }

    @SuppressWarnings("unchecked")
    public DeContractValidation findWithSequenceId(String deDealId, String sequenceId) {
        logger.debug(deDealId, sequenceId);

        DeContractValidation record = null;
        try {
            Criteria cr = getCurrentSession().createCriteria(DeContractValidation.class);
            cr.add(Restrictions.eq("id.dealId", deDealId));
            cr.add(Restrictions.eq("id.sequenceId", sequenceId));
            record = (DeContractValidation) cr.uniqueResult();
        } catch (Exception e) {
            logger.error("Error retrieving DeContractValidation record from DB. ", e);
        }
        return record;
    }
}
