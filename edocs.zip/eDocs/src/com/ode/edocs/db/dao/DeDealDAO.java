package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DeDeal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DeDealDAO {

    private static final Logger logger = LogManager.getLogger(DeDealDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public void saveOrUpdate(DeDeal deDeal) throws Exception {
        logger.debug(deDeal);
        final Timestamp now = new Timestamp(new Date().getTime());
        deDeal.setLastModifiedTs(now);
        getCurrentSession().saveOrUpdate(deDeal);
        //
    }

    /**
     * @param deal
     * @param recordState
     * @param modifiedUser
     * @throws Exception
     */
    public void updateRecordState(final DeDeal deal, final String latestDistributionStatus, final String recordState, final String modifiedUser)
        throws Exception {

        logger.debug("Enter updateRecordState");
        final Timestamp now = new Timestamp(new Date().getTime());
		if (null != latestDistributionStatus) {
			deal.setLatestDistributionStatus(latestDistributionStatus);
		}
        deal.setLastModifiedTs(now);
        deal.setRecordState(recordState);
        deal.setModifiedBy(modifiedUser);
        deal.setModifiedTimestamp(now);
        getCurrentSession().saveOrUpdate(deal);
        getCurrentSession().flush();
        logger.debug("Exit updateRecordState");
    }

    public DeDeal find(String dmsDealerId, String dmsDealNum, String lenderId) throws Exception {
        logger.debug(dmsDealerId, dmsDealNum, lenderId);

        DeDeal deal = null;
        Criteria cr = getCurrentSession().createCriteria(DeDeal.class);
        cr.add(Restrictions.eq("dmsDealerId", dmsDealerId));
        cr.add(Restrictions.eq("dmsDealNum", dmsDealNum));
        cr.add(Restrictions.eq("lenderId", lenderId));
        deal = (DeDeal) cr.uniqueResult();

        return deal;
    }
    
    @SuppressWarnings("unchecked")
	public DeDeal findDeals(String dmsDealerId, String dmsDealNum, List<String> lenderIds) throws Exception {
        logger.debug(dmsDealerId, dmsDealNum, lenderIds);

        List<DeDeal> deals = null;
        Criteria cr = getCurrentSession().createCriteria(DeDeal.class);
        cr.add(Restrictions.eq("dmsDealerId", dmsDealerId));
        cr.add(Restrictions.eq("dmsDealNum", dmsDealNum));
        cr.addOrder(Order.desc("lastModifiedTs"));
        cr.add(Restrictions.in("lenderId", lenderIds));
        deals = cr.list();
        return (deals != null && deals.size()>0) ? deals.get(0) : null;
    }

    public DeDeal getByDeDealId(final String deDealId) throws Exception {

        logger.debug("Enter getByDeDealId. deDealId" + deDealId);

        DeDeal deal = null;
        Criteria cr = getCurrentSession().createCriteria(DeDeal.class);
        cr.add(Restrictions.eq("dealId", deDealId));
        deal = (DeDeal) cr.uniqueResult();
        logger.debug("Exit getByDeDealId. deDealId" + deDealId);
        return deal;
    }

    public DeDeal getEconStatus(String vaultDocId, String dmsDealNum) throws Exception {
        logger.debug(vaultDocId, dmsDealNum);

        DeDeal deal = null;

        Criteria cr = getCurrentSession().createCriteria(DeDeal.class);
        cr.add(Restrictions.eq("vaultDocId", vaultDocId));
        cr.add(Restrictions.eq("dmsDealNum", dmsDealNum));
        deal = (DeDeal) cr.uniqueResult();
        return deal;
    }
}
