package com.ode.edocs.db.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.ode.edocs.db.entity.DeFaxService;

@Component
@Transactional
public class DeFaxServiceDAO {
	
private static final Logger logger = LogManager.getLogger(DeFaxServiceDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public DeFaxService getFaxNumber( String lenderId, String transactionType) throws Exception {
		logger.debug(lenderId, transactionType);
		
		DeFaxService deFaxService = null;
		Criteria cr = getCurrentSession().createCriteria(DeFaxService.class);
		cr.add(Restrictions.eq("lenderId", lenderId));
		cr.add(Restrictions.eq("transactionType", transactionType));
	
		deFaxService = (DeFaxService) cr.uniqueResult();
		
		return deFaxService;
	}

}
