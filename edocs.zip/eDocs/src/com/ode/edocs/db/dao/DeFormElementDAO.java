package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DeFormElement;
import com.ode.edocs.db.entity.FormElementEntity;
import com.ode.edocs.rest.entity.FormElementKey;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DeFormElementDAO {
    private static final Logger logger = LogManager.getLogger(DeFormElementDAO.class);

    @Autowired
    private SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    @SuppressWarnings("unchecked")
    public DeFormElement getDeFormElement(FormElementKey key) {
        logger.debug(key.getDcDocTypeId() + key.getLenderId() + key.getStateId());

        DeFormElement deFormElement = null;
        List<DeFormElement> deFormElements = null;
        Criteria cr = getCurrentSession().createCriteria(DeFormElement.class);
        cr.add(Restrictions.eq("dcDocTypeId", key.getDcDocTypeId()));
        deFormElements = cr.list();

        if (null != deFormElements && deFormElements.size() > 0) {
            deFormElement = deFormElements.stream()
                .filter(p -> p.getLenderId().equals(key.getLenderId()) && p.getStateId().equals(key.getStateId()))
                .findFirst().orElse(null);
            // If cannot find a match, lookup by lenderID from request and
            // stateID 'ALL'
            if (deFormElement == null) {
                deFormElement = deFormElements.stream()
                    .filter(p -> p.getLenderId().equals(key.getLenderId()) && "ALL".equals(p.getStateId())).findFirst()
                    .orElse(null);
                // If cannot find a match, lookup by lenderID 'ALL' and stateID
                // 'ALL'
                if (deFormElement == null) {
                    deFormElement = deFormElements.stream()
                        .filter(p -> "ALL".equals(p.getLenderId()) && "ALL".equals(p.getStateId())).findFirst()
                        .orElse(null);
                }
            }
        }
        if (deFormElement == null) {
            logger.debug("No DE_FORM_ELEMENT record found for DC Doc type id: {}, lender id: {}, state id: {}",
                key.getDcDocTypeId(), key.getLenderId(), key.getStateId());
            return null;
        } else {
            logger.debug(deFormElement.toString());
            return deFormElement;
        }
    }

    /**
     * @param key
     * @param docTypeIdList
     * @return
     */
    public List<DeFormElement> getDeFormElementsCollection(final FormElementKey key,
        final List<Integer> docTypeIdList) {

        logger.debug("Entered getDeFormElementsCollection() for lender: " + key.getLenderId() + "and state: "
            + key.getStateId());

        List<FormElementEntity> formElementEntityList = getFormElementEntityCollection(key, docTypeIdList);

        List<DeFormElement> deFormElements = null;
        Criteria cr = getCurrentSession().createCriteria(DeFormElement.class);
        Conjunction andConditions = Restrictions.conjunction();
        final Integer[] primaryKeyValues = new Integer[docTypeIdList.size()];
        int i = 0;
        for (FormElementEntity entity : formElementEntityList) {
            primaryKeyValues[i] = entity.getId();
            i++;
        }

        andConditions.add(Restrictions.in("id", primaryKeyValues));
        cr.add(andConditions);
        deFormElements = cr.list();
        logger.debug("Exit getDeFormElementsCollection()");
        return deFormElements;
    }

    /**
     * @param key
     * @param docTypeIdList
     * @return
     */
    public List<FormElementEntity> getFormElementEntityCollection(final FormElementKey key,
        final List<Integer> docTypeIdList) {

        logger.debug("Entered getFormElementEntityCollection() for lender: " + key.getLenderId() + "and state: "
            + key.getStateId());

        List<FormElementEntity> formElementEntityList = null;
        List<FormElementEntity> filteredList = new ArrayList<>();
        Criteria cr = getCurrentSession().createCriteria(FormElementEntity.class);
        Disjunction orConditions = Restrictions.disjunction();
        Conjunction andConditions = Restrictions.conjunction();
        final String[] lenderIdValues = { key.getLenderId(), "ALL" };
        final String[] stateIdValues = { key.getStateId(), "ALL" };
        final Integer[] docTypeIdValues = new Integer[docTypeIdList.size()];

        int i = 0;
        for (final Integer docTypeId : docTypeIdList) {
            logger.debug("Adding docTypeId: " + docTypeId + " to the query");
            docTypeIdValues[i] = docTypeId;
            i++;
        }

        andConditions.add(Restrictions.in("dcDocTypeId", docTypeIdValues));
        orConditions.add(Restrictions.in("lenderId", lenderIdValues));
        orConditions.add(Restrictions.in("stateId", stateIdValues));
        cr.add(andConditions);
        cr.add(orConditions);
        formElementEntityList = cr.list();

        FormElementEntity formElementEntity = null;

        if (null != formElementEntityList && !formElementEntityList.isEmpty()) {

            for (Integer docTypeId : docTypeIdList) {
                formElementEntity = formElementEntityList
                    .stream().filter(p -> p.getDcDocTypeId().equals(docTypeId)
                        && p.getLenderId().equals(key.getLenderId()) && p.getStateId().equals(key.getStateId()))
                    .findFirst().orElse(null);
                // If cannot find a match, lookup by lenderID from request and
                // stateID 'ALL'
                if (formElementEntity == null) {
                    formElementEntity = formElementEntityList.stream()
                        .filter(p -> p.getDcDocTypeId().equals(docTypeId) && p.getLenderId().equals(key.getLenderId())
                            && "ALL".equals(p.getStateId()))
                        .findFirst().orElse(null);
                    // If cannot find a match, lookup by lenderID 'ALL' and stateID
                    // 'ALL'
                    if (formElementEntity == null) {
                        formElementEntity = formElementEntityList.stream()
                            .filter(p -> p.getDcDocTypeId().equals(docTypeId) && "ALL".equals(p.getLenderId())
                                && "ALL".equals(p.getStateId()))
                            .findFirst().orElse(null);
                    }
                }

                if (formElementEntity != null) {
                    filteredList.add(formElementEntity);
                }
            }

        }
        logger.debug("Entered getFormElementEntityCollection()");
        return filteredList;
    }

}
