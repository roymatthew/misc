package com.ode.edocs.db.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.StringUtils;

import com.ode.edocs.db.entity.DeLenderDestination;

@Component
@Transactional
public class DeLenderDestinationDAO {
	
	private static final Logger logger = LogManager.getLogger(DeLenderDestinationDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public DeLenderDestination findByLenderId(String lenderId, String application) throws Exception {
	    logger.debug(lenderId);
     
		DeLenderDestination lenderDestination = null;
		Criteria cr = getCurrentSession().createCriteria(DeLenderDestination.class);
		cr.add(Restrictions.eq("de_lender_id", lenderId));
		cr.add(Restrictions.eq("application", application));
		lenderDestination = (DeLenderDestination) cr.uniqueResult();
		
		return lenderDestination;
	}

	public DeLenderDestination findByLenderIdAndProduct(String lenderId, String application, String  product) throws Exception {
	    logger.debug("LenderId: {}, Application: {}, Product: {}", lenderId, application, product);
     
		DeLenderDestination lenderDestination = null;
		Criteria cr = getCurrentSession().createCriteria(DeLenderDestination.class);
		cr.add(Restrictions.eq("de_lender_id", lenderId));
		cr.add(Restrictions.eq("application", application));
		if(StringUtils.isEmpty(product)){
			cr.add(Restrictions.isNull("product"));
		}else{
			cr.add(Restrictions.eq("product", product));
		}
		lenderDestination = (DeLenderDestination) cr.uniqueResult();
		if (lenderDestination == null) {
			logger.debug("No lender destination record found with given parameters");
		}
		return lenderDestination;
	}
}