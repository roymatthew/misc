package com.ode.edocs.db.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DeLenderFeature;

@Component
@Transactional
public class DeLenderFeatureDAO {
	
	private static final Logger logger = LogManager.getLogger(DeLenderFeatureDAO.class);

	@Autowired
	public SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings("unchecked")
	public List<DeLenderFeature> getFeaturesForLenderAndDms(String lenderId, List<String> dmsSearchList) throws Exception {
		logger.debug(lenderId + ", " + dmsSearchList);
		
		List<DeLenderFeature> features = null;		
		Criteria cr = getCurrentSession().createCriteria(DeLenderFeature.class);
		cr.add(Restrictions.eq("lenderId", lenderId));
        cr.add(Restrictions.in("dmsId", dmsSearchList));
        features = cr.list();

        return features;
	}
}
