package com.ode.edocs.db.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DeLenderPartner;

@Component
@Transactional
public class DeLenderPartnerDAO {
	private static final Logger logger = LogManager.getLogger(DeLenderPartnerDAO.class);
	
	@Autowired
	public SessionFactory sessionFactory; //private
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public DeLenderPartner getByPartnerId(String partnerId) throws Exception {
		logger.debug(partnerId);
		DeLenderPartner deLenderPartner = null;
		
		Criteria cr = getCurrentSession().createCriteria(DeLenderPartner.class);
		cr.add(Restrictions.eq("partnerId", partnerId));
		deLenderPartner = (DeLenderPartner) cr.uniqueResult();
		
		return deLenderPartner;
	}
	
	@SuppressWarnings("unchecked")

	public List<DeLenderPartner> getListByLenderId(String lenderId) throws Exception {

		logger.debug(lenderId);
		List<DeLenderPartner> deLenderPartner = null;
		
		Criteria cr = getCurrentSession().createCriteria(DeLenderPartner.class);
		cr.add(Restrictions.eq("lenderId", lenderId));
		deLenderPartner = cr.list();		
		return deLenderPartner;

	}
}
