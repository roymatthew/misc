package com.ode.edocs.db.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DeMaintenanceHistory;
import com.ode.edocs.util.AppConstants;

@Component
@Transactional
public class DeMaintenanceHistoryDAO {

	private static final Logger logger = LogManager.getLogger(DeMaintenanceHistoryDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings("unchecked")
	public List<DeMaintenanceHistory> getRecordsForDeDeal(String deDealId) throws Exception {
		logger.debug(deDealId);
		
		List<DeMaintenanceHistory> records = null;
		try {
			Criteria cr = getCurrentSession().createCriteria(DeMaintenanceHistory.class);
			cr.add(Restrictions.eq("pageName", AppConstants.DE_MAINTENANCE_DEAL_PAGE));
			cr.add(Restrictions.eq("itemId", deDealId));
			cr.add(Restrictions.eq("action", AppConstants.DE_MAINTENANCE_NOTE_ACTION));
			records = cr.list();
		} catch(Exception e) {
			logger.error("Error retrieving DeMaintenanceHistory records from DB. ", e);
			throw e;
		}
		
		return records;
	}
}