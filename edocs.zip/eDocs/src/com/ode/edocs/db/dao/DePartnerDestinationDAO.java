package com.ode.edocs.db.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DePartnerDestination;

@Component
@Transactional
public class DePartnerDestinationDAO {
	
private static final Logger logger = LogManager.getLogger(DePartnerDestinationDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public DePartnerDestination findByProduct(String product) throws Exception {
	    logger.debug(product);
     
		DePartnerDestination partnerDestination = null;
		Criteria cr = getCurrentSession().createCriteria(DePartnerDestination.class);
		cr.add(Restrictions.eq("product", product));
		partnerDestination = (DePartnerDestination) cr.uniqueResult();
		
		return partnerDestination;
	}
	
	public DePartnerDestination findByPartnerAndProduct(String partnerId, String product) throws Exception {
		logger.debug("findByPartnerAndProduct: partnerId > " + partnerId + ", product > " + product);
	     
		DePartnerDestination partnerDestination = null;
		Criteria cr = getCurrentSession().createCriteria(DePartnerDestination.class);
		cr.add(Restrictions.eq("product", product));
		cr.add(Restrictions.eq("partnerId", partnerId));
		partnerDestination = (DePartnerDestination) cr.uniqueResult();
		
		return partnerDestination;
	}
}