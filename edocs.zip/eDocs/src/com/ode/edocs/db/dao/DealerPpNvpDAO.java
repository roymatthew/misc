package com.ode.edocs.db.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.DealerPpNvp;
import com.ode.edocs.util.AppConstants;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

@Component
@Transactional
public class DealerPpNvpDAO {
	
	private static final Logger logger = LogManager.getLogger(DealerPpNvpDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

		
	@SuppressWarnings("unchecked")
	public DealerPpNvp findEyesOnDocFlag(String dealerId, String lenderId) throws Exception {
		logger.debug(dealerId);
		List<DealerPpNvp> records = null;
		Criteria cr = getCurrentSession().createCriteria(DealerPpNvp.class);
	
		cr.add(Restrictions.eq("dealerId", dealerId));
		cr.add(Restrictions.eq("partnerId", lenderId));
		cr.add(Restrictions.eq("productId", "DC"));
		cr.add(Restrictions.eq("status", "A"));
		cr.add(Restrictions.eq("parmName", "EOD"));
		
		try{
			records =  cr.list();
			if (null != records && records.size() > 0) {
				return records.get(0);
			}
		} catch (Exception e) {
			logger.error("Error while retreiving Eyes On Doc information", e);	
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public DealerPpNvp isRouteOneEnabledForDealer(String dealerId, String lenderId, String dmsId, String productId) throws Exception {
		logger.debug(dealerId);
		List<DealerPpNvp> records = null;
		Criteria cr = getCurrentSession().createCriteria(DealerPpNvp.class);
	
		cr.add(Restrictions.eq("dealerId", dealerId));
		cr.add(Restrictions.eq("partnerId", lenderId));
		cr.add(Restrictions.eq("productId", productId));
		cr.add(Restrictions.eq("status", "A"));
		cr.add(Restrictions.eq("parmName", AppConstants.ROUTEONE_DEALER_FLAG));
		cr.add(Restrictions.eq("parmValue", AppConstants.ROUTEONE_FLAG_YES));
		cr.add(Restrictions.eq("dspId", dmsId));
		
		try {
			records =  cr.list();
			if (null != records && records.size() > 0) {
				return records.get(0);
			}
		} catch (Exception e) {
			logger.error("Error while retreiving Eyes On Doc information", e);	
		}
		return null;
	}
}
