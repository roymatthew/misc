package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DmsDocType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DmsDocTypeDAO {

    private static final Logger logger = LogManager.getLogger(DmsDocTypeDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public void saveOrUpdate(DmsDocType dmsDocType) throws Exception {
        logger.debug("saveOrUpdate(DmsDocType dmsDocType) method ");
        getCurrentSession().saveOrUpdate(dmsDocType);

    }

    public DmsDocType findByName(String name, String dms) throws Exception {
        logger.debug(name, dms);

        DmsDocType docType = null;
        Criteria cr = getCurrentSession().createCriteria(DmsDocType.class);
        cr.add(Restrictions.eq("docName", name).ignoreCase());
        cr.add(Restrictions.eq("dmsId", dms));
        docType = (DmsDocType) cr.uniqueResult();

        return docType;
    }
}