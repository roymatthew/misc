package com.ode.edocs.db.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.ode.edocs.db.entity.ErrorLog;

@Component
@Transactional
public class ErrorLogDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	private static final Logger logger = LogManager.getLogger(ErrorLogDAO.class);
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public ErrorLog saveOrUpdate(ErrorLog errorLog) {
		logger.debug(errorLog);
		try {
			getCurrentSession().saveOrUpdate(errorLog);
		} catch (Exception e) {
			logger.error("An error occured while saving error log record: ", e);
		}
		return errorLog;
	}
}
