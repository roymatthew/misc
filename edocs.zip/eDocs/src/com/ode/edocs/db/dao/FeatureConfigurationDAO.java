package com.ode.edocs.db.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ode.edocs.db.entity.FeatureConfiguration;

@Component
@Transactional
public class FeatureConfigurationDAO{
	private static final Logger logger = LogManager.getLogger(FeatureConfigurationDAO.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings("unchecked")
	public List<FeatureConfiguration> getConfiguration(String lenderId){
		logger.debug(lenderId);
		
		List<FeatureConfiguration> featureConfigurations = null;
		try{
			Criteria cr = getCurrentSession().createCriteria(FeatureConfiguration.class);
			cr.add(Restrictions.eq("lenderId", lenderId));
			featureConfigurations = cr.list();
		}catch(Exception e){
			logger.error("could not retrieve feature configuration records", e);
		}
				
		return featureConfigurations;
	}

	@SuppressWarnings("unchecked")
	public List<FeatureConfiguration> getConfigurationWithName(String lenderId, String featureName){
		logger.debug(lenderId, featureName);
		
		List<FeatureConfiguration> featureConfigurations = null;
		try{
			Criteria cr = getCurrentSession().createCriteria(FeatureConfiguration.class);
			cr.add(Restrictions.eq("lenderId", lenderId));
			cr.add(Restrictions.eq("featureName", featureName));
			featureConfigurations = cr.list();
		}catch(Exception e){
			logger.error("could not retrieve feature configuration records", e);
		}
				
		return featureConfigurations;
	}
}
