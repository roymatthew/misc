package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.Forms;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class FormsDAO {

    private static final Logger logger = LogManager.getLogger(FormsDAO.class);

    @Autowired
    private SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    @SuppressWarnings("unchecked")
    public List<Forms> findForms(String dspForm, String dspRev, String lenderCode) throws Exception {
        logger.debug(dspForm, dspRev);
        List<Forms> records = null;
        Criteria cr = getCurrentSession().createCriteria(Forms.class);
        cr.add(Restrictions.eq("dspForm", dspForm));
        cr.add(Restrictions.eq("dspRev", dspRev));
        cr.add(Restrictions.eq("lenderCode", lenderCode));
        records = cr.list();
        return records;
    }

}
