package com.ode.edocs.db.dao;

import com.ode.edocs.File;

public interface IDcDocumentBatchDAO {

    /**
     * @param file
     */
    void doBatchInsertDocData(final File file);

}
