package com.ode.edocs.db.dao;

import com.ode.edocs.db.entity.DcDocType;
import com.ode.edocs.db.entity.LenDocType;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class LenDocTypeDAO {

    private static final Logger logger = LogManager.getLogger(LenDocTypeDAO.class);

    @Autowired
    public SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    public void saveOrUpdate(DcDocType dcDocType) throws Exception {
        logger.debug("saveOrUpdate(DcDocType dcDocType) method");
        getCurrentSession().saveOrUpdate(dcDocType);

    }

    @SuppressWarnings("unchecked")
    public List<LenDocType> findByDcDocTypeId(Integer dcDocTypeId, String lenderId) throws Exception {
        logger.debug(dcDocTypeId + lenderId);

        List<LenDocType> docTypes = null;
        Criteria cr = getCurrentSession().createCriteria(LenDocType.class);
        cr.add(Restrictions.eq("dcDocType.id", dcDocTypeId));
        cr.add(Restrictions.eq("lenderId", lenderId));
        docTypes = cr.list();

        return docTypes;
    }

}