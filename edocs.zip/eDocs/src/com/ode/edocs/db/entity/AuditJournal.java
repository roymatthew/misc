package com.ode.edocs.db.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AUDITJOURNAL", schema = "CRGATE")
public class AuditJournal implements Serializable {
    private static final long serialVersionUID = 7310298830807578164L;
    @Id
    @Column(name = "SYSTEMID")
    private String systemId;

    @Column(name = "DEALERID")
    private String dealerId;

    @Column(name = "PARTNERID")
    private String partnerId;

    @Column(name = "USERID")
    private String userId;

    @Column(name = "TRANSDATETIME")
    private Date transDateTime;

    @Column(name = "TRANSTYPE")
    private String transType;

    @Column(name = "AUDITDATA")
    private String auditData;

    @Column(name = "ACCOUNTID")
    private String accountId;

    @Column(name = "REQUEST_ID")
    private String requestId;

    @Column(name = "TRANSACTION_ID")
    private String transactionId;

    @Column(name = "DSP_ID")
    private String dspId;

    @Column(name = "CJ_KEY")
    private Integer cjKey;

    @Column(name = "DE_DEAL_ID")
    private String deDealId;

    @Column(name = "DMS_DEAL_NUMBER")
    private String dmsDealNumber;

    public String getDeDealId() {
        return deDealId;
    }

    public void setDeDealId(String deDealId) {
        this.deDealId = deDealId;
    }

    public String getDmsDealNumber() {
        return dmsDealNumber;
    }

    public void setDmsDealNumber(String dmsDealNumber) {
        this.dmsDealNumber = dmsDealNumber;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getTransDateTime() {
        return transDateTime;
    }

    public void setTransDateTime(Date date) {
        transDateTime = date;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getAuditData() {
        return auditData;
    }

    public void setAuditData(String auditData) {
        this.auditData = auditData;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getDspId() {
        return dspId;
    }

    public void setDspId(String dspId) {
        this.dspId = dspId;
    }

    public Integer getCjKey() {
        return cjKey;
    }

    public void setCjKey(Integer cjKey) {
        this.cjKey = cjKey;
    }

    @Override
    public String toString() {
        return "AuditJournal [systemId=" + systemId + ", dealerId=" + dealerId + ", partnerId=" + partnerId
            + ", userId=" + userId + ", transDateTime=" + transDateTime + ", transType=" + transType + ", auditData="
            + auditData + ", accountId=" + accountId + ", requestId=" + requestId + ", transactionId=" + transactionId
            + ", dspId=" + dspId + ", cjKey=" + cjKey + ", deDealId=" + deDealId + ", dmsDealNumber=" + dmsDealNumber
            + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (accountId == null ? 0 : accountId.hashCode());
        result = prime * result + (auditData == null ? 0 : auditData.hashCode());
        result = prime * result + (cjKey == null ? 0 : cjKey.hashCode());
        result = prime * result + (deDealId == null ? 0 : deDealId.hashCode());
        result = prime * result + (dealerId == null ? 0 : dealerId.hashCode());
        result = prime * result + (dmsDealNumber == null ? 0 : dmsDealNumber.hashCode());
        result = prime * result + (dspId == null ? 0 : dspId.hashCode());
        result = prime * result + (partnerId == null ? 0 : partnerId.hashCode());
        result = prime * result + (requestId == null ? 0 : requestId.hashCode());
        result = prime * result + (systemId == null ? 0 : systemId.hashCode());
        result = prime * result + (transDateTime == null ? 0 : transDateTime.hashCode());
        result = prime * result + (transType == null ? 0 : transType.hashCode());
        result = prime * result + (transactionId == null ? 0 : transactionId.hashCode());
        result = prime * result + (userId == null ? 0 : userId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        AuditJournal other = (AuditJournal) obj;
        if (accountId == null) {
            if (null != other.accountId) {
                return false;
            }
        } else if (!accountId.equals(other.accountId)) {
            return false;
        }
        if (auditData == null) {
            if (null != other.auditData) {
                return false;
            }
        } else if (!auditData.equals(other.auditData)) {
            return false;
        }
        if (cjKey == null) {
            if (null != other.cjKey) {
                return false;
            }
        } else if (!cjKey.equals(other.cjKey)) {
            return false;
        }
        if (deDealId == null) {
            if (null != other.deDealId) {
                return false;
            }
        } else if (!deDealId.equals(other.deDealId)) {
            return false;
        }
        if (dealerId == null) {
            if (null != other.dealerId) {
                return false;
            }
        } else if (!dealerId.equals(other.dealerId)) {
            return false;
        }
        if (dmsDealNumber == null) {
            if (null != other.dmsDealNumber) {
                return false;
            }
        } else if (!dmsDealNumber.equals(other.dmsDealNumber)) {
            return false;
        }
        if (dspId == null) {
            if (null != other.dspId) {
                return false;
            }
        } else if (!dspId.equals(other.dspId)) {
            return false;
        }
        if (partnerId == null) {
            if (null != other.partnerId) {
                return false;
            }
        } else if (!partnerId.equals(other.partnerId)) {
            return false;
        }
        if (requestId == null) {
            if (null != other.requestId) {
                return false;
            }
        } else if (!requestId.equals(other.requestId)) {
            return false;
        }
        if (systemId == null) {
            if (null != other.systemId) {
                return false;
            }
        } else if (!systemId.equals(other.systemId)) {
            return false;
        }
        if (transDateTime == null) {
            if (null != other.transDateTime) {
                return false;
            }
        } else if (!transDateTime.equals(other.transDateTime)) {
            return false;
        }
        if (transType == null) {
            if (null != other.transType) {
                return false;
            }
        } else if (!transType.equals(other.transType)) {
            return false;
        }
        if (transactionId == null) {
            if (null != other.transactionId) {
                return false;
            }
        } else if (!transactionId.equals(other.transactionId)) {
            return false;
        }
        if (userId == null) {
            if (null != other.userId) {
                return false;
            }
        } else if (!userId.equals(other.userId)) {
            return false;
        }
        return true;
    }
}
