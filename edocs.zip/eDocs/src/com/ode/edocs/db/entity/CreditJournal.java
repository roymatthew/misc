package com.ode.edocs.db.entity;

import java.math.BigInteger;
import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.CREDITJOURNAL")
public class CreditJournal {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "CJ_KEY")
	private BigInteger cjKey;
	
	@Column(name = "SYSTEMID")
	private String systemId;
	
	@Column(name = "DSP_ID")
	private String dspId;
	
	@Column(name = "DEALERID")
	private String dealerId;
	
	@Column(name = "PARTNERID")
	private String partnerId;
	
	@Column(name = "USERID")
	private String userId;
	
	@Column(name = "TRANSDATETIME")
	private Date transDateTime;
	
	@Column(name = "TRANSTYPE")
	private String transType;
	
	@Column(name = "APPLTYPE")
	private String applicationType;
	
	@Column(name = "ADPDEALNO")
	private String adpDealNumber;
	
	@Column(name = "PARTNERDEALNO")
	private String partnerDealNumber;
	
	@Column(name = "CRDATAXML")
	@Lob
	private String crDataXml;
	
	@Column(name = "SEQUENCENO")
	private String sequenceNumber;
	
	@Column(name = "FINANCEINSTITUTION")
	private String financeInstitution;
	
	@Column(name = "TRANSFLAG")
	private String transFlag;
	
	@Column(name = "ACCOUNTID")
	private String accountId;
	
	@Column(name = "DELIVERY_SOURCE")
	private String deliverySource;
	
	@Column(name = "APPLICATION_SOURCE")
	private String applicationSource;
	
	@Column(name = "TRANSACTION_ID")
	private String transactionId;

	@Column(name = "DEAL_ID")
	private String dealId;

	@Column(name = "SEQUENCE_ID")
	private String sequenceId;
	
	@Column(name = "ENCRYPTION_KEY_ID")
	private String encryptionKeyId;

	public BigInteger getCjKey() {
		return cjKey;
	}

	public void setCjKey(BigInteger cjKey) {
		this.cjKey = cjKey;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getDspId() {
		return dspId;
	}

	public void setDspId(String dspId) {
		this.dspId = dspId;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getTransDateTime() {
		return transDateTime;
	}

	public void setTransDateTime(Date transDateTime) {
		this.transDateTime = transDateTime;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getAdpDealNumber() {
		return adpDealNumber;
	}

	public void setAdpDealNumber(String adpDealNumber) {
		this.adpDealNumber = adpDealNumber;
	}

	public String getPartnerDealNumber() {
		return partnerDealNumber;
	}

	public void setPartnerDealNumber(String partnerDealNumber) {
		this.partnerDealNumber = partnerDealNumber;
	}

	public String getCrDataXml() {
		return crDataXml;
	}

	public void setCrDataXml(String crDataXml) {
		this.crDataXml = crDataXml;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getFinanceInstitution() {
		return financeInstitution;
	}

	public void setFinanceInstitution(String financeInstitution) {
		this.financeInstitution = financeInstitution;
	}

	public String getTransFlag() {
		return transFlag;
	}

	public void setTransFlag(String transFlag) {
		this.transFlag = transFlag;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getDeliverySource() {
		return deliverySource;
	}

	public void setDeliverySource(String deliverySource) {
		this.deliverySource = deliverySource;
	}

	public String getApplicationSource() {
		return applicationSource;
	}

	public void setApplicationSource(String applicationSource) {
		this.applicationSource = applicationSource;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}
	
	public String getEncryptionKeyId() {
		return encryptionKeyId;
	}
	
	public void setEncryptionKeyId(String encryptionKeyId) {
		this.encryptionKeyId = encryptionKeyId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CreditJournal [cjKey=");
		builder.append(cjKey);
		builder.append(", systemId=");
		builder.append(systemId);
		builder.append(", dspId=");
		builder.append(dspId);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append(", partnerId=");
		builder.append(partnerId);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", transDateTime=");
		builder.append(transDateTime);
		builder.append(", transType=");
		builder.append(transType);
		builder.append(", applicationType=");
		builder.append(applicationType);
		builder.append(", adpDealNumber=");
		builder.append(adpDealNumber);
		builder.append(", partnerDealNumber=");
		builder.append(partnerDealNumber);
		builder.append(", sequenceNumber=");
		builder.append(sequenceNumber);
		builder.append(", financeInstitution=");
		builder.append(financeInstitution);
		builder.append(", transFlag=");
		builder.append(transFlag);
		builder.append(", accountId=");
		builder.append(accountId);
		builder.append(", deliverySource=");
		builder.append(deliverySource);
		builder.append(", applicationSource=");
		builder.append(applicationSource);
		builder.append(", transationId=");
		builder.append(transactionId);
		builder.append(", dealId=");
		builder.append(dealId);
		builder.append(", sequenceId=");
		builder.append(sequenceId);
		builder.append(", encryptionKeyId=");
		builder.append(encryptionKeyId);
		builder.append("]");
		return builder.toString();
	}
}