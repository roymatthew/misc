package com.ode.edocs.db.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CRGATE.DC_DIGITAL_DEAL")
public class DcDigitalDeal {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "DC_DIGITAL_DEAL_ID")
    private Integer dcDigitalDealId;

    @Column(name = "DEALER_ID")
    private String dealerId;

    @Column(name = "PARTNER_ID")
    private String partnerId;

    @Column(name = "SEQUENCE_NO")
    private String sequenceNo;

    @Column(name = "DMS_DEAL_NUMBER")
    private String dmsDealNumber;

    @Column(name = "FUNDING_STATUS")
    private String fundingStatus;

    @Column(name = "VALIDATION_RESULT")
    private String validationResult;

    @Column(name = "CREATED_TS")
    private Date createdTs;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFIED_TS", insertable = false)
    private Date modifiedTs;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

    @Column(name = "VAULT_DOC_ID")
    private String vaultDocId;

    @Column(name = "DE_DEAL_ID")
    private String deDealId;

    public Integer getDcDigitalDealId() {
        return dcDigitalDealId;
    }

    public void setDcDigitalDealId(Integer dcDigitalDealId) {
        this.dcDigitalDealId = dcDigitalDealId;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(String sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public String getDmsDealNumber() {
        return dmsDealNumber;
    }

    public void setDmsDealNumber(String dmsDealNumber) {
        this.dmsDealNumber = dmsDealNumber;
    }

    public String getFundingStatus() {
        return fundingStatus;
    }

    public void setFundingStatus(String fundingStatus) {
        this.fundingStatus = fundingStatus;
    }

    public String getValidationResult() {
        return validationResult;
    }

    public void setValidationResult(String validationResult) {
        this.validationResult = validationResult;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(Date createdTs) {
        this.createdTs = createdTs;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getModifiedTs() {
        return modifiedTs;
    }

    public void setModifiedTs(Date modifiedTs) {
        this.modifiedTs = modifiedTs;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getVaultDocId() {
        return vaultDocId;
    }

    public void setVaultDocId(String vaultDocId) {
        this.vaultDocId = vaultDocId;
    }

    public String getDeDealId() {
        return deDealId;
    }

    public void setDeDealId(String deDealId) {
        this.deDealId = deDealId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DcDigitalDeal [");
        if (null != dcDigitalDealId) {
            builder.append("dcDigitalDealId=");
            builder.append(dcDigitalDealId);
            builder.append(", ");
        }
        if (null != dealerId) {
            builder.append("dealerId=");
            builder.append(dealerId);
            builder.append(", ");
        }
        if (null != partnerId) {
            builder.append("partnerId=");
            builder.append(partnerId);
            builder.append(", ");
        }
        if (null != sequenceNo) {
            builder.append("sequenceNo=");
            builder.append(sequenceNo);
            builder.append(", ");
        }
        if (null != dmsDealNumber) {
            builder.append("dmsDealNumber=");
            builder.append(dmsDealNumber);
            builder.append(", ");
        }
        if (null != fundingStatus) {
            builder.append("fundingStatus=");
            builder.append(fundingStatus);
            builder.append(", ");
        }
        if (null != validationResult) {
            builder.append("validationResult=");
            builder.append(validationResult);
            builder.append(", ");
        }
        if (null != createdTs) {
            builder.append("createdTs=");
            builder.append(createdTs);
            builder.append(", ");
        }
        if (null != createdBy) {
            builder.append("createdBy=");
            builder.append(createdBy);
            builder.append(", ");
        }
        if (null != modifiedTs) {
            builder.append("modifiedTs=");
            builder.append(modifiedTs);
            builder.append(", ");
        }
        if (null != modifiedBy) {
            builder.append("modifiedBy=");
            builder.append(modifiedBy);
            builder.append(", ");
        }
        if (null != vaultDocId) {
            builder.append("vaultDocId=");
            builder.append(vaultDocId);
            builder.append(", ");
        }
        if (null != deDealId) {
            builder.append("deDealId=");
            builder.append(deDealId);
        }
        builder.append("]");
        return builder.toString();
    }

}
