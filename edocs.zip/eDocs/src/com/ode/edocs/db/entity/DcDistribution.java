package com.ode.edocs.db.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "CRGATE.DC_DISTRIBUTION")
public class DcDistribution {

    public DcDistribution() {
        super();
    }

    @EmbeddedId
    private DcDistributionId id;

    @Column(name = "INBOUND_XML")
    private BigInteger inboundXml;

    @Column(name = "OUTBOUND_XML")
    private BigInteger outboundXml;

    @Column(name = "FILE_LOCATION")
    private String fileLocation;

    @Column(name = "MESSAGE_TYPE")
    private String messageType;

    @Column(name = "DIST_STATUS")
    private String dist_status;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TS")
    private Date createdByTs;

    @Column(name = "MODIFIED_TS")
    private Date modifiedTs;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

    @Column(name = "VAULT_DOC_ID")
    private String vaultDocId;

    @Column(name = "CV_SEQUENCE_ID")
    private String cvSequenceId;

    @Column(name = "READY_TO_BOOK")
    private String readyToBook;
    
    @Column(name = "AUTHORIZATION_ID")
    private String authorizationId;

    @Transient
    private String transactionId;

    @Transient
    private String accountId;

    public DcDistributionId getId() {
        return id;
    }

    public void setId(DcDistributionId id) {
        this.id = id;
    }

    public BigInteger getInboundXml() {
        return inboundXml;
    }

    public void setInboundXml(BigInteger inboundXml) {
        this.inboundXml = inboundXml;
    }

    public BigInteger getOutboundXml() {
        return outboundXml;
    }

    public void setOutboundXml(BigInteger outboundXml) {
        this.outboundXml = outboundXml;
    }

    public String getFileLocation() {
        return fileLocation;
    }

    public void setFileLocation(String fileLocation) {
        this.fileLocation = fileLocation;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getDist_status() {
        return dist_status;
    }

    public void setDist_status(String dist_status) {
        this.dist_status = dist_status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedByTs() {
        return createdByTs;
    }

    public void setCreatedByTs(Date createdByTs) {
        this.createdByTs = createdByTs;
    }

    public Date getModifiedTs() {
        return modifiedTs;
    }

    public void setModifiedTs(Date modifiedTs) {
        this.modifiedTs = modifiedTs;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getVaultDocId() {
        return vaultDocId;
    }

    public void setVaultDocId(String vaultDocId) {
        this.vaultDocId = vaultDocId;
    }

    public String getCvSequenceId() {
        return cvSequenceId;
    }

    public void setCvSequenceId(String cvSequenceId) {
        this.cvSequenceId = cvSequenceId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getReadyToBook() {
        return readyToBook;
    }

    public void setReadyToBook(String readyToBook) {
        this.readyToBook = readyToBook;
    }

    public String getAuthorizationId() {
		return authorizationId;
	}

	public void setAuthorizationId(String authorizationId) {
		this.authorizationId = authorizationId;
	}

    @Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DcDistribution [id=");
		builder.append(id);
		builder.append(", inboundXml=");
		builder.append(inboundXml);
		builder.append(", outboundXml=");
		builder.append(outboundXml);
		builder.append(", fileLocation=");
		builder.append(fileLocation);
		builder.append(", messageType=");
		builder.append(messageType);
		builder.append(", dist_status=");
		builder.append(dist_status);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", createdByTs=");
		builder.append(createdByTs);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", vaultDocId=");
		builder.append(vaultDocId);
		builder.append(", cvSequenceId=");
		builder.append(cvSequenceId);
		builder.append(", readyToBook=");
		builder.append(readyToBook);
		builder.append(", authorizationId=");
		builder.append(authorizationId);
		builder.append(", transactionId=");
		builder.append(transactionId);
		builder.append(", accountId=");
		builder.append(accountId);
		builder.append("]");
		return builder.toString();
	}

	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (id == null ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DcDistribution other = (DcDistribution) obj;
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    @Embeddable
    public static class DcDistributionId implements Serializable {
        public DcDistributionId() {
            super();
        }

        private static final long serialVersionUID = 5959262760822531659L;
        @Column(name = "DEAL_ID")
        private String dealId;

        @Column(name = "SEQUENCE_ID")
        private String sequenceId;

        public String getDealId() {
            return dealId;
        }

        public void setDealId(String dealId) {
            this.dealId = dealId;
        }

        public String getSequenceId() {
            return sequenceId;
        }

        public void setSequenceId(String sequenceId) {
            this.sequenceId = sequenceId;
        }

        @Override
        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append("DcDistributionId [dealId=");
            builder.append(dealId);
            builder.append(", sequenceId=");
            builder.append(sequenceId);
            builder.append("]");
            return builder.toString();
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + (dealId == null ? 0 : dealId.hashCode());
            result = prime * result + (sequenceId == null ? 0 : sequenceId.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            DcDistributionId other = (DcDistributionId) obj;
            if (dealId == null) {
                if (null != other.dealId) {
                    return false;
                }
            } else if (!dealId.equals(other.dealId)) {
                return false;
            }
            if (sequenceId == null) {
                if (null != other.sequenceId) {
                    return false;
                }
            } else if (!sequenceId.equals(other.sequenceId)) {
                return false;
            }
            return true;
        }
    }
}
