package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DC_DOC_DATA")
public class DcDocData {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DC_DOC_DATA_ID")
	private Integer dcDocDataId;
	
	@Column(name = "DC_DOCUMENT_ID")
	private Integer dcDocumentId;
	
	@Column(name = "DATA_NAME")
	private String dataName;
	
	@Column(name = "DATA_VALUE")
	private String dataValue;
	
	@Column(name = "DATA_TYPE")
	private String dataType;
	
	@Column(name = "SECTION")
	private String section;
	
	@Column(name = "CREATED_TS")
	private Date createdTs;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name = "DISPLAY_NAME")
	private String displayName;
	
	@Column(name = "GROUP_NAME")
	private String groupName;
	
	@Column(name = "IS_DROP_DOWN")
	private String isDropDown;
	
	@Column(name = "IS_EDITABLE")
	private String isEditable;
	
	public String getIsEditable() {
		return isEditable;
	}

	public void setIsEditable(String isEditable) {
		this.isEditable = isEditable;
	}

	public String getIsDropDown() {
		return isDropDown;
	}

	public void setIsDropDown(String isDropDown) {
		this.isDropDown = isDropDown;
	}

	public Integer getDcDocDataId() {
		return dcDocDataId;
	}

	public void setDcDocDataId(Integer dcDocDataId) {
		this.dcDocDataId = dcDocDataId;
	}

	public Integer getDcDocumentId() {
		return dcDocumentId;
	}

	public void setDcDocumentId(Integer dcDocumentId) {
		this.dcDocumentId = dcDocumentId;
	}

	public String getDataName() {
		return dataName;
	}

	public void setDataName(String dataName) {
		this.dataName = dataName;
	}

	public String getDataValue() {
		return dataValue;
	}

	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedTs() {
		return modifiedTs;
	}

	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	@Override
	public String toString() {
		return "DcDocData [dcDocDataId=" + dcDocDataId + ", dcDocumentId=" + dcDocumentId + ", dataName=" + dataName
				+ ", dataValue=" + dataValue + ", dataType=" + dataType + ", section=" + section + ", createdTs="
				+ createdTs + ", createdBy=" + createdBy + ", modifiedTs=" + modifiedTs + ", modifiedBy=" + modifiedBy
				+ ", displayName=" + displayName + ", groupName=" + groupName + "]";
	}
}