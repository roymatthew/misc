package com.ode.edocs.db.entity;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DC_DOC_FIELD")
public class DcDocField {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "DC_DOC_FIELD_ID")
	private Integer id;
	@Column(name = "DC_DOC_TYPE_ID")
	private Integer dcDocTypeId;
	@Column(name = "DMS_DOC_TYPE_ID")
	private Integer dmsDocTypeId;
	@Column(name = "FIELD_NAME")
	private String fieldName;
	@Column(name = "FIELD_TYPE")
	private String fieldType;
	@Column(name = "SECTION")
	private String section;	
	@Column(name = "XPATH")
	private String xpath;
	@Column(name = "OVERRIDE_VALUE")
	private String overrideValue;
	@Column(name = "GROUP_NAME")
	private String group_name;
	@Column(name = "FIELD_EXPRESSION")
	private String field_expression;
	@Column(name = "CREATED_TS")
	private Date createdTs;
	@Column(name = "CREATED_BY")
	private String createdBy;
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "TRIM_DATA_FLAG")
	private String trimDataFlag;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getDcDocTypeId() {
		return dcDocTypeId;
	}
	public void setDcDocTypeId(Integer dcDocTypeId) {
		this.dcDocTypeId = dcDocTypeId;
	}
	
	public Integer getDmsDocTypeId() {
		return dmsDocTypeId;
	}
	public void setDmsDocTypeId(Integer dmsDocTypeId) {
		this.dmsDocTypeId = dmsDocTypeId;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getXpath() {
		return xpath;
	}
	public void setXpath(String xpath) {
		this.xpath = xpath;
	}
	public String getOverrideValue() {
		return overrideValue;
	}
	public void setOverrideValue(String overrideValue) {
		this.overrideValue = overrideValue;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	public String getField_expression() {
		return field_expression;
	}
	public void setField_expression(String field_expression) {
		this.field_expression = field_expression;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getTrimDataFlag() {
		return trimDataFlag;
	}
	public void setTrimDataFlag(String trimDataFlag) {
		this.trimDataFlag = trimDataFlag;
	}
	@Override
	public String toString() {
		return "DcDocField [id=" + id + ", dcDocTypeId=" + dcDocTypeId
				+ ", dmsDocTypeId=" + dmsDocTypeId + ", fieldName=" + fieldName
				+ ", fieldType=" + fieldType + ", section=" + section
				+ ", xpath=" + xpath + ", overrideValue=" + overrideValue
				+ ", group_name=" + group_name + ", field_expression="
				+ field_expression + ", createdTs=" + createdTs
				+ ", createdBy=" + createdBy + ", modifiedTs=" + modifiedTs
				+ ", modifiedBy=" + modifiedBy + ", trimDataFlag=" + trimDataFlag + "]";
	}
}