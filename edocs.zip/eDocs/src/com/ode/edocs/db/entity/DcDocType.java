package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DC_DOC_TYPE")
public class DcDocType {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "DC_DOC_TYPE_ID")
	private Integer id;
	@Column(name = "DOC_NAME")
	private String name;
	@Column(name = "DOC_TYPE")
	private String type;
	@Column(name = "CREATED_TS")
	private Date createdTs;
	@Column(name = "CREATED_BY")
	private String createdBy;
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DcDocType [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append(", type=");
		builder.append(type);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append("]");
		return builder.toString();
	}
}