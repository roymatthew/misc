package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DC_DOCUMENT")
public class DcDocument {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "DC_DOCUMENT_ID", updatable = false, insertable = false)
	private Integer id;
	
	@Column(name = "DEAL_ID")
	private String dealId;
	
	@Column(name = "DIST_SEQUENCE_ID")
	private String sequenceId;
	
	@Column(name = "LENDER_DOC_NAME")
	private String lenderDocName;
	
	@Column(name = "DOC_TYPE")
	private String docType;
	
	@Column(name = "FORM_TYPE")
	private String formType;
	
	@Column(name = "METADATA_XML")
	private String metadata_xml;
	
	@Column(name = "CREATED_TS")
	private Date createdTs;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name = "DMS_DOC_NAME")
	private String dmsDocName;
	
	@Column(name = "ENCRYPTION_KEY_ID")
	private String encryptionKeyId;
	
	@Column(name = "FORM_COMPLETE")
	private String formComplete;
	
	@Column(name="DOC_STATUS")
	private String docStatus;
	
	public String getDocStatus() {
		return docStatus;
	}
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDealId() {
		return dealId;
	}
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}
	public String getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}
	public String getLenderDocName() {
		return lenderDocName;
	}
	public void setLenderDocName(String lenderDocName) {
		this.lenderDocName = lenderDocName;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	public String getMetadata_xml() {
		return metadata_xml;
	}
	public void setMetadata_xml(String metadata_xml) {
		this.metadata_xml = metadata_xml;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getDmsDocName() {
		return dmsDocName;
	}
	public void setDmsDocName(String dmsDocName) {
		this.dmsDocName = dmsDocName;
	}
	public String getEncryptionKeyId() {
		return encryptionKeyId;
	}
	public void setEncryptionKeyId(String encryptionKeyId) {
		this.encryptionKeyId = encryptionKeyId;
	}
	public String getFormComplete() {
		return formComplete;
	}
	public void setFormComplete(String formComplete) {
		this.formComplete = formComplete;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DcDocument [id=");
		builder.append(id);
		builder.append(", dealId=");
		builder.append(dealId);
		builder.append(", sequenceId=");
		builder.append(sequenceId);
		builder.append(", lenderDocName=");
		builder.append(lenderDocName);
		builder.append(", docType=");
		builder.append(docType);
		builder.append(", formType=");
		builder.append(formType);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", dmsDocName=");
		builder.append(dmsDocName);
		builder.append(", formComplete=");
		builder.append(formComplete);
		builder.append("]");
		return builder.toString();
	}

}