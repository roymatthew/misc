package com.ode.edocs.db.entity;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "CRGATE.DC_FORM")
public class DcForm {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "DC_FORM_ID")
	private BigInteger dcFormId;
	
	@Column(name = "DC_DIGITAL_DEAL_ID")
	private BigInteger dcDigitalDealId;

	@Column(name = "DE_DEAL_ID")
	private String deDealId;
	
	@Column(name = "RFL_SEQUENCE_ID")
	private String rflSequenceId;
	
	@ManyToOne
    @JoinColumn(name = "DC_DOCUMENT_ID", nullable=true)
	private DcDocument dcDocument;
	
	@Column(name = "FORM_ID")
	private String formId;
	
	@Column(name = "FORM_NAME")
	private String formName;
	
	@Column(name = "FORM_COMMENT")
	private String formComment;
	
	@Column(name = "FORM_STATUS")
	private String formStatus;
	
	@Column(name = "PRODUCT_DESCRIPTION")
	private String productDescription;
	
	@Column(name = "PRODUCT_FORM_NAME")
	private String productFormName;
	
	@Column(name = "PRODUCT_FORM_VERSION_DATE")
	private Date productFormVersionDate;
	
	@Column(name = "LENDER_RECEIVED_DATE")
	private Date lenderReceivedDate;
	
	@Column(name = "TRANSFERRED_DATE")
	private Date transferredDate;
	
	@Column(name = "REQUIRED_FORM_FLAG")
	private String requiredFormFlag;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_TS")
	private Date createdTs;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;

	public BigInteger getDcFormId() {
		return dcFormId;
	}

	public void setDcFormId(BigInteger dcFormId) {
		this.dcFormId = dcFormId;
	}

	public BigInteger getDcDigitalDealId() {
		return dcDigitalDealId;
	}

	public void setDcDigitalDealId(BigInteger dcDigitalDealId) {
		this.dcDigitalDealId = dcDigitalDealId;
	}

	public String getDeDealId() {
		return deDealId;
	}

	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}

	public String getRflSequenceId() {
		return rflSequenceId;
	}

	public void setRflSequenceId(String rflSequenceId) {
		this.rflSequenceId = rflSequenceId;
	}

	public DcDocument getDcDocument() {
		return dcDocument;
	}

	public void setDcDocument(DcDocument dcDocument) {
		this.dcDocument = dcDocument;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getFormComment() {
		return formComment;
	}

	public void setFormComment(String formComment) {
		this.formComment = formComment;
	}

	public String getFormStatus() {
		return formStatus;
	}

	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductFormName() {
		return productFormName;
	}

	public void setProductFormName(String productFormName) {
		this.productFormName = productFormName;
	}

	public Date getProductFormVersionDate() {
		return productFormVersionDate;
	}

	public void setProductFormVersionDate(Date productFormVersionDate) {
		this.productFormVersionDate = productFormVersionDate;
	}

	public Date getLenderReceivedDate() {
		return lenderReceivedDate;
	}

	public void setLenderReceivedDate(Date lenderReceivedDate) {
		this.lenderReceivedDate = lenderReceivedDate;
	}

	public Date getTransferredDate() {
		return transferredDate;
	}

	public void setTransferredDate(Date transferredDate) {
		this.transferredDate = transferredDate;
	}

	public String getRequiredFormFlag() {
		return requiredFormFlag;
	}

	public void setRequiredFormFlag(String requiredFormFlag) {
		this.requiredFormFlag = requiredFormFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedTs() {
		return modifiedTs;
	}

	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DCForm [dcFormId=");
		builder.append(dcFormId);
		builder.append(", dcDigitalDealId=");
		builder.append(dcDigitalDealId);
		builder.append(", deDealId=");
		builder.append(deDealId);
		builder.append(", rflSequenceId=");
		builder.append(rflSequenceId);
		builder.append(", dcDocument=");
		builder.append(dcDocument);
		builder.append(", formId=");
		builder.append(formId);
		builder.append(", formName=");
		builder.append(formName);
		builder.append(", formComment=");
		builder.append(formComment);
		builder.append(", formStatus=");
		builder.append(formStatus);
		builder.append(", productDescription=");
		builder.append(productDescription);
		builder.append(", productFormName=");
		builder.append(productFormName);
		builder.append(", productFormVersionDate=");
		builder.append(productFormVersionDate);
		builder.append(", lenderReceivedDate=");
		builder.append(lenderReceivedDate);
		builder.append(", transferredDate=");
		builder.append(transferredDate);
		builder.append(", requiredFormFlag=");
		builder.append(requiredFormFlag);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append("]");
		return builder.toString();
	}
	
}