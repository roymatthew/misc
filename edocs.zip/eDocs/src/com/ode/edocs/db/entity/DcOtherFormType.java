package com.ode.edocs.db.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "CRGATE.DC_OTHER_FORM_TYPE")
public class DcOtherFormType {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "ID")
	private Integer id;

	@Column(name = "DE_DEAL_ID")
	private String deDealId;

	@Column(name = "DMS_DOC_NAME")
	private String dmsDocName;

	@Column(name = "LEN_DOC_NAME")
	private String lenDocName;

	@Column(name = "FORM_ID")
	private String formId;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_TS")
	private Date createdTs;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDeDealId() {
		return deDealId;
	}

	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}

	public String getDmsDocName() {
		return dmsDocName;
	}

	public void setDmsDocName(String dmsDocName) {
		this.dmsDocName = dmsDocName;
	}

	public String getLenDocName() {
		return lenDocName;
	}

	public void setLenDocName(String lenDocName) {
		this.lenDocName = lenDocName;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DcOtherFormType [id=");
		builder.append(id);
		builder.append(", deDealId=");
		builder.append(deDealId);
		builder.append(", dmsDocName=");
		builder.append(dmsDocName);
		builder.append(", lenDocName=");
		builder.append(lenDocName);
		builder.append(", formId=");
		builder.append(formId);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append("]");
		return builder.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		DcOtherFormType other = (DcOtherFormType) obj;
		if (this.id == null) {
			if (other.getId() != null) {
				return false;
			}
		}
		else if (!this.id.equals(other.getId())) {
			return false;
		}
		if (this.deDealId == null) {
			if (other.getDeDealId() != null) {
				return false;
			}
		}
		else if (!this.deDealId.equals(other.getDeDealId())) {
			return false;
		}
		if (this.dmsDocName == null) {
			if (other.getDmsDocName() != null) {
				return false;
			}
		}
		else if (!this.dmsDocName.equals(other.getDmsDocName())) {
			return false;
		}
		if (this.lenDocName == null) {
			if (other.getLenDocName() != null) {
				return false;
			}
		}
		else if (!this.lenDocName.equals(other.getLenDocName())) {
			return false;
		}
		if (this.formId == null) {
			if (other.getFormId() != null) {
				return false;
			}
		}
		else if (!this.formId.equals(other.getFormId())) {
			return false;
		}
		if (this.createdBy == null) {
			if (other.getCreatedBy() != null) {
				return false;
			}
		}
		else if (!this.createdBy.equals(other.getCreatedBy())) {
			return false;
		}
		if (this.createdTs == null) {
			if (other.getCreatedTs() != null) {
				return false;
			}
		}
		else if (!this.createdTs.equals(other.getCreatedTs())) {
			return false;
		}
		return true;
	}
	
	
}