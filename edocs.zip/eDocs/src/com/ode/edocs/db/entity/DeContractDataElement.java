package com.ode.edocs.db.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the DE_CONTRACT_DATA_ELEMENT database table.
 *
 */
@Entity
@Table(name = "CRGATE.DE_CONTRACT_DATA_ELEMENT")
public class DeContractDataElement {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "ELEMENT_NAME")
    private String elementName;

    @Column(name = "XPATH")
    private String xpath;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TS")
    private Date createdTs;

    public DeContractDataElement() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(Date createdTs) {
        this.createdTs = createdTs;
    }

    @Override
    public String toString() {
        return "DeContractDataElement [id=" + id + ", elementName=" + elementName + ", xpath=" + xpath + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (createdBy == null ? 0 : createdBy.hashCode());
        result = prime * result + (createdTs == null ? 0 : createdTs.hashCode());
        result = prime * result + (elementName == null ? 0 : elementName.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        result = prime * result + (xpath == null ? 0 : xpath.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeContractDataElement other = (DeContractDataElement) obj;
        if (createdBy == null) {
            if (null != other.createdBy) {
                return false;
            }
        } else if (!createdBy.equals(other.createdBy)) {
            return false;
        }
        if (createdTs == null) {
            if (null != other.createdTs) {
                return false;
            }
        } else if (!createdTs.equals(other.createdTs)) {
            return false;
        }
        if (elementName == null) {
            if (null != other.elementName) {
                return false;
            }
        } else if (!elementName.equals(other.elementName)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (xpath == null) {
            if (null != other.xpath) {
                return false;
            }
        } else if (!xpath.equals(other.xpath)) {
            return false;
        }
        return true;
    }
}
