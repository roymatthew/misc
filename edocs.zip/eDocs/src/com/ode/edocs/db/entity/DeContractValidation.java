package com.ode.edocs.db.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_CONTRACT_VALIDATION")
public class DeContractValidation implements Serializable {
    private static final long serialVersionUID = -6212345171893742378L;

    @EmbeddedId
    private DeContractValidationId id;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "STATUS_TS")
    private Date statusTs;

    @Column(name = "SUBMITTED_TS")
    private Date submittedTs;

    @Column(name = "DMS_DEAL_NUM")
    private String dmsDealNum;

    @Column(name = "LENDER_SEQ_NUM")
    private String lenderSeqNum;

    @Column(name = "ACCOUNT_NUM")
    private String accountNum;

    @Column(name = "DEALER_ID")
    private String dealerId;

    @Column(name = "VIN")
    private String vin;

    @Column(name = "BUYER_FIRST_NAME")
    private String buyerFirstName;

    @Column(name = "BUYER_LAST_NAME")
    private String buyerLastName;

    @Column(name = "VAULT_DOC_ID")
    private String vaultDocId;

    @Column(name = "FROM_PF")
    private String fromPf;

    @Column(name = "APPLICATION_TYPE")
    private String applicationType;
    
    @Column(name = "AUTHORIZATION_ID")
    private String authorizationId;
    
    @Column(name = "CONTRACT_ID")
    private String contractId;
    
    public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public DeContractValidationId getId() {
        return id;
    }

    public void setId(DeContractValidationId id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getStatusTs() {
        return statusTs;
    }

    public void setStatusTs(Date statusTs) {
        this.statusTs = statusTs;
    }

    public Date getSubmittedTs() {
        return submittedTs;
    }

    public void setSubmittedTs(Date submittedTs) {
        this.submittedTs = submittedTs;
    }

    public String getDmsDealNum() {
        return dmsDealNum;
    }

    public void setDmsDealNum(String dmsDealNum) {
        this.dmsDealNum = dmsDealNum;
    }

    public String getLenderSeqNum() {
        return lenderSeqNum;
    }

    public void setLenderSeqNum(String lenderSeqNum) {
        this.lenderSeqNum = lenderSeqNum;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getBuyerFirstName() {
        return buyerFirstName;
    }

    public void setBuyerFirstName(String buyerFirstName) {
        this.buyerFirstName = buyerFirstName;
    }

    public String getBuyerLastName() {
        return buyerLastName;
    }

    public void setBuyerLastName(String buyerLastName) {
        this.buyerLastName = buyerLastName;
    }

    public String getVaultDocId() {
        return vaultDocId;
    }

    public void setVaultDocId(String vaultDocId) {
        this.vaultDocId = vaultDocId;
    }

    public String getFromPf() {
        return fromPf;
    }

    public void setFromPf(String fromPf) {
        this.fromPf = fromPf;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public String getAuthorizationId() {
		return authorizationId;
	}

	public void setAuthorizationId(String authorizationId) {
		this.authorizationId = authorizationId;
	}

	@Override
	public String toString() {
		return "DeContractValidation [id=" + id + ", status=" + status + ", statusTs=" + statusTs + ", submittedTs="
				+ submittedTs + ", dmsDealNum=" + dmsDealNum + ", lenderSeqNum=" + lenderSeqNum + ", accountNum="
				+ accountNum + ", dealerId=" + dealerId + ", vin=" + vin + ", buyerFirstName=" + buyerFirstName
				+ ", buyerLastName=" + buyerLastName + ", vaultDocId=" + vaultDocId + ", fromPf=" + fromPf
				+ ", applicationType=" + applicationType + ", authorizationId=" + authorizationId + ", contractId="
				+ contractId + "]";
	}

	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (id == null ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeContractValidation other = (DeContractValidation) obj;
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    @Embeddable
    public static class DeContractValidationId implements Serializable {
        private static final long serialVersionUID = 8655885255167692789L;

        public DeContractValidationId() {
            super();
        }

        @Column(name = "DEAL_ID")
        private String dealId;

        @Column(name = "SEQUENCE_ID")
        private String sequenceId;

        public String getDealId() {
            return dealId;
        }

        public void setDealId(String dealId) {
            this.dealId = dealId;
        }

        public String getSequenceId() {
            return sequenceId;
        }

        public void setSequenceId(String sequenceId) {
            this.sequenceId = sequenceId;
        }

        @Override
        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append("DeContractValidationId [dealId=");
            builder.append(dealId);
            builder.append(", sequenceId=");
            builder.append(sequenceId);
            builder.append("]");
            return builder.toString();
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + (dealId == null ? 0 : dealId.hashCode());
            result = prime * result + (sequenceId == null ? 0 : sequenceId.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            DeContractValidationId other = (DeContractValidationId) obj;
            if (dealId == null) {
                if (null != other.dealId) {
                    return false;
                }
            } else if (!dealId.equals(other.dealId)) {
                return false;
            }
            if (sequenceId == null) {
                if (null != other.sequenceId) {
                    return false;
                }
            } else if (!sequenceId.equals(other.sequenceId)) {
                return false;
            }
            return true;
        }
    }
}
