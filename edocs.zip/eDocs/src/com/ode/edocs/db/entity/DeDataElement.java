package com.ode.edocs.db.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

/**
 * The persistent class for the DE_DATA_ELEMENT database table.
 *
 */
@Entity
@Table(name = "CRGATE.DE_DATA_ELEMENT")
public class DeDataElement {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "ELEMENT_NAME")
    private String elementName;

    @Column(name = "ELEMENT_TYPE")
    private String elementType;

    @Column(name = "FINANCE_RETAIL")
    private String financeRetail;

    @Column(name = "FINANCE_LEASE")
    private String financeLease;

    @Column(name = "FINANCE_BALLOON")
    private String financeBalloon;

    @Column(name = "APP_BUSINESS")
    private String appBusiness;

    @Column(name = "APP_BUSINESS_COBUYER")
    private String appBusinessCobuyer;

    @Column(name = "APP_BUSINESS_GUARANTOR")
    private String appBusinessGuarantor;

    @Column(name = "APP_INDIVIDUAL")
    private String appIndividual;

    @Column(name = "APP_INDIVIDUAL_COBUYER")
    private String appIndividualCobuyer;

    @Column(name = "APP_INDIVIDUAL_GUARANTOR")
    private String appIndividualGuarantor;

    // @Column(name="TRIM_FLAG")
    // private String trimFlag;

    @Column(name = "GROUP_NAME")
    private String groupName;

    @Column(name = "DISPLAY_NAME")
    private String displayName;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TS")
    private Date createdTs;

    @Column(name = "IS_DROP_DOWN")
    private String isDropDown;

    @Column(name = "IS_EDITABLE")
    private String isEditable;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "deDataElement")
    @JsonManagedReference
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<DeDataElementXpath> deDataElementXpaths;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "deDataElement")
    @JsonBackReference
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<DeFormElementItem> deFormElementItems;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "deDataElement")
    @JsonManagedReference
    @LazyCollection(LazyCollectionOption.FALSE)
    private DeDocumentReview dcDocumentReview;

    public DeDataElement() {
    }

    public String getIsEditable() {
        return isEditable;
    }

    public void setIsEditable(String isEditable) {
        this.isEditable = isEditable;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIsDropDown() {
        return isDropDown;
    }

    public void setIsDropDown(String isDropDown) {
        this.isDropDown = isDropDown;
    }

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getElementType() {
        return elementType;
    }

    public void setElementType(String elementType) {
        this.elementType = elementType;
    }

    public String getFinanceRetail() {
        return financeRetail;
    }

    public void setFinanceRetail(String financeRetail) {
        this.financeRetail = financeRetail;
    }

    public String getFinanceLease() {
        return financeLease;
    }

    public void setFinanceLease(String financeLease) {
        this.financeLease = financeLease;
    }

    public String getFinanceBalloon() {
        return financeBalloon;
    }

    public void setFinanceBalloon(String financeBalloon) {
        this.financeBalloon = financeBalloon;
    }

    public String getAppBusiness() {
        return appBusiness;
    }

    public void setAppBusiness(String appBusiness) {
        this.appBusiness = appBusiness;
    }

    public String getAppBusinessCobuyer() {
        return appBusinessCobuyer;
    }

    public void setAppBusinessCobuyer(String appBusinessCobuyer) {
        this.appBusinessCobuyer = appBusinessCobuyer;
    }

    public String getAppBusinessGuarantor() {
        return appBusinessGuarantor;
    }

    public void setAppBusinessGuarantor(String appBusinessGuarantor) {
        this.appBusinessGuarantor = appBusinessGuarantor;
    }

    public String getAppIndividual() {
        return appIndividual;
    }

    public void setAppIndividual(String appIndividual) {
        this.appIndividual = appIndividual;
    }

    public String getAppIndividualCobuyer() {
        return appIndividualCobuyer;
    }

    public void setAppIndividualCobuyer(String appIndividualCobuyer) {
        this.appIndividualCobuyer = appIndividualCobuyer;
    }

    public String getAppIndividualGuarantor() {
        return appIndividualGuarantor;
    }

    public void setAppIndividualGuarantor(String appIndividualGuarantor) {
        this.appIndividualGuarantor = appIndividualGuarantor;
    }

    // public String getTrimFlag() {
    // return trimFlag;
    // }
    //
    // public void setTrimFlag(String trimFlag) {
    // this.trimFlag = trimFlag;
    // }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(Date createdTs) {
        this.createdTs = createdTs;
    }

    public List<DeDataElementXpath> getDeDataElementXpaths() {
        return deDataElementXpaths;
    }

    public void setDeDataElementXpaths(List<DeDataElementXpath> deDataElementXpaths) {
        this.deDataElementXpaths = deDataElementXpaths;
    }

    public List<DeFormElementItem> getDeFormElementItem() {
        return deFormElementItems;
    }

    public void setDeFormElementItem(List<DeFormElementItem> deFormElementItem) {
        deFormElementItems = deFormElementItem;
    }

    public DeDocumentReview getDeDocumentReview() {
        return dcDocumentReview;
    }

    public void setDeDocumentReview(DeDocumentReview deDocumentReview) {
        dcDocumentReview = deDocumentReview;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (appBusiness == null ? 0 : appBusiness.hashCode());
        result = prime * result + (appBusinessCobuyer == null ? 0 : appBusinessCobuyer.hashCode());
        result = prime * result + (appBusinessGuarantor == null ? 0 : appBusinessGuarantor.hashCode());
        result = prime * result + (appIndividual == null ? 0 : appIndividual.hashCode());
        result = prime * result + (appIndividualCobuyer == null ? 0 : appIndividualCobuyer.hashCode());
        result = prime * result + (appIndividualGuarantor == null ? 0 : appIndividualGuarantor.hashCode());
        result = prime * result + (createdBy == null ? 0 : createdBy.hashCode());
        result = prime * result + (createdTs == null ? 0 : createdTs.hashCode());
        result = prime * result + (displayName == null ? 0 : displayName.hashCode());
        result = prime * result + (elementName == null ? 0 : elementName.hashCode());
        result = prime * result + (elementType == null ? 0 : elementType.hashCode());
        result = prime * result + (financeBalloon == null ? 0 : financeBalloon.hashCode());
        result = prime * result + (financeLease == null ? 0 : financeLease.hashCode());
        result = prime * result + (financeRetail == null ? 0 : financeRetail.hashCode());
        result = prime * result + (groupName == null ? 0 : groupName.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        result = prime * result + (isDropDown == null ? 0 : isDropDown.hashCode());
        result = prime * result + (isEditable == null ? 0 : isEditable.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeDataElement other = (DeDataElement) obj;
        if (appBusiness == null) {
            if (null != other.appBusiness) {
                return false;
            }
        } else if (!appBusiness.equals(other.appBusiness)) {
            return false;
        }
        if (appBusinessCobuyer == null) {
            if (null != other.appBusinessCobuyer) {
                return false;
            }
        } else if (!appBusinessCobuyer.equals(other.appBusinessCobuyer)) {
            return false;
        }
        if (appBusinessGuarantor == null) {
            if (null != other.appBusinessGuarantor) {
                return false;
            }
        } else if (!appBusinessGuarantor.equals(other.appBusinessGuarantor)) {
            return false;
        }
        if (appIndividual == null) {
            if (null != other.appIndividual) {
                return false;
            }
        } else if (!appIndividual.equals(other.appIndividual)) {
            return false;
        }
        if (appIndividualCobuyer == null) {
            if (null != other.appIndividualCobuyer) {
                return false;
            }
        } else if (!appIndividualCobuyer.equals(other.appIndividualCobuyer)) {
            return false;
        }
        if (appIndividualGuarantor == null) {
            if (null != other.appIndividualGuarantor) {
                return false;
            }
        } else if (!appIndividualGuarantor.equals(other.appIndividualGuarantor)) {
            return false;
        }
        if (createdBy == null) {
            if (null != other.createdBy) {
                return false;
            }
        } else if (!createdBy.equals(other.createdBy)) {
            return false;
        }
        if (createdTs == null) {
            if (null != other.createdTs) {
                return false;
            }
        } else if (!createdTs.equals(other.createdTs)) {
            return false;
        }
        if (displayName == null) {
            if (null != other.displayName) {
                return false;
            }
        } else if (!displayName.equals(other.displayName)) {
            return false;
        }
        if (elementName == null) {
            if (null != other.elementName) {
                return false;
            }
        } else if (!elementName.equals(other.elementName)) {
            return false;
        }
        if (elementType == null) {
            if (null != other.elementType) {
                return false;
            }
        } else if (!elementType.equals(other.elementType)) {
            return false;
        }
        if (financeBalloon == null) {
            if (null != other.financeBalloon) {
                return false;
            }
        } else if (!financeBalloon.equals(other.financeBalloon)) {
            return false;
        }
        if (financeLease == null) {
            if (null != other.financeLease) {
                return false;
            }
        } else if (!financeLease.equals(other.financeLease)) {
            return false;
        }
        if (financeRetail == null) {
            if (null != other.financeRetail) {
                return false;
            }
        } else if (!financeRetail.equals(other.financeRetail)) {
            return false;
        }
        if (groupName == null) {
            if (null != other.groupName) {
                return false;
            }
        } else if (!groupName.equals(other.groupName)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (isDropDown == null) {
            if (null != other.isDropDown) {
                return false;
            }
        } else if (!isDropDown.equals(other.isDropDown)) {
            return false;
        }
        if (isEditable == null) {
            if (null != other.isEditable) {
                return false;
            }
        } else if (!isEditable.equals(other.isEditable)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "DeDataElement [id=" + id + ", elementName=" + elementName + ", elementType=" + elementType
            + ", financeRetail=" + financeRetail + ", financeLease=" + financeLease + ", financeBalloon="
            + financeBalloon + ", appBusiness=" + appBusiness + ", appBusinessCobuyer=" + appBusinessCobuyer
            + ", appBusinessGuarantor=" + appBusinessGuarantor + ", appIndividual=" + appIndividual
            + ", appIndividualCobuyer=" + appIndividualCobuyer + ", appIndividualGuarantor=" + appIndividualGuarantor
            + ", groupName=" + groupName + ", displayName=" + displayName + ", createdBy=" + createdBy + ", createdTs="
            + createdTs + ", isDropDown=" + isDropDown + ", isEditable=" + isEditable + "]";
    }
}
