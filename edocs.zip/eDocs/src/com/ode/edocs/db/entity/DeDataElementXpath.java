package com.ode.edocs.db.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

/**
 * The persistent class for the DE_DATA_ELEMENT_XPATH database table.
 *
 */
@Entity
@Table(name = "CRGATE.DE_DATA_ELEMENT_XPATH")
public class DeDataElementXpath {
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "DATA_ELEMENT_ID")
    private Integer dataElementId;

    @Column(name = "DMS_ID")
    private String dmsId;

    @Column(name = "XPATH")
    private String xpath;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TS")
    private Date createdTs;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DATA_ELEMENT_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    @JsonBackReference
    @NotFound(action = NotFoundAction.IGNORE)
    private DeDataElement deDataElement;

    public DeDataElementXpath() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDataElementId() {
        return dataElementId;
    }

    public void setDataElementId(Integer dataElementId) {
        this.dataElementId = dataElementId;
    }

    public String getDmsId() {
        return dmsId;
    }

    public void setDmsId(String dmsId) {
        this.dmsId = dmsId;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(Date createdTs) {
        this.createdTs = createdTs;
    }

    public DeDataElement getElement() {
        return deDataElement;
    }

    public void setElement(DeDataElement deDataElement) {
        this.deDataElement = deDataElement;
    }

    @Override
    public String toString() {
        return "DeDataElementXpath [id=" + id + ", dataElementId=" + dataElementId + ", dmsId=" + dmsId + ", xpath="
            + xpath + ", createdBy=" + createdBy + ", createdTs=" + createdTs + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (createdBy == null ? 0 : createdBy.hashCode());
        result = prime * result + (createdTs == null ? 0 : createdTs.hashCode());
        result = prime * result + (dataElementId == null ? 0 : dataElementId.hashCode());
        result = prime * result + (deDataElement == null ? 0 : deDataElement.hashCode());
        result = prime * result + (dmsId == null ? 0 : dmsId.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        result = prime * result + (xpath == null ? 0 : xpath.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeDataElementXpath other = (DeDataElementXpath) obj;
        if (createdBy == null) {
            if (null != other.createdBy) {
                return false;
            }
        } else if (!createdBy.equals(other.createdBy)) {
            return false;
        }
        if (createdTs == null) {
            if (null != other.createdTs) {
                return false;
            }
        } else if (!createdTs.equals(other.createdTs)) {
            return false;
        }
        if (dataElementId == null) {
            if (null != other.dataElementId) {
                return false;
            }
        } else if (!dataElementId.equals(other.dataElementId)) {
            return false;
        }
        if (deDataElement == null) {
            if (null != other.deDataElement) {
                return false;
            }
        } else if (!deDataElement.equals(other.deDataElement)) {
            return false;
        }
        if (dmsId == null) {
            if (null != other.dmsId) {
                return false;
            }
        } else if (!dmsId.equals(other.dmsId)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (xpath == null) {
            if (null != other.xpath) {
                return false;
            }
        } else if (!xpath.equals(other.xpath)) {
            return false;
        }
        return true;
    }
}
