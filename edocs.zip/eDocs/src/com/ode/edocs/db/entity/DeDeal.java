package com.ode.edocs.db.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_DEAL")
public class DeDeal implements Serializable {
    private static final long serialVersionUID = -6212345171893742378L;

    @Id
    @Column(name = "DE_DEAL_ID")
    private String dealId;
    @Column(name = "LENDER_DEALER_ID")
    private String lenderDealerId;
    @Column(name = "DMS_DEALER_ID")
    private String dmsDealerId;
    @Column(name = "DMS_DEAL_NUM")
    private String dmsDealNum;
    @Column(name = "VAULT_DOC_ID")
    private String vaultDocId;
    @Column(name = "LENDER_ID")
    private String lenderId;
    @Column(name = "DMS_ID")
    private String dmsId;
    @Column(name = "FINANCE_TYPE")
    private String financeType;
    @Column(name = "VIN")
    private String vin;
    @Column(name = "BUYER_FIRST_NAME")
    private String buyerFirstName;
    @Column(name = "BUYER_LAST_NAME")
    private String buyerLastName;
    @Column(name = "CA_SEQUENCE_ID")
    private String caSequenceId;
    @Column(name = "CA_APPLICATION_NUM")
    private String caApplicationNum;
    @Column(name = "CA_STATUS")
    private String caStatus;
    @Column(name = "CA_STATUS_TS")
    private Date caStatusTs;
    @Column(name = "CA_SUBMITTED_TS")
    private Date caSubmittedTs;
    @Column(name = "CV_SEQUENCE_ID")
    private String cvSequenceId;
    @Column(name = "CV_STATUS")
    private String cvStatus;
    @Column(name = "CV_STATUS_TS")
    private Date cvStatusTs;
    @Column(name = "CV_SUBMITTED_TS")
    private Date cvSubmittedTs;
    @Column(name = "LENDER_SEQ_NUM")
    private String lenderSeqNum;
    @Column(name = "ACCOUNT_NUM")
    private String accountNum;
    @Column(name = "FUNDING_STATUS")
    private String fundingStatus;
    @Column(name = "FUNDING_STATUS_TS")
    private Date fundingStatusTs;
    @Column(name = "DISTRIBUTION_TS")
    private Date distributionTs;
    @Column(name = "ECON_STATUS")
    private String econStatus;
    @Column(name = "ECON_STATUS_TS")
    private Date econStatusTs;
    @Column(name = "ECON_SUBMITTED_TS")
    private Date econSubmittedTs;
    @Column(name = "DEAL_EXECUTION_STATE")
    private String dealExecutionState;
    @Column(name = "CONTRACT_DATE")
    private Date contractDate;
    @Column(name = "SPOT_FLAG")
    private String spotFlag;
    @Column(name = "LATEST_DISTRIBUTION_STATUS")
    private String latestDistributionStatus;
    @Column(name = "DISTRIBUTED_CV_SEQ_ID")
    private String distributedCvSeqId;
    @Column(name = "APPLICATION_TYPE")
    private String applicationType;
    @Column(name = "RECORD_STATE")
    private String recordState;
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
    @Column(name = "MODIFIED_TS")
    private Timestamp modifiedTimestamp;
    @Column(name = "LAST_MODIFIED_TS")
    private Date lastModifiedTs;

    public String getDealId() {
        return dealId;
    }

    public void setDealId(String dealId) {
        this.dealId = dealId;
    }

    public String getLenderDealerId() {
        return lenderDealerId;
    }

    public void setLenderDealerId(String lenderDealerId) {
        this.lenderDealerId = lenderDealerId;
    }

    public String getDmsDealerId() {
        return dmsDealerId;
    }

    public void setDmsDealerId(String dmsDealerId) {
        this.dmsDealerId = dmsDealerId;
    }

    public String getDmsDealNum() {
        return dmsDealNum;
    }

    public void setDmsDealNum(String dmsDealNum) {
        this.dmsDealNum = dmsDealNum;
    }

    public String getVaultDocId() {
        return vaultDocId;
    }

    public void setVaultDocId(String vaultDocId) {
        this.vaultDocId = vaultDocId;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getDmsId() {
        return dmsId;
    }

    public void setDmsId(String dmsId) {
        this.dmsId = dmsId;
    }

    public String getFinanceType() {
        return financeType;
    }

    public void setFinanceType(String financeType) {
        this.financeType = financeType;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getBuyerFirstName() {
        return buyerFirstName;
    }

    public void setBuyerFirstName(String buyerFirstName) {
        this.buyerFirstName = buyerFirstName;
    }

    public String getBuyerLastName() {
        return buyerLastName;
    }

    public void setBuyerLastName(String buyerLastName) {
        this.buyerLastName = buyerLastName;
    }

    public String getCaSequenceId() {
        return caSequenceId;
    }

    public void setCaSequenceId(String caSequenceId) {
        this.caSequenceId = caSequenceId;
    }

    public String getCaApplicationNum() {
        return caApplicationNum;
    }

    public void setCaApplicationNum(String caApplicationNum) {
        this.caApplicationNum = caApplicationNum;
    }

    public String getCaStatus() {
        return caStatus;
    }

    public void setCaStatus(String caStatus) {
        this.caStatus = caStatus;
    }

    public Date getCaStatusTs() {
        return caStatusTs;
    }

    public void setCaStatusTs(Date caStatusTs) {
        this.caStatusTs = caStatusTs;
    }

    public Date getCaSubmittedTs() {
        return caSubmittedTs;
    }

    public void setCaSubmittedTs(Date caSubmittedTs) {
        this.caSubmittedTs = caSubmittedTs;
    }

    public String getCvSequenceId() {
        return cvSequenceId;
    }

    public void setCvSequenceId(String cvSequenceId) {
        this.cvSequenceId = cvSequenceId;
    }

    public String getCvStatus() {
        return cvStatus;
    }

    public void setCvStatus(String cvStatus) {
        this.cvStatus = cvStatus;
    }

    public Date getCvStatusTs() {
        return cvStatusTs;
    }

    public void setCvStatusTs(Date cvStatusTs) {
        this.cvStatusTs = cvStatusTs;
    }

    public Date getCvSubmittedTs() {
        return cvSubmittedTs;
    }

    public void setCvSubmittedTs(Date cvSubmittedTs) {
        this.cvSubmittedTs = cvSubmittedTs;
    }

    public String getLenderSeqNum() {
        return lenderSeqNum;
    }

    public void setLenderSeqNum(String lenderSeqNum) {
        this.lenderSeqNum = lenderSeqNum;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getFundingStatus() {
        return fundingStatus;
    }

    public void setFundingStatus(String fundingStatus) {
        this.fundingStatus = fundingStatus;
    }

    public Date getFundingStatusTs() {
        return fundingStatusTs;
    }

    public void setFundingStatusTs(Date fundingStatusTs) {
        this.fundingStatusTs = fundingStatusTs;
    }

    public Date getDistributionTs() {
        return distributionTs;
    }

    public void setDistributionTs(Date distributionTs) {
        this.distributionTs = distributionTs;
    }

    public String getEconStatus() {
        return econStatus;
    }

    public void setEconStatus(String econStatus) {
        this.econStatus = econStatus;
    }

    public Date getEconStatusTs() {
        return econStatusTs;
    }

    public void setEconStatusTs(Date econStatusTs) {
        this.econStatusTs = econStatusTs;
    }

    public Date getEconSubmittedTs() {
        return econSubmittedTs;
    }

    public void setEconSubmittedTs(Date econSubmittedTs) {
        this.econSubmittedTs = econSubmittedTs;
    }

    public String getDealExecutionState() {
        return dealExecutionState;
    }

    public void setDealExecutionState(String dealExecutionState) {
        this.dealExecutionState = dealExecutionState;
    }

    public Date getContractDate() {
        return contractDate;
    }

    public void setContractDate(Date contractDate) {
        this.contractDate = contractDate;
    }

    public String getSpotFlag() {
        return spotFlag;
    }

    public void setSpotFlag(String spotFlag) {
        this.spotFlag = spotFlag;
    }

    public String getLatestDistributionStatus() {
        return latestDistributionStatus;
    }

    public void setLatestDistributionStatus(String latestDistributionStatus) {
        this.latestDistributionStatus = latestDistributionStatus;
    }

    public String getDistributedCvSeqId() {
        return distributedCvSeqId;
    }

    public void setDistributedCvSeqId(String distributedCvSeqId) {
        this.distributedCvSeqId = distributedCvSeqId;
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public String getRecordState() {
        return recordState;
    }

    public void setRecordState(final String recordState) {
        this.recordState = recordState;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(final String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedTimestamp() {
        return modifiedTimestamp;
    }

    public void setModifiedTimestamp(final Timestamp modifiedTimestamp) {
        this.modifiedTimestamp = modifiedTimestamp;
    }    

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeDeal [dealId=");
		builder.append(dealId);
		builder.append(", lenderDealerId=");
		builder.append(lenderDealerId);
		builder.append(", dmsDealerId=");
		builder.append(dmsDealerId);
		builder.append(", dmsDealNum=");
		builder.append(dmsDealNum);
		builder.append(", vaultDocId=");
		builder.append(vaultDocId);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", dmsId=");
		builder.append(dmsId);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", vin=");
		builder.append(vin);
		builder.append(", buyerFirstName=");
		builder.append(buyerFirstName);
		builder.append(", buyerLastName=");
		builder.append(buyerLastName);
		builder.append(", caSequenceId=");
		builder.append(caSequenceId);
		builder.append(", caApplicationNum=");
		builder.append(caApplicationNum);
		builder.append(", caStatus=");
		builder.append(caStatus);
		builder.append(", caStatusTs=");
		builder.append(caStatusTs);
		builder.append(", caSubmittedTs=");
		builder.append(caSubmittedTs);
		builder.append(", cvSequenceId=");
		builder.append(cvSequenceId);
		builder.append(", cvStatus=");
		builder.append(cvStatus);
		builder.append(", cvStatusTs=");
		builder.append(cvStatusTs);
		builder.append(", cvSubmittedTs=");
		builder.append(cvSubmittedTs);
		builder.append(", lenderSeqNum=");
		builder.append(lenderSeqNum);
		builder.append(", accountNum=");
		builder.append(accountNum);
		builder.append(", fundingStatus=");
		builder.append(fundingStatus);
		builder.append(", fundingStatusTs=");
		builder.append(fundingStatusTs);
		builder.append(", distributionTs=");
		builder.append(distributionTs);
		builder.append(", econStatus=");
		builder.append(econStatus);
		builder.append(", econStatusTs=");
		builder.append(econStatusTs);
		builder.append(", econSubmittedTs=");
		builder.append(econSubmittedTs);
		builder.append(", dealExecutionState=");
		builder.append(dealExecutionState);
		builder.append(", contractDate=");
		builder.append(contractDate);
		builder.append(", spotFlag=");
		builder.append(spotFlag);
		builder.append(", latestDistributionStatus=");
		builder.append(latestDistributionStatus);
		builder.append(", distributedCvSeqId=");
		builder.append(distributedCvSeqId);
		builder.append(", applicationType=");
		builder.append(applicationType);
		builder.append(", recordState=");
		builder.append(recordState);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", modifiedTimestamp=");
		builder.append(modifiedTimestamp);
		builder.append(", lastModifiedTs=");
		builder.append(lastModifiedTs);
		builder.append("]");
		return builder.toString();
	}

	

}
