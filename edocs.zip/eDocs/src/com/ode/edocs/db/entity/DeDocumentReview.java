package com.ode.edocs.db.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

/**
 * The persistent class for the DE_DOCUMENT_REVIEW database table.
 *
 */
@Entity
@Table(name = "CRGATE.DE_DOCUMENT_REVIEW")
public class DeDocumentReview {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "DATA_ELEMENT_ID")
    private Integer dataElementId;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CONTRACT_DATA_ELEMENT_ID")
    private DeContractDataElement deContractDataElement;

    @Column(name = "META_DATA_ELEMENTS")
    private String metaDataElements;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DATA_ELEMENT_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    @JsonManagedReference
    @NotFound(action = NotFoundAction.IGNORE)
    private DeDataElement deDataElement;

    public DeDocumentReview() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMetaDataElements() {
        return metaDataElements;
    }

    public void setMetaDataElements(String metaDataElements) {
        this.metaDataElements = metaDataElements;
    }

    public Integer getDataElementId() {
        return dataElementId;
    }

    public void setDataElementId(Integer dataElementId) {
        this.dataElementId = dataElementId;
    }

    public DeContractDataElement getDeContractDataElement() {
        return deContractDataElement;
    }

    public void setDeContractDataElement(DeContractDataElement deContractDataElement) {
        this.deContractDataElement = deContractDataElement;
    }

    public DeDataElement getDeDataElement() {
        return deDataElement;
    }

    public void setDeDataElement(DeDataElement deDataElement) {
        this.deDataElement = deDataElement;
    }

    @Override
    public String toString() {
        return "DeDocumentReview [id=" + id + ", dataElementId=" + dataElementId + ", metaDataElements="
            + metaDataElements + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (dataElementId == null ? 0 : dataElementId.hashCode());
        result = prime * result + (deContractDataElement == null ? 0 : deContractDataElement.hashCode());
        result = prime * result + (deDataElement == null ? 0 : deDataElement.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        result = prime * result + (metaDataElements == null ? 0 : metaDataElements.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeDocumentReview other = (DeDocumentReview) obj;
        if (dataElementId == null) {
            if (null != other.dataElementId) {
                return false;
            }
        } else if (!dataElementId.equals(other.dataElementId)) {
            return false;
        }
        if (deContractDataElement == null) {
            if (null != other.deContractDataElement) {
                return false;
            }
        } else if (!deContractDataElement.equals(other.deContractDataElement)) {
            return false;
        }
        if (deDataElement == null) {
            if (null != other.deDataElement) {
                return false;
            }
        } else if (!deDataElement.equals(other.deDataElement)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (metaDataElements == null) {
            if (null != other.metaDataElements) {
                return false;
            }
        } else if (!metaDataElements.equals(other.metaDataElements)) {
            return false;
        }
        return true;
    }
}
