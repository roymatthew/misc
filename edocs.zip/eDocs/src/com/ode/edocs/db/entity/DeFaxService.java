package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_FAX_SERVICE")
public class DeFaxService {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "FAX_SERVICE_ID")
	private Integer faxServiceId;

	@Column(name = "LENDER_ID")
	private String lenderId;

	@Column(name = "TRANSACTION_TYPE")
	private String transactionType;
	
	@Column(name = "FAX_NUMBER")
	private String faxNumber;
	
	@Column(name = "FAX_HEADER")
	private String faxHeader;
	
	@Column(name = "CREATED_TS")
	private Date createdTs;
	
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	
	@Column(name = "MODIFIED_BY")
	private String modifyBy;

	public Integer getFaxServiceId() {
		return faxServiceId;
	}

	public void setFaxServiceId(Integer faxServiceId) {
		this.faxServiceId = faxServiceId;
	}

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	
	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getFaxHeader() {
		return faxHeader;
	}

	public void setFaxHeader(String faxHeader) {
		this.faxHeader = faxHeader;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getModifiedTs() {
		return modifiedTs;
	}

	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeFaxService [faxServiceId=");
		builder.append(faxServiceId);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", transactionType=");
		builder.append(transactionType);
		builder.append(", faxNumber=");
		builder.append(faxNumber);
		builder.append(", faxHeader=");
		builder.append(faxHeader);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifyBy=");
		builder.append(modifyBy);
		builder.append("]");
		return builder.toString();
	}

	
}
