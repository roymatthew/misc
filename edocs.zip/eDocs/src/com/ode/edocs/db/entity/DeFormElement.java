package com.ode.edocs.db.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

/**
 * The persistent class for the DE_FORM_ELEMENT database table.
 *
 */
@Entity
@Table(name = "CRGATE.DE_FORM_ELEMENT")
public class DeFormElement {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "DC_DOC_TYPE_ID")
    private Integer dcDocTypeId;

    @Column(name = "LENDER_ID")
    private String lenderId;

    @Column(name = "STATE_ID")
    private String stateId;

    @Column(name = "FORM_NUMBER")
    private String formNumber;

    @Column(name = "REVISION_DATE")
    private Date revisionDate;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "deFormElement")
    @JsonManagedReference
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<DeFormElementItem> deFormElementItems;

    public DeFormElement() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDcDocTypeId() {
        return dcDocTypeId;
    }

    public void setDcDocTypeId(Integer dcDocTypeId) {
        this.dcDocTypeId = dcDocTypeId;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    public String getFormNumber() {
        return formNumber;
    }

    public void setFormNumber(String formNumber) {
        this.formNumber = formNumber;
    }

    public Date getRevisionDate() {
        return revisionDate;
    }

    public void setRevisionDate(Date revisionDate) {
        this.revisionDate = revisionDate;
    }

    public List<DeFormElementItem> getDeFormElementItems() {
        return deFormElementItems;
    }

    public void setDeFormElementItems(List<DeFormElementItem> deFormElementItems) {
        this.deFormElementItems = deFormElementItems;
    }

    @Override
    public String toString() {
        return "DeFormElement [id=" + id + ", dcDocTypeId=" + dcDocTypeId + ", lenderId=" + lenderId + ", stateId="
            + stateId + ", formNumber=" + formNumber + ", revisionDate=" + revisionDate + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (dcDocTypeId == null ? 0 : dcDocTypeId.hashCode());
        result = prime * result + (deFormElementItems == null ? 0 : deFormElementItems.hashCode());
        result = prime * result + (formNumber == null ? 0 : formNumber.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        result = prime * result + (lenderId == null ? 0 : lenderId.hashCode());
        result = prime * result + (revisionDate == null ? 0 : revisionDate.hashCode());
        result = prime * result + (stateId == null ? 0 : stateId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeFormElement other = (DeFormElement) obj;
        if (dcDocTypeId == null) {
            if (null != other.dcDocTypeId) {
                return false;
            }
        } else if (!dcDocTypeId.equals(other.dcDocTypeId)) {
            return false;
        }
        if (deFormElementItems == null) {
            if (null != other.deFormElementItems) {
                return false;
            }
        } else if (!deFormElementItems.equals(other.deFormElementItems)) {
            return false;
        }
        if (formNumber == null) {
            if (null != other.formNumber) {
                return false;
            }
        } else if (!formNumber.equals(other.formNumber)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (lenderId == null) {
            if (null != other.lenderId) {
                return false;
            }
        } else if (!lenderId.equals(other.lenderId)) {
            return false;
        }
        if (revisionDate == null) {
            if (null != other.revisionDate) {
                return false;
            }
        } else if (!revisionDate.equals(other.revisionDate)) {
            return false;
        }
        if (stateId == null) {
            if (null != other.stateId) {
                return false;
            }
        } else if (!stateId.equals(other.stateId)) {
            return false;
        }
        return true;
    }
}
