package com.ode.edocs.db.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

/**
 * The persistent class for the DE_FORM_ELEMENT_ITEM database table.
 *
 */
@Entity
@Table(name = "CRGATE.DE_FORM_ELEMENT_ITEM")
public class DeFormElementItem {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "FORM_ELEMENT_ID")
    private Integer formElementId;

    @Column(name = "DATA_ELEMENT_ID")
    private Integer dataElementId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DATA_ELEMENT_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    @JsonManagedReference
    @NotFound(action = NotFoundAction.IGNORE)
    private DeDataElement deDataElement;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FORM_ELEMENT_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    @JsonBackReference
    @NotFound(action = NotFoundAction.IGNORE)
    private DeFormElement deFormElement;

    public DeFormElementItem() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFormElementId() {
        return formElementId;
    }

    public void setFormElementId(Integer formElementId) {
        this.formElementId = formElementId;
    }

    public Integer getDataElementId() {
        return dataElementId;
    }

    public void seDatatElementId(Integer dataElementId) {
        this.dataElementId = dataElementId;
    }

    public DeDataElement getDeDataElement() {
        return deDataElement;
    }

    public void setDeDataElement(DeDataElement deDataElement) {
        this.deDataElement = deDataElement;
    }

    public DeFormElement getDeFormElement() {
        return deFormElement;
    }

    public void setDeFormElement(DeFormElement deFormElement) {
        this.deFormElement = deFormElement;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (dataElementId == null ? 0 : dataElementId.hashCode());
        result = prime * result + (deDataElement == null ? 0 : deDataElement.hashCode());
        result = prime * result + (deFormElement == null ? 0 : deFormElement.hashCode());
        result = prime * result + (formElementId == null ? 0 : formElementId.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DeFormElementItem other = (DeFormElementItem) obj;
        if (dataElementId == null) {
            if (null != other.dataElementId) {
                return false;
            }
        } else if (!dataElementId.equals(other.dataElementId)) {
            return false;
        }
        if (deDataElement == null) {
            if (null != other.deDataElement) {
                return false;
            }
        } else if (!deDataElement.equals(other.deDataElement)) {
            return false;
        }
        if (deFormElement == null) {
            if (null != other.deFormElement) {
                return false;
            }
        } else if (!deFormElement.equals(other.deFormElement)) {
            return false;
        }
        if (formElementId == null) {
            if (null != other.formElementId) {
                return false;
            }
        } else if (!formElementId.equals(other.formElementId)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "DeFormElementItem [id=" + id + ", formElementId=" + formElementId + ", dataElementId=" + dataElementId
            + "]";
    }
}
