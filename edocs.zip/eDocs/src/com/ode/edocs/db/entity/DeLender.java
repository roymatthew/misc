package com.ode.edocs.db.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_LENDER")
public class DeLender {

	@Id
	@Column(name = "LENDER_ID")
	private String lender_id;
	
	@Column(name = "LENDER_NAME")
	private String lender_name;
	
	@Column(name = "LENDER_ORGANIZATION")
	private String lender_organization;
	
	@Column(name = "EYES_ON_DOC")
	private String eyes_on_doc;
	
	@Column(name = "VAULT_ORG_ID")
	private Integer vault_org_id;
	
	@Column(name = "VAULT_ORG")
	private String vault_org;
	
	@Column(name = "VAULT_USERNAME")
	private String vault_username;
	
	@Column(name = "VAULT_PASSWORD")
	private String vault_password;
	
	@Column(name = "EDOCS_SCHEMA_VERSION")
	private String edocs_schema_version;
	
	@Column(name = "EDOCS_SCNDRY_SCHEMA_VERSION")
	private String edocsSecondarySchemaVersion;
	
	@Column(name = "ANCILLARY_DATA_FLAG")
	private String ancillary_data_flag;
	
	@Column(name = "DOC_REVIEW_FLAG")
	private String doc_review_flag;
	
	@Column(name = "AUTO_CV_FLAG")
	private String auto_cv_flag;
	
	@Column(name = "LENDER_INTEGRATION_FLAG")
	private String lender_integration_flag;
	
	@Column(name = "FILE_SIZE_CHECK")
	private String file_size_check;
	
	@Column(name = "FAX_SOLUTION_FLAG")
	private String fax_solution_flag;
	
	@Column(name = "AUTONOMOUS_DATA_LOOKUP_ENABLED")
	private String autoNomousDataLookupEnabled;
	
	@Column(name = "DOCUMENT_MAPPING_ENABLED")
	private String documentMappingEnabled;

	public String getLender_id() {
		return lender_id;
	}

	public void setLender_id(String lender_id) {
		this.lender_id = lender_id;
	}

	public String getLender_name() {
		return lender_name;
	}

	public void setLender_name(String lender_name) {
		this.lender_name = lender_name;
	}

	public String getLender_organization() {
		return lender_organization;
	}

	public void setLender_organization(String lender_organization) {
		this.lender_organization = lender_organization;
	}

	public String getEyes_on_doc() {
		return eyes_on_doc;
	}

	public void setEyes_on_doc(String eyes_on_doc) {
		this.eyes_on_doc = eyes_on_doc;
	}

	public Integer getVault_org_id() {
		return vault_org_id;
	}

	public void setVault_org_id(Integer vault_org_id) {
		this.vault_org_id = vault_org_id;
	}

	public String getVault_org() {
		return vault_org;
	}

	public void setVault_org(String vault_org) {
		this.vault_org = vault_org;
	}

	public String getVault_username() {
		return vault_username;
	}

	public void setVault_username(String vault_username) {
		this.vault_username = vault_username;
	}

	public String getVault_password() {
		return vault_password;
	}

	public void setVault_password(String vault_password) {
		this.vault_password = vault_password;
	}

	public String getEdocs_schema_version() {
		return edocs_schema_version;
	}

	public void setEdocs_schema_version(String edocs_schema_version) {
		this.edocs_schema_version = edocs_schema_version;
	}

	public String getAncillary_data_flag() {
		return ancillary_data_flag;
	}

	public void setAncillary_data_flag(String ancillary_data_flag) {
		this.ancillary_data_flag = ancillary_data_flag;
	}

	public String getDoc_review_flag() {
		return doc_review_flag;
	}

	public void setDoc_review_flag(String doc_review_flag) {
		this.doc_review_flag = doc_review_flag;
	}

	public String getAuto_cv_flag() {
		return auto_cv_flag;
	}

	public void setAuto_cv_flag(String auto_cv_flag) {
		this.auto_cv_flag = auto_cv_flag;
	}

	public String getLender_integration_flag() {
		return lender_integration_flag;
	}

	public void setLender_integration_flag(String lender_integration_flag) {
		this.lender_integration_flag = lender_integration_flag;
	}
	
	public String getFile_size_check() {
		return file_size_check;
	}
	
	public void setFile_size_check(String file_size_check) {
		this.file_size_check = file_size_check;
	}

	public String getFax_solution_flag() {
		return fax_solution_flag;
	}

	public void setFax_solution_flag(String fax_solution_flag) {
		this.fax_solution_flag = fax_solution_flag;
	}

	public String getAutoNomousDataLookupEnabled() {
		return autoNomousDataLookupEnabled;
	}

	public void setAutoNomousDataLookupEnabled(String autoNomousDataLookupEnabled) {
		this.autoNomousDataLookupEnabled = autoNomousDataLookupEnabled;
	}

	public String getDocumentMappingEnabled() {
		return documentMappingEnabled;
	}

	public void setDocumentMappingEnabled(String documentMappingEnabled) {
		this.documentMappingEnabled = documentMappingEnabled;
	}

	public String getEdocsSecondarySchemaVersion() {
		return edocsSecondarySchemaVersion;
	}

	public void setEdocsSecondarySchemaVersion(String edocsSecondarySchemaVersion) {
		this.edocsSecondarySchemaVersion = edocsSecondarySchemaVersion;
	}

	@Override
	public String toString() {
		return "DeLender [lender_id=" + lender_id + ", lender_name=" + lender_name + ", lender_organization="
				+ lender_organization + ", eyes_on_doc=" + eyes_on_doc + ", vault_org_id=" + vault_org_id
				+ ", vault_org=" + vault_org + ", vault_username=" + vault_username + ", vault_password="
				+ vault_password + ", edocs_schema_version=" + edocs_schema_version + ", edocsSecondarySchemaVersion="
				+ edocsSecondarySchemaVersion + ", ancillary_data_flag=" + ancillary_data_flag + ", doc_review_flag="
				+ doc_review_flag + ", auto_cv_flag=" + auto_cv_flag + ", lender_integration_flag="
				+ lender_integration_flag + ", file_size_check=" + file_size_check + ", fax_solution_flag="
				+ fax_solution_flag + ", autoNomousDataLookupEnabled=" + autoNomousDataLookupEnabled
				+ ", documentMappingEnabled=" + documentMappingEnabled + "]";
	}
}