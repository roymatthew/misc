package com.ode.edocs.db.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_LENDER_DESTINATION")
public class DeLenderDestination {

	@Id
	@Column(name = "DE_LENDER_DESTINATION_ID")
	private int de_lender_destination_id;
	
	@Column(name = "APPLICATION")
	private String application;
	
	@Column(name = "DESTINATION_URL")
	private String destination_url;
	
	@Column(name = "WS_CONTENT_TYPE")
	private String ws_content_type;
	
	@Column(name = "WS_SOAP_ACTION")
	private String ws_soap_action;
	
	@Column(name = "WS_AUTH_TYPE")
	private String ws_auth_type;
	
	@Column(name = "WS_USERNAME")
	private String ws_username;
	
	@Column(name = "WS_PASSWORD")
	private String ws_password;
	
	@Column(name = "DE_LENDER_ID")
	private String de_lender_id;
	
	@Column(name = "PRODUCT")
	private String product;

	public int getDe_lender_destination_id() {
		return de_lender_destination_id;
	}

	public void setDe_lender_destination_id(int de_lender_destination_id) {
		this.de_lender_destination_id = de_lender_destination_id;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getDestination_url() {
		return destination_url;
	}

	public void setDestination_url(String destination_url) {
		this.destination_url = destination_url;
	}

	public String getWs_content_type() {
		return ws_content_type;
	}

	public void setWs_content_type(String ws_content_type) {
		this.ws_content_type = ws_content_type;
	}

	public String getWs_soap_action() {
		return ws_soap_action;
	}

	public void setWs_soap_action(String ws_soap_action) {
		this.ws_soap_action = ws_soap_action;
	}

	public String getWs_auth_type() {
		return ws_auth_type;
	}

	public void setWs_auth_type(String ws_auth_type) {
		this.ws_auth_type = ws_auth_type;
	}

	public String getWs_username() {
		return ws_username;
	}

	public void setWs_username(String ws_username) {
		this.ws_username = ws_username;
	}

	public String getWs_password() {
		return ws_password;
	}

	public void setWs_password(String ws_password) {
		this.ws_password = ws_password;
	}

	public String getDe_lender_id() {
		return de_lender_id;
	}

	public void setDe_lender_id(String de_lender_id) {
		this.de_lender_id = de_lender_id;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeLenderDestination [de_lender_destination_id=");
		builder.append(de_lender_destination_id);
		builder.append(", application=");
		builder.append(application);
		builder.append(", destination_url=");
		builder.append(destination_url);
		builder.append(", ws_content_type=");
		builder.append(ws_content_type);
		builder.append(", ws_soap_action=");
		builder.append(ws_soap_action);
		builder.append(", ws_auth_type=");
		builder.append(ws_auth_type);
		builder.append(", ws_username=");
		builder.append(ws_username);
		builder.append(", ws_password=");
		builder.append(ws_password);
		builder.append(", de_lender_id=");
		builder.append(de_lender_id);
		builder.append(", product=");
		builder.append(product);
		builder.append("]");
		return builder.toString();
	}
}