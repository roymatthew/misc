package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_LENDER_FEATURE")
public class DeLenderFeature {
	
	@Id
	@Column(name = "ID")
	private int id;
	
	@Column(name = "LENDER_ID")
	private String lenderId;
	
	@Column(name = "DMS_ID")
	private String dmsId;
	
	@Column(name = "FEATURE_ID")
	private String featureId;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "CREATED_TS")
	private Date createdTs;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public String getDmsId() {
		return dmsId;
	}

	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}

	public String getFeatureId() {
		return featureId;
	}

	public void setFeatureId(String featureId) {
		this.featureId = featureId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeLenderFeature [id=");
		builder.append(id);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", dmsId=");
		builder.append(dmsId);
		builder.append(", featureId=");
		builder.append(featureId);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append("]");
		return builder.toString();
	}
}