package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_LENDER_PARTNER")
public class DeLenderPartner {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "LENDER_PARTNER_ID")
	private Integer lenderPartnerId;
	
	@Column(name = "LENDER_ID")
	private String lenderId;
	
	@Column(name = "PARTNER_ID")
	private String partnerId;
	
	@Column(name = "PARTNER_NAME")
	private String partnerName;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "CREATED_TS")
	private Date createdTs;

	public Integer getLenderPartnerId() {
		return lenderPartnerId;
	}

	public void setLenderPartnerId(Integer lenderPartnerId) {
		this.lenderPartnerId = lenderPartnerId;
	}

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	@Override
	public String toString() {
		return "DeLenderPartner [lenderPartnerId=" + lenderPartnerId + ", lenderId=" + lenderId + ", partnerId="
				+ partnerId + ", partnerName=" + partnerName + ", createdBy=" + createdBy + ", createdTs=" + createdTs
				+ "]";
	}
}
