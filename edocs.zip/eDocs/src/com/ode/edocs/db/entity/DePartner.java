package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_PARTNER")
public class DePartner {

	@Id
	@Column(name = "PARTNER_ID")
	private String partnerId;

	@Column(name = "LENDER_NAME")
	private String lenderName;
	
	@Column(name = "CREATED_TS")
	private Date createdTs;

	@Column(name = "CREATED_BY")
	private String createdBy;

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getLenderName() {
		return lenderName;
	}

	public void setLenderName(String lenderName) {
		this.lenderName = lenderName;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DePartner [partnerId=");
		builder.append(partnerId);
		builder.append(", lenderName=");
		builder.append(lenderName);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append("]");
		return builder.toString();
	}

}
