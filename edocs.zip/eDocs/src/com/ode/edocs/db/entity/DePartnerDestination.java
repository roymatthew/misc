package com.ode.edocs.db.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_PARTNER_DESTINATION")
public class DePartnerDestination {

	@Id
	@Column(name = "ID")
	private Integer id;

	@Column(name = "DESTINATION_URL")
	private String destinationUrl;
	
	@Column(name = "WS_CONTENT_TYPE")
	private String wsContentType;
	
	@Column(name = "WS_SOAP_ACTION")
	private String wsSoapAction;
	
	@Column(name = "WS_AUTH_TYPE")
	private String wsAuthType;
	
	@Column(name = "WS_USERNAME")
	private String wsUsername;
	
	@Column(name = "WS_PASSWORD")
	private String wsPassword;
	
	@Column(name = "PARTNER_ID")
	private String partnerId;
	
	@Column(name = "PRODUCT")
	private String product;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDestinationUrl() {
		return destinationUrl;
	}

	public void setDestinationUrl(String destinationUrl) {
		this.destinationUrl = destinationUrl;
	}

	public String getWsContentType() {
		return wsContentType;
	}

	public void setWsContentType(String wsContentType) {
		this.wsContentType = wsContentType;
	}

	public String getWsSoapAction() {
		return wsSoapAction;
	}

	public void setWsSoapAction(String wsSoapAction) {
		this.wsSoapAction = wsSoapAction;
	}

	public String getWsAuthType() {
		return wsAuthType;
	}

	public void setWsAuthType(String wsAuthType) {
		this.wsAuthType = wsAuthType;
	}

	public String getWsUsername() {
		return wsUsername;
	}

	public void setWsUsername(String wsUsername) {
		this.wsUsername = wsUsername;
	}

	public String getWsPassword() {
		return wsPassword;
	}

	public void setWsPassword(String wsPassword) {
		this.wsPassword = wsPassword;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DePartnerDestination [id=");
		builder.append(id);
		builder.append(", destinationUrl=");
		builder.append(destinationUrl);
		builder.append(", wsContentType=");
		builder.append(wsContentType);
		builder.append(", wsSoapAction=");
		builder.append(wsSoapAction);
		builder.append(", wsAuthType=");
		builder.append(wsAuthType);
		builder.append(", wsUsername=");
		builder.append(wsUsername);
		builder.append(", wsPassword=");
		builder.append(wsPassword);
		builder.append(", partnerId=");
		builder.append(partnerId);
		builder.append(", product=");
		builder.append(product);
		builder.append("]");
		return builder.toString();
	}

}
