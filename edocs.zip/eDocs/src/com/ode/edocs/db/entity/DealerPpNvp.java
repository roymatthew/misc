package com.ode.edocs.db.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DEALER_PP_NVP")
public class DealerPpNvp implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "DEALER_ID")
    private String dealerId;

    @Id
    @Column(name = "PARTNER_ID")
    private String partnerId;

    @Id
    @Column(name = "PRODUCT_ID")
    private String productId;

    @Column(name = "START_DATE")
    private Date startDate;

    @Column(name = "END_DATE")
    private Date endDate;

    @Column(name = "PARM_NAME")
    private String parmName;

    @Id
    @Column(name = "PARM_VALUE")
    private String parmValue;

    @Column(name = "PARM_SEQUENCE")
    private String parmSequence;

    @Column(name = "DEPT_NO")
    private String deptNo;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "MODIFIED_TS")
    private Date modifiedTs;

    @Column(name = "MODIFIED_BY")
    private String modofiedBy;

    @Column(name = "DSP_ID")
    private String dspId;

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getParmName() {
        return parmName;
    }

    public void setParmName(String parmName) {
        this.parmName = parmName;
    }

    public String getParmValue() {
        return parmValue;
    }

    public void setParmValue(String parmValue) {
        this.parmValue = parmValue;
    }

    public String getParmSequence() {
        return parmSequence;
    }

    public void setParmSequence(String parmSequence) {
        this.parmSequence = parmSequence;
    }

    public String getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getModifiedTs() {
        return modifiedTs;
    }

    public void setModifiedTs(Date modifiedTs) {
        this.modifiedTs = modifiedTs;
    }

    public String getModofiedBy() {
        return modofiedBy;
    }

    public void setModofiedBy(String modofiedBy) {
        this.modofiedBy = modofiedBy;
    }

    public String getDspId() {
        return dspId;
    }

    public void setDspId(String dspId) {
        this.dspId = dspId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DealerPpNvp [");
        if (null != dealerId) {
            builder.append("dealerId=");
            builder.append(dealerId);
            builder.append(", ");
        }
        if (null != partnerId) {
            builder.append("partnerId=");
            builder.append(partnerId);
            builder.append(", ");
        }
        if (null != productId) {
            builder.append("productId=");
            builder.append(productId);
            builder.append(", ");
        }
        if (null != startDate) {
            builder.append("startDate=");
            builder.append(startDate);
            builder.append(", ");
        }
        if (null != endDate) {
            builder.append("endDate=");
            builder.append(endDate);
            builder.append(", ");
        }
        if (null != parmName) {
            builder.append("parmName=");
            builder.append(parmName);
            builder.append(", ");
        }
        if (null != parmValue) {
            builder.append("parmValue=");
            builder.append(parmValue);
            builder.append(", ");
        }
        if (null != parmSequence) {
            builder.append("parmSequence=");
            builder.append(parmSequence);
            builder.append(", ");
        }
        if (null != deptNo) {
            builder.append("deptNo=");
            builder.append(deptNo);
            builder.append(", ");
        }
        if (null != status) {
            builder.append("status=");
            builder.append(status);
            builder.append(", ");
        }
        if (null != modifiedTs) {
            builder.append("modifiedTs=");
            builder.append(modifiedTs);
            builder.append(", ");
        }
        if (null != modofiedBy) {
            builder.append("modofiedBy=");
            builder.append(modofiedBy);
            builder.append(", ");
        }
        if (null != dspId) {
            builder.append("dspId=");
            builder.append(dspId);
        }
        builder.append("]");
        return builder.toString();
    }

}
