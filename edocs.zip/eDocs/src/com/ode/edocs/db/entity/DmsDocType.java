package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DMS_DOC_TYPE")
public class DmsDocType {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "DMS_DOC_TYPE_ID")
	private Integer id;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DC_DOC_TYPE_ID")
	private DcDocType dcDocType;
	@Column(name = "DMS_ID")
	private String dmsId;
	@Column(name = "DOC_NAME")
	private String docName;
	@Column(name = "CREATED_TS")
	private Date createdTs;
	@Column(name = "CREATED_BY")
	private String createdBy;
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "DMS_FORM_ID")
	private String dmsFormId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public DcDocType getDcDocType() {
		return dcDocType;
	}
	public void setDcDocType(DcDocType dcDocType) {
		this.dcDocType = dcDocType;
	}
	public String getDmsId() {
		return dmsId;
	}
	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getDmsFormId() {
		return dmsFormId;
	}
	public void setDmsFormId(String dmsFormId) {
		this.dmsFormId = dmsFormId;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DmsDocType [id=");
		builder.append(id);
		builder.append(", dcDocType=");
		builder.append(dcDocType);
		builder.append(", dmsId=");
		builder.append(dmsId);
		builder.append(", docName=");
		builder.append(docName);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", dmsFormId=");
		builder.append(dmsFormId);
		builder.append("]");
		return builder.toString();
	}
}