package com.ode.edocs.db.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ERROR_LOG", schema = "CRGATE")
public class ErrorLog {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    @Column(name = "DEAL_ID")
    private String dealId;

    @Column(name = "DMS_DEAL_NUM")
    private String dmsDealNum;

    @Column(name = "LENDER_ID")
    private String lenderId;

    @Column(name = "DMS_DEALER_ID")
    private String dmsDealerId;

    @Column(name = "SEQUENCE_ID")
    private String sequenceId;

    @Column(name = "TRANS_TYPE")
    private String transactionType;

    @Column(name = "TRANSACTION_ID")
    private String transactionId;

    @Column(name = "ERROR_CODE")
    private String errorCode;

    @Column(name = "ERROR_MESSAGE")
    private String errorMessage;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TS")
    private Timestamp createdTs;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDealId() {
        return dealId;
    }

    public void setDealId(String dealId) {
        this.dealId = dealId;
    }

    public String getDmsDealNum() {
        return dmsDealNum;
    }

    public void setDmsDealNum(String dmsDealNum) {
        this.dmsDealNum = dmsDealNum;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getDmsDealerId() {
        return dmsDealerId;
    }

    public String getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(String sequenceId) {
        this.sequenceId = sequenceId;
    }

    public void setDmsDealerId(String dmsDealerId) {
        this.dmsDealerId = dmsDealerId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(Timestamp createdTs) {
        this.createdTs = createdTs;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    @Override
    public String toString() {
        return "ErrorLog [id=" + id + ", dealId=" + dealId + ", dmsDealNum=" + dmsDealNum + ", lenderId=" + lenderId
            + ", dmsDealerId=" + dmsDealerId + ", sequenceId=" + sequenceId + ", transactionType=" + transactionType
            + ", transactionId=" + transactionId + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
            + ", createdBy=" + createdBy + ", createdTs=" + createdTs + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (createdBy == null ? 0 : createdBy.hashCode());
        result = prime * result + (createdTs == null ? 0 : createdTs.hashCode());
        result = prime * result + (dealId == null ? 0 : dealId.hashCode());
        result = prime * result + (dmsDealNum == null ? 0 : dmsDealNum.hashCode());
        result = prime * result + (dmsDealerId == null ? 0 : dmsDealerId.hashCode());
        result = prime * result + (errorCode == null ? 0 : errorCode.hashCode());
        result = prime * result + (errorMessage == null ? 0 : errorMessage.hashCode());
        result = prime * result + (id == null ? 0 : id.hashCode());
        result = prime * result + (lenderId == null ? 0 : lenderId.hashCode());
        result = prime * result + (sequenceId == null ? 0 : sequenceId.hashCode());
        result = prime * result + (transactionId == null ? 0 : transactionId.hashCode());
        result = prime * result + (transactionType == null ? 0 : transactionType.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ErrorLog other = (ErrorLog) obj;
        if (createdBy == null) {
            if (null != other.createdBy) {
                return false;
            }
        } else if (!createdBy.equals(other.createdBy)) {
            return false;
        }
        if (createdTs == null) {
            if (null != other.createdTs) {
                return false;
            }
        } else if (!createdTs.equals(other.createdTs)) {
            return false;
        }
        if (dealId == null) {
            if (null != other.dealId) {
                return false;
            }
        } else if (!dealId.equals(other.dealId)) {
            return false;
        }
        if (dmsDealNum == null) {
            if (null != other.dmsDealNum) {
                return false;
            }
        } else if (!dmsDealNum.equals(other.dmsDealNum)) {
            return false;
        }
        if (dmsDealerId == null) {
            if (null != other.dmsDealerId) {
                return false;
            }
        } else if (!dmsDealerId.equals(other.dmsDealerId)) {
            return false;
        }
        if (errorCode == null) {
            if (null != other.errorCode) {
                return false;
            }
        } else if (!errorCode.equals(other.errorCode)) {
            return false;
        }
        if (errorMessage == null) {
            if (null != other.errorMessage) {
                return false;
            }
        } else if (!errorMessage.equals(other.errorMessage)) {
            return false;
        }
        if (id == null) {
            if (null != other.id) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (lenderId == null) {
            if (null != other.lenderId) {
                return false;
            }
        } else if (!lenderId.equals(other.lenderId)) {
            return false;
        }
        if (sequenceId == null) {
            if (null != other.sequenceId) {
                return false;
            }
        } else if (!sequenceId.equals(other.sequenceId)) {
            return false;
        }
        if (transactionId == null) {
            if (null != other.transactionId) {
                return false;
            }
        } else if (!transactionId.equals(other.transactionId)) {
            return false;
        }
        if (transactionType == null) {
            if (null != other.transactionType) {
                return false;
            }
        } else if (!transactionType.equals(other.transactionType)) {
            return false;
        }
        return true;
    }
}
