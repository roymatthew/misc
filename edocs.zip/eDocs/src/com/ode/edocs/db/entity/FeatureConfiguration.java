package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.FEATURE_CONFIGURATION")
public class FeatureConfiguration {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "ID")
	private int	id;
	@Column(name = "LENDER_ID")
	private String lenderId;
	@Column(name = "PRODUCT")
	private String product;
	@Column(name = "FEATURE_NAME")
	private String featureName;
	@Column(name = "FEATURE_VALUE")
	private String featureValue;
	@Column(name = "CREATED_TS")
	private Date createdTs;
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	@Column(name = "DMS_ID")
	private String dmsId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getFeatureName() {
		return featureName;
	}
	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}
	public String getFeatureValue() {
		return featureValue;
	}
	public void setFeatureValue(String featureValue) {
		this.featureValue = featureValue;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getDmsId() {
		return dmsId;
	}
	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FeatureConfiguration [id=");
		builder.append(id);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", product=");
		builder.append(product);
		builder.append(", featureName=");
		builder.append(featureName);
		builder.append(", featureValue=");
		builder.append(featureValue);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", dmsId=");
		builder.append(dmsId);
		builder.append("]");
		return builder.toString();
	}
}
