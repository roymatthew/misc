package com.ode.edocs.db.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.DE_FORM_ELEMENT")
public class FormElementEntity {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "DC_DOC_TYPE_ID")
    private Integer dcDocTypeId;

    @Column(name = "LENDER_ID")
    private String lenderId;

    @Column(name = "STATE_ID")
    private String stateId;

    @Column(name = "FORM_NUMBER")
    private String formNumber;

    @Column(name = "REVISION_DATE")
    private Date revisionDate;

    public FormElementEntity() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDcDocTypeId() {
        return dcDocTypeId;
    }

    public void setDcDocTypeId(Integer dcDocTypeId) {
        this.dcDocTypeId = dcDocTypeId;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    public String getFormNumber() {
        return formNumber;
    }

    public void setFormNumber(String formNumber) {
        this.formNumber = formNumber;
    }

    public Date getRevisionDate() {
        return revisionDate;
    }

    public void setRevisionDate(Date revisionDate) {
        this.revisionDate = revisionDate;
    }

}
