package com.ode.edocs.db.entity;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.FORMS")
public class Forms {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "FORMS_ID")
	private BigInteger formsId;

	@Column(name = "LENDER_CODE")
	private String lenderCode;
	@Column(name = "FORM_NUMBER")
	private String formNumber;
	@Column(name = "REV_DATE")
	private Date revDate;
	@Column(name = "DSP")
	private String dsp;
	@Column(name = "DSP_FORM")
	private String dspForm;
	@Column(name = "DSP_REV")
	private String dspRev;
	@Column(name = "STATE")
	private String state;
	@Column(name = "FORM_DESCRIPTION")
	private String formDescription;
	@Column(name = "FINANCE_TYPE")
	private String financeType;
	@Column(name = "PRODUCT_TYPE")
	private String productType;
	@Column(name = "EFFECTIVE_DATE")
	private Date effectiveDate;
	@Column(name = "EXPIRATION_DATE")
	private Date expiryDate;
	@Column(name = "STATE_GROUP")
	private String stateGroup;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	
	
	public BigInteger getFormsId() {
		return formsId;
	}
	public void setFormsId(BigInteger formsId) {
		this.formsId = formsId;
	}
	public String getLenderCode() {
		return lenderCode;
	}
	public void setLenderCode(String lenderCode) {
		this.lenderCode = lenderCode;
	}
	public String getFormNumber() {
		return formNumber;
	}
	public void setFormNumber(String formNumber) {
		this.formNumber = formNumber;
	}
	public Date getRevDate() {
		return revDate;
	}
	public void setRevDate(Date revDate) {
		this.revDate = revDate;
	}
	public String getDsp() {
		return dsp;
	}
	public void setDsp(String dsp) {
		this.dsp = dsp;
	}
	public String getDspForm() {
		return dspForm;
	}
	public void setDspForm(String dspForm) {
		this.dspForm = dspForm;
	}
	public String getDspRev() {
		return dspRev;
	}
	public void setDspRev(String dspRev) {
		this.dspRev = dspRev;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getFormDescription() {
		return formDescription;
	}
	public void setFormDescription(String formDescription) {
		this.formDescription = formDescription;
	}
	public String getFinanceType() {
		return financeType;
	}
	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getStateGroup() {
		return stateGroup;
	}
	public void setStateGroup(String stateGroup) {
		this.stateGroup = stateGroup;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	
	

}
