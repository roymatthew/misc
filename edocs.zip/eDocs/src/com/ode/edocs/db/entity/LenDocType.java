package com.ode.edocs.db.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.LEN_DOC_TYPE")
public class LenDocType {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "LEN_DOC_TYPE_ID")
	private Integer id;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DC_DOC_TYPE_ID")
	private DcDocType dcDocType;
	@Column(name = "LENDER_ID")
	private String lenderId;
	@Column(name = "DOC_NAME")
	private String docName;
	@Column(name = "CREATED_TS")
	private Date createdTs;
	@Column(name = "CREATED_BY")
	private String createdBy;
	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public DcDocType getDcDocType() {
		return dcDocType;
	}
	public void setDcDocType(DcDocType dcDocType) {
		this.dcDocType = dcDocType;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LenDocType [id=");
		builder.append(id);
		builder.append(", dcDocType=");
		builder.append(dcDocType);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", docName=");
		builder.append(docName);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append("]");
		return builder.toString();
	}

}