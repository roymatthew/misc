package com.ode.edocs.db.repostiory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ode.edocs.db.entity.DeDeal;

//@Repository
public interface DeDealRepository extends JpaRepository<DeDeal, String> {

  public DeDeal findByDealId(final String dealId);
}
