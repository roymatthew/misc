package com.ode.edocs.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.service.IDealService;

@RestController
public class DeDealController {
  
  @Autowired
  private IDealService dealService;
  
  @RequestMapping(value = "/deal/dealId/{dealId}", method = RequestMethod.GET)
  @ResponseBody
  public DeDeal getDeal(@PathVariable final String dealId)
  {
    return dealService.getDeal(dealId);
  }

}
