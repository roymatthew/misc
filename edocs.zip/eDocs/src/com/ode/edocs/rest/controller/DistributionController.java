package com.ode.edocs.rest.controller;

import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.service.IDistributionService;
import com.ode.edocs.util.AppConstants;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class DistributionController {

    private static final Logger logger = LogManager.getLogger(DistributionController.class);

    @Autowired
    private IDistributionService distributionService;

    /**
     * @param requestXML
     * @return
     */
    @RequestMapping(value = "/distributeNew", method = RequestMethod.POST)
    @ResponseBody
    public String distribute(@RequestBody String requestXML) {

        logger.debug("Enter distribute");

        DcDistribution distribution = null;
        String responseMessage = "";
        try {

            distribution = distributionService.handleDistribution(requestXML, new Date());
            if (null != distribution) {
                responseMessage = AppConstants.DISTRIBUTE_SUCCESS_CODE + "-" + AppConstants.DISTRIBUTE_SUCCESS_MESSAGE;
            }

        } catch (final Exception e) {
            logger.error("Unable to begin eDocs process", e);
            responseMessage = e.getMessage();
        }
        logger.debug("Completed Distribution");
        return responseMessage;

    }
}
