package com.ode.edocs.rest.controller;

import com.ode.edocs.db.dao.ErrorLogDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.rest.entity.DocDataReviewResponse;
import com.ode.edocs.rest.entity.DocumentReviewRequest;
import com.ode.edocs.service.IDistributionService;
import com.ode.edocs.service.IDocDataReviewService;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.DistributionHelper;
import com.ode.edocs.util.IHandleDistributeUtil;
import com.ode.edocs.util.MailSender;


import java.util.Date;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EDocsRestService {

    private static final Logger logger = LogManager.getLogger(EDocsRestService.class);

    @Autowired
    IDocDataReviewService docDataReviewService;

    @Autowired
    MailSender mailSender;

    @Autowired
    ErrorLogDAO errorLogDAO;

    @Autowired
    private IDistributionService distributionService;
    
    @Autowired
    private IHandleDistributeUtil handleDistributeImpl;

    @RequestMapping(value = "/distributePacket", method = RequestMethod.POST)
    public @ResponseBody String distributePacket(@RequestBody String requestXML) throws Exception {

        logger.debug("Entered distributePacket() method");
        long startTime = System.nanoTime();
        final UUID uuid = UUID.randomUUID();
        ThreadContext.put("uuid", uuid.toString());
        final Date currentDate = new Date();
        String responseMessage = "";
        DcDistribution distribution = null;
        try {
            distribution = distributionService.handleDistribution(requestXML, currentDate);
            if (null != distribution) {
                responseMessage = AppConstants.DISTRIBUTE_SUCCESS_CODE + "-" + AppConstants.DISTRIBUTE_SUCCESS_MESSAGE;
                logger.debug(responseMessage);
            }
        } catch (final ApplicationException ae) {
            logger.error("Distribution process failed", ae);
            throw ae;
        } catch (final Exception e) {
            logger.error("Distribution process failed", e);
            throw e;
        }

        logger.debug("Exit distributePacket()");
        long endTime = System.nanoTime();
        logger.debug("Execution time: " + (endTime - startTime) / 1000000 + "ms");
        return responseMessage;
    }

    /**
     * Compare latest ancillary data from DcDocData table for a document against ECOUT contract data, and update the
     * DcDocData document review answers Return the list of document review answers to caller
     */
    @RequestMapping(value = "/documentReview", method = RequestMethod.POST)
    public @ResponseBody DocDataReviewResponse documentReview(@RequestBody DocumentReviewRequest request) {
        logger.debug("Entered  documentReview(@RequestBody DocumentReviewRequest request) method");
        DocDataReviewResponse response = docDataReviewService.documentReview(request);
        return response;
    }

    /**
     * Eyes on Doc is enabled for Lender. Resume distribution process after documents are reviewed
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/resumeDistribution", method = RequestMethod.POST)
    public @ResponseBody Boolean resumeDistribution(@RequestBody DistributionHelper request) {
        logger.debug("Entered  resumeDistribution(@RequestBody DistributionHelper request) method");
        return handleDistributeImpl.resumeDistribution(request);
    }

    @ExceptionHandler({ Exception.class })
    public @ResponseBody String handleException(final Exception ex) {
        logger.debug("Entered handleException()");
        // return new ResponseEntity<Object>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        String responseMessage = "";
        if (ex != null && ex.getMessage() != null) {
            responseMessage = AppConstants.UNEXPECTED_ERROR_CODE + "-" + ex.getMessage();
        } else {
            responseMessage = AppConstants.UNEXPECTED_ERROR_CODE + "-" + AppConstants.UNEXPECTED_ERROR_MESSAGE;
        }
        return responseMessage;
    }

    @ExceptionHandler({ ApplicationException.class })
    public @ResponseBody String handleApplicationException(final ApplicationException ex) {
        logger.debug("Entered handleApplicationException()");
        // return new ResponseEntity<Object>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        String responseMessage = "";
        if (ex != null) {
        	if (ex.getMessage() != null && ex.getCode() != null) {
                responseMessage = ex.getCode() + "-" + ex.getMessage();
            } else if (ex.getCode() != null) {
                responseMessage = ex.getCode();
            } else {
                return handleException(ex);
            }
        } else {
            return handleException(ex);
        }
        return responseMessage;
    }
}
