package com.ode.edocs.rest.entity;

import java.util.List;
import com.ode.edocs.db.entity.DcDocData;

public class DocDataReviewResponse {
	private Boolean docDataUpdated;
	private Boolean documentMarkedAsReviewed;
	private Boolean documentMarkedAsComplete;
	private Boolean distributionMarkedAsReviewed;
	private Boolean distributionMarkedAsReadyToBook;
	private Boolean errorOnDocReview;
	private String errorMessage;
	private List<DcDocData> latestDcDocData;
	
	public DocDataReviewResponse() {
		this.docDataUpdated = true;
		this.documentMarkedAsReviewed = true;
		this.distributionMarkedAsReviewed = false;
	}
	
	public Boolean getErrorOnDocReview() {
		return errorOnDocReview;
	}

	public void setErrorOnDocReview(Boolean errorOnDocReview) {
		this.errorOnDocReview = errorOnDocReview;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Boolean getDocDataUpdated() {
		return docDataUpdated;
	}

	public void setDocDataUpdated(Boolean docDataUpdated) {
		this.docDataUpdated = docDataUpdated;
	}

	public Boolean getDocumentMarkedAsReviewed() {
		return documentMarkedAsReviewed;
	}

	public void setDocumentMarkedAsReviewed(Boolean documentMarkedAsReviewed) {
		this.documentMarkedAsReviewed = documentMarkedAsReviewed;
	}

	public Boolean getDocumentMarkedAsComplete() {
		return documentMarkedAsComplete;
	}

	public void setDocumentMarkedAsComplete(Boolean documentMarkedAsComplete) {
		this.documentMarkedAsComplete = documentMarkedAsComplete;
	}

	public Boolean getDistributionMarkedAsReviewed() {
		return distributionMarkedAsReviewed;
	}

	public void setDistributionMarkedAsReviewed(Boolean distributionMarkedAsReviewed) {
		this.distributionMarkedAsReviewed = distributionMarkedAsReviewed;
	}

	public Boolean getDistributionMarkedAsReadyToBook() {
		return distributionMarkedAsReadyToBook;
	}

	public void setDistributionMarkedAsReadyToBook(Boolean distributionMarkedAsReadyToBook) {
		this.distributionMarkedAsReadyToBook = distributionMarkedAsReadyToBook;
	}

	public List<DcDocData> getLatestDcDocData() {
		return latestDcDocData;
	}

	public void setLatestDcDocData(List<DcDocData> latestDcDocData) {
		this.latestDcDocData = latestDcDocData;
	}
	
	
}
