package com.ode.edocs.rest.entity;

public class DocumentReviewRequest {
    private String lenderId;
    private String dmsDealId;
    private String dealerId;
    private String partnerId;
    private String deDealId;
    private String dmsId;
    private String contractExecutionState;
    private String lenderDocName;
    private String distSequenceId;
    private String passedCVSequenceId;
    private String modifiedBy;
    private Integer dmsDocTypeId;
    private Integer dcDocumentId;

    public DocumentReviewRequest() {
    }

    public String getPassedCVSequenceId() {
        return passedCVSequenceId;
    }

    public void setPassedCVSequenceId(String passedCVSequenceId) {
        this.passedCVSequenceId = passedCVSequenceId;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getDistSequenceId() {
        return distSequenceId;
    }

    public void setDistSequenceId(String distSequenceId) {
        this.distSequenceId = distSequenceId;
    }

    public String getLenderDocName() {
        return lenderDocName;
    }

    public void setLenderDocName(String lenderDocName) {
        this.lenderDocName = lenderDocName;
    }

    public String getContractExecutionState() {
        return contractExecutionState;
    }

    public void setContractExecutionState(String contractExecutionState) {
        this.contractExecutionState = contractExecutionState;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getDmsDealId() {
        return dmsDealId;
    }

    public void setDmsDealId(String dmsDealId) {
        this.dmsDealId = dmsDealId;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getDeDealId() {
        return deDealId;
    }

    public void setDeDealId(String deDealId) {
        this.deDealId = deDealId;
    }

    public String getDmsId() {
        return dmsId;
    }

    public void setDmsId(String dmsId) {
        this.dmsId = dmsId;
    }

    public Integer getDmsDocTypeId() {
        return dmsDocTypeId;
    }

    public void setDmsDocTypeId(Integer dmsDocTypeId) {
        this.dmsDocTypeId = dmsDocTypeId;
    }

    public Integer getDcDocumentId() {
        return dcDocumentId;
    }

    public void setDcDocumentId(Integer dcDocumentId) {
        this.dcDocumentId = dcDocumentId;
    }

    @Override
    public String toString() {
        return "DocumentReviewRequest [lenderId=" + lenderId + ", dmsDealId=" + dmsDealId + ", dealerId=" + dealerId
            + ", partnerId=" + partnerId + ", deDealId=" + deDealId + ", dmsId=" + dmsId + ", dmsDocTypeId="
            + dmsDocTypeId + ", dcDocumentId=" + dcDocumentId + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (dcDocumentId == null ? 0 : dcDocumentId.hashCode());
        result = prime * result + (deDealId == null ? 0 : deDealId.hashCode());
        result = prime * result + (dealerId == null ? 0 : dealerId.hashCode());
        result = prime * result + (dmsDealId == null ? 0 : dmsDealId.hashCode());
        result = prime * result + (dmsDocTypeId == null ? 0 : dmsDocTypeId.hashCode());
        result = prime * result + (dmsId == null ? 0 : dmsId.hashCode());
        result = prime * result + (lenderId == null ? 0 : lenderId.hashCode());
        result = prime * result + (partnerId == null ? 0 : partnerId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DocumentReviewRequest other = (DocumentReviewRequest) obj;
        if (dcDocumentId == null) {
            if (null != other.dcDocumentId) {
                return false;
            }
        } else if (!dcDocumentId.equals(other.dcDocumentId)) {
            return false;
        }
        if (deDealId == null) {
            if (null != other.deDealId) {
                return false;
            }
        } else if (!deDealId.equals(other.deDealId)) {
            return false;
        }
        if (dealerId == null) {
            if (null != other.dealerId) {
                return false;
            }
        } else if (!dealerId.equals(other.dealerId)) {
            return false;
        }
        if (dmsDealId == null) {
            if (null != other.dmsDealId) {
                return false;
            }
        } else if (!dmsDealId.equals(other.dmsDealId)) {
            return false;
        }
        if (dmsDocTypeId == null) {
            if (null != other.dmsDocTypeId) {
                return false;
            }
        } else if (!dmsDocTypeId.equals(other.dmsDocTypeId)) {
            return false;
        }
        if (dmsId == null) {
            if (null != other.dmsId) {
                return false;
            }
        } else if (!dmsId.equals(other.dmsId)) {
            return false;
        }
        if (lenderId == null) {
            if (null != other.lenderId) {
                return false;
            }
        } else if (!lenderId.equals(other.lenderId)) {
            return false;
        }
        if (partnerId == null) {
            if (null != other.partnerId) {
                return false;
            }
        } else if (!partnerId.equals(other.partnerId)) {
            return false;
        }
        return true;
    }
}
