package com.ode.edocs.rest.entity;

public class ErrorDetail {
    private String dealId;
    private String dmsDealNum;
    private String lenderId;
    private String distributionId;
    private String transactionId;
    private String code;
    private String message;
    private String dealerId;
    private String transactionType;

    public ErrorDetail() {
        dealId = "";
        transactionType = "";
    }

    public ErrorDetail(String message, String code) {
        dealId = "";
        transactionType = "";
        this.code = code;
        this.message = message;
    }

    public ErrorDetail add(String message, String code) {
        this.code = code;
        this.message = message;
        return this;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getDealId() {
        return dealId;
    }

    public void setDealId(String dealId) {
        this.dealId = dealId;
    }

    public String getDmsDealNum() {
        return dmsDealNum;
    }

    public void setDmsDealNum(String dmsDealNum) {
        this.dmsDealNum = dmsDealNum;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getDistributionId() {
        return distributionId;
    }

    public void setDistributionId(String distributionId) {
        this.distributionId = distributionId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ErrorDetail [dealId=" + dealId + ", dmsDealNum=" + dmsDealNum + ", lenderId=" + lenderId
            + ", distributionId=" + distributionId + ", transactionId=" + transactionId + ", code=" + code
            + ", message=" + message + ", dealerId=" + dealerId + ", transactionType=" + transactionType + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (code == null ? 0 : code.hashCode());
        result = prime * result + (dealId == null ? 0 : dealId.hashCode());
        result = prime * result + (dealerId == null ? 0 : dealerId.hashCode());
        result = prime * result + (distributionId == null ? 0 : distributionId.hashCode());
        result = prime * result + (dmsDealNum == null ? 0 : dmsDealNum.hashCode());
        result = prime * result + (lenderId == null ? 0 : lenderId.hashCode());
        result = prime * result + (message == null ? 0 : message.hashCode());
        result = prime * result + (transactionId == null ? 0 : transactionId.hashCode());
        result = prime * result + (transactionType == null ? 0 : transactionType.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ErrorDetail other = (ErrorDetail) obj;
        if (code == null) {
            if (null != other.code) {
                return false;
            }
        } else if (!code.equals(other.code)) {
            return false;
        }
        if (dealId == null) {
            if (null != other.dealId) {
                return false;
            }
        } else if (!dealId.equals(other.dealId)) {
            return false;
        }
        if (dealerId == null) {
            if (null != other.dealerId) {
                return false;
            }
        } else if (!dealerId.equals(other.dealerId)) {
            return false;
        }
        if (distributionId == null) {
            if (null != other.distributionId) {
                return false;
            }
        } else if (!distributionId.equals(other.distributionId)) {
            return false;
        }
        if (dmsDealNum == null) {
            if (null != other.dmsDealNum) {
                return false;
            }
        } else if (!dmsDealNum.equals(other.dmsDealNum)) {
            return false;
        }
        if (lenderId == null) {
            if (null != other.lenderId) {
                return false;
            }
        } else if (!lenderId.equals(other.lenderId)) {
            return false;
        }
        if (message == null) {
            if (null != other.message) {
                return false;
            }
        } else if (!message.equals(other.message)) {
            return false;
        }
        if (transactionId == null) {
            if (null != other.transactionId) {
                return false;
            }
        } else if (!transactionId.equals(other.transactionId)) {
            return false;
        }
        if (transactionType == null) {
            if (null != other.transactionType) {
                return false;
            }
        } else if (!transactionType.equals(other.transactionType)) {
            return false;
        }
        return true;
    }
}
