package com.ode.edocs.rest.entity;

public class FaxDocument {

    private int dcDocumentId;
    private String docName;
    private String docFormat;
    private String contents;

    public int getDcDocumentId() {
        return dcDocumentId;
    }

    public void setDcDocumentId(int dcDocumentId) {
        this.dcDocumentId = dcDocumentId;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocFormat() {
        return docFormat;
    }

    public void setDocFormat(String docFormat) {
        this.docFormat = docFormat;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FaxDocument [dcDocumentId=");
        builder.append(dcDocumentId);
        builder.append(", docName=");
        builder.append(docName);
        builder.append(", docFormat=");
        builder.append(docFormat);
        builder.append(", contents=");
        if (null != contents && !contents.isEmpty()) {
            builder.append("base64string");
        }
        builder.append("]");
        return builder.toString();
    }
}
