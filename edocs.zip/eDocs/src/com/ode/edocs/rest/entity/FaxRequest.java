package com.ode.edocs.rest.entity;

import java.util.List;

public class FaxRequest {

	private String deDealId;
	private String distSequenceId;
	private String recipientFaxNumber;
	private String headerDetails;
	private String bodId;
	private String sendConfirmationFlag;
	private List<FaxDocument> documents;
	
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}
	public String getDistSequenceId() {
		return distSequenceId;
	}
	public void setDistSequenceId(String distSequenceId) {
		this.distSequenceId = distSequenceId;
	}
	
	public List<FaxDocument> getDocuments() {
		return documents;
	}
	public void setDocuments(List<FaxDocument> documents) {
		this.documents = documents;
	}
	public String getRecipientFaxNumber() {
		return recipientFaxNumber;
	}
	public void setRecipientFaxNumber(String recipientFaxNumber) {
		this.recipientFaxNumber = recipientFaxNumber;
	}
	public String getHeaderDetails() {
		return headerDetails;
	}
	public void setHeaderDetails(String headerDetails) {
		this.headerDetails = headerDetails;
	}
	public String getBodId() {
		return bodId;
	}
	public void setBodId(String bodId) {
		this.bodId = bodId;
	}
	public String getSendConfirmationFlag() {
		return sendConfirmationFlag;
	}

	public void setSendConfirmationFlag(String sendConfirmationFlag) {
		this.sendConfirmationFlag = sendConfirmationFlag;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FaxRequest [deDealId=");
		builder.append(deDealId);
		builder.append(", distSequenceId=");
		builder.append(distSequenceId);
		builder.append(", recipientFaxNumber=");
		builder.append(recipientFaxNumber);
		builder.append(", headerDetails=");
		builder.append(headerDetails);
		builder.append(", bodId=");
		builder.append(bodId);
		builder.append(", sendConfirmationFlag=");
		builder.append(sendConfirmationFlag);
		builder.append(", documents=");
		builder.append(documents);
		builder.append("]");
		return builder.toString();
	}
	
	
}
