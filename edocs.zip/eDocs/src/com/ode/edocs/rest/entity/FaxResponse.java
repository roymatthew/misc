package com.ode.edocs.rest.entity;

public class FaxResponse {
	
	private String efaxIn;
	private String faxResponseCode;
	private String faxResponseMessage;
	
	public FaxResponse() {
		faxResponseCode = "";
		faxResponseMessage = "";
	}
	
	public String getEfaxIn() {
		return efaxIn;
	}
	public void setEfaxIn(String efaxIn) {
		this.efaxIn = efaxIn;
	}
	public String getFaxResponseCode() {
		return faxResponseCode;
	}
	public void setFaxResponseCode(String faxResponseCode) {
		this.faxResponseCode = faxResponseCode;
	}
	public String getFaxResponseMessage() {
		return faxResponseMessage;
	}
	public void setFaxResponseMessage(String faxResponseMessage) {
		this.faxResponseMessage = faxResponseMessage;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FaxResponse [efaxIn=");
		builder.append(efaxIn);
		if (faxResponseCode != null) {
			builder.append(", faxResponseCode=");
			builder.append(faxResponseCode);
		}
		if (faxResponseMessage != null) {
			builder.append(", faxResponseMessage=");
			builder.append(faxResponseMessage);
		}
		builder.append("]");
		return builder.toString();
	}

}
