package com.ode.edocs.rest.entity;

public class FormElementKey {
    private Integer dcDocTypeId;
    private String lenderId;
    private String stateId;

    public Integer getDcDocTypeId() {
        return dcDocTypeId;
    }

    public void setDcDocTypeId(Integer dcDocTypeId) {
        this.dcDocTypeId = dcDocTypeId;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    @Override
    public String toString() {
        return "FormElementKey [dcDocTypeId=" + dcDocTypeId + ", lenderId=" + lenderId + ", stateId=" + stateId + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (dcDocTypeId == null ? 0 : dcDocTypeId.hashCode());
        result = prime * result + (lenderId == null ? 0 : lenderId.hashCode());
        result = prime * result + (stateId == null ? 0 : stateId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        FormElementKey other = (FormElementKey) obj;
        if (dcDocTypeId == null) {
            if (null != other.dcDocTypeId) {
                return false;
            }
        } else if (!dcDocTypeId.equals(other.dcDocTypeId)) {
            return false;
        }
        if (lenderId == null) {
            if (null != other.lenderId) {
                return false;
            }
        } else if (!lenderId.equals(other.lenderId)) {
            return false;
        }
        if (stateId == null) {
            if (null != other.stateId) {
                return false;
            }
        } else if (!stateId.equals(other.stateId)) {
            return false;
        }
        return true;
    }

}
