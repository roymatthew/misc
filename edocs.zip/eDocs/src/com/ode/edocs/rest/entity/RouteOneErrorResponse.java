package com.ode.edocs.rest.entity;

public class RouteOneErrorResponse {
	
	private String status;
	private String routeOneErrorCode;
	private String errorMessage;
	private String developerMessage;
	private String detailsLocation;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRouteOneErrorCode() {
		return routeOneErrorCode;
	}
	public void setRouteOneErrorCode(String routeOneErrorCode) {
		this.routeOneErrorCode = routeOneErrorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getDeveloperMessage() {
		return developerMessage;
	}
	public void setDeveloperMessage(String developerMessage) {
		this.developerMessage = developerMessage;
	}
	public String getDetailsLocation() {
		return detailsLocation;
	}
	public void setDetailsLocation(String detailsLocation) {
		this.detailsLocation = detailsLocation;
	}
	@Override
	public String toString() {
		return "RouteOneErrorResponse [status=" + status + ", routeOneErrorCode=" + routeOneErrorCode
				+ ", errorMessage=" + errorMessage + ", developerMessage=" + developerMessage + ", detailsLocation="
				+ detailsLocation + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((detailsLocation == null) ? 0 : detailsLocation.hashCode());
		result = prime * result + ((developerMessage == null) ? 0 : developerMessage.hashCode());
		result = prime * result + ((errorMessage == null) ? 0 : errorMessage.hashCode());
		result = prime * result + ((routeOneErrorCode == null) ? 0 : routeOneErrorCode.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RouteOneErrorResponse other = (RouteOneErrorResponse) obj;
		if (detailsLocation == null) {
			if (other.detailsLocation != null)
				return false;
		} else if (!detailsLocation.equals(other.detailsLocation))
			return false;
		if (developerMessage == null) {
			if (other.developerMessage != null)
				return false;
		} else if (!developerMessage.equals(other.developerMessage))
			return false;
		if (errorMessage == null) {
			if (other.errorMessage != null)
				return false;
		} else if (!errorMessage.equals(other.errorMessage))
			return false;
		if (routeOneErrorCode == null) {
			if (other.routeOneErrorCode != null)
				return false;
		} else if (!routeOneErrorCode.equals(other.routeOneErrorCode))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	
}
