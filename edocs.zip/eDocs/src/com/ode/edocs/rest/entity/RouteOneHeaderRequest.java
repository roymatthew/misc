package com.ode.edocs.rest.entity;

import java.io.Serializable;

public class RouteOneHeaderRequest implements Serializable{
	private static final long serialVersionUID = -1095478566847026448L;
	private String xml;
	private String dealerId;
	private String dealerProductId;
	private String partnerProductId;
	private String URL;
	private String dmsId;
	private String verb;
	private String authorizationId;
	private String partnerId;

	public String getXml() {
		return xml;
	}

	public void setXml(String xml) {
		this.xml = xml;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getURL() {
		return URL;
	}

	public void setURL(String uRL) {
		URL = uRL;
	}

	public String getDmsId() {
		return dmsId;
	}

	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}

	public String getVerb() {
		return verb;
	}

	public void setVerb(String verb) {
		this.verb = verb;
	}

	public String getAuthorizationId() {
		return authorizationId;
	}

	public void setAuthorizationId(String authorizationId) {
		this.authorizationId = authorizationId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getDealerProductId() {
		return dealerProductId;
	}

	public void setDealerProductId(String dealerProductId) {
		this.dealerProductId = dealerProductId;
	}

	public String getPartnerProductId() {
		return partnerProductId;
	}

	public void setPartnerProductId(String partnerProductId) {
		this.partnerProductId = partnerProductId;
	}

	@Override
	public String toString() {
		return "HMACInput [xml=" + xml + ", dealerId=" + dealerId + ", dealerProductId=" + dealerProductId
				+ ", partnerProductId=" + partnerProductId + ", URL=" + URL + ", dmsId=" + dmsId + ", verb=" + verb
				+ ", authorizationId=" + authorizationId + ", partnerId=" + partnerId + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((URL == null) ? 0 : URL.hashCode());
		result = prime * result + ((authorizationId == null) ? 0 : authorizationId.hashCode());
		result = prime * result + ((dealerId == null) ? 0 : dealerId.hashCode());
		result = prime * result + ((dealerProductId == null) ? 0 : dealerProductId.hashCode());
		result = prime * result + ((dmsId == null) ? 0 : dmsId.hashCode());
		result = prime * result + ((partnerId == null) ? 0 : partnerId.hashCode());
		result = prime * result + ((partnerProductId == null) ? 0 : partnerProductId.hashCode());
		result = prime * result + ((verb == null) ? 0 : verb.hashCode());
		result = prime * result + ((xml == null) ? 0 : xml.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RouteOneHeaderRequest other = (RouteOneHeaderRequest) obj;
		if (URL == null) {
			if (other.URL != null)
				return false;
		} else if (!URL.equals(other.URL))
			return false;
		if (authorizationId == null) {
			if (other.authorizationId != null)
				return false;
		} else if (!authorizationId.equals(other.authorizationId))
			return false;
		if (dealerId == null) {
			if (other.dealerId != null)
				return false;
		} else if (!dealerId.equals(other.dealerId))
			return false;
		if (dealerProductId == null) {
			if (other.dealerProductId != null)
				return false;
		} else if (!dealerProductId.equals(other.dealerProductId))
			return false;
		if (dmsId == null) {
			if (other.dmsId != null)
				return false;
		} else if (!dmsId.equals(other.dmsId))
			return false;
		if (partnerId == null) {
			if (other.partnerId != null)
				return false;
		} else if (!partnerId.equals(other.partnerId))
			return false;
		if (partnerProductId == null) {
			if (other.partnerProductId != null)
				return false;
		} else if (!partnerProductId.equals(other.partnerProductId))
			return false;
		if (verb == null) {
			if (other.verb != null)
				return false;
		} else if (!verb.equals(other.verb))
			return false;
		if (xml == null) {
			if (other.xml != null)
				return false;
		} else if (!xml.equals(other.xml))
			return false;
		return true;
	}
}
