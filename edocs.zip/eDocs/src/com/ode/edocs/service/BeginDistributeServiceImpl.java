package com.ode.edocs.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ode.edocs.File;
import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.ReCVData;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DcDistribution.DcDistributionId;
import com.ode.edocs.db.entity.DcDocType;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderFeature;
import com.ode.edocs.db.entity.DmsDocType;
import com.ode.edocs.db.entity.LenDocType;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.IAftermarketProductsUtil;
import com.ode.edocs.util.IHandleDistributeUtil;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.XMLConstants;
import com.ode.edocs.vo.BeginCompleteProcessingVO;

@Service
public class BeginDistributeServiceImpl implements IBeginDistributeService {

	private static final Logger logger = LogManager.getLogger(BeginDistributeServiceImpl.class);

	@Autowired
	public MetaDataHandler metaDataHandler;
	@Autowired
	public IDmsDocTypeDAOService dmsdocTypeService;
	@Autowired
	public ILenDocTypeDAOService lenDocTypeService;
	@Autowired
	public ICreditJournalService creditJournalService;
	@Autowired
	public IDealService dealService;
	@Autowired
	public IDistributionService distributionService;
	@Autowired
	public ICompleteDistributeService completeDistributeService;
	@Autowired
	public IHandleDistributeUtil handleDistributeUtil;
	@Autowired
	private IDcDocumentService dcDocumentService;
	@Autowired
	private IValidationUtil validationUtil;
	@Autowired
	private IFileMetadataService fileMetaDataService;
	@Autowired
	private IAftermarketProductsUtil aftermarketProductsUtil;
	@Autowired
	private IDeLenderFeatureService deLenderFeatureServiceImpl;

	@Value("${baseAutonomousRFLForVCI}")
	private String baseAutonomousRFLForVCI;

	@Override
	public DcDistribution beginDistribute(final BeginCompleteProcessingVO beginCompleteProcessingVO, DeLender lender,
			DeDeal deDeal, ReCVData autoReCv, CreditJournal cjEcout, DeContractValidation cv, ErrorDetail errorDetail, boolean isRouteOneTransaction)
			throws Exception {

		Date date = new Date();
		final LocalDateTime start = LocalDateTime.now();

		logger.debug("Entered beginDistribute method");
		beginCompleteProcessingVO.setDealerId(deDeal.getDmsDealerId());
		beginCompleteProcessingVO.setDeDealId(deDeal.getDealId());
		String cvSequenceId = cv.getId().getSequenceId();
		beginCompleteProcessingVO.setEcout(null);

		List<DcDistribution> distributions = distributionService.find(beginCompleteProcessingVO.getDeDealId());
		String dmsId = EdocsXmlUtils.getDmsId(beginCompleteProcessingVO.geteDocIn());
		String lenderId = lender.getLender_id();

		if (null != autoReCv && AppConstants.AUTO_RE_CV_VALIDATION_VALID.equals(autoReCv.getAutoCvValidationStatus())) {
			beginCompleteProcessingVO.setEcout(EdocsXmlUtils.getDocumentFromString(autoReCv.getAutoCvOut()));
			beginCompleteProcessingVO.setTransactionId(autoReCv.getTransactionId());
			creditJournalService.updateEDocIn(beginCompleteProcessingVO.getEdocInCjKey(), beginCompleteProcessingVO.getTransactionId());
		} else {
			beginCompleteProcessingVO.setEcout(creditJournalService.getDocumentFromCreditJournal(cjEcout));
		}

		String authorizationId = EdocsXmlUtils.getAuthorizationId(beginCompleteProcessingVO.geteDocIn());
		String financeType = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.getEcout(), XMLConstants.starFinanceTypePath);
		financeType = handleDistributeUtil.convertFinanceType(financeType);
		logger.debug("financeType:{}", financeType);

		CreditJournal cjEcin = creditJournalService.findByDeDealIdAndSequenceId(deDeal.getDealId(),
				cjEcout.getSequenceId(), cjEcout.getDealerId(), AppConstants.TRANS_TYPE_ECIN);
		Document ecIn = creditJournalService.getDocumentFromCreditJournal(cjEcin);
		String applicationType = handleDistributeUtil.getApplicationType(ecIn);
		logger.debug("applicationType:{}", applicationType);
		
		// Vault doc id
		String vaultDocId = HandlerUtils.getVaultDocId(beginCompleteProcessingVO.geteDocIn());
		beginCompleteProcessingVO.setVaultDocId(vaultDocId);

		String readyToBookFlag = "Y";

		final LocalDateTime dcDocStart = LocalDateTime.now();

		int fileCounter = 0;

		for (File file : beginCompleteProcessingVO.getFiles()) {
			fileCounter++;
			LocalDateTime filesStartTime = LocalDateTime.now();
			String formattedFileName = HandlerUtils.getFormattedFileName(file);
			file.setFormattedFileName(formattedFileName);
			String formType = HandlerUtils.getFormType(beginCompleteProcessingVO.geteDocIn(), file, dmsId);
			file.setFormType(formType);

			String getDocName = file.getFilename();
			String docName = file.getFilename().substring(0, getDocName.lastIndexOf('.'));
			
			logger.debug("Logging file information. formType: {}, docName: {}, isContract: {}", formType, docName, file.isContract());
			// When the redistribution was sent as a paper deal, VaultDocId should be blank
			if (file.isContract() && AppConstants.SCANNED.equalsIgnoreCase(formType)) {
				logger.debug(
						"Since the Contract is scanned we are setting blank value for vaultDocId and EConStatus in DeDeal table. FormType:{}", formType);
				deDeal.setVaultDocId("");
				deDeal.setEconStatus("");
			}

			if (AppConstants.DSP_ADP.equals(dmsId) && (AppConstants.CONTRACT_RETAIL_VCI.equalsIgnoreCase(docName)
					|| AppConstants.CONTRACT_LEASE_VCI.equalsIgnoreCase(docName)
					|| AppConstants.CONTRACT_BALLOON_VCI.equalsIgnoreCase(docName))) {

				beginCompleteProcessingVO.setIndValue(handleDistributeUtil.getvaultIndicator(docName, formType, vaultDocId));
			}

			if (AppConstants.DOCUMENT_MAPPING_FLAG_NO.equals(lender.getDocumentMappingEnabled())) {
				// for lenders that disable document mapping, instead of mapping
				// document, set lenDocName and dmsDocName as received
				file.setLenderDocName(formattedFileName);
				file.getDmsDocType().setDocName(formattedFileName);
			} else {
				file.setLenderDocName(AppConstants.DEAFULT_FILE_NAME);
				// If the document mapping not found, write lender doc name as
				// Other

				// for all the lenders that enable document mapping, do document
				// name translation
				DmsDocType dmsDocType = dmsdocTypeService.findByName(formattedFileName, dmsId);

				if (null == dmsDocType) {
					if (validationUtil.isVCILender(lenderId)) {
						logger.debug("DMSDoctype not found for VCI, setting the lender doc name as received");
						// If we cannot map the document and its VCI lender,
						// then send the document name as received
						file.setLenderDocName(formattedFileName);
						file.getDmsDocType().setDocName(formattedFileName);
					} else {
						// For all other lenders, default the document as
						// 'Other'
						logger.debug("DMSDoctype not found for {}, setting the lender doc name as Other", lenderId);
						dmsDocType = dmsdocTypeService.findByName(AppConstants.DOC_NAME_OTHER, dmsId);
					}
				}

				file.setDmsDocType(dmsDocType);
				if (null != dmsDocType && null != dmsDocType.getDcDocType()) {
					file.setDcDocType(dmsDocType.getDcDocType());
					DcDocType dcDocType = dmsDocType.getDcDocType();
					String docType = dcDocType.getType();
					
					if (AppConstants.DOC_TYPE_CONTRACT.equalsIgnoreCase(docType) && null != deDeal.getFundingStatus()
							&& AppConstants.FUNDING_STATUS_HELD.equalsIgnoreCase(deDeal.getFundingStatus()) && !isRouteOneTransaction) {
						logger.error("Contract cannot be transmitted when the deal is in {} status.",
								deDeal.getFundingStatus());
						throw new ApplicationException(
								errorDetail.add(AppConstants.NO_CONTRACT_IN_HELD_STATUS_ERROR_MESSAGE,
										AppConstants.NO_CONTRACT_IN_HELD_STATUS_ERROR_CODE));
					}
					List<LenDocType> lenDocTypes = lenDocTypeService
							.findByDcDocTypeId(dmsDocType.getDcDocType().getId(), lenderId);
					if (null != lenDocTypes && lenDocTypes.size() == 1) {
						file.setLenderDocName(lenDocTypes.get(0).getDocName());
						file.setLenDocType(lenDocTypes.get(0));
					} else if (null == lenDocTypes) {
						logger.warn("did not find Lender Doc Type for lender:{}, DMS Doc Type:{}, DC Doc Type:{}",
								lenderId, dmsDocType.getDocName(), file.getDcDocType().getName());
					} else if (lenDocTypes.size() > 1) {
						logger.warn(
								"found too many Lender Doc Type matches:{}, using the first match. lender:{}, "
										+ "DMS Doc Type:{}, DC Doc Type:{}",
								lenDocTypes.size(), lenderId, dmsDocType.getDocName(), file.getDcDocType().getName());
						file.setLenderDocName(lenDocTypes.get(0).getDocName());
						file.setLenDocType(lenDocTypes.get(0));
					}
				}

			}

			LocalDateTime filesEndTime = LocalDateTime.now();
			logger.debug("Processing for file: " + (formattedFileName != null ? formattedFileName : "") + " took "
					+ ChronoUnit.SECONDS.between(filesStartTime, filesEndTime) + " seconds");

		} // end of file loop

		// Depending on the flag, load the meta data configuration from
		// NEW tables or from old DC_DOC_FIELD
		if (AppConstants.AUTONOMOUS_FLAG_YES.equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {

			fileMetaDataService.addMetaDataFieldsToDistributionFilesForAutonomousLender(
					beginCompleteProcessingVO.getFiles(), lender, deDeal, financeType, applicationType);

		} else {
			fileMetaDataService.addFieldsToDistributionFilesForLender(beginCompleteProcessingVO.getFiles());
		}

		// PEN After-market Logic
		List<DeLenderFeature> lenderFeatures = deLenderFeatureServiceImpl.getFeaturesForLenderAndDms(lenderId, dmsId);
		if (handleDistributeUtil.isFeatureEnabled(lenderFeatures, AppConstants.LENDER_FEATURE_PEN_INTEGRATION)) {
			aftermarketProductsUtil.sendMessageToPEN(beginCompleteProcessingVO, deDeal);
		}

		// set up DcDocument, DcDocData etc for all files
		readyToBookFlag = dcDocumentService.prepareDocuments(beginCompleteProcessingVO, lender, cv, deDeal,
				applicationType, dmsId);

		logger.debug("Processed " + fileCounter + " files");

		final LocalDateTime dcDocEnd = LocalDateTime.now();
		logger.debug("Processing for DcDocuments and DocData took " + ChronoUnit.SECONDS.between(dcDocStart, dcDocEnd)
				+ " seconds");

		// Only set messageType to trailing if previous distributions with a
		// status of "Distributed" exist.
		String messageType = "";
		if (validationUtil.previousDistributionExists(distributions)) {
			messageType = "Trailing";
		} else {
			messageType = "Contract";
		}

		DcDistribution distribution = buildDcDistributionRecord(beginCompleteProcessingVO.getDeDealId(),
				beginCompleteProcessingVO.getSequenceId(), beginCompleteProcessingVO.getEdocInCjKey(), null,
				AppConstants.DOCUMENT_STATUS_PENDING, messageType, beginCompleteProcessingVO.getTimeStamp(), vaultDocId,
				cvSequenceId, authorizationId);

		// if DOCUMENT_MAPPING_ENABLED flag is not N for a lender , write the
		// ready to book value in the DC_DISTRIBUTION table
		if (!AppConstants.DOCUMENT_MAPPING_FLAG_NO.equalsIgnoreCase(lender.getDocumentMappingEnabled())
				&& null != distribution) {

			distribution.setReadyToBook(readyToBookFlag);
		}

		// Set contract id
		beginCompleteProcessingVO.setContractId(cv.getContractId());
		
		if (beginCompleteProcessingVO.isEyesOnDoc()) {
			logger.debug("EYES_ON_DOC flag set to Y for lender {}, finishing up processing for later review.", lender.getLender_id());
			distributionService.save(distribution);
			deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_PENDING);
			deDeal.setDistributionTs(date);
			deDeal.setFundingStatus(AppConstants.FUNDING_STATUS_PENDING);
			deDeal.setFundingStatusTs(date);
			dealService.saveOrUpdate(deDeal);
		} else {
			logger.debug("EYES_ON_DOC flag set to N for lender {}, completing processing without review.",
					lender.getLender_id());
			completeDistributeService.completeDistribute(beginCompleteProcessingVO, deDeal, lender, financeType,
					distribution, errorDetail, isRouteOneTransaction);
		}

		final LocalDateTime end = LocalDateTime.now();
		logger.debug("Begin Distribution process took " + ChronoUnit.SECONDS.between(start, end) + " seconds");

		return distribution;

	}

	@Override
	public DcDistribution buildDcDistributionRecord(String deDealId, String sequenceId, BigInteger edocInCjKey,
			BigInteger edocOutCjKey, String distStatus, String messageType, Date timeStamp, String vaultDocId,
			String cvSequenceId, String authorizationId) throws Exception {
		logger.debug("Entered buildDcDistributionRecord method");
		DcDistribution dcDistribution = new DcDistribution();

		DcDistribution.DcDistributionId id = new DcDistributionId();
		id.setDealId(deDealId);

		id.setSequenceId(sequenceId);
		dcDistribution.setId(id);
		dcDistribution.setInboundXml(edocInCjKey);
		dcDistribution.setOutboundXml(edocOutCjKey);
		dcDistribution.setFileLocation("");
		dcDistribution.setMessageType(messageType);
		dcDistribution.setDist_status(distStatus);
		dcDistribution.setCreatedBy("SYSTEM");
		dcDistribution.setCreatedByTs(timeStamp);
		dcDistribution.setModifiedBy("");
		dcDistribution.setModifiedTs(timeStamp);
		dcDistribution.setVaultDocId(vaultDocId);
		dcDistribution.setCvSequenceId(cvSequenceId);
		dcDistribution.setAuthorizationId(authorizationId);

		return dcDistribution;
	}

}
