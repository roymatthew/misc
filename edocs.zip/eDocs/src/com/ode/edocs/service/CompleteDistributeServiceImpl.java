package com.ode.edocs.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Namespace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ode.edocs.DistributionCheckHandler;
import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.bo.LenderBO;
import com.ode.edocs.bo.factory.DmsBOFactory;
import com.ode.edocs.bo.factory.LenderBOFactory;
import com.ode.edocs.client.LenderTransmitClient;
import com.ode.edocs.client.RouteOneTransmitClient;
import com.ode.edocs.db.dao.DeDealDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.db.entity.DeMaintenanceHistory;
import com.ode.edocs.db.entity.DePartnerDestination;
import com.ode.edocs.db.entity.FeatureConfiguration;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.rest.entity.FaxRequest;
import com.ode.edocs.rest.entity.FaxResponse;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.CommonsUtil;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.IFaxUtil;
import com.ode.edocs.util.IHandleDistributeUtil;
import com.ode.edocs.util.IServicesUtil;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.IZipUtil;
import com.ode.edocs.util.XMLConstants;
import com.ode.edocs.vo.BeginCompleteProcessingVO;
import com.ode.edocs.vo.CommonsUtilNvpVO;
import com.ode.edocs.xml.DistributionSchemaRouteOne;
import com.ode.edocs.xml.DistributionSchemaV1_0;
import com.ode.edocs.xml.DistributionSchemaV2_0;
import com.ode.edocs.xml.DistributionSchemaV3_0;

@Service
public class CompleteDistributeServiceImpl implements ICompleteDistributeService {
	private static final Logger logger = LogManager.getLogger(CompleteDistributeServiceImpl.class);

	@Autowired
	private DeDealDAO deDealDAO;
	
	@Autowired
	DistributionCheckHandler distributionCheckHandler;
	
	@Autowired
	MetaDataHandler metaDataHandler;
	
	@Autowired
	DistributionSchemaRouteOne distributionSchemaRouteOne;
	
	@Autowired
	private DistributionSchemaV1_0 distributionSchemaV1;
	
	@Autowired
	private DistributionSchemaV2_0 distributionSchemaV2;
	
	@Autowired
	private DistributionSchemaV3_0 distributionSchemaV3;
	
	@Autowired
	private IZipUtil zipUtil;
	
	@Autowired
	private IValidationUtil validationUtil;
	
	@Autowired
	private IFaxUtil faxUtilImpl;
	
	@Autowired
	private IDeLenderDestinationDAOService deLenderDestinationService;
	
	@Autowired
	private IDePartnerDestinationService partnerDestinationService;
	
	@Autowired
	private IDeMaintenanceHistoryDAOService deMaintenanceHistoryService;
	
	@Autowired
	private ICreditJournalService creditJournalService;
	
	@Autowired
	private IDistributionService distributionService;
	
	@Autowired
	LenderTransmitClient lenderTransmitClient;
	
	@Autowired
	RouteOneTransmitClient routeOneTransmitClient;
	
	@Autowired
	IHandleDistributeUtil handleDistributeUtil;
	
	@Autowired
	private IServicesUtil servicesUtil;
	
    @Autowired
    private DmsBOFactory dmsBOFactory;
	
    @Autowired
    private LenderBOFactory lenderBOFactory;
    
    @Autowired
    private IFeatureConfigurationDAOService featureConfigurationService;
	
	@Value("${CV_Test_applicationNumber}")
	private String cvTestApplicationNumber;

	private static Namespace dig = Namespace.getNamespace("dig", "http://www.opendealerexchange.com/DigitalDeal");
	private static Namespace soaptrans = Namespace.getNamespace("soaptrans",
			"http://www.starstandards.org/webservices/2005/10/transport");

	@Override
	public void completeDistribute(BeginCompleteProcessingVO beginCompleteProcessingVO, DeDeal deDeal, DeLender lender,
			String financeType, DcDistribution distribution, ErrorDetail errorDetail, boolean isRouteOneTransaction) throws Exception {

		final LocalDateTime start = LocalDateTime.now();
		Date date = new Date();
		logger.debug("Entered completeDistribute()");
		try {
			boolean faxService = false;
			boolean routeOneSchema = false;
			Map <String, String> additionalInfo = new HashMap<>(); // Additional information for RouteOne request
			
			String deDealId = deDeal.getDealId();
			String dmsId = EdocsXmlUtils.getDmsId(beginCompleteProcessingVO.geteDocIn());
			String lenderId = lender.getLender_id();
			String vaultDocId = beginCompleteProcessingVO.getVaultDocId();
			
			beginCompleteProcessingVO.setDmsId(dmsId);

			boolean eodFlag = validationUtil.isEyesOnDocEnabled(beginCompleteProcessingVO.getDealerId(),
					deDeal.getLenderId(), lender);

			String dcDistributionStatus = AppConstants.DISTRIBUTION_STATUS_RECEIVED;
			

			Document outgoingXml = null;

			// Get Lender Destination object
			DeLenderDestination lenderDest = null;
			DePartnerDestination partnerDestination = null;

			String lenderDestinationId = lenderId;
			boolean mockLender = false;
			if (deDeal.getCaApplicationNum().equalsIgnoreCase(cvTestApplicationNumber)) {
				lenderDestinationId = AppConstants.MOCK_LENDER_ID;
				mockLender = true;
			}
			
			String dealerId = EdocsXmlUtils.getDealerId(beginCompleteProcessingVO.geteDocIn());
			String bodId = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(),
					XMLConstants.starBodIdPath);
			try {
				
				if (eodFlag && mockLender) {
					lenderDest = deLenderDestinationService.findByLenderIdAndProduct(lenderDestinationId,
							AppConstants.APPLICATION_EDOCS, AppConstants.PRODUCT_EYES_ON_DOC);
				} else if (!eodFlag && mockLender) {
					lenderDest = deLenderDestinationService.findByLenderIdAndProduct(lenderDestinationId,
							AppConstants.APPLICATION_EDOCS, null);
				} else if (eodFlag && !mockLender) {
					lenderDest = deLenderDestinationService.findByLenderIdAndProduct(lenderId,
							AppConstants.APPLICATION_EDOCS, AppConstants.PRODUCT_EYES_ON_DOC);
				} else if (!isRouteOneTransaction) {
					lenderDest = deLenderDestinationService.findByLenderIdAndProduct(lenderId,
							AppConstants.APPLICATION_EDOCS, null);
				} else if (isRouteOneTransaction) {
					partnerDestination = partnerDestinationService.findByPartnerAndProduct(AppConstants.ROUTEONE_PARTNER, AppConstants.PRODUCT_EDOC);
				}
			} catch (Exception e) {
				ApplicationException ae = new ApplicationException(
						"Error getting lender destination record for lender " + lenderId + ":",
						AppConstants.LENDER_DESTINATION_FAILURE_CODE, e);
				ae.setErrorDetail(errorDetail);
				throw ae;
			}
			
	        final DmsBO dms = dmsBOFactory.createDMS(beginCompleteProcessingVO.getDmsId());
	        dms.init(beginCompleteProcessingVO.geteDocIn());
	        final LenderBO lenderBO = lenderBOFactory.createLender(lender.getLender_id(),
	        		beginCompleteProcessingVO.getLenderId(), dms);
			
			beginCompleteProcessingVO.setLenderDest(lenderDest);
			beginCompleteProcessingVO.setPartnerDestination(partnerDestination);

			// Update DcDocData review questions if applicable
			if (AppConstants.EYES_ON_DOC_FLAG_YES.equalsIgnoreCase(lender.getEyes_on_doc()) && 
				AppConstants.ANCILLARY_DATA_FLAG_YES.equalsIgnoreCase(lender.getAncillary_data_flag()) && 
				AppConstants.DOCUMENT_REVIEW_FLAG_YES.equalsIgnoreCase(lender.getDoc_review_flag())) {
				handleDistributeUtil.processQuestionReview(beginCompleteProcessingVO.getFiles(),
						beginCompleteProcessingVO.getEcout());
			}

			BigInteger edocOutCjKey = null;
			
			if (null != lender.getLender_integration_flag() && AppConstants.LENDER_INTEGRATION_FLAG_YES.equalsIgnoreCase(lender.getLender_integration_flag()) || 
			    null != lender.getFax_solution_flag() && AppConstants.FAX_SOLUTION_FLAG_YES.equalsIgnoreCase(lender.getFax_solution_flag())) {

				String schema = lender.getEdocs_schema_version();
				
				if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_1.equalsIgnoreCase(schema) || 
					AppConstants.DISTRIBUTION_SCHEMA_VERSION_3.equalsIgnoreCase(schema)) {
					outgoingXml = createDistributionRequestXML(schema, beginCompleteProcessingVO, deDeal, lender, financeType, distribution, additionalInfo);
				} else if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_2.equalsIgnoreCase(schema)) {
					if (eodFlag) {
						logger.info("Schema version setup is 2 and EOD Flag is enabled, hence distribution schema 2 is selected");
						outgoingXml = createDistributionRequestXML(schema, beginCompleteProcessingVO, deDeal, lender, financeType, distribution, additionalInfo);
					} else {
						logger.info("Schema version setup is 2 but EOD Flag is not enabled (either lender EYES_ON_DOC is N , or dealer not set up for EOD, or both), hence selecting secondary schema to create XML");
						outgoingXml = createDistributionRequestXML(lender.getEdocsSecondarySchemaVersion(), beginCompleteProcessingVO, deDeal, lender, financeType, distribution, additionalInfo);
					}
				} else if (AppConstants.DISTRIBUTION_JSON.equalsIgnoreCase(schema)) {
					faxService = true;
				} else if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_R1.equalsIgnoreCase(lender.getEdocs_schema_version())) {
					String partyId = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(), XMLConstants.starPartyIdPath);
					String applicationNumber = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.getEcout(), XMLConstants.starRouteOneApplicationNumber);
					String authorizationId = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(), XMLConstants.authorizationId);
					String dealerNumber = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(), XMLConstants.starDealerNumberPath);
					
					additionalInfo.put("partyId", partyId);
					additionalInfo.put("applicationNumber", applicationNumber);
					additionalInfo.put("authorizationId", authorizationId);
					additionalInfo.put("dealerNumber", dealerNumber);
					additionalInfo.put("lenderId", lender.getLender_id());
					additionalInfo.put("contractID", beginCompleteProcessingVO.getContractId());
					logger.debug("PartyId > {}, ApplicationNum > {}, AuthorizationId > {}, DealerNumber > {}, LenderId > {}, ContractId > {}", partyId, applicationNumber, authorizationId, dealerNumber, lender.getLender_id(), beginCompleteProcessingVO.getContractId());
					if (isRouteOneTransaction) {
						logger.info("RouteOne Distribution schema for the lender and transaction to be sent to RouteOne");
						routeOneSchema = true;
						outgoingXml = createDistributionRequestXML(schema, beginCompleteProcessingVO, deDeal, lender, financeType, distribution, additionalInfo);
					} else {
						logger.info("RouteOne Distribution schema for the lender, but identified that transaction *NOT* to be sent to RouteOne. Selecting the secondary schema from DE_LENDER");
						if (AppConstants.DISTRIBUTION_JSON.equals(lender.getEdocsSecondarySchemaVersion())) faxService = true;
						outgoingXml = createDistributionRequestXML(lender.getEdocsSecondarySchemaVersion(), beginCompleteProcessingVO, deDeal, lender, financeType, distribution, additionalInfo);
					}
				} else {
					logger.error("Error sending distribution to lender - unable to find a schema match for version:{}", schema);
					throw new ApplicationException(errorDetail.add(AppConstants.NO_SCHEMA_MATCH_FOR_LENDER_SCHEMA_VERSION_MESSAGE, AppConstants.NO_SCHEMA_MATCH_FOR_LENDER_SCHEMA_VERSION_CODE));
				}

				if (faxService) {
					deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_FAX_PENDING);
					deDeal.setDistributionTs(date);
					dcDistributionStatus = AppConstants.DISTRIBUTION_STATUS_FAX_PENDING;
				} else {
					// convert outgoing xml to string -- BEFORE STRIPPING ATTACHMENT
			        List<FeatureConfiguration> featureConfigurations = featureConfigurationService.getConfiguration(lenderId);
			        Map<String, String> webSvcFeatures = CommonsUtil.getMapOfWebServiceFeaturesForLender(featureConfigurations);
					String outgoingXmlString = EdocsXmlUtils.convertDocumentToString(outgoingXml);
					if (lenderBO.isEDocoutChangesRequired()) {
						logger.debug("EDOCOUT before making custom changes for {} => {}", lenderBO.getLenderId(), outgoingXmlString);
						org.w3c.dom.Document doc = EdocsXmlUtils.getW3CDocumentFromString(outgoingXmlString);
						doc = lenderBO.makeChangesToEDocOut(bodId, doc, webSvcFeatures);
				        logger.debug("Finished making custom changes to EDOCOUT for lender: {}", lenderBO.getLenderId());
						outgoingXmlString = EdocsXmlUtils.getXmlStringFromDocument(doc);
						logger.debug("Custom EDOCOUT => {}", outgoingXmlString);
					}

					// strip attachment and write to credit journal
					if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_3.equalsIgnoreCase(schema) || 
						AppConstants.DISTRIBUTION_SCHEMA_VERSION_2.equalsIgnoreCase(schema) && !eodFlag) {
						zipUtil.stripAttachment(outgoingXml, XMLConstants.soapTransAttachmentDataPath, soaptrans);
					} else if (routeOneSchema) {
						zipUtil.stripAttachment(outgoingXml, XMLConstants.routeOneContentPath, null);
					} else {
						zipUtil.stripAttachment(outgoingXml, XMLConstants.digFileContentPath, dig);
					}

					edocOutCjKey = creditJournalService.writeEDOCOUT(beginCompleteProcessingVO.geteDocIn(), outgoingXml,
							beginCompleteProcessingVO.getTimeStamp(), deDealId,
							beginCompleteProcessingVO.getSequenceId(), beginCompleteProcessingVO.getTransactionId(),
							beginCompleteProcessingVO.getAccountId());

					String lenderResponse = null;
					
					// Post to routeOne destination
					if (routeOneSchema) {
						logger.info("-- Sending distribution to RouteOne --");
						lenderResponse = this.routeOneTransmitClient.postWithHMACAuth(outgoingXmlString, deDeal, partnerDestination, additionalInfo, errorDetail);
					} else { // Post to an ODE lender
						lenderResponse = lenderTransmitClient.sendToLender(outgoingXmlString, lenderId, lender, lenderDest,
								true, deDeal, beginCompleteProcessingVO.getSequenceId(), errorDetail, vaultDocId, isRouteOneTransaction);
					}
					
					dcDistributionStatus = AppConstants.DISTRIBUTION_STATUS_DISTRIBUTED;
					BigInteger edocAckInCjKey = creditJournalService.writeEDOCACKIN("EDOCACKIN",
							beginCompleteProcessingVO.geteDocIn(), lenderResponse,
							beginCompleteProcessingVO.getTimeStamp(), deDealId,
							beginCompleteProcessingVO.getSequenceId(), beginCompleteProcessingVO.getTransactionId(),
							beginCompleteProcessingVO.getAccountId());
					logger.debug("EDOCACKIN CJKEY: {}", edocAckInCjKey);
				}

			} else {
				logger.debug("Integration is not enabled for {}, NOT sending the distribution and marking "
						+ "the distribution status as Received", lender.getLender_id());
			}

			// Set the latest distribution status as 'Distributed'. Only update
			// on the first distribution.
			if (!AppConstants.DISTRIBUTION_STATUS_DISTRIBUTED.equalsIgnoreCase(deDeal.getLatestDistributionStatus()) && !faxService) {
				logger.debug("Latest distribution status > Distributed");
				deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_DISTRIBUTED);
				deDeal.setDistributionTs(date);
			}

			// Only mark the first one as "Distributed"
			if (beginCompleteProcessingVO.getSequenceId().endsWith("01")) {
				deDeal.setFundingStatus(AppConstants.FUNDING_STATUS_DISTRIBUTED);
				deDeal.setFundingStatusTs(date);
			}

			// Update Deal funding status as 'Received' for non integrated
			// lender
			if (AppConstants.LENDER_INTEGRATION_FLAG_NO.equals(lender.getLender_integration_flag())) {
				if (AppConstants.FAX_SOLUTION_FLAG_YES.equals(lender.getFax_solution_flag())) {
					deDeal.setFundingStatus("");
					deDeal.setFundingStatusTs(date);
				} else {
					deDeal.setFundingStatus(AppConstants.FUNDING_STATUS_RECEIVED);
					deDeal.setFundingStatusTs(date);
				}
			}

			// save record as distributed/update existing dist record
			if (null != distribution) {
				distribution.setTransactionId(beginCompleteProcessingVO.getTransactionId());
				distribution.setAccountId(beginCompleteProcessingVO.getAccountId());
				handleDistributeUtil.updateDcDistributionRecord(distribution, beginCompleteProcessingVO.getFiles(),
						lender, edocOutCjKey, dcDistributionStatus, beginCompleteProcessingVO.getTimeStamp());
				String savedSequenceId = "";
				savedSequenceId = distribution.getId().getSequenceId();
				if (!savedSequenceId.equals(beginCompleteProcessingVO.getSequenceId())) {
					logger.warn("sequenceId sent to lender:{} does not match sequenceId written to db:{}",
							beginCompleteProcessingVO.getSequenceId(), savedSequenceId);
				}
			}

			// Exclude VCI and RR for other lenders from this logic
			if (!validationUtil.isVCILender(lenderId) && !dmsId.equalsIgnoreCase(AppConstants.DSP_REYNOLDS)
					&& !AppConstants.ECONTRACT_STATUS_ASSIGNED.equals(deDeal.getEconStatus())) {
				if (servicesUtil.vaultDocument(vaultDocId, deDeal, beginCompleteProcessingVO.getDealerId(), lender)) {
					deDeal.setEconStatus(AppConstants.ECONTRACT_STATUS_ASSIGNED);
					deDeal.setEconStatusTs(new Date());
				}
			}

			
			if (faxService) {
				FaxRequest faxRequest = faxUtilImpl.createFaxRequest(deDeal, beginCompleteProcessingVO.getFiles(),
						beginCompleteProcessingVO.getSequenceId(), bodId, lenderId);
				FaxResponse faxResponse = faxUtilImpl.faxDocuments(deDeal, faxRequest, lenderDest, deDealDAO);
				if ("200".equals(faxResponse.getFaxResponseCode())) {
					BigInteger faxInCjKey = faxUtilImpl.writeFAXIN(beginCompleteProcessingVO.geteDocIn(),
							faxResponse.getEfaxIn(), beginCompleteProcessingVO.getTimeStamp(), deDealId,
							beginCompleteProcessingVO.getSequenceId(), beginCompleteProcessingVO.getTransactionId(),
							beginCompleteProcessingVO.getAccountId());
					deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_STATUS_DISTRIBUTED);
					logger.debug("FAXIN CJKEY: {}", faxInCjKey);
				} else {
					dcDistributionStatus = AppConstants.DISTRIBUTION_STATUS_FAILED;
					handleDistributeUtil.updateDcDistributionRecord(distribution, beginCompleteProcessingVO.getFiles(),
							lender, edocOutCjKey, dcDistributionStatus, beginCompleteProcessingVO.getTimeStamp());
					deDeal.setLatestDistributionStatus(AppConstants.DISTRIBUTION_FAILED);
				}
			}
			logger.debug("*Funding Status: {}", deDeal.getFundingStatus());
			deDealDAO.saveOrUpdate(deDeal);
			
		} catch (Exception e) {
			logger.error(e);
			ApplicationException appE;
			if (e instanceof ApplicationException) {
				appE = (ApplicationException) e;
				appE.setErrorDetail(errorDetail);
				appE.setDistribution(distribution);
				appE.setDealerId(beginCompleteProcessingVO.getDealerId());
			} else {
				appE = new ApplicationException(e, distribution, e.getMessage(), AppConstants.UNEXPECTED_ERROR_CODE);
				appE.setErrorDetail(errorDetail);
				appE.setDistribution(distribution);
				appE.setDealerId(beginCompleteProcessingVO.getDealerId());
			}
			throw appE;
		}

		final LocalDateTime end = LocalDateTime.now();
		logger.debug("Complete Distribution process took " + ChronoUnit.SECONDS.between(start, end) + " seconds");
	}

	/*
	 * Schema 1, is the default schema (MB, JPM, any new lenders)
	 * Schema 2, is the new distribution message for autonomous funding
	 * Schema 3, is the existing VCI message
	 * Schema 4, is the GMF distribution message
	 * Schema R1, is the RouteOne distribution message
	 */
	private Document createDistributionRequestXML(String schemaVersion, BeginCompleteProcessingVO beginCompleteProcessingVO, DeDeal deDeal, 
												  DeLender lender, String financeType, DcDistribution distribution, Map <String, String> additionalInfo) throws Exception, ApplicationException {
		logger.info("Creating distribution request XML, Distribution schema: {}", schemaVersion);
		Document outgoingXml = null;
		
		if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_1.equalsIgnoreCase(schemaVersion)) {
			String bodId = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(),
					XMLConstants.starBodIdPath);
			outgoingXml = distributionSchemaV1.createOutgoingXml(beginCompleteProcessingVO.getEcout(),
																 beginCompleteProcessingVO.getFiles(), beginCompleteProcessingVO.getDmsId(), lender.getLender_id(), deDeal.getDealId(),
																 beginCompleteProcessingVO.getSequenceId(), financeType, beginCompleteProcessingVO.getLenderDest(), lender, bodId);
		} else if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_2.equalsIgnoreCase(schemaVersion)) {
			List<DeMaintenanceHistory> maintRecords = deMaintenanceHistoryService.getRecordsForDeDeal(deDeal.getDealId());
			List<DcDistribution> distributions = distributionService.find(deDeal.getDealId());
			outgoingXml = distributionSchemaV2.createOutgoingXml(beginCompleteProcessingVO.getEcout(),
																 beginCompleteProcessingVO.getFiles(), beginCompleteProcessingVO.getDmsId(), deDeal,
																 beginCompleteProcessingVO.getSequenceId(), financeType, beginCompleteProcessingVO.getLenderDest(), lender,
																 distribution, maintRecords, distributions);
		} else if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_3.equalsIgnoreCase(schemaVersion)) {
			String zipFileName = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(), XMLConstants.soapTransFileNamePath);
			String signatureName = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(), XMLConstants.signatureName);
			String signatureValue = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(), XMLConstants.signatureValue);
			HashMap<String, String> attributeTag = new HashMap<String, String>();
			attributeTag.put(signatureName, signatureValue);
			if (null != beginCompleteProcessingVO.getIndValue()) {
				attributeTag.put("eVaultIndicator", beginCompleteProcessingVO.getIndValue());
			}
			
			outgoingXml = distributionSchemaV3.createOutgoingXml(beginCompleteProcessingVO.getEcout(),
																 beginCompleteProcessingVO.getProcessedBase64Zip(), zipFileName,
																 beginCompleteProcessingVO.getTransactionId(), attributeTag);
		} else if (AppConstants.DISTRIBUTION_SCHEMA_VERSION_R1.equalsIgnoreCase(schemaVersion)) {
			// Consider creating XML based on "initial" distribution schema, if the funding status is not "Held"
			boolean isInitial = !AppConstants.FUNDING_STATUS_HELD.equalsIgnoreCase(deDeal.getFundingStatus());
			String bodId = EdocsXmlUtils.getTextFromXpath(beginCompleteProcessingVO.geteDocIn(),
					XMLConstants.starBodIdPath);
			outgoingXml = distributionSchemaRouteOne.createOutgoingXml(isInitial, beginCompleteProcessingVO.getEcout(),
					beginCompleteProcessingVO.getFiles(), beginCompleteProcessingVO.getDmsId(), deDeal.getDealId(),
					lender, beginCompleteProcessingVO.getPartnerDestination(), additionalInfo, bodId,
					beginCompleteProcessingVO.getDealerId());
		}
		return outgoingXml;
	}
}
