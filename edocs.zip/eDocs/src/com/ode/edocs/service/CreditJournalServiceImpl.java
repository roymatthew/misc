package com.ode.edocs.service;

import com.ode.edocs.db.dao.CreditJournalDAO;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.DocumentReviewRequest;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.IHandleDistributeUtil;
import com.ode.edocs.util.IServicesUtil;
import com.ode.edocs.util.IZipUtil;
import com.ode.edocs.util.XMLConstants;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.math.BigInteger;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Namespace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CreditJournalServiceImpl implements ICreditJournalService {

    private static final Logger logger = LogManager.getLogger(CreditJournalServiceImpl.class);

    private static Namespace soaptrans = Namespace.getNamespace("soaptrans",
        "http://www.starstandards.org/webservices/2005/10/transport");

    @Autowired
    private CreditJournalDAO creditJournalDAO;

    @Autowired
    private IServicesUtil servicesUtil;

    @Autowired
    private IHandleDistributeUtil handleDistributeImpl;

    @Autowired
    private IZipUtil zipUtil;

    /**
     * {@inheritDoc}
     */
    @Override
    public CreditJournal getCreditJournalRecord(final DeDeal deDeal, final DeContractValidation contractValidation, final String transType)
        throws Exception {
        logger.debug("Entered getCreditJournalRecord. DealId: {}, ContractValidation: {}, TransType: {}", deDeal.getDmsDealNum(), contractValidation.getStatus(), transType);
        CreditJournal creditJournal = getCreditJournalDAO().findByDeDealIdAndSequenceId(deDeal.getDealId(),
            (contractValidation != null && contractValidation.getId() != null ? contractValidation.getId().getSequenceId() : ""), deDeal.getDmsDealerId(), transType);
        logger.debug("Exit getCreditJournalRecord");
        return creditJournal;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writeEDOCIN(final DistributionProcessingVO distributionProcessingVO, final Date timeStamp,
        final String transactionId, final String accountId) throws Exception {

        logger.debug("Entered writeEDOCIN(DistributionProcessingVO, Date, String, String");

        CreditJournal creditJournal = new CreditJournal();
        final String dsp = EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(),
            XMLConstants.starCreatorNameCodePath);

        zipUtil.stripAttachment(distributionProcessingVO.geteDocIn(), XMLConstants.soapTransAttachmentDataPath,
            soaptrans);
        final String xml = EdocsXmlUtils.convertDocumentToString(distributionProcessingVO.geteDocIn());
        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(xml).get(1));
        creditJournal.setSystemId(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starStoreNumber));
        creditJournal.setDealerId(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(),
            XMLConstants.starDestinationNameCode);
        if (partnerId == null || "".equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(),
                XMLConstants.starDestinationPath);
        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("EDOCIN");
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(xml).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(),
            XMLConstants.starFinanceTypePath);
        financeType = getHandleDistributeUtil().convertFinanceType(financeType);
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starBodIdPath));
        creditJournal.setSequenceNumber("");
        creditJournal.setFinanceInstitution("");
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal.setApplicationSource(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(
            EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(), XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(distributionProcessingVO.getDeDealId());
        creditJournal.setSequenceId(distributionProcessingVO.getDistributionSequenceId());
        creditJournal.setTransactionId(transactionId);

        final BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);

        logger.debug("Exit writeEDOCIN(DistributionProcessingVO, Date, String, String");

        return logger.exit(creditJournalKey);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writeEDOCACKOUT(final Document inDocument, final String eDocsResponse, final Date timeStamp,
        final DcDistribution distribution) throws Exception {

        logger.debug("Entered writeEDOCACKOUT(Document, String, Date, DcDistribution)");
        BigInteger creditJournalKey = null;
        // IF document is STAR format
        if (EdocsXmlUtils.doesXPathExist(inDocument, XMLConstants.starDealerNumberPath)) {
            CreditJournal creditJournal = new CreditJournal();
            String dsp = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath);
            creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(eDocsResponse).get(1));
            creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starStoreNumber));
            creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealerNumberPath));

            String partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationNameCode);
            if (partnerId == null || "".equals(partnerId)) {
                partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationPath);
            }
            creditJournal.setPartnerId(partnerId);
            creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starAuthorizationPath));
            creditJournal.setTransDateTime(timeStamp);
            creditJournal.setTransType("EDOCACKOUT");
            creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(eDocsResponse).get(0));
            String financeType = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starFinanceTypePath);
            financeType = getHandleDistributeUtil().convertFinanceType(financeType);
            creditJournal.setApplicationType(financeType);
            creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealIdPath));
            creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starBodIdPath));
            creditJournal.setSequenceNumber("");
            creditJournal.setFinanceInstitution("");
            creditJournal.setTransFlag("N");
            creditJournal.setDeliverySource(dsp);
            creditJournal
            .setApplicationSource(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
            creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));

            if (null != distribution) {
                creditJournal.setDealId(distribution.getId().getDealId());
                creditJournal.setSequenceId(distribution.getId().getSequenceId());
                creditJournal.setTransactionId(distribution.getTransactionId());
                creditJournal.setAccountId(distribution.getAccountId());
            }

            creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        }

        logger.debug("Exit writeEDOCACKOUT(Document, String, Date, DcDistribution)");

        return creditJournalKey;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writeEDOCACKIN(String transType, Document inDocument, String lenderResponse, Date timeStamp,
        String deDealId, String sequenceId, String transactionId, String accountId) throws Exception {
        logger.debug("Entered writeEDOCACKIN(String, Document, String, Date, String, String, String, String)");
        CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath);
        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(lenderResponse).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationNameCode);
        if (partnerId == null || AppConstants.EMPTY_STRING.equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationPath);

        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType(transType);
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(lenderResponse).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starBodIdPath));
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal
        .setApplicationSource(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(deDealId);
        creditJournal.setSequenceId(sequenceId);
        creditJournal.setTransactionId(transactionId);

        BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        logger.debug("Exit writeEDOCACKIN(String, Document, String, Date, String, String, String, String)");
        return creditJournalKey;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writeEDOCOUT(Document inDocument, Document outDocument, Date timeStamp, String deDealId,
        String sequenceId, String transactionId, String accountId) throws Exception {
        logger.debug("Entered writeEDOCOUT(Document, Document, Date, String, String, String, String)");
        final CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath);

        String outgoingXml = EdocsXmlUtils.convertDocumentToString(outDocument);
        //logger.debug("outgoingXml:{}", outgoingXml);

        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(outgoingXml).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationNameCode);
        if (partnerId == null || AppConstants.EMPTY_STRING.equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationPath);
        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("EDOCOUT");
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(outgoingXml).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starBodIdPath));
        // creditJournal.setSequenceNumber(EdocsXmlUtils.getTextFromXpath(inDocument, "//star:BODId"));
        // BODId is too big for this column, why are we doing this?
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal
        .setApplicationSource(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(deDealId);
        creditJournal.setSequenceId(sequenceId);
        creditJournal.setTransactionId(transactionId);

        BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        logger.debug("Exited writeEDOCOUT(Document, Document, Date, String, String, String, String)");

        return creditJournalKey;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writeAUTOCVOUT(Document document, Date timeStamp, String dealId, String autoCvOut,
        CreditJournal cjEcout, String dmsDealerId, String lenderId) throws Exception {
        logger.debug("Entered writeAUTOCVOUT()");
        CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starCreatorNameCodePath);
        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(autoCvOut).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDealerNumberPath));
        // creditJournal.setPartnerId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDestinationNameCode));
        creditJournal.setPartnerId(lenderId);
        creditJournal.setUserId("eDocs");
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("AUTOCVOUT");
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(autoCvOut).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(AppConstants.EMPTY_STRING);
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setDeliverySource(dsp);
        creditJournal.setApplicationSource("OD");
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(dealId);

        if (null != cjEcout) {
            creditJournal.setTransactionId(cjEcout.getTransactionId());
        }

        BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        logger.debug("Exit writeAUTOCVOUT()");
        return logger.exit(creditJournalKey);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writeEDOCIN(Document document, Date timeStamp, String deDealId, String sequenceId,
        String transactionId, String dealerId, String accountId, Namespace soaptrans) throws Exception {

        logger.debug("Entered writeEDOCIN()");

        CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starCreatorNameCodePath);

        zipUtil.stripAttachment(document, XMLConstants.soapTransAttachmentDataPath, soaptrans);
        String xml = EdocsXmlUtils.convertDocumentToString(document);
        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(xml).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDestinationNameCode);
        if (partnerId == null || AppConstants.EMPTY_STRING.equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDestinationPath);
        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("EDOCIN");
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(xml).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starBodIdPath));
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal
        .setApplicationSource(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(deDealId);
        creditJournal.setSequenceId(sequenceId);
        creditJournal.setTransactionId(transactionId);

        BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        logger.debug("Exited method writeEDOCIN()");

        return creditJournalKey;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writePENIN(Document inDocument, String dataXml, Date timeStamp,
        String deDealId, String sequenceId, String transactionId, String accountId) throws Exception {
    	
    	logger.entry(inDocument, dataXml, timeStamp, deDealId, sequenceId, transactionId, accountId);
        logger.debug("Entered writePENIN(Document, String, Date, String, String, String, String)");
        CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath);
        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(dataXml).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationNameCode);
        if (partnerId == null || AppConstants.EMPTY_STRING.equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationPath);

        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("PENIN");
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(dataXml).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starBodIdPath));
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal.setApplicationSource(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(deDealId);
        creditJournal.setSequenceId(sequenceId);
        creditJournal.setTransactionId(transactionId);

        BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        logger.debug("Exit writePENIN(Document, String, Date, String, String, String, String)");
        return creditJournalKey;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger writePENOUT(Document inDocument, String dataXml, Date timeStamp,
        String deDealId, String sequenceId, String transactionId, String accountId) throws Exception {
    	
    	logger.entry(inDocument, dataXml, timeStamp, deDealId, sequenceId, transactionId, accountId);
        logger.debug("Entered writePENOUT(Document, String, Date, String, String, String, String)");
        CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath);
        creditJournal.setCrDataXml(getHandleDistributeUtil().encryptedXmlwithKeyId(dataXml).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationNameCode);
        if (partnerId == null || AppConstants.EMPTY_STRING.equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationPath);

        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("PENOUT");
        creditJournal.setEncryptionKeyId(getHandleDistributeUtil().encryptedXmlwithKeyId(dataXml).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starBodIdPath));
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal.setApplicationSource(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(deDealId);
        creditJournal.setSequenceId(sequenceId);
        creditJournal.setTransactionId(transactionId);

        BigInteger creditJournalKey = getCreditJournalDAO().saveOrUpdate(creditJournal);
        logger.debug("Exit writePENOUT(Document, String, Date, String, String, String, String)");
        return creditJournalKey;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void updateEDocIn(BigInteger edocInCjKey, String transactionId) throws Exception {
        logger.debug("Entered updateEDocIn()");
        CreditJournal cj = getCreditJournalDAO().findCreditJournalByCjKey(edocInCjKey, "EDOCIN");
        if (null != cj) {
            cj.setTransactionId(transactionId);
            cj.setTransDateTime(new Date());
            getCreditJournalDAO().saveOrUpdateRecord(cj);
        } else {
            logger.warn("could not find eDocIn to update:{}", transactionId);
            logger.debug("WARNING: could not find eDocIn to update:{}", transactionId);
        }
        logger.debug("Exited method updateEDocIn()");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public CreditJournal getLatestECOUTRecord(final DocumentReviewRequest request) throws Exception {
        logger.debug("Entered getLatestECOUTRecord()");
        CreditJournal creditJournal = null;
        CreditJournal ecackin = getCreditJournalDAO().findLatestAccr(request.getDmsDealId(), "ECACKIN",
            request.getDealerId(), request.getPartnerId());
        if (null != ecackin) {
            String transactionId = ecackin.getTransactionId();
            String[] transTypes = { "ECOUT" };
            creditJournal = getCreditJournalDAO().findMostRecentByTransactionId(transactionId, request.getDealerId(),
                request.getPartnerId(), transTypes);
        } else {
            logger.warn("could not find EACKIN record with deal id:{}, dealer id {}, partner id {}",
                request.getDmsDealId(), request.getDealerId(), request.getPartnerId());
        }
        logger.debug("Exited getLatestECOUTRecord()");

        return creditJournal;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public CreditJournal findByDeDealIdAndSequenceId(final String deDealId, final String sequenceId,
        final String dealerId, final String transType) throws Exception {
        logger.debug("Entered findByDeDealIdAndSequenceId()");
        return getCreditJournalDAO().findByDeDealIdAndSequenceId(deDealId, sequenceId, dealerId, transType);
    }

    /**
     * Getter for edocsProcessUtil.
     *
     * @return
     */
    public IHandleDistributeUtil getHandleDistributeUtil() {
        return handleDistributeImpl;
    }

    /**
     * Getter for creditJournalDAO.
     *
     * @return
     */
    @Override
    public CreditJournalDAO getCreditJournalDAO() {
        return creditJournalDAO;
    }

    @Override
    public void setCreditJournalDAO(CreditJournalDAO creditJournalDAO) {
        
        this.creditJournalDAO = creditJournalDAO;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Document getDocumentFromCreditJournal(CreditJournal creditJournal) throws ApplicationException, Exception {
        String docString = "";
        try {
        	if (creditJournal != null) {
        		docString = servicesUtil.decryptText(creditJournal.getCrDataXml(), creditJournal.getEncryptionKeyId());
        	} else {
        		logger.error("creditJournal record is null, not able to extract the XML");
        	}
            
        } catch (Exception e) {
            logger.error("could not decrypt xml", e);
            throw new ApplicationException(creditJournal.getDealerId(), e, AppConstants.DECRYPT_ECOUT_FAILED_CODE);
        }
        Document doc = EdocsXmlUtils.getDocumentFromString(docString);
        return doc;
    }

    /**
     * {@inheritDoc}
     *
     * @throws Exception
     */
    @Override
    public CreditJournal findByCreditJournalKey(final BigInteger creditJournalKey, final String transactionType)
        throws Exception {
        return creditJournalDAO.findCreditJournalByCjKey(creditJournalKey, transactionType);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteCreditJournal(final BigInteger creditJournalKey) {
        creditJournalDAO.deleteCreditJournal(creditJournalKey);

    }

    @Override
    public CreditJournal findLatestAccr(String dmsDealNo, String transType, String dealerId, String partnerId)
        throws Exception {
        return creditJournalDAO.findLatestAccr(dmsDealNo, transType, dealerId, partnerId);
    }

    @Override
    public CreditJournal findMostRecentByTransactionId(String transactionId, String dealerId, String partnerId,
        String[] transTypes) throws Exception {
        return creditJournalDAO.findMostRecentByTransactionId(transactionId, dealerId, partnerId, transTypes);
    }

    @Override
    public CreditJournal findCreditJournalByCjKey(BigInteger edocInCjKey, String transType) throws Exception {
        return creditJournalDAO.findCreditJournalByCjKey(edocInCjKey, transType);
    }

    @Override
    public BigInteger saveOrUpdate(CreditJournal creditJournal) throws Exception {
        return creditJournalDAO.saveOrUpdate(creditJournal);
    }

    @Override
    public void saveOrUpdateRecord(final CreditJournal creditJournal) throws Exception {
        
        creditJournalDAO.saveOrUpdateRecord(creditJournal);
    }

    @Override
    public CreditJournal findMostRecentByDeDealId(String deDealId, String dealerId, String partnerId,
        String[] transTypes) throws Exception {
        return creditJournalDAO.findMostRecentByDeDealId(deDealId, dealerId, partnerId, transTypes);
    }


}
