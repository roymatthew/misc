package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DcDocFieldDAO;
import com.ode.edocs.db.entity.DcDocField;

@Service
public class DcDocFieldDAOServiceImpl implements IDcDocFieldDAOService {

	private static final Logger logger = LogManager.getLogger(DcDocFieldDAOServiceImpl.class);

	@Autowired
	private DcDocFieldDAO dcDocFieldDAO;

	@Override
	public DcDocFieldDAO getDcDocFieldDAO() {
		return dcDocFieldDAO;
	}

	@Override
	public void setDcDocFieldDAO(DcDocFieldDAO dcDocFieldDAO) {

	}

	@Override
	public List<DcDocField> findByDcDocTypeId(Integer dcDocTypeId) throws Exception {
		return dcDocFieldDAO.findByDcDocTypeId(dcDocTypeId);

	}

	@Override
	public List<DcDocField> findByDmsDocTypeId(Integer id) throws Exception {
		return dcDocFieldDAO.findByDmsDocTypeId(id);
	}

	@Override
	public List<DcDocField> findByDmsDocTypeIdAndSection(Integer dmsDocTypeId, String section) throws Exception {
		return dcDocFieldDAO.findByDmsDocTypeIdAndSection(dmsDocTypeId, section);
	}
}
