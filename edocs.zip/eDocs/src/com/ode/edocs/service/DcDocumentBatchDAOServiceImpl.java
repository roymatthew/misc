package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DcDocumentBatchDAO;
import com.ode.edocs.db.dao.IDcDocumentBatchDAO;

@Service
public class DcDocumentBatchDAOServiceImpl implements IDcDocumentBatchDAOService {

	private static final Logger logger = LogManager.getLogger(DcDocumentBatchDAOServiceImpl.class);

	@Autowired
	IDcDocumentBatchDAO dcDocumentBatchDAO;

	@Override
	public void doBatchInsertDocData(final File file) {
		dcDocumentBatchDAO.doBatchInsertDocData(file);
	}

}
