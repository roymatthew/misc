package com.ode.edocs.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.File;
import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.db.dao.DcDocumentDAO;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.FormElementKey;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.IHandleDistributeUtil;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.vo.BeginCompleteProcessingVO;

@Service
public class DcDocumentServiceImpl implements IDcDocumentService {

	private static final Logger logger = LogManager.getLogger(DcDocumentServiceImpl.class);

	@Autowired
	private DcDocumentDAO dcDocumentDAO;

	@Autowired
	private IHandleDistributeUtil handleDistributeUtil;

	@Autowired
	private IValidationUtil validationUtil;

	@Autowired
	private IDcDocumentBatchDAOService dcDocumentBatchService;

	@Autowired
	private IDocDataService docDataService;

	@Autowired
	private IFileMetadataService fileMetadataService;

	@Autowired
	private IDcFormDAOService dcFormService;

	@Autowired
	private MetaDataHandler metaDataHandler;

	@Override
	public DcDocument saveDcDocument(final File file, final String dealId, final String sequenceId, final String dmsId)
			throws Exception {

		final Timestamp now = new Timestamp(new Date().getTime());
		DcDocument dcDocument = new DcDocument();
		String dmsDocName = file.getFilename();
		if (!StringUtils.isEmpty(file.getFilename()) && file.getFilename().toLowerCase().endsWith(".pdf")) {
			dmsDocName = file.getFilename().substring(0, file.getFilename().length() - 4);
		}
		dcDocument.setDmsDocName(dmsDocName);
		dcDocument.setDealId(dealId);
		dcDocument.setSequenceId(sequenceId);
		dcDocument.setLenderDocName(file.getLenderDocName());
		dcDocument.setFormType(file.getFormType());

		if (null != file.getDcDocType()) {
			dcDocument.setDocType(file.getDcDocType().getType());
		} else {
			dcDocument.setDocType("A");
		}

		if (null != file.getAncillaryData()) {
			String ancillaryXml = EdocsXmlUtils.convertDocumentToString(file.getAncillaryData());
			dcDocument.setEncryptionKeyId(handleDistributeUtil.encryptedXmlwithKeyId(ancillaryXml).get(0));
			dcDocument.setMetadata_xml(handleDistributeUtil.encryptedXmlwithKeyId(ancillaryXml).get(1));
		}

		dcDocument.setCreatedBy(dmsId);
		dcDocument.setCreatedTs(now);
		dcDocument.setModifiedBy(dmsId);
		dcDocument.setModifiedTs(now);
		dcDocument = dcDocumentDAO.save(dcDocument);

		return dcDocument;

	}

	@Override
	public String prepareDocuments(BeginCompleteProcessingVO beginCompleteProcessingVO, final DeLender lender,
			DeContractValidation cv, DeDeal deDeal, String applicationType, final String dmsId) throws Exception {

		logger.debug("Entered prepareDocuments()");

		String readyToBookFlag = "Y";

		for (final File file : beginCompleteProcessingVO.getFiles()) {

			final String dmsDocName = file.getFilename();

			final DcDocument dcDocument = saveDcDocument(file, deDeal.getDealId(),
					beginCompleteProcessingVO.getSequenceId(), dmsId);
			file.setDcDocument(dcDocument);
			List<DcForm> dcForms = dcFormService.findOutstandingForms(deDeal.getDealId(), file.getFormattedFileName());
			file.setDcForms(dcForms);
			if (AppConstants.DSP_ADP.equalsIgnoreCase(dmsId)) {
				file.setRequiredForm(validationUtil.isADPRequiredForm(file).toString());
			} else {
				file.setRequiredForm(validationUtil.isRequiredForm(dcForms).toString());
			}
			handleDistributeUtil.updateForms(dcForms, dcDocument, file, deDeal.getDealId(), lender.getLender_id());

			List<DeDataElement> dataElements = null;

			if (AppConstants.AUTONOMOUS_FLAG_YES.equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {

				if (null != file.getDmsDocType() && null != file.getDmsDocType().getDcDocType()) {
					final FormElementKey lookupKey = metaDataHandler.buildElementKey(
							file.getDmsDocType().getDcDocType().getId(), lender.getLender_id(),
							deDeal.getDealExecutionState());
					dataElements = fileMetadataService.getSessionMetaDataMap().get(lookupKey);
					if (dataElements == null || dataElements.isEmpty()) {
						logger.debug("dataElements from session is null/empty for " + lookupKey);
					}
					// for autonomous funding lender, get data value for each
					// DE_DATA_ELEMENT field
					docDataService.savaDocDataForAutonomousLender(file, dcDocument,
							beginCompleteProcessingVO.getEcout(), deDeal, lender, dmsId, cv, dataElements, dmsDocName,
							applicationType);
				}

			} else {
				// for non-autonomous funding lender, follow the old flow and
				// get data value for each DC_DOC_FIELD
				docDataService.savaDocData(file, dcDocument, beginCompleteProcessingVO.getEcout(), deDeal, lender,
						dmsId, cv, dataElements, dmsDocName, applicationType);
			}

			// write DocData from file to DC_DOC_DATA table
			dcDocumentBatchService.doBatchInsertDocData(file);

			// for each form in the distribution, update Form Complete flag.
			// if all the type M data are not blank, and all the type R data are
			// evaluated as Y, and all the type F data are evaluated as Y
			// then form complete will be Y, otherwise N
			if (AppConstants.DOCUMENT_MAPPING_FLAG_YES.equalsIgnoreCase(lender.getDocumentMappingEnabled())) {
				dcDocument.setFormComplete("Y");
				for (DcDocData data : file.getDocData()) {
					if (AppConstants.SECTION_META_DATA.equals(data.getSection())
							&& (data.getDataValue() == null || data.getDataValue().isEmpty())
							|| AppConstants.SECTION_REVIEW_DATA.equals(data.getSection())
									&& !"Y".equalsIgnoreCase(data.getDataValue())
							|| AppConstants.SECTION_FORM_QUESTION_DATA.equals(data.getSection())
									&& !"Y".equalsIgnoreCase(data.getDataValue())) {
						dcDocument.setFormComplete("N");
						// if form complete value is Y for all the forms in
						// distribution, then Ready to Book value will be Y for
						// that distribution, otherwise N
						readyToBookFlag = "N";
						break;
					}
				}
				dcDocumentDAO.saveOrUpdate(dcDocument);
				file.setDcDocument(dcDocument);
			}

		}
		logger.debug("Exit prepareDocuments()");
		return readyToBookFlag;

	}

	@Override
	public DcDocumentDAO getDcDocumentDAO() {
		return dcDocumentDAO;
	}

	@Override
	public void setDcDocumentDAO(DcDocumentDAO dcDocumentDAO) {

	}

	@Override
	public DcDocument save(DcDocument dcDocument) throws Exception {
		return dcDocumentDAO.save(dcDocument);
	}

	@Override
	public void saveOrUpdate(DcDocument dcDocument) throws Exception {
		dcDocumentDAO.saveOrUpdate(dcDocument);
	}

	@Override
	public DcDocument getDcDocument(String deDealId, String sequenceId, String dmsDocName) throws Exception {
		return dcDocumentDAO.getDcDocument(deDealId, sequenceId, dmsDocName);
	}

	@Override
	public List<DcDocument> getDcDocumentList(String deDealId, String distSequenceId) throws Exception {
		return dcDocumentDAO.getDcDocumentList(deDealId, distSequenceId);
	}

	@Override
	public DcDocument getDcDocument(Integer dcDocumentId) throws Exception {
		return dcDocumentDAO.getDcDocument(dcDocumentId);
	}

}
