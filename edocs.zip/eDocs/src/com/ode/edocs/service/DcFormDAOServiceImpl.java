package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DcFormDAO;
import com.ode.edocs.db.entity.DcForm;

@Service
public class DcFormDAOServiceImpl implements IDcFormDAOService {

	private static final Logger logger = LogManager.getLogger(DcFormDAOServiceImpl.class);
	
	@Autowired
	private DcFormDAO dcFormDAO;
	
	@Override
	public DcFormDAO getDcFormDAO() {
		return dcFormDAO;
	}

	@Override
	public void setDcFormDAO(DcFormDAO dcFormDAO) {

	}
	
	@Override
	public void saveOrUpdate(DcForm dcForm) throws Exception {
		dcFormDAO.saveOrUpdate(dcForm);
	}
	
	@Override
	public List<DcForm> findForms(String dealId, String formName) throws Exception {
		return dcFormDAO.findForms(dealId, formName);
	}

	@Override
	public List<DcForm> findOutstandingForms(String deDealId, String formattedFileName) throws Exception {
		return dcFormDAO.findOutstandingForms(deDealId, formattedFileName);
	}
}
