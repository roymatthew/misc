package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeContractValidationDAO;
import com.ode.edocs.db.entity.DeContractValidation;

@Service
public class DeContractValidationDAOServiceImpl implements IDeContractValidationDAOService {

	private static final Logger logger = LogManager.getLogger(DeContractValidationDAOServiceImpl.class);

	@Autowired
	private DeContractValidationDAO deContractValidationDAO;

	@Override
	public DeContractValidationDAO getDeContractValidationDAO() {
		return deContractValidationDAO;
	}

	@Override
	public void setDeContractValidationDAO(DeContractValidationDAO deContractValidationDAO) {

	}

	@Override
	public DeContractValidation findMostRecentWithStatus(String deDealId, String[] statuses) throws Exception {
			return deContractValidationDAO.findMostRecentWithStatus(deDealId, statuses);
	}

	@Override
	public DeContractValidation findMostRecentWithStatusAndLenderSequenceNumber(String deDealId, String[] statuses,
			String sequenceNumber) throws Exception {
		return deContractValidationDAO.findMostRecentWithStatusAndLenderSequenceNumber(deDealId, statuses,
				sequenceNumber);
	}

	@Override
	public DeContractValidation findMostRecent(String deDealId) throws Exception {
		return deContractValidationDAO.findMostRecent(deDealId);
	}

	@Override
	public DeContractValidation findWithSequenceId(String deDealId, String sequenceId) {
		return deContractValidationDAO.findWithSequenceId(deDealId, sequenceId);
	}

}
