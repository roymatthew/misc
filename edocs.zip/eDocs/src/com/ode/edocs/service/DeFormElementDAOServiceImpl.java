package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeFormElementDAO;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DeFormElement;
import com.ode.edocs.db.entity.FormElementEntity;
import com.ode.edocs.rest.entity.FormElementKey;

@Service
public class DeFormElementDAOServiceImpl implements IDeFormElementDAOService {

	private static final Logger logger = LogManager.getLogger(DeFormElementDAOServiceImpl.class);

	@Autowired
	private FormsDAO formsDAO;

	@Autowired
	private DeFormElementDAO deFormElementDAO;

	@Override
	public FormsDAO getFormsDao() throws Exception {
		return formsDAO;
	}

	@Override
	public void setFormsDao(FormsDAO formsDao) {

	}

	@Override
	public DeFormElementDAO getDeFormElementDAO() {
		return deFormElementDAO;
	}

	@Override
	public void setDeFormElementDAO(DeFormElementDAO deFormElementDAO) {

	}

	@Override
	public DeFormElement getDeFormElement(FormElementKey key) {
		return deFormElementDAO.getDeFormElement(key);
	}

	@Override
	public List<DeFormElement> getDeFormElementsCollection(final FormElementKey key,
			final List<Integer> docTypeIdList) {
		return deFormElementDAO.getDeFormElementsCollection(key, docTypeIdList);
	}

	@Override
	public List<FormElementEntity> getFormElementEntityCollection(final FormElementKey key,
			final List<Integer> docTypeIdList) {
		return deFormElementDAO.getFormElementEntityCollection(key, docTypeIdList);
	}

}
