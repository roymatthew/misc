package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeLenderDAO;
import com.ode.edocs.db.dao.DeLenderPartnerDAO;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderPartner;

@Service
public class DeLenderDAOServiceImpl implements IDeLenderDAOService {

	private static final Logger logger = LogManager.getLogger(DeLenderDAOServiceImpl.class);

	@Autowired
	private DeLenderDAO deLenderDAO;

	@Autowired
	private DeLenderPartnerDAO deLenderPartnerDAO;

	@Override
	public DeLenderDAO getDeLenderDAO() {
		return deLenderDAO;
	}

	@Override
	public void setDeLenderDAO(DeLenderDAO deLenderDAO) {

	}

	@Override
	public DeLender findLenderByLenderId(final String partnerId) throws Exception {
		return deLenderDAO.findByLenderId(partnerId);
	}

	@Override
	public DeLender findByLenderId(String lenderId) throws Exception {
		return deLenderDAO.findByLenderId(lenderId);
	}

	@Override
	public DeLender getDeLenderByLenderOrPartnerId(final String partyId) throws Exception {

		DeLender lender;
		try {
			lender = findLenderByLenderId(partyId);
			if (lender == null) {
				DeLenderPartner lenderPartner = deLenderPartnerDAO.getByPartnerId(partyId);
				if (null != lenderPartner) {
					lender = findLenderByLenderId(lenderPartner.getLenderId());
				} else {
					logger.error("Could not find DeLenderPartner with partyid: " + partyId);
					throw new Exception("Could not find DeLenderPartner with partyid: " + partyId);
				}
			}

			return lender;

		} catch (final Exception e) {
			logger.error("Could not find Lender with lenderid/partyid: " + partyId);
			throw e;
		}
	}

}
