package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeLenderDestinationDAO;
import com.ode.edocs.db.entity.DeLenderDestination;

@Service
public class DeLenderDestinationDAOServiceImpl implements IDeLenderDestinationDAOService {

	private static final Logger logger = LogManager.getLogger(DeLenderDestinationDAOServiceImpl.class);

	@Autowired
	private DeLenderDestinationDAO deLenderDestinationDAO;

	@Override
	public DeLenderDestinationDAO getDeLenderDestinationDAO() {
		return deLenderDestinationDAO;
	}

	@Override
	public void setDeLenderDestinationDAO(DeLenderDestinationDAO deLenderDestinationDAO) {

	}

	@Override
	public DeLenderDestination findByLenderId(String lenderId, String applicationLp) throws Exception {
		return deLenderDestinationDAO.findByLenderId(lenderId, applicationLp);
	}

	@Override
	public DeLenderDestination findByLenderIdAndProduct(String lenderDestinationId, String applicationEdocs,
			String productEyesOnDoc) throws Exception {
		return deLenderDestinationDAO.findByLenderIdAndProduct(lenderDestinationId, applicationEdocs, productEyesOnDoc);
	}

}
