package com.ode.edocs.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeLenderFeatureDAO;
import com.ode.edocs.db.entity.DeLenderFeature;
import com.ode.edocs.util.AppConstants;

@Service
public class DeLenderFeatureServiceImpl implements IDeLenderFeatureService {
	
	@Autowired
    private DeLenderFeatureDAO deLenderFeatureDAO;

	@Override
    public DeLenderFeatureDAO getDeLenderFeatureDAO() {
        return deLenderFeatureDAO;
    }
	
	@Override
    public void setDeLenderFeatureDAO(DeLenderFeatureDAO deLenderFeatureDAO) {
        this.deLenderFeatureDAO = deLenderFeatureDAO;
    }
	
	@Override
	public List<DeLenderFeature> getFeaturesForLenderAndDms(String lenderId, String dmsId) throws Exception {
		List<String> dmsSearchList = new ArrayList<String>();
		dmsSearchList.add(dmsId);
		dmsSearchList.add(AppConstants.DMS_SEARCH_CRITERIA_ALL);
        return getDeLenderFeatureDAO().getFeaturesForLenderAndDms(lenderId, dmsSearchList);
    }
}
