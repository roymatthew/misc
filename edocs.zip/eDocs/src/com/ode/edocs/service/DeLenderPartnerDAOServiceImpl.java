package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeLenderPartnerDAO;
import com.ode.edocs.db.entity.DeLenderPartner;

@Service
public class DeLenderPartnerDAOServiceImpl implements IDeLenderPartnerDAOService {

	private static final Logger logger = LogManager.getLogger(DeLenderPartnerDAOServiceImpl.class);

	@Autowired
	private DeLenderPartnerDAO deLenderPartnerDAO;

	@Override
	public DeLenderPartnerDAO getDeLenderPartnerDAO() {
		return deLenderPartnerDAO;
	}

	@Override
	public void setDeLenderPartnerDAO(DeLenderPartnerDAO deLenderPartnerDAO) {

	}

	@Override
	public DeLenderPartner getLenderPartnerByPartnerId(final String partnerId) throws Exception {
		return deLenderPartnerDAO.getByPartnerId(partnerId);
	}

	@Override
	public DeLenderPartner getByPartnerId(String partnerId) throws Exception {
		return deLenderPartnerDAO.getByPartnerId(partnerId);
	}

	@Override
	public List<DeLenderPartner> getListByLenderId(String lenderId) throws Exception {
		return deLenderPartnerDAO.getListByLenderId(lenderId);
	}
}
