package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeMaintenanceHistoryDAO;
import com.ode.edocs.db.entity.DeMaintenanceHistory;

@Service
public class DeMaintenanceHistoryDAOServiceImpl implements IDeMaintenanceHistoryDAOService {

	private static final Logger logger = LogManager.getLogger(DeMaintenanceHistoryDAOServiceImpl.class);

	@Autowired
	private DeMaintenanceHistoryDAO deMaintenanceHistoryDAO;

	@Override
	public DeMaintenanceHistoryDAO getDeMaintenanceHistoryDAO() {
		return deMaintenanceHistoryDAO;
	}

	@Override
	public void setDeMaintenanceHistoryDAO(DeMaintenanceHistoryDAO deMaintenanceHistoryDAO) {

	}

	@Override
	public List<DeMaintenanceHistory> getRecordsForDeDeal(String deDealId) throws Exception {
		return deMaintenanceHistoryDAO.getRecordsForDeDeal(deDealId);
	}

}
