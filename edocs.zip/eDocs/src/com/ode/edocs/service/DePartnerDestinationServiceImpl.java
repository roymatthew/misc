package com.ode.edocs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DePartnerDestinationDAO;
import com.ode.edocs.db.entity.DePartnerDestination;

@Service
public class DePartnerDestinationServiceImpl implements IDePartnerDestinationService {
	
	@Autowired
	private DePartnerDestinationDAO dePartnerDestinationDAO;

	/**
     * {@inheritDoc}
     */
	@Override
	public DePartnerDestinationDAO getDePartnerDestinationDAO() {
		return dePartnerDestinationDAO;
	}

	/**
     * {@inheritDoc}
     */
	@Override
	public void setDePartnerDestinationDAO(DePartnerDestinationDAO dePartnerDestinationDAO) {
		this.dePartnerDestinationDAO = dePartnerDestinationDAO;
	}
	
	/**
     * {@inheritDoc}
     */
	@Override
	public DePartnerDestination findByProduct(String product) throws Exception {
		return getDePartnerDestinationDAO().findByProduct(product);
	}
	
	@Override
	public DePartnerDestination findByPartnerAndProduct(String partnerId, String product) throws Exception {
		return getDePartnerDestinationDAO().findByPartnerAndProduct(partnerId, product);
	}
}