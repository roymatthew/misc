package com.ode.edocs.service;

import java.time.Instant;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DeDealDAO;
import com.ode.edocs.db.dao.DeLenderPartnerDAO;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLenderPartner;
import com.ode.edocs.util.AppConstants;

@Service
public class DealServiceImplementation implements IDealService {

	private static final Logger logger = LogManager.getLogger(DealServiceImplementation.class);

	@Autowired
	private DeDealDAO deDealDAO;

	@Autowired
	private DeLenderPartnerDAO deLenderPartner;

	@Override
	public DeDealDAO getDeDealDAO() throws Exception {
		return deDealDAO;
	}

	@Override
	public void setDeDealDAO(DeDealDAO deDealDAO) {

	}

	@Value("${master_lender_code_translation}")
	private String[] masterLenderCodeTranslation;

	private static Map<String, List<String>> lenderCodesMap = new HashMap<String, List<String>>();

	public void loadLenderCodes() {
		if (lenderCodesMap.isEmpty()) {
			try {
				for (String lenderToTranslate : masterLenderCodeTranslation) {
					List<DeLenderPartner> deLenderPartnerlist = deLenderPartner.getListByLenderId(lenderToTranslate);
					List<String> partnerListFromDeLenderPartner = deLenderPartnerlist.stream()
							.map(l -> l.getPartnerId()).collect(Collectors.toList());
					partnerListFromDeLenderPartner.add(lenderToTranslate);
					lenderCodesMap.put(lenderToTranslate, partnerListFromDeLenderPartner);
				}
			} catch (Exception e) {
				logger.error("An error occured while getting partner codes: ", e);
			}
		}
	}

	@Override
	public DeDeal getDeal(String dealId) {
		try {
			return deDealDAO.getByDeDealId(dealId);
		} catch (final Exception e) {
			logger.error("Could not find Deal with dealId: " + dealId);
		}
		return null;
	}

	@Override
	public DeDeal getDealInEditState(final String dmsDealerId, final String dmsDealNum, final String lenderId,
			final String globalLenderId) throws Exception {

		logger.debug("Enter getDealInEditState. dmsDealerId: {}, dmsDealNum: {}, lenderId: {}, globalLenderId: {}", dmsDealerId, dmsDealNum, lenderId, globalLenderId);
		System.out.println("in getDealInEditState method ");
		Instant start = Instant.now();

		List<String> partnerListFromDeLenderPartner = lenderCodesMap.get(globalLenderId);

		DeDeal deal = null;

		if ((null != partnerListFromDeLenderPartner) && partnerListFromDeLenderPartner.contains(lenderId)) {
			deal = deDealDAO.findDeals(dmsDealerId, dmsDealNum, partnerListFromDeLenderPartner);
		} else {
			deal = deDealDAO.find(dmsDealerId, dmsDealNum, lenderId);
			logger.debug("Found deal");
		}

		if (null != deal) {
			deDealDAO.updateRecordState(deal, null, AppConstants.RECORD_STATE_READ_FOR_UPDATE, AppConstants.EDOCS_APP);
			logger.debug("Updated deal record state for edit");
			deal = deDealDAO.getByDeDealId(deal.getDealId());
		    logger.debug("Got deal by dealId " +deal.getDealId());
		}
		logger.debug("Exit getDealInEditState");
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();  
		logger.debug("Time taken to execute getDealInEditState: " + timeElapsed);
	    System.out.println("Time taken to execute getDealInEditState: " +timeElapsed);
		System.out.println("getting out of getDealInEditState method ");
		return deal;
	}

	@Override
	public void saveOrUpdate(final DeDeal deal) throws Exception {
		deDealDAO.saveOrUpdate(deal);
	}

	@Override
	public void updateRecordState(final String dealId, String latestDistributionStatus, final String recordState, final String modifiedUser)
			throws Exception {
		logger.debug("Enter updateRecordState");

		final DeDeal deal = deDealDAO.getByDeDealId(dealId);

		deDealDAO.updateRecordState(deal, latestDistributionStatus, recordState, modifiedUser);

		logger.debug("Exit updateRecordState");
	}

	@Override
	public DeDeal getByDeDealId(final String deDealId) throws Exception {
		return deDealDAO.getByDeDealId(deDealId);
	}

	@Override
	public DeDeal find(String dealerId, String dealId, String lenderId) throws Exception {
		return deDealDAO.find(dealerId, dealId, lenderId);
	}
}
