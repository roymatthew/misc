package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DealerPpNvpDAO;
import com.ode.edocs.db.entity.DealerPpNvp;

@Service
public class DealerPpNvpDAOServiceImpl implements IDealerPpNvpDAOService {

	private static final Logger logger = LogManager.getLogger(DealerPpNvpDAOServiceImpl.class);

	@Autowired
	private DealerPpNvpDAO dealerPpNvpDAO;

	@Override
	public DealerPpNvpDAO getDealerPpNvpDAO() {
		return dealerPpNvpDAO;
	}

	@Override
	public void setDealerPpNvpDAO(DealerPpNvpDAO dealerPpNvpDAO) {
	}

	@Override
	public DealerPpNvp findEyesOnDocFlag(final String dmsDealerId, final String lenderId) throws Exception {
		return dealerPpNvpDAO.findEyesOnDocFlag(dmsDealerId, lenderId);
	}

	@Override
	public boolean isRouteOneEnabledForDealer(String dealerId, String lenderId, String dmsId, String productId) throws Exception {
		DealerPpNvp dealerPpNvp = dealerPpNvpDAO.isRouteOneEnabledForDealer(dealerId, lenderId, dmsId, productId);
		if (dealerPpNvp == null) {
			logger.info("RouteOne partial integration enabled for lender, but dealer is not enabled for integration");
			return false;
		}
		logger.info("RouteOne partial integration enabled for lender, and dealer is enabled for integration");
		return true;
	}
}
