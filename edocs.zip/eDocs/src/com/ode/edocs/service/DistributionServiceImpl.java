package com.ode.edocs.service;

import com.ode.edocs.DistributionCheckHandler;
import com.ode.edocs.DistributionErrorHandler;
import com.ode.edocs.ReCVData;
import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.bo.LenderBO;
import com.ode.edocs.bo.factory.DmsBOFactory;
import com.ode.edocs.bo.factory.LenderBOFactory;
import com.ode.edocs.db.dao.DcDistributionDAO;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.DistributionHelper;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.EncryptionUtils;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.IHandleDistributeUtil;
import com.ode.edocs.util.IPrepareDistributionUtil;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.IZipUtil;
import com.ode.edocs.util.RandomGUID;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.edocs.vo.BeginCompleteProcessingVO;
import com.ode.edocs.vo.DistributionProcessingVO;
import com.ode.edocs.vo.ParameterVOBuilderFactory;
import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DistributionServiceImpl implements IDistributionService {

    private static final Logger logger = LogManager.getLogger(DistributionServiceImpl.class);

    @Autowired
    private DmsBOFactory dmsBOFactory;

    @Autowired
    private LenderBOFactory lenderBOFactory;

    @Autowired
    private DistributionErrorHandler distributionErrorHandler;

    @Autowired
    private DcDistributionDAO dcDistributionDAO;

    @Autowired
    private VaultRegisterDocumentDAO vaultRegisterDocumentDAO;

    @Autowired
    private FormsDAO formsDao;

    @Autowired
    private IBeginDistributeService beginDistributeService;

    @Autowired
    private IDeLenderDAOService deLenderService;

    @Autowired
    private ISpotCheckService spotCheckService;

    @Autowired
    private ICreditJournalService creditJournalService;

    @Autowired
    private IDealService dealService;

    @Autowired
    private IPrepareDistributionUtil prepareDistributionUtil;

    @Autowired
    private IValidationUtil validationUtil;

    @Autowired
    private IHandleDistributeUtil handleDistributeImpl;

    @Autowired
    private IZipUtil zipUtil;
    
    @Autowired
    private DistributionCheckHandler distributionCheckHandler;

    @Override
    public DcDistribution prepareDistributionForCompletion(final DmsBO dms, final LenderBO lender,
        final Document eDocIn, final Date timeStamp, final ErrorDetail errorDetail) throws Exception {
        logger.debug("Enter prepareDistributionForCompletion");
        DcDistribution distribution = null;
        final List<DistributionHelper> distHelpers = HandlerUtils.getDistributionDataFromNodes(eDocIn);
        for (DistributionHelper distHelper : distHelpers) {
            prepareDistributionUtil.prepareDistributionForCompletion(distHelper, timeStamp, errorDetail);
        }
        logger.debug("Exit prepareDistributionForCompletion");
        return distribution;
    }

    @Override
    public DcDistribution handleDistribution(final String xmlString, final Date timeStamp) throws Exception {

        logger.debug("Entry");
        final LocalDateTime start = LocalDateTime.now();
        DcDistribution distribution = null;
        boolean distributionHasContract = false;
        final ErrorDetail errorDetail = new ErrorDetail();
        ReCVData reCVData = null;
        final DistributionProcessingVO distributionProcessingVO = EdocsXmlUtils
            .getDistributionProcessingParams(xmlString);

        logger.debug("***** Start EDOCS handleDistribution at: " + start + " *****");
        logger.debug("DealerId: " + distributionProcessingVO.getDealerId() + ", DealId: "
            + distributionProcessingVO.getDmsDealNumber());

        final Document eDocsIncomingDocument = EdocsXmlUtils.getDocumentFromString(xmlString);
        
        String vaultDocId = HandlerUtils.getVaultDocId(eDocsIncomingDocument);

        final DmsBO dms = dmsBOFactory.createDMS(distributionProcessingVO.getDmsId());
        dms.init(distributionProcessingVO.geteDocIn());

        DeLender lender;
        String responseMessage = "";
        try {
            lender = deLenderService.getDeLenderByLenderOrPartnerId(distributionProcessingVO.getPartyId());
        } catch (final Exception e) {
            throw new ApplicationException(AppConstants.DE_LENDER_NOT_FOUND_MESSAGE,
                AppConstants.DE_LENDER_NOT_FOUND_CODE);
        }

        final LenderBO lenderBO = lenderBOFactory.createLender(lender.getLender_id(),
            distributionProcessingVO.getPartyId(), dms);

        DeDeal deal = null;
        try {

            dealService.loadLenderCodes();
            // pull deal by incoming partyid
            deal = dealService.getDealInEditState(distributionProcessingVO.getDealerId(),
                distributionProcessingVO.getDmsDealNumber(), distributionProcessingVO.getPartyId(), lender.getLender_id());
            if (null != deal) {
            	distributionProcessingVO.setPreviousDistributionStatus(deal.getLatestDistributionStatus());
            	distributionCheckHandler.ifStatusSubmitted(deal);
				if (null != vaultDocId && !vaultDocId.isEmpty()) {
					// Write the vault doc id to table only if DMS is not Reynolds
					if (!AppConstants.DSP_REYNOLDS.equals(distributionProcessingVO.getDmsId()) && !AppConstants.DSP_ADVENT.equals(distributionProcessingVO.getDmsId())) deal.setVaultDocId(vaultDocId);
				}
                logger.debug("Found deal with DmsDealNumber: " + distributionProcessingVO.getDmsDealNumber());
                distributionProcessingVO.setDeDealId(deal.getDealId());
            } else {
                logger.error("No deDeal found for DmsDealNumber: " + distributionProcessingVO.getDmsDealNumber());
                throw new ApplicationException(errorDetail.add(AppConstants.DE_DEAL_NOT_FOUND_MESSAGE, AppConstants.DE_DEAL_NOT_FOUND_CODE));
            }

            // Find Contract Validation record, based on lender and sequence id
            final DeContractValidation contractValidation = dms.getContractValidation(lenderBO, deal, errorDetail);
            if (contractValidation == null) {
            	logger.info("No valid CV identified for this distribution");
            	throw new ApplicationException(errorDetail.add(AppConstants.CV_STATUS_NOT_PASSED_ERROR_MESSAGE, AppConstants.CV_STATUS_NOT_PASSED_CODE));
            }
            if (null != contractValidation.getApplicationType() && !contractValidation.getApplicationType().isEmpty()) {
                deal.setApplicationType(contractValidation.getApplicationType());
            }

            // start getting distributions
            final List<DcDistribution> distributions = getDistributions(deal.getDealId());
            final String sequenceId = handleDistributeImpl.determineSequenceId(distributions);
            distributionProcessingVO.setDistributionSequenceId(sequenceId);
            distributionProcessingVO.setDealerId(deal.getDmsDealerId());
            // check distribution status
            validationUtil.checkDistributionStatus(distributions, errorDetail);

            // get eyes on doc flag
            final boolean eyesOnDocFlag = validationUtil.isEyesOnDocEnabled(deal.getDmsDealerId(), deal.getLenderId(), lender);

            // get ancillary files
            // attachmentProcessingVO has files and ancillary files
            final AttachmentProcessingVO attachmentProcessingVO = zipUtil.extractAttachmentParams(distributionProcessingVO, errorDetail);

            // check if distribution has contract
            distributionHasContract = validationUtil.doesDistributionHasContract(attachmentProcessingVO.getFiles(),
                distributionProcessingVO.getDmsId(), lender.getLender_id());

            if (distributionHasContract) {
                deal.setDistributedCvSeqId(contractValidation.getId().getSequenceId());
            }
            
            // Is the incoming distribution to be send to RouteOne?
         	boolean isRouteOneTransaction = validationUtil.isRouteOneTransaction(lender.getLender_id(), distributionProcessingVO.getDealerId(), distributionProcessingVO.getDmsId(), AppConstants.PRODUCT_DC);
         	logger.debug("Is R1 transaction: ",  isRouteOneTransaction);
         	
         	String transType = AppConstants.TRANS_TYPE_ECOUT;
         	
			if (isRouteOneTransaction) {
				transType = AppConstants.TRANS_TYPE_ECOUT2;
			} else {
				boolean isNewCVWorkflow = validationUtil.isNewCVWorkflow(lender.getLender_id(),
						distributionProcessingVO.getDealerId(), distributionProcessingVO.getDmsId(),
						AppConstants.PRODUCT_DC);
				if (isNewCVWorkflow) {
					transType = AppConstants.TRANS_TYPE_ECOUT2;
				}
			}
         	
         	
            // get credit journal record
            CreditJournal creditJournalEcout = creditJournalService.getCreditJournalRecord(deal, contractValidation, transType);
            String accountId = null;
            if (null != creditJournalEcout) {
                accountId = creditJournalEcout.getAccountId();
            }

            // write EDOCIN to credit journal with new generated transactionId
            final String transactionId = RandomGUID.getInstance().getRandomGUID(false);
            errorDetail.setTransactionId(transactionId);
            final BigInteger edocInCreditJournalKey = creditJournalService.writeEDOCIN(distributionProcessingVO, timeStamp, transactionId, accountId);

            // RouteOne end point consist of contract id. If we do not have valid contract id for the identified CV, throw error
         	if (isRouteOneTransaction) {
         		if ((contractValidation.getContractId() == null || "".equals(contractValidation.getContractId())) && !eyesOnDocFlag) {
         			logger.debug("Contract Id: {}. This is a RouteOne transaction and we need valid contract id for sending distribution", contractValidation.getContractId());
         			throw new ApplicationException(errorDetail.add(AppConstants.CV_CONTRACT_ID_NOT_FOUND_MESSAGE, AppConstants.CV_CONTRACT_ID_NOT_FOUND));
         		}
         	}
         	
         	// File processing
         	// PDF size check, resolution check
         	final byte[] byteArray = zipUtil.processZipAttachmentFile(distributionProcessingVO, attachmentProcessingVO, lender, eyesOnDocFlag, errorDetail);
         	
         	// do spot check
            reCVData = spotCheckService.handleSpotCheck(distributionProcessingVO, distributions, creditJournalEcout, lender, deal, timeStamp, errorDetail);
         	
            //Update VaultDocId to deDeal to facilitate VaultWS to identify a deal using VaultDocId.
            dealService.saveOrUpdate(deal);
            
            // -- Vault Assignment --
            // As of now we only do validate vaulted contract for CDK. For other DMSs this call just returns the deal unchanged.
            deal = dms.validateVaultedContract(eDocsIncomingDocument, lender, deal, errorDetail, isRouteOneTransaction);
                        
            logger.debug("Deal eConStatus after validating vaulted contract: " + deal.getEconStatus());

            // start Reynolds specific checks
            final String vaultIndicator = handleDistributeImpl.determineVaultIndicator(deal);

            // Check if Econ Status is Assigned
            dms.validateEconStatus(lenderBO, deal);

            // if DMS is RR, do the contract check for Chase
            dms.checkContractInForms(deal, attachmentProcessingVO.getFiles(), formsDao, errorDetail, lenderBO);
            dms.validateFundingStatus(deal, errorDetail, lenderBO);
            dms.validateContractStatus(deal, vaultRegisterDocumentDAO, distributionHasContract, attachmentProcessingVO,
                lenderBO, errorDetail);
            // if DMS is RR, validateContract logic would executed for all
            // lenders except VCI
            dms.validateContract(lenderBO, distributions, vaultIndicator, attachmentProcessingVO.getFiles(), deal,
                lender.getLender_id(), errorDetail);
            // if DMS is RR, validateLender logic would be executed for all
            // lenders except VCI
            dms.validateLender(lenderBO, deal, lender.getLender_id(), distributionProcessingVO.getPartyId(),
                vaultIndicator, errorDetail);
            // end Reynolds specific checks

            // save deal
            dealService.saveOrUpdate(deal);

            // Process zip attachments.
            final LocalDateTime zipStart = LocalDateTime.now();
            final String processedBase64Zip = EncryptionUtils.base64Encode(byteArray);
            ParameterVOBuilderFactory.createBeginDistributeParametersVO(eDocsIncomingDocument, dms, lender, deal)
            .setCreditJournalParams(edocInCreditJournalKey, creditJournalEcout)
            .setFileParams(attachmentProcessingVO.getFiles(), processedBase64Zip)
            .setContractValidationParams(contractValidation, reCVData, eyesOnDocFlag, vaultIndicator)
            .setIds(sequenceId, transactionId, accountId).setErrorHandlingParameters(timeStamp, errorDetail);
            final LocalDateTime zipEnd = LocalDateTime.now();
            logger.debug("Zip attachment processing took " + ChronoUnit.SECONDS.between(zipStart, zipEnd) + " seconds");

            BeginCompleteProcessingVO beginCompleteProcessingVO = new BeginCompleteProcessingVO();
            beginCompleteProcessingVO.seteDocIn(eDocsIncomingDocument);
            beginCompleteProcessingVO.setTimeStamp(timeStamp);
            beginCompleteProcessingVO.setEdocInCjKey(edocInCreditJournalKey);
            beginCompleteProcessingVO.setSequenceId(sequenceId);
            beginCompleteProcessingVO.setFiles(attachmentProcessingVO.getFiles());
            beginCompleteProcessingVO.setProcessedBase64Zip(processedBase64Zip);
            beginCompleteProcessingVO.setTransactionId(transactionId);
            beginCompleteProcessingVO.setAccountId(accountId);
            beginCompleteProcessingVO.setIndValue(vaultIndicator);
            beginCompleteProcessingVO.setEyesOnDoc(eyesOnDocFlag);

            distribution = beginDistributeService.beginDistribute(beginCompleteProcessingVO, lender, deal, reCVData,
                creditJournalEcout, contractValidation, errorDetail, isRouteOneTransaction);

            responseMessage = AppConstants.DISTRIBUTE_SUCCESS_CODE + "-" + AppConstants.DISTRIBUTE_SUCCESS_MESSAGE;

            /* Update deal record state to update completed */
            dealService.updateRecordState(deal.getDealId(), null, AppConstants.RECORD_STATE_UPDATE_COMPLETE,
                AppConstants.EDOCS_APP);

        } catch (final Exception e) {
            // call the distributionErrorHandler to handle updates of credit
            // journal record, distribution record etc
            // we will also reset the record state of deal record and throw
            // ApplicationException back
            logger.error(e);
            distributionErrorHandler.handleDistributionError(e, distributionProcessingVO, deal);
        } finally {
            if (null != eDocsIncomingDocument) {
                try {
                    BigInteger edocAckOutCjKey = creditJournalService.writeEDOCACKOUT(eDocsIncomingDocument,
                        responseMessage, new Date(), distribution);
                    logger.debug("EDOCACKOUT CJKEY: {}", edocAckOutCjKey);
                } catch (Exception ex) {
                    logger.error("Error saving EDOCACKOUT.", ex);
                }
            }
        }

        final LocalDateTime end = LocalDateTime.now();
        logger.debug("***** End handleDistribution at: " + end + " *****");
        logger.debug("Distribution process took " + ChronoUnit.SECONDS.between(start, end) + " seconds");
        return distribution;
    }

    @Override
    public List<DcDistribution> getDistributions(final String dealId) throws Exception {
        return dcDistributionDAO.find(dealId);
    }

    @Override
    public DcDistribution find(String deDealId, String sequenceId) throws Exception {
        return dcDistributionDAO.find(deDealId, sequenceId);
    }

    @Override
    public List<DcDistribution> find(String deDealId) throws Exception {
        return dcDistributionDAO.find(deDealId);
    }

    @Override
    public void save(DcDistribution distribution) throws Exception {
        dcDistributionDAO.save(distribution);
    }

    @Override
    public void saveOrUpdate(DcDistribution distribution) throws Exception {
        dcDistributionDAO.saveOrUpdate(distribution);
    }

    @Override
    public DcDistributionDAO getDcDistributionDAO() {
        return dcDistributionDAO;
    }

    @Override
    public void setDcDistributionDAO(DcDistributionDAO dcDistributionDAO) {

    }
}
