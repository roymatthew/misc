package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.DmsDocTypeDAO;
import com.ode.edocs.db.entity.DmsDocType;

@Service
public class DmsDocTypeDAOServiceImpl implements IDmsDocTypeDAOService {
	private static final Logger logger = LogManager.getLogger(DmsDocTypeDAOServiceImpl.class);

	@Autowired
	private DmsDocTypeDAO dmsDocTypeDAO;

	@Override
	public DmsDocTypeDAO getDmsDocTypeDAO() {
		return dmsDocTypeDAO;
	}

	@Override
	public void setDmsDocTypeDAO(DmsDocTypeDAO dmsDocTypeDAO) {

	}

	@Override
	public DmsDocType findByName(String formattedFileName, String dmsId) throws Exception {
		return dmsDocTypeDAO.findByName(formattedFileName, dmsId);
	}

	@Override
	public DmsDocType findDmsDocTypeByName(String formattedFileName, String dmsId) throws Exception {
		return dmsDocTypeDAO.findByName(formattedFileName, dmsId);
	}

}
