package com.ode.edocs.service;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DmsDocType;
import com.ode.edocs.rest.entity.DocDataReviewResponse;
import com.ode.edocs.rest.entity.DocumentReviewRequest;
import com.ode.edocs.rest.entity.FormElementKey;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.IDataValueUtil;
import com.ode.edocs.util.IHandleDistributeUtil;

@Service
public class DocDataReviewServiceImpl implements IDocDataReviewService {
	private static final Logger logger = LogManager.getLogger(DocDataReviewServiceImpl.class);

	@Autowired
	private MetaDataHandler metaDataHandler;
	@Autowired
	private IHandleDistributeUtil handleDistributeUtil;
	@Autowired
	private IDataValueUtil dataValueUtil;
	@Autowired
	private IDmsDocTypeDAOService dmsdocTypeService;
	@Autowired
	private IDeContractValidationDAOService deContractValidationService;
	@Autowired
	private ICreditJournalService creditJournalService;
	@Autowired
	private IDcDocumentService dcDocumentService;
	@Autowired
	private IDocDataService dcDocDataService;
	@Autowired
	private IDcDocFieldDAOService dcDocFieldService;

	private NumberFormat sequenceNumberFormat = NumberFormat.getIntegerInstance();
	// create for autonomous funding flow
	// use dcDocTypeId, lenderId and stateId as key and corresponding metaData
	// fields from DE_DATA_ELEMENT table as value
	// store map into memory and lookup based on distribution file information
	private static HashMap<FormElementKey, List<DeDataElement>> metaDataMap;

	static {
		metaDataMap = new HashMap<FormElementKey, List<DeDataElement>>();
	}

	public DocDataReviewServiceImpl() {
		super();
		sequenceNumberFormat.setMaximumIntegerDigits(2);
		sequenceNumberFormat.setMinimumIntegerDigits(2);
	}

	/**
	 * Document Review request from DE UI
	 *
	 * @param request
	 * @return
	 */
	@Override
	public DocDataReviewResponse documentReview(DocumentReviewRequest request) {
		logger.debug("Entered documentReview(DocumentReviewRequest request) method");
		List<DcDocData> dcDocData = null;
		DocDataReviewResponse response = new DocDataReviewResponse();

		try {
			// Get all DC_DOC_DATA records for this document
			dcDocData = dcDocDataService.findDataByDcDocumentId(request.getDcDocumentId());

			// Get latest ECOUT
			CreditJournal cjEcout = creditJournalService.getLatestECOUTRecord(request);
			Document ecOut = creditJournalService.getDocumentFromCreditJournal(cjEcout);

			// Get lender
			DeLender lender = handleDistributeUtil.getLender(request.getLenderId());

			// New tables are used to get the meta data fields
			if ("Y".equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {
				// Find the list of review questions data element names for this
				// document from DC_DOC_DATA table (type R/ E)
				List<String> metaDataFieldNames = new ArrayList<String>();
				for (DcDocData dcDoc : dcDocData.stream()
						.filter(p -> p.getSection().equals("R") || p.getSection().equals("E"))
						.collect(Collectors.toList())) {
					metaDataFieldNames.add(dcDoc.getDataName());
				}

				// All the data elements from session (this is populated already
				// at the initial eDocs processing)
				Set<DeDataElement> uniqueDataElements = new HashSet<DeDataElement>();
				Iterator<FormElementKey> it = metaDataMap.keySet().iterator();
				while (it.hasNext()) {
					List<DeDataElement> elements = metaDataMap.get(it.next());
					if (elements != null) {
						for (DeDataElement e : elements) {
							uniqueDataElements.add(e);
						}
					}
				}

				if (uniqueDataElements.size() == 0) {
					// We do not have the list from session, at least get the
					// fields corresponding to this document

					// Find the DMS Doc Type/ DC Doc Type associated to this
					// document and get the dc doc type id
					String lenderDocName = request.getLenderDocName();
					DmsDocType dmsDocType = dmsdocTypeService.findByName(lenderDocName, request.getDmsId());

					if (null != dmsDocType) {
						Integer dcDocTypeId = dmsDocType.getDcDocType().getId();
						FormElementKey key = metaDataHandler.buildElementKey(dcDocTypeId, lender.getLender_id(),
								request.getContractExecutionState());
						if (!metaDataMap.containsKey(key)) {
							List<DeDataElement> elements = metaDataHandler.getMetaDataFields(key);
							metaDataMap.put(key, elements);
							for (DeDataElement e : elements) {
								uniqueDataElements.add(e);
							}
						}
					}
				}

				// Unique list of Data Elements
				List<DeDataElement> dataElements = new ArrayList<DeDataElement>(uniqueDataElements);

				boolean isFormComplete = true;
				for (DeDataElement r : dataElements) {
					if (metaDataFieldNames.contains(r.getElementName())) {
						DcDocData docReviewData = dcDocData.stream()
								.filter(p -> p.getDataName().equals(r.getElementName())).findFirst().orElse(null);

						if (null != docReviewData) {
							String result = "";
							if ("E".equals(r.getElementType())) { // Special
								// Review
								// Question
								String lenderSeqNum = "";

								if ("SequenceNumberMatchesCV".equals(r.getElementName())) {
									DeContractValidation cv = deContractValidationService
											.findWithSequenceId(request.getDeDealId(), request.getPassedCVSequenceId());
									if (null != cv) {
										lenderSeqNum = cv.getLenderSeqNum();
									}
								}
								result = dataValueUtil.getDataValueForTypeE(dataElements, r, null, dcDocData,
										request.getDmsId(), lenderSeqNum);

							} else if ("R".equals(r.getElementType())) { // Review
								// Question
								result = dataValueUtil.evaluateDocumentReviewComparisonForAutonomousLender(null, null,
										dcDocData, ecOut, dataElements, r);
							}
							if ("N".equals(result)) {
								isFormComplete = false;
							}
							docReviewData.setDataValue(result);
							docReviewData.setModifiedBy(AppConstants.EDOCS_COMPARISON);
							docReviewData.setModifiedTs(new Date());

							// Update DcDocData
							dcDocDataService.saveOrUpdate(docReviewData);
						}
					}
				}

				// Calculate Form Complete flag for this document
				if (isFormComplete) {
					// All review question answers are 'Y', lets see the
					// metadata elements (section !"R")
					for (DcDocData dcDoc : dcDocData.stream().filter(p -> !"R".equals(p.getSection()))
							.collect(Collectors.toList())) {
						if (dcDoc.getDataValue() == null || "".equals(dcDoc.getDataValue())) {
							isFormComplete = false;
							break;
						}
					}
				}
				boolean documentUpdated = handleDistributeUtil.updateFormCompleteAndReviewedFlagForDocument(
						request.getDcDocumentId(), isFormComplete ? "Y" : "N", request.getModifiedBy());
				if (documentUpdated) {
					response.setDocumentMarkedAsReviewed(true);
					response.setDocumentMarkedAsComplete(isFormComplete);
				}

				// Calculate Ready to Book and Distribution reviewed flags for
				// this distribution
				boolean readyToBook = true;
				boolean distributionReviewed = true;
				List<DcDocument> dcDocuments = dcDocumentService.getDcDocumentList(request.getDeDealId(),
						request.getDistSequenceId());
				if (null != dcDocuments && dcDocuments.size() > 0) {
					for (DcDocument dcDocument : dcDocuments) {
						if (!"Y".equals(dcDocument.getFormComplete())) {
							readyToBook = false;
						}
						if (!AppConstants.DOC_STATUS_REVIEWED.equals(dcDocument.getDocStatus())) {
							distributionReviewed = false;
						}
					}
				}
				boolean distributionUpdated = handleDistributeUtil.updateReadyToBookAndReviewedFlagForDistribution(
						request.getDeDealId(), request.getDistSequenceId(), distributionReviewed,
						readyToBook ? "Y" : "N", request.getModifiedBy());
				if (distributionUpdated) {
					response.setDistributionMarkedAsReviewed(distributionReviewed);
					response.setDistributionMarkedAsReadyToBook(readyToBook);
				}
			} else {
				// DC_DOC_FIELD is used to get the meta data fields

				// Get all document review questions for this document type
				List<DcDocField> reviewQuestionDocFields = dcDocFieldService
						.findByDmsDocTypeIdAndSection(request.getDmsDocTypeId(), "R");

				// Get all DC_DOC_DATA records for this document
				dcDocData = dcDocDataService.findDataByDcDocumentId(request.getDcDocumentId());

				// Compare latest DC_DOC_DATA ancillary values Vs Contract data
				dataValueUtil.compareDocDataWithContract(ecOut, reviewQuestionDocFields, dcDocData, request.getDmsId(),
						request.getDcDocumentId());
			}
		} catch (Exception e) {
			response.setErrorOnDocReview(true);
			response.setErrorMessage("An error occured while doing document review. Please refresh");
			logger.error("An error occured while processing document review: ", e);
		}
		response.setLatestDcDocData(dcDocData);
		return response;
	}

}
