package com.ode.edocs.service;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DcDocDataDAO;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.IDataValueUtil;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocDataServiceImpl implements IDocDataService {

    private static final Logger logger = LogManager.getLogger(DocDataServiceImpl.class);

    @Autowired
    private DcDocDataDAO dcDocDataDAO;
    
    @Autowired
    private IDataValueUtil dataValueUtil;

    /**
     * {@inheritDoc}
     */
    @Override
    public Boolean savaDocDataForAutonomousLender(final File file, final DcDocument dcDocument, final Document ecout,
        DeDeal deDeal, final DeLender lender, String dmsId, DeContractValidation cv,
        final List<DeDataElement> dataElements, final String dmsDocName, final String applicationType)
            throws Exception {

        final Timestamp now = new Timestamp(new Date().getTime());

        if (null != file.getMetaDataFields() && file.getMetaDataFields().size() > 0) {
            for (DeDataElement field : file.getMetaDataFields()) {
                String dataValue = "";
                String elementType = field.getElementType();
                if (AppConstants.ANCILLARY_DATA_FLAG_YES.equalsIgnoreCase(lender.getAncillary_data_flag())) {
                    if ("M".equals(elementType) || "R".equals(elementType)) {
                        // Meta data / Review Question
                        dataValue = dataValueUtil.getDataValue(dmsId, ecout, file, null, field, lender, applicationType,
                            dataElements);
                    } else if ("D".equals(elementType)) {
                        // Special Meta data
                        dataValue = dataValueUtil.getDataValueForTypeD(field, file.getLenderDocName());
                    } else if ("E".equals(elementType)) {
                        // Special Review Question
                        dataValue = dataValueUtil.getDataValueForTypeE(dataElements, field, file, null, dmsId,
                            cv.getLenderSeqNum());
                    }
                    // any other element type will have blank value
                }

                DcDocData docData = new DcDocData();
                docData.setDcDocumentId(dcDocument.getId());
                docData.setDataName(field.getElementName());
                docData.setSection(field.getElementType());
                if (field.getElementName().equals("ValidationSequenceNumber")) {
                    docData.setDataValue(deDeal.getLenderSeqNum());
                } else if (field.getElementName().equals("AccountNumber")) {
                    docData.setDataValue(deDeal.getAccountNum());
                } else {
                    if (null != dataValue) {
                        dataValue = dataValue.trim();
                    }
                    docData.setDataValue(dataValue);
                }
                docData.setCreatedTs(now);
                docData.setCreatedBy(dmsId);
                docData.setModifiedTs(now);
                docData.setModifiedBy(dmsId);
                docData.setDisplayName(field.getDisplayName());
                docData.setGroupName(field.getGroupName());
                docData.setIsDropDown(field.getIsDropDown());
                docData.setIsEditable(field.getIsEditable());

                file.getDocData().add(docData);

            }

            return Boolean.TRUE;
        }
        logger.debug("No DE_DATA_ELEMENTs found for document: {}, No data updated in DC_DOC_DATA for this document.",
            dmsDocName);

        return Boolean.FALSE;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Boolean savaDocData(final File file, final DcDocument dcDocument, final Document ecout, DeDeal deDeal,
        final DeLender lender, String dmsId, DeContractValidation cv, final List<DeDataElement> dataElements,
        final String dmsDocName, final String applicationType) throws Exception {

        final Timestamp now = new Timestamp(new Date().getTime());

        if (null != file.getFields() && file.getFields().size() > 0) {
            for (DcDocField field : file.getFields()) {
                String dataValue = "";
                dataValue = dataValueUtil.getDataValue(dmsId, ecout, file, field, null, lender, applicationType, null);

                DcDocData docData = new DcDocData();
                docData.setDcDocumentId(dcDocument.getId());
                docData.setDataName(field.getFieldName());
                docData.setDataType(field.getFieldType());
                docData.setSection(field.getSection());
                if (field.getFieldName().equals("ValidationSequenceNumber")) {
                    docData.setDataValue(deDeal.getLenderSeqNum());
                } else if (field.getFieldName().equals("AccountNumber")) {
                    docData.setDataValue(deDeal.getAccountNum());
                } else {
                    if (null != dataValue) {
                        dataValue = dataValue.trim();
                    }
                    docData.setDataValue(dataValue);
                }
                docData.setCreatedTs(now);
                docData.setCreatedBy(dmsId);
                docData.setModifiedTs(now);
                docData.setModifiedBy(dmsId);
                docData.setDisplayName(null);
                docData.setGroupName(field.getGroup_name());

                file.getDocData().add(docData);
            }
            return Boolean.TRUE;
        }
        logger.debug("No DC_DOC_FIELDS found for document: {}, No data updated in DC_DOC_DATA for this document.",
            dmsDocName);
        return false;

    }
    
    @Override
    public DcDocDataDAO getDcDocDataDAO() {
        return dcDocDataDAO;
    }

    @Override
    public void setDcDocDataDAO(DcDocDataDAO dcDocDataDAO) {

    }
    
    @Override
    public DcDocData save(DcDocData docData) throws Exception {
    	return dcDocDataDAO.save(docData);
    }
    
    @Override
    public void saveOrUpdate(DcDocData docData) throws Exception {
    dcDocDataDAO.saveOrUpdate(docData);
    }
    
    @Override
    public List<DcDocData> findDataByDcDocumentId(Integer id) throws Exception {
        return dcDocDataDAO.findDataByDcDocumentId(id);
    }

}
