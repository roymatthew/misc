package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.FeatureConfigurationDAO;
import com.ode.edocs.db.entity.FeatureConfiguration;

@Service
public class FeatureConfigurationDAOServiceImpl implements IFeatureConfigurationDAOService {

	private static final Logger logger = LogManager.getLogger(FeatureConfigurationDAOServiceImpl.class);

	@Autowired
	private FeatureConfigurationDAO featureConfigurationDAO;

	@Override
	public FeatureConfigurationDAO getFeatureConfigurationDao() {
		return featureConfigurationDAO;
	}

	@Override
	public void setFeatureConfigurationDao(FeatureConfigurationDAO featureConfigurationDao) {

	}

	@Override
	public List<FeatureConfiguration> getConfiguration(String lenderId) {
		return featureConfigurationDAO.getConfiguration(lenderId);

	}

	@Override
	public List<FeatureConfiguration> getConfigurationWithName(String lenderId, String featureName) throws Exception {
		return featureConfigurationDAO.getConfigurationWithName(lenderId, featureName);
	}

}
