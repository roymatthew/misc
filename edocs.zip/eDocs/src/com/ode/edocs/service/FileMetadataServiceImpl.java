package com.ode.edocs.service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.File;
import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.FormElementKey;

@Service
public class FileMetadataServiceImpl implements IFileMetadataService {

	private static final Logger logger = LogManager.getLogger(FileMetadataServiceImpl.class);

	@Autowired
	private MetaDataHandler metaDataHandler;

	@Autowired
	private IDcDocFieldDAOService dcDocFieldService;

	private static HashMap<FormElementKey, List<DeDataElement>> sessionMetaDataMap;

	static {
		sessionMetaDataMap = new HashMap<FormElementKey, List<DeDataElement>>();
	}

	@Override
	public List<File> addMetaDataFieldsToDistributionFilesForAutonomousLender(final List<File> files,
			final DeLender lender, final DeDeal deal, final String financeType, final String applicationType)
			throws Exception {

		logger.debug("Entered addMetaDataFieldsToDistributionFilesForAutonomousLender()");

		FormElementKey key = new FormElementKey();
		key.setLenderId(lender.getLender_id());
		key.setStateId(deal.getDealExecutionState());

		final List<Integer> docTypeIdList = new ArrayList<>();

		files.stream().forEach(file -> {

			if (null != file.getDmsDocType() && null != file.getDmsDocType().getDcDocType()) {

				FormElementKey lookupKey = metaDataHandler.buildElementKey(file.getDmsDocType().getDcDocType().getId(),
						lender.getLender_id(), deal.getDealExecutionState());
				if (sessionMetaDataMap.get(lookupKey) == null) {
					docTypeIdList.add(Integer.valueOf(file.getDmsDocType().getDcDocType().getId()));
				}
			} else {
				logger.debug("Skipped file: " + file.getFormattedFileName()
						+ " for data element lookup since it's DmsDocType/DcDocType is null");
			}

		});

		final LocalDateTime start = LocalDateTime.now();
		Map<String, List<DeDataElement>> metaDataMap = new HashMap<>();
		if (!docTypeIdList.isEmpty()) {
			logger.debug("Calling metaDataHandler to bring back metadata fields map");
			metaDataMap = metaDataHandler.getMetaDataFieldsAsMap(key, docTypeIdList);
		}
		final LocalDateTime end = LocalDateTime.now();
		logger.debug("metaDataMap build completed in " + ChronoUnit.SECONDS.between(start, end) + " seconds");

		for (final File file : files) {

			if (null != file.getDmsDocType() && null != file.getDmsDocType().getDcDocType()) {

				final FormElementKey lookupKey = metaDataHandler.buildElementKey(
						file.getDmsDocType().getDcDocType().getId(), lender.getLender_id(),
						deal.getDealExecutionState());
				List<DeDataElement> dataElements = sessionMetaDataMap.get(lookupKey);
				if (dataElements == null || dataElements.isEmpty()) {
					dataElements = metaDataMap.get(String.valueOf(file.getDmsDocType().getDcDocType().getId()));
					sessionMetaDataMap.put(lookupKey, dataElements);
				} else {
					logger.debug("Found dataElements for key: " + lookupKey + " in sessionMetaDataMap.");

				}
				// filter the metadata fields based on finance type and
				// application type of the deal
				if (dataElements != null && !dataElements.isEmpty()) {
					file.setMetaDataFields(
							metaDataHandler.metaDataFieldsFilter(dataElements, financeType, applicationType));
				}

			}
		}

		logger.debug("Exit addMetaDataFieldsToDistributionFilesForAutonomousLender()");

		return files;
	}

	@Override
	public List<File> addFieldsToDistributionFilesForLender(final List<File> files) throws Exception {

		logger.debug("Entered addFieldsToDistributionFilesForLender()");

		files.stream().forEach(file -> {

			if (null != file.getDmsDocType()) {
				List<DcDocField> fields;
				try {
					fields = dcDocFieldService.findByDmsDocTypeId(file.getDmsDocType().getId());
					file.setFields(fields);
				} catch (final Exception e) {
					logger.error("Caught exception from DcDocFieldDAO.findByDmsDocTypeId()", e);
				}
			}

		});
		logger.debug("Exit addFieldsToDistributionFilesForLender()");
		return files;
	}

	@Override
	public HashMap<FormElementKey, List<DeDataElement>> getSessionMetaDataMap() {
		return sessionMetaDataMap;
	}

}
