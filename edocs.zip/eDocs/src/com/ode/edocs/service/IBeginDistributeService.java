package com.ode.edocs.service;

import com.ode.edocs.ReCVData;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.vo.BeginCompleteProcessingVO;
import java.math.BigInteger;
import java.util.Date;

public interface IBeginDistributeService {

    /**
     * @param beginCompleteProcessingVO
     * @param lender
     * @param deDeal
     * @param autoReCv
     * @param cjEcout
     * @param cv
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DcDistribution beginDistribute(BeginCompleteProcessingVO beginCompleteProcessingVO, DeLender lender, DeDeal deDeal,
        ReCVData autoReCv, CreditJournal cjEcout, DeContractValidation cv, ErrorDetail errorDetail, boolean isRouteOneTransaction) throws Exception;

    /**
     * @param deDealId
     * @param sequenceId
     * @param edocInCjKey
     * @param edocOutCjKey
     * @param distStatus
     * @param messageType
     * @param timeStamp
     * @param vaultDocId
     * @param cvSequenceId
     * @return
     * @throws Exception
     */
    DcDistribution buildDcDistributionRecord(String deDealId, String sequenceId, BigInteger edocInCjKey,
        BigInteger edocOutCjKey, String distStatus, String messageType, Date timeStamp, String vaultDocId,
        String cvSequenceId, String authorizationId) throws Exception;

}
