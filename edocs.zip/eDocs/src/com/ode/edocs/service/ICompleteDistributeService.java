package com.ode.edocs.service;

import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.vo.BeginCompleteProcessingVO;

public interface ICompleteDistributeService {

    /**
     * @param beginCompleteProcessingVO
     * @param deDeal
     * @param lender
     * @param ecout
     * @param financeType
     * @param distribution
     * @param errorDetail
     * @throws Exception
     */
    void completeDistribute(BeginCompleteProcessingVO beginCompleteProcessingVO, DeDeal deDeal, DeLender lender,
        String financeType, DcDistribution distribution, ErrorDetail errorDetail, boolean isRouteOneTransaction) throws Exception;

}
