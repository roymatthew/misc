package com.ode.edocs.service;

import com.ode.edocs.db.dao.CreditJournalDAO;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.rest.entity.DocumentReviewRequest;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.math.BigInteger;
import java.util.Date;
import org.jdom2.Document;
import org.jdom2.Namespace;

public interface ICreditJournalService {

    /**
     * @param deDeal
     * @param contractValidation
     * @return
     * @throws Exception
     */
    CreditJournal getCreditJournalRecord(final DeDeal deDeal, final DeContractValidation contractValidation, final String transType)
        throws Exception;
    
    /**
     * @param distributionProcessingVO
     * @param timeStamp
     * @param transactionId
     * @param accountId
     * @return
     * @throws Exception
     */
    
    BigInteger writeEDOCIN(final DistributionProcessingVO distributionProcessingVO, final Date timeStamp,
        final String transactionId, final String accountId) throws Exception;
    
    /**
     * @param distributionProcessingVO
     * @param timeStamp
     * @param transactionId
     * @param accountId
     * @return
     * @throws Exception
     */
    public BigInteger writePENIN(Document inDocument, String dataXml, Date timeStamp,
        String deDealId, String sequenceId, String transactionId, String accountId) throws Exception;
    
    /**
     * @param distributionProcessingVO
     * @param timeStamp
     * @param transactionId
     * @param accountId
     * @return
     * @throws Exception
     */
    public BigInteger writePENOUT(Document inDocument, String dataXml, Date timeStamp,
        String deDealId, String sequenceId, String transactionId, String accountId) throws Exception;

    /**
     * @param inDocument
     * @param eDocsResponse
     * @param timeStamp
     * @param distribution
     * @return
     * @throws Exception
     */
    BigInteger writeEDOCACKOUT(final Document inDocument, final String eDocsResponse, final Date timeStamp,
        final DcDistribution distribution) throws Exception;

    /**
     * @param transType
     * @param inDocument
     * @param lenderResponse
     * @param timeStamp
     * @param deDealId
     * @param sequenceId
     * @param transactionId
     * @param accountId
     * @return
     * @throws Exception
     */
    BigInteger writeEDOCACKIN(String transType, Document inDocument, String lenderResponse, Date timeStamp,
        String deDealId, String sequenceId, String transactionId, String accountId) throws Exception;

    /**
     * @param inDocument
     * @param outDocument
     * @param timeStamp
     * @param deDealId
     * @param sequenceId
     * @param transactionId
     * @param accountId
     * @return
     * @throws Exception
     */
    BigInteger writeEDOCOUT(Document inDocument, Document outDocument, Date timeStamp, String deDealId,
        String sequenceId, String transactionId, String accountId) throws Exception;

    /**
     * @param document
     * @param timeStamp
     * @param dealId
     * @param autoCvOut
     * @param cjEcout
     * @param dmsDealerId
     * @return
     * @throws Exception
     */
    BigInteger writeAUTOCVOUT(Document document, Date timeStamp, String dealId, String autoCvOut, CreditJournal cjEcout,
        String dmsDealerId, String lenderId) throws Exception;

    /**
     * @param document
     * @param timeStamp
     * @param deDealId
     * @param sequenceId
     * @param transactionId
     * @param dealerId
     * @param accountId
     * @param soaptrans
     * @return
     * @throws Exception
     */
    BigInteger writeEDOCIN(Document document, Date timeStamp, String deDealId, String sequenceId, String transactionId,
        String dealerId, String accountId, Namespace soaptrans) throws Exception;

    /**
     * @param edocInCjKey
     * @param transactionId
     * @throws Exception
     */
    void updateEDocIn(BigInteger edocInCjKey, String transactionId) throws Exception;

    /**
     * @param request
     * @return
     * @throws Exception
     */
    CreditJournal getLatestECOUTRecord(final DocumentReviewRequest request) throws Exception;

    /**
     * @param deDealId
     * @param sequenceId
     * @param dealerId
     * @param transType
     * @return
     * @throws Exception
     */
    CreditJournal findByDeDealIdAndSequenceId(final String deDealId, final String sequenceId, final String dealerId,
        final String transType) throws Exception;

    /**
     * @param creditJournal
     * @return
     * @throws ApplicationException
     * @throws Exception
     */
    Document getDocumentFromCreditJournal(CreditJournal creditJournal) throws ApplicationException, Exception;

    /**
     * @param creditJournalKey
     * @throws Exception
     */
    CreditJournal findByCreditJournalKey(final BigInteger creditJournalKey, final String transactionType)
        throws Exception;

    /**
     * @param creditJournalKey
     */
    void deleteCreditJournal(final BigInteger creditJournalKey);

    CreditJournalDAO getCreditJournalDAO();

    void setCreditJournalDAO(CreditJournalDAO creditJournalDAO);

    CreditJournal findLatestAccr(String dmsDealId, String transType, String dealerId, String partnerId) throws Exception;

    CreditJournal findMostRecentByTransactionId(String transactionId, String dealerId, String partnerId,
        String[] transTypes) throws Exception;

    CreditJournal findCreditJournalByCjKey(BigInteger edocInCjKey, String transType) throws Exception;

    BigInteger saveOrUpdate(CreditJournal creditJournal) throws Exception;

    void saveOrUpdateRecord(CreditJournal cj) throws Exception;

    public CreditJournal findMostRecentByDeDealId(String deDealId, String dealerId, String partnerId,
        String[] transTypes) throws Exception;

}
