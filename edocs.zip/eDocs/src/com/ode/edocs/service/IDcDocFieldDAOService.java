package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.DcDocFieldDAO;
import com.ode.edocs.db.entity.DcDocField;

public interface IDcDocFieldDAOService {

	DcDocFieldDAO getDcDocFieldDAO();

	void setDcDocFieldDAO(DcDocFieldDAO dcDocFieldDAO);

	List<DcDocField> findByDcDocTypeId(Integer dcDocTypeId) throws Exception;

	List<DcDocField> findByDmsDocTypeId(Integer id) throws Exception;

	List<DcDocField> findByDmsDocTypeIdAndSection(Integer dmsDocTypeId, String section) throws Exception;

}
