package com.ode.edocs.service;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DcDocumentBatchDAO;

public interface IDcDocumentBatchDAOService {

	void doBatchInsertDocData(final File file);

}
