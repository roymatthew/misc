package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DcDocumentDAO;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.vo.BeginCompleteProcessingVO;

public interface IDcDocumentService {

    /**
     * @param file
     * @param dealId
     * @param sequenceId
     * @param dmsId
     * @return
     * @throws Exception
     */
    DcDocument saveDcDocument(final File file, final String dealId, final String sequenceId, final String dmsId)
        throws Exception;

    /**
     * @param files
     * @param deDealId
     * @param lenderId
     * @throws Exception
     */
    String prepareDocuments(BeginCompleteProcessingVO beginCompleteProcessingVO, final DeLender lender,
        DeContractValidation cv, DeDeal deDeal, String applicationType, final String dmsId)
            throws Exception;

	DcDocumentDAO getDcDocumentDAO();

	void setDcDocumentDAO(DcDocumentDAO dcDocumentDAO);

	DcDocument save(DcDocument dcDocument) throws Exception;

	void saveOrUpdate(DcDocument dcDocument) throws Exception;

	DcDocument getDcDocument(String deDealId, String sequenceId, String dmsDocName) throws Exception;

	List<DcDocument> getDcDocumentList(String deDealId, String distSequenceId) throws Exception;

	DcDocument getDcDocument(Integer dcDocumentId) throws Exception;

}
