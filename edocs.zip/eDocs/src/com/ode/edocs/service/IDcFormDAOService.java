package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.DcFormDAO;
import com.ode.edocs.db.entity.DcForm;

public interface IDcFormDAOService {

	DcFormDAO getDcFormDAO();

	void setDcFormDAO(DcFormDAO dcFormDAO);

	void saveOrUpdate(DcForm dcForm) throws Exception;

	List<DcForm> findForms(String dealId, String formName) throws Exception;

	List<DcForm> findOutstandingForms(String deDealId, String formattedFileName) throws Exception;

}
