package com.ode.edocs.service;

import com.ode.edocs.db.dao.DeContractValidationDAO;
import com.ode.edocs.db.entity.DeContractValidation;

public interface IDeContractValidationDAOService {

	DeContractValidationDAO getDeContractValidationDAO();

	void setDeContractValidationDAO(DeContractValidationDAO deContractValidationDAO);

	DeContractValidation findMostRecentWithStatus(String deDealId, String[] statuses) throws Exception;

	DeContractValidation findMostRecentWithStatusAndLenderSequenceNumber(String deDealId, String[] statuses,
			String sequenceNumber) throws Exception;

	DeContractValidation findMostRecent(String deDealId) throws Exception;

	DeContractValidation findWithSequenceId(String deDealId, String sequenceId);
}
