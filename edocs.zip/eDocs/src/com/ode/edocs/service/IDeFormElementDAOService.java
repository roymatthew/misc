package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.DeFormElementDAO;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DeFormElement;
import com.ode.edocs.db.entity.FormElementEntity;
import com.ode.edocs.rest.entity.FormElementKey;

public interface IDeFormElementDAOService {

	FormsDAO getFormsDao() throws Exception;

	void setFormsDao(FormsDAO formsDao);

	void setDeFormElementDAO(DeFormElementDAO deFormElementDAO);

	DeFormElementDAO getDeFormElementDAO();

	DeFormElement getDeFormElement(FormElementKey key);

	List<DeFormElement> getDeFormElementsCollection(FormElementKey key, List<Integer> docTypeIdList);

	List<FormElementEntity> getFormElementEntityCollection(FormElementKey key, List<Integer> docTypeIdList);

}
