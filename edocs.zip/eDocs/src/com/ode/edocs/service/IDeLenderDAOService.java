package com.ode.edocs.service;

import com.ode.edocs.db.dao.DeLenderDAO;
import com.ode.edocs.db.entity.DeLender;

public interface IDeLenderDAOService {

	DeLenderDAO getDeLenderDAO();

	void setDeLenderDAO(DeLenderDAO deLenderDAO);

	DeLender findLenderByLenderId(String partnerId) throws Exception;

	DeLender findByLenderId(String lenderId) throws Exception;

	DeLender getDeLenderByLenderOrPartnerId(final String partyId) throws Exception;

}
