package com.ode.edocs.service;

import com.ode.edocs.db.dao.DeLenderDestinationDAO;
import com.ode.edocs.db.entity.DeLenderDestination;

public interface IDeLenderDestinationDAOService {

	DeLenderDestinationDAO getDeLenderDestinationDAO();

	void setDeLenderDestinationDAO(DeLenderDestinationDAO deLenderDestinationDAO);

	DeLenderDestination findByLenderId(String lenderId, String applicationLp) throws Exception;

	DeLenderDestination findByLenderIdAndProduct(String lenderDestinationId, String applicationEdocs,
			String productEyesOnDoc) throws Exception;

}
