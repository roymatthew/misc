package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.DeLenderFeatureDAO;
import com.ode.edocs.db.entity.DeLenderFeature;

public interface IDeLenderFeatureService {

	public DeLenderFeatureDAO getDeLenderFeatureDAO();
	
	public void setDeLenderFeatureDAO(DeLenderFeatureDAO deLenderFeatureDAO);
	
	public List<DeLenderFeature> getFeaturesForLenderAndDms(String lenderId, String dmsId) throws Exception;
}