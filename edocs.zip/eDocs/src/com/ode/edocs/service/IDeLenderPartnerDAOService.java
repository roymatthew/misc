package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.DeLenderPartnerDAO;
import com.ode.edocs.db.entity.DeLenderPartner;

public interface IDeLenderPartnerDAOService {

	DeLenderPartnerDAO getDeLenderPartnerDAO();

	void setDeLenderPartnerDAO(DeLenderPartnerDAO deLenderPartnerDAO);

	DeLenderPartner getLenderPartnerByPartnerId(String partnerId) throws Exception;

	DeLenderPartner getByPartnerId(String partnerId) throws Exception;

	List<DeLenderPartner> getListByLenderId(String lenderId) throws Exception;

}
