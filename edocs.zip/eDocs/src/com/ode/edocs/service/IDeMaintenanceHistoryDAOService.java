package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.DeMaintenanceHistoryDAO;
import com.ode.edocs.db.entity.DeMaintenanceHistory;

public interface IDeMaintenanceHistoryDAOService {

	DeMaintenanceHistoryDAO getDeMaintenanceHistoryDAO();

	void setDeMaintenanceHistoryDAO(DeMaintenanceHistoryDAO deMaintenanceHistoryDAO);

	List<DeMaintenanceHistory> getRecordsForDeDeal(String deDealId) throws Exception;
}
