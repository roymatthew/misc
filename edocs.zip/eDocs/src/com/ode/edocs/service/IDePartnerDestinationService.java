package com.ode.edocs.service;

import com.ode.edocs.db.dao.DePartnerDestinationDAO;
import com.ode.edocs.db.entity.DePartnerDestination;

public interface IDePartnerDestinationService {

	public DePartnerDestinationDAO getDePartnerDestinationDAO();
	
	public void setDePartnerDestinationDAO(DePartnerDestinationDAO dePartnerDestinationDAO);
	
	public DePartnerDestination findByProduct(String product) throws Exception;
	
	public DePartnerDestination findByPartnerAndProduct(String partnerId, String product) throws Exception;
}
