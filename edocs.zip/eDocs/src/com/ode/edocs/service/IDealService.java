package com.ode.edocs.service;

import com.ode.edocs.db.dao.DeDealDAO;
import com.ode.edocs.db.entity.DeDeal;

public interface IDealService {

    /**
     * @param dealId
     * @return
     */
    DeDeal getDeal(final String dealId);

    /**
     * @param deal
     * @throws Exception
     */
    void saveOrUpdate(final DeDeal deal) throws Exception;

    /**
     * @param dmsDealerId
     * @param dmsDealNum
     * @param lenderId
     * @return
     * @throws Exception
     */
    DeDeal getDealInEditState(final String dmsDealerId, final String dmsDealNum, final String lenderId, final String globalLenderId)
        throws Exception;

    /**
     * @param deal
     * @param recordState
     * @param modifiedUser
     * @throws Exception
     */
    void updateRecordState(final String dealId, final String latestDistributionStatus, final String recordState, final String modifiedUser) throws Exception;
    
    DeDealDAO getDeDealDAO() throws Exception;
	
	void setDeDealDAO(DeDealDAO deDealDAO);
    
    DeDeal getByDeDealId(String deDealId) throws Exception;
	
	DeDeal find(String dealerId, String dealId, String lenderId) throws Exception;
	
	void loadLenderCodes();
}
