package com.ode.edocs.service;

import com.ode.edocs.db.dao.DealerPpNvpDAO;
import com.ode.edocs.db.entity.DealerPpNvp;

public interface IDealerPpNvpDAOService {

	DealerPpNvpDAO getDealerPpNvpDAO();

	void setDealerPpNvpDAO(DealerPpNvpDAO dealerPpNvpDAO);

	DealerPpNvp findEyesOnDocFlag(String dmsDealerId, String lenderId) throws Exception;
	
	boolean isRouteOneEnabledForDealer(String dealerId, String lenderId, String dmsId, String productId) throws Exception;
}
