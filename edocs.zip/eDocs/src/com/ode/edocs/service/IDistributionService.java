package com.ode.edocs.service;

import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.bo.LenderBO;
import com.ode.edocs.db.dao.DcDistributionDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.rest.entity.ErrorDetail;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public interface IDistributionService {

    /**
     * @param xmlString String
     * @param timeStamp Date
     * @return Boolean
     * @throws Exception
     */
    DcDistribution handleDistribution(final String xmlString, final Date timeStamp) throws Exception;

    /**
     * @param dealId
     * @return
     * @throws Exception
     */
    List<DcDistribution> getDistributions(final String dealId) throws Exception;

    /**
     * @param dms
     * @param lender
     * @param eDocIn
     * @param timeStamp
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DcDistribution prepareDistributionForCompletion(DmsBO dms, LenderBO lender, Document eDocIn,
        Date timeStamp, ErrorDetail errorDetail) throws Exception;

	DcDistribution find(String deDealId, String sequenceId) throws Exception;

	List<DcDistribution> find(String deDealId) throws Exception;

	void save(DcDistribution distribution) throws Exception;

	void saveOrUpdate(DcDistribution distribution) throws Exception;

	DcDistributionDAO getDcDistributionDAO();

	void setDcDistributionDAO(DcDistributionDAO dcDistributionDAO);

}
