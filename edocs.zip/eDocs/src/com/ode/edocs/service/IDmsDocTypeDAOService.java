package com.ode.edocs.service;

import com.ode.edocs.db.dao.DmsDocTypeDAO;
import com.ode.edocs.db.entity.DmsDocType;

public interface IDmsDocTypeDAOService {

	DmsDocTypeDAO getDmsDocTypeDAO();

	void setDmsDocTypeDAO(DmsDocTypeDAO dmsDocTypeDAO);

	DmsDocType findByName(String formattedFileName, String dmsId) throws Exception;

	DmsDocType findDmsDocTypeByName(String formattedFileName, String dmsId) throws Exception;

}
