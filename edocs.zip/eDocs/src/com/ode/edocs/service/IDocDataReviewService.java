package com.ode.edocs.service;

import com.ode.edocs.rest.entity.DocDataReviewResponse;
import com.ode.edocs.rest.entity.DocumentReviewRequest;

public interface IDocDataReviewService {

    /**
     * @param request
     * @return
     */
    DocDataReviewResponse documentReview(DocumentReviewRequest request);

}
