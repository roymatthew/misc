package com.ode.edocs.service;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DcDocDataDAO;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import java.util.List;
import org.jdom2.Document;

public interface IDocDataService {

    /**
     * @param file
     * @param dcDocument
     * @param ecout
     * @param deDeal
     * @param lender
     * @param dmsId
     * @param cv
     * @param dataElements
     * @param dmsDocName
     * @param applicationType
     * @return
     * @throws Exception
     */
    Boolean savaDocData(final File file, final DcDocument dcDocument, final Document ecout, DeDeal deDeal,
        final DeLender lender, String dmsId, DeContractValidation cv, final List<DeDataElement> dataElements,
        final String dmsDocName, final String applicationType) throws Exception;

    /**
     * @param file
     * @param dcDocument
     * @param ecout
     * @param deDeal
     * @param lender
     * @param dmsId
     * @param cv
     * @param dataElements
     * @param dmsDocName
     * @param applicationType
     * @return
     * @throws Exception
     */
    Boolean savaDocDataForAutonomousLender(final File file, final DcDocument dcDocument, final Document ecout,
        DeDeal deDeal, final DeLender lender, String dmsId, DeContractValidation cv,
        final List<DeDataElement> dataElements, final String dmsDocName, final String applicationType) throws Exception;

	DcDocDataDAO getDcDocDataDAO();

	void setDcDocDataDAO(DcDocDataDAO dcDocDataDAO);

	DcDocData save(DcDocData docData) throws Exception;

	void saveOrUpdate(DcDocData docData) throws Exception;

	List<DcDocData> findDataByDcDocumentId(Integer id) throws Exception;

    
}
