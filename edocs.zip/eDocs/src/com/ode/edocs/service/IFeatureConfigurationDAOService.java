package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.FeatureConfigurationDAO;
import com.ode.edocs.db.entity.FeatureConfiguration;

public interface IFeatureConfigurationDAOService {

	FeatureConfigurationDAO getFeatureConfigurationDao();

	void setFeatureConfigurationDao(FeatureConfigurationDAO featureConfigurationDao);

	List<FeatureConfiguration> getConfiguration(String lenderId);

	List<FeatureConfiguration> getConfigurationWithName(String lenderId, String featureName) throws Exception;

}
