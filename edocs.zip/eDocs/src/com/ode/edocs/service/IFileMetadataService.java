package com.ode.edocs.service;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.FormElementKey;
import java.util.HashMap;
import java.util.List;

public interface IFileMetadataService {

    List<File> addMetaDataFieldsToDistributionFilesForAutonomousLender(final List<File> files, final DeLender lender,
        final DeDeal deal, final String financeType, final String applicationType) throws Exception;

    List<File> addFieldsToDistributionFilesForLender(final List<File> files) throws Exception;

    HashMap<FormElementKey, List<DeDataElement>> getSessionMetaDataMap();

}
