package com.ode.edocs.service;

import java.util.List;

import com.ode.edocs.db.dao.LenDocTypeDAO;
import com.ode.edocs.db.entity.LenDocType;

public interface ILenDocTypeDAOService {

	LenDocTypeDAO getLenDocTypeDAO();

	void setLenDocTypeDAO(LenDocTypeDAO lenDocTypeDAO);

	List<LenDocType> findByDcDocTypeId(Integer id, String lenderId) throws Exception;

}
