package com.ode.edocs.service;

import com.ode.edocs.ReCVData;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public interface ISpotCheckService {

    /**
     * @param distributionProcessingVO
     * @param distributions
     * @param cjEcout
     * @param lender
     * @param deDeal
     * @param timeStamp
     * @param errorDetail
     * @return
     * @throws Exception
     * @throws ApplicationException
     */
    ReCVData handleSpotCheck(final DistributionProcessingVO distributionProcessingVO,
        List<DcDistribution> distributions, final CreditJournal cjEcout, final DeLender lender, final DeDeal deDeal,
        final Date timeStamp, final ErrorDetail errorDetail) throws Exception, ApplicationException;

    /**
     * @param eDocIn
     * @param cjEcout
     * @param lenderId
     * @param lender
     * @param deDeal
     * @param timeStamp
     * @param errorDetail
     * @return
     * @throws Exception
     * @throws ApplicationException
     */
    ReCVData runAutoReCV(final Document eDocIn, final CreditJournal cjEcout, final String lenderId,
        final DeLender lender, final DeDeal deDeal, final Date timeStamp, final ErrorDetail errorDetail)
        throws Exception, ApplicationException;

    /**
     * @param deDeal
     * @param formComment
     * @param formName
     * @throws Exception
     */
    void updateFormComment(final DeDeal deDeal, final String formComment, final String formName) throws Exception;

    /**
     * @param accr
     * @param deDeal
     * @param validationResult
     * @return
     * @throws Exception
     * @throws ApplicationException
     */
    String parseValidationMessage(final Document accr, final DeDeal deDeal, final String validationResult)
        throws Exception, ApplicationException;

}
