package com.ode.edocs.service;

import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import com.ode.vault.db.entity.VaultRegisterDocument;

public interface IVaultRegisterDocumentDAOService {

	VaultRegisterDocumentDAO getVaultRegisterDocumentDAO();

	void setVaultRegisterDocumentDAO(VaultRegisterDocumentDAO vaultRegisterDocumentDAO);

	VaultRegisterDocument findVaultDocId(String dealerId, String dealId) throws Exception;

}
