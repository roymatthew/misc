package com.ode.edocs.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.db.dao.LenDocTypeDAO;
import com.ode.edocs.db.entity.LenDocType;

@Service
public class LenDocTypeDAOServiceImpl implements ILenDocTypeDAOService {

	private static final Logger logger = LogManager.getLogger(LenDocTypeDAOServiceImpl.class);

	@Autowired
	private LenDocTypeDAO lenDocTypeDAO;

	@Override
	public LenDocTypeDAO getLenDocTypeDAO() {
		return lenDocTypeDAO;
	}

	@Override
	public void setLenDocTypeDAO(LenDocTypeDAO lenDocTypeDAO) {

	}

	@Override
	public List<LenDocType> findByDcDocTypeId(Integer id, String lenderId) throws Exception {
		return lenDocTypeDAO.findByDcDocTypeId(id, lenderId);
	}

}
