package com.ode.edocs.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.ElementFilter;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.edocs.ReCVData;
import com.ode.edocs.client.LenderTransmitClient;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.ApplicationException;
import com.ode.edocs.util.EdocsXmlUtils;
import com.ode.edocs.util.EncryptionUtils;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.XMLConstants;
import com.ode.edocs.vo.DistributionProcessingVO;

@Service
public class SpotCheckServiceImpl implements ISpotCheckService {

	private static final Logger logger = LogManager.getLogger(SpotCheckServiceImpl.class);

	@Autowired
	private IDcFormDAOService dcFormService;

	@Autowired
	private IDeLenderDestinationDAOService deLenderDestinationService;

	@Autowired
	private ICreditJournalService creditJournalService;

	@Autowired
	LenderTransmitClient lenderTransmitClient;

	@Autowired
	private IValidationUtil validationUtil;

	private static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");

	@Override
	public ReCVData handleSpotCheck(final DistributionProcessingVO distributionProcessingVO,
			List<DcDistribution> distributions, final CreditJournal cjEcout, final DeLender lender, final DeDeal deDeal,
			final Date timeStamp, final ErrorDetail errorDetail) throws Exception, ApplicationException {

		logger.debug("Entered handleSpotCheck()");

		ReCVData reCVData = null;
		// If its a SPOT deal and SPOT flag is enabled for this lender, then do
		// a CV now with correct application number
		if (StringUtils.equals(deDeal.getSpotFlag(), AppConstants.SPOT_FLAG_YES)
				&& StringUtils.equals(lender.getAuto_cv_flag(), AppConstants.AUTO_RE_CV_FLAG_YES)
				&& !validationUtil.previousDistributionExists(distributions)) {

			validationUtil.isApplicationNumberBlank(deDeal, distributionProcessingVO.getApplicationNumber());

			deDeal.setCaApplicationNum(distributionProcessingVO.getApplicationNumber());
			reCVData = runAutoReCV(distributionProcessingVO.geteDocIn(), cjEcout, lender.getLender_id(), lender, deDeal,
					timeStamp, errorDetail);

			validationUtil.isAutoReCvValid(deDeal, reCVData, errorDetail, distributionProcessingVO.getDmsId());

		} else if (validationUtil.previousDistributionExists(distributions)
				&& StringUtils.equals(lender.getAuto_cv_flag(), AppConstants.AUTO_RE_CV_FLAG_YES)) {

			CreditJournal autoCvOut = creditJournalService.findMostRecentByDeDealId(
					distributionProcessingVO.getDeDealId(), distributionProcessingVO.getDealerId(),
					distributionProcessingVO.getPartyId(), new String[] { "AUTOCVOUT" });

			if (autoCvOut != null) {
				reCVData = new ReCVData();
				reCVData.setAutoCvOut(
						EncryptionUtils.decryptText(autoCvOut.getCrDataXml(), autoCvOut.getEncryptionKeyId()));
				reCVData.setTransactionId(cjEcout != null ? cjEcout.getTransactionId() : "");

				CreditJournal autoCvAckIn = creditJournalService.findMostRecentByDeDealId(
						distributionProcessingVO.getDeDealId(), distributionProcessingVO.getDealerId(),
						distributionProcessingVO.getPartyId(), new String[] { "AUTOCVACKIN" });
				if (autoCvAckIn != null) {
					Document autoCvAckInDoc = creditJournalService.getDocumentFromCreditJournal(autoCvAckIn);
					String autoCvOutValidationResult = EdocsXmlUtils.getTextFromXpath(autoCvAckInDoc,
							XMLConstants.starValidationResultsPath);
					reCVData.setAutoCvValidationStatus(autoCvOutValidationResult);
				} else {
					reCVData.setAutoCvValidationStatus("No record found.");
				}
			}
		}

		logger.debug("Exit handleSpotCheck()");

		return reCVData;
	}

	@Override
	public ReCVData runAutoReCV(final Document eDocIn, final CreditJournal cjEcout, final String lenderId,
			final DeLender lender, final DeDeal deDeal, final Date timeStamp, final ErrorDetail errorDetail)
			throws Exception, ApplicationException {

		logger.debug("Entered runAutoReCV()");

		ReCVData reCVData = new ReCVData();
		// get latest ECOUT
		String validationResult = "";
		reCVData.setTransactionId(cjEcout != null ? cjEcout.getTransactionId() : "");
		final Document ecout = creditJournalService.getDocumentFromCreditJournal(cjEcout);

		// add Application number
		final XPathExpression<Element> headerXpath = XPathFactory.instance().compile(XMLConstants.starHeaderPath,
				Filters.element(), null, star);
		final List<Element> elements = headerXpath.evaluate(ecout);
		if (null != elements) {
			for (Element element : elements) {
				Element applicationNumber = new Element("ApplicationNumber", element.getNamespace());
				applicationNumber.setText(deDeal.getCaApplicationNum());
				element.addContent(6, applicationNumber);
			}
		} else {
			logger.debug("Header element not found");
		}

		// remove SpecialPrograms code that starts with XX
		final XPathExpression<Element> spXpath = XPathFactory.instance().compile(XMLConstants.starsplPrgmPath,
				Filters.element(), null, star);
		final List<Element> spElements = spXpath.evaluate(ecout);
		if (null != spElements) {
			for (Element element : spElements) {
				element.getParent().removeContent(element);
			}
		} else {
			logger.debug("Special Program element not found");
		}

		String outgoingXmlString = EdocsXmlUtils.convertDocumentToString(ecout);

		outgoingXmlString = outgoingXmlString.replaceAll("<SpecialProgramDetail />", "");
		//logger.info(outgoingXmlString);
		DeLenderDestination lenderDest = null;
		// Post to lender
		try {
			lenderDest = deLenderDestinationService.findByLenderId(lenderId, AppConstants.APPLICATION_LP);
		} catch (Exception e) {
			ApplicationException ae = new ApplicationException(
					"Error getting lender destination record for lender " + lenderId + ":",
					AppConstants.LENDER_DESTINATION_FAILURE_CODE + "-" + AppConstants.APPLICATION_LP, e);
			ae.setErrorDetail(errorDetail);
			throw ae;
		}

		reCVData.setAutoCvOut(outgoingXmlString);

		// Write AUTOCVOUT transaction to CreditJournal
		final BigInteger autoCvOutCjKey = creditJournalService.writeAUTOCVOUT(eDocIn, timeStamp, deDeal.getDealId(),
				outgoingXmlString, cjEcout, deDeal.getDmsDealerId(), deDeal.getLenderId());
		logger.debug("AUTOCVOUT CJ KEY:{}", autoCvOutCjKey);

		final String lenderResponse = lenderTransmitClient.sendToLender(outgoingXmlString, lenderId, lender, lenderDest,
				false, null, null, errorDetail, null, false);

		// parse validation result
		final Document accr = EdocsXmlUtils.getDocumentFromString(lenderResponse);
		final BigInteger autoCvAckInCjKey = creditJournalService.writeEDOCACKIN("AUTOCVACKIN", eDocIn, lenderResponse,
				timeStamp, deDeal.getDealId(), "", cjEcout.getTransactionId(), cjEcout.getAccountId());
		logger.debug("AUTOCVACKIN CJ KEY:{}", autoCvAckInCjKey);

		validationResult = EdocsXmlUtils.getTextFromXpath(accr, XMLConstants.starValidationResultsPath);
		logger.debug("Validation Result from Auto Re CV: " + validationResult);

		if (null != validationResult && AppConstants.AUTO_RE_CV_VALIDATION_VALID.equals(validationResult)) {
			reCVData.setAutoCvValidationStatus(validationResult);
			// clear DcForm 'Contract' form comments that was populated with
			// error messages during auto reCV process
			updateFormComment(deDeal, "", AppConstants.FORM_NAME_CONTRACT);
		} else {
			// parse for validation message and update message in DCForm table
			String errorMessage = parseValidationMessage(accr, deDeal, validationResult);
			reCVData.setAutoCvValidationStatus(errorMessage);
		}

		logger.debug("Exit runAutoReCV()");

		return reCVData;
	}

	@Override
	public void updateFormComment(DeDeal deDeal, String formComment, String formName) throws Exception {

		logger.debug("Entered updateFormComment()");

		List<DcForm> dcForms = dcFormService.findForms(deDeal.getDealId(), formName);
		if (null != dcForms) {
			for (DcForm dcForm : dcForms) {
				dcForm.setFormComment(formComment);
				dcFormService.saveOrUpdate(dcForm);
			}
		}

		logger.debug("Exit updateFormComment()");
	}

	@Override
	public String parseValidationMessage(final Document accr, final DeDeal deDeal, final String validationResult)
			throws Exception, ApplicationException {

		logger.debug("Exit parseValidationMessage()");

		// find validation messages where error criticality = 'E' or criticality
		// = 'F' with Validation status as unresolved
		List<String> errorMessages = new ArrayList<String>();
		String errorMessage = "";

		Element root = accr.getRootElement();
		Element header = null;
		ElementFilter filter = new ElementFilter("Header");
		for (Element element : root.getDescendants(filter)) {
			header = element;
		}

		if (null != header) {
			List<Element> elements = header.getChildren("ValidationMessage", star);
			for (Element element : elements) {
				if (element.getChild("ErrorCriticality", star).getText().equals("E")
						|| element.getChild("ErrorCriticality", star).getText().equals("F")
								&& AppConstants.AUTO_RE_CV_VALIDATION_UNRESOLVED.equalsIgnoreCase(validationResult)) {
					errorMessages.add(element.getChild("Description", star).getText());
				}
			}
		} else {
			logger.debug("Header element not found");
		}

		// update DcForm for contract if there's error messages
		// if (null != errorMessages && errorMessages.size() > 0) {
		if (errorMessages.size() > 0) {
			errorMessage = errorMessages.toString();
			updateFormComment(deDeal, errorMessage, AppConstants.FORM_NAME_CONTRACT);
		}

		logger.debug("Exit parseValidationMessage()");

		return errorMessage;
	}
}
