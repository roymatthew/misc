package com.ode.edocs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.vault.db.dao.VaultRegisterDocumentDAO;
import com.ode.vault.db.entity.VaultRegisterDocument;

@Service
public class VaultRegisterDocumentDAOServiceImpl implements IVaultRegisterDocumentDAOService {

	private static final Logger logger = LogManager.getLogger(VaultRegisterDocumentDAOServiceImpl.class);

	@Autowired
	private VaultRegisterDocumentDAO vaultRegisterDocumentDAO;

	@Override
	public VaultRegisterDocumentDAO getVaultRegisterDocumentDAO() {
		return vaultRegisterDocumentDAO;
	}

	@Override
	public void setVaultRegisterDocumentDAO(VaultRegisterDocumentDAO vaultRegisterDocumentDAO) {

	}

	@Override
	public VaultRegisterDocument findVaultDocId(final String dealerId, final String dealId) throws Exception {
		return vaultRegisterDocumentDAO.findVaultDocId(dealerId, dealId);
	}

}
