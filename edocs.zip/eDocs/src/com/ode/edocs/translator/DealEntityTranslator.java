package com.ode.edocs.translator;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.vo.DealVO;
import org.springframework.beans.BeanUtils;

/**
 * Class to translate a Deal entity to its value object and vice versa.
 */
public class DealEntityTranslator {

    /**
     * This method takes a Deal entity and translates it to a Deal value object.
     *
     * @param dealEntity DeDeal
     * @return dealVO DealVO
     */
    public DealVO translateDealEntityToDealVO(final DeDeal dealEntity) {
        final DealVO dealVO = new DealVO();
        BeanUtils.copyProperties(dealEntity, dealVO);
        return dealVO;
    }

    /**
     * This method takes a Deal value object and translates it to a Deal entity.
     *
     * @param dealEntity DeDeal
     * @return dealVO DealVO
     */
    public DeDeal translateDealVOToDealEntity(final DealVO dealVO) {
        final DeDeal deal = new DeDeal();
        BeanUtils.copyProperties(dealVO, deal);
        return deal;
    }

    /**
     * This method takes a Deal value object and Deal Entity and update selected attributes of the entity.
     *
     * @param dealEntity DeDeal
     * @return dealVO DealVO
     */
    public DeDeal updateDealEntity(final DeDeal deal, final DealVO dealVO) {
        deal.setApplicationType(dealVO.getApplicationType());
        deal.setEconStatus(dealVO.getEconStatus());
        return deal;
    }

}
