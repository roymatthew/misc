package com.ode.edocs.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.service.ICreditJournalService;
import com.ode.edocs.vo.BeginCompleteProcessingVO;
import com.ode.pen.ws.client.AftermarketDataContainer;

@Component
public class AftermarketProductsUtil implements IAftermarketProductsUtil {
	
	private static final Logger logger = LogManager.getLogger(AftermarketProductsUtil.class);

	@Autowired
    public ICreditJournalService creditJournalService;
	
	@Autowired
    public IPENUtil penUtil;
	
	@Override
	public void sendMessageToPEN(final BeginCompleteProcessingVO beginCompleteProcessingVO, DeDeal deDeal) {
		logger.debug("Enter sendMessageToPEN");
		
		try {
			//Put future logic for PEN in here
			AftermarketDataContainer aftermarketData = penUtil.sendRequestToPen(beginCompleteProcessingVO, deDeal);
			logger.debug("AftermarketDataContainer from PEN:" + aftermarketData);
		} catch(Exception e) {
			logger.error("An error occurred processing aftermarket products.", e);
		}
	}
}