package com.ode.edocs.util;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class AppConstants {

    // -- Vault Transaction Types
    public static final String TRANS_TYPE_VAULT_ACCEPT_REQUEST = "ECARQ";
    public static final String TRANS_TYPE_VAULT_ACCEPT_RESPONSE = "ECARS";
    public static final String TRANS_TYPE_VAULT_REJECT_REQUEST = "ECRRQ";
    public static final String TRANS_TYPE_VAULT_REJECT_RESPONSE = "ECRRS";
    public static final String TRANS_TYPE_VAULT_SEARCH_REQUEST = "ECSRQ";
    public static final String TRANS_TYPE_VAULT_SEARCH_RESPONSE = "ECSRS";

    // -- Vault response codes
    public static final String VAULT_ACCEPT_SUCCESSFUL = "I0700";
    public static final String VAULT_REJECT_SUCCESSFUL = "I0800";
    public static final String VAULT_SEARCH_SUCCESSFUL = "I0400";
    public static final String VAULT_LOGIN_SUCCESSFUL = "I0100";
    public static final String VAULT_LOGOUT_SUCCESSFUL = "I0200";
    public static final String VAULT_ASSIGN_SUCCESSFUL = "I0500";
    public static final String VAULT_ASSIGN_SUCCESS_MESSAGE = "assign document successful";
    public static final String VAULT_SEARCH_SUCCESS_MESSAGE = "search successful";

    // -- Trans Types
    public static final String TRANS_TYPE_EDOCIN = "EDOCIN";
    public static final String TRANS_TYPE_ECIN = "ECIN";
    public static final String TRANS_TYPE_ECOUT = "ECOUT";
    public static final String TRANS_TYPE_ECOUT2 = "ECOUT2";
    public static final String TRANS_TYPE_ECACKIN = "ECACKIN";
    public static final String[] TRANS_TYPES_ECOUT = new String[] { "ECOUT", "AUTOCVOUT" };

    public static final String ECON_STATUS_ASSIGNED = "Assigned";

    public static final String VAULT_ASSIGN_FAILURE = "E9010";
    public static final String VAULT_ASSIGN_FAILURE_MESSAGE = "Error while assigning the document to Lender Vault";

    public static final String VAULT_SEARCH_FAILURE_CODE = "E9011";
    public static final String VAULT_SEARCH_FAILURE_MESSAGE = "An unexpected error occurred while searching for the assigned contract.";

    public static final String VAULT_ASSIGN_RESPONSE_SUCCESS = "Success";
    public static final String VAULT_ASSIGN_RESPONSE_UNEXPECTED_ERROR = "Unxepected error";
    public static final String VAULT_ASSIGN_RESPONSE_DOC_NOT_FOUND = "Document not found";
    public static final String VAULT_ASSIGN_RESPONSE_ERROR_WITH_DOC = "Error with document";

    public static final String VAULT_SEARCH_DOCUMENT_ACTIVE_FOUND = "Active Document Found";
    public static final String VAULT_SEARCH_DOCUMENT_INACTIVE_FOUND = "Inactive Document Found";
    public static final String VAULT_SEARCH_DOCUMENT_NOT_EXIST = "Document Doesnt Exist";
    public static final String VAULT_SEARCH_DOCUMENT_ERROR = "Document Search Error";

    public static final String LENDER_FEATURE_PEN_INTEGRATION = "PIF";

    public static final String DISTRIBUTION_SEQUENCE_PREFIX = "DS";
    public static final String DISTRIBUTION_SCHEMA_VERSION_1 = "1";
    public static final String DISTRIBUTION_SCHEMA_VERSION_2 = "2";
    public static final String DISTRIBUTION_SCHEMA_VERSION_3 = "3";
    public static final String DISTRIBUTION_JSON = "4";
    public static final String DISTRIBUTION_SCHEMA_VERSION_R1 = "R1";
    public static final String DOC_TYPE_CONTRACT = "C";
    public static final String DOC_TYPE_LEASE_WORKSHEET = "L";
    public static final String DOC_TYPE_ANCILLARY = "A";
    public static final String DOC_NAME_LEASE_WORKSHEET = "Lease Worksheet";
    public static final String DOC_NAME_OTHER = "Other";
    public static final String SECTION_META_DATA = "M";
    public static final String SECTION_REVIEW_DATA = "R";
    public static final String SECTION_FORM_QUESTION_DATA = "F";
    public static final String SECTION_VERIFICATION_DATA = "V";
    public static final String DSP_REYNOLDS = "RR";
    public static final String DSP_ADVENT = "AR";
    public static final String DSP_ADP = "AD";
    public static final String DMS_SEARCH_CRITERIA_ALL = "ALL";
    public static final String CONTRACT_RETAIL_VCI = "00001-Contract - Retail";
    public static final String CONTRACT_LEASE_VCI = "00001-Contract - Lease";
    public static final String CONTRACT_BALLOON_VCI = "00001-Contract - Balloon";
    public static final String CONTRACT_NAME = "00001-Contract";
    public static final String LENDER_MB = "MB";
    public static final String CONTRACT_NAME_RR = "-Contract";
    public static final String SCANNED = "scanned";
    public static final String CONTRACT = "-contract.pdf";

    public static final String ANCILLARY_DATA_FLAG_YES = "Y";
    public static final String ANCILLARY_DATA_FLAG_NO = "N";
    public static final String DOCUMENT_REVIEW_FLAG_YES = "Y";
    public static final String DOCUMENT_REVIEW_FLAG_NO = "N";
    public static final String EYES_ON_DOC_FLAG_YES = "Y";
    public static final String EYES_ON_DOC_FLAG_NO = "N";
    public static final String LENDER_INTEGRATION_FLAG_YES = "Y";
    public static final String LENDER_INTEGRATION_FLAG_NO = "N";
    public static final String FAX_SOLUTION_FLAG_YES = "Y";
    public static final String FAX_SOLUTION_FLAG_NO = "N";
    public static final String FAX_CONFIRMATION_FLAG_YES = "Y";
    public static final String FAX_CONFIRMATION_FLAG_NO = "N";
    public static final String SPOT_FLAG_YES = "Y";
    public static final String SPOT_FLAG_NO = "N";
    public static final String AUTO_RE_CV_FLAG_YES = "Y";
    public static final String AUTO_RE_CV_FLAG_NO = "N";
    public static final String REQUIRED_FORM_FLAG_YES = "Y";
    public static final String REQUIRED_FORM_FLAG_NO = "N";
    public static final String FILE_SIZE_CHECK_FLAG_YES = "Y";
    public static final String FILE_SIZE_CHECK_FLAG_NO = "N";
    public static final String AUTONOMOUS_FLAG_YES = "Y";
    public static final String AUTONOMOUS_FLAG_NO = "N";
    public static final String DOCUMENT_MAPPING_FLAG_YES = "Y";
    public static final String DOCUMENT_MAPPING_FLAG_NO = "N";

    public static final String DISTRIBUTION_STATUS_FAILED = "Failed";
    public static final String DISTRIBUTION_STATUS_PENDING = "Pending";
    public static final String DISTRIBUTION_STATUS_RECEIVED = "Received";
    public static final String DISTRIBUTION_STATUS_DISTRIBUTED = "Distributed";
    public static final String DISTRIBUTION_STATUS_FAX_PENDING = "Fax Pending";
    public static final String DISTRIBUTION_STATUS_LENDER_FAILURE = "Lender Failure";
    public static final String DOCUMENT_STATUS_DISTRIBUTED = "Distributed";
    public static final String DOCUMENT_STATUS_PENDING = "Pending";
    public static final String ECONTRACT_STATUS_ASSIGNED = "Assigned";
    public static final String DISTRIBUTION_STATUS_SUBMITTED = "Submitted";
    public static final String ECONTRACT_STATUS_ASSIGNMENT_FAILED = "Assignment Failed";
    public static final String FUNDING_STATUS_DISTRIBUTED = "Distributed";
    public static final String FUNDING_STATUS_PENDING = "Pending";
    public static final String FUNDING_STATUS_RECEIVED = "Received";
    public static final String FUNDING_STATUS_BOOKED = "Booked";
    public static final String FUNDING_STATUS_HELD = "Held";
    public static final String FUNDING_STATUS_RETURNED_TO_DEALER = "Returned To Dealer";
    public static final String FUNDING_STATUS_REJECTED = "Rejected";
    public static final String FUNDING_STATUS_ASSIGNMENT_FAILED = "Assignment Failed";
    public static final String DOC_STATUS_REVIEWED = "Reviewed";
    public static final String DIST_STATUS_REVIEWED = "Reviewed";
    public static final String DISTRIBUTION_FAILED = "Distribution Failed";
    public static final String WITHDRAW_FAILED = "Withdraw Failed";

    public static final String[] CV_STATUSES_PASSED = new String[] { "Passed", "Valid" };
    public static final String CV_STATUS_PASSED_FOR_CHASE = "Passed";

    public static final String[] HTTP_SUCCESS_CODES = new String[] { "200", "202" };

    public static final String ATTACHMENT_ESIGNED_TRUE = "true";
    public static final String ATTACHMENT_ESIGNED_FALSE = "false";
    public static final String DEAFULT_FILE_NAME = "Other";
    public static final String DOC_NAME_DEALER_PRODUCT = "Dealer Product";
    public static final String EDOCS_DMS_USER = "edocs-dms";

    public static final DecimalFormat FORM_ID_FORMAT = new DecimalFormat("#00000");

    public static final String DISTRIBUTE_SUCCESS_CODE = "I0000";
    public static final String DISTRIBUTE_SUCCESS_MESSAGE = "Successfully Distributed";

    public static final String DE_LENDER_NOT_FOUND_CODE = "E9000";
    public static final String DE_LENDER_NOT_FOUND_MESSAGE = "Unable to process distribution.";
    public static final String DE_DEAL_NOT_FOUND_CODE = "E9001";
    public static final String DE_DEAL_NOT_FOUND_MESSAGE = "No deal exists for distribution processing.";
    public static final String DE_DEAL_WRONG_FUNDING_STATUS_CODE = "E9020";
    public static final String DE_DEAL_WRONG_FUNDING_STATUS_MESSAGE = "Your distribution has already been processed. Please contact your lender for additional assistance.";
    public static final String DE_DEAL_NOT_ASSIGNED_CODE = "E9021";
    public static final String DE_DEAL_NOT_ASSIGNED_MESSAGE = "There is no eContract currently Assigned for this deal.  Please Assign the eContract and resend eDocs.";
    public static final String DE_DEAL_ASSIGNED_TO_WRONG_LENDER_CODE = "E9022";
    public static final String DE_DEAL_ASSIGNED_TO_WRONG_LENDER_MESSAGE = "The eContract for this deal is Assigned to another lender.";
    public static final String DISTRIBUTION_PENDING_STATUS_ERROR_CODE = "E9111";
    public static final String DISTRIBUTION_IS_IN_PENDING_STATUS = "You are unable to distribute an eDocs Packet while in Pending status.";
    public static final String UNEXPECTED_ERROR_CODE = "E9050";
    public static final String UNEXPECTED_ERROR_MESSAGE = "An unexpected error has occured.";
    public static final String LENDER_DESTINATION_NOT_FOUND_CODE = "E9080";
    public static final String LENDER_DESTINATION_NOT_FOUND_MESSAGE = "Destination URL not found for lender";
    public static final String LEASE_WORKSHEET_NOT_VALID_CODE = "E9081";
    public static final String LEASE_WORKSHEET_NOT_VALID_MESSAGE = "Please pick the correct LEASE WORKSHEET that is presented in the Deal Jacket";
    public static final String DISTRIBUTE_FAILURE_CODE = "E9090";
    public static final String DISTRIBUTE_LENDER_FAILURE = "The lender loan origination system is currently unavailable";
    public static final String DISTRIBUTE_FAILURE_MESSAGE = "Unable to Distribute the documents";
    public static final String DECRYPT_ECOUT_FAILED_MESSAGE = "Unable to decrypt ECOUT.";
    public static final String DECRYPT_ECOUT_FAILED_CODE = "E9091";
    public static final String ZIPFILE_WRITE_ERROR = "E9092";
    public static final String ZIPFILE_READ_ERROR_MESSAGE = "Error reading zip file";
    public static final String ZIPFILE_READ_ERROR_CODE = "E9093";
    public static final String EDOCIN_PARSE_ERROR = "E9094";
    public static final String EDOCIN_PARSE_ERR_MSG = "Document parsing error";
    public static final String DEALNUM_SEQUENCENO_NOT_FOUND = "E9095";
    public static final String NO_SCHEMA_MATCH_FOR_LENDER_SCHEMA_VERSION_MESSAGE = "Unable to send distribution, no setup exists for lender";
    public static final String NO_SCHEMA_MATCH_FOR_LENDER_SCHEMA_VERSION_CODE = "E9096";
    public static final String LENDER_DESTINATION_FAILURE_CODE = "E9097";
    public static final String FAX_TO_LENDER_ERROR_CODE = "E9104";
    public static final String DECRYPT_EDOCIN_FAILED_MESSAGE = "Unable to decrypt EDOCIN.";
    public static final String DECRYPT_EDOCIN_FAILED_CODE = "E9098";
    public static final String APPLICATION_EDOCS = "EDOCS";
    public static final String APPLICATION_LP = "LP";
    public static final String PRODUCT_EYES_ON_DOC = "EOD";
    public static final String AUTO_RE_CV_VALIDATION_VALID = "Valid";
    public static final String AUTO_RE_CV_VALIDATION_UNRESOLVED = "Unresolved";
    public static final String AUTO_RE_CV_VALIDATION_ERROR_MESSAGE = "Transmission failed due to Contract Validation Error. All validation errors can be viewed in the required forms section of your deal jacket.";
    public static final String AUTO_RE_CV_VALIDATION_ERROR_CODE = "E9099";
    public static final String NO_CONTRACT_IN_HELD_STATUS_ERROR_MESSAGE = "Contract cannot be transmitted when the deal is in 'HELD' status";
    public static final String NO_CONTRACT_IN_HELD_STATUS_ERROR_CODE = "E9100";
    public static final String AUTO_RE_CV_NO_APPLICATION_NUM_ERROR_MESSAGE = "Transmission Failed. No application number found in distribution request.";
    public static final String AUTO_RE_CV_NO_APPLICATION_NUM_ERROR_CODE = "E9002";
    public static final String RR_CHASE_DSP_FORM_ERROR_MESSAGE = "Contract form sent does not match a lender approved contract form";
    public static final String RR_CHASE_DSP_FORM_ERROR_CODE = "E9207";
    public static final String FORM_NAME_CONTRACT = "Contract";
    public static final String EDOCS_COMPARISON = "eDocs-comparison";
    public static final String FIELD_TYPE_DATE = "Date";
    public static final String FILE_SIZE_EXCEEDED_ERROR = "E9103";
    public static final String FILE_SIZE_EXCEEDED_ERROR_MESSAGE = "The system has detected that an attachment is larger than 10MB. Try checking and correcting the scanner settings, re-scan the document and resubmit the package with the new document.";
    public static final String FILE_SIZE_EXCEEDED_ERROR_MESSAGE1 = "invalidFile";
    public static final String FILE_SIZE_EXCEEDED_ERROR_MESSAGE2 = " file exceeds the required limit of ";
    public static final String FILE_SIZE_EXCEEDED_ERROR_MESSAGE3 = " MB. Please rescan and resend the document within limits.";
    public static final String FILE_RESOLUTION_INVALID_ERROR = "E9101";
    public static final String FILE_RESOLUTION_INVALID_ERROR_MESSAGE1 = " does not meet the minimum resolution of ";
    public static final String FILE_RESOLUTION_INVALID_ERROR_MESSAGE2 = "dpi. Please rescan the document and resend the Digital Deal Jacket.";
    public static final String DISTRIBUTION_WITHOUT_VAULTDOCID_ERROR_CODE = "E9102";
    public static final String DISTRIBUTION_WITHOUT_VAULTDOCID_ERROR_MESSAGE = "The Distribution Failed. Please check the document linked to the Contract item in the Deal Jacket. Please contact CDK support if the problem persists.";
    public static final String NO_ASSIGNED_CONTRACT_IN_DISTRIBUTION_CODE = "E9105";
    public static final String NO_ASSIGNED_CONTRACT_IN_DISTRIBUTION_ERROR_MESSAGE = "Distribution must contain the Assigned eContract. Please select the correct eContract Form for distribution.";
    public static final String VAULTSTATUS_NULL_OR_BLANK_CODE = "E9106";
    public static final String VAULTSTATUS_NULL_OR_BLANK_ERROR_MESSAGE = "No Vaulted eContract exists. Please Register and Assign the eContract prior to distribution.";
    public static final String VAULTSTATUS_NOT_ASSIGNED_CODE = "E9107";
    public static final String VAULTSTATUS_NOT_ASSIGNED_ERROR_MESSAGE = "eContract must be Assigned prior to distribution. Please Assign the eContract and resend the distribution.";
    public static final String NO_VAULTED_DOCUMENT_MB_CODE = "E9108";
    public static final String NO_VAULTED_DOCUMENT_MB_ERROR_MESSAGE = "Unable to distribute this deal.  Please select eSigned Contract and retransmit.  Please contact CDK support if error persists (vaulted contract not present).";
    public static final String CV_STATUS_NOT_PASSED_CODE = "E9109";
    public static final String CV_STATUS_NOT_PASSED_ERROR_MESSAGE = "There is not a Passed validation for this deal. Please run contract validation before you try to distribute the package to the lender.�";
    public static final String VAULT_DOC_ID_NOT_VAULTED_CODE = "E9110";
    public static final String VAULT_DOC_ID_NOT_VAULTED_MESSAGE = "There is not a vaulted contract contained in the distribution. Please contact CDK support for assistance.";

    public static final String CONTRACT_NAME_NOT_ASSIGNED_CODE = "E9200";
    public static final String CONTRACT_NAME_NOT_ASSIGNED_MESSAGE = "Your contract must contain the non-authoritative copy of the contract. Please assign the name as Contract and try again.";
    public static final String ECONTRACT_RR_NOT_ASSIGNED_CODE = "E9204";
    public static final String ECONTRACT_RR_NOT_ASSIGNED_MESSAGE = "The distribution must contain a vaulted eContract that has been Assigned to the lender. Assign the contract and try again. Please contact Reynolds support if you need additional assistance.";
    public static final String ECONTRACT_RR_NOT_ATTACHED_CODE = "E9205";
    public static final String ECONTRACT_RR_NOT_ATTACHED_MESSAGE = "The distribution must contain a vaulted eContract that has been Assigned to the lender. Attach the eContract and try again. Please contact Reynolds support if you need additional assistance.";
    public static final String ECONTRACT_MB_RR_AR_NOT_ATTACHED_CODE = "E9206";
    public static final String ECONTRACT_MB_RR_AR_NOT_ATTACHED_MESSAGE = "eDocs transmission failed: Verify properly assigned and labeled contract.";
    public static final String ECONTRACT_AR_NOT_ASSIGNED_CODE = "E9207";
    public static final String ECONTRACT_AR_NOT_ASSIGNED_MESSAGE = "The distribution must contain a vaulted eContract that has been Assigned to the lender. Assign the contract and try again. Please contact Advent support if you need additional assistance.";
    public static final String ECONTRACT_AR_NOT_ATTACHED_CODE = "E9208";
    public static final String ECONTRACT_AR_NOT_ATTACHED_MESSAGE = "The distribution must contain a vaulted eContract that has been Assigned to the lender. Attach the eContract and try again. Please contact Advent support if you need additional assistance.";
    
    public static final String PASSED_CV_DOESNT_EXIST_CODE = "E9301";
    public static final String PASSED_CV_DOESNT_EXIST_MESSAGE = "There is not a Passed validation for this deal. Please run contract validation before you try to distribute the package to the lender.";

    public static final String LATEST_DISTRIBUTION_STATUS_NOT_SUBMITTED_CODE = "E9302";
    public static final String LATEST_DISTRIBUTION_STATUS_NOT_SUBMITTED_MESSAGE = "A distribution is already in process. Your deal status will be updated shortly.";
    public static final String CV_CONTRACT_ID_NOT_FOUND = "E9303";
    public static final String CV_CONTRACT_ID_NOT_FOUND_MESSAGE = "No contract id found for the selected CV to send to RouteOne";
    public static final String DE_MAINTENANCE_NOTE_ACTION = "USER NOTE";
    public static final String DE_MAINTENANCE_DEAL_PAGE = "DEAL";

    // Database errors
    public static final String DC_OTHER_FORM_TYPE_SEARCH_NO_RESULTS_CODE = "E9400";

    public static final String ANCILLARY_DATA_TRIM_FLAG_YES = "Y";

    public static final String[] BUSINESS_APPLICATION_TYPE = new String[] { "BU", "BC", "BG" };
    public static final String[] INDIVIDUAL_APPLICATION_TYPE = new String[] { "IN", "IJ", "IC" };

    public static final String REPORT_APP_CALL_FAILURE = "*************Alert for Reports application call failure************";
    public static final String BLANK = "";
    public static final String ATTACHMENT_TEXT_REPLACED = "attachment text replaced";
    public static final String FILE_EXTENSION_PDF = "pdf";

    public static final String ANCILLARY_CONTRACT_XML_REVISION_DATE_FORMAT = "MM/yy";
    public static final String FORMS_DSP_REV_DATE_FORMAT = "yyyy-MM-dd";

    public static final String CHASE_LENDER_ID = "JPM";
    public static final String DEMO_LENDER_ID = "ECO";
    public static final String CUDC_LENDER_ID = "CUDC";
    public static final String SAF_LENDER_ID = "SAF";
    public static final String CHC_LENDER_ID = "CHC";
    public static final String TEST_LENDER_ID = "ODE";
    public static final String GMF_LENDER_ID = "GMF";
    public static final String VCI_LENDER_ID = "VCI";
    public static final String AFS_LENDER_ID = "AFS";

    public static final String PEN_PARTNER_ID = "PEN";

    public static final String BLANK_SPACE = " ";
    public static final String EMPTY_STRING = "";
    public static final String NA = "NA";
    public static final String YES = "Y";
    public static final String NO = "N";
    public static final String STRING_X = "X";
    public static final String eForm = "eForm";
    public static final String ASSIGNED_STATUS = "Assigned";
    public static final String DOCUMENT_STARTS_WITH_E = "E-";

    public static final String CONTRACT_RETAIL = "Contract - Retail";
    public static final String CONTRACT_LEASE = "Contract - Lease";
    public static final String CONTRACT_BALLOON = "Contract - Balloon";
    public static final String FILE_NAME_LEASE_AGGREEMENT = "Lease Agreement";

    public static final String CONTRACT_RETAIL_XML = "00001-Contract - Retail.xml";
    public static final String CONTRACT_LEASE_XML = "00001-Contract - Lease.xml";
    public static final String CONTRACT_BALLOON_XML = "00001-Contract - Balloon.xml";

    public static final String CONTRACT_RETAIL_PDF = "00001-Contract - Retail.pdf";
    public static final String CONTRACT_LEASE_PDF = "00001-Contract - Lease.pdf";
    public static final String CONTRACT_BALLOON_PDF = "00001-Contract - Balloon.pdf";

    public static enum CONTRACT_XML {
        CONTRACT_RETAIL_XML, CONTRACT_LEASE_XML, CONTRACT_BALLOON_XML
    }

    public static enum CONTRACT_PDF {
        CONTRACT_RETAIL_PDF, CONTRACT_LEASE_PDF, CONTRACT_BALLOON_PDF
    }

    // Keystores
    // TODO: make this sendMsgToDestinationWithTwoWaySSL reusable for lenders other than CHASE:
    // these values need to be externally configurable on a per lender basis.
    public static String TRUST_KEY_STORE_TYPE = "JKS";
    public static String TRUST_KEY_STORE_FILE = "/data/ode/keystores/trust_keystore.jks";
    public static String TRUST_KEY_STORE_PASS = "password";
    public static String CERT_ALIAS = "chase.stage.opendlrex.com";
    public static String IDENTITY_KEY_STORE_TYPE = "JKS";
    public static String IDENTITY_KEY_STORE_FILE = "/data/ode/keystores/identity_keystore.jks";
    public static String IDENTITY_KEY_STORE_PASS = "ode123";
    public static String FEATURE_NAME_TWO_WAY_SSL = "twoWaySSL";

    public static final String MOCK_LENDER_ID = "MOCK";

    public static final List<String> ancillaryMetaDataTypes;
    static {
        ancillaryMetaDataTypes = new ArrayList<String>();
        ancillaryMetaDataTypes.add("M");
        ancillaryMetaDataTypes.add("D");
    }

    public static final List<String> reviewQuestionsMetaDataTypes;
    static {
        reviewQuestionsMetaDataTypes = new ArrayList<String>();
        reviewQuestionsMetaDataTypes.add("R");
        reviewQuestionsMetaDataTypes.add("E");
        reviewQuestionsMetaDataTypes.add("F");
    }

    public static final String SequenceIDDS01 = "DS01";
    public static final SimpleDateFormat mmddyyyy = new SimpleDateFormat("MM-dd-yyyy");
    public static final String FinanceType_R = "R";
    public static final String FinanceType_L = "L";
    public static final String FinanceType_1 = "1";
    public static final String FinanceType_2 = "2";
    public static final String MessageType_T = "Trailing";
    public static final String MessageType_C = "Contract";
    public static final String VAULT_WITHDRAW_RESPONSE_SUCCESS = "Success";
    public static final String VAULT_WITHDRAW_SUCCESSFUL = "I0600";
    public static final String VAULT_WITHDRAW_RESPONSE_FAILED = "Failed";
    public static final String VAULT_WITHDRAW_RESPONSE_UNEXPECTED_ERROR = "Unxepected error";
    public static final String DISTRIBUTION_LENDER_FAILURE_STATUS_ERROR_CODE = "E9111";
    public static final String DISTRIBUTION_LENDER_FAILURE_STATUS_ERROR_MESSAGE = "Vault Assignment Failure during SendToLender";
    public static final String DISTRIBUTION_CONTRACT_ASSIGNMENT_FAILED = "Distribution failed due to Contract assignment failure";
    public static final String RECORD_STATE_READ_FOR_UPDATE = "ReadForUpdate";
    public static final String RECORD_STATE_UPDATE_COMPLETE = "UpdateComplete";
    public static final String EDOCS_APP = "Edocs";
    public static final String ACTIVE_STATUS = "Active";
    public static final String DSP_ADP_DATE_FORMAT = "yyyy-MM-dd";
    public static final String DSP_REYNOLDS_DATE_PATTERN = "MM/dd/yyyy";
    
    //public static final String MESSAGE_TYPE_INITIAL = "Contract";
    //public static final String MESSAGE_TYPE_TRAILING = "Trailing";
    
    // RouteOne
    public final static String HMAC_SHA256_ALGORITHM = "HmacSHA256";
    public final static String DATE_FORMAT = "EEE, dd MMM yyyy HH:mm:ss zzz";
    public final static String ROUTE_ONE_DEALER_ID = "QJ5XL";
	public final static String ROUTE_ONE_USER_ID = "gmuser";
	public final static String ROUTE_ONE_EMAIL_ID = "gmuser@cdkdealer.com";
	public final static String ROUTE_ONE_FIRST_NAME = "john";
	public final static String ROUTE_ONE_LAST_NAME = "foo";
	public final static String AUTH_ACCESS_KEY_PREFIX = "RouteOne ";
	public final static String MESSAGE_DIGEST_MD5 = "MD5";
	
    public final static String HEADER_DEALER_ID = "X-RouteOne-Act-As-Dealership";
	public final static String HEADER_USER_ID = "X-RouteOne-Audit-User-ID";
	public final static String HEADER_EMAIL_ID = "X-RouteOne-Audit-User-Email";
	public final static String HEADER_FIRST_NAME = "X-RouteOne-Audit-User-FirstName";
	public final static String HEADER_LAST_NAME = "X-RouteOne-Audit-User-LastName";
	public final static String HEADER_DATE_LABEL = "Date";
	public final static String HEADER_AUTH_LABEL = "Authorization";
	public final static String HEADER_DIGEST_LABEL = "Content-MD5";
	public final static String HEADER_CONTENT_LABEL = "Content-Type";
	public static final String HEADER_COOKIE_LABEL = "Cookie";
	public static final String AUTH_TYPE_LDAP = "LDAP";
	public static final String AUTH_TYPE_OAUTH2 = "OAuth2";
	public static final String AUTH_HEADER_TYPE_BASIC = "Basic ";
	public static final String AUTH_HEADER_TYPE_BEARER = "Bearer ";
	public static final String HTTP_HEADERS_SOAP_ACTION_LABEL = "SOAPAction";
	
	public final static String ROUTEONE_FULL_INTEGRATION = "R1F";
	public final static String ROUTEONE_PARTIAL_INTEGRATION = "R1P";
	public final static String ROUTEONE_DEALER_FLAG = "R1";
	
	public static final String ROUTEONE_DETERMINATION_FAILURE_ERROR_CODE = "E9304";
    public static final String ROUTEONE_DETERMINATION_FAILURE_MESSAGE = "Cannot determine if RouteOne integration enabled for this lender and dealer";
    
    public static final String PRODUCT_DC = "DC";
    public static final String PRODUCT_EDOC = "eDoc";
    public static final String PRODUCT_EDOCS = "eDocs";
    public static final String PRODUCT_WEBSVC = "WEBSVC";
    public static final String ROUTEONE_FLAG_YES = "Y";
    public static final String ROUTEONE_PARTNER = "RO";
    
    public static final String URL_APPENDAGE_DISTRIBUTE = "/distribute";
    public static final String URL_APPENDAGE_DISTRIBUTE_ADDENDUM = "/distribute-addendum";
    
    public static final String SAMPLE = "SAMPLE";
    
    public static final String LENDER_VCF = "VCF";
    public static final String LENDER_VOL = "VOL";
    
	/**
	 * Web Service headers for Lenders
	 */
	public static final String SOAP_HEADER_MSG_LANG_CODE = "MessageLanguageCode";
	public static final String SOAP_HEADER_SENDER_ID = "SenderID";
	public static final String SOAP_HEADER_TARGET_ID = "TargetID";
	public static final String SOAP_HEADER_MESSAGE_TYPE = "MessageType";
	public static final String SOAP_HEADER_FA_SVC_CNTRL = "h:FASServiceControl";
	public static final String SOAP_HEADER_SENT_TS = "SentTimeStamp";
	public static final String SOAP_HEADER_CORRELATION_ID = "CorrelationID";
	public static final String TAG_NAME_SOAP_BODY = "soap:Body";
	public static final String TAG_NAME_PUT_REQUEST = "PutRequest";
	public static final String TAG_NAME_PAYLOAD_MANIFEST = "payloadManifest";
	public static final String TAG_NAME_PROCESS_MESSAGE = "ProcessMessage";
	public static final String TAG_NAME_PUT_MESSAGE = "PutMessage";
	public static final String TAG_NAME_PCC = "ProcessCreditContract";
	public static final String NS_PREFIX_XMLNS_NAME = "xmlns";
	public static final String PUT_REQUEST_XMLNS = "PutRequestXmlns";
	public static final String NS_PREFIX_XMLNS_H_NAME = "xmlns:h";
	public static final String NS_XMLNS_H_VALUE = "urn:com:Fiserv:AutoSolutions:2008:07";
	public static final String NS_PREFIX_XMLNS_XSD_NAME = "xmlns:xsd";
	public static final String NS_XMLNS_XSD_VALUE = "http://www.w3.org/2001/XMLSchema";
	public static final String NS_PREFIX_XMLNS_XSI_NAME = "xmlns:xsi";
	public static final String NS_XMLNS_XSI_VALUE = "http://www.w3.org/2001/XMLSchema-instance";


}
