package com.ode.edocs.util;

import java.util.Date;

import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.rest.entity.ErrorDetail;

public class ApplicationException extends Exception {
	private static final long serialVersionUID = 7713691125798830597L;

	private String alertMessage;
	private String dealerId;
	private Date timestamp;
	private String code;
	private String message;
	private Exception originalException;
	private DcDistribution distribution;
	private ErrorDetail errorDetail;

	public ApplicationException(Exception originalException) {
		this.originalException = originalException;
	}

	public ApplicationException(Date timestamp, Exception originalException) {
		this.timestamp = timestamp;
		this.originalException = originalException;
	}

	public ApplicationException(String dealerId, Exception originalException, String code) {
		this.dealerId = dealerId;
		this.originalException = originalException;
		this.code = code;
	}

	public ApplicationException(Exception originalException, String message) {
		this.message = message;
		this.originalException = originalException;
	}

	public ApplicationException(String message) {
		this.message = message;
	}

	public ApplicationException(ErrorDetail errorDetail) {
		this.errorDetail = errorDetail;
		this.message = errorDetail.getMessage();
		this.code = errorDetail.getCode();
	}

	public ApplicationException(String message, String code, Exception originalException) {
		this.message = message;
		this.code = code;
		this.originalException = originalException;
	}

	public ApplicationException(String dealerId, String message, String code) {
		this.dealerId = dealerId;
		this.message = message;
		this.code = code;
	}

	public ApplicationException(DcDistribution distribution, String message, String code) {
		this.distribution = distribution;
		this.message = message;
		this.code = code;
	}

	public ApplicationException(Exception originalException, DcDistribution distribution, String message, String code) {
		this.originalException = originalException;
		this.distribution = distribution;
		this.message = message;
		this.code = code;
	}

	public ApplicationException(String message, String code) {
		this.message = message;
		this.code = code;
	}

	public ErrorDetail getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(ErrorDetail errorDetail) {
		this.errorDetail = errorDetail;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Exception getOriginalException() {
		return originalException;
	}

	public void setOriginalException(Exception originalException) {
		this.originalException = originalException;
	}

	public DcDistribution getDistribution() {
		return distribution;
	}

	public void setDistribution(DcDistribution distribution) {
		this.distribution = distribution;
	}
}
