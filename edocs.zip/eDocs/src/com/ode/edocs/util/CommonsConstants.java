/**
 * 
 */
package com.ode.edocs.util;

/**
 * @author rmathew
 *
 */
public interface CommonsConstants {
	public static final String KEY_X509 = "X509";
	public static final String VALUE_X509_MUTUAL_AUTH = "MutualAuth";
	public static final String VALUE_X509_CLIENT_AUTH = "ClientCert";
	public static final String KEY_KEY_STORE = "KeyStore";
	public static final Object KEY_KEY_STORE_FORMAT = "KeyStoreFormat";
	public static final String KEY_TRUST_STORE = "TrustStore";
	public static final String KEY_PROTOCOL_VERSION = "Protocol";
	public static final String JKS_FORMAT = "JKS";
	public static final String PKCS_FORMAT = "PKCS12";
	public static final String EXTN_JKS = ".jks";
	public static final String EXTN_PFX = ".pfx";
	public static final String PRODUCT_WEBSVC = "WEBSVC";
	public static final String KEY_KEY_STORE_PWD = "KeyStorePwd";
	public static final String KEY_CERT_PWD = "CertPwd";
}
