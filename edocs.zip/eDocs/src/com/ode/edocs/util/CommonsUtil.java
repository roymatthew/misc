/**
 * 
 */
package com.ode.edocs.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.edocs.db.entity.FeatureConfiguration;
import com.ode.edocs.vo.CommonsUtilNvpVO;

/**
 * @author rmathew
 *
 */
public class CommonsUtil {

	private static final Logger logger = LogManager.getLogger(CommonsUtil.class);

	/**
	 * @param featureConfigurations
	 * @return
	 */
	public static List<CommonsUtilNvpVO> getWebServiceFeatures(List<FeatureConfiguration> featureConfigurations) {
		logger.debug("Entered getWebServiceFeaturesForLender method of CommonsUtil.class");
		List<FeatureConfiguration> listOfWebServiceFeatureConfigurations = filterWebServiceFeatureConfigurations(
				featureConfigurations);
		if (listOfWebServiceFeatureConfigurations.isEmpty())
		{
			logger.debug("No webservice feature configurations found for given lender!");
		}
		List<CommonsUtilNvpVO> listOfWebServiceFeatures = new ArrayList<>();
		listOfWebServiceFeatureConfigurations.stream().forEach(featureConfig -> {
			CommonsUtilNvpVO nvpVO = new CommonsUtilNvpVO();
			nvpVO.setName(featureConfig.getFeatureName());
			nvpVO.setValue(featureConfig.getFeatureValue());
			listOfWebServiceFeatures.add(nvpVO);
		});
		logger.debug(
				"Exit getWebServiceFeaturesForLender method of CommonsUtil.class. listOfWebServiceFeatures contains {} items",
				listOfWebServiceFeatures.size());
		return listOfWebServiceFeatures;
	}

	/**
	 * @param featureConfigurations
	 * @return
	 */
	public static List<FeatureConfiguration> filterWebServiceFeatureConfigurations(
			final List<FeatureConfiguration> featureConfigurations) {
		logger.debug("Entered filterWebServiceFeatureConfigurations() method of CommonsUtil.class");
		List<FeatureConfiguration> listOfWebServiceFeatureConfigurations = new ArrayList<>();
		if (null != featureConfigurations && !featureConfigurations.isEmpty()) {
			for (FeatureConfiguration featureConfiguration : featureConfigurations)
				if (AppConstants.PRODUCT_WEBSVC.equals(featureConfiguration.getProduct())) {
					listOfWebServiceFeatureConfigurations.add(featureConfiguration);
				}
		}
		return listOfWebServiceFeatureConfigurations;
	}
	
	/**
	 * @return
	 */
	public static Map<String, String> getMapOfWebServiceFeaturesForLender(
			final List<FeatureConfiguration> featureConfigurations) {
		logger.debug(
				"Entered getMapOfWebServiceFeaturesForLender method of CommonsUtil.class. featureConfigurations contains {} items",
				featureConfigurations.size());
		List<FeatureConfiguration> listOfWebServiceFeatureConfigurations = filterWebServiceFeatureConfigurations(
				featureConfigurations);
		Map<String, String> map = new HashMap<>();
		if (listOfWebServiceFeatureConfigurations.isEmpty())
		{
			logger.debug("No webservice feature configurations found for given lender!");
		}
		else
		{
/*			map = listOfWebServiceFeatureConfigurations.stream().collect(
					Collectors.toMap(FeatureConfiguration::getFeatureName, FeatureConfiguration::getFeatureValue));
*/
			listOfWebServiceFeatureConfigurations.stream().forEach(fC -> {
				map.put(fC.getFeatureName(), fC.getFeatureValue());
			});
			logger.debug(
					"Exit getMapOfWebServiceFeaturesForLender method of CommonsUtil.class. map contains {} items",
					map.size());
		}
		return map;

	}

}
