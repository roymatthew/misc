package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDataElementXpath;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.service.IDocDataService;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DataValueUtilImpl implements IDataValueUtil {

    private static final Logger logger = LogManager.getLogger(DataValueUtilImpl.class);

    @Autowired
    private MetaDataHandler metaDataHandler;
    
    @Autowired
    private IDocDataService dcDocDataService;

    @Value("${baseAutonomousRFLForVCI}")
    private String baseAutonomousRFLForVCI;

    Date now = new Date();
    private String msg = "ECOUT > '{}', Ancillary > '{}', Comparison Result > '{}'";

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#getDataValue(java.lang.String, org.jdom2.Document, com.ode.edocs.File,
     * com.ode.edocs.db.entity.DcDocField, com.ode.edocs.db.entity.DeDataElement, com.ode.edocs.db.entity.DeLender,
     * java.lang.String, java.util.List)
     */
    @Override
    public String getDataValue(String dmsId, Document ecout, File file, DcDocField dcDocField,
        DeDataElement elementField, DeLender lender, String applicationType, List<DeDataElement> dataElements)
            throws Exception {

        logger.debug("Entered getDataValue method");
        String dataValue = null;
        String docType = file.getDcDocument().getDocType();
        String trimDataFlag = "";
        String fieldName = "";
        String elementType = "";
        String xpath = "";

        try {
            if (AppConstants.AUTONOMOUS_FLAG_YES.equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {
               if (elementField != null)  {
            	   fieldName = elementField.getElementName();
            	   elementType = elementField.getElementType();
               }
                
                if (AppConstants.SECTION_META_DATA.equalsIgnoreCase(elementType)) {
                    // for meta data elements, get xpath from
                    // DE_DATA_ELEMENT_XPATH table
                    if (null != elementField.getDeDataElementXpaths()) {
                        DeDataElementXpath deDataElementXpath = elementField.getDeDataElementXpaths().stream()
                            .filter(p -> dmsId.equals(p.getDmsId())).findFirst().orElse(null);
                        if (null != deDataElementXpath) {
                            xpath = deDataElementXpath.getXpath();
                        }
                    }
                } else if (AppConstants.SECTION_REVIEW_DATA.equalsIgnoreCase(elementType)) {
                    // for doc review elements, get xpath from
                    // DE_CONTRACT_DATA_ELEMENT table
                    xpath = elementField.getDeDocumentReview().getDeContractDataElement().getXpath();

                    // Review question (type 'R') logic below in this method
                    // Type 'F' - dataValue to be null, DE UI will populate it
                    // Type 'D' - ignore as of now
                }
            } else {
                // for non-autonomous funding lender, get value from
                // DC_DOC_FIELD table
            	if (dcDocField != null) {
	                trimDataFlag = dcDocField.getTrimDataFlag();
	                fieldName = dcDocField.getFieldName();
	                elementType = dcDocField.getSection();
	                xpath = dcDocField.getXpath();
            	}
            }
            logger.info(fieldName);

            if (null != dcDocField && null != dcDocField.getOverrideValue()
                && !dcDocField.getOverrideValue().isEmpty()) {
                dataValue = dcDocField.getOverrideValue();
            } else if (null != xpath && !xpath.isEmpty()) {
                if (("C".equals(docType) || "L".equals(docType))
                    && AppConstants.AUTONOMOUS_FLAG_NO.equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {

                    // document is contract or lease worksheet, use ECOUT data
                    dataValue = HandlerUtils.evaluateExpression(ecout, xpath);
                } else if (null != file.getAncillaryData()) {

                    // document is ancillary, use incoming xml data
                    // Get value for Meta data element
                    if (AppConstants.SECTION_META_DATA.equalsIgnoreCase(elementType)) {

                        // Autonomous lenders
                        if (AppConstants.AUTONOMOUS_FLAG_YES
                            .equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {
                            dataValue = HandlerUtils.evaluateExpression(file.getAncillaryData(), xpath);
                        } else {
                            // Non Autonomous lenders
                            if (fieldName.equals("DBAName")
                                && Arrays.asList(AppConstants.BUSINESS_APPLICATION_TYPE).contains(applicationType)
                                || (fieldName.equals("BuyerLastName") || fieldName.equals("BuyerFullName")) && Arrays
                                .asList(AppConstants.INDIVIDUAL_APPLICATION_TYPE).contains(applicationType)) {
                                dataValue = HandlerUtils.evaluateExpression(file.getAncillaryData(), xpath);
                            } else {
                                dataValue = HandlerUtils.evaluateExpression(file.getAncillaryData(), xpath);
                            }

                            if (null != trimDataFlag
                                && AppConstants.ANCILLARY_DATA_TRIM_FLAG_YES.equalsIgnoreCase(trimDataFlag)) {
                                dataValue = dataValue.replaceAll("\\s+", "");
                            }
                        }

                        if (null != dataValue && !dataValue.trim().isEmpty()) {
                            logger.debug(dataValue);
                            return dataValue;
                        } else {
                            return null;
                        }
                    } else if (AppConstants.SECTION_REVIEW_DATA.equalsIgnoreCase(elementType)) {
                        // Autonomous Lenders - Get value of Review Question
                        if (AppConstants.AUTONOMOUS_FLAG_YES
                            .equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {
                            dataValue = evaluateDocumentReviewComparisonForAutonomousLender(file, dmsId, null, ecout,
                                dataElements, elementField);
                        } else {
                            // Non Autonomous Lenders - Get value of Review
                            // Question
                            if ((fieldName.equals("BusinessAddressMatchesContract") && Arrays.asList(AppConstants.INDIVIDUAL_APPLICATION_TYPE).contains(applicationType)) || 
                            	(fieldName.equals("BuyerNameMatchesContract") && Arrays.asList(AppConstants.BUSINESS_APPLICATION_TYPE).contains(applicationType)) || 
                            	(fieldName.equals("BuyerAddressMatchesContract") && Arrays.asList(AppConstants.BUSINESS_APPLICATION_TYPE).contains(applicationType)) || 
                            	(fieldName.equals("BusinessNameMatchesContract") && Arrays.asList(AppConstants.INDIVIDUAL_APPLICATION_TYPE).contains(applicationType))) {
                                dataValue = "X";
                            } else if (fieldName.equals("BuyerNameMatchesContract") || fieldName.equals("CoBuyerNameMatchesContract")) {
                            	// Lets compare buyer first name/ last name as starts with/ ends with in ancillary data
                            	dataValue = evaluateDocumentReviewComparison(file, lender, ecout, dcDocField, elementField, dmsId, true);
                            } else {
                                dataValue = evaluateDocumentReviewComparison(file, lender, ecout, dcDocField, elementField, dmsId, false);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("An error occured while calculating data value: ", e);
        }

        return dataValue;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#evaluateDocumentReviewComparison(com.ode.edocs.File,
     * com.ode.edocs.db.entity.DeLender, org.jdom2.Document, com.ode.edocs.db.entity.DcDocField,
     * com.ode.edocs.db.entity.DeDataElement, java.lang.String)
     */
    @Override
    public String evaluateDocumentReviewComparison(File file, DeLender lender, Document ecout, DcDocField currentField, 
    											   DeDataElement metaDataField, String dmsId, boolean matchDataInText) throws Exception {
        logger.debug("Entered evaluateDocumentReviewComparison method");
        String dataValue = null;

        // comparison logic here
        List<DcDocField> fields = file.getFields();
        String ancillaryFieldValue = null;
        String metaDataFieldExpression = "";
        String xpath = "";
        String fieldType = "";
        String trimDataFlag = "";

        // for non-autonomous funding lender, get value from DC_DOC_FIELD table
        metaDataFieldExpression = (currentField != null ? currentField.getField_expression() : "");
        xpath = currentField.getXpath();
        fieldType = currentField.getFieldType();
        trimDataFlag = currentField.getTrimDataFlag();

        if (null != metaDataFieldExpression && null != xpath) {
            // Get ancillaryDocValue for comparison

            if (metaDataFieldExpression.contains("|")) {
                String[] multiExpressions = metaDataFieldExpression.split("\\|");
                for (String expression : multiExpressions) {
                    // Determine what field/fields need to be accessed in the
                    // DcDocData
                    ancillaryFieldValue = HandlerUtils.getAncillaryValueFromFile(expression.trim(), fields, file);
                    if (null != ancillaryFieldValue && ancillaryFieldValue.trim().length() > 0) {
                        break;
                    }
                }
            } else {
                // Determine what field/fields need to be accessed in the
                // DcDocData
                ancillaryFieldValue = HandlerUtils.getAncillaryValueFromFile(metaDataFieldExpression.trim(), fields,
                    file);
            }

            ancillaryFieldValue = HandlerUtils.formatFieldValue(ancillaryFieldValue, fieldType, dmsId);

            // Trim flag logic
            if (null != ancillaryFieldValue && null != trimDataFlag
                && AppConstants.ANCILLARY_DATA_TRIM_FLAG_YES.equalsIgnoreCase(trimDataFlag)) {
                ancillaryFieldValue = ancillaryFieldValue.replaceAll("\\s+", "");
            }

            String ecOutValue = null;
            if (null != ancillaryFieldValue && !ancillaryFieldValue.trim().isEmpty()) {
            	if (matchDataInText) { // Lets compare buyer first name/ last name as starts with/ ends with in ancillary data
            		dataValue = evaluateEcoutValueInAncillaryData(ecout, xpath, ancillaryFieldValue);
            	} else {
            		// Get ECOUT value for comparison.
                    ecOutValue = HandlerUtils.evaluateExpression(ecout, xpath);

                    // Do comparison
                    if (ecOutValue.equalsIgnoreCase(ancillaryFieldValue)) {
                        dataValue = "Y";
                    } else {
                        dataValue = "N";
                    }
            	}
            } else {
                dataValue = "X";
            }
            logger.info(msg, ecOutValue, ancillaryFieldValue, dataValue);
        }

        return dataValue;
    }
    
    /**
     * Return 'Y', If ECOUT firstName starts in ancillary data and ECOUT lastName ends in ancillary data
     * @return
     */
    private static String evaluateEcoutValueInAncillaryData(Document ecout, String xpath, String ancillaryFieldValue) {
    	String dataValue = "X";
    	if (xpath.contains(",")) {
            String[] entries = xpath.split("\\,");
            if (entries.length == 2) {
            	try {
            		String ecOutValue1 = HandlerUtils.evaluateExpression(ecout, entries[0].trim());
                	String ecOutValue2 = HandlerUtils.evaluateExpression(ecout, entries[1].trim());
                	logger.info("ECOUT: firstName > '" + ecOutValue1 + "'");
                	logger.info("ECOUT: lastName > '" + ecOutValue2 + "'");
                	logger.info("Ancillary: Name > '" + ancillaryFieldValue + "'");
                	if (ancillaryFieldValue.startsWith(ecOutValue1) && ancillaryFieldValue.endsWith(ecOutValue2)) {
                		dataValue = "Y";
                	} else {
                		dataValue = "N";
                	}
            	} catch (Exception e) {
            		logger.error("An error occured while getting ECOUT value to compare in Ancillary data, ", e);
            	}
            }
    	}
    	return dataValue;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#evaluateDocumentReviewComparisonForAutonomousLender(com.ode.edocs.File,
     * java.lang.String, java.util.List, org.jdom2.Document, java.util.List, com.ode.edocs.db.entity.DeDataElement)
     */
    // Calculate value of review question of type E
    @Override
    public String evaluateDocumentReviewComparisonForAutonomousLender(File file, String dmsId,
        List<DcDocData> dcDocData, Document ecout, List<DeDataElement> dataElements, DeDataElement metaDataField)
            throws Exception {

        logger.debug("Entered evaluateDocumentReviewComparisonForAutonomousLender method");
        // Ancillary value to compared against ECOUT value
        StringBuilder ancillaryValue = new StringBuilder();

        // Get the meta data value
        metaDataHandler.getMetaDataValue(file, dataElements, metaDataField, dcDocData, ancillaryValue, dmsId);

        // Get the ECOUT value
        String ecOutXpath = (metaDataField != null ? metaDataField.getDeDocumentReview().getDeContractDataElement().getXpath() : "");
        String ecOutValue = null;
        if (null != ecOutXpath && !"".equals(ecOutXpath)) {
            ecOutValue = HandlerUtils.evaluateExpression(ecout, ecOutXpath);
        }

        // Do comparison
        String result = "N";
        if (null != ecOutValue) {
            result = ecOutValue.equalsIgnoreCase(ancillaryValue.toString()) ? "Y" : "N";
        }

        logger.info(msg, ecOutValue, ancillaryValue.toString(), result);

        return result;

    }

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#getDataValueForTypeD(com.ode.edocs.db.entity.DeDataElement,
     * java.lang.String)
     */
    // Calculate value of meta data element of type D
    @Override
    public String getDataValueForTypeD(DeDataElement field, String lenderDocName) {

        logger.debug("Entered getDataValueForTypeD()");
        String dataValue = "";
        String elementName = field.getElementName();

        // BaseRFL data element - value is Y if the document name match one of
        // the RFL VCI document list from configuration
        if ("BaseRFL".equalsIgnoreCase(elementName)) {
            logger.info("baseAutonomousRFLForVCI: {}", baseAutonomousRFLForVCI);
            if (null != baseAutonomousRFLForVCI) {
                String[] values = baseAutonomousRFLForVCI.split("\\|");
                boolean isBaseRfl = Arrays.stream(values).anyMatch(lenderDocName::equals);
                dataValue = isBaseRfl ? "Y" : "N";
            }
        }
        // For any other element of type D, data value will be blank
        logger.info("dataVaule: {}", dataValue);
        return dataValue;

    }

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#getDataValueForTypeE(java.util.List,
     * com.ode.edocs.db.entity.DeDataElement, com.ode.edocs.File, java.util.List, java.lang.String, java.lang.String)
     */
    @Override
    public String getDataValueForTypeE(List<DeDataElement> dataElements, DeDataElement field, File file,
        List<DcDocData> dcDocData, String dmsId, String lenderSeqNum) {

        logger.debug("Entered getDataValueForTypeE()");
        String dataValue = "";
        String elementName = field.getElementName();
        try {
            if ("SequenceNumberMatchesCV".equals(elementName)) {
                StringBuilder ancillaryValue = new StringBuilder();

                // Get meta data value from ancillary XML
                metaDataHandler.getMetaDataValue(file, dataElements, field, dcDocData, ancillaryValue, dmsId);

                dataValue = ancillaryValue.toString().equals(lenderSeqNum) ? "Y" : "N";
                logger.info("LenderSequenceNumber > '{}', Ancillary > '{}', Comparison Result > '{}'", lenderSeqNum,
                    ancillaryValue.toString(), dataValue);
            }
        } catch (Exception e) {
            logger.error("Error occured while getting data value for type E record: ", e);
        }
        // For any other element of type D, data value will be blank
        return dataValue;

    }

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#compareDocDataWithContract(org.jdom2.Document, java.util.List,
     * java.util.List, java.lang.String, java.lang.Integer)
     */
    @Override
    public void compareDocDataWithContract(Document ecOut, List<DcDocField> reviewQuestionDocFields,
        List<DcDocData> dcDocData, String dmsId, Integer dcDocumentId) throws Exception {

        logger.debug("Entered compareDocDataWithContract method");
        try {
            String metaDataFieldExpression = null;
            String ecOutXPath = null;
            String dataValue = null;

            for (DcDocField field : reviewQuestionDocFields) {
                metaDataFieldExpression = field.getField_expression();
                ecOutXPath = field.getXpath();
                if (null != metaDataFieldExpression && null != ecOutXPath) {
                    Predicate<DcDocData> predicate = p -> p.getDataName().equals(field.getFieldName());
                    DcDocData docReviewData = dcDocData.stream().filter(predicate).findFirst().orElse(null);
                    if (docReviewData == null) {
                        // No ancillary data record found in DC_DOC_DATA, add a
                        // new one
                        docReviewData = new DcDocData();
                        docReviewData.setDcDocumentId(dcDocumentId);
                        docReviewData.setDataName(field.getFieldName());
                        dataValue = compareAncillaryVsContract(ecOut, dmsId, metaDataFieldExpression, dcDocData, field);
                        docReviewData.setDataValue(dataValue);
                        docReviewData.setSection("R");
                        docReviewData.setCreatedBy(AppConstants.EDOCS_COMPARISON);
                        docReviewData.setCreatedTs(now);

                        // Update DcDocData
                        dcDocDataService.saveOrUpdate(docReviewData);

                        // Add this new record to list, so that compare will
                        // work properly
                        dcDocData.add(docReviewData);
                    } else {
                        dataValue = compareAncillaryVsContract(ecOut, dmsId, metaDataFieldExpression, dcDocData, field);
                        docReviewData.setDataValue(dataValue);
                        docReviewData.setModifiedBy(AppConstants.EDOCS_COMPARISON);
                        docReviewData.setModifiedTs(now);
                        // Update DcDocData
                        dcDocDataService.saveOrUpdate(docReviewData);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error occured while saving processing ancillary data values, ", e);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.ode.edocs.util.IDataValueUtil#compareAncillaryVsContract(org.jdom2.Document, java.lang.String,
     * java.lang.String, java.util.List, com.ode.edocs.db.entity.DcDocField)
     */
    @Override
    public String compareAncillaryVsContract(Document ecOut, String dmsId, String metaDataFieldExpression,
        List<DcDocData> dcDocData, DcDocField field) throws Exception {
        logger.debug("Entered compareAncillaryVsContract method");
        String ancillaryFieldValue = null;
        String ecOutValue = null;
        String result = "X";
        String fieldType = field.getFieldType();
        String trimDataFlag = field.getTrimDataFlag();
        String ecOutXPath = field.getXpath();

        // Get ancillaryDocValue for comparison
        if (metaDataFieldExpression.contains("|")) {
            String[] multiExpressions = metaDataFieldExpression.split("\\|");
            for (String expression : multiExpressions) {
                ancillaryFieldValue = HandlerUtils.getLatestAncillaryValue(expression.trim(), dcDocData);
                if (null != ancillaryFieldValue && ancillaryFieldValue.trim().length() > 0) {
                    break;
                }
            }
        } else {
            // Determine what field/fields need to be accessed in the DcDocData
            ancillaryFieldValue = HandlerUtils.getLatestAncillaryValue(metaDataFieldExpression.trim(), dcDocData);
        }

        if (null != ancillaryFieldValue && !ancillaryFieldValue.trim().isEmpty()) {
            ancillaryFieldValue = HandlerUtils.formatFieldValue(ancillaryFieldValue, fieldType, dmsId);
            // Trim flag logic
            if (null != trimDataFlag && AppConstants.ANCILLARY_DATA_TRIM_FLAG_YES.equalsIgnoreCase(trimDataFlag)) {
                if (ancillaryFieldValue != null) ancillaryFieldValue = ancillaryFieldValue.replaceAll("\\s+", "");
            }

            // Get ECOUT value for comparison.
            ecOutValue = HandlerUtils.evaluateExpression(ecOut, ecOutXPath);

            // Do comparison

            result = ecOutValue.equalsIgnoreCase(ancillaryFieldValue) ? "Y" : "N";
        }
        logger.info(msg, ecOutValue, ancillaryFieldValue, result);
        return result;
    }
}
