package com.ode.edocs.util;

public class DistributionHelper {
	String deDealId;
	String sequenceId;
	
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}
	public String getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}
	
	@Override
	public String toString() {
		return "DistributionHelper [deDealId=" + deDealId + ", sequenceId=" + sequenceId + "]";
	}
}