package com.ode.edocs.util;

import com.ode.edocs.util.enums.DmsEnum;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.xml.sax.InputSource;

public class EdocsXmlUtils {

    private static final Logger logger = LogManager.getLogger(EdocsXmlUtils.class);

    private static Namespace dig = Namespace.getNamespace("dig", "http://www.opendealerexchange.com/DigitalDeal");
    private static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");
    private static Namespace soaptrans = Namespace.getNamespace("soaptrans",
        "http://www.starstandards.org/webservices/2005/10/transport");
    private static Namespace ns = Namespace.getNamespace("ns", "http://www.cdk.com/DC/DealData/");
    private static List<Namespace> namespaces = Arrays.asList(star, soaptrans, dig, ns);

    /**
     * @param inboundXml
     * @return dmsId String
     * @throws Exception
     */
    public static String getDmsId(final Document inboundXml) throws Exception {

        logger.debug("Enter getDmsId");
        String dmsId = "";
        dmsId = getTextFromXpath(inboundXml, XMLConstants.starCreatorNameCodePath);
        if ("RE".equalsIgnoreCase(dmsId) || "RP".equalsIgnoreCase(dmsId)) {
            dmsId = DmsEnum.RR.getDmsId();
        }
        logger.debug("Exit getDmsId");
        return dmsId;
    }
    
    public static String getDealerId(final Document inboundXml) throws Exception {
        logger.debug("Enter getDealerId");
        String dealerId = getTextFromXpath(inboundXml, XMLConstants.starDealerNumberCodePath);
        logger.debug("Exit getDealerId");
        return dealerId;
    }
    
    public static String getAuthorizationId(final Document inboundXml) throws Exception {

        logger.debug("Enter getAuthorizationId");
        String authorizationId = getTextFromXpath(inboundXml, XMLConstants.authorizationId);
        logger.debug("Exit getauthorizationId:  ", authorizationId);
        return authorizationId;
    }

    /**
     * @param xml
     * @param xpath
     * @return
     * @throws Exception
     */
    public static boolean doesXPathExist(final Document xml, final String xpath) throws Exception {

        if (xml == null || StringUtils.isBlank(xpath)) {
            return false;
        }

        final String value = getTextFromXpath(xml, xpath);
        if (!StringUtils.isBlank(value)) {
            return true;
        }

        return false;
    }

    /**
     * @param document
     * @param xpathExpression
     * @return
     * @throws Exception
     */
    public static String getTextFromXpath(final Document document, final String xpathExpression) throws Exception {

        logger.debug("Enter getTextFromXpath");

        if (document == null) {
            logger.warn("Document is null for xpath expression {}.", xpathExpression);
            return "";
        }

        String elementText = "";
        final XPathExpression<Element> xpath = XPathFactory.instance().compile(xpathExpression, Filters.element(), null,
            namespaces);
        final List<Element> elements = xpath.evaluate(document);
        Element element = null;
        if (null != elements && !elements.isEmpty()) {
            if (elements.size() > 1) {
                logger.warn("More than one result found for xpath:{}", xpathExpression);
            }
            element = elements.get(0);
        }
        if (null != element) {
            elementText = element.getText().trim();
        } else {
            logger.debug("{} not found", xpathExpression);
        }

        // This hack exists to avoid logging byte64 encoded strings.
        if (elementText.length() > 1000) {
            return elementText;
        }

        //logger.trace("Entry: " + xpathExpression + ", Exit: " + elementText);
        logger.debug("Exit getTextFromXpath");
        return elementText;
    }

    /**
     * @param document
     * @param xpathExpression
     * @return
     * @throws Exception
     */
    public static String getTextFromXpathFunction(final Document document, final String xpathExpression)
        throws Exception {
        logger.debug("Entered method getTextFromXpathFunction()");
        if (document == null) {
            logger.debug("Document is null for xpath expression {}.", xpathExpression);
            return "";
        }

        XPathExpression<String> xpath = XPathFactory.instance().compile(xpathExpression, Filters.fstring(), null,
            namespaces);
        List<String> elementTextList = xpath.evaluate(document);
        String elementText = null;
        if (null != elementTextList && !elementTextList.isEmpty()) {
            if (elementTextList.size() > 1) {
                logger.debug("More than one result found for xpath:{}", xpathExpression);
            }
            elementText = elementTextList.get(0);
        }
        if (null != elementText) {
            logger.debug("{} found - getting text", xpathExpression);
            return elementText.trim();
        } else {
            logger.debug("{} not found", xpathExpression);
            return "";
        }
    }

    /**
     * @param xml
     * @return
     * @throws Exception
     */
    public static Document getDocumentFromString(final String xml) throws Exception {

        logger.debug("Enter getDocumentFromString");

        final SAXBuilder saxBuilder = new SAXBuilder();
        Document document = null;
        try {
            document = saxBuilder.build(new StringReader(xml));
        } catch (JDOMException e) {
            logger.error("Could not parse XML into document, but we will continue with distribution", e);
            //throw new ApplicationException(AppConstants.EDOCIN_PARSE_ERR_MSG, AppConstants.EDOCIN_PARSE_ERROR, e);
        } catch (IOException e) {
            logger.error("could not read xml into document", e);
            throw new ApplicationException(AppConstants.EDOCIN_PARSE_ERR_MSG, AppConstants.EDOCIN_PARSE_ERROR, e);
        }

        logger.debug("Exit getDocumentFromString");
        return document;
    }

    /**
     * @param stream
     * @return
     * @throws Exception
     */
    public static Document getDocumentFromInputStream(final InputStream stream) throws Exception {

        logger.debug("Enter getDocumentFromInputStream");

        final SAXBuilder saxBuilder = new SAXBuilder();
        Document document = null;
        try {
            document = saxBuilder.build(stream);
        } catch (JDOMException e) {
            logger.error("Could not parse XML into document, but we will continue with distribution", e);
            //throw new ApplicationException(AppConstants.EDOCIN_PARSE_ERR_MSG, AppConstants.EDOCIN_PARSE_ERROR, e);
        } catch (IOException e) {
            logger.error("could not read xml into document", e);
            throw new ApplicationException(AppConstants.EDOCIN_PARSE_ERR_MSG, AppConstants.EDOCIN_PARSE_ERROR, e);
        }

        logger.debug("Exit getDocumentFromInputStream");
        return document;
    }

    /**
     * @param document
     * @return
     * @throws Exception
     */
    public static String convertDocumentToString(final Document document) throws Exception {

        logger.debug("Entering ConvertDocumentToString(final Document document) method");

        final XMLOutputter xmlOutput = new XMLOutputter();
        xmlOutput.setFormat(Format.getPrettyFormat());
        final String strippedXml = xmlOutput.outputString(document);

        return strippedXml;
    }

    /**
     * @param xml
     * @return
     * @throws Exception
     */
    public static DistributionProcessingVO getDistributionProcessingParams(final String xml) throws Exception {

        logger.debug("Enter getDistributionProcessingParams");

        final SAXBuilder saxBuilder = new SAXBuilder();
        Document document = null;
        DistributionProcessingVO distributionProcessingVO = new DistributionProcessingVO();
        try {
            document = saxBuilder.build(new StringReader(xml));
            distributionProcessingVO = new DistributionProcessingVO(document);
        } catch (JDOMException e) {
            logger.error("Could not parse XML into document, but we will continue with distribution", e);
            //throw new ApplicationException(AppConstants.EDOCIN_PARSE_ERR_MSG, AppConstants.EDOCIN_PARSE_ERROR, e);
        } catch (IOException e) {
            logger.error("could not read xml into document", e);
            throw new ApplicationException(AppConstants.EDOCIN_PARSE_ERR_MSG, AppConstants.EDOCIN_PARSE_ERROR, e);
        }

        distributionProcessingVO.setDmsId(getDmsId(document));
        distributionProcessingVO
        .setApplicationNumber(getTextFromXpath(document, XMLConstants.starApplicationNumberPath));
        distributionProcessingVO.setDmsDealNumber(getTextFromXpath(document, XMLConstants.starDealIdPath));
        distributionProcessingVO.setPartyId(getTextFromXpath(document, XMLConstants.starPartyIdPath));
        distributionProcessingVO.setDealerId(getTextFromXpath(document, XMLConstants.starDealerNumberPath));
        distributionProcessingVO
        .setContractValidationSequenceNumber(getTextFromXpath(document, XMLConstants.starBodIdPath));

        logger.debug("Exit getDistributionProcessingParams");
        return distributionProcessingVO;
    }
    
	/**
	 * @param doc
	 * @return
	 * @throws TransformerException
	 */
	public static String getXmlStringFromDocument(final org.w3c.dom.Document doc) throws TransformerException {
		
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
				org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
		Transformer transformer = tf.newTransformer();
		if (transformer != null) {
			transformer.transform(domSource, result);
		} else {
			logger.debug("transformer is null");
		}
		return writer.toString();
	}
	
    /**
     * @param xml
     * @return
     * @throws Exception
     */
    public static org.w3c.dom.Document getW3CDocumentFromString(final String xml) throws Exception {

        logger.debug("Enter getW3CDocumentFromString");
        org.w3c.dom.Document document = null;
        try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = factory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(xml));
			document = documentBuilder.parse(is);
		} catch (final Exception e) {
	        logger.debug("Exception caught within getW3CDocumentFromString() method", e);
	        throw e;
		}
        logger.debug("Exit getW3CDocumentFromString");
        return document;

    }

}
