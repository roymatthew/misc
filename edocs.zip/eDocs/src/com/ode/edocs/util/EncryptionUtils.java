package com.ode.edocs.util;

import com.ode.edocs.Keys;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.openssl.EncryptionException;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public final class EncryptionUtils {
    private static final Logger logger = LogManager.getLogger(EncryptionUtils.class);

    private static final String HARDCODED_KEYID = "000";
    private static final String HARDCODED_KEYSTRING = "6s1l2c7gv3k209ii5ilgw";
    private static final String HARDCODED_ALGORITHM = "PBEWithSHA1AndRC4_128";
    private static final String DEFAULT_KEYID = "001";

    private static List<Keys> keyInfo;
    static {
        keyInfo = Keys.getKeyInfo();
    }

    private static final int count = 20;
    private static final byte[] salt = { (byte) 0xc7, (byte) 0x7d, (byte) 0x21, (byte) 0x8c, (byte) 0x7e, (byte) 0xc8,
            (byte) 0xee, (byte) 0x96 };
    private static final byte[] IV = { (byte) 0x93, (byte) 0xCE, (byte) 0xA9, (byte) 0x7E, (byte) 0x83, (byte) 0xAE,
            (byte) 0x72, (byte) 0xAB, (byte) 0x0B, (byte) 0x39, (byte) 0xDF, (byte) 0x7E, (byte) 0x43, (byte) 0x5B,
            (byte) 0x86, (byte) 0x0C };

    public synchronized static final List<String> encryptText(String dataToEncrypt) throws Exception {
        BASE64Encoder base64Encoder = new BASE64Encoder();
        List<String> encryptedText = new ArrayList<String>();

        String keyId = HARDCODED_KEYID;
        String password = HARDCODED_KEYSTRING;
        String algorithm = HARDCODED_ALGORITHM;
        Date now = new Date();
        boolean matchFound = false;

        for (Keys key : keyInfo) {
            // get active key with current system timestamp
            if (key.getEffectiveDate().before(now) && key.getExpiryDate().after(now)) {
                keyId = key.getKeyId();
                password = key.getKeyString();
                algorithm = key.getAlgorithm();
                matchFound = true;
                break;
            }
        }

        if (!keyInfo.isEmpty() && !matchFound) {
            logger.error("could not find an active key, will use default key: " + DEFAULT_KEYID);
            keyId = DEFAULT_KEYID;
            for (Keys key : keyInfo) {
                if (key.getKeyId().equals(keyId)) {
                    password = key.getKeyString();
                    algorithm = key.getAlgorithm();
                    matchFound = true;
                    break;
                }
            }
        }

        if (!matchFound) {
            logger.error("could not find an active key, will use default key: " + HARDCODED_KEYID);
        }
        logger.debug("keyId:{}", keyId);
        logger.debug("algorithm:{}", algorithm);

        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
        PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, count, new IvParameterSpec(IV));
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
        SecretKey key = keyFactory.generateSecret(keySpec);

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.ENCRYPT_MODE, key, parameterSpec);

        byte[] encryptedBytes = cipher.doFinal(dataToEncrypt.getBytes());
        encryptedText.add(0, keyId);
        encryptedText.add(1, base64Encoder.encodeBuffer(encryptedBytes));

        return encryptedText;
    }

    /**
     * Takes in encrypted text data as a base64 encoded string, and returns
     * enecrypted data.
     *
     * @param dataToDecrypt
     *            The data to decrypt
     * @param password
     *            The password
     * @return Encrypted text data
     *
     * @throws EncryptionException
     * @throws InvalidAlgorithmParameterException
     * @throws InvalidKeyException
     * @throws IOException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     */
    public synchronized static final String decryptText(String dataToDecrypt, String keyId) throws Exception {
        logger.debug("Entered method decryptText(String dataToDecrypt, String keyId)");
        BASE64Decoder base64Decoder = new BASE64Decoder();

        String password = "";
        String algorithm = "";
        boolean matchFound = false;

        if (null != keyId && keyId.equals(HARDCODED_KEYID)) {
            password = HARDCODED_KEYSTRING;
            algorithm = HARDCODED_ALGORITHM;
        } else {
            if (keyInfo.isEmpty()) {
                throw new Exception("No data from keys.xml available. Cannot decrypt xml.");
            }
            if (keyId == null) {
                keyId = DEFAULT_KEYID;
            }
            for (Keys key : keyInfo) {
                // look up password with the data associated keyId
                if (key.getKeyId().equals(keyId)) {
                    password = key.getKeyString();
                    algorithm = key.getAlgorithm();
                    matchFound = true;
                    break;
                }
            }
            if (!matchFound) {
                logger.error("could not find a matching key in keys.xml - cannot decrypt xml");
                throw new Exception("could not find a matching key in keys.xml - cannot decrypt xml");
            }
        }

        logger.debug("keyId:{}", keyId);
        logger.debug("algorithm:{}", algorithm);

        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, 20, 32);
        PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, count, new IvParameterSpec(IV));

        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
        SecretKey key = keyFactory.generateSecret(keySpec);

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key, parameterSpec);

        byte[] encryptedBytes = base64Decoder.decodeBuffer(dataToDecrypt);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);


        return new String(decryptedBytes);
    }
    public static byte[] base64Decode(String encodedString) throws Exception {
        logger.debug("Entered method base64Decode(String encodedString)");
        BASE64Decoder base64Decoder = new BASE64Decoder();
        byte[] binaryData = null;
        try {
            binaryData = base64Decoder.decodeBuffer(encodedString);
        } catch (IOException e) {
            logger.error("could not decode base64 string", e);
        }


        return binaryData;
    }

    public static String base64Encode(byte[] binaryData) throws Exception {
        logger.debug("Entered method base64Encode(byte[] binaryData)");
        BASE64Encoder base64Encoder = new BASE64Encoder();
        String encodedString = null;
        encodedString = base64Encoder.encodeBuffer(binaryData);


        return encodedString;
    }
}