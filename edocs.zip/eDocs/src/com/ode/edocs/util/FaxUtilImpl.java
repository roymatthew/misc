package com.ode.edocs.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.ode.edocs.File;
import com.ode.edocs.db.dao.DeDealDAO;
import com.ode.edocs.db.dao.DeFaxServiceDAO;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeFaxService;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.rest.entity.FaxDocument;
import com.ode.edocs.rest.entity.FaxRequest;
import com.ode.edocs.rest.entity.FaxResponse;
import com.ode.edocs.service.ICreditJournalService;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class FaxUtilImpl implements IFaxUtil {

    private static final Logger logger = LogManager.getLogger(FaxUtilImpl.class);

    @Autowired
    private DeFaxServiceDAO deFaxServiceDao;

    @Autowired
    public IHandleDistributeUtil handleDistributeImpl;

    @Autowired
    public ICreditJournalService creditJournalService;


    @Override
    public FaxResponse faxDocuments(DeDeal deDeal, FaxRequest faxRequest, DeLenderDestination lenderDest,
        DeDealDAO deDealDAO) {
        logger.debug(
            "Entered method faxDocuments(DeDeal deDeal, FaxRequest faxRequest, DeLenderDestination lenderDest,DeDealDAO deDealDAO)");
        RestTemplate restTemplate = new RestTemplate();
        String destUrl = "";
        if (lenderDest != null) {
        	destUrl = lenderDest.getDestination_url();
        } else {
        	logger.debug("lenderDest is null, sending to lender will fail");
        }
        FaxResponse faxResponse = new FaxResponse();

        try {
            String result = restTemplate.postForObject(destUrl, faxRequest, String.class);
            String faxRequestStringAttachmentRemoved = removeAndReplaceBase64Attachment(faxRequest);
            faxResponse.setEfaxIn(faxRequestStringAttachmentRemoved);
            if (null != result) {
                String[] split = result.split(":");
                faxResponse.setFaxResponseCode(split[0]);
                faxResponse.setFaxResponseMessage(split[1]);
                logger.info("FaxService Response: " + result);
            } else logger.info("FaxService Response: is null");
            
            if (!"200".contentEquals(faxResponse.getFaxResponseCode())) {

                logger.error(
                    "Error sending document to Fax Service at:" + destUrl + " Response: " + faxResponse.toString());
                throw new ApplicationException(
                    deDeal.getLenderId(), "Error sending document to Fax Service at:" + destUrl
                    + ", fax service response code is:" + faxResponse.getFaxResponseCode(),
                    AppConstants.FAX_TO_LENDER_ERROR_CODE);
            } else {
                return faxResponse;
            }

        } catch (Exception e) {
            logger.error(e);
        }

        return faxResponse;
    }

    private String removeAndReplaceBase64Attachment(FaxRequest faxRequest) {
    	if (faxRequest != null) {
	        List<FaxDocument> documents = faxRequest.getDocuments();
	        for (FaxDocument document : documents) {
	            document.setContents(AppConstants.ATTACHMENT_TEXT_REPLACED);
	        }
    	}
        return jsonToString(faxRequest);

    }

    @Override
    public String jsonToString(FaxRequest faxRequest) {
        com.fasterxml.jackson.databind.ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        String faxRequestString = "";
        try {
            logger.info(mapper.writeValueAsString(faxRequest));
            faxRequestString = mapper.writeValueAsString(faxRequest);
        } catch (JsonProcessingException e) {
            logger.info(e.getMessage());
        }
        return faxRequestString;
    }

    @Override
    public FaxRequest createFaxRequest(DeDeal deDeal, List<File> files, String sequenceId, String bodId,
        String lenderId) {
        logger.debug(
            "Entered method createFaxRequest(DeDeal deDeal, List<File> files, String sequenceId, String bodId,String lenderId)");
        String transactionType = "";
        DeFaxService deFaxService = null;

        if (sequenceId.equals("DS01")) {
            transactionType = "I";
        } else {
            transactionType = "T";
        }

        FaxRequest faxRequest = new FaxRequest();
        faxRequest.setDeDealId(deDeal.getDealId());
        faxRequest.setDistSequenceId(sequenceId);
        faxRequest.setBodId(bodId);

        if (AppConstants.DSP_REYNOLDS.equalsIgnoreCase(deDeal.getDmsId())) {
            faxRequest.setSendConfirmationFlag(AppConstants.FAX_CONFIRMATION_FLAG_YES);
        } else {
            faxRequest.setSendConfirmationFlag(AppConstants.FAX_CONFIRMATION_FLAG_NO);
        }

        try {
            deFaxService = deFaxServiceDao.getFaxNumber(lenderId, transactionType);
        } catch (Exception e) {
            logger.error(e);
        }

        if (null != deFaxService) {
            faxRequest.setRecipientFaxNumber(deFaxService.getFaxNumber());
            faxRequest.setHeaderDetails(deFaxService.getFaxHeader());
            List<FaxDocument> documentList = new ArrayList<FaxDocument>();
            for (File file : files) {
                if (null != file.getFileExtension()
                    && AppConstants.FILE_EXTENSION_PDF.equalsIgnoreCase(file.getFileExtension())) {
                    FaxDocument document = new FaxDocument();
                    document.setDcDocumentId(file.getDcDocument().getId());
                    document.setDocName(file.getFormattedFileName());
                    document.setDocFormat(file.getFileExtension());
                    try {
                        document.setContents(EncryptionUtils.base64Encode(file.getContents()));
                    } catch (Exception e) {
                        logger.error("", e);
                    }
                    documentList.add(document);
                }
            }

            faxRequest.setDocuments(documentList);
            // Print the Json Request in logs
            jsonToString(faxRequest);
            return faxRequest;
        } else {
            logger.error("Unable to find the Fax Service details for the lender: " + lenderId);
            return null;
        }
    }

    @Override
    public BigInteger writeFAXIN(Document inDocument, String faxRequest, Date timeStamp, String deDealId,
        String sequenceId, String transactionId, String accountId) throws Exception {
        logger.debug(
            "Entered method writeFAXIN(Document inDocument, String faxRequest, Date timeStamp, String deDealId,String sequenceId, String transactionId, String accountId)");

        CreditJournal creditJournal = new CreditJournal();
        String dsp = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath);
        String faxRequestXml = "<faxRequest>" + (faxRequest != null ? faxRequest : "") + "</faxRequest>";

        creditJournal.setCrDataXml(handleDistributeImpl.encryptedXmlwithKeyId(faxRequestXml).get(1));
        creditJournal.setSystemId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starStoreNumber));
        creditJournal.setDealerId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealerNumberPath));

        String partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationNameCode);
        if (partnerId == null || AppConstants.EMPTY_STRING.equals(partnerId)) {
            partnerId = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDestinationPath);
        }
        creditJournal.setPartnerId(partnerId);
        creditJournal.setUserId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starAuthorizationPath));
        creditJournal.setTransDateTime(timeStamp);
        creditJournal.setTransType("FAXIN");
        creditJournal.setEncryptionKeyId(handleDistributeImpl.encryptedXmlwithKeyId(faxRequest).get(0));
        String financeType = EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starFinanceTypePath);
        if (financeType.equals("1")) {
            financeType = "R";
        } else if (financeType.equals("2")) {
            financeType = "L";
        }
        creditJournal.setApplicationType(financeType);
        creditJournal.setAdpDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starDealIdPath));
        creditJournal.setPartnerDealNumber(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starBodIdPath));
        creditJournal.setSequenceNumber(AppConstants.EMPTY_STRING);
        creditJournal.setFinanceInstitution(AppConstants.EMPTY_STRING);
        creditJournal.setTransFlag(AppConstants.NO);
        creditJournal.setAccountId(accountId);
        creditJournal.setDeliverySource(dsp);
        creditJournal
        .setApplicationSource(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDspId(EdocsXmlUtils.getTextFromXpath(inDocument, XMLConstants.starCreatorNameCodePath));
        creditJournal.setDealId(deDealId);
        creditJournal.setSequenceId(sequenceId);
        creditJournal.setTransactionId(transactionId);

        BigInteger cjKey = creditJournalService.saveOrUpdate(creditJournal);
        return cjKey;
    }

    @Override
    public DeFaxService getFaxNumber(String lenderId, String transactionType) throws Exception {

        return null;
    }
}
