package com.ode.edocs.util;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.ode.edocs.db.entity.*;
import com.ode.edocs.service.*;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ode.edocs.File;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.vault.db.entity.VaultRegisterDocument;

@Component
public class HandleDistributeUtilImpl implements IHandleDistributeUtil {

	private static final Logger logger = LogManager.getLogger(HandleDistributeUtilImpl.class);

	@Autowired
	private IDealService dealService;
	@Autowired
	private IDcFormDAOService dcFormService;
	@Autowired
	private IDistributionService disributionService;
	@Autowired
	private IDocDataService dcDocDataService;
	@Autowired
	private IDcDocumentService dcDocumentService;
	@Autowired
	private IDeLenderDAOService deLenderService;
	@Autowired
	private IDeLenderPartnerDAOService deLenderPartnerService;
	@Autowired
	private IVaultRegisterDocumentDAOService vaultRegisterDocumentService;
	@Autowired
	private IServicesUtil servicesImpl;
	@Autowired
	private IPrepareDistributionUtil prepareDistributionUtil;

	private NumberFormat sequenceNumberFormat = NumberFormat.getIntegerInstance(); // NO_UCD
																					// (test
																					// only)

	@Value("${baseAutonomousRFLForVCI}")
	private String baseAutonomousRFLForVCI;

	@Override
	public void updateDcDistributionRecord(DcDistribution distribution, List<File> files, DeLender lender,
			BigInteger edocOutCjKey, String distStatus, Date timeStamp) throws Exception {

		logger.debug("Entered updateDcDistributionRecord method");
		if (distribution != null) {
			distribution.setOutboundXml(edocOutCjKey);
			distribution.setDist_status(distStatus);
			distribution.setModifiedBy("SYSTEM");
			distribution.setModifiedTs(timeStamp);
	
			if (!AppConstants.DOCUMENT_MAPPING_FLAG_NO.equalsIgnoreCase(lender.getDocumentMappingEnabled())) {
				for (File file : files) {
					if (!"Y".equalsIgnoreCase(file.getDcDocument().getFormComplete())) {
						distribution.setReadyToBook("N");
						break;
					}
					distribution.setReadyToBook("Y");
				}
			}
			disributionService.saveOrUpdate(distribution);
		}
	}

	@Override
	public void processQuestionReview(List<File> files, Document ecOut) throws Exception {

		logger.debug("Entered processQuestionReview()");
		for (File file : files) {
			if (null != file.getDocData() && !file.getDocData().isEmpty()) {
				for (DcDocData docData : file.getDocData()) {
					if (null != docData.getSection()
							&& AppConstants.SECTION_REVIEW_DATA.equalsIgnoreCase(docData.getSection())) {

						// if a change is needed, determineQuestionUpdate will
						// set the new value in the docData
						// return true and process the DB update
						String newQuestionAnswer = reEvaluateReviewQuestion(file, ecOut, docData);
						String currentQuestionAnswer = docData.getDataValue();

						// Compare the stored answer with the new answer
						if (null != newQuestionAnswer && !newQuestionAnswer.isEmpty() && null != currentQuestionAnswer
								&& !currentQuestionAnswer.isEmpty()
								&& !currentQuestionAnswer.equals(newQuestionAnswer)) {
							// Update stored answer with new answer.
							docData.setDataValue(newQuestionAnswer);
							dcDocDataService.saveOrUpdate(docData);
						}
					}
				}
			}
		}

	}

	@Override
	public String reEvaluateReviewQuestion(File file, Document ecout, DcDocData currentQuestion) throws Exception {

		logger.debug("Entered reEvaluateReviewQuestion method");
		List<DcDocData> storedMetaData = new ArrayList<DcDocData>();
		DcDocField questionField = null;
		String newQuestionAnswer = null;

		// Load storedMetaData list with DcDocData metadata (section M)
		for (DcDocData data : file.getDocData()) {
			if (null != data.getSection() && AppConstants.SECTION_META_DATA.equalsIgnoreCase(data.getSection())) {
				storedMetaData.add(data);
			}
		}

		// Find and load questionField object with DcDocField that matches the
		// currentQuestion dataName
		if (null != file.getFields() && !file.getFields().isEmpty()) {
			for (DcDocField docField : file.getFields()) {
				if (docField.getFieldName().equalsIgnoreCase(currentQuestion.getDataName())) {
					questionField = docField;
					break;
				}
			}
		}

		// comparison logic here
		if (null != questionField) {
			String storedValue = null;
			String fieldExpression = questionField.getField_expression();
			String starXPath = questionField.getXpath();
			String trimDataFlag = questionField.getTrimDataFlag();

			if (null != fieldExpression) {

				if (fieldExpression.contains("|")) {
					String[] multiExpressions = fieldExpression.split("\\|");
					for (String expression : multiExpressions) {

						// Determine what field/fields need to be accessed in
						// the DcDocData
						storedValue = HandlerUtils.getStoredAncillaryValue(expression.trim(), storedMetaData);
						if (null != storedValue && storedValue.trim().length() > 0) {
							break;
						}
					}
				} else {
					// Determine what field/fields need to be accessed in the
					// DcDocData
					storedValue = HandlerUtils.getStoredAncillaryValue(fieldExpression.trim(), storedMetaData);
				}
			}

			// Trim flag logic
			if (null != storedValue && null != trimDataFlag
					&& AppConstants.ANCILLARY_DATA_TRIM_FLAG_YES.equalsIgnoreCase(trimDataFlag)) {
				storedValue = storedValue.replaceAll("\\s+", "");
			}

			if (null != storedValue && !storedValue.trim().isEmpty() && null != starXPath && !starXPath.isEmpty()) {
				// Get ECOUT value for comparison.
				String ecOutValue = HandlerUtils.evaluateExpression(ecout, starXPath).trim();
				// Do comparison
				if (ecOutValue.trim().equalsIgnoreCase(storedValue)) {
					newQuestionAnswer = "Y";
				} else {
					newQuestionAnswer = "N";
				}
			} else {
				newQuestionAnswer = "X";
			}
		}

		return newQuestionAnswer;
	}

	@Override
	public void updateForms(final List<DcForm> dcForms, final DcDocument dcDocument, final File file,
			final String deDealId, final String lenderId) throws Exception {

		logger.debug("Entered updateForms method");
		String dmsFormId = "00000";
		String docName = dcDocument.getDmsDocName();
		// If the formID is prefixed with the document/pdf name, use that.
		if (null != docName && docName.indexOf("-") > 0) {
			dmsFormId = docName.substring(0, docName.indexOf("-"));
		}

		DmsDocType dmsDocType = file.getDmsDocType();

		if (null != dmsDocType) {
			dmsFormId = dmsDocType.getDmsFormId();
			if ((dmsFormId == null || dmsFormId.isEmpty()) && null != dmsDocType.getId()) {
				// Unsolicited additional documents sent from DMS
				// If the document does not have formId prefix and if it is also not
				// found in the DMS DOC TYPE table,
				// then use the dmsDocType Id to use as the formId
				dmsFormId = AppConstants.FORM_ID_FORMAT.format(dmsDocType.getId());
			}
		}

		String documentName = dmsDocType != null ? dmsDocType.getDocName() : file.getLenderDocName();
		Date now = new Date();
		if (dcForms == null || dcForms.isEmpty()) {
			logger.debug("dcForms is null. Adding DcForm..");
			DcForm dcForm = new DcForm();

			dcForm.setDeDealId(deDealId);
			dcForm.setDcDocument(dcDocument);
			dcForm.setFormId(dmsFormId);
			dcForm.setFormName(documentName);
			dcForm.setFormStatus(AppConstants.DOCUMENT_STATUS_DISTRIBUTED);
			dcForm.setTransferredDate(now);
			dcForm.setRequiredFormFlag(AppConstants.REQUIRED_FORM_FLAG_NO);
			dcForm.setCreatedBy(AppConstants.EDOCS_DMS_USER);
			dcForm.setCreatedTs(now);
			dcForm.setModifiedBy(AppConstants.EDOCS_DMS_USER);
			dcForm.setModifiedTs(now);

			dcFormService.saveOrUpdate(dcForm);
			logger.debug("DcForm added");
		} else {
			int count = 0;
			for (DcForm dcForm : dcForms) {
				logger.debug("Updating DCForm with dmsFormId: " + (dmsFormId != null ? dmsFormId : ""));
				dcForm.setDcDocument(dcDocument);
				dcForm.setFormId(dmsFormId);
				dcForm.setFormStatus(AppConstants.DOCUMENT_STATUS_DISTRIBUTED);
				dcForm.setTransferredDate(now);
				dcForm.setModifiedBy(AppConstants.EDOCS_DMS_USER);
				dcForm.setModifiedTs(now);
				dcFormService.saveOrUpdate(dcForm);
				count++;
			}

			logger.debug(count + " forms Updated");
		}

		logger.debug("Exited updateForms method");
	}

	@Override
	public String getvaultIndicator(String docName, String formType, String vaultDocId) {

		logger.debug("Entered getvaultIndicator(String docName, String formType, String vaultDocId) method");
		if ("eForm".equalsIgnoreCase(formType) && null != vaultDocId && !vaultDocId.isEmpty()) {
			return "Y";
		} else if ("eForm".equalsIgnoreCase(formType) && (vaultDocId == null || vaultDocId.isEmpty())) {
			return "NA";
		} else {
			return "N";
		}
	}

	@Override
	public String getApplicationType(Document inboundXml) throws Exception {

		logger.debug("Entered getApplicationType method");
		String applicationType = "";

		applicationType = EdocsXmlUtils.getTextFromXpath(inboundXml, XMLConstants.starApplicationTypePath);

		return applicationType;
	}

	@Override
	public void updateDealLatestDistributionStatus(String deDealId, String distSequenceId) {

		logger.debug("Entered updateDealLatestDistributionStatus(String deDealId, String distSequenceId)  method");
		try {
			List<DcDistribution> distributions = disributionService.find(deDealId);

			if (distributions.size() > 0) {
				DcDistribution lastDistribution = distributions.get(0);
				if (lastDistribution.getId().getSequenceId().equals(distSequenceId)) {
					// Update DE_DEAL LATEST_DISTRIBUTION_STATUS as Reviewed
					DeDeal deDeal = dealService.getByDeDealId(deDealId);
					if (null != deDeal) {
						deDeal.setLatestDistributionStatus(AppConstants.DIST_STATUS_REVIEWED);
						deDeal.setDistributionTs(new Date());
						dealService.saveOrUpdate(deDeal);
						logger.info("Deal latest distribution status updated to 'Reviewed'");
					}
				}
			}
		} catch (Exception e) {
			logger.error("An error occured while updating latest distribution status in DE_DEAL: ", e);
		}
	}

	@Override
	public boolean updateReadyToBookAndReviewedFlagForDistribution(String deDealId, String distSequenceId,
			boolean distributionReviewed, String readyToBook, String modifiedBy) {

		logger.debug("Entered updateReadyToBookAndReviewedFlagForDistribution method");
		try {
			if (!distributionReviewed) {
				logger.info(
						"There are still documents waiting for review for the distribution: {}, hence *not* updating distribution status as 'Reviewed'",
						deDealId + distSequenceId);
			}
			DcDistribution dcDistribution = disributionService.find(deDealId, distSequenceId);
			if (null != dcDistribution) {
				if (distributionReviewed) {
					dcDistribution.setDist_status(AppConstants.DIST_STATUS_REVIEWED);
				}
				dcDistribution.setModifiedBy(extractUserName(modifiedBy));
				dcDistribution.setModifiedTs(getCurrentTime());
				dcDistribution.setReadyToBook(readyToBook);
				disributionService.saveOrUpdate(dcDistribution);
				logger.info("Distribution status and ready to book flags updated");

				// Update DE_DEAL LATEST_DISTRIBUTION_STATUS as Reviewed, if
				// this distribution is the latest one
				updateDealLatestDistributionStatus(deDealId, distSequenceId);
				return true;
			}
			return false;
		} catch (Exception e) {
			logger.error("An error occured while updating ready to book flag for distribution: ", e);
		}
		return false;
	}

	// Get user name from an email id
	@Override
	public String extractUserName(String userEmail) {
		if (null != userEmail) {
			int index = userEmail.indexOf("@");
			String userName = index != -1 ? userEmail.substring(0, index) : userEmail;
			return userName;
		}
		return null;
	}

	// Get current time stamp
	@Override
	public Timestamp getCurrentTime() {
		Calendar calendar = Calendar.getInstance();
		Date now = calendar.getTime();
		return new Timestamp(now.getTime());
	}

	@Override
	public boolean updateFormCompleteAndReviewedFlagForDocument(Integer dcDocumentId, String formComplete,
			String modifiedBy) {

		logger.debug("Entered updateFormCompleteAndReviewedFlagForDocument method");
		try {
			DcDocument dcDocument = dcDocumentService.getDcDocument(dcDocumentId);
			if (null != dcDocument) {
				dcDocument.setFormComplete(formComplete);
				dcDocument.setModifiedBy(extractUserName(modifiedBy));
				dcDocument.setModifiedTs(getCurrentTime());
				dcDocument.setDocStatus(AppConstants.DOC_STATUS_REVIEWED);
				dcDocumentService.saveOrUpdate(dcDocument);
				logger.info("Document status and form complete flags updated");
				return true;
			}
			return false;
		} catch (Exception e) {
			logger.error("An error occured while updating form complete flag: ", e);
		}
		return false;

	}

	@Override
	public DeLender getLender(String lenderId) throws Exception, ApplicationException {

		// Find the correct lender based on the incoming lender Id
		// If the incoming Id is of a partner, look up DE_LENDER_PARTNER table
		// to find correct parent lender id
		DeLender lender = deLenderService.findByLenderId(lenderId);
		if (lender == null) {
			DeLenderPartner deLenderPartner = deLenderPartnerService.getByPartnerId(lenderId);
			if (null != deLenderPartner) {
				lender = deLenderService.findByLenderId(deLenderPartner.getLenderId());
				if (null == lender) {
					logger.error("No record in DeLender table for lender:{}", deLenderPartner.getLenderId());
					throw new ApplicationException(new ErrorDetail(AppConstants.DE_LENDER_NOT_FOUND_MESSAGE,
							AppConstants.DE_LENDER_NOT_FOUND_CODE));
				}
			} else {
				logger.error("No record in DeLenderPartner table for lender:{}", lenderId);
				throw new ApplicationException(new ErrorDetail(AppConstants.DE_LENDER_NOT_FOUND_MESSAGE,
						AppConstants.DE_LENDER_NOT_FOUND_CODE));
			}
		}
		return lender;
	}

	@Override
	public List<String> encryptedXmlwithKeyId(String xml) {
		List<String> encryptedXmlwithKeyId = new ArrayList<String>();
		try {
			// get encrypted data along with the key Id
			encryptedXmlwithKeyId = servicesImpl.encryptText(xml);
		} catch (Exception e) {
			logger.warn("error encrypting xml", e);
			logger.debug("WARNING: error encrypting xml", e);
		}
		return encryptedXmlwithKeyId;
	}

	@Override
	public String determineSequenceId(final List<DcDistribution> distributions) throws Exception {
		logger.debug("Entered determineSequenceId method");
		String newSequenceId = "";
		if (distributions == null || distributions.isEmpty()) {
			newSequenceId = AppConstants.DISTRIBUTION_SEQUENCE_PREFIX + "01";
			logger.debug("no distributions exist for this deal, setting sequence at 01");
		} else {
			logger.debug(distributions.size()
					+ " distributions for this deal exist - determining largest existing sequence");
			final String sequenceId = distributions.get(0).getId().getSequenceId();
			logger.debug("SequenceId of the most recent distribution: " + sequenceId);
			if (StringUtils.isNotBlank(sequenceId)) {
				try {
					int sequence = Integer.parseInt(sequenceId.trim().substring(2));
					newSequenceId = AppConstants.DISTRIBUTION_SEQUENCE_PREFIX
							+ sequenceNumberFormat.format(sequence + 1);
				} catch (Exception e) {
					logger.error(e);
					throw new ApplicationException("Error parsing sequnceId to int");
				}
			}

		}
		logger.debug("Exit determineSequenceId method. New sequenceId: " + newSequenceId);
		return newSequenceId;
	}

	/**
	 * @param financeTypeIn
	 * @return
	 */
	@Override
	public String convertFinanceType(final String financeTypeIn) {
		logger.debug("Entering ConvertFinanceType(final String financeTypeIn) method > financeTypeIn: {}", financeTypeIn);
		String financeType = "";

		if ("1".equals(financeTypeIn)) {
			financeType = "R";
		} else if ("2".equals(financeTypeIn)) {
			financeType = "L";
		} else if ("3".equals(financeTypeIn)) {
			financeType = "B";
		} else financeType = financeTypeIn;
		return financeType;
	}

	/**
	 * @param deal
	 * @return
	 * @throws Exception
	 */
	@Override
	public String determineVaultIndicator(final DeDeal deal) throws Exception {
		logger.debug("Entering determineVaultIndicator(final DeDeal deal) method");
		String vaultIndicator = "NA";
		if (AppConstants.DSP_REYNOLDS.equals(deal.getDmsId()) || AppConstants.DSP_ADVENT.equals(deal.getDmsId())) {
			VaultRegisterDocument vaultDocRecord = vaultRegisterDocumentService.findVaultDocId(deal.getDmsDealerId(),
					deal.getDmsDealNum());
			if (vaultDocRecord == null) {
				vaultIndicator = "N";
			} else {
				String vaultDocId = vaultDocRecord.getDocumentId();
				if (null != vaultDocId && !vaultDocId.isEmpty()) {
					if (null != deal.getEconStatus() && deal.getEconStatus().equalsIgnoreCase("Assigned")) {
						vaultIndicator = "Y";
					} else {
						vaultIndicator = "N";
					}
				} else {
					vaultIndicator = "N";
				}
			}
		}
		return vaultIndicator;
	}

	@Override
	public Boolean resumeDistribution(DistributionHelper request) {

		logger.debug("Entered resumeDistribution(DistributionHelper request) method");
		try {
			ErrorDetail errorDetail = new ErrorDetail();
			errorDetail.setTransactionType("EYE_ON_DOC_RESUME");
			prepareDistributionUtil.prepareDistributionForCompletion(request, new Date(), errorDetail);
		} catch (Exception e) {
			logger.error("An error occured while distributing the pending distribution. ", e);
			return false;
		}
		return true;

	}

	@Override
	public Document getDocumentFromCreditJournal(final CreditJournal creditJournal)
			throws ApplicationException, Exception {

		logger.debug("Enter getDocumentFromCreditJournal");
		String docString = "";
		try {
			docString = EncryptionUtils.decryptText(creditJournal.getCrDataXml(), creditJournal.getEncryptionKeyId());
		} catch (Exception e) {
			logger.error("could not decrypt xml", e);
			throw new ApplicationException(creditJournal.getDealerId(), e, AppConstants.DECRYPT_ECOUT_FAILED_CODE);
		}
		Document doc = EdocsXmlUtils.getDocumentFromString(docString);
		return doc;
	}

	@Override
	public boolean isFeatureEnabled(List<DeLenderFeature> lenderFeatures, String feature) {
		logger.debug("Enter isFeatureEnabled");

		if (lenderFeatures != null && !lenderFeatures.isEmpty()) {
			for (DeLenderFeature lenderFeature : lenderFeatures) {
				if (lenderFeature.getFeatureId() != null && lenderFeature.getFeatureId().equalsIgnoreCase(feature)) {
					return true;
				}
			}
		}

		return false;
	}
}
