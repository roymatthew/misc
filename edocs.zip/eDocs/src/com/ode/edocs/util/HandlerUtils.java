package com.ode.edocs.util;

import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PRStream;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStream;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.ode.edocs.File;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.vo.DistributionPacket;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.function.Predicate;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.ElementFilter;
import org.xml.sax.InputSource;

public class HandlerUtils {

    private static final Logger logger = LogManager.getLogger(HandlerUtils.class);

    private static Namespace dig = Namespace.getNamespace("dig", "http://www.opendealerexchange.com/DigitalDeal");
    private static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");
    private static Namespace soaptrans = Namespace.getNamespace("soaptrans",
        "http://www.starstandards.org/webservices/2005/10/transport");
    private static Namespace ns = Namespace.getNamespace("ns", "http://www.cdk.com/DC/DealData/");
    private static List<Namespace> namespaces = Arrays.asList(star, soaptrans, dig, ns);

    /**
     * @param file
     * @return
     * @throws Exception
     */
    public static String getFormattedFileName(final File file) throws Exception {
        logger.debug("Entered method getFormattedFileName(File file)");

        if (file == null) {
            return null;
        }
        // set File extension
        int i = file.getFilename().lastIndexOf(".");
        file.setFileExtension(file.getFilename().substring(i + 1));

        int hyphenLocation = file.getFilename().indexOf("-") + 1;
        if (hyphenLocation > 0) { // hyphen exists
            // Check if the text before dash is doc ID. If not, keep it because
            // it will be part of doc name.
            boolean docIdPrefixExists = true;
            try {
                String textBeforeHyphen = file.getFilename().substring(0, hyphenLocation - 1);
                Integer.parseInt(textBeforeHyphen);
            } catch (NumberFormatException e) {
                logger.debug("could not parse to number", e);
                docIdPrefixExists = false;
            }
            if (!docIdPrefixExists) {
                hyphenLocation = 0;
            }
        }

        String formattedFileName = file.getFilename().substring(hyphenLocation);
        if (formattedFileName.contains(".")) {
            formattedFileName = formattedFileName.substring(0, formattedFileName.lastIndexOf('.'));
        }
        file.setFormattedFileName(formattedFileName);
        return formattedFileName;
    }

    /**
     * Returns the actual DMS document name came from DMS without .pdf extension.
     *
     * @param file
     * @return
     * @throws Exception
     */
    public static String getDMSDocName(final File file) throws Exception {
        logger.debug("Entered method getDMSDocName(File file)");
        if (file == null) {
            return null;
        }
        String fileName = file.getFilename();
        if (fileName.contains(".")) {
            fileName = fileName.substring(0, fileName.lastIndexOf('.'));
        }
        return fileName;
    }

    /**
     * @param file
     * @return
     * @throws Exception
     */
    public static String getDocumentName(final File file) throws Exception {
        logger.debug("Entered method getDocumentName(File file)");

        String documentName = "";

        if (null != file) {
            if (null != file.getDmsDocType() && null != file.getDmsDocType().getDcDocType()
                && null != file.getDmsDocType().getDcDocType().getName()
                && !file.getDmsDocType().getDcDocType().getName().equalsIgnoreCase(AppConstants.DOC_NAME_OTHER)) {
                documentName = file.getDmsDocType().getDcDocType().getName();
            } else if (null != file.getFilename()) {
                documentName = file.getFilename();
            }

            if (documentName.contains(".")) {
                documentName = documentName.substring(0, documentName.lastIndexOf("."));
            }

            int hyphenLocation = documentName.indexOf("-") + 1;
            if (hyphenLocation > 0) { // hyphen exists
                // Check if the text before dash is doc ID. If not, keep it
                // because it will be part of doc name.
                boolean docIdPrefixExists = true;
                try {
                    String textBeforeHyphen = documentName.substring(0, hyphenLocation - 1);
                    Integer.parseInt(textBeforeHyphen);
                } catch (NumberFormatException e) {
                    logger.debug("could not parse to number", e);
                    docIdPrefixExists = false;
                }
                if (!docIdPrefixExists) {
                    hyphenLocation = 0;
                }
            }
            documentName = documentName.substring(hyphenLocation);
        }

        // For MB Dealer Product 1, Dealer Product 2 ....Dealer Product 10
        // should be sent as Dealer Product
        if (documentName.startsWith(AppConstants.DOC_NAME_DEALER_PRODUCT)) {
            return AppConstants.DOC_NAME_DEALER_PRODUCT;
        }

        return documentName;
    }

    /**
     * @param document
     * @return
     * @throws Exception
     */
    public static List<DistributionHelper> getDistributionDataFromNodes(final Document document) throws Exception {
        logger.debug("Entered method getDistributionDataFromNodes(Document document)");

        Element rootNode = document.getRootElement();
        List<Element> distributions = rootNode.getChildren("Distribution");
        List<DistributionHelper> distHelpers = new ArrayList<DistributionHelper>();

        for (Element distribution : distributions) {
            DistributionHelper distHelper = new DistributionHelper();
            Element dealIdElement = distribution.getChild("DealId");
            Element sequenceIdElement = distribution.getChild("SequenceId");

            distHelper.setDeDealId(dealIdElement.getText());
            distHelper.setSequenceId(sequenceIdElement.getText());

            distHelpers.add(distHelper);
        }

        return distHelpers;
    }

    /**
     * @param msgToSend
     * @return
     * @throws Exception
     */
    public static InputStreamRequestEntity getRequestEntity(String msgToSend) throws Exception {
        logger.debug("Entered method getRequestEntity(String msgToSend) ");
        InputStreamRequestEntity requestEntity = null;
        if (null != msgToSend && msgToSend.trim().length() != 0) {
            ByteArrayInputStream bais = new ByteArrayInputStream(msgToSend.getBytes());
            requestEntity = new InputStreamRequestEntity(bais, InputStreamRequestEntity.CONTENT_LENGTH_AUTO, null);
        }
        return requestEntity;
    }

    /**
     * Returns a org.w3c.dom.Document.
     *
     * @param xmlString
     * @return
     * @throws Exception
     */
    public static org.w3c.dom.Document getDocument(final String xmlString) throws Exception {
        logger.debug("Entered method getDocument(String xmlString)");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(xmlString));
        org.w3c.dom.Document doc = dBuilder.parse(is);
        doc.getDocumentElement().normalize();

        return doc;
    }

    /**
     * @param fields
     * @param metaDataFieldExpression
     * @return
     */
    public static String findFieldXPathForExpression(final List<DcDocField> fields,
        final String metaDataFieldExpression) {
        logger.debug("Entered method findFieldXPathForExpression()");
        if (null != fields && !fields.isEmpty()) {
            for (DcDocField field : fields) {
                if (field.getFieldName().equalsIgnoreCase(metaDataFieldExpression)) {
                    return field.getXpath();
                }
            }
        }
        return null;
    }

    /**
     * @param storedMetaData
     * @param fieldName
     * @return
     */
    public static String findStoredValueForExpression(final List<DcDocData> storedMetaData, final String fieldName) {
        logger.debug("Entered method findStoredValueForExpression()");
        for (DcDocData storedMetaDatum : storedMetaData) {
            if (storedMetaDatum.getDataName().equalsIgnoreCase(fieldName)) {
                return storedMetaDatum.getDataValue();
            }
        }
        return null;
    }

    /**
     * @param lenderDest
     * @return
     */
    public static boolean doesHeaderSecurityExist(final DeLenderDestination lenderDest) {
        logger.debug("Entered method doesHeaderSecurityExist()");
        String userName = null;
        String password = null;
        
        if (lenderDest != null) {
        	userName = lenderDest.getWs_username();;
        	password = lenderDest.getWs_password();
        } else {
        	logger.debug("No lender destination record");
        }

        if (null != userName && !userName.isEmpty() && null != password && !password.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * @param files
     * @return
     * @throws Exception
     */
    public static boolean leaseWorksheetExists(final List<File> files) throws Exception {
        logger.debug("Entered method leaseWorksheetExists()");
        for (File file : files) {
            if (file.getFilename().endsWith(".pdf")) {
                String formattedFileName = HandlerUtils.getFormattedFileName(file);
                if (AppConstants.DOC_NAME_LEASE_WORKSHEET.equalsIgnoreCase(formattedFileName)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param metaDataFieldExpression
     * @param fields
     * @param file
     * @return
     * @throws Exception
     */
    public static String getAncillaryValueFromFile(final String metaDataFieldExpression, final List<DcDocField> fields,
        File file) throws Exception {
        logger.debug("Entered method getAncillaryValueFromFile()");
        String ancillaryFieldValue = null;

        if (metaDataFieldExpression.contains(",")) {
            String[] metaDataFieldNames = metaDataFieldExpression.split(",");
            StringBuilder sb = new StringBuilder("");
            String metaDataFieldValue = null;
            for (String metaDataFieldName : metaDataFieldNames) {
                String metaDataFieldXpath = "";

                // loop through dcDocFields here, find the field that matches
                // the metaDataFieldName. take the xpath of that field. use it
                // to lookup the value in the ancillary xml.
                metaDataFieldXpath = findFieldXPathForExpression(fields, metaDataFieldName);
                if (null != metaDataFieldXpath && !metaDataFieldXpath.isEmpty()) {
                    metaDataFieldValue = evaluateExpression(file.getAncillaryData(), metaDataFieldXpath);
                    if (null != metaDataFieldValue) {
                        if (sb.length() > 0) {
                            sb.append(" ");
                        }
                        sb.append(metaDataFieldValue);
                    }
                }
            }
            if (sb.length() > 0) {
                ancillaryFieldValue = sb.toString();
            }
        } else {
            String metaDataFieldXpath = "";

            // loop through dcDocFields or deDataElements here, find the field
            // that matches the metaDataFieldExpression. take the xpath of that
            // field. use it to lookup the value in the ancillary xml.
            metaDataFieldXpath = findFieldXPathForExpression(fields, metaDataFieldExpression);
            if (null != metaDataFieldXpath && !metaDataFieldXpath.isEmpty() && null != file.getAncillaryData()) {
                ancillaryFieldValue = evaluateExpression(file.getAncillaryData(), metaDataFieldXpath);
            }
        }

        return ancillaryFieldValue;
    }

    /**
     * @param metaDataFieldExpression
     * @param dcDocData
     * @return
     * @throws Exception
     */
    public static String getLatestAncillaryValue(final String metaDataFieldExpression, final List<DcDocData> dcDocData)
        throws Exception {
        logger.debug("Entered method getDocumentFromString(String xml)");
        String ancillaryFieldValue = null;

        if (metaDataFieldExpression.contains(",")) {
            String[] metaDataFieldNames = metaDataFieldExpression.split(",");
            logger.info(Arrays.toString(metaDataFieldNames));
            StringBuilder sb = new StringBuilder("");
            for (String metaDataFieldName : metaDataFieldNames) {
                Predicate<DcDocData> predicate = p -> p.getDataName().equals(metaDataFieldName);
                DcDocData ancillaryData = dcDocData.stream().filter(predicate).findFirst().orElse(null);

                if (null != ancillaryData) {
                    if (sb.length() > 0) {
                        sb.append(" ");
                    }
                    sb.append(ancillaryData.getDataValue());
                }
            }
            if (sb.length() > 0) {
                ancillaryFieldValue = sb.toString();
            }
        } else {
            Predicate<DcDocData> predicate = p -> p.getDataName().equals(metaDataFieldExpression);
            DcDocData ancillaryData = dcDocData.stream().filter(predicate).findFirst().orElse(null);
            if (null != ancillaryData) {
                ancillaryFieldValue = ancillaryData.getDataValue();
            }
        }
        return ancillaryFieldValue;
    }

    /**
     * @param fieldExpression
     * @param storedMetaData
     * @return
     * @throws Exception
     */
    public static String getStoredAncillaryValue(final String fieldExpression, final List<DcDocData> storedMetaData)
        throws Exception {
        logger.debug("Entered method getStoredAncillaryValue()");
        String storedValue = null;

        if (fieldExpression.contains(",")) {
            String[] fieldNames = fieldExpression.split(",");
            StringBuilder sb = new StringBuilder("");
            String partialStoredValue = null;
            for (String fieldName : fieldNames) {
                partialStoredValue = findStoredValueForExpression(storedMetaData, fieldName);
                if (null != partialStoredValue) {
                    if (sb.length() > 0) {
                        sb.append(" ");
                    }
                    sb.append(partialStoredValue);
                }
            }
            if (sb.length() > 0) {
                storedValue = sb.toString();
            }
        } else {
            storedValue = findStoredValueForExpression(storedMetaData, fieldExpression);
        }

        return storedValue;
    }

    /**
     * @param document
     * @param expression
     * @return
     * @throws Exception
     */
    public static String evaluateExpression(Document document, String expression) throws Exception {
        logger.debug("Entered method evaluateExpression()");
        String result = "";
        
        if (null != document) {
	        if (expression.startsWith("//")) {
	            result = EdocsXmlUtils.getTextFromXpath(document, expression);
	        } else {
	            result = EdocsXmlUtils.getTextFromXpathFunction(document, expression);
	        }
        }

        return result;
    }

    /**
     * @param document
     * @param nvpElementName
     * @param name
     * @return
     * @throws Exception
     */
    public static String getNVPTextFromXpath(Document document, String nvpElementName, String name) throws Exception {
        logger.debug("Entered method getNVPTextFromXpath()");
        if (document == null) {
            logger.warn("Document is null.");
            return "";
        }

        String nvpValue = "";
        Element root = document.getRootElement();
        ElementFilter nvpFilter = new ElementFilter(nvpElementName);
        for (Element nvpElement : root.getDescendants(nvpFilter)) {
            Element nameElement = nvpElement.getChild("Name");

            if (null != nameElement && null != nameElement.getText()) {
                String nvpName = nameElement.getText().trim();
                if (name.equalsIgnoreCase(nvpName)) {
                    Element valueElement = nvpElement.getChild("Value");

                    if (null != valueElement && null != valueElement.getText()) {
                        nvpValue = valueElement.getText().trim();
                    }
                }
            }
        }

        if (nvpValue.isEmpty()) {
            logger.debug("{} not found", nvpElementName);
        }

        logger.trace("Entry: " + nvpElementName + ", Exit: " + nvpValue);
        return nvpValue;
    }

    /**
     * @param fieldValue
     * @param fieldType
     * @param dmsId
     * @return
     */
    public static String formatFieldValue(final String fieldValue, final String fieldType, final String dmsId) {
        logger.debug("Entered method formatFieldValue()");
        String formattedFieldValue = fieldValue;
        // if type is date, convert format before doing the comparison
        if (fieldType == null || fieldType.trim().isEmpty()) {
            return formattedFieldValue;
        } else if (AppConstants.FIELD_TYPE_DATE.equalsIgnoreCase(fieldType)) {
            String pattern = "";
            if (AppConstants.DSP_ADP.equalsIgnoreCase(dmsId)) {
                pattern = AppConstants.DSP_ADP_DATE_FORMAT;
            } else if (AppConstants.DSP_REYNOLDS.equalsIgnoreCase(dmsId)) {
                pattern = AppConstants.DSP_REYNOLDS_DATE_PATTERN;
            }

            DateFormat fromDF = new SimpleDateFormat(pattern);
            DateFormat toDF = new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date formatDate = fromDF.parse(fieldValue);
                formattedFieldValue = toDF.format(formatDate);
            } catch (Exception e) {
            	logger.error("Error formatting date: " + (fieldValue != null ? fieldValue : "null"));
                return null;
            }
        }
        return formattedFieldValue;
    }

    /**
     * 
     * @param attachmentFileLocation
     * @param fileSizeLimit
     * @param checkFileSize
     * @return
     */
    public static DistributionPacket removeAncillaryXmlFromAttachment(final String attachmentFileLocation, final String fileSizeLimit, final boolean checkFileSize) {
        logger.debug("removeAncillaryXmlFromAttachment(attachmentFileLocation: {}, fileSizeLimit: {}, checkFileSize: {})", attachmentFileLocation, fileSizeLimit, checkFileSize);
        DistributionPacket distributionPacket = new DistributionPacket();
        int BUFFER = 2048;
        byte data[] = new byte[BUFFER];
        ByteArrayOutputStream bout = new ByteArrayOutputStream(2048);
        ZipOutputStream zout = new ZipOutputStream(bout);
        StringBuffer errorMessage = new StringBuffer();
        try {
            java.io.File attachedFile = new java.io.File(attachmentFileLocation);
            ZipFile zf = new ZipFile(attachedFile);
            final Enumeration<? extends ZipEntry> entries = zf.entries();
            while (entries.hasMoreElements()) {
                final ZipEntry zipEntry = entries.nextElement();
                boolean isAncillaryXml = false;
                InputStream is = zf.getInputStream(zipEntry);
                String fileName = zipEntry.getName();
                if (fileName.toLowerCase().endsWith(".xml")) {
                    isAncillaryXml = true;
                }
                long fileSize = zipEntry.getSize();
                double fileSizeInMB = fileSize / (double) (1024 * 1024);
                logger.debug(">> File name: {}, Size: [{} bytes, {} MB], isAncillaryXML: {}", fileName, fileSize, fileSizeInMB, isAncillaryXml);
                if (!isAncillaryXml) {
                	if (checkFileSize && (fileSizeInMB > Double.parseDouble(fileSizeLimit))) {
                		logger.debug(">>>> '{}' exceeded size of {} MB", fileName, fileSizeLimit);
                        errorMessage.append(new StringBuffer(fileName).append(AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE2).append(fileSizeLimit).append(AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE3).append(",").toString());
                    }
                    ZipEntry zipEntryOut = new ZipEntry(zipEntry.getName());
                    zout.putNextEntry(zipEntryOut);
                    int count;
                    while ((count = is.read(data, 0, BUFFER)) != -1) {
                        zout.write(data, 0, count);
                    }
                    is.close();
                }
            }
        } catch (Exception e) {
            logger.error("Error in HandlerUtils.removeAncillaryXmlFromAttachment(): ", e);
        } finally {
        	if (zout != null) {
        		try {
					zout.close();
				} catch (IOException e) {
					logger.error("Error in closing ZIP out stream", e);
				}
        	}
        	if (bout != null) {
        		try {
        			bout.close();
				} catch (IOException e) {
					logger.error("Error in closing Byte out stream", e);
				}
        	}
        }
        if (!"".equals(errorMessage) && errorMessage.length() > 0) {
            errorMessage.deleteCharAt(errorMessage.length() - 1);
        }
        distributionPacket.setFileCheckError(errorMessage.toString());
        distributionPacket.setData(bout.toByteArray());
        return distributionPacket;
    }
    
    /**
     * Look for each file size in zip file and create error message if it violates specified size
     * @param attachmentFileLocation
     * @param fileSizeLimit
     * @return
     */
    public static StringBuffer fileSizeExceeded(final String attachmentFileLocation, String fileSizeLimit) {
    	logger.debug("fileSizeExceeded(attachmentFileLocation: {}, fileSizeLimit: {})", attachmentFileLocation, fileSizeLimit);
    	StringBuffer errorMessage = new StringBuffer();
    	int BUFFER = 2048;
        byte data[] = new byte[BUFFER];
        ByteArrayOutputStream bout = new ByteArrayOutputStream(2048);
        ZipOutputStream zout = new ZipOutputStream(bout);
    	try {
    		java.io.File attachedFile = new java.io.File(attachmentFileLocation);
            ZipFile zf = new ZipFile(attachedFile);
            final Enumeration<? extends ZipEntry> entries = zf.entries();
            while (entries.hasMoreElements()) {
            	final ZipEntry zipEntry = entries.nextElement();
            	InputStream is = zf.getInputStream(zipEntry);
                String fileName = zipEntry.getName();
                long fileSize = zipEntry.getSize();
                double fileSizeInMB = fileSize / (double) (1024 * 1024);
                logger.debug(">> File name: {}, Size: [{} bytes, {} MB]", fileName, fileSize, fileSizeInMB);
                if (fileName.toLowerCase().endsWith(".pdf")) {
                	if (fileSizeInMB > Double.parseDouble(fileSizeLimit)) {
                		logger.debug(">>>> '{}' exceeded size of {} MB", fileName, fileSizeLimit);
                        errorMessage.append(new StringBuffer(fileName).append(AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE2).append(fileSizeLimit).append(AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE3).append(",").toString());
                	}
                }
            }
    	} catch(Exception e) {
    		logger.error("Error in HandlerUtils.fileSizeExceeded(): ", e);
    	} finally {
        	if (zout != null) {
        		try {
					zout.close();
				} catch (IOException e) {
					logger.error("Error in closing ZIP out stream", e);
				}
        	}
        	if (bout != null) {
        		try {
        			bout.close();
				} catch (IOException e) {
					logger.error("Error in closing Byte out stream", e);
				}
        	}
        }
    	if (!"".equals(errorMessage) && errorMessage.length() > 0) {
            errorMessage.deleteCharAt(errorMessage.length() - 1);
        }
        return errorMessage;
    }

    /**
     * @param bytes
     * @param fileSizeLimit
     * @return
     */
    public static StringBuffer fileSizeExceeded(byte[] bytes, String fileSizeLimit) {
        ZipEntry zipEntry = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ZipInputStream zipInStream = new ZipInputStream(bis);
        StringBuffer errorMessage = new StringBuffer();
        try {
            while (null != (zipEntry = zipInStream.getNextEntry())) {
                String fileName = zipEntry.getName();
                if (fileName.toLowerCase().endsWith(".pdf")) {
                    long fileSize = zipEntry.getSize();
                    logger.info("---------------------------");
                    logger.info("File name: {}", fileName);
                    logger.info("File size: {}", fileSize);
                    double fileSizeInMB = fileSize / (double) (1024 * 1024);
                    if (fileSizeInMB > Double.parseDouble(fileSizeLimit)) {
                        errorMessage.append(fileName + AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE2 + fileSizeLimit
                            + AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE3 + ",");
                    }
                    logger.info("File size in MB : {}", fileSizeInMB);
                }
            }
        } catch (Exception e) {
            logger.error("Error in HandlerUtils.processFileSize(): ", e);
        }
        if (!"".equals(errorMessage) && errorMessage.length() > 0) {
            errorMessage.deleteCharAt(errorMessage.length() - 1);
        }
        return errorMessage;
    }

    /**
     * @param bytes
     * @param fileResolutionLimit
     * @return
     */
    public static StringBuffer checkFileResolution(byte[] bytes, int fileResolutionLimit) {
        ZipEntry zipEntry = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ZipInputStream zipInStream = new ZipInputStream(bis);
        StringBuffer errorMessage = new StringBuffer();
        boolean isScannedPdf = false;

        try {
            while (null != (zipEntry = zipInStream.getNextEntry())) {
                String fileName = zipEntry.getName();
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                int data = zipInStream.read();

                while (data != -1) {
                    output.write(data);
                    data = zipInStream.read();
                }
                byte[] zipEntryByteArray = output.toByteArray();
                logger.info("---------------------------");
                logger.info("File name: {}", fileName);

                if (fileName.toLowerCase().endsWith(".pdf")) {
                    PdfReader chartReader = new PdfReader(zipEntryByteArray);
                    isScannedPdf = processScannedPdf(chartReader, fileName);
                    if (!zipEntry.isDirectory() && fileName.toLowerCase().endsWith(".pdf") && isScannedPdf) {
                        for (int i = 0; i < chartReader.getXrefSize(); i++) {
                            PdfObject pdfobj = chartReader.getPdfObject(i);
                            if (null != pdfobj && pdfobj.isStream()) {
                                PdfStream stream = (PdfStream) pdfobj;
                                PdfObject pdfsubtype = stream.get(PdfName.SUBTYPE);
                                if (null != pdfsubtype && pdfsubtype.toString().equals(PdfName.IMAGE.toString())) {
                                    byte[] image = PdfReader.getStreamBytesRaw((PRStream) stream);
                                    int width = Integer.parseInt(stream.get(PdfName.WIDTH).toString());
                                    int height = Integer.parseInt(stream.get(PdfName.HEIGHT).toString());
                                    logger.info("Height: {}", height);
                                    logger.info("Width: {}", width);
                                    Image imageObject = null;
                                    imageObject = Image.getInstance(image);
                                    if (null != imageObject) {
                                        logger.info("ResolutionX: {}", imageObject.getDpiX());
                                        logger.info("ResolutionY: {}", imageObject.getDpiY());
                                    }
                                    if (imageObject.getDpiX() < fileResolutionLimit
                                        || imageObject.getDpiY() < fileResolutionLimit) {
                                        errorMessage
                                        .append(fileName + AppConstants.FILE_RESOLUTION_INVALID_ERROR_MESSAGE1
                                            + new Integer(fileResolutionLimit).toString()
                                            + AppConstants.FILE_RESOLUTION_INVALID_ERROR_MESSAGE2 + ",");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error in HandlerUtils.checkFileResolution(): ", e);
        }

        if (!"".equals(errorMessage) && errorMessage.length() > 0) {
            errorMessage.deleteCharAt(errorMessage.length() - 1);
        }

        return errorMessage;
    }

    /**
     * @param chartReader
     * @param fileName
     * @return
     * @throws IOException
     */
    public static boolean processScannedPdf(PdfReader chartReader, String fileName) throws IOException {
        boolean isScannedPdf = false;
        for (int i = 1; i <= chartReader.getNumberOfPages(); i++) {
            String text = PdfTextExtractor.getTextFromPage(chartReader, i);
            if (text.equals("")) {
                isScannedPdf = true;
            }
        }
        logger.info("{} is a Scanned Pdf: {}", fileName, isScannedPdf);
        return isScannedPdf;
    }

    /**
     * @param files
     * @return
     */
    public static Document getAncillaryContractDataForVCI(List<File> files) {
        Document ancillaryDataFile = null;
        for (File file : files) {
            String fileName = file.getFilename();

            if ("00001-Contract - Retail.pdf".equalsIgnoreCase(fileName)
                || "00001-Contract - Lease.pdf".equalsIgnoreCase(fileName)
                || "00001-Contract - Balloon.pdf".equalsIgnoreCase(fileName)) {
            	if (null != file.getAncillaryData()) {
            		ancillaryDataFile = file.getAncillaryData();
            	}
                return ancillaryDataFile;
            }
        }
        return ancillaryDataFile;
    }

    /**
     * @param files
     * @return
     */
    public static Document getAncillaryContractData(List<File> files) {
        logger.debug("Entered method getAncillaryContractData(List<File> files)");
        Document ancillaryDataFile = null;
        for (File file : files) {
            String fileName = file.getFilename();

            // RR-Non VCI lenders can have any combination of numbers in front
            // of the Contract.xml.
            // Instead of doing a direct string match, look for a contains on
            // "-Contract".
            if (null != fileName && fileName.contains(AppConstants.CONTRACT_NAME_RR)) {
            	if (null != file.getAncillaryData()) {
            		ancillaryDataFile = file.getAncillaryData();
            	}
                return ancillaryDataFile;
            }
        }

        return ancillaryDataFile;
    }

    /**
     * @param document
     * @return
     * @throws Exception
     */
    public static String getVaultDocId(Document document) throws Exception {
        logger.debug("Entered method getVaultDocId(Document document)");
        String vaultDocId = "";

        vaultDocId = EdocsXmlUtils.getTextFromXpath(document, XMLConstants.starDocumentIdpath);
        logger.info("Vault Doc Id:{} ", vaultDocId);

        return vaultDocId;
    }

    /**
     * @param inboundXml
     * @param file
     * @param dmsId
     * @return
     * @throws Exception
     */
    public static String getFormType(Document inboundXml, File file, String dmsId) throws Exception {
        logger.debug("Entered method getFormType(Document inboundXml, File file, String dmsId)");
        String fileName = file.getFilename();
        String formType = "";
        if (fileName.contains(".")) {
            fileName = fileName.substring(0, fileName.lastIndexOf("."));
        }
        if (AppConstants.DSP_ADP.equals(dmsId)) {
            formType = EdocsXmlUtils.getTextFromXpath(inboundXml,
                XMLConstants.starContractDocNamePath + fileName + "']/star:AttributeValue");
            if (null != formType && !formType.equals("")) {
                formType = formType.substring(formType.lastIndexOf(":") + 1);
                if (formType.equalsIgnoreCase("eform")) {
                    file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                    file.seteForm(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                } else if (formType.equalsIgnoreCase("esigned")) {
                    file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                    file.seteForm(AppConstants.ATTACHMENT_ESIGNED_FALSE);
                }
            }
        } else if (AppConstants.DSP_REYNOLDS.equals(dmsId)) {
            if (null == file.getAncillaryData()) {
                formType = "scanned";
            } else {
                file.seteForm(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                String eSigned = HandlerUtils.evaluateExpression(file.getAncillaryData(),
                    XMLConstants.ancillaryFormPath);
                if (eSigned.equals("true")) {
                    formType = "eSigned";
                    file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                } else {
                    formType = "eForm";
                    file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_FALSE);
                }
            }
        } else if (AppConstants.DSP_ADVENT.equals(dmsId)) {
            if (null == file.getAncillaryData()) {
                formType = "scanned";
            } else {
                file.seteForm(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                String eSigned = HandlerUtils.evaluateExpression(file.getAncillaryData(),
                    XMLConstants.ancillaryFormPath);
                if (eSigned.equals("true")) {
                    formType = "eSigned";
                    file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_TRUE);
                } else {
                    formType = "eForm";
                    file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_FALSE);
                }
            }
        }
        if (formType.equals("scanned") || formType.equals("")) {
            file.seteForm(AppConstants.ATTACHMENT_ESIGNED_FALSE);
            file.seteSigned(AppConstants.ATTACHMENT_ESIGNED_FALSE);
        }
        return formType;
    }

}
