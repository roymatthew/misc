package com.ode.edocs.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HttpTransmitUtil {
	private static final Logger logger = LogManager.getLogger(HttpTransmitUtil.class);
	
	private HttpTransmitUtil() {}

	public static String getCurrentDate() {
		return new SimpleDateFormat(AppConstants.DATE_FORMAT).format(new Date());
	}
	
	// Construct RouteOne end point based on contract id and type of distribution
	public static String getFinalRouteOneURL(String baseURL, String contractId, boolean isInitial) {
		String url = baseURL + (contractId != null ? contractId : "") + (isInitial ? AppConstants.URL_APPENDAGE_DISTRIBUTE : AppConstants.URL_APPENDAGE_DISTRIBUTE_ADDENDUM);
		logger.info("RouteOne endpoint >> {}", url);
		return url;
	}
}