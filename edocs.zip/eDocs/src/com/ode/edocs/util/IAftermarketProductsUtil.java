package com.ode.edocs.util;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.vo.BeginCompleteProcessingVO;

public interface IAftermarketProductsUtil {

	public void sendMessageToPEN(final BeginCompleteProcessingVO beginCompleteProcessingVO, DeDeal deDeal);
}