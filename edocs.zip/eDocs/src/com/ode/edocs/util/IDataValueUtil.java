package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeLender;
import java.util.List;
import org.jdom2.Document;

public interface IDataValueUtil {

    /**
     * @param dmsId
     * @param ecout
     * @param file
     * @param dcDocField
     * @param elementField
     * @param lender
     * @param applicationType
     * @param dataElements
     * @return
     * @throws Exception
     */
    public String getDataValue(String dmsId, Document ecout, File file, DcDocField dcDocField,
        DeDataElement elementField, DeLender lender, String applicationType, List<DeDataElement> dataElements)
            throws Exception;

    /**
     * @param field
     * @param lenderDocName
     * @return
     */
    String getDataValueForTypeD(DeDataElement field, String lenderDocName);

    /**
     * @param dataElements
     * @param field
     * @param file
     * @param dcDocData
     * @param dmsId
     * @param lenderSeqNum
     * @return
     */
    String getDataValueForTypeE(List<DeDataElement> dataElements, DeDataElement field, File file,
        List<DcDocData> dcDocData, String dmsId, String lenderSeqNum);

    /**
     * @param file
     * @param lender
     * @param ecout
     * @param currentField
     * @param metaDataField
     * @param dmsId
     * @return
     * @throws Exception
     */
    String evaluateDocumentReviewComparison(File file, DeLender lender, Document ecout, DcDocField currentField,
        DeDataElement metaDataField, String dmsId, boolean matchDataInText) throws Exception;

    /**
     * @param file
     * @param dmsId
     * @param dcDocData
     * @param ecout
     * @param dataElements
     * @param metaDataField
     * @return
     * @throws Exception
     */
    String evaluateDocumentReviewComparisonForAutonomousLender(File file, String dmsId, List<DcDocData> dcDocData,
        Document ecout, List<DeDataElement> dataElements, DeDataElement metaDataField) throws Exception;

    /**
     * @param ecOut
     * @param reviewQuestionDocFields
     * @param dcDocData
     * @param dmsId
     * @param dcDocumentId
     * @throws Exception
     */
    void compareDocDataWithContract(Document ecOut, List<DcDocField> reviewQuestionDocFields, List<DcDocData> dcDocData,
        String dmsId, Integer dcDocumentId) throws Exception;

    /**
     * @param ecOut
     * @param dmsId
     * @param metaDataFieldExpression
     * @param dcDocData
     * @param field
     * @return
     * @throws Exception
     */
    String compareAncillaryVsContract(Document ecOut, String dmsId, String metaDataFieldExpression,
        List<DcDocData> dcDocData, DcDocField field) throws Exception;
}
