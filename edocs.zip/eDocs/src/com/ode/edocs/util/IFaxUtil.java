package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DeDealDAO;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeFaxService;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.rest.entity.FaxRequest;
import com.ode.edocs.rest.entity.FaxResponse;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public interface IFaxUtil {

	public FaxResponse faxDocuments(DeDeal deDeal, FaxRequest faxRequest, DeLenderDestination lenderDest, DeDealDAO deDealDAO);
	
	public String jsonToString(FaxRequest faxRequest);
	
	public FaxRequest createFaxRequest(DeDeal deDeal, List<File> files, String sequenceId, String bodId, String lenderId);
	
	public BigInteger writeFAXIN(Document inDocument, String faxRequest, Date timeStamp, String deDealId, String sequenceId, String transactionId, String accountId) throws Exception;

	DeFaxService getFaxNumber(String lenderId, String transactionType) throws Exception;

}
