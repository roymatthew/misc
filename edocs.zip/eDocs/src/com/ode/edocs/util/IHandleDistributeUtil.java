package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderFeature;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public interface IHandleDistributeUtil {

    /**
     * @param distribution
     * @param files
     * @param lender
     * @param edocOutCjKey
     * @param distStatus
     * @param timeStamp
     * @throws Exception
     */
    public void updateDcDistributionRecord(DcDistribution distribution, List<File> files, DeLender lender,
        BigInteger edocOutCjKey, String distStatus, Date timeStamp) throws Exception;

    /**
     * @param files
     * @param ecOut
     * @throws Exception
     */
    public void processQuestionReview(List<File> files, Document ecOut) throws Exception;

    public String reEvaluateReviewQuestion(File file, Document ecout, DcDocData currentQuestion) throws Exception;

    /**
     * @param dcForms
     * @param dcDocument
     * @param file
     * @param deDealId
     * @param lenderId
     * @throws Exception
     */
    public void updateForms(List<DcForm> dcForms, DcDocument dcDocument, File file, String deDealId, String lenderId)
        throws Exception;

    /**
     * @param docName
     * @param formType
     * @param vaultDocId
     * @return
     */
    public String getvaultIndicator(String docName, String formType, String vaultDocId);

    /**
     * @param inboundXml
     * @return
     * @throws Exception
     */
    public String getApplicationType(Document inboundXml) throws Exception;

    /**
     * @param deDealId
     * @param distSequenceId
     * @param distributionReviewed
     * @param readyToBook
     * @param modifiedBy
     * @return
     */
    public boolean updateReadyToBookAndReviewedFlagForDistribution(String deDealId, String distSequenceId,
        boolean distributionReviewed, String readyToBook, String modifiedBy);

    /**
     * @param dcDocumentId
     * @param formComplete
     * @param modifiedBy
     * @return
     */
    public boolean updateFormCompleteAndReviewedFlagForDocument(Integer dcDocumentId, String formComplete,
        String modifiedBy);

    /**
     * @param deDealId
     * @param distSequenceId
     */
    void updateDealLatestDistributionStatus(String deDealId, String distSequenceId);

    /**
     * @param lenderId
     * @return
     * @throws Exception
     * @throws ApplicationException
     */
    public DeLender getLender(String lenderId) throws Exception, ApplicationException;

    /**
     * @param xml
     * @return
     */
    List<String> encryptedXmlwithKeyId(String xml);

    /**
     * @param distributions
     * @return
     * @throws Exception
     */
    String determineSequenceId(final List<DcDistribution> distributions) throws Exception;

    /**
     * @param financeType
     * @return
     */
    String convertFinanceType(final String financeType);

    /**
     * @param userEmail
     * @return
     */
    public String extractUserName(String userEmail);

    public Timestamp getCurrentTime();

    /**
     * @param deal
     * @return
     * @throws Exception
     */
    String determineVaultIndicator(final DeDeal deal) throws Exception;

    /**
     * @param request
     * @return
     */
    Boolean resumeDistribution(DistributionHelper request);

    /**
     * @param creditJournal
     * @return
     * @throws ApplicationException
     * @throws Exception
     */
    Document getDocumentFromCreditJournal(final CreditJournal creditJournal) throws ApplicationException, Exception;
    
    /**
     * @param request
     * @return
     */
    public boolean isFeatureEnabled(List<DeLenderFeature> lenderFeatures, String feature);
}
