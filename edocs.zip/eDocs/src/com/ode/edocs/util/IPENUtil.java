package com.ode.edocs.util;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.vo.BeginCompleteProcessingVO;
import com.ode.pen.ws.client.AftermarketDataContainer;

public interface IPENUtil {

	public AftermarketDataContainer sendRequestToPen(final BeginCompleteProcessingVO beginCompleteProcessingVO, final DeDeal deDeal);
	
}
