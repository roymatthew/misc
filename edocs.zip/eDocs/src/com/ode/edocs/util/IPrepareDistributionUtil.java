package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.rest.entity.ErrorDetail;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public interface IPrepareDistributionUtil {

    /**
     * @param distHelper
     * @param timeStamp
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DcDistribution prepareDistributionForCompletion(DistributionHelper distHelper, Date timeStamp,
        ErrorDetail errorDetail) throws Exception;

    /**
     * @param eDocIn
     * @param deDealId
     * @param sequenceId
     * @param dealerId
     * @param createdDay
     * @return
     * @throws Exception
     */
    List<File> readFilesFromSystem(Document eDocIn, String deDealId, String sequenceId, String dealerId,
        String createdDay) throws Exception;

}
