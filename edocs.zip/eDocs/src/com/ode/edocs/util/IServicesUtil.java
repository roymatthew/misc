package com.ode.edocs.util;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import java.util.List;

public interface IServicesUtil {

    boolean vaultDocument(String vaultDocId, DeDeal deDeal, String dealerId, DeLender lender) throws Exception;

    String base64Encode(byte[] binaryData) throws Exception;

    String decryptText(String crDataXml, String encryptionKeyId) throws Exception;

    List<String> encryptText(String xml) throws Exception;

    String assignDocument(String vaultDocId, DeDeal deDeal, DeLender lender) throws Exception;

    String withdrawDocument(String vaultDocId, DeDeal deDeal) throws Exception;

}
