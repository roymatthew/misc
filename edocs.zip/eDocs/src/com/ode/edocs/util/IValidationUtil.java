package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.ReCVData;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.vault.db.entity.VaultRegisterDocument;
import java.util.List;
import org.jdom2.Document;

public interface IValidationUtil {

    /**
     * @param deDeal
     * @param applicationNumber
     * @throws ApplicationException
     */
    void isApplicationNumberBlank(DeDeal deDeal, String applicationNumber)
        throws ApplicationException;

    /**
     * @param deDeal
     * @param reCVData
     * @param errorDetail
     * @param dmsId
     * @throws ApplicationException
     */
    void isAutoReCvValid(DeDeal deDeal, ReCVData reCVData, ErrorDetail errorDetail, String dmsId)
        throws ApplicationException;

    /**
     * @param eDocIn
     * @param lender
     * @param deDeal
     * @return
     * @throws Exception
     */
    DeDeal validateVaultedContractForCDK(Document eDocIn, DeLender lender, DeDeal deDeal)
        throws Exception;

    /**
     * @param files
     * @param deDeal
     * @param lenderId
     * @param sequenceNumberCheck
     * @throws Exception
     */
    void validateContractForARAndRR(List<File> files, DeDeal deDeal, String lenderId) throws Exception;

    /**
     * @param deDeal
     * @param lenderId
     * @throws Exception
     */
    void validateLenderForRR(DeDeal deDeal, String lenderId) throws Exception;

    /**
     * @param deal
     * @param lenderId
     * @param errorDetail
     * @throws ApplicationException
     */
    void validateLender(final DeDeal deal, final String lenderId,
        final String partyId, final ErrorDetail errorDetail) throws ApplicationException;

    /**
     * @param distributions
     * @param errorDetail
     * @throws ApplicationException
     */
    void checkDistributionStatus(final List<DcDistribution> distributions, final ErrorDetail errorDetail)
        throws ApplicationException;

    /**
     * @param ancillaryFiles
     * @return
     */
    boolean doesDistributionHasAncillaryContractFile(final List<String> ancillaryFiles);

    /**
     * @param files
     * @param dmsId
     * @param lenderId
     * @return
     */
    boolean doesDistributionHasContract(List<File> files, String dmsId, String lenderId);

    /**
     * Return true if the EYES_ON_DOC is enabled for the lender and the dealer is enabled for EOD.
     * @param dmsDealerId
     * @param lenderId
     * @param lender
     * @return
     * @throws Exception
     */
    boolean isEyesOnDocEnabled(final String dmsDealerId, final String lenderId, final DeLender lender) throws Exception;

    /**
     * Parse text from the Lease Worksheet PDF and look for the ODE-CV
     * indicator.
     *
     * @param files
     * @return
     * @throws Exception
     */

    boolean isLeaseWorksheetValid(List<File> files) throws Exception;

    /**
     * @param vaultDocId
     * @return
     */
    boolean vaultDocIdExists(final String vaultDocId);

    /**
     * @param files
     * @param formsDao
     * @return
     */
    boolean isContractInApprovedFormList(final List<File> files, final FormsDAO formsDao, final String partyId);

    /**
     * @param docName
     * @return
     */
    boolean isVCIContract(final String docName);

    /**
     * @param docName
     * @return
     */
    boolean isContract(final String docName);

    /**
     * @param formType
     * @return
     */
    boolean isEForm(final String formType);

    /**
     * @param distributions
     * @return
     */
    boolean previousDistributionExists(final List<DcDistribution> distributions);

    /**
     * @param deDeal
     * @return
     */
    boolean isDeDealNew(final DeDeal deDeal);

    /**
     * @param file
     * @return
     * @throws Exception
     */
    Boolean isADPRequiredForm(final File file) throws Exception;

    /**
     * @param dcForms
     * @return
     * @throws Exception
     */
    Boolean isRequiredForm(final List<DcForm> dcForms) throws Exception;

    /**
     * @param deDeal
     * @param vaultDocRecord
     * @param errorDetail
     * @throws ApplicationException
     */
    void checkVaultStatus(final DeDeal deDeal, final VaultRegisterDocument vaultDocRecord,
        final ErrorDetail errorDetail) throws ApplicationException;

    /**
     * @param lenderId
     * @return
     */
    boolean isVCILender(final String lenderId);

    void validateEconStatus(final DeDeal deDeal) throws ApplicationException;
    
    /**
     * Validate is the Deal came from CDK
     * @param deDeal
     * @return
     * @throws ApplicationException
     */
    boolean isCDKDeal(final String dmsId);
    
    boolean isRouteOneTransaction(String lenderId, String dealerId, String dmsId, String productId) throws ApplicationException;
    
    boolean isNewCVWorkflow(String lenderId, String dealerId, String dmsId, String productId) throws ApplicationException;
}