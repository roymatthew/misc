package com.ode.edocs.util;

import com.ode.edocs.bo.DistributionFile;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.util.zip.ZipFile;
import org.jdom2.Document;
import org.jdom2.Namespace;

public interface IZipUtil {

    /**
     * @param deDealId
     * @param sequenceId
     * @param dealerId
     * @param attachmentDirLoc
     * @return
     * @throws Exception
     */
    String getZipAttachmentLocation(final String deDealId, final String sequenceId, final String dealerId,
        final String attachmentDirLoc) throws Exception;

    /**
     * @param dealerId
     * @param base64Zip
     * @param attachmentLoc
     * @return
     * @throws Exception
     */
    DistributionFile getFilesFromZip(final String dealerId, final String base64Zip, final String attachmentLoc, final String textFile)
        throws Exception;

    /**
     * @param zipFile
     * @return
     * @throws Exception
     */
    DistributionFile extractFilesFromZip(final ZipFile zipFile) throws Exception;

    /**
     * @param distributionProcessingVO
     * @param errorDetail
     * @return
     * @throws Exception
     */
    AttachmentProcessingVO extractAttachmentParams(final DistributionProcessingVO distributionProcessingVO,
        final ErrorDetail errorDetail) throws Exception;

    /**
     * @param document
     * @param xpathString
     * @param namespace
     * @throws Exception
     */
    void stripAttachment(final Document document, final String xpathString, final Namespace namespace) throws Exception;

    /**
     * @param distributionProcessingVO
     * @param attachmentProcessingVO
     * @param lender
     * @param eyesOnDocFlag
     * @param errorDetail
     * @return
     * @throws Exception
     */
    byte[] processZipAttachmentFile(final DistributionProcessingVO distributionProcessingVO,
        final AttachmentProcessingVO attachmentProcessingVO, final DeLender lender, final boolean eyesOnDocFlag,
        final ErrorDetail errorDetail) throws Exception;

    /**
     * @param deDealId
     * @param sequenceId
     * @param dealerId
     * @return
     * @throws Exception
     */
    String getZipAttachmentLocation(String deDealId, String sequenceId, String dealerId)
        throws Exception;

    /**
     * @param dealerId
     * @param base64Zip
     * @param attachmentLoc
     * @param errorDetail
     * @return
     * @throws Exception
     */
    DistributionFile getFilesFromZip(String dealerId, String base64Zip, String attachmentLoc,
        ErrorDetail errorDetail) throws Exception;

}
