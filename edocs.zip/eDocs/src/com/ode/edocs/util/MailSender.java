package com.ode.edocs.util;

import com.ode.edocs.db.entity.DeDeal;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

@Component
public class MailSender {
    @Autowired
    JavaMailSenderImpl mailSender;
    @Value("${environment}")
    String environment;
    @Value("${email.from}")
    String from;
    @Value("${email.to}")
    String to;

    private static final Logger logger = LogManager.getLogger(MailSender.class);

    public void sendAlertEmail(ApplicationException e){
        logger.debug("Entered method sendAlertEmail(ApplicationException e)");
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setFrom(from);
        message.setSubject(environment+": Alert from eDocs WebService");

        String alertMessage = getConsolidatedMessage(e);

        message.setText(alertMessage);
        try{
            mailSender.send(message);
        }catch(Exception ex){
            logger.error("Unable to send error notification email:", ex);
        }

    }

    public String getConsolidatedMessage(ApplicationException e) {
        String alertMessage = "";
        if(e.getAlertMessage()!=null){
            alertMessage += e.getAlertMessage() + "\n";
        }
        if(e.getTimestamp()!=null){
            alertMessage += "timestamp: " + e.getTimestamp() + "\n";
        }
        if(e.getDealerId()!=null){
            alertMessage += "Dealer ID: " + e.getDealerId() + "\n";
        }
        if(e.getCode()!=null){
            alertMessage += "Return Code from WS: " + e.getCode() + "\n";
        }
        if(e.getMessage()!=null){
            alertMessage += "Return Message from WS: " + e.getMessage() + "\n";
        }
        else {
            alertMessage += "Null response back from eDocs WebService\n";
        }
        if(e.getOriginalException()!=null){
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.getOriginalException().printStackTrace(pw);
            alertMessage += sw.toString();
        }
        return alertMessage;
    }

    public void sendVaultEmail(String message, DeDeal deDeal){
        String subject = environment+": vault accept/reject failed";

        String body = "An error occured when attempting to assign a vaulted document on behalf of a Dealer. \n\n"
            + "Lender: " + deDeal.getLenderId() + "\n"
            + "Dealer: " + deDeal.getDmsDealerId() + "\n"
            + "DocumentId: " + deDeal.getVaultDocId() + "\n"
            + "Contract Application Number: " + deDeal.getCaApplicationNum() + "\n\n"
            + message;

        sendEmail(subject, body, to);
    }

    public void sendVaultEmail(String message,  DeDeal deDeal, Exception e){
        String stackTrace ="";
        if(null != e){
            Writer writer = new StringWriter();
            PrintWriter printWriter = new PrintWriter(writer);
            e.printStackTrace(printWriter);
            stackTrace = writer.toString();
        }
        message += "\n" + stackTrace;

        sendVaultEmail(message, deDeal);
    }

    public void sendEncryptionEmail(String message) {
        String subject = environment + ": alert for encryption/decryption";

        String body = "An error occred with keys.xml file. \n"
            + message;

        sendEmail(subject, body, to);
    }

    public void sendEmail(String subject, String body, String email){
        logger.debug("Entered method sendEmail(String subject, String body, String email)s");
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setFrom(from);
        message.setSubject(subject);
        message.setText(body);
        try{
            mailSender.send(message);
        }catch(Exception e){
            logger.error("could not send email", e);
        }

    }

    public void sendVaultWithDrawEmail(String message, DeDeal deDeal) {
        String subject = environment + ": vault withdraw failed";

        String body = "An error occured when attempting to Withdraw Vault. \n\n" + "Lender: " + deDeal.getLenderId()
            + "\n" + "Dealer: " + deDeal.getDmsDealerId() + "\n" + "DocumentId: " + deDeal.getVaultDocId() + "\n"
            + "Contract Application Number: " + deDeal.getCaApplicationNum() + "\n\n" + message;

        sendEmail(subject, body, to);
    }

}
