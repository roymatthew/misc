package com.ode.edocs.util;

import java.io.StringWriter;
import java.math.BigInteger;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.ws.Holder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DePartnerDestination;
import com.ode.edocs.service.ICreditJournalService;
import com.ode.edocs.service.IDePartnerDestinationService;
import com.ode.edocs.vo.BeginCompleteProcessingVO;
import com.ode.pen.ws.client.AftermarketAuthenticationHeader;
import com.ode.pen.ws.client.AftermarketDataContainer;
import com.ode.pen.ws.client.ExchangeController;

@Component
public class PENUtilImpl implements IPENUtil {

	private static final Logger logger = LogManager.getLogger(PENUtilImpl.class);

	@Autowired
    public ICreditJournalService creditJournalService;
	
	@Autowired
	private IDePartnerDestinationService dePartnerDestinationServiceImpl;
	
	private static Namespace soapenv = Namespace.getNamespace("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
	private static Namespace xmlSchema = Namespace.getNamespace("xsd", "http://www.w3.org/2001/XMLSchema");
	private static Namespace xmlSchemaInstance = Namespace.getNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
	private static Namespace odeDefault = Namespace.getNamespace("http://exchange.opendealerexchange.com");

	public AftermarketDataContainer sendRequestToPen(final BeginCompleteProcessingVO beginCompleteProcessingVO, final DeDeal deDeal) {
        logger.debug("Entered method AftermarketDataContainer.sendRequestToPen "+ deDeal);
        
        AftermarketDataContainer aftermarketData = null;     
		try {
			DePartnerDestination dePartnerDestination = dePartnerDestinationServiceImpl.findByProduct(AppConstants.PEN_PARTNER_ID);
			if (null != dePartnerDestination) {
				logger.debug("dePartnerDestination:" + dePartnerDestination);
				
				URL destinationUrl = new URL(dePartnerDestination.getDestinationUrl() + ExchangeController.URL_APPEND);
				AftermarketAuthenticationHeader authHeader = new AftermarketAuthenticationHeader(dePartnerDestination.getWsUsername(), dePartnerDestination.getWsPassword());
				
				//Write PENIN
				writePENIN(beginCompleteProcessingVO, authHeader, deDeal);
				
				aftermarketData = new ExchangeController(destinationUrl).getExchangeControllerSoap()
						.getAftermarketData(deDeal.getDmsDealNum(), deDeal.getVin(), new Holder<AftermarketAuthenticationHeader>(authHeader));
				
				//Write PENOUT
				writePENOUT(beginCompleteProcessingVO, aftermarketData, deDeal);
				
			} else {
				logger.debug("dePartnerDestination is null.");
			}
		} catch (Exception e) {
			logger.error("Exception while getting PEN data.", e);
		}
		
		return logger.exit(aftermarketData);
	}
	
	private void writePENIN(final BeginCompleteProcessingVO beginCompleteProcessingVO, AftermarketAuthenticationHeader aftermarketAuthHeader, DeDeal deDeal) {
		logger.debug("Entered method writePENIN "+ deDeal);

		try {
			String penin = buildPENIN(aftermarketAuthHeader, deDeal);
			
			BigInteger penInCjKey = creditJournalService.writePENIN(beginCompleteProcessingVO.geteDocIn(), 
					penin, beginCompleteProcessingVO.getTimeStamp(), deDeal.getDealId(), 
					beginCompleteProcessingVO.getSequenceId(), beginCompleteProcessingVO.getTransactionId(), 
					beginCompleteProcessingVO.getAccountId());
    		logger.debug("PENIN CJKEY: {}", penInCjKey);
		} catch(Exception e) {
			logger.error("Unable to write PENIN to Creditjournal", e);
		}
	}
	
	private void writePENOUT(final BeginCompleteProcessingVO beginCompleteProcessingVO, AftermarketDataContainer aftermarketData, DeDeal deDeal) {
		logger.debug("Entered method writePENOUT");
		
		try {
			String penout = buildPENOUT(aftermarketData);
			
			BigInteger penOutCjKey = creditJournalService.writePENOUT(beginCompleteProcessingVO.geteDocIn(), 
					penout, beginCompleteProcessingVO.getTimeStamp(), deDeal.getDealId(), 
					beginCompleteProcessingVO.getSequenceId(), beginCompleteProcessingVO.getTransactionId(), 
					beginCompleteProcessingVO.getAccountId());
    		logger.debug("PENOUT CJKEY: {}", penOutCjKey);
		} catch(Exception e) {
			logger.error("Unable to write PENOUT to Creditjournal", e);
		}
	}
	
	private String buildPENIN(AftermarketAuthenticationHeader aftermarketAuthHeader, DeDeal deDeal) {
		logger.debug("Entered method buildPENIN");
		
		Document outgoingXml = new Document();
		
		Element rootElement = new Element("Envelope", soapenv);
		rootElement.addNamespaceDeclaration(soapenv);
		rootElement.addNamespaceDeclaration(xmlSchema);
		rootElement.addNamespaceDeclaration(xmlSchemaInstance);
		
		Element body = new Element("Body", soapenv);
		Element getAftermarketData = new Element("GetAftermarketData", odeDefault);
		
		Element dealNum = new Element("DealNumber", odeDefault);
		dealNum.setText(deDeal.getDmsDealNum());
		
		Element vin = new Element("VehicleVIN", odeDefault);
		vin.setText(deDeal.getVin());
		
		getAftermarketData.addContent(dealNum);
		getAftermarketData.addContent(vin);
		
		body.addContent(getAftermarketData);
		rootElement.addContent(body);
		
		outgoingXml.setRootElement(rootElement);
		
		String peninString = "";
		try {
			peninString = EdocsXmlUtils.convertDocumentToString(outgoingXml);
		} catch(Exception e) {
			logger.error("Error generating PENIN String", e);
		}
		
		return peninString;
	}
	
	private String buildPENOUT(AftermarketDataContainer aftermarketData) {
		logger.debug("Entered method buildPENIN");
		
		String penout = "";
		try {
			JAXBContext context = JAXBContext.newInstance(AftermarketDataContainer.class);
	        Marshaller m = context.createMarshaller();
	
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	
	        StringWriter sw = new StringWriter();
	        m.marshal(aftermarketData, sw);
	        penout = sw.toString();
		} catch(Exception e) {
			logger.error("Unable to marshall AftermarketDataContainer to String XML for PENOUT", e);
		}
		
		return penout;
	}
}