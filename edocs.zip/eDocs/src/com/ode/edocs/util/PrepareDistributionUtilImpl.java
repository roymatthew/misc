package com.ode.edocs.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipFile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ode.edocs.DistributionCheckHandler;
import com.ode.edocs.File;
import com.ode.edocs.MetaDataHandler;
import com.ode.edocs.bo.DistributionFile;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DcDocField;
import com.ode.edocs.db.entity.DcDocType;
import com.ode.edocs.db.entity.DcDocument;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDataElement;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderPartner;
import com.ode.edocs.db.entity.DmsDocType;
import com.ode.edocs.db.entity.LenDocType;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.rest.entity.FormElementKey;
import com.ode.edocs.service.IBeginDistributeService;
import com.ode.edocs.service.ICompleteDistributeService;
import com.ode.edocs.service.ICreditJournalService;
import com.ode.edocs.service.IDcDocFieldDAOService;
import com.ode.edocs.service.IDcDocumentService;
import com.ode.edocs.service.IDcFormDAOService;
import com.ode.edocs.service.IDeLenderDAOService;
import com.ode.edocs.service.IDeLenderPartnerDAOService;
import com.ode.edocs.service.IDealService;
import com.ode.edocs.service.IDistributionService;
import com.ode.edocs.service.IDmsDocTypeDAOService;
import com.ode.edocs.service.IDocDataService;
import com.ode.edocs.service.ILenDocTypeDAOService;
import com.ode.edocs.vo.BeginCompleteProcessingVO;

@Component
public class PrepareDistributionUtilImpl implements IPrepareDistributionUtil {

	private static final Logger logger = LogManager.getLogger(PrepareDistributionUtilImpl.class);

	@Autowired
	private IDmsDocTypeDAOService dmsdocTypeService;
	@Autowired
	private ILenDocTypeDAOService lenDocTypeService;
	@Autowired
	private IDcDocFieldDAOService dcDocFieldService;
	@Autowired
	private IDcFormDAOService dcFormService;
	@Autowired
	private IDeLenderDAOService deLenderService;
	@Autowired
	private IDeLenderPartnerDAOService deLenderPartnerService;
	@Autowired
	private IDealService dealService;
	@Autowired
	IBeginDistributeService beginDistributeService;
	@Autowired
	private ICreditJournalService creditJournalService;
	@Autowired
	ICompleteDistributeService completeDistributeService;
	@Autowired
	private IDistributionService distributionService;
	@Autowired
	private IDcDocumentService dcDocumentService;
	@Autowired
	private IDocDataService dcDcDataService;
	@Autowired
	private IServicesUtil servicesUtil;
	@Autowired
	private IValidationUtil validationUtil;
	@Autowired
	private IHandleDistributeUtil handleDistributeUtil;
	@Autowired
	private IZipUtil zipUtil;
	@Autowired
	MetaDataHandler metaDataHandler;
	@Autowired
	DistributionCheckHandler distributionCheckHandler;

	private static HashMap<FormElementKey, List<DeDataElement>> metaDataMap;

	static {
		metaDataMap = new HashMap<FormElementKey, List<DeDataElement>>();
	}

	@Value("${baseAutonomousRFLForVCI}")
	private String baseAutonomousRFLForVCI;

	@Override
	public DcDistribution prepareDistributionForCompletion(DistributionHelper distHelper, Date timeStamp,
			ErrorDetail errorDetail) throws Exception {
		logger.debug("Entered prepareDistributionForCompletion()");
		String deDealId = distHelper.getDeDealId();
		String sequenceId = distHelper.getSequenceId();
		DeDeal deDeal = dealService.getByDeDealId(deDealId);

		String dealerId = deDeal.getDmsDealerId();
		String indValue = "NA";

		// In case the data is absent for Eyes on doc resume scenario
		errorDetail.setDealerId(dealerId);
		errorDetail.setDealId(deDealId);
		errorDetail.setDmsDealNum(deDeal.getDmsDealNum());

		ThreadContext.put("dealerId", dealerId);
		ThreadContext.put("dealNumber", deDeal.getDmsDealNum());

		CreditJournal cjEDocIn = creditJournalService.findByDeDealIdAndSequenceId(deDealId, sequenceId, dealerId,
				AppConstants.TRANS_TYPE_EDOCIN);

		String eDocInString = "";
		try {
			if (cjEDocIn != null) eDocInString = servicesUtil.decryptText(cjEDocIn.getCrDataXml(), cjEDocIn.getEncryptionKeyId());
		} catch (Exception e) {
			logger.error("could not decrypt EDOCIN xml", e);
			ApplicationException ae = new ApplicationException(dealerId, e, AppConstants.DECRYPT_EDOCIN_FAILED_CODE);
			ae.setErrorDetail(errorDetail);
			throw ae;
		}
		Document eDocIn = EdocsXmlUtils.getDocumentFromString(eDocInString);
		String sequenceNumber = EdocsXmlUtils.getTextFromXpath(eDocIn, XMLConstants.starBodIdPath);
		String dmsId = EdocsXmlUtils.getDmsId(eDocIn);

		String partnerId = EdocsXmlUtils.getTextFromXpath(eDocIn, XMLConstants.starPartyIdPath);
		String lenderId = "";

		DeLender lender = deLenderService.findByLenderId(partnerId);
		if (null != lender) {
			lenderId = partnerId;
		} else {
			DeLenderPartner deLenderPartner = deLenderPartnerService.getByPartnerId(partnerId);
			if (null != deLenderPartner) {
				lenderId = deLenderPartner.getLenderId();
				lender = deLenderService.findByLenderId(lenderId);
			} else {
				logger.error("No record in DeLenderPartner table for lender:{}", partnerId);
				throw new ApplicationException(errorDetail.add(AppConstants.DE_LENDER_NOT_FOUND_MESSAGE,
						AppConstants.DE_LENDER_NOT_FOUND_CODE));
			}
		}
		errorDetail.setLenderId(lenderId);

		DeContractValidation cv = distributionCheckHandler.retrievePassedCV(deDeal, sequenceNumber);

		CreditJournal cjEcout = creditJournalService.getCreditJournalRecord(deDeal, cv, AppConstants.TRANS_TYPE_ECOUT);

		String ecoutString = "";
		try {
			if (cjEcout != null) ecoutString = servicesUtil.decryptText(cjEcout.getCrDataXml(), cjEcout.getEncryptionKeyId());
		} catch (Exception e) {
			logger.error("could not decrypt ECOUT xml", e);
			ApplicationException ae = new ApplicationException(dealerId, e, AppConstants.DECRYPT_ECOUT_FAILED_CODE);
			ae.setErrorDetail(errorDetail);
			throw ae;
		}
		Document ecout = EdocsXmlUtils.getDocumentFromString(ecoutString);

		String financeType = EdocsXmlUtils.getTextFromXpath(eDocIn, XMLConstants.starFinanceTypePath);
		financeType = handleDistributeUtil.convertFinanceType(financeType);

		CreditJournal cjEcin = creditJournalService.findByDeDealIdAndSequenceId(deDeal.getDealId(),
				cjEcout.getSequenceId(), cjEcout.getDealerId(), AppConstants.TRANS_TYPE_ECIN);
		Document ecIn = creditJournalService.getDocumentFromCreditJournal(cjEcin);
		String applicationType = handleDistributeUtil.getApplicationType(ecIn);

		// Find the distribution and created timestamp
		DcDistribution dcDistribution = distributionService.find(deDealId, sequenceId);
		String createdDay = "";
		if (null != dcDistribution) {
			Date createdTs = dcDistribution.getCreatedByTs();
			if (null != createdTs) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
				createdDay = dateFormat.format(createdTs);
			}
		}
		List<File> files = readFilesFromSystem(eDocIn, deDealId, sequenceId, dealerId, createdDay);

		HashMap<String, String> formTypeMap = new HashMap<String, String>();
		
		// Vault document id
		String vaultDocId = HandlerUtils.getVaultDocId(eDocIn);

		// File preparation
		for (File file : files) {
			String formattedFileName = HandlerUtils.getFormattedFileName(file);
			List<DcForm> dcForms = dcFormService.findForms(deDealId, formattedFileName);
			file.setDcForms(dcForms);
			if (AppConstants.DSP_ADP.equalsIgnoreCase(dmsId)) {
				file.setRequiredForm(validationUtil.isADPRequiredForm(file).toString());
			} else {
				file.setRequiredForm(validationUtil.isRequiredForm(dcForms).toString());
			}
			String formType = HandlerUtils.getFormType(eDocIn, file, dmsId);
			formTypeMap.put(formattedFileName, formType);

			String getDocName = file.getFilename();
			String docName = file.getFilename().substring(0, getDocName.lastIndexOf('.'));

			if (AppConstants.DSP_ADP.equals(dmsId) && (AppConstants.CONTRACT_RETAIL_VCI.equalsIgnoreCase(docName)
					|| AppConstants.CONTRACT_LEASE_VCI.equalsIgnoreCase(docName)
					|| AppConstants.CONTRACT_BALLOON_VCI.equalsIgnoreCase(docName))) {

				indValue = handleDistributeUtil.getvaultIndicator(docName, formType, vaultDocId);
			}

			DcDocType dcDocType = null;
			DmsDocType dmsDocType = dmsdocTypeService.findByName(formattedFileName, dmsId);

			if (dmsDocType == null) {
				dmsDocType = dmsdocTypeService.findByName(AppConstants.DOC_NAME_OTHER, dmsId);
			}

			List<DcDocField> fields = null;
			if (null != dmsDocType && null != dmsDocType.getDcDocType()) {
				dcDocType = dmsDocType.getDcDocType();
				List<LenDocType> lenDocTypes = lenDocTypeService.findByDcDocTypeId(dmsDocType.getDcDocType().getId(),
						lenderId);
				if (null != lenDocTypes && lenDocTypes.size() == 1) {
					lenDocTypes.get(0).getDocName();
					file.setLenDocType(lenDocTypes.get(0));
				} else if (lenDocTypes == null) {
					logger.warn("did not find Lender Doc Type for lender:{}, DMS Doc Type:{}, DC Doc Type:{}", lenderId,
							dmsDocType.getDocName(), dcDocType.getName());
				} else if (lenDocTypes.size() > 1) {
					logger.warn(
							"found too many Lender Doc Type matches:{}, using the first match. lender:{}, "
									+ "DMS Doc Type:{}, DC Doc Type:{}",
							lenDocTypes.size(), lenderId, dmsDocType.getDocName(), dcDocType.getName());
					lenDocTypes.get(0).getDocName();
					file.setLenDocType(lenDocTypes.get(0));
				}
				if (AppConstants.AUTONOMOUS_FLAG_YES.equalsIgnoreCase(lender.getAutoNomousDataLookupEnabled())) {
					// for autonomous funding lender, get doc fields map
					Integer dcDocTypeId = dmsDocType.getDcDocType().getId();
					FormElementKey key = metaDataHandler.buildElementKey(dcDocTypeId, lenderId,
							deDeal.getDealExecutionState());
					if (!metaDataMap.containsKey(key)) {
						metaDataMap.put(key, metaDataHandler.getMetaDataFields(key));
					}
					// filter the metadata fields based on finance type and
					// application type of the deal
					file.setMetaDataFields(
							metaDataHandler.metaDataFieldsFilter(metaDataMap.get(key), financeType, applicationType));
				} else {
					// for non-autonomous funding lender, get doc fields from
					// DC_DOC_FIELD
					fields = dcDocFieldService.findByDmsDocTypeId(dmsDocType.getId());
					file.setFields(fields);
				}
			}

			String dmsDocName = HandlerUtils.getDMSDocName(file);
			DcDocument dcDocument = dcDocumentService.getDcDocument(deDealId, sequenceId, dmsDocName);
			file.setDcDocument(dcDocument);
			List<DcDocData> dcDocData = dcDcDataService.findDataByDcDocumentId(dcDocument.getId());
			file.setDocData(dcDocData);
		}

		DcDistribution distribution = distributionService.find(deDealId, sequenceId);

		BeginCompleteProcessingVO beginCompleteProcessingVO = new BeginCompleteProcessingVO();
		beginCompleteProcessingVO.seteDocIn(eDocIn);
		beginCompleteProcessingVO.setDealerId(dealerId);
		beginCompleteProcessingVO.setSequenceId(sequenceId);
		beginCompleteProcessingVO
				.setTransactionId(cjEDocIn != null ? cjEDocIn.getTransactionId() : cjEcout.getTransactionId());
		beginCompleteProcessingVO.setFiles(files);
		beginCompleteProcessingVO.setTimeStamp(timeStamp);
		beginCompleteProcessingVO.setAccountId(cjEcout.getAccountId());
		beginCompleteProcessingVO.setIndValue(indValue);
		beginCompleteProcessingVO.setEcout(ecout);
		beginCompleteProcessingVO.setVaultDocId(vaultDocId);

		completeDistributeService.completeDistribute(beginCompleteProcessingVO, deDeal, lender, financeType,
				distribution, errorDetail, false);

		logger.debug("Exit prepareDistributionForCompletion()");

		return distribution;
	}

	@Override
	public List<File> readFilesFromSystem(Document eDocIn, String deDealId, String sequenceId, String dealerId,
			String createdDay) throws Exception {

		logger.debug("Entered readFilesFromSystem method");
		List<File> files = new ArrayList<File>();

		// create zip file name
		String zipFileName = "XXXX.zip";
		if (null != deDealId && !deDealId.isEmpty() && null != sequenceId && !sequenceId.isEmpty()) {
			zipFileName = deDealId + sequenceId + ".zip";
		} else {
			if (deDealId == null) deDealId = "";
			logger.error("dealid:{} or sequence id:{} are null / empty. cannot read zip file.", deDealId, sequenceId);
			throw new ApplicationException(dealerId,
					"dealid or sequence id are null or empty. cannot read zip file, dealid:" + deDealId + ", seqid:"
							+ (sequenceId != null ? sequenceId : "null"),
					AppConstants.DEALNUM_SEQUENCENO_NOT_FOUND);
		}

		logger.debug("zipFileName:{}", zipFileName);

		// Read ZIP file from file system
		List<String> fileLocations = new ArrayList<String>();
		// JBoss release onwards ZIP file will be under the distribution day
		// folder (edocs/attachments/YYYY_MM_DD/*.zip)
		// Old distributions still have ZIP file under edocs/attachments/*.zip
		fileLocations.add("/data/ode/eDocs/attachments/" + createdDay + "/" + zipFileName);
		fileLocations.add("/data/ode/eDocs/attachments/" + zipFileName);

		int index = -1;
		boolean found = false;
		ZipFile zipFile = null;

		while (!found && index < fileLocations.size() - 1) {
			try {
				index++;
				logger.info("*** Trying to read ZIP file from location : " + fileLocations.get(index));
				java.io.File diskZipFile = new java.io.File(fileLocations.get(index));
				zipFile = new ZipFile(diskZipFile);
				found = true;
				logger.info("*** ZIP file found at location : " + fileLocations.get(index));
			} catch (IOException ioe) {
				logger.info("*** ZIP file NOT found at location : " + fileLocations.get(index));
			} catch (Exception e) {
				logger.info("*** ZIP file NOT found at location : " + fileLocations.get(index));
			}
		}

		if (!found) {
			String message = "ZIP file not found at locations: " + fileLocations.toString();
			zipFile.close();
			throw new ApplicationException(dealerId, message, AppConstants.ZIPFILE_READ_ERROR_CODE);
		}

		// extract files from zip file
		DistributionFile f = zipUtil.extractFilesFromZip(zipFile);
		files = f.getFiles();
		zipFile.close();

		return files;

	}

}
