package com.ode.edocs.util;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ServicesUtilImpl implements IServicesUtil{

    private static final Logger logger = LogManager.getLogger(ServicesUtilImpl.class);

    @Autowired
    public VaultUtil vaultUtil;

    @Autowired
    public IFaxUtil faxUtilImpl;

    @Autowired
    public IZipUtil zipUtilImpl;

    @Override
    public boolean vaultDocument(String vaultDocId, DeDeal deDeal, String dealerId, DeLender lender) throws Exception {
        return vaultUtil.vaultDocument(vaultDocId, deDeal, dealerId, lender);
    }

    @Override
    public String base64Encode(byte[] binaryData) throws Exception {
        return EncryptionUtils.base64Encode(binaryData);
    }

    @Override
    public String decryptText(String crDataXml, String encryptionKeyId) throws Exception {
        return EncryptionUtils.decryptText(crDataXml, encryptionKeyId);
    }

    @Override
    public List<String> encryptText(String xml) throws Exception {
        return EncryptionUtils.encryptText(xml);
    }

    @Override
    public String assignDocument(String vaultDocId, DeDeal deDeal, DeLender lender) throws Exception {
        return vaultUtil.assignDocument(vaultDocId, deDeal, lender);
    }

    /**
     * VaultDocID should be verified as existing before this is called. Will attempt to withdraw the vaultDocId. Returns
     * a response status as a string
     *
     * @param vaultDocId
     * @param deDeal
     * @return
     */
    @Override
    public String withdrawDocument(String vaultDocId, DeDeal deDeal) throws Exception {
        logger.debug("Entered withdrawDocument() method");

        return vaultUtil.withdrawDocument(vaultDocId, deDeal);

    }

}
