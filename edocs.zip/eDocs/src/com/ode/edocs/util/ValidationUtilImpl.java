package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.ReCVData;
import com.ode.edocs.db.dao.FormsDAO;
import com.ode.edocs.db.entity.DcDistribution;
import com.ode.edocs.db.entity.DcForm;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderPartner;
import com.ode.edocs.db.entity.DealerPpNvp;
import com.ode.edocs.db.entity.DmsDocType;
import com.ode.edocs.db.entity.Forms;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.service.IDeLenderDAOService;
import com.ode.edocs.service.IDeLenderPartnerDAOService;
import com.ode.edocs.service.IDealerPpNvpDAOService;
import com.ode.edocs.service.IDmsDocTypeDAOService;
import com.ode.vault.db.entity.VaultRegisterDocument;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.jdom2.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class ValidationUtilImpl implements IValidationUtil {

    private static final Logger logger = LogManager.getLogger(ValidationUtilImpl.class);

    @Autowired
    private IServicesUtil servicesImpl;

    @Autowired
    private IDmsDocTypeDAOService dmsdocTypeService;

    @Autowired
    private IDeLenderDAOService deLenderService;

    @Autowired
    private IDeLenderPartnerDAOService deLenderPartnerService;

    @Autowired
    private IDealerPpNvpDAOService dealerPpNvpService;
    
    @Value("${sequenceNumberCheck}")
    private String sequenceNumberCheck;

    @Value("${leaseWorksheetKey}")
    private String leaseWorksheetKey;
    
    @Value("${commonServiceURL}")
    private String commonServiceURL;

    @Override
    public void isApplicationNumberBlank(DeDeal deDeal, String applicationNumber) throws ApplicationException {
        logger.debug("Entered ValidationsUtil-isApplicationNumberBlank method");
        if (StringUtils.isBlank(applicationNumber)) {
            logger.error("No application number in EDOCIN for Re CV, not submitting Re CV for the dealer: "
                + deDeal.getDmsDealerId() + " DMS deal number: " + deDeal.getDmsDealNum());
            logger.debug("No application number in EDOCIN for Re CV, not submitting Re CV for the dealer: "
                + deDeal.getDmsDealerId() + " DMS deal number: " + deDeal.getDmsDealNum());
            logger.debug("Exited ValidationsUtil-isApplicationNumberBlank method..Throws AppException");
            throw new ApplicationException(AppConstants.AUTO_RE_CV_NO_APPLICATION_NUM_ERROR_MESSAGE,
                AppConstants.AUTO_RE_CV_NO_APPLICATION_NUM_ERROR_CODE);
        }
    }

    @Override
    public void isAutoReCvValid(DeDeal deDeal, ReCVData reCVData, ErrorDetail errorDetail, String dmsId)
        throws ApplicationException {
        logger.debug("Entered ValidationsUtil-isAutoReCvValid method");

        if (!reCVData.getAutoCvValidationStatus().equals(AppConstants.AUTO_RE_CV_VALIDATION_VALID)) {
            logger.error("Re CV failed for the dealer: " + deDeal.getDmsDealerId() + " DMS deal number: "
                + deDeal.getDmsDealNum());
            logger.debug("Re CV failed for the dealer: " + deDeal.getDmsDealerId() + " DMS deal number: "
                + deDeal.getDmsDealNum());
            if (AppConstants.DSP_REYNOLDS.equalsIgnoreCase(dmsId) || AppConstants.DSP_ADVENT.equalsIgnoreCase(dmsId)) {
                throw new ApplicationException(errorDetail.add(reCVData.getAutoCvValidationStatus(),
                    AppConstants.AUTO_RE_CV_VALIDATION_ERROR_CODE));
            } else if (AppConstants.DSP_ADP.equalsIgnoreCase(dmsId)) {
                throw new ApplicationException(errorDetail.add(AppConstants.AUTO_RE_CV_VALIDATION_ERROR_MESSAGE,
                    AppConstants.AUTO_RE_CV_VALIDATION_ERROR_CODE));
            } 
            logger.debug("Exited ValidationsUtil-isAutoReCvValid method..Throws App Exception..");
        }

        logger.debug("Exited ValidationsUtil-isAutoReCvValid method");
    }

    /**
     * Attempts to vault the contract. If it's unable to, a vault search is
     * performed on the vaultDocId to determine the issue and an error will be
     * returned.
     *
     * @param eDocIn
     * @param lender
     * @param deDeal
     * @return
     * @throws Exception
     */
    @Override
    public DeDeal validateVaultedContractForCDK(Document eDocIn, DeLender lender, DeDeal deDeal) throws Exception {
        logger.debug("Entered ValidationsUtil-validateVaultedContractForCDK method");
        Date now = new Date();
        String vaultDocId = HandlerUtils.getVaultDocId(eDocIn);

        if (vaultDocIdExists(vaultDocId)) {
            // This is an eContract, ODE must check the vault if the docID
            // exists with a status of �Active�.
            // If it does proceed to �Assigned� and send the distribution to the lender.
            // If there is not vaulted contract with that id, or an error
            // occurs, then ODE must message back to the DMS.

            String assignStatus = null;
            ApplicationException applicationException = new ApplicationException(
                AppConstants.VAULT_ASSIGN_RESPONSE_ERROR_WITH_DOC);

            try {
                assignStatus = servicesImpl.assignDocument(vaultDocId, deDeal, lender);
            } catch (final Exception e) {
                applicationException = new ApplicationException(e.getMessage());
            }
            if (AppConstants.VAULT_ASSIGN_RESPONSE_DOC_NOT_FOUND.equalsIgnoreCase(assignStatus)) {
                logger.debug(AppConstants.VAULT_DOC_ID_NOT_VAULTED_MESSAGE);
                applicationException = new ApplicationException(AppConstants.VAULT_DOC_ID_NOT_VAULTED_MESSAGE,
                    AppConstants.VAULT_DOC_ID_NOT_VAULTED_CODE);
            } else if (AppConstants.VAULT_ASSIGN_RESPONSE_UNEXPECTED_ERROR.equalsIgnoreCase(assignStatus)
                || AppConstants.VAULT_ASSIGN_RESPONSE_ERROR_WITH_DOC.equalsIgnoreCase(assignStatus)) {
                logger.debug(AppConstants.VAULT_DOC_ID_NOT_VAULTED_MESSAGE);
                applicationException = new ApplicationException(AppConstants.VAULT_ASSIGN_FAILURE_MESSAGE,
                    AppConstants.VAULT_ASSIGN_FAILURE);
            }

            if (assignStatus == null || AppConstants.VAULT_ASSIGN_RESPONSE_DOC_NOT_FOUND.equalsIgnoreCase(assignStatus)
                || AppConstants.VAULT_ASSIGN_RESPONSE_UNEXPECTED_ERROR.equalsIgnoreCase(assignStatus)
                || AppConstants.VAULT_ASSIGN_RESPONSE_ERROR_WITH_DOC.equalsIgnoreCase(assignStatus)) {

                // All these errors are considered as system errors
                throw applicationException;
            }
            deDeal.setEconStatus(AppConstants.ECONTRACT_STATUS_ASSIGNED);
            deDeal.setEconStatusTs(now);
        }
        logger.debug("Exited ValidationsUtil-validateVaultedContractForCDK method");
        return deDeal;
    }

    /**
     * Validates the contract and vault status for RR.
     *
     * @param files
     * @param deDeal
     * @throws Exception
     */
    @Override
    public void validateContractForARAndRR(List<File> files, DeDeal deDeal, String lenderId) throws Exception {
        logger.debug("Entered ValidationsUtil-validateContractForARAndRR method");
        // Check for contract.xml
        Document ancillaryContractDataFile = HandlerUtils.getAncillaryContractData(files);
        if (ancillaryContractDataFile == null) {
            logger.debug("Null or blank contract.xml");
            if (AppConstants.LENDER_MB.equalsIgnoreCase(lenderId)) {
                logger.debug("Exited ValidationsUtil-validateContractForARAndRR method"
                    + AppConstants.ECONTRACT_MB_RR_AR_NOT_ATTACHED_CODE);
                throw new ApplicationException(AppConstants.ECONTRACT_MB_RR_AR_NOT_ATTACHED_MESSAGE,
                    AppConstants.ECONTRACT_MB_RR_AR_NOT_ATTACHED_CODE);
            } else {
				if (AppConstants.DSP_REYNOLDS.equalsIgnoreCase(deDeal.getDmsId())) {
					logger.debug("Exited ValidationsUtil-validateContractForARAndRR method"
							+ AppConstants.ECONTRACT_RR_NOT_ATTACHED_MESSAGE);
					throw new ApplicationException(AppConstants.ECONTRACT_RR_NOT_ATTACHED_MESSAGE,
							AppConstants.ECONTRACT_RR_NOT_ATTACHED_CODE);
				} else {
					logger.debug("Exited ValidationsUtil-validateContractForARAndRR method"
							+ AppConstants.ECONTRACT_AR_NOT_ATTACHED_MESSAGE);
					throw new ApplicationException(AppConstants.ECONTRACT_AR_NOT_ATTACHED_MESSAGE,
							AppConstants.ECONTRACT_AR_NOT_ATTACHED_CODE);
				}
            }
        }

        // Check for sequence number in contract.xml. Only do this for lenders
        // that are enabled for it.
        if (sequenceNumberCheck.contains(lenderId) && AppConstants.DSP_REYNOLDS.equalsIgnoreCase(deDeal.getDmsId())) {
            String sequenceNumber = HandlerUtils.getNVPTextFromXpath(ancillaryContractDataFile, "DataField",
                "SEQUENCE NUMBER");
            if (null != sequenceNumber && !sequenceNumber.isEmpty()) {

                // Reject if not assigned
                if (deDeal.getEconStatus() == null
                    || !deDeal.getEconStatus().equalsIgnoreCase(AppConstants.ECON_STATUS_ASSIGNED)) {
					if (AppConstants.DSP_REYNOLDS.equalsIgnoreCase(deDeal.getDmsId())) {
						throw new ApplicationException(AppConstants.ECONTRACT_RR_NOT_ASSIGNED_MESSAGE,
								AppConstants.ECONTRACT_RR_NOT_ASSIGNED_CODE);
					} else {
						throw new ApplicationException(AppConstants.ECONTRACT_AR_NOT_ASSIGNED_MESSAGE,
								AppConstants.ECONTRACT_AR_NOT_ASSIGNED_CODE);
					}
                }
            } else {
                logger.debug("Null or blank sequenceNumber");
                if (AppConstants.LENDER_MB.equalsIgnoreCase(lenderId)) {
                    logger.debug("Exited ValidationsUtil-validateContractForARAndRR method"
                        + AppConstants.ECONTRACT_MB_RR_AR_NOT_ATTACHED_CODE);
                    throw new ApplicationException(AppConstants.ECONTRACT_MB_RR_AR_NOT_ATTACHED_MESSAGE,
                        AppConstants.ECONTRACT_MB_RR_AR_NOT_ATTACHED_CODE);
                } else {
                	if (AppConstants.DSP_REYNOLDS.equalsIgnoreCase(deDeal.getDmsId())) {
                    logger.debug("Exited ValidationsUtil-validateContractForARAndRR method"
                        + AppConstants.ECONTRACT_RR_NOT_ATTACHED_MESSAGE);
                    throw new ApplicationException(AppConstants.ECONTRACT_RR_NOT_ATTACHED_MESSAGE,
                        AppConstants.ECONTRACT_RR_NOT_ATTACHED_CODE);
                	} else {
                		logger.debug("Exited ValidationsUtil-validateContractForARAndRR method"
                                + AppConstants.ECONTRACT_AR_NOT_ATTACHED_MESSAGE);
                            throw new ApplicationException(AppConstants.ECONTRACT_RR_NOT_ATTACHED_MESSAGE,
                                AppConstants.ECONTRACT_AR_NOT_ATTACHED_CODE);
                	}
                }
            }
        }
        logger.debug("Exited ValidationsUtil-validateContractForARAndRR method");

    }

    @Override
    public void validateLenderForRR(DeDeal deDeal, String lenderId) throws Exception {
        logger.debug("Entered ValidationsUtil-validateLenderForRR method");
        // Reject if assigned to the wrong lender.
        if (deDeal.getEconStatus() == null
            || AppConstants.ECON_STATUS_ASSIGNED.equalsIgnoreCase(deDeal.getEconStatus())) {
            String deDealLenderId = deDeal.getLenderId();
            if (!deDealLenderId.equalsIgnoreCase(lenderId)) {
                final DeLender deLender = deLenderService.findLenderByLenderId(deDealLenderId);
                if (deLender == null) {
                    final DeLenderPartner deLenderPartner = deLenderPartnerService
                        .getLenderPartnerByPartnerId(deDealLenderId);
                    if (null != deLenderPartner) {
                        deDealLenderId = deLenderPartner.getLenderId();
                    } else {
                        logger.error("No record in DeLenderPartner table for lender:{}", deDealLenderId);
                        logger.debug("No record in DeLenderPartner table for lender:{}", deDealLenderId);
                        throw new ApplicationException(AppConstants.DE_LENDER_NOT_FOUND_MESSAGE,
                            AppConstants.DE_LENDER_NOT_FOUND_CODE);
                    }
                }
            }

            if (!deDealLenderId.equalsIgnoreCase(lenderId)) {
                logger.error(
                    "DeDeal is in 'Assigned' ECON_STATUS but is assigned to wrong lender, deDealId:{}, lenderId:{}, eContractStatus:{}",
                    deDeal.getDealId(), deDeal.getLenderId(), deDeal.getEconStatus());
                logger.debug(
                    "DeDeal is in 'Assigned' ECON_STATUS but is assigned to wrong lender, deDealId:{}, lenderId:{}, eContractStatus:{}",
                    deDeal.getDealId(), deDeal.getLenderId(), deDeal.getEconStatus());
                throw new ApplicationException(AppConstants.DE_DEAL_ASSIGNED_TO_WRONG_LENDER_MESSAGE,
                    AppConstants.DE_DEAL_ASSIGNED_TO_WRONG_LENDER_CODE);
            }
        }
        logger.debug("Exited ValidationsUtil-validateLenderForRR method");

    }

    @Override
    public void validateLender(final DeDeal deal, final String lenderId, final String partyId,
        final ErrorDetail errorDetail) throws ApplicationException {

        logger.debug("Enter validateLender for lenderId:" + lenderId);

        // Reject if assigned to the wrong lender.
        if (deal.getEconStatus() == null || AppConstants.ECON_STATUS_ASSIGNED.equalsIgnoreCase(deal.getEconStatus())) {
            String deDealLenderId = deal.getLenderId();

            if (!deDealLenderId.equalsIgnoreCase(lenderId) && !deDealLenderId.equalsIgnoreCase(partyId)) {
                logger.error(
                    "DeDeal is in 'Assigned' ECON_STATUS but is assigned to wrong lender, deDealId:{}, lenderId:{}, eContractStatus:{}",
                    deal.getDealId(), deal.getLenderId(), deal.getEconStatus());
                throw new ApplicationException(errorDetail.add(AppConstants.DE_DEAL_ASSIGNED_TO_WRONG_LENDER_MESSAGE,
                    AppConstants.DE_DEAL_ASSIGNED_TO_WRONG_LENDER_CODE));
            }
        }

        logger.debug("Exit validateLender for lenderId:" + lenderId);

    }

    @Override
    public void checkDistributionStatus(final List<DcDistribution> distributions, ErrorDetail errorDetail)
        throws ApplicationException {
        // EOD Lenders - Do not allow the dealer to distribute on "Pending"
        // status.
        logger.debug(
            "Entered checkDistributionStatus(List<DcDistribution> distributions, ErrorDetail errorDetail) method");
        if (null != distributions && !distributions.isEmpty()
            && distributions.get(0).getDist_status().equalsIgnoreCase(AppConstants.DOCUMENT_STATUS_PENDING)) {
            throw new ApplicationException(errorDetail.add(AppConstants.DISTRIBUTION_IS_IN_PENDING_STATUS,
                AppConstants.DISTRIBUTION_PENDING_STATUS_ERROR_CODE));
        }
        logger.debug("Exit checkDistributionStatus");
    }

    @Override
    public boolean doesDistributionHasContract(List<File> files, String dmsId, String lenderId) {
        logger.debug("Entering DoesDistributionHasContract(List<File> files, String dmsId, String lenderId) method");
        for (File file : files) {
            try {
                String formattedFileName = HandlerUtils.getFormattedFileName(file);
                String fileName = "";

                if (isVCILender(lenderId)) {
                    fileName = formattedFileName;
                    if ("Contract - Retail".equalsIgnoreCase(fileName) || "Contract - Lease".equalsIgnoreCase(fileName)
                        || "Contract - Balloon".equalsIgnoreCase(fileName)) {
                    	file.setContract(true);
                        return true;
                    }
                } else {
                    final DmsDocType dmsDocType = dmsdocTypeService.findDmsDocTypeByName(formattedFileName, dmsId);
                    if (null != dmsDocType) {
                        fileName = dmsDocType.getDocName();
                    }
                }

                if ("Contract".equalsIgnoreCase(fileName) || "Lease Agreement".equalsIgnoreCase(fileName)) {
                	file.setContract(true);
                    return true;
                }
            } catch (Exception e) {
                logger.error("", e);
            }
        }
        logger.debug("Exit doesDistributionHasContract");
        return false;
    }

    /**
     * @param ancillaryFiles
     * @return
     */
    @Override
    public boolean doesDistributionHasAncillaryContractFile(List<String> ancillaryFiles) {
        logger.debug("Entering doesDistributionHasAncillaryContractFile(List<String> ancillaryFiles) method");

        try {
            if (ancillaryFiles.contains("00001-Contract - Retail.xml")
                || ancillaryFiles.contains("00001-Contract - Lease.xml")
                || ancillaryFiles.contains("00001-Contract - Balloon.xml")) {
                return true;
            }
        } catch (Exception e) {
            logger.error("", e);
        }
        logger.debug("Exit doesDistributionHasAncillaryContractFile");
        return false;
    }

    @Override
    public boolean isEyesOnDocEnabled(final String dmsDealerId, final String lenderId, final DeLender lender)
        throws Exception {

        logger.debug("Enter isEyesOnDocEnabled (String dmsDealerId, String lenderId, DeLender lender) method > dmsDealerId: {}, lenderId: {}", dmsDealerId, lenderId);
        DealerPpNvp dealerPpNvp = dealerPpNvpService.findEyesOnDocFlag(dmsDealerId, lenderId);

        if (null != dealerPpNvp && AppConstants.EYES_ON_DOC_FLAG_YES.equalsIgnoreCase(dealerPpNvp.getParmValue())
            && AppConstants.EYES_ON_DOC_FLAG_YES.equalsIgnoreCase(lender.getEyes_on_doc())) {
            return true;
        }
        logger.debug("Exit isEyesOnDocEnabled");
        return false;
    }

    @Override
    public boolean isLeaseWorksheetValid(List<File> files) throws Exception {

        logger.debug("Entered isLeaseWorksheetValid method");
        for (File file : files) {
            if (file.getFilename().endsWith(".pdf")) {
                String formattedFileName = HandlerUtils.getFormattedFileName(file);
                if (AppConstants.DOC_NAME_LEASE_WORKSHEET.equalsIgnoreCase(formattedFileName)) {
                    InputStream leaseWorksheetStream = new ByteArrayInputStream(file.getContents());
                    PDFTextStripper stripper = new PDFTextStripper();
                    PDDocument pdDoc = null;

                    try {
                        pdDoc = PDDocument.load(leaseWorksheetStream);
                        String pdfText = stripper.getText(pdDoc);
                        List<String> pdfTextLines = Arrays.asList(pdfText.split("\\r\\n"));

                        for (String pdfTextLine : pdfTextLines) {
                            if (pdfTextLine.contains(leaseWorksheetKey) || pdfTextLine.equals(leaseWorksheetKey)) {
                                return true;
                            }
                        }
                    } catch (Exception e) {
                        throw e;
                    } finally {
                        if (null != pdDoc) {
                            pdDoc.close();
                        }
                    }
                }
            }
        }

        return false;
    }

    @Override
    public boolean vaultDocIdExists(final String vaultDocId) {
        logger.debug("Entered method vaultDocIdExists(String vaultDocId)");
        if (vaultDocId == null || vaultDocId.isEmpty()) {
            return false;
        }
        return true;
    }

    @Override
    public boolean isContractInApprovedFormList(final List<File> files, final FormsDAO formsDao, final String partyId) {
        logger.debug("Entered method isContractInApprovedFormList()");
        // get the Contract.xml file
        String dmsFormName = null;
        String dmsRevDate = null;
        Document ancillaryDataFile = null;
        for (File file : files) {
            String fileName = file.getFilename();
            if (fileName.contains(AppConstants.CONTRACT_NAME_RR)) {
                ancillaryDataFile = file.getAncillaryData();
                break;
            }
        }

        if (null != ancillaryDataFile) {
            try {
                dmsFormName = HandlerUtils.evaluateExpression(ancillaryDataFile,
                    XMLConstants.ancillaryformDataDocNamePath);

                dmsRevDate = HandlerUtils.evaluateExpression(ancillaryDataFile,
                    XMLConstants.ANCILLARY_FORM_DATA_DOCUMENT_VERSION_XPATH);
                // Format revisonDate to dsp_rev in forms table
                // input format: MM/yy
                SimpleDateFormat parser = new SimpleDateFormat(
                    AppConstants.ANCILLARY_CONTRACT_XML_REVISION_DATE_FORMAT);
                // output format: yyyy-MM-dd
                SimpleDateFormat formatter = new SimpleDateFormat(AppConstants.FORMS_DSP_REV_DATE_FORMAT);
                String formattedRevisionDate = formatter.format(parser.parse(dmsRevDate));
                List<Forms> forms = formsDao.findForms(dmsFormName, formattedRevisionDate, partyId);

                if (null != forms && forms.size() > 0) {
                    return true;
                }
            } catch (Exception e) {
                logger.warn(e.getMessage());
                logger.warn("Unable to fetch form info from the contract.xml file");
            }
        }
        return false;
    }

    @Override
    public boolean isVCIContract(final String docName) {
        logger.debug("Entered method isVCIContract(String docName)");

        if (AppConstants.CONTRACT_RETAIL_VCI.equalsIgnoreCase(docName)
            || AppConstants.CONTRACT_LEASE_VCI.equalsIgnoreCase(docName)
            || AppConstants.CONTRACT_BALLOON_VCI.equalsIgnoreCase(docName)) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isContract(final String docName) {
        logger.debug("Entered method isContract(String docName)");
        if (AppConstants.CONTRACT_NAME.equalsIgnoreCase(docName)) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isEForm(final String formType) {
        logger.debug("Entered method isEForm(String formType)");
        if ("eform".equalsIgnoreCase(formType)) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isDeDealNew(final DeDeal deDeal) {
        logger.debug("Entered method isDeDealNew(DeDeal deDeal)");

        String status = deDeal.getFundingStatus();
        if (status == null || status.isEmpty()) {
            return true;
        }

        return false;
    }

    @Override
    public boolean previousDistributionExists(final List<DcDistribution> distributions) {
        logger.debug("Entered method previousDistributionExists(List<DcDistribution> distributions)");
        if (null != distributions && !distributions.isEmpty()) {
            for (DcDistribution distribution : distributions) {
                if (null != distribution.getDist_status()
                    && AppConstants.DOCUMENT_STATUS_DISTRIBUTED.equalsIgnoreCase(distribution.getDist_status())) {
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public Boolean isADPRequiredForm(final File file) throws Exception {
        logger.debug("Entered method isADPRequiredForm(File file)");
        if (file == null) {
            return false;
        }
        boolean requiredForm = false;
        int hyphenLocation = file.getFilename().indexOf("-");
        if (hyphenLocation >= 0) {
            try {
                String textBeforeHyphen = file.getFilename().substring(0, hyphenLocation);
                Integer.parseInt(textBeforeHyphen);
                requiredForm = true;
            } catch (NumberFormatException e) {
                logger.debug("could not parse to number", e);
            }
        }
        return requiredForm;
    }

    @Override
    public Boolean isRequiredForm(final List<DcForm> dcForms) throws Exception {
        logger.debug("Entered isRequiredForm()");
        boolean requiredForm = false;

        if (null != dcForms && !dcForms.isEmpty()) {
            // The top form will always be the most recent. Ordered by
            // CREATED_DT, DESC.
            DcForm dcForm = dcForms.get(0);
            String requiredFormFlag = dcForm.getRequiredFormFlag();
            if (null != requiredFormFlag && !requiredFormFlag.isEmpty()
                && AppConstants.REQUIRED_FORM_FLAG_YES.equalsIgnoreCase(requiredFormFlag)) {
                requiredForm = true;
            }
        }
        return requiredForm;
    }

    @Override
    public void checkVaultStatus(DeDeal deDeal, VaultRegisterDocument vaultDocRecord, ErrorDetail errorDetail)
        throws ApplicationException {
        logger.debug(
            "Entered method checkVaultStatus(DeDeal deDeal, VaultRegisterDocument vaultDocRecord, ErrorDetail errorDetail)");
        if (vaultDocRecord == null) { // If there is no record in
            // VaultRegisterDocument table
            logger.error("DeDeal is not in 'Assigned' econtract status, deDealId:{}, eContractStatus:{}",
                deDeal.getDealId(), deDeal.getEconStatus());
            throw new ApplicationException(errorDetail.add(AppConstants.VAULTSTATUS_NULL_OR_BLANK_ERROR_MESSAGE,
                AppConstants.VAULTSTATUS_NULL_OR_BLANK_CODE));
        }
        logger.error("DeDeal is not in 'Assigned' econtract status, deDealId:{}, eContractStatus:{}",
            deDeal.getDealId(), deDeal.getEconStatus());
        throw new ApplicationException(errorDetail.add(AppConstants.VAULTSTATUS_NOT_ASSIGNED_ERROR_MESSAGE,
            AppConstants.VAULTSTATUS_NOT_ASSIGNED_CODE));
    }

    @Override
    public boolean isVCILender(final String lenderId) {
        return lenderId.equals("VCI") || lenderId.equals("AFS");
    }

    @Override
    public void validateEconStatus(DeDeal deDeal) throws ApplicationException {

        logger.debug("Entered ValidateEconStatus method in ValiadationUitl class");

        if (!AppConstants.ECON_STATUS_ASSIGNED.equalsIgnoreCase(deDeal.getEconStatus())) {
            logger.debug(AppConstants.DE_DEAL_NOT_ASSIGNED_MESSAGE);

            throw new ApplicationException(AppConstants.DE_DEAL_NOT_ASSIGNED_MESSAGE,
                AppConstants.DE_DEAL_NOT_ASSIGNED_CODE);
        }

    }

    @Override
    public boolean isCDKDeal(final String dmsId) {
    	return ("AD".equalsIgnoreCase(dmsId) || "CDK".equalsIgnoreCase(dmsId));
    }
    
    /**
     * Call Common Service API to determine whether RouteOne transaction enabled for this lender/dealer/product combination
     */
    @Override
    public boolean isRouteOneTransaction(String lenderId, String dealerId, String dmsId, String productId) throws ApplicationException {
    	logger.debug("isRouteOneTransaction: lenderId > " + lenderId + ", dealerId > " + dealerId + ", dmsId > " + dmsId + ", productId > " + productId);
    	boolean isRouteOne = false;
    	try {
	    	RestTemplate restTemplate = new RestTemplate();
	    	String url = commonServiceURL + "/routeoneFlag";
	    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
	    	        										   .queryParam("dealerId", dealerId)
	    	        										   .queryParam("lenderId", lenderId)
	    	        										   .queryParam("productId", productId);
	    	logger.debug("CommonServices URL > " + builder.build().encode().toUri());
	    	ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(), Boolean.class);
	    	isRouteOne = response.getBody().booleanValue();
	    	logger.debug("RouteOne is " + (isRouteOne ? "" : "*not*") + " enabled for lenderId: {}, dealerId: {}, productId: {}", lenderId, dealerId, productId);
    	} catch (Exception e) {
    		logger.error("Cannot determine if RouteOne integration enabled for this lender and dealer, ", e);
    		throw new ApplicationException(AppConstants.ROUTEONE_DETERMINATION_FAILURE_ERROR_CODE, AppConstants.ROUTEONE_DETERMINATION_FAILURE_MESSAGE);
    	}
    	return isRouteOne;
    }
    
    @Override
    public boolean isNewCVWorkflow(String lenderId, String dealerId, String dmsId, String productId) throws ApplicationException {
    	logger.debug("isNewCVWorkflow: lenderId > " + lenderId + ", dealerId > " + dealerId + ", dmsId > " + dmsId + ", productId > " + productId);
    	boolean isNewWorkFlow = false;
    	try {
	    	RestTemplate restTemplate = new RestTemplate();
	    	String url = commonServiceURL + "/isNewCVWorkflow";
	    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
	    	        										   .queryParam("dealerId", dealerId)
	    	        										   .queryParam("lenderId", lenderId)
	    	        										   .queryParam("productId", productId)
	    														.queryParam("dmsId", dmsId);
	    	logger.debug("CommonServices URL > " + builder.build().encode().toUri());
	    	ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(), Boolean.class);
	    	isNewWorkFlow = response.getBody().booleanValue();
	    	logger.debug("New workflow is " + (isNewWorkFlow ? "" : "*not*") + " enabled for lenderId: {}, dealerId: {}, productId: {}, dmsId: {}", lenderId, dealerId, productId, dmsId);
    	} catch (Exception e) {
    		logger.error("Cannot determine if RouteOne integration enabled for this lender and dealer, ", e);
    		throw new ApplicationException(AppConstants.ROUTEONE_DETERMINATION_FAILURE_ERROR_CODE, AppConstants.ROUTEONE_DETERMINATION_FAILURE_MESSAGE);
    	}
    	return isNewWorkFlow;
    }
}
