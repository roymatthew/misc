package com.ode.edocs.util;

import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.vault.ws.client.AssignDocumentRequest;
import com.ode.vault.ws.client.AssignDocumentResponse;
import com.ode.vault.ws.client.LoginRequest;
import com.ode.vault.ws.client.LoginResponse;
import com.ode.vault.ws.client.LogoutRequest;
import com.ode.vault.ws.client.LogoutResponse;
import com.ode.vault.ws.client.SearchRequest;
import com.ode.vault.ws.client.SearchResponse;
import com.ode.vault.ws.client.SearchResponse.Document;
import com.ode.vault.ws.client.VaultBindingImpl;
import com.ode.vault.ws.client.WithdrawDocumentRequest;
import com.ode.vault.ws.client.WithdrawDocumentResponse;
import java.math.BigInteger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class VaultUtil {
    @Value("${vaultServiceUrl}")
    private String vaultServiceUrl;
    private static final Logger logger = LogManager.getLogger(VaultUtil.class);

    @Autowired
    private MailSender mailSender;
    @Autowired
    private VaultBindingImpl vault;
    @Autowired
    private IValidationUtil validationUtil;

    @Value("${vaultOrganization}")
    String vaultOrganization;
    @Value("${vaultUsername}")
    String vaultUsername;
    @Value("${vaultPassword}")
    String vaultPassword;

    /**
     * @param deDeal
     * @return
     */
    public String vaultLogin(final DeDeal deDeal) {
        logger.debug("Entered vaultLogin(DeDeal deDeal) method");
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setOrganization(vaultOrganization);
        loginRequest.setUsername(vaultUsername);
        loginRequest.setPassword(vaultPassword);
        LoginResponse loginResponse = null;
        loginResponse = vault.login(loginRequest);
        if (null != loginResponse) {
            String token = loginResponse.getToken();
            logger.debug("token:{}", token);
            if (loginResponse.getResponseCode() == null
                || !loginResponse.getResponseCode().equals(AppConstants.VAULT_LOGIN_SUCCESSFUL)) {
                logger.error("login failed with response:(" + loginResponse.getResponseCode() + ") "
                    + loginResponse.getResponseMessage());
                mailSender.sendVaultEmail("login failed with response:(" + loginResponse.getResponseCode() + ") "
                    + loginResponse.getResponseMessage(), deDeal, null);
            }
            return token;
        }
        logger.error("null response from login request");
        mailSender.sendVaultEmail("login failed with null response.", deDeal, null);
        return null;
    }

    /**
     * @param token
     * @param deDeal
     */
    private void vaultLogout(String token, DeDeal deDeal) {
        logger.debug("Entered vaultLogout(String token, DeDeal deDeal) method");
        LogoutRequest logoutRequest = new LogoutRequest();
        logoutRequest.setToken(token);
        LogoutResponse logoutResponse = null;
        logoutResponse = vault.logout(logoutRequest);
        if (null != logoutResponse) {
            logger.debug("response:({}) {}", logoutResponse.getResponseCode(), logoutResponse.getResponseMessage());
            if (logoutResponse.getResponseCode() == null
                || !logoutResponse.getResponseCode().equals(AppConstants.VAULT_LOGOUT_SUCCESSFUL)) {
                mailSender.sendVaultEmail("logout failed with response:(" + logoutResponse.getResponseCode() + ") "
                    + logoutResponse.getResponseMessage(), deDeal, null);
            }
        } else {
            mailSender.sendVaultEmail("logout failed with null response", deDeal, null);
            logger.error("null response from logout request");
        }

    }

    public SearchResponse.Document vaultSearch(String documentId, String token, boolean assigned, DeDeal deDeal) {
        logger.debug("Entered vaultLogout(String token, DeDeal deDeal) method");
        SearchResponse.Document doc;
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.setToken(token);
        searchRequest.setDocumentId(documentId);
        logger.debug("searching for Accepted/Pending Acceptance doc");
        searchRequest.getStatus().add(BigInteger.valueOf(20)); // ACCEPTED
        searchRequest.getStatus().add(BigInteger.valueOf(21)); // PENDING_ACCEPTANCE

        SearchResponse searchResponse = null;
        searchResponse = vault.search(searchRequest);
        if (null != searchResponse) {

            logger.debug(searchResponse);
            int resultSize = searchResponse.getDocument().size();
            logger.debug("number of records found:{}", resultSize);
            if (resultSize < 1) {
                logger.warn("no documents found from search.");
                mailSender.sendVaultEmail("no documents found from search:", deDeal, null);
                return null;
            }
            doc = searchResponse.getDocument().get(0);
            logger.debug("documentId of first record:{}", doc.getDocumentId());
            logger.debug("transactionId of first record:{}", doc.getTransactionId());
            if (!AppConstants.VAULT_SEARCH_SUCCESSFUL.equalsIgnoreCase(searchResponse.getResponseCode())) {
                logger.error("search for documentId: " + documentId + " failed with response:("
                    + searchResponse.getResponseCode() + ") " + searchResponse.getResponseMessage());
                mailSender.sendVaultEmail("search for documentId: " + documentId + " failed with response:("
                    + searchResponse.getResponseCode() + ") " + searchResponse.getResponseMessage(), deDeal, null);
            }
            return doc;
        }
        logger.error("null response from search request");
        mailSender.sendVaultEmail("search for documentId: " + documentId + " failed with null response", deDeal, null);
        return null;
    }

    /**
     * @param vaultDocId
     * @param deDeal
     * @param lender
     * @return
     * @throws Exception
     */
    public boolean updateVaultStatus(String vaultDocId, DeDeal deDeal, DeLender lender) throws Exception {

        logger.debug("Entered updateVaultStatus()");
        boolean vaultAssignSuccess = false;
        if (null == vaultDocId || vaultDocId.isEmpty()) {
            logger.error("vault Doc Id is null or blank, cannot assign document");
        } else if (null == lender || null == lender.getVault_org_id()) {
            logger.error("lender's vault org id cannot be found, cannot assign document:{}", lender);
        } else {
            String token = vaultLogin(deDeal);
            AssignDocumentRequest assignRequest = new AssignDocumentRequest();
            assignRequest.setToken(token);
            assignRequest.setDocumentId(vaultDocId);
            assignRequest.setOrganizationId(String.valueOf(lender.getVault_org_id()));
            logger.debug(assignRequest);
            try {
                AssignDocumentResponse assignResponse = vault.assignDocument(assignRequest);
                logger.debug(assignResponse);
                if (null != assignResponse.getResponseCode()
                    && !assignResponse.getResponseCode().equals(AppConstants.VAULT_ASSIGN_SUCCESSFUL)) {
                    logger.error("unable to assign document");
                    mailSender.sendVaultEmail(
                        "Assign for " + deDeal.getVaultDocId() + " failed with Response Code: "
                            + assignResponse.getResponseCode() + " Message: " + assignResponse.getResponseMessage(),
                            deDeal, null);
                    vaultAssignSuccess = false;
                    if (validationUtil.isVCILender(lender.getLender_id())) {
                        throw new ApplicationException(
                            new ErrorDetail("Unable to assign the document", "assignDocument"));
                    }
                } else {
                    vaultAssignSuccess = true;
                    vaultLogout(token, deDeal);
                }

            } catch (Exception e) {
                logger.error("unable to assign document", e);

                mailSender.sendVaultEmail("Unable to assign document", deDeal, e);
                vaultAssignSuccess = false;
                if (validationUtil.isVCILender(lender.getLender_id())) {
                    throw new ApplicationException(new ErrorDetail("Unable to assign the document", "assignDocument"));
                }
            }
        }

        logger.debug("Exit updateVaultStatus()");
        return vaultAssignSuccess;
    }

    /**
     * VaultDocID and DeLender should be verified as existing before this is called. Will attempt to assign the
     * vaultDocId. If assign is unsuccessful, will do a vault search to see if document exists in the vault.
     *
     * Returns a response status as a string
     *
     * @param vaultDocId
     * @param deDeal
     * @param lender
     * @return
     */
    public String assignDocument(String vaultDocId, DeDeal deDeal, DeLender lender) throws Exception {

        logger.debug("Entered assignDocument()");
        String responseStatus = AppConstants.VAULT_ASSIGN_RESPONSE_SUCCESS;

        String token = vaultLogin(deDeal);
        AssignDocumentRequest assignRequest = new AssignDocumentRequest();
        assignRequest.setToken(token);
        assignRequest.setDocumentId(vaultDocId);
        assignRequest.setOrganizationId(String.valueOf(lender.getVault_org_id()));
        logger.debug(assignRequest);

        try {
            AssignDocumentResponse assignResponse = vault.assignDocument(assignRequest);
            logger.debug(assignResponse);
            if (null != assignResponse.getResponseCode()
                && !assignResponse.getResponseCode().equals(AppConstants.VAULT_ASSIGN_SUCCESSFUL)) {

                // There was an error when attempting to assign the document.
                // Do a vault search here to refine what error code we should return.
                SearchRequest searchRequest = new SearchRequest();
                searchRequest.setToken(token);
                searchRequest.setDocumentId(vaultDocId);
                logger.debug("SearchRequest: {}", searchRequest);
                SearchResponse searchResponse = vault.search(searchRequest);
                logger.debug("SearchResponse: {}", searchResponse);

                if (null != searchResponse && null != searchResponse.getDocument()
                    && !searchResponse.getDocument().isEmpty()) {
                    if (!AppConstants.VAULT_SEARCH_SUCCESSFUL.equalsIgnoreCase(searchResponse.getResponseCode())) {
                        // throw generic error here
                        logger.error("Graceful error - Error occurred in vault search function.");
                        responseStatus = AppConstants.VAULT_ASSIGN_RESPONSE_ERROR_WITH_DOC;
                        sendVaultEmail(deDeal, assignResponse, responseStatus);
                    } else {
                        for (Document document : searchResponse.getDocument()) {
                            if (null == document.getDocumentId()) {
                                logger.error("Graceful error - No document found in vault for docId: {}", vaultDocId);
                                responseStatus = AppConstants.VAULT_ASSIGN_RESPONSE_DOC_NOT_FOUND;
                                sendVaultEmail(deDeal, assignResponse, responseStatus);
                            } else {
                                // throw generic error here
                                logger.error("Graceful error - Unable to assign document");
                                responseStatus = AppConstants.VAULT_ASSIGN_RESPONSE_ERROR_WITH_DOC;
                                sendVaultEmail(deDeal, assignResponse, responseStatus);
                            }
                        }
                    }
                } else {
                    logger.error("Graceful error - No document found in vault for docId: {}", vaultDocId);
                    responseStatus = AppConstants.VAULT_ASSIGN_RESPONSE_DOC_NOT_FOUND;
                    sendVaultEmail(deDeal, assignResponse, responseStatus);
                }
            }

        } catch (Exception e) {
            logger.error("Unexpected error: Unable to assign document", e);
            responseStatus = AppConstants.VAULT_ASSIGN_RESPONSE_UNEXPECTED_ERROR;
            mailSender.sendVaultEmail("Unexpecter error while attempting to assign document", deDeal, e);
        } finally {
            vaultLogout(token, deDeal);
        }

        logger.debug("Exit assignDocument()");
        return responseStatus;
    }

    /**
     * @param vaultDocId
     * @param deDeal
     * @param lender
     * @return
     * @throws Exception
     */
    public String searchDocument(String vaultDocId, DeDeal deDeal, DeLender lender) throws Exception {

        logger.debug("Entered searchDocument()");
        String responseStatus = null;
        String token = vaultLogin(deDeal);

        try {
            SearchRequest searchRequest = new SearchRequest();
            searchRequest.setToken(token);
            searchRequest.setDocumentId(vaultDocId);

            logger.debug("SearchRequest: {}", searchRequest);
            SearchResponse searchResponse = vault.search(searchRequest);
            logger.debug("SearchResponse: {}", searchResponse);

            if (searchResponse == null
                || !AppConstants.VAULT_SEARCH_SUCCESSFUL.equalsIgnoreCase(searchResponse.getResponseCode())) {
                logger.error("Vault search error for doc id: {}", vaultDocId);
                responseStatus = AppConstants.VAULT_SEARCH_DOCUMENT_ERROR;
            } else {
                if (searchResponse.getDocument() == null || searchResponse.getDocument().isEmpty()) {
                    logger.debug("Return message - No document exists in vault for docId: {}", vaultDocId);
                    responseStatus = AppConstants.VAULT_SEARCH_DOCUMENT_NOT_EXIST;
                } else {
                    SearchResponse.Document vaultDoc = searchResponse.getDocument().get(0);
                    if (vaultDoc.getStatus().equals(new BigInteger("2"))) {
                        logger.debug("Return message - Active document found in vault for docId: {}", vaultDocId);
                        responseStatus = AppConstants.VAULT_SEARCH_DOCUMENT_ACTIVE_FOUND;
                    } else {
                        logger.debug("Return message - Inactive document found in vault for docId: {}", vaultDocId);
                        responseStatus = AppConstants.VAULT_SEARCH_DOCUMENT_INACTIVE_FOUND;
                    }
                }
            }

        } catch (Exception e) {
            logger.error("Error occured while executing vault search.", e);
            responseStatus = AppConstants.VAULT_SEARCH_DOCUMENT_ERROR;
            mailSender.sendVaultEmail("Error occured while executing vault search.", deDeal, e);
        } finally {
            vaultLogout(token, deDeal);
        }
        logger.debug("Exit searchDocument()");
        return responseStatus;
    }

    /**
     * @param vaultDocId
     * @param deDeal
     * @param dealerId
     * @param lender
     * @return
     * @throws Exception
     */
    public boolean vaultDocument(String vaultDocId, DeDeal deDeal, String dealerId, DeLender lender) throws Exception {

        logger.debug("Entered vaultDocument()");
        if (vaultDocId == null) {
            return false;
        }
        boolean assignDocumentToVault = false;
        try {
            assignDocumentToVault = updateVaultStatus(vaultDocId, deDeal, lender);
        } catch (Exception e) {
            logger.error("Vault error assigning document", e);
            ErrorDetail errorDetail = new ErrorDetail();
            errorDetail.setDealerId(deDeal.getDmsDealerId());
            errorDetail.setDealId(deDeal.getDealId());
            errorDetail.setDmsDealNum(deDeal.getDmsDealNum());
            errorDetail.setLenderId(lender.getLender_id());
            if (validationUtil.isVCILender(lender.getLender_id())) {
                ApplicationException ae = new ApplicationException(dealerId, AppConstants.VAULT_ASSIGN_FAILURE_MESSAGE,
                    AppConstants.VAULT_ASSIGN_FAILURE);
                ae.setErrorDetail(errorDetail);
                throw ae;
            }
            ApplicationException ae = new ApplicationException(dealerId, e, AppConstants.VAULT_ASSIGN_FAILURE);
            ae.setErrorDetail(errorDetail);
            throw ae;
        }
        logger.debug("Exit vaultDocument()");
        return assignDocumentToVault;
    }

    /**
     * @return
     */
    public MailSender getMailSender() {
        return mailSender;
    }

    /**
     * @param mailSender
     */
    public void setMailSender(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    /**
     * @param deDeal
     * @param assignResponse
     * @param responseStatus
     */
    private void sendVaultEmail(DeDeal deDeal, AssignDocumentResponse assignResponse, String responseStatus) {
        logger.debug(
            "Entered sendVaultEmail(DeDeal deDeal, AssignDocumentResponse assignResponse, String responseStatus) method");
        mailSender.sendVaultEmail(
            "Assign for " + deDeal.getVaultDocId() + " failed with Response Code: " + assignResponse.getResponseCode()
            + " Reason: " + responseStatus + ", " + assignResponse.getResponseMessage(),
            deDeal, null);

    }

    /**
     * VaultDocID should be verified as existing before this is called. Will attempt to withdraw the vaultDocId. Returns
     * a response status as a string
     *
     * @param vaultDocId
     * @param deDeal
     * @return
     */
    public String withdrawDocument(String vaultDocId, DeDeal deDeal) throws Exception {

        logger.debug("Enter withdrawDocument()");

        String responseStatus = AppConstants.VAULT_WITHDRAW_RESPONSE_SUCCESS;

        String token = vaultLogin(deDeal);

        WithdrawDocumentRequest withDrawRequest = setWithDrawRequest(vaultDocId, token);
        logger.debug("withdrawDocument request >> " + withDrawRequest);

        try {
            WithdrawDocumentResponse withDrawResponse = vault.withdrawDocument(withDrawRequest);
            logger.debug("withdrawDocument response >> " + withDrawResponse);

            if (null != withDrawResponse
                && !AppConstants.VAULT_WITHDRAW_SUCCESSFUL.equals(withDrawResponse.getResponseCode())) {
                responseStatus = AppConstants.VAULT_WITHDRAW_RESPONSE_FAILED;
                mailSender.sendVaultWithDrawEmail("Unable to withdraw vault process, withdraw failed", deDeal);
            }
        } catch (Exception e) {
            logger.error("Unexpected error:: Unable to withdraw document", e);
            responseStatus = AppConstants.VAULT_WITHDRAW_RESPONSE_UNEXPECTED_ERROR;
            mailSender.sendVaultEmail("Unexpected error while attempting to withdraw Vault process", deDeal, e);
        } finally {
            vaultLogout(token, deDeal);
        }
        logger.debug("Exit withdrawDocument()");
        return responseStatus;
    }

    /**
     * @param vaultDocId
     * @param token
     * @return
     */
    private WithdrawDocumentRequest setWithDrawRequest(final String vaultDocId, final String token) {

        final WithdrawDocumentRequest withDrawRequest = new WithdrawDocumentRequest();
        withDrawRequest.setToken(token);
        withDrawRequest.setDocumentId(vaultDocId);
        return withDrawRequest;
    }

}
