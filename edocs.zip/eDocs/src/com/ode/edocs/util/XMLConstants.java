package com.ode.edocs.util;

public class XMLConstants {

    public static final String digNameSpace = "http://www.opendealerexchange.com/DigitalDeal";
    public static final String starNameSpace = "http://www.starstandards.org/STAR";
    public static final String soapTransNameSpace = "http://www.starstandards.org/webservices/2005/10/transport";
    public static final String starDealerNumberPath = "//star:DealerNumber";
    public static final String starAuthorizationPath = "//star:AuthorizationId";
    public static final String starFinanceTypePath = "//star:FinanceType";
    public static final String starHeaderPath = "//star:Header";
    public static final String starBodyPath = "//star:Body";
    public static final String starDealIdPath = "//star:DealId";
    public static final String starPartyIdPath = "//star:FinanceCompany/star:PartyId";
    public static final String starApplicationNumberPath = "//star:ApplicationNumber";
    public static final String starBodIdPath = "//star:BODId";
    public static final String starsplPrgmPath = "//star:SpecialPrograms[starts-with(.,'XX') or starts-with(.,'xx')]";
    public static final String soapTransAttachmentDataPath = "//soaptrans:attachmentData";
    public static final String soapTransFileNamePath = "//soaptrans:fileName";
    public static final String ancillaryformDataDocNamePath = "//AncillaryFormData/DocumentName";
    public static final String ANCILLARY_FORM_DATA_DOCUMENT_VERSION_XPATH = "//AncillaryFormData/DocumentVersionDate";
    public static final String digFileContentPath = "//dig:FileContent";
    public static final String routeOneContentPath = "//Document";
    public static final String emptySpacePath = "\\s+";
    public static final String starCreatorNameCodePath = "//star:CreatorNameCode";
    public static final String starDealerNumberCodePath = "//star:DealerNumber";
    public static final String authorizationId = "//star:AuthorizationId";
    public static final String starStoreNumber = "//star:StoreNumber";
    public static final String starDestinationNameCode = "//star:DestinationNameCode";
    public static final String starDestinationPath = "//star:Destination";
    public static final String signatureName = "//star:AdditionalContractAttribute[star:AttributeName='ContractSignatureConfirmation']/star:AttributeName";
    public static final String signatureValue = "//star:AdditionalContractAttribute[star:AttributeName='ContractSignatureConfirmation']/star:AttributeValue";
    public static final String starApplicationTypePath = "//star:CreditContract/star:Header/star:ApplicationType";
    public static final String starValidationResultsPath = "//star:ValidationResults";
    public static final String starProcessCreditPath = "//star:ProcessCreditContract";
    public static final String starDocumentIdpath = "//star:DocumentId";
    public static final String starContractDocNamePath = "//star:AdditionalContractAttribute[star:AttributeName='docName:";
    public static final String ancillaryFormPath = "//AncillaryFormData/eSigned";
    public static final String starRouteOneProcessCreditContract = "ContractPackage/RouteOneProcessCreditContract";
    public static final String starRouteOneApplicationNumber = "ContractPackage/RouteOneProcessCreditContract/DataArea/CreditContract/Header/ApplicationNumber[@desc='Retail System Provider']";
    public static final String payloadManifestPath = "//star:payloadManifest";
    public static final String processCreditContractPath = "//star:ProcessCreditContract";
    public static final String putMessagetPath = "//star:PutMessage";
    

}
