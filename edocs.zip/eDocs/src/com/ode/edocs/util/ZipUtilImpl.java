package com.ode.edocs.util;

import com.ode.edocs.File;
import com.ode.edocs.bo.DistributionFile;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import com.ode.edocs.vo.AttachmentProcessingVO;
import com.ode.edocs.vo.DistributionPacket;
import com.ode.edocs.vo.DistributionProcessingVO;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ZipUtilImpl implements IZipUtil {

    private static final Logger logger = LogManager.getLogger(ZipUtilImpl.class);

    @Autowired
    private IValidationUtil validationUtil;

    private String ewzf = "error writing Zip File";
    private String emzp = "Exited method ZipUtil-processZipAttachmentFile...";

    @Value("${attachmentDirLoc}")
    private String attachmentDirLoc;

    @Value("${fileSizeLimit}")
    private String fileSizeLimit;

    @Value("${fileResolutionLimit}")
    private int fileResolutionLimit;

    /**
     * {@inheritDoc}
     */
    @Override
    public String getZipAttachmentLocation(String deDealId, String sequenceId, String dealerId, String attachmentDirLoc)
        throws Exception {
        logger.debug("Entered get ZipAttachment location..");

        // determine zip file name
        String zipFileName = "XXXX.zip";
        if (null != deDealId && !deDealId.isEmpty() && null != sequenceId && !sequenceId.isEmpty()) {
            zipFileName = deDealId + sequenceId + ".zip";
        } else {
            logger.error("dealid:{} or sequence id:{} are null / empty. cannot create zip file.", deDealId, sequenceId);
            throw new ApplicationException(dealerId,
                "dealid or sequence id are null or empty. cannot read zip file, dealid:" + deDealId + ", seqid:"
                    + sequenceId,
                    AppConstants.DEALNUM_SEQUENCENO_NOT_FOUND);
        }

        logger.debug("zipFileName:{}", zipFileName);

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String formattedTimestamp = timestamp.toString().replaceAll("[^a-zA-Z0-9]", "_");
        String currentDate = formattedTimestamp.substring(0, 10);
        String dirWithTimeStamp = attachmentDirLoc + "/" + currentDate;
        java.io.File dirfile = new java.io.File(dirWithTimeStamp);
        if (!dirfile.exists()) {
            if (dirfile.mkdirs()) {
                logger.info("created directory " + dirWithTimeStamp);
                logger.debug("created directory", dirWithTimeStamp);
            } else {
                logger.error("Failed to create directory " + dirWithTimeStamp);
                logger.debug("Failed to create directory " + dirWithTimeStamp);
            }
        }
        String attachmentLoc = dirWithTimeStamp + "/" + zipFileName;
        logger.debug("Exited get ZipAttachment location..attachmentLoc is " + attachmentLoc);
        return attachmentLoc;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DistributionFile getFilesFromZip(String dealerId, String base64Zip, String attachmentLoc, String textFile) throws Exception {
        logger.debug("Entered getFilesFromZip method...");

        new ArrayList<File>();
        base64Zip = base64Zip.trim();
        byte[] byteArrayZip = EncryptionUtils.base64Decode(base64Zip);
        
        logger.debug("base64Zip string length: {}", base64Zip.length());
        
        /*
        // Write the base64 string to a text file for validation
        String base64DataFileLocation = attachmentLoc.substring(0, attachmentLoc.lastIndexOf("/")) + "/" + textFile;
        try {
        	logger.debug("Writing base64 string to location {}", textFile);
        	FileWriter myWriter = new FileWriter(base64DataFileLocation);
            myWriter.write(base64Zip);
            myWriter.close();
        }catch (Exception e) {
        	logger.debug("Error in writing base64 data to text file > ", e);
        }
        */

        // write zip file to file system
        java.io.File diskZipFile = null;
        try {
        	logger.debug("Writing ZIP file to > {}", attachmentLoc);
        	logger.debug("Size of zip bytes > {}", byteArrayZip.length);
            diskZipFile = new java.io.File(attachmentLoc);
            BufferedOutputStream zipBos = new BufferedOutputStream(new FileOutputStream(diskZipFile));
            zipBos.write(byteArrayZip);
            zipBos.close();
        } catch (IOException ioe) {
            logger.debug(ewzf, ioe);
            throw new ApplicationException(dealerId, ioe, AppConstants.ZIPFILE_WRITE_ERROR);
        } catch (Exception e) {
        	logger.debug(ewzf, e);
            throw new ApplicationException(dealerId, e, AppConstants.ZIPFILE_WRITE_ERROR);
        }

        // read zip file from file system
        ZipFile zipFile = null;
        try {
        	logger.debug("Reading and processing ZIP file");
            zipFile = new ZipFile(diskZipFile);
        } catch (IOException e) {
            logger.debug("Error reading zip file", e);
            throw new ApplicationException(dealerId, e, AppConstants.ZIPFILE_READ_ERROR_CODE);
        }

        // extract files from zip file
        DistributionFile f = extractFilesFromZip(zipFile);
        zipFile.close();
        return f;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @SuppressWarnings("rawtypes")
    public DistributionFile extractFilesFromZip(final ZipFile zipFile) throws Exception {

        List<File> files = new ArrayList<File>();
        List<String> ancillaries = new ArrayList<String>();
        DistributionFile f = new DistributionFile();

        ZipEntry entry = null;
        try {
            logger.debug("iterating through zip entries");
            if (null != zipFile) {
                Enumeration enumeration = zipFile.entries();
                while (enumeration.hasMoreElements()) {
                    entry = (ZipEntry) enumeration.nextElement();
                    logger.debug("zip entry:{}", entry);
                    if (null != entry) {
                        if (!entry.isDirectory()) {
                            String fullPath = entry.getName();
                            String filename = fullPath.substring(fullPath.lastIndexOf("/") + 1);
                            if (!filename.endsWith(".xml")) {
                                File file = new File();
                                file.setFilename(filename);
                                InputStream fileInputStream = zipFile.getInputStream(entry);
                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                IOUtils.copy(fileInputStream, baos);
                                file.setContents(baos.toByteArray());

                                // Get ancillary document, if available
                                if (filename.endsWith(".pdf")) {
                                    String ancillaryName = filename.replace(".pdf", ".xml");
                                    ZipEntry ancillaryEntry = zipFile.getEntry(ancillaryName);
                                    if (null != ancillaryEntry) {
                                        logger.debug("Ancillary file found:{}, entry:{}", ancillaryName,
                                            ancillaryEntry);
                                        InputStream ancillaryInputStream = zipFile.getInputStream(ancillaryEntry);
                                        Document ancillaryDocument = EdocsXmlUtils
                                            .getDocumentFromInputStream(ancillaryInputStream);
                                        file.setAncillaryData(ancillaryDocument);
                                    }
                                }

                                baos.close();
                                files.add(file);
                            } else {
                                ancillaries.add(filename);

                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            logger.error("error reading file from zip", e);
            throw new ApplicationException(AppConstants.ZIPFILE_READ_ERROR_MESSAGE,
                AppConstants.ZIPFILE_READ_ERROR_CODE, e);
        }

        f.setFiles(files);
        f.setAncillaries(ancillaries);

        return f;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte[] processZipAttachmentFile(final DistributionProcessingVO distributionProcessingVO,
        final AttachmentProcessingVO attachmentProcessingVO, final DeLender lender, final boolean eyesOnDocFlag,
        final ErrorDetail errorDetail) throws Exception {
        logger.entry();
        DistributionPacket distributionPacket = new DistributionPacket();
        final byte[] decodedBytes = EncryptionUtils.base64Decode(attachmentProcessingVO.getBase64Zip());
        byte[] bytes = new byte[2048];
        final boolean checkFileSize = AppConstants.FILE_SIZE_CHECK_FLAG_YES.equals(lender.getFile_size_check());
        boolean fileSizeChecked = false;
        
        if (validationUtil.isVCILender(lender.getLender_id()) && !eyesOnDocFlag) {
        	distributionPacket = HandlerUtils.removeAncillaryXmlFromAttachment(attachmentProcessingVO.getAttachmentLocation(), fileSizeLimit, checkFileSize);
        	bytes = distributionPacket.getData();
        	fileSizeChecked = true;
            
        	// after removing, write new zip file to file system
            String newZipFileName = distributionProcessingVO.getDeDealId()
                + distributionProcessingVO.getDistributionSequenceId() + "-EDOCOUT" + ".zip";
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            String formattedTimestamp = timestamp.toString().replaceAll("[^a-zA-Z0-9]", "_");
            String currentDate = formattedTimestamp.substring(0, 10);
            String dirWithTimeStamp = attachmentDirLoc + "/" + currentDate;
            String newAttachmentLoc = dirWithTimeStamp + "/" + newZipFileName;
            java.io.File newDiskZipFile = new java.io.File(newAttachmentLoc);
            try {
                if (!newDiskZipFile.exists()) {
                    BufferedOutputStream newZipBos = new BufferedOutputStream(new FileOutputStream(newDiskZipFile));
                    newZipBos.write(bytes);
                    newZipBos.close();
                }
            } catch (IOException e) {
                logger.error("error writing zip file", e);
                ApplicationException ae = new ApplicationException(distributionProcessingVO.getDealerId(), e,
                    AppConstants.ZIPFILE_WRITE_ERROR);
                ae.setErrorDetail(errorDetail);
                throw ae;
            }

        }

        if (checkFileSize) {
        	String errorMessage = null;
        	if (fileSizeChecked) {
        		logger.debug("File size already checked, getting error message (if any)");
        		errorMessage = distributionPacket.getFileCheckError();
        	} else {
        		logger.debug("Checking each file size in zip..");
        		errorMessage = HandlerUtils.fileSizeExceeded(attachmentProcessingVO.getAttachmentLocation(), fileSizeLimit).toString();
        	}
            if (!"".equals(errorMessage)) {
            	logger.debug(">> File size exceeded the limit, haulting the distribution process << {}", errorMessage);
                ApplicationException ae = new ApplicationException(distributionProcessingVO.getDealerId(),
                    AppConstants.FILE_SIZE_EXCEEDED_ERROR_MESSAGE + " " + errorMessage,
                    AppConstants.FILE_SIZE_EXCEEDED_ERROR);
                ae.setErrorDetail(errorDetail);
                throw ae;
            }
        }

        // check file resolution only for VCI RR
        if (validationUtil.isVCILender(lender.getLender_id())
            && AppConstants.DSP_REYNOLDS.equalsIgnoreCase(distributionProcessingVO.getDmsId())) {
            String resolutionErrorMessage = HandlerUtils.checkFileResolution(decodedBytes, fileResolutionLimit)
                .toString();
            if (!"".equals(resolutionErrorMessage)) {
                ApplicationException ae = new ApplicationException(distributionProcessingVO.getDealerId(),
                    resolutionErrorMessage, AppConstants.FILE_RESOLUTION_INVALID_ERROR);
                ae.setErrorDetail(errorDetail);
                throw ae;
            }
        }

        return logger.exit(bytes);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public AttachmentProcessingVO extractAttachmentParams(final DistributionProcessingVO distributionProcessingVO,
        ErrorDetail errorDetail) throws Exception {

        logger.debug("Enter extractAttachmentParams");
        AttachmentProcessingVO vo = new AttachmentProcessingVO();

        final String base64Zip = EdocsXmlUtils.getTextFromXpath(distributionProcessingVO.geteDocIn(),
            XMLConstants.soapTransAttachmentDataPath);

        final String attachmentLocation = getZipAttachmentLocation(distributionProcessingVO.getDeDealId(),
            distributionProcessingVO.getDistributionSequenceId(), distributionProcessingVO.getDealerId(),
            attachmentDirLoc);

        String textFile = distributionProcessingVO.getDeDealId() + "_" + distributionProcessingVO.getDistributionSequenceId() + "_" + distributionProcessingVO.getDealerId() + ".txt";
        DistributionFile distributionFile = getFilesFromZip(distributionProcessingVO.getDealerId(), base64Zip, attachmentLocation, textFile);
        vo.setBase64Zip(base64Zip);
        vo.setAttachmentLocation(attachmentLocation);
        vo.setDistributionFile(distributionFile);
        logger.debug("Exit extractAttachmentParams");

        return vo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stripAttachment(Document document, String xpathString, Namespace namespace) throws Exception {
        logger.debug("Entered method stripAttachment(Document document, String xpathString, Namespace namespace)");
        
        XPathExpression<Element> xpath = null;
        if (namespace != null) xpath = XPathFactory.instance().compile(xpathString, Filters.element(), null, namespace);
        else xpath = XPathFactory.instance().compile(xpathString, Filters.element(), null);
        List<Element> elements = xpath.evaluate(document);
        if (null != elements) {
            for (Element element : elements) {
                logger.debug("attachmentData found - replacing text");
                element.setText("attachment text replaced");
            }
        } else {
            logger.debug("attachmentData not found");
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getZipAttachmentLocation(String deDealId, String sequenceId, String dealerId) throws Exception {

        logger.debug("Entered getZipAttachmentLocation method");
        // determine zip file name
        String zipFileName = "XXXX.zip";
        if (null != deDealId && !deDealId.isEmpty() && null != sequenceId && !sequenceId.isEmpty()) {
            zipFileName = deDealId + sequenceId + ".zip";
        } else {
            logger.error("dealid:{} or sequence id:{} are null / empty. cannot create zip file.", deDealId, sequenceId);
            throw new ApplicationException(dealerId,
                "dealid or sequence id are null or empty. cannot read zip file, dealid:" + deDealId + ", seqid:"
                    + sequenceId,
                    AppConstants.DEALNUM_SEQUENCENO_NOT_FOUND);
        }

        logger.debug("zipFileName:{}", zipFileName);

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String formattedTimestamp = timestamp.toString().replaceAll("[^a-zA-Z0-9]", "_");
        String currentDate = formattedTimestamp.substring(0, 10);
        String dirWithTimeStamp = attachmentDirLoc + "/" + currentDate;
        java.io.File dirfile = new java.io.File(dirWithTimeStamp);
        if (!dirfile.exists()) {
            if (dirfile.mkdirs()) {
                logger.info("created directory " + dirWithTimeStamp);
            } else {
                logger.error("Failed to create directory " + dirWithTimeStamp);
            }
        }
        String attachmentLoc = dirWithTimeStamp + "/" + zipFileName;

        return attachmentLoc;

    }

    @Override
    public DistributionFile getFilesFromZip(String dealerId, String base64Zip, String attachmentLoc, ErrorDetail errorDetail) throws Exception {

        logger.debug("Entered getFilesFromZip method");
        new ArrayList<File>();
        byte[] byteArrayZip = EncryptionUtils.base64Decode(base64Zip);

        // write zip file to file system
        java.io.File diskZipFile = null;
        try {
            diskZipFile = new java.io.File(attachmentLoc);
            BufferedOutputStream zipBos = new BufferedOutputStream(new FileOutputStream(diskZipFile));
            zipBos.write(byteArrayZip);
            logger.debug("Zip file is written to the attachment folder");
            zipBos.close();
        } catch (IOException e) {
            logger.error("error writing zip file", e);
            ApplicationException ae = new ApplicationException(dealerId, e, AppConstants.ZIPFILE_WRITE_ERROR);
            ae.setErrorDetail(errorDetail);
            throw ae;
        }

        // read zip file from file system
        ZipFile zipFile = null;
        try {
        	logger.debug("Read zip file");
            zipFile = new ZipFile(diskZipFile);
        } catch (IOException e) {
            logger.error("error reading zip file", e);
            ApplicationException ae = new ApplicationException(dealerId, e, AppConstants.ZIPFILE_READ_ERROR_CODE);
            ae.setErrorDetail(errorDetail);
            throw ae;
        }

        // extract files from zip file
        DistributionFile f = extractFilesFromZip(zipFile);
        zipFile.close();

        return f;

    }

}
