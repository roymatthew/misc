package com.ode.edocs.util.enums;

import org.apache.commons.lang.StringUtils;
import com.ode.edocs.util.ApplicationException;

public enum DmsEnum {
  
  AR("AR", "Advent"), AD("AD", "Cdk"), CDK("CDK", "Ck"), RR("RR", "Reynolds");
  
  private String dmsId;  
  private String name;

  private DmsEnum(final String dmsId, final String name) {
    this.dmsId = dmsId;
    this.name = name;
  } 
  
  public String getDmsId() {
    return dmsId;
  }
  public void setDmsId(String dmsId) {
    this.dmsId = dmsId;
  }
  
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  
    /**
   * @param code
   * @return
     * @throws ApplicationException 
   */
  public static DmsEnum getDmsEnumByDmsId(final String dmsId) throws ApplicationException
  {
    if (StringUtils.isBlank(dmsId))
    {
      throw new ApplicationException("Invalid dmsId provided");
    }
    DmsEnum anEnum = null;
    
    if (CDK.getDmsId().equals(dmsId))
    {
      anEnum = CDK;
    }
    if (AD.getDmsId().equals(dmsId))
    {
      anEnum = AD;
    }
    else if (RR.getDmsId().equals(dmsId))
    {
      anEnum = RR;
    } else if (AR.getDmsId().equals(dmsId))
    {
    	anEnum = AR;
    }
      
    return anEnum;
  }
  

}
