package com.ode.edocs.util.enums;

public enum LenderEnum {

  ACF("ACF", "ACF", "Acf"), AFS("AFS", "AFS", "Afs"), BMW("BMW", "BMW", "Bmw"), CUC("CUC", "CUDC", "Cudc"), CUD("CUD",
      "CUD", "Cud"), ECO("ECO", "ECO", "Eco"), GMF("GMF", "GMF", "General Motors Financial"), MB("MB", "MBFS", "Mercedes Benz Financial Services"), MCS("MCS",
          "MCS", "Mcs"), SMF("SMF", "SMF", "SMF"), VCF("VCF", "VCF", "Vcf"), 
  VOL("VOL", "VOL", "Vol"), VCI("VCI", "VCI", "VOLKSWAGEN"), JPM("JPM", "Chase", "Chase Auto Finance"), 
  SAF("SAF", "SAF", "SANTANDER AUTO FINANCE"), CHC("CHC", "CHC", "Chrysler Capital"), ODE("ODE", "ODE", "Test Lender"), GENERIC("GGG","NEW", "New Lender");
  
  private String lenderId;
  private String organization;
  private String name;

  LenderEnum(final String lenderId, final String organization, final String name) {
    this.lenderId = lenderId;
    this.organization = organization;
    this.name = name;
  }

  public String getLenderId() {
    return lenderId;
  }

  public void setLenderId(final String lenderId) {
    this.lenderId = lenderId;
  }

  public String getOrganization() {
    return organization;
  }

  public void setOrganization(final String organization) {
    this.organization = organization;
  }
  
  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  /**
   * @param lenderId
   * @return LenderEnum
   */
  public static LenderEnum getLenderEnum(final String lenderId) {

    LenderEnum anEnum = null;

    switch (lenderId) {
      case "ACF":
        anEnum = ACF;
        break;
      case "AFS":
        anEnum = AFS;
        break;
      case "BMW":
        anEnum = BMW;
        break;
      case "CUC":
        anEnum = CUC;
        break;
      case "CUD":
        anEnum = CUD;
        break;
      case "ECO":
        break;
      case "GMF":
        anEnum = GMF;
        break;
      case "MB":
        anEnum = MB;
        break;
      case "MCS":
        anEnum = MCS;
        break;
      case "SMF":
        anEnum = SMF;
        break;
      case "VCF":
        anEnum = VCF;
        break;
      case "VOL":
          anEnum = VOL;
          break;
      case "VCI":
        anEnum = VCI;
        break;  
      case "JPM":
        anEnum = JPM;
        break; 
      default:
        anEnum = GENERIC;
        break;
    }
    return anEnum;
  }

}
