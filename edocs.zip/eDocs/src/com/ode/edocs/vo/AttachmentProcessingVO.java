package com.ode.edocs.vo;

import java.util.List;
import com.ode.edocs.File;
import com.ode.edocs.bo.DistributionFile;

public class AttachmentProcessingVO {  
  
  private String base64Zip;
  private String attachmentLocation;
  private DistributionFile distributionFile;
  private List<File> files;
  private List<String> ancillaryFiles;
  
  public String getBase64Zip() {
    return base64Zip;
  }
  public void setBase64Zip(String base64Zip) {
    this.base64Zip = base64Zip;
  }
  public String getAttachmentLocation() {
    return attachmentLocation;
  }
  public void setAttachmentLocation(String attachmentLocation) {
    this.attachmentLocation = attachmentLocation;
  }
  public DistributionFile getDistributionFile() {
    return distributionFile;
  }
  public void setDistributionFile(DistributionFile distributionFile) {
    this.distributionFile = distributionFile;
  }
  public List<File> getFiles() {
    return distributionFile.getFiles();
  }
  public void setFiles(List<File> files) {
    this.files = files;
  }
  public List<String> getAncillaryFiles() {
    return distributionFile.getAncillaries();
  }
  public void setAncillaryFiles(List<String> ancillaryFiles) {
    this.ancillaryFiles = ancillaryFiles;
  }

}
