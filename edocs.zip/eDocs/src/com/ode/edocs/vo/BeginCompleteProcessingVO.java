package com.ode.edocs.vo;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.db.entity.DePartnerDestination;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public class BeginCompleteProcessingVO {

    private Document eDocIn;
    private Date timeStamp;
    private BigInteger edocInCjKey;
    private String sequenceId;
    private List<File> files;
    private String processedBase64Zip;
    private String transactionId;
    private String accountId;
    private String indValue;
    private boolean isEyesOnDoc;
    private String dealerId;
    private String deDealId;
    private String cvSequenceId;
    private Document ecout;
    private String dmsId;
    private String lenderId;
    private Document ecIn;
    private String applicationType;
    private String contractId;
    private BigInteger edocOutCjKey;
    private String vaultDocId;
    private DeLenderDestination lenderDest;
	private DePartnerDestination partnerDestination;

    public BeginCompleteProcessingVO() {
        super();
        contractId = "";
    }
    
    public String getVaultDocId() {
		return vaultDocId;
	}

	public void setVaultDocId(String vaultDocId) {
		this.vaultDocId = vaultDocId;
	}

	public DeLenderDestination getLenderDest() {
		return lenderDest;
	}

	public void setLenderDest(DeLenderDestination lenderDest) {
		this.lenderDest = lenderDest;
	}

	public DePartnerDestination getPartnerDestination() {
		return partnerDestination;
	}

	public void setPartnerDestination(DePartnerDestination partnerDestination) {
		this.partnerDestination = partnerDestination;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public BigInteger getEdocOutCjKey() {
        return edocOutCjKey;
    }

    public void setEdocOutCjKey(BigInteger edocOutCjKey) {
        this.edocOutCjKey = edocOutCjKey;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getDeDealId() {
        return deDealId;
    }

    public void setDeDealId(String deDealId) {
        this.deDealId = deDealId;
    }

    public String getCvSequenceId() {
        return cvSequenceId;
    }

    public void setCvSequenceId(String cvSequenceId) {
        this.cvSequenceId = cvSequenceId;
    }

    public Document getEcout() {
        return ecout;
    }

    public void setEcout(Document ecout) {
        this.ecout = ecout;
    }

    public String getDmsId() {
        return dmsId;
    }

    public void setDmsId(String dmsId) {
        this.dmsId = dmsId;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public Document getEcIn() {
        return ecIn;
    }

    public void setEcIn(Document ecIn) {
        this.ecIn = ecIn;
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public Document geteDocIn() {
        return eDocIn;
    }

    public void seteDocIn(Document eDocIn) {
        this.eDocIn = eDocIn;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public BigInteger getEdocInCjKey() {
        return edocInCjKey;
    }

    public void setEdocInCjKey(BigInteger edocInCjKey) {
        this.edocInCjKey = edocInCjKey;
    }

    public String getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(String sequenceId) {
        this.sequenceId = sequenceId;
    }

    public List<File> getFiles() {
        return files;
    }

    public void setFiles(List<File> files) {
        this.files = files;
    }

    public String getProcessedBase64Zip() {
        return processedBase64Zip;
    }

    public void setProcessedBase64Zip(String processedBase64Zip) {
        this.processedBase64Zip = processedBase64Zip;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getIndValue() {
        return indValue;
    }

    public void setIndValue(String indValue) {
        this.indValue = indValue;
    }

    public boolean isEyesOnDoc() {
        return isEyesOnDoc;
    }

    public void setEyesOnDoc(boolean isEyesOnDoc) {
        this.isEyesOnDoc = isEyesOnDoc;
    }

	@Override
	public String toString() {
		return "BeginCompleteProcessingVO [timeStamp=" + timeStamp + ", edocInCjKey=" + edocInCjKey + ", sequenceId="
				+ sequenceId + ", processedBase64Zip=" + processedBase64Zip + ", transactionId=" + transactionId
				+ ", accountId=" + accountId + ", indValue=" + indValue + ", isEyesOnDoc=" + isEyesOnDoc + ", dealerId="
				+ dealerId + ", deDealId=" + deDealId + ", cvSequenceId=" + cvSequenceId + ", dmsId=" + dmsId
				+ ", lenderId=" + lenderId + ", applicationType=" + applicationType + ", contractId=" + contractId
				+ ", edocOutCjKey=" + edocOutCjKey + ", vaultDocId=" + vaultDocId + "]";
	}
}
