package com.ode.edocs.vo;

import com.ode.edocs.File;
import com.ode.edocs.ReCVData;
import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.db.entity.CreditJournal;
import com.ode.edocs.db.entity.DeContractValidation;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.rest.entity.ErrorDetail;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import org.jdom2.Document;

public class BeginDistributeParmetersVO {

  private Document eDocsIncomingDocument;
  private Date timeStamp;
  private DmsBO dmsBO;
  private DeLender lender;
  private DeDeal deal;
  private ReCVData autoReCVData;
  private BigInteger edocsIncomingCreditJournalKey;
  private String sequenceId;
  private List<File> files;
  private String processedBase64Zip;
  private CreditJournal creditJournalEcout;
  private DeContractValidation contractValidation;
  private String transactionId;
  private String accountId;
  private String vaultIndicatorValue;
  private boolean isEyesOnDoc;
  private ErrorDetail errorDetail;


  /**
   * @param eDocsIncomingDocument
   * @param dmsBO
   * @param lender
   * @param deal
   */
  public BeginDistributeParmetersVO(final Document eDocsIncomingDocument, final DmsBO dmsBO,
      final DeLender lender, final DeDeal deal) {
    seteDocsIncomingDocument(eDocsIncomingDocument);
    setDmsBO(dmsBO);
    setLender(lender);
    setDeal(deal);
  }

  /**
   * @param edocsIncomingCreditJournalKey BigInteger
   * @param creditJournalEcout CreditJournal
   */
  public BeginDistributeParmetersVO setCreditJournalParams(
      final BigInteger edocsIncomingCreditJournalKey, final CreditJournal creditJournalEcout) {
    setEdocsIncomingCreditJournalKey(edocsIncomingCreditJournalKey);
    setCreditJournalEcout(creditJournalEcout);
    return this;
  }

  /**
   * @param files
   * @param processedBase64Zip
   * @return
   */
  public BeginDistributeParmetersVO setFileParams(final List<File> files,
      final String processedBase64Zip) {
    setFiles(files);
    setProcessedBase64Zip(processedBase64Zip);
    return this;
  }

  /**
   * @param contractValidation
   * @param autoReCVData
   * @param eyesOnDoc
   * @param vaultIndicatorValue
   * @return
   */
  public BeginDistributeParmetersVO setContractValidationParams(
      final DeContractValidation contractValidation, final ReCVData autoReCVData,
      final boolean eyesOnDoc, final String vaultIndicatorValue) {
    setContractValidation(contractValidation);
    setAutoReCVData(autoReCVData);
    setEyesOnDoc(eyesOnDoc);
    setVaultIndicatorValue(vaultIndicatorValue);
    return this;
  }

  /**
   * @param timeStamp
   * @param errorDetail
   * @return
   */
  public BeginDistributeParmetersVO setErrorHandlingParameters(final Date timeStamp,
      final ErrorDetail errorDetail) {
    setTimeStamp(timeStamp);
    setErrorDetail(errorDetail);
    return this;
  }

  /**
   * @param sequenceId
   * @param transactionId
   * @param accountId
   * @return
   */
  public BeginDistributeParmetersVO setIds(final String sequenceId, final String transactionId,
      final String accountId) {
    setSequenceId(sequenceId);
    setTransactionId(transactionId);
    setAccountId(accountId);
    return this;
  }

  public Document geteDocsIncomingDocument() {
    return eDocsIncomingDocument;
  }

  public void seteDocsIncomingDocument(Document eDocsIncomingDocument) {
    this.eDocsIncomingDocument = eDocsIncomingDocument;
  }

  public Date getTimeStamp() {
    return timeStamp;
  }

  public void setTimeStamp(Date timeStamp) {
    this.timeStamp = timeStamp;
  }

  public DeLender getLender() {
    return lender;
  }

  public void setLender(DeLender lender) {
    this.lender = lender;
  }

  public DeDeal getDeal() {
    return deal;
  }

  public void setDeal(DeDeal deal) {
    this.deal = deal;
  }

  public ReCVData getAutoReCVData() {
    return autoReCVData;
  }

  public void setAutoReCVData(ReCVData autoReCVData) {
    this.autoReCVData = autoReCVData;
  }

  public BigInteger getEdocsIncomingCreditJournalKey() {
    return edocsIncomingCreditJournalKey;
  }

  public void setEdocsIncomingCreditJournalKey(BigInteger edocsIncomingCreditJournalKey) {
    this.edocsIncomingCreditJournalKey = edocsIncomingCreditJournalKey;
  }

  public String getSequenceId() {
    return sequenceId;
  }

  public void setSequenceId(String sequenceId) {
    this.sequenceId = sequenceId;
  }

  public List<File> getFiles() {
    return files;
  }

  public void setFiles(List<File> files) {
    this.files = files;
  }

  public String getProcessedBase64Zip() {
    return processedBase64Zip;
  }

  public void setProcessedBase64Zip(String processedBase64Zip) {
    this.processedBase64Zip = processedBase64Zip;
  }

  public CreditJournal getCreditJournalEcout() {
    return creditJournalEcout;
  }

  public void setCreditJournalEcout(CreditJournal creditJournalEcout) {
    this.creditJournalEcout = creditJournalEcout;
  }

  public DeContractValidation getContractValidation() {
    return contractValidation;
  }

  public void setContractValidation(DeContractValidation contractValidation) {
    this.contractValidation = contractValidation;
  }

  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getVaultIndicatorValue() {
    return vaultIndicatorValue;
  }

  public void setVaultIndicatorValue(String vaultIndicatorValue) {
    this.vaultIndicatorValue = vaultIndicatorValue;
  }

  public boolean isEyesOnDoc() {
    return isEyesOnDoc;
  }

  public void setEyesOnDoc(boolean isEyesOnDoc) {
    this.isEyesOnDoc = isEyesOnDoc;
  }

  public ErrorDetail getErrorDetail() {
    return errorDetail;
  }

  public void setErrorDetail(ErrorDetail errorDetail) {
    this.errorDetail = errorDetail;
  }

  public DmsBO getDmsBO() {
    return dmsBO;
  }

  public void setDmsBO(DmsBO dmsBO) {
    this.dmsBO = dmsBO;
  }

}
