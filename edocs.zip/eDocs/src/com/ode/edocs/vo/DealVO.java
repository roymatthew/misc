package com.ode.edocs.vo;

import java.util.Date;

public class DealVO {

  private String dealId;
  private String lenderDealerId;
  private String dmsDealerId;
  private String dmsDealNum;
  private String vaultDocId;
  private String lenderId;
  private String dmsId;
  private String financeType;
  private String vin;
  private String buyerFirstName;
  private String buyerLastName;
  private String caSequenceId;
  private String caApplicationNum;
  private String caStatus;
  private Date caStatusTs;
  private Date caSubmittedTs;
  private String cvSequenceId;
  private String cvStatus;
  private Date cvStatusTs;
  private Date cvSubmittedTs;
  private String lenderSeqNum;
  private String accountNum;
  private String fundingStatus;
  private Date fundingStatusTs;
  private Date distributionTs;
  private String econStatus;
  private Date econStatusTs;
  private Date econSubmittedTs;
  private String dealExecutionState;
  private Date contractDate;
  private String spotFlag;
  private String latestDistributionStatus;
  private String distributedCvSeqId;
  private String applicationType;
  @Override
  public String toString() {
    return "DealVO [dealId=" + dealId + ", lenderDealerId=" + lenderDealerId + ", dmsDealerId="
        + dmsDealerId + ", dmsDealNum=" + dmsDealNum + ", vaultDocId=" + vaultDocId + ", lenderId="
        + lenderId + ", dmsId=" + dmsId + ", financeType=" + financeType + ", vin=" + vin
        + ", buyerFirstName=" + buyerFirstName + ", buyerLastName=" + buyerLastName
        + ", caSequenceId=" + caSequenceId + ", caApplicationNum=" + caApplicationNum
        + ", caStatus=" + caStatus + ", caStatusTs=" + caStatusTs + ", caSubmittedTs="
        + caSubmittedTs + ", cvSequenceId=" + cvSequenceId + ", cvStatus=" + cvStatus
        + ", cvStatusTs=" + cvStatusTs + ", cvSubmittedTs=" + cvSubmittedTs + ", lenderSeqNum="
        + lenderSeqNum + ", accountNum=" + accountNum + ", fundingStatus=" + fundingStatus
        + ", fundingStatusTs=" + fundingStatusTs + ", distributionTs=" + distributionTs
        + ", econStatus=" + econStatus + ", econStatusTs=" + econStatusTs + ", econSubmittedTs="
        + econSubmittedTs + ", dealExecutionState=" + dealExecutionState + ", contractDate="
        + contractDate + ", spotFlag=" + spotFlag + ", latestDistributionStatus="
        + latestDistributionStatus + ", distributedCvSeqId=" + distributedCvSeqId
        + ", applicationType=" + applicationType + "]";
  }
  public String getDealId() {
    return dealId;
  }
  public void setDealId(String dealId) {
    this.dealId = dealId;
  }
  public String getLenderDealerId() {
    return lenderDealerId;
  }
  public void setLenderDealerId(String lenderDealerId) {
    this.lenderDealerId = lenderDealerId;
  }
  public String getDmsDealerId() {
    return dmsDealerId;
  }
  public void setDmsDealerId(String dmsDealerId) {
    this.dmsDealerId = dmsDealerId;
  }
  public String getDmsDealNum() {
    return dmsDealNum;
  }
  public void setDmsDealNum(String dmsDealNum) {
    this.dmsDealNum = dmsDealNum;
  }
  public String getVaultDocId() {
    return vaultDocId;
  }
  public void setVaultDocId(String vaultDocId) {
    this.vaultDocId = vaultDocId;
  }
  public String getLenderId() {
    return lenderId;
  }
  public void setLenderId(String lenderId) {
    this.lenderId = lenderId;
  }
  public String getDmsId() {
    return dmsId;
  }
  public void setDmsId(String dmsId) {
    this.dmsId = dmsId;
  }
  public String getFinanceType() {
    return financeType;
  }
  public void setFinanceType(String financeType) {
    this.financeType = financeType;
  }
  public String getVin() {
    return vin;
  }
  public void setVin(String vin) {
    this.vin = vin;
  }
  public String getBuyerFirstName() {
    return buyerFirstName;
  }
  public void setBuyerFirstName(String buyerFirstName) {
    this.buyerFirstName = buyerFirstName;
  }
  public String getBuyerLastName() {
    return buyerLastName;
  }
  public void setBuyerLastName(String buyerLastName) {
    this.buyerLastName = buyerLastName;
  }
  public String getCaSequenceId() {
    return caSequenceId;
  }
  public void setCaSequenceId(String caSequenceId) {
    this.caSequenceId = caSequenceId;
  }
  public String getCaApplicationNum() {
    return caApplicationNum;
  }
  public void setCaApplicationNum(String caApplicationNum) {
    this.caApplicationNum = caApplicationNum;
  }
  public String getCaStatus() {
    return caStatus;
  }
  public void setCaStatus(String caStatus) {
    this.caStatus = caStatus;
  }
  public Date getCaStatusTs() {
    return caStatusTs;
  }
  public void setCaStatusTs(Date caStatusTs) {
    this.caStatusTs = caStatusTs;
  }
  public Date getCaSubmittedTs() {
    return caSubmittedTs;
  }
  public void setCaSubmittedTs(Date caSubmittedTs) {
    this.caSubmittedTs = caSubmittedTs;
  }
  public String getCvSequenceId() {
    return cvSequenceId;
  }
  public void setCvSequenceId(String cvSequenceId) {
    this.cvSequenceId = cvSequenceId;
  }
  public String getCvStatus() {
    return cvStatus;
  }
  public void setCvStatus(String cvStatus) {
    this.cvStatus = cvStatus;
  }
  public Date getCvStatusTs() {
    return cvStatusTs;
  }
  public void setCvStatusTs(Date cvStatusTs) {
    this.cvStatusTs = cvStatusTs;
  }
  public Date getCvSubmittedTs() {
    return cvSubmittedTs;
  }
  public void setCvSubmittedTs(Date cvSubmittedTs) {
    this.cvSubmittedTs = cvSubmittedTs;
  }
  public String getLenderSeqNum() {
    return lenderSeqNum;
  }
  public void setLenderSeqNum(String lenderSeqNum) {
    this.lenderSeqNum = lenderSeqNum;
  }
  public String getAccountNum() {
    return accountNum;
  }
  public void setAccountNum(String accountNum) {
    this.accountNum = accountNum;
  }
  public String getFundingStatus() {
    return fundingStatus;
  }
  public void setFundingStatus(String fundingStatus) {
    this.fundingStatus = fundingStatus;
  }
  public Date getFundingStatusTs() {
    return fundingStatusTs;
  }
  public void setFundingStatusTs(Date fundingStatusTs) {
    this.fundingStatusTs = fundingStatusTs;
  }
  public Date getDistributionTs() {
    return distributionTs;
  }
  public void setDistributionTs(Date distributionTs) {
    this.distributionTs = distributionTs;
  }
  public String getEconStatus() {
    return econStatus;
  }
  public void setEconStatus(String econStatus) {
    this.econStatus = econStatus;
  }
  public Date getEconStatusTs() {
    return econStatusTs;
  }
  public void setEconStatusTs(Date econStatusTs) {
    this.econStatusTs = econStatusTs;
  }
  public Date getEconSubmittedTs() {
    return econSubmittedTs;
  }
  public void setEconSubmittedTs(Date econSubmittedTs) {
    this.econSubmittedTs = econSubmittedTs;
  }
  public String getDealExecutionState() {
    return dealExecutionState;
  }
  public void setDealExecutionState(String dealExecutionState) {
    this.dealExecutionState = dealExecutionState;
  }
  public Date getContractDate() {
    return contractDate;
  }
  public void setContractDate(Date contractDate) {
    this.contractDate = contractDate;
  }
  public String getSpotFlag() {
    return spotFlag;
  }
  public void setSpotFlag(String spotFlag) {
    this.spotFlag = spotFlag;
  }
  public String getLatestDistributionStatus() {
    return latestDistributionStatus;
  }
  public void setLatestDistributionStatus(String latestDistributionStatus) {
    this.latestDistributionStatus = latestDistributionStatus;
  }
  public String getDistributedCvSeqId() {
    return distributedCvSeqId;
  }
  public void setDistributedCvSeqId(String distributedCvSeqId) {
    this.distributedCvSeqId = distributedCvSeqId;
  }
  public String getApplicationType() {
    return applicationType;
  }
  public void setApplicationType(String applicationType) {
    this.applicationType = applicationType;
  }
  
  

}
