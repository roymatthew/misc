package com.ode.edocs.vo;

import java.util.Arrays;

public class DistributionPacket {
	private byte data[];
	private String fileCheckError;
	
	public DistributionPacket() {
		this.data = new byte[2048];
		this.fileCheckError = "";
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getFileCheckError() {
		return fileCheckError;
	}

	public void setFileCheckError(String fileCheckError) {
		this.fileCheckError = fileCheckError;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(data);
		result = prime * result + ((fileCheckError == null) ? 0 : fileCheckError.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DistributionPacket other = (DistributionPacket) obj;
		if (!Arrays.equals(data, other.data))
			return false;
		if (fileCheckError == null) {
			if (other.fileCheckError != null)
				return false;
		} else if (!fileCheckError.equals(other.fileCheckError))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DistributionPacket [data=" + Arrays.toString(data) + ", fileCheckError=" + fileCheckError + "]";
	}
}
