package com.ode.edocs.vo;

import org.jdom2.Document;

public class DistributionProcessingVO {

    private String dmsId;
    private String dmsDealNumber;
    private String deDealId;
    private Document eDocIn;
    private String partyId;
    private String applicationNumber;
    private String distributionSequenceId;
    private String contractValidationSequenceNumber;
    private String dealerId;
    private String previousDistributionStatus;
    
    public DistributionProcessingVO() {
        super();
    }

    public DistributionProcessingVO(Document eDocIn) {
        super();
        this.eDocIn = eDocIn;
    }
    
    public String getPreviousDistributionStatus() {
		return previousDistributionStatus;
	}

	public void setPreviousDistributionStatus(String previousDistributionStatus) {
		this.previousDistributionStatus = previousDistributionStatus;
	}

	public String getDeDealId() {
        return deDealId;
    }

    public void setDeDealId(String deDealId) {
        this.deDealId = deDealId;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public Document geteDocIn() {
        return eDocIn;
    }

    public void seteDocIn(Document eDocIn) {
        this.eDocIn = eDocIn;
    }

    public String getApplicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(String applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    public String getDmsId() {
        return dmsId;
    }

    public void setDmsId(String dmsId) {
        this.dmsId = dmsId;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    @Override
    public String toString() {
        return "DistributionProcessingVO [dmsId=" + dmsId + ", dmsDealNumber=" + dmsDealNumber + ", deDealId="
            + deDealId + ", dealerId=" + dealerId + ", eDocIn=" + eDocIn + ", partyId=" + partyId
            + ", applicationNumber=" + applicationNumber + ", distributionSequenceId=" + distributionSequenceId
            + ", contractValidationSequenceNumber=" + contractValidationSequenceNumber + "]";
    }

    public String getDmsDealNumber() {
        return dmsDealNumber;
    }

    public void setDmsDealNumber(final String dmsDealNumber) {
        this.dmsDealNumber = dmsDealNumber;
    }

    public String getContractValidationSequenceNumber() {
        return contractValidationSequenceNumber;
    }

    public void setContractValidationSequenceNumber(String contractValidationSequenceNumber) {
        this.contractValidationSequenceNumber = contractValidationSequenceNumber;
    }

    public String getDistributionSequenceId() {
        return distributionSequenceId;
    }

    public void setDistributionSequenceId(String distributionSequenceId) {
        this.distributionSequenceId = distributionSequenceId;
    }

}
