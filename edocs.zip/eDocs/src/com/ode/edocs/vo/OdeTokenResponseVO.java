package com.ode.edocs.vo;

public class OdeTokenResponseVO {
    private int code;
    private String token;
    private String error;

    public OdeTokenResponseVO() {
        this.code = -1;
        this.token = "";
        this.error = "";
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

}
