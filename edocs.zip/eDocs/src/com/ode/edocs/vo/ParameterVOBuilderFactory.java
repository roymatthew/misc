package com.ode.edocs.vo;

import com.ode.edocs.bo.DmsBO;
import com.ode.edocs.db.entity.DeDeal;
import com.ode.edocs.db.entity.DeLender;
import org.jdom2.Document;

public class ParameterVOBuilderFactory {

    public static BeginDistributeParmetersVO createBeginDistributeParametersVO(final Document eDocsIncomingDocument, final DmsBO dmsBO, final DeLender lender, final DeDeal deal) {
        return new BeginDistributeParmetersVO(eDocsIncomingDocument, dmsBO, lender, deal);
    }

}
