package com.ode.edocs.xml;

import com.ode.edocs.File;
import com.ode.edocs.db.dao.DcOtherFormTypeDAO;
import com.ode.edocs.db.dao.ErrorLogDAO;
import com.ode.edocs.db.entity.*;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.EncryptionUtils;
import com.ode.edocs.util.XMLConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class DistributionSchemaRouteOne {
	private static final Logger logger = LogManager.getLogger(DistributionSchemaRouteOne.class);

    //private static Namespace starDefault = Namespace.getNamespace("http://www.starstandards.org/STAR");
    private static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");
    //private static Namespace dig = Namespace.getNamespace("dig", "http://www.opendealerexchange.com/DigitalDeal");
    //private static Namespace wsse = Namespace.getNamespace("wsse", "http://schemas.xmlsoap.org/ws/2002/07/secext");
    //private static Namespace wsu = Namespace.getNamespace("wsu", "http://schemas.xmlsoap.org/ws/2002/07/utility");
    //private static Namespace soapenv = Namespace.getNamespace("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");

    @Autowired
    private ErrorLogDAO errorLogDAO;

    @Autowired
    private DcOtherFormTypeDAO dcOtherFormTypeDAO;

    /**
     *
     * @param isInitial - initial / trailing package
     * @param ecout
     * @param files
     * @param dmsId
     * @param dealId
     * @param lender
     * @param partnerDestination
     * @param input
     * @return
     * @throws Exception
     */
    public Document createOutgoingXml(boolean isInitial, Document ecout, List<File> files, String dmsId, String dealId,
                                      DeLender lender, DePartnerDestination partnerDestination,
                                      Map<String, String> input, String bodId, String dealerId) throws Exception {
    	logger.debug("isInitial > " + isInitial + ", dmsId > " + dmsId + ", lenderId > " + lender.getLender_id() + ", dealId > " + dealId);
    	logger.debug(partnerDestination.toString());

            // create document & root element
            Document outDoc = new Document();

            Element rootElement = new Element("ContractPackage"); //, starDefault
            //rootElement.addNamespaceDeclaration(soapenv);
            //rootElement.addNamespaceDeclaration(dig);
            //rootElement.setNamespace(soapenv);

            Element element = new Element ("PartnerFSID");
            element.setText(input.get("partyId"));
            rootElement.addContent(element);

            if (isInitial) {
            	element = new Element ("RouteOneCreditApplicationConversationID");
                element.setText(input.get("applicationNumber"));
                rootElement.addContent(element);

                element = new Element ("AssignmentUserId");
                element.setText(input.get("authorizationId"));
                rootElement.addContent(element);

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
                String sdf = dateFormat.format(new Date());
                element = new Element ("AssignmentTimeStamp");
                element.setText(sdf);
                rootElement.addContent(element);
            } else {
            	element = new Element ("BODId");
            	element.setText(bodId);
            	rootElement.addContent(element);
            }

            element = new Element ("Comments");
            element.setText("");
            rootElement.addContent(element);
            Element ecout2ContractPackage = null;
            if (isInitial) {
	            element = new Element ("RouteOneProcessCreditContract");
	            if (null != ecout) {
	            	XPathExpression<Element> xpath = XPathFactory.instance().compile(XMLConstants.starRouteOneProcessCreditContract, Filters.element(), null, star);
	            	ecout2ContractPackage = xpath.evaluateFirst(ecout);
	                ecout2ContractPackage.detach();
	                element.addContent(ecout2ContractPackage.getChildren().get(0).clone());
	                element.addContent(ecout2ContractPackage.getChildren().get(1).clone());
	            }
	            rootElement.addContent(element);
            }

            boolean includeAncillaryData = AppConstants.ANCILLARY_DATA_FLAG_YES.equalsIgnoreCase(lender.getAncillary_data_flag());
            boolean includeReviewQuestions = AppConstants.DOCUMENT_REVIEW_FLAG_YES.equalsIgnoreCase(lender.getDoc_review_flag());
            element = new Element ("DocumentAttachments");
            populateDocuments(files, element, includeAncillaryData, includeReviewQuestions, bodId, dealerId, lender.getLender_id());
            rootElement.addContent(element);

            outDoc.setRootElement(rootElement);
            return outDoc;
    }

    public void populateDocuments(List<File> files, Element documentAttachments, boolean includeAncillaryData,
                                   boolean includeReviewQuestions, String bodId, String dealerId, String lenderId) throws Exception {
        logger.debug("No. of files > " + files.size() + ", includeAncillaryData > " + includeAncillaryData + ", includeReviewQuestions > " + includeReviewQuestions);
        Element documentAttachment = null;
        Element element = null;
        String formType = null;
        List<DcDocData> metaData = null;
        List<DcDocData> reviewData = null;
        List<DcOtherFormType> dcOtherFormTypes = getAndProcessDcOtherFormTypes(files, lenderId, dealerId, bodId);

		for (File file : files) {
			if (!file.getFilename().toLowerCase().endsWith(AppConstants.CONTRACT)) {
				documentAttachment = new Element("DocumentAttachment");
                String dmsDocumentName = getDocumentName(file);
				DcOtherFormType dcOtherFormType = getDcOtherFormTypeByDmsDocName(dcOtherFormTypes, dmsDocumentName);

				element = new Element("FileName");
                String fileName = getOutgoingXmlDocumentName(file, dcOtherFormType, dmsDocumentName, true, true);
                element.setText(fileName);
                documentAttachment.addContent(element);

				element = new Element("DocumentType");
				String documentType = getOutgoingXmlDocumentName(file, dcOtherFormType, dmsDocumentName, true, false);
				element.setText(documentType); // Setting document name as type
				documentAttachment.addContent(element);

				element = new Element("Description");
				String description = getOutgoingXmlDocumentName(file, dcOtherFormType, dmsDocumentName, false, false);
				element.setText(description);
				documentAttachment.addContent(element);

				formType = file.getFormType();
				boolean vaildForm = !"".equals(formType) && !"scanned".equals(formType);

				Element documentFields = new Element("DocumentFields");
				Element documentReview = new Element("DocumentReview");

				if (includeAncillaryData || includeReviewQuestions) {
					metaData = new ArrayList<>();
					reviewData = new ArrayList<>();

					// Collect the ancillary data/ review questions for this
					// file
					if (null != file.getDocData()) {
						for (DcDocData data : file.getDocData()) {
							String section = data.getSection();
							boolean isSectionMetaData = AppConstants.SECTION_META_DATA.equals(section)
									|| AppConstants.SECTION_VERIFICATION_DATA.equals(section);
							if (isSectionMetaData) {
								if (null != data.getDataValue() && !data.getDataValue().isEmpty()) {
									metaData.add(data);
								}
							} else {
								reviewData.add(data);
							}
						}
					}

					if (includeAncillaryData && vaildForm && !metaData.isEmpty()) {
						populateDataAsNVP(documentFields, metaData);
					}

					if (includeReviewQuestions && vaildForm && !reviewData.isEmpty()) {
						populateDataAsNVP(documentReview, reviewData);
					}
				}
				documentAttachment.addContent(documentFields);
				documentAttachment.addContent(documentReview);

				Element document = new Element("Document");
				document.setText(EncryptionUtils.base64Encode(file.getContents()));
				documentAttachment.addContent(document);

				documentAttachments.addContent(documentAttachment);
			}
        }
    }

    public void populateDataAsNVP(Element parentElement, List<DcDocData> docData) throws Exception {
        logger.debug("Entered populateDataAsNVP(Element parentElement, List<DcDocData> data) method");
        for (DcDocData data : docData) {
            Element nvpElement = new Element("DocumentMetaData");

            Element name = new Element("Name");
            Element value = new Element("Value");
            name.setText(data.getDataName());
            value.setText(data.getDataValue());

            nvpElement.addContent(name);
            nvpElement.addContent(value);

            parentElement.addContent(nvpElement);
        }
    }

    public String getDocumentName(final File file) throws Exception {
        logger.debug("Entered method getDocumentName(File file)");

        String documentName = "";

        if (null != file.getDmsDocType() && null != file.getDmsDocType().getDcDocType()
            && null != file.getDmsDocType().getDcDocType().getName()
            && !file.getDmsDocType().getDcDocType().getName().equalsIgnoreCase(AppConstants.DOC_NAME_OTHER)) {
            documentName = file.getDmsDocType().getDcDocType().getName();
        } else if (null != file.getFilename()) {
            documentName = file.getFilename();
        }

        if (documentName.contains(".")) {
            documentName = documentName.substring(0, documentName.lastIndexOf("."));
        }

        int hyphenLocation = documentName.indexOf("-") + 1;
        if (hyphenLocation > 0) { // hyphen exists
            // Check if the text before dash is doc ID. If not, keep it
            // because it will be part of doc name.
            boolean docIdPrefixExists = true;
            try {
                String textBeforeHyphen = documentName.substring(0, hyphenLocation - 1);
                Integer.parseInt(textBeforeHyphen);
            } catch (NumberFormatException e) {
                logger.debug("could not parse to number", e);
                docIdPrefixExists = false;
            }
            if (!docIdPrefixExists) {
                hyphenLocation = 0;
            }
        }
        documentName = documentName.substring(hyphenLocation);

        // For MB Dealer Product 1, Dealer Product 2 ....Dealer Product 10
        // should be sent as Dealer Product
        if (documentName.startsWith(AppConstants.DOC_NAME_DEALER_PRODUCT)) {
            return AppConstants.DOC_NAME_DEALER_PRODUCT;
        }

        return documentName;
    }

    private List<DcOtherFormType> getAndProcessDcOtherFormTypes(List<File> files, String lenderId, String dealerId, String bodId) throws Exception {
        List<DcOtherFormType> dcOtherFormTypes = new ArrayList<>();
        if (!files.isEmpty()) { // Get all DcOtherFormTypes from first DeDealId found. DeDealId should be same in all files.
            List<File> filesWithDealId = files.stream()
                    .filter(file -> null != file.getDcDocument() && null != file.getDcDocument().getDealId() && file.getFilename().matches(".*Other\\d+\\..*"))
                    .collect(Collectors.toList());
            if (!filesWithDealId.isEmpty()) {
                String deDealId = filesWithDealId.get(0).getDcDocument().getDealId();
                dcOtherFormTypes = getDcOtherFormTypesByDeDealId(deDealId);
                for (File file : filesWithDealId) { // Go thru all ".*Other.*" files
                    String documentName = getDocumentName(file);
                    if (dcOtherFormTypes.stream().noneMatch( // Check each file name against dcOtherFormTypes found
                            dcOtherFormType -> documentName.equalsIgnoreCase(dcOtherFormType.getDmsDocName()))) {
                        // Create error saying file is not found in DC_OTHER_FORM_TYPE
                        String errorMessage = "Unable to find DC_OTHER_FORM_TYPE entries with DmsDocName " +
                                documentName + " and DeDealId " + deDealId;
                        logger.error(errorMessage);
                        createErrorLog(lenderId, dealerId, deDealId, bodId, file.getDcDocument().getSequenceId(), errorMessage);
                    }
                }
            } else {
                logger.debug("Couldn't find any files that matches this criteria: null != file.getDcDocument() && " +
                        "null != file.getDcDocument().getDealId() && file.getFilename().matches(\".*Other\\d+\\..*\")");
            }
        }
        return dcOtherFormTypes;
    }

    public List<DcOtherFormType> getDcOtherFormTypesByDeDealId(String deDealId) {
        logger.debug("Entered method getDcOtherFormTypesByDeDealId(String deDealId). deDealId: {}", deDealId);
        List<DcOtherFormType> dcOtherFormTypes = dcOtherFormTypeDAO.getDcOtherFormTypesByDeDealId(deDealId);
        if (dcOtherFormTypes.isEmpty()) {
            logger.error("Unable to find DC_OTHER_FORM_TYPE entry with DE_DEAL_ID {}", deDealId);
        }
        return dcOtherFormTypes;
    }

    public DcOtherFormType getDcOtherFormTypeByDmsDocName(List<DcOtherFormType> dcOtherFormTypes, String dmsDocName) {
        logger.debug("Entered method getDcOtherFormTypeByDmsDocName(List<DcOtherFormType> dcOtherFormTypes, String dmsDocName)." +
                " dmsDocName: {}", dmsDocName);
        DcOtherFormType dcOtherFormTypeWithDmsDocName = null;
        List<DcOtherFormType> matchingDmsDocNames = dcOtherFormTypes.stream()
                .filter(dcOtherFormType -> dmsDocName.equalsIgnoreCase(dcOtherFormType.getDmsDocName()))
                .collect(Collectors.toList());
        if (matchingDmsDocNames.size() == 1) {
            logger.debug("Found DcOtherFormType to match DmsDocName {}", dmsDocName);
            dcOtherFormTypeWithDmsDocName = matchingDmsDocNames.get(0);
        } else if (matchingDmsDocNames.size() > 1) {
            logger.debug("Unexpectedly found more than one DcOtherFormType with DmsDocName {}. Grabbing the latest.", dmsDocName);
            dcOtherFormTypeWithDmsDocName = matchingDmsDocNames.get(0);
        }
        return dcOtherFormTypeWithDmsDocName;
    }

    private void createErrorLog(String lenderId, String dealerId, String dealId, String bodId, String sequenceId, String errorMessage) {
        logger.debug("Entered method createErrorLog(String lenderId, String dealerId, String dealId, String bodId, String sequenceId, String errorMessage)." +
                " lenderId: {}; dealerId: {}; dealId: {}; bodId: {}; sequenceId: {}; errorMessage: {}.",
                lenderId, dealerId, dealId, bodId, sequenceId, errorMessage);
        ErrorLog log = new ErrorLog();
        log.setLenderId(lenderId);
        log.setTransactionType(AppConstants.TRANS_TYPE_EDOCIN);
        log.setDealId(dealId);
        log.setDmsDealNum(bodId);
        log.setSequenceId(sequenceId);
        log.setErrorMessage(errorMessage);
        log.setErrorCode(AppConstants.DC_OTHER_FORM_TYPE_SEARCH_NO_RESULTS_CODE);
        log.setDmsDealerId(dealerId);
        Calendar calendar = Calendar.getInstance();
        Date now = calendar.getTime();
        log.setCreatedBy(AppConstants.APPLICATION_EDOCS);
        log.setCreatedTs(new Timestamp(now.getTime()));
        errorLogDAO.saveOrUpdate(log);
    }

    /**
     * Determines the correct document name for the outgoing XML, can be used for FileName, DocumentType, and Description
     *
     * @param file - the File from DocumentAttachments
     * @param useDmsDocName - if true, the default document name will be the DMS document name,
     * 							if false, the default document name will be lender document name
     * @param appendFileExtension - if true, the file extension will be appended to the document name
     * @return the document name to be used in the outgoing XML
     */
    public String getOutgoingXmlDocumentName(File file, DcOtherFormType dcOtherFormType, String dmsDocumentName,
                                             boolean useDmsDocName, boolean appendFileExtension) {
        // If dcOtherFormType is still null, use default document name
    	if (dcOtherFormType == null) {
    		if (useDmsDocName) {
    			return dmsDocumentName;
    		}
    		else {
    			String lenderDocumentName = null;
    			if (null != file.getLenDocType() && null != file.getLenDocType().getDocName()) {
    				if (file.getLenDocType().getDocName().startsWith(AppConstants.DOC_NAME_DEALER_PRODUCT)) {
    					lenderDocumentName = AppConstants.DOC_NAME_DEALER_PRODUCT;
    				} else {
    					lenderDocumentName = file.getLenDocType().getDocName();
    				}
    			} else {
    				lenderDocumentName = AppConstants.DEAFULT_FILE_NAME;
    			}
    			return lenderDocumentName;
    		}
    	}
        // Append file extension if requested
    	if (appendFileExtension) {
    		if (file.getFileExtension().startsWith(".")) {
    			return dcOtherFormType.getLenDocName() + file.getFileExtension();
    		}
    		else {
    			return dcOtherFormType.getLenDocName() + "." + file.getFileExtension();
    		}
    	}
    	else {
    		return dcOtherFormType.getLenDocName();
    	}
    }
}
