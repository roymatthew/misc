package com.ode.edocs.xml;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.DcDocData;
import com.ode.edocs.db.entity.DeLender;
import com.ode.edocs.db.entity.DeLenderDestination;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.EncryptionUtils;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.XMLConstants;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.ElementFilter;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.springframework.stereotype.Component;

@Component
public class DistributionSchemaV1_0 {

    private static final Logger logger = LogManager.getLogger(DistributionSchemaV1_0.class);

    private static Namespace starDefault = Namespace.getNamespace("http://www.starstandards.org/STAR");
    private static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");
    private static Namespace dig = Namespace.getNamespace("dig", "http://www.opendealerexchange.com/DigitalDeal");
    private static Namespace wsse = Namespace.getNamespace("wsse", "http://schemas.xmlsoap.org/ws/2002/07/secext");
    private static Namespace wsu = Namespace.getNamespace("wsu", "http://schemas.xmlsoap.org/ws/2002/07/utility");
    private static Namespace soapenv = Namespace.getNamespace("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");

    public Document createOutgoingXml(Document ecout, List<File> files, String dmsId, String lenderId, String dealId,
        String sequenceId, String financeType, DeLenderDestination lenderDest, DeLender lender, String bodId) throws Exception {
        logger.debug(
            "Entered createOutgoingXml(Document ecout, List<File> files, String dmsId, String lenderId, String dealId, String sequenceId, String financeType, DeLenderDestination lenderDest, DeLender lender) method");
        Element pcc = null;
        if (null != ecout) {
            XPathExpression<Element> xpath = XPathFactory.instance().compile(XMLConstants.starProcessCreditPath,
                Filters.element(), null, star);
            pcc = xpath.evaluateFirst(ecout);
            pcc.detach();
        }

        // create document & root element
        Document outDoc = new Document();

        Element rootElement = new Element("Envelope", starDefault); // setting default namespace to STAR so
        // ProcessCreditContract element below does not have
        // a namespace prefix. MB's system is not using a
        // standard xml parser and cannot handle a prefix on
        // ProcessCreditContract.
        rootElement.addNamespaceDeclaration(soapenv);
        rootElement.addNamespaceDeclaration(dig);
        rootElement.setNamespace(soapenv);

        Element headerElement = new Element("Header");
        if (HandlerUtils.doesHeaderSecurityExist(lenderDest)) {
            Element userNameElement = new Element("Username");
            userNameElement.setNamespace(wsse);
            userNameElement.setText(lenderDest.getWs_username());

            Element passwordElement = new Element("Password");
            passwordElement.setNamespace(wsse);
            passwordElement.setAttribute("Type", "wsse:PasswordText");
            passwordElement.setText(lenderDest.getWs_password());

            Element userTokenElement = new Element("UsernameToken");
            userTokenElement.addNamespaceDeclaration(wsu);
            userTokenElement.setNamespace(wsse);
            userTokenElement.addContent(userNameElement);
            userTokenElement.addContent(passwordElement);

            Element securityElement = new Element("Security");
            securityElement.addNamespaceDeclaration(wsse);
            securityElement.setNamespace(wsse);
            securityElement.addContent(userTokenElement);

            // Create Soap Header
            headerElement.setNamespace(soapenv);
            headerElement.addContent(securityElement);
        }

        // Create Soap Body
        Element body = new Element("Body");
        body.setNamespace(soapenv);

        // create digital deal element
        Element digitalDealDistributionElement = new Element("DigitalDealDistribution").setNamespace(dig);

        // create sections
        Element header = new Element("Header").setNamespace(dig);
        Element contractData = new Element("ContractData").setNamespace(dig);
        Element documents = new Element("Documents").setNamespace(dig);

        // populate sections
        populateHeader(header, dmsId, lenderId, dealId, sequenceId);
		if (null != pcc) {
			if ("AR".equalsIgnoreCase(dmsId)) {
				Element creator = pcc.getChildren().get(0).getChildren().get(0);
				creator.getChild("CreatorNameCode", star).setText("AR");
				Element sender = pcc.getChildren().get(0).getChildren().get(0);
				sender.getChild("SenderNameCode", star).setText("OD");

				Element applicationArea = pcc.getChildren().get(0);
				
				if (null != applicationArea) {
					// Add BODId
					if (null == applicationArea.getChild("BODId", star)) {
						int creationDateTimeIndex = applicationArea.indexOf(applicationArea.getChild("CreationDateTime", star));
						Element bodID = new Element("BODId").setNamespace(applicationArea.getNamespace()).setText(bodId);
						applicationArea.addContent(++creationDateTimeIndex, bodID);
					}
				}
				contractData.addContent(pcc);
			} else {
				contractData.addContent(pcc);
			}
		}
        populateDocuments(files, documents, financeType, dealId, lender);

        digitalDealDistributionElement.addContent(header);
        digitalDealDistributionElement.addContent(contractData);
        digitalDealDistributionElement.addContent(documents);

        body.addContent(digitalDealDistributionElement);

        rootElement.addContent(headerElement);
        rootElement.addContent(body);

        outDoc.setRootElement(rootElement);

        return outDoc;
    }

    private void populateHeader(Element header, String dmsId, String lenderId, String dealId, String sequenceId)
        throws Exception {
        logger.debug(
            "Entered populateHeader(Element header, String dmsId, String lenderId, String dealId, String sequenceId) method");
        Element distributionId = new Element("DistributionId").setNamespace(dig);
        Element messageType = new Element("MessageType").setNamespace(dig);
        Element dmsName = new Element("DMSName").setNamespace(dig);
        Element lenderName = new Element("LenderName").setNamespace(dig);

        header.addContent(distributionId);
        header.addContent(messageType);
        header.addContent(dmsName);
        header.addContent(lenderName);

        distributionId.setText(dealId + sequenceId);
        if (sequenceId.equals("DS01")) {
            messageType.setText("Contract");
        } else {
            messageType.setText("Trailing");
        }
        dmsName.setText(dmsId);
        lenderName.setText(lenderId);

    }

    private void populateDocuments(List<File> files, Element documents, String financeType, String dealId,
        DeLender lender) throws Exception {
        logger.debug(
            "Entered populateDocuments(List<File> files, Element documents, String financeType, String dealId, DeLender lender) method");
        File contractFile = null;
        File leaseWorksheetFile = null;
        List<File> ancillaryFiles = new ArrayList<File>();
        for (File file : files) {
            if (null != file.getDcDocument() && null != file.getDcDocument().getDocType()
                && file.getDcDocument().getDocType().equals(AppConstants.DOC_TYPE_CONTRACT)) {

                if (null != contractFile) {
                    logger.warn("more than one contract found in attachments");
                }
                contractFile = file;
            } else if (null != file.getDcDocument() && null != file.getDcDocument().getDocType()
                && file.getDcDocument().getDocType().equals(AppConstants.DOC_TYPE_LEASE_WORKSHEET)) {

                if (null != leaseWorksheetFile) {
                    logger.warn("more than one lease worksheet found in attachments");
                }
                leaseWorksheetFile = file;
            } else {
                ancillaryFiles.add(file);
            }
        }

        if (null != contractFile) {
            Element contract = new Element("Contract").setNamespace(dig);
            documents.addContent(contract);
            populateContract(contract, contractFile, dealId, lender);
        }

        for (File ancillaryFile : ancillaryFiles) {
            Element ancillaryDocument = new Element("AncillaryDocument").setNamespace(dig);
            documents.addContent(ancillaryDocument);
            populateAncillaryDocument(ancillaryDocument, ancillaryFile, dealId, lender);
        }

    }

    private void populateContract(Element contract, File file, String dealId, DeLender lender) throws Exception {
        logger.debug("Entered populateContract(Element contract, File file, String dealId, DeLender lender) method");
        List<DcDocData> metaData = new ArrayList<DcDocData>();
        List<DcDocData> reviewData = new ArrayList<DcDocData>();
        if (null != file && null != file.getDocData()) {
            for (DcDocData data : file.getDocData()) {
                if (null != data && AppConstants.SECTION_META_DATA.equals(data.getSection())) {
                    metaData.add(data);
                } else if (null != data && AppConstants.SECTION_REVIEW_DATA.equals(data.getSection())) {
                    reviewData.add(data);
                }
            }
        }

        Element contractName = new Element("ContractName").setNamespace(dig);
        Element documentMetadata = new Element("DocumentMetadata").setNamespace(dig);
        Element additionalContractData = new Element("AdditionalContractData").setNamespace(dig);
        Element contractDocReview = new Element("ContractDocReview").setNamespace(dig);
        Element attachment = new Element("Attachment").setNamespace(dig);

        contract.addContent(contractName);
        contract.addContent(documentMetadata);
        contract.addContent(additionalContractData);
        contract.addContent(contractDocReview);
        contract.addContent(attachment);

        contractName.setText(HandlerUtils.getDocumentName(file));

        populateDocumentMetadata(documentMetadata, file);
        populateDataAsNVP(additionalContractData, metaData);

        // Attach doc review elements if the lender is opted for it for contract/ lease agreement
        if (AppConstants.DOCUMENT_REVIEW_FLAG_YES.equalsIgnoreCase(lender.getDoc_review_flag())) {
            populateDataAsNVP(contractDocReview, reviewData);
        }
        populateAttachment(attachment, file);

    }

    private void populateAncillaryDocument(Element ancillaryDocument, File file, String dealId, DeLender lender)
        throws Exception {
        logger.debug(
            "Entered populateAncillaryDocument(Element ancillaryDocument, File file, String dealId, DeLender lender)  method");
        List<DcDocData> metaData = new ArrayList<DcDocData>();
        List<DcDocData> reviewData = new ArrayList<DcDocData>();
        if (null != file && null != file.getDocData()) {
            for (DcDocData data : file.getDocData()) {
                if (null != data) {
                    String section = data.getSection();
                    boolean isSectionMetaData = AppConstants.SECTION_META_DATA.equals(section)
                        || AppConstants.SECTION_VERIFICATION_DATA.equals(section);
                    /*
                     * FormSignaturePresent verification to fly in meta data section
                     */
                    if (isSectionMetaData) {
                        if (null != data.getDataValue() && !data.getDataValue().isEmpty()) {
                            metaData.add(data);
                        }
                    } else {
                        reviewData.add(data);
                    }
                }
            }
        }

        Element documentName = new Element("DocumentName", dig);
        Element documentMetadata = new Element("DocumentMetadata", dig);
        Element ancillaryMetaData = new Element("AncillaryMetaData", dig);
        Element ancillaryDocReview = new Element("AncillaryDocReview", dig);
        Element attachment = new Element("Attachment", dig);

        ancillaryDocument.addContent(documentName);
        ancillaryDocument.addContent(documentMetadata);
        ancillaryDocument.addContent(ancillaryMetaData);
        ancillaryDocument.addContent(ancillaryDocReview);
        ancillaryDocument.addContent(attachment);

        documentName.setText(HandlerUtils.getDocumentName(file));

        populateDocumentMetadata(documentMetadata, file);
        String formType = (file != null ? file.getFormType() : "");

        if (AppConstants.ANCILLARY_DATA_FLAG_YES.equalsIgnoreCase(lender.getAncillary_data_flag())
            && !"".equals(formType) && !"scanned".equals(formType)) {
            populateDataAsNVP(ancillaryMetaData, metaData);
        }

        if (AppConstants.DOCUMENT_REVIEW_FLAG_YES.equalsIgnoreCase(lender.getDoc_review_flag()) && !"".equals(formType)
            && !"scanned".equals(formType)) {
            populateDataAsNVP(ancillaryDocReview, reviewData);
        }

        populateAttachment(attachment, file);

    }

    private void populateDocumentMetadata(Element documentMetadata, File file) throws Exception {
        logger.debug("Entered populateDocumentMetadata(Element documentMetadata, File file) method");
        Element documentId = new Element("DocumentId", dig);
        Element documentStatus = new Element("DocumentStatus", dig);
        Element documentComment = new Element("DocumentComment", dig);
        Element lenderDocumentId = new Element("LenderDocumentId", dig);
        Element lenderDocumentName = new Element("LenderDocumentName", dig);
        Element requiredForm = new Element("RequiredForm", dig);
        Element productDescription = new Element("ProductDescription", dig);
        Element productFormName = new Element("ProductFormName", dig);
        Element productFormVersionDate = new Element("ProductFormVersionDate", dig);

        documentMetadata.addContent(documentId);
        documentMetadata.addContent(documentStatus);
        documentMetadata.addContent(documentComment);
        documentMetadata.addContent(lenderDocumentId);
        documentMetadata.addContent(lenderDocumentName);
        documentMetadata.addContent(requiredForm);
        documentMetadata.addContent(productDescription);
        documentMetadata.addContent(productFormName);
        documentMetadata.addContent(productFormVersionDate);

        if (null != file && null != file.getDcDocument() && null != file.getDcDocument().getId()) {
            documentId.setText(file.getDcDocument().getId().toString());
        }
        documentStatus.setText(AppConstants.DOCUMENT_STATUS_DISTRIBUTED);
        documentComment.setText("");
        if (null != file && null != file.getLenDocType() && null != file.getLenDocType().getDocName()) {
            if (file.getLenDocType().getDocName().startsWith(AppConstants.DOC_NAME_DEALER_PRODUCT)) {
                lenderDocumentName.setText(AppConstants.DOC_NAME_DEALER_PRODUCT);
            } else {
                lenderDocumentName.setText(file.getLenDocType().getDocName());
            }
        } else {
            lenderDocumentName.setText(AppConstants.DEAFULT_FILE_NAME);
        }
        requiredForm.setText(file != null ? file.getRequiredForm() : "");
        productDescription.setText("");
        productFormName.setText("");
        productFormVersionDate.setText("");

    }

    public void populateAttachment(Element attachment, File file) throws Exception {
        logger.debug("Entered populateAttachment(Element attachment, File file) method");
        Element fileContent = new Element("FileContent", dig);
        Element eSigned = new Element("ESigned", dig);
        Element eForm = new Element("EForm", dig);

        attachment.addContent(fileContent);
        attachment.addContent(eSigned);
        attachment.addContent(eForm);

        if (null != file) {
            fileContent.setText(EncryptionUtils.base64Encode(file.getContents()));
            if (null != file.geteForm()) {
                eForm.setText(file.geteForm());
            }

            if (null != file.geteSigned()) {
                eSigned.setText(file.geteSigned());
            }
        }

    }

    public void populateDataAsNVP(Element parentElement, List<DcDocData> data) throws Exception {
        logger.debug("Entered populateDataAsNVP(Element parentElement, List<DcDocData> data) method");
        if (null != data) {
            for (DcDocData datum : data) {
                Element nvpElement = new Element("NameValuePair", dig);

                Element name = new Element("Name", dig);
                Element value = new Element("Value", dig);
                name.setText(datum.getDataName());
                value.setText(datum.getDataValue());

                nvpElement.addContent(name);
                nvpElement.addContent(value);

                parentElement.addContent(nvpElement);
            }
        }

    }
}
