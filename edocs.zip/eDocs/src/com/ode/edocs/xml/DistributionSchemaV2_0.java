package com.ode.edocs.xml;

import com.ode.edocs.File;
import com.ode.edocs.db.entity.*;
import com.ode.edocs.util.AppConstants;
import com.ode.edocs.util.EncryptionUtils;
import com.ode.edocs.util.HandlerUtils;
import com.ode.edocs.util.IValidationUtil;
import com.ode.edocs.util.XMLConstants;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DistributionSchemaV2_0 {

    private static final Logger logger = LogManager.getLogger(DistributionSchemaV2_0.class);

    @Autowired
    private IValidationUtil validationUtil;

    private static Namespace starDefault = Namespace.getNamespace("http://www.starstandards.org/STAR");
    private static Namespace star = Namespace.getNamespace("star", "http://www.starstandards.org/STAR");
    private static Namespace dig = Namespace.getNamespace("dig", "http://www.opendealerexchange.com/DigitalDeal");
    private static Namespace wsse = Namespace.getNamespace("wsse", "http://schemas.xmlsoap.org/ws/2002/07/secext");
    private static Namespace wsu = Namespace.getNamespace("wsu", "http://schemas.xmlsoap.org/ws/2002/07/utility");
    private static Namespace soapenv = Namespace.getNamespace("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");

    private DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

    public Document createOutgoingXml(Document ecout, List<File> files, String dmsId, DeDeal deDeal, String sequenceId,
        String financeType, DeLenderDestination lenderDest, DeLender lender, DcDistribution distribution,
        List<DeMaintenanceHistory> maintRecords, List<DcDistribution> distributions) throws Exception {
        logger.debug("Entered createOutgoingXml method");
        Element pcc = null;
        if (null != ecout) {
            XPathExpression<Element> xpath = XPathFactory.instance().compile(XMLConstants.starProcessCreditPath,
                Filters.element(), null, star);
            pcc = xpath.evaluateFirst(ecout);
            pcc.detach();
        }

        String dealId = deDeal.getDealId();

        // create document & root element
        Document outDoc = new Document();

        Element rootElement = new Element("Envelope", starDefault);
        // setting default namespace to STAR so ProcessCreditContract element below
        // does not have a namespace prefix. MB's system is not using
        // a standard xml parser and cannot handle a prefix on ProcessCreditContract.

        rootElement.addNamespaceDeclaration(soapenv);
        rootElement.addNamespaceDeclaration(dig);
        rootElement.setNamespace(soapenv);

        Element headerElement = new Element("Header");

        // Header Security Fields
        if (HandlerUtils.doesHeaderSecurityExist(lenderDest)) {
            // Create Soap Header
            headerElement.setNamespace(soapenv);
            headerElement.addContent(populateSecurityElement(lenderDest));
        }

        // Create Soap Body
        Element body = new Element("Body");
        body.setNamespace(soapenv);

        // create digital deal element
        Element digitalDealDistributionElement = new Element("DigitalDealDistribution").setNamespace(dig);

        // create and populate sections
        Element header = populateHeader(dmsId, lender.getLender_id(), dealId, sequenceId);
        Element dealInfo = populateDealInfo(deDeal, maintRecords, distribution, distributions);
        Element contractData = new Element("ContractData").setNamespace(dig);
        if (null != pcc) {
            contractData.addContent(pcc);
        }
        Element documents = populateDocuments(files, financeType, dealId, lender, distribution, dmsId, distributions);

        digitalDealDistributionElement.addContent(header);
        digitalDealDistributionElement.addContent(dealInfo);
        digitalDealDistributionElement.addContent(contractData);
        digitalDealDistributionElement.addContent(documents);

        body.addContent(digitalDealDistributionElement);

        rootElement.addContent(headerElement);
        rootElement.addContent(body);

        outDoc.setRootElement(rootElement);

        return outDoc;
    }

    private Element populateDealInfo(DeDeal deDeal, List<DeMaintenanceHistory> maintRecords,
        DcDistribution distribution, List<DcDistribution> distributions) throws Exception {
        logger.debug("Entered populateDealInfo method");
        Element dealInfo = new Element("DealInfo").setNamespace(dig);

        Element dealStatus = new Element("DealStatus").setNamespace(dig);
        dealStatus.setText(getDealStatus(deDeal));
        dealInfo.addContent(dealStatus);

        if (null != maintRecords && !maintRecords.isEmpty()) {
            for (DeMaintenanceHistory maintRecord : maintRecords) {
                Element messages = new Element("Messages").setNamespace(dig);

                Element type = new Element("Type").setNamespace(dig);
                Element description = new Element("Description").setNamespace(dig);
                Element user = new Element("User").setNamespace(dig);
                Element timestamp = new Element("Timestamp").setNamespace(dig);

                type.setText("InternalNote");
                description.setText(maintRecord.getDescription());
                user.setText(maintRecord.getCreatedBy());
                String createdBy = dateFormat.format(maintRecord.getCreatedTs());
                timestamp.setText(createdBy);

                messages.addContent(type);
                messages.addContent(description);
                messages.addContent(user);
                messages.addContent(timestamp);

                dealInfo.addContent(messages);
            }
        }

        Element readyToBook = populateReadyToBookNVP(distribution, distributions);

        dealInfo.addContent(readyToBook);

        return dealInfo;
    }

    private Element populateHeader(String dmsId, String lenderId, String dealId, String sequenceId) throws Exception {
        logger.debug("Entered populateHeader(String dmsId, String lenderId, String dealId, String sequenceId) method");
        Element header = new Element("Header").setNamespace(dig);

        Element distributionId = new Element("DistributionId").setNamespace(dig);
        Element messageType = new Element("MessageType").setNamespace(dig);
        Element dmsName = new Element("DMSName").setNamespace(dig);
        Element lenderName = new Element("LenderName").setNamespace(dig);

        header.addContent(distributionId);
        header.addContent(messageType);
        header.addContent(dmsName);
        header.addContent(lenderName);

        distributionId.setText(dealId + sequenceId);
        if (sequenceId.equals("DS01")) {
            messageType.setText("Contract");
        } else {
            messageType.setText("Trailing");
        }
        dmsName.setText(dmsId);
        lenderName.setText(lenderId);

        return header;
    }

    private Element populateDocuments(List<File> files, String financeType, String dealId, DeLender lender,
        DcDistribution distribution, String dmsId, List<DcDistribution> distributions) throws Exception {
        logger.debug("Entered DcDistribution method");
        Element documents = new Element("Documents").setNamespace(dig);

        File contractFile = null;
        File leaseWorksheetFile = null;
        List<File> ancillaryFiles = new ArrayList<File>();
        for (File file : files) {
            if (null != file.getDcDocument() && null != file.getDcDocument().getDocType()
                && file.getDcDocument().getDocType().equals(AppConstants.DOC_TYPE_CONTRACT)) {

                if (null != contractFile) {
                    logger.warn("more than one contract found in attachments");
                }
                contractFile = file;
            } else if (null != file.getDcDocument() && null != file.getDcDocument().getDocType()
                && file.getDcDocument().getDocType().equals(AppConstants.DOC_TYPE_LEASE_WORKSHEET)) {

                if (null != leaseWorksheetFile) {
                    logger.warn("more than one lease worksheet found in attachments");
                }
                leaseWorksheetFile = file;
            } else {
                ancillaryFiles.add(file);
            }
        }

        /**
         * Populate Contract in Documents section
         */
        if (null != contractFile) {
            Element contract = new Element("Contract").setNamespace(dig);
            documents.addContent(contract);
            populateContract(contract, contractFile, dealId, lender, distribution, dmsId, distributions);
        }

        /**
         * Populate AncillaryDocument in Documents section
         */
        for (File ancillaryFile : ancillaryFiles) {
            Element ancillaryDocument = new Element("AncillaryDocument").setNamespace(dig);
            documents.addContent(ancillaryDocument);
            populateAncillaryDocument(ancillaryDocument, ancillaryFile, dealId, lender, dmsId);
        }

        return documents;
    }

    private void populateContract(Element contract, File file, String dealId, DeLender lender,
        DcDistribution distribution, String dmsId, List<DcDistribution> distributions) throws Exception {
        logger.debug("Entered populateContract method");
        List<DcDocData> metaData = new ArrayList<DcDocData>();
        List<DcDocData> reviewData = new ArrayList<DcDocData>();
        /*
         * if (null != file && null != file.getDocData()) { for (DcDocData data : file.getDocData()) { if (null != data
         * && AppConstants.SECTION_META_DATA.equals(data.getSection())) { metaData.add(data); } else if (null != data &&
         * AppConstants.SECTION_REVIEW_DATA.equals(data.getSection())) { reviewData.add(data); }
         */
        if (file != null && file.getDocData() != null) {
            for (DcDocData data : file.getDocData()) {
                String section = data.getSection();
                if (AppConstants.ancillaryMetaDataTypes.contains(section)) {
                    metaData.add(data);
                } else if (AppConstants.reviewQuestionsMetaDataTypes.contains(section)) {
                    reviewData.add(data);
                }
            }
        }

        Element contractName = new Element("ContractName").setNamespace(dig);
        Element documentMetadata = new Element("DocumentMetadata").setNamespace(dig);
        Element additionalContractData = new Element("AdditionalContractData").setNamespace(dig);
        Element contractDocReview = new Element("ContractDocReview").setNamespace(dig);
        Element attachment = new Element("Attachment").setNamespace(dig);

        contract.addContent(contractName);
        contract.addContent(documentMetadata);
        contract.addContent(additionalContractData);
        contract.addContent(contractDocReview);
        contract.addContent(attachment);

        contractName.setText(HandlerUtils.getDocumentName(file));

        populateDocumentMetadata(documentMetadata, file, dmsId);

        // TODO: populate contract sections from DB - Not ready for Laurel-2,
        // ContractSections will be a blank element
        // Section data comes from CONTRACT_EDIT_DATA.ADDITIONAL_CONTRACT_DATA
        Element contractSections = new Element("ContractSections").setNamespace(dig);
        additionalContractData.addContent(contractSections);

        populateDataAsNVP(additionalContractData, metaData);

        // Attach doc review elements if the lender is opted for it for
        // contract/ lease agreement
        if (AppConstants.DOCUMENT_REVIEW_FLAG_YES.equalsIgnoreCase(lender.getDoc_review_flag())) {
            populateDataAsNVP(contractDocReview, reviewData);

            // Add elements to contractDocReview
            // Populate FormComplete (file.dcdocument.formcomplete) and
            // ReadyToBook (distribution.readyToBook - if DS01 take from table, if not, = N)
            contractDocReview.addContent(populateFormCompleteNVP(file));
            contractDocReview.addContent(populateReadyToBookNVP(distribution, distributions));
        }

        populateAttachment(attachment, file);

    }

    private void populateAncillaryDocument(Element ancillaryDocument, File file, String dealId, DeLender lender,
        String dmsId) throws Exception {
        logger.debug("Entered populateAncillaryDocument method");
        List<DcDocData> metaData = new ArrayList<DcDocData>();
        List<DcDocData> reviewData = new ArrayList<DcDocData>();
        if (null != file && null != file.getDocData()) {
            for (DcDocData data : file.getDocData()) {
                if (null != data) {
                    String section = data.getSection();
                    /*
                     * boolean isSectionMetaData = AppConstants.SECTION_META_DATA.equals(section) ||
                     * AppConstants.SECTION_VERIFICATION_DATA.equals(section);
                     * 
                     * // FormSignaturePresent verification to fly in meta data section
                     * 
                     * if (isSectionMetaData) { if (null != data.getDataValue() && !data.getDataValue().isEmpty()) {
                     * metaData.add(data); } } else {
                     */
                    if (AppConstants.ancillaryMetaDataTypes.contains(section)) {
                        metaData.add(data);
                    } else if (AppConstants.reviewQuestionsMetaDataTypes.contains(section)) {
                        reviewData.add(data);
                    }
                }
            }
        }

        Element documentName = new Element("DocumentName", dig);
        Element documentMetadata = new Element("DocumentMetadata", dig);
        Element ancillaryMetaData = new Element("AncillaryMetaData", dig);
        Element ancillaryDocReview = new Element("AncillaryDocReview", dig);
        Element attachment = new Element("Attachment", dig);

        ancillaryDocument.addContent(documentName);
        ancillaryDocument.addContent(documentMetadata);
        ancillaryDocument.addContent(ancillaryMetaData);
        ancillaryDocument.addContent(ancillaryDocReview);
        ancillaryDocument.addContent(attachment);

        documentName.setText(HandlerUtils.getDocumentName(file));

        populateDocumentMetadata(documentMetadata, file, dmsId);

        if (AppConstants.ANCILLARY_DATA_FLAG_YES.equalsIgnoreCase(lender.getAncillary_data_flag())) {
            populateDataAsNVP(ancillaryMetaData, metaData);
        }

        if (AppConstants.DOCUMENT_REVIEW_FLAG_YES.equalsIgnoreCase(lender.getDoc_review_flag())) {
            populateDataAsNVP(ancillaryDocReview, reviewData);
            ancillaryDocReview.addContent(populateFormCompleteNVP(file));
        }

        populateAttachment(attachment, file);

    }

    private void populateDocumentMetadata(Element documentMetadata, File file, String dmsId) throws Exception {
        logger.debug("Entered populateDocumentMetadata method");
        Element documentId = new Element("DocumentId", dig);
        Element documentStatus = new Element("DocumentStatus", dig);
        Element documentComment = new Element("DocumentComment", dig);
        Element lenderDocumentId = new Element("LenderDocumentId", dig);
        Element lenderDocumentName = new Element("LenderDocumentName", dig);
        Element requiredForm = new Element("RequiredForm", dig);
        Element productDescription = new Element("ProductDescription", dig);
        Element productFormName = new Element("ProductFormName", dig);
        Element productFormVersionDate = new Element("ProductFormVersionDate", dig);

        documentMetadata.addContent(documentId);
        documentMetadata.addContent(documentStatus);
        documentMetadata.addContent(documentComment);
        documentMetadata.addContent(lenderDocumentId);
        documentMetadata.addContent(lenderDocumentName);
        documentMetadata.addContent(requiredForm);
        documentMetadata.addContent(productDescription);
        documentMetadata.addContent(productFormName);
        documentMetadata.addContent(productFormVersionDate);

        if (null != file && null != file.getDcDocument() && null != file.getDcDocument().getId()) {
            documentId.setText(file.getDcDocument().getId().toString());
        }
        documentStatus.setText(AppConstants.DOCUMENT_STATUS_DISTRIBUTED);
        documentComment.setText("");
        String lenderDocIdValue = "";
        if (file != null) {
            lenderDocIdValue = file.getDmsDocType().getDmsFormId();
        }
        if ("".equals(lenderDocIdValue) || lenderDocIdValue == null) { // A
            // catch in case the value is NULL in the table.

            lenderDocIdValue = "00000";
        }
        lenderDocumentId.setText(lenderDocIdValue);
        if (null != file && null != file.getLenDocType() && null != file.getLenDocType().getDocName()) {
            if (file.getLenDocType().getDocName().startsWith(AppConstants.DOC_NAME_DEALER_PRODUCT)) {
                lenderDocumentName.setText(AppConstants.DOC_NAME_DEALER_PRODUCT);
            } else {
                lenderDocumentName.setText(file.getLenDocType().getDocName());
            }
        } else {
            lenderDocumentName.setText(AppConstants.DEAFULT_FILE_NAME);
        }
        requiredForm.setText(file.getRequiredForm());
        productDescription.setText("");
        productFormName.setText("");
        productFormVersionDate.setText("");

    }

    public void populateAttachment(Element attachment, File file) throws Exception {
        logger.debug("Entered populateAttachment method");
        Element fileContent = new Element("FileContent", dig);
        Element eSigned = new Element("ESigned", dig);
        Element eForm = new Element("EForm", dig);

        attachment.addContent(fileContent);
        attachment.addContent(eSigned);
        attachment.addContent(eForm);

        if (null != file) {
            fileContent.setText(EncryptionUtils.base64Encode(file.getContents()));
            if (null != file.geteForm()) {
                eForm.setText(file.geteForm());
            }

            if (null != file.geteSigned()) {
                eSigned.setText(file.geteSigned());
            }
        }

    }

    public void populateDataAsNVP(Element parentElement, List<DcDocData> data) throws Exception {
        logger.debug("Entered populateDataAsNVP method");
        if (null != data) {
            for (DcDocData datum : data) {
                Element nvpElement = new Element("NameValuePair", dig);

                Element name = new Element("Name", dig);
                Element value = new Element("Value", dig);
                name.setText(datum.getDataName());
                value.setText(datum.getDataValue());

                nvpElement.addContent(name);
                nvpElement.addContent(value);

                parentElement.addContent(nvpElement);
            }
        }

    }

    private String getDealStatus(DeDeal deDeal) {
        logger.debug("Entered getDealStatus method");
        String dealStatus = "";

        if (null != deDeal.getFundingStatus() && !deDeal.getFundingStatus().isEmpty()) {
            dealStatus = deDeal.getFundingStatus();
        } else if (null != deDeal.getEconStatus() && !deDeal.getEconStatus().isEmpty()) {
            dealStatus = deDeal.getEconStatus();
        } else if (null != deDeal.getLatestDistributionStatus() && !deDeal.getLatestDistributionStatus().isEmpty()) {
            dealStatus = deDeal.getLatestDistributionStatus();
        } else if (null != deDeal.getCvStatus() && !deDeal.getCvStatus().isEmpty()) {
            dealStatus = deDeal.getCvStatus();
        } else if (null != deDeal.getCaStatus() && !deDeal.getCaStatus().isEmpty()) {
            dealStatus = deDeal.getCaStatus();
        }

        return dealStatus;
    }

    private Element populateFormCompleteNVP(File file) {
        logger.debug("Entered populateFormCompleteNVP method");
        Element formComplete = new Element("NameValuePair").setNamespace(dig);
        Element formCompleteName = new Element("Name").setNamespace(dig);
        Element formCompleteValue = new Element("Value").setNamespace(dig);

        formCompleteName.setText("FormComplete");
        formCompleteValue.setText(file != null && file.getDcDocument() != null ? file.getDcDocument().getFormComplete() : "");

        formComplete.addContent(formCompleteName);
        formComplete.addContent(formCompleteValue);

        return formComplete;
    }

    private Element populateReadyToBookNVP(DcDistribution distribution, List<DcDistribution> distributions) {
        logger.debug("Entered populateReadyToBookNVP method");
        Element readyToBook = new Element("NameValuePair").setNamespace(dig);
        Element readyToBookName = new Element("Name").setNamespace(dig);
        Element readyToBookValue = new Element("Value").setNamespace(dig);

        String readyToBookFlag = "N";

        // This logic only applies to the initial distribution
        if (!validationUtil.previousDistributionExists(distributions)) {
            readyToBookFlag = distribution.getReadyToBook();
        }

        readyToBookName.setText("ReadyToBook");
        readyToBookValue.setText(readyToBookFlag);

        readyToBook.addContent(readyToBookName);
        readyToBook.addContent(readyToBookValue);

        return readyToBook;
    }

    private Element populateSecurityElement(DeLenderDestination lenderDest) {
        logger.debug("Entered populateSecurityElement method");
        Element userNameElement = new Element("Username");
        userNameElement.setNamespace(wsse);
        userNameElement.setText(lenderDest.getWs_username());

        Element passwordElement = new Element("Password");
        passwordElement.setNamespace(wsse);
        passwordElement.setAttribute("Type", "wsse:PasswordText");
        passwordElement.setText(lenderDest.getWs_password());

        Element userTokenElement = new Element("UsernameToken");
        userTokenElement.addNamespaceDeclaration(wsu);
        userTokenElement.setNamespace(wsse);
        userTokenElement.addContent(userNameElement);
        userTokenElement.addContent(passwordElement);

        Element securityElement = new Element("Security");
        securityElement.addNamespaceDeclaration(wsse);
        securityElement.setNamespace(wsse);
        securityElement.addContent(userTokenElement);

        return securityElement;
    }
}
