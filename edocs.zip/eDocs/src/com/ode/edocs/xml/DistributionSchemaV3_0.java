package com.ode.edocs.xml;

import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.springframework.stereotype.Component;

@Component
public class DistributionSchemaV3_0 {
    private static final Logger logger = LogManager.getLogger(DistributionSchemaV3_0.class);

    private static Namespace starDefault = Namespace.getNamespace("http://www.starstandards.org/STAR");
    private static Namespace star = Namespace.getNamespace("s", "http://www.starstandards.org/STAR");
    private static Namespace wsse = Namespace.getNamespace("wsse",
        "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
    private static Namespace soap = Namespace.getNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
    private static Namespace soapenv = Namespace.getNamespace("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
    private static Namespace transport = Namespace.getNamespace("a",
        "http://www.starstandards.org/webservices/2005/10/transport");
    private static Namespace trans = Namespace.getNamespace("trans",
        "http://www.starstandards.org/webservices/2005/10/transport");
    private static Namespace oagis = Namespace.getNamespace("oa", "http://www.openapplications.org/oagis");
    private static Namespace creditApps = Namespace.getNamespace("p",
        "http://CreditGateWay/Ecommerce/Services/CreditApps");
    private static Namespace soapEnc = Namespace.getNamespace("soapenc", "http://schemas.xmlsoap.org/soap/encoding/");
    private static Namespace xmlSchema = Namespace.getNamespace("xsd", "http://www.w3.org/2001/XMLSchema");
    private static Namespace xalan = Namespace.getNamespace("xalan", "http://xml.apache.org/xslt");
    private static Namespace xmlSchemaInstance = Namespace.getNamespace("xsi",
        "http://www.w3.org/2001/XMLSchema-instance");

    public Document createOutgoingXml(Document ecout, String base64EncodedAttachment, String fileName,
        String transactionId, HashMap<String, String> additionalContractAttributeData) throws Exception {
        logger.debug("Entered createOutgoingXml method");
        XMLOutputter xml = new XMLOutputter();
        xml.setFormat(Format.getPrettyFormat());

        Element headerElement = null;
        Document outDoc = new Document();
        try {
            Element rootElement = new Element("Envelope", starDefault);
            rootElement.addNamespaceDeclaration(soap);
            rootElement.addNamespaceDeclaration(starDefault);
            rootElement.addNamespaceDeclaration(transport);
            rootElement.addNamespaceDeclaration(oagis);
            rootElement.addNamespaceDeclaration(creditApps);
            rootElement.addNamespaceDeclaration(star);
            rootElement.addNamespaceDeclaration(soapEnc);
            rootElement.addNamespaceDeclaration(soapenv);
            rootElement.addNamespaceDeclaration(trans);
            rootElement.addNamespaceDeclaration(xalan);
            rootElement.addNamespaceDeclaration(xmlSchema);
            rootElement.addNamespaceDeclaration(xmlSchemaInstance);
            rootElement.setNamespace(soap);
            outDoc.setRootElement(rootElement);
            rootElement.addContent(ecout.getRootElement().getChildren().get(0).clone());
            rootElement.addContent(ecout.getRootElement().getChildren().get(1).clone());

            List<Element> chilElements = outDoc.getRootElement().getChildren();
            headerElement = chilElements.get(0);
            Element body = chilElements.get(1);
            Element putBody = body.getChildren().get(0);
            Element payLoad = putBody.getChildren().get(0);
            Element financeCompany = payLoad.getChildren().get(0).getChildren().get(0).getChildren().get(1)
                .getChildren().get(1).getChildren().get(1);
            modifyFinanceCompanyForVCI(financeCompany.getChildren());

            XPathExpression<Element> xpath = XPathFactory.instance().compile("//s:BODId", Filters.element(), null,
                star);
            Element bodId = xpath.evaluateFirst(outDoc);
            bodId.setText(transactionId);

            Element attachmentContent = new Element("content");
            attachmentContent.setAttribute("id", "Content_1275");

            Element attachment = new Element("attachment");
            Element fileNameAttachment = new Element("fileName");
            fileNameAttachment.setText(fileName);
            fileNameAttachment.setNamespace(payLoad.getNamespace());
            Element attachmentData = new Element("attachmentData");
            attachmentData.setText(base64EncodedAttachment);
            attachmentData.setNamespace(payLoad.getNamespace());
            Element mimeCode = new Element("mimeCode");
            mimeCode.setText("application/zip");
            mimeCode.setNamespace(payLoad.getNamespace());
            attachment.addContent(fileNameAttachment);
            attachment.addContent(attachmentData);
            attachment.addContent(mimeCode);
            attachment.setNamespace(payLoad.getNamespace());
            attachmentContent.addContent(attachment);
            attachmentContent.setNamespace(payLoad.getNamespace());
            payLoad.addContent(attachmentContent);
            List<Element> headerChildElements = headerElement.getChildren();
			if (null != headerChildElements && headerChildElements.size() > 1) {
				Element payloadManifest = headerChildElements.get(1);

				Element attachmentPayloadManifest = new Element("manifest");
				attachmentPayloadManifest.setAttribute("contentID", "Content_1275");
				attachmentPayloadManifest.setAttribute("element", "attachment");
				attachmentPayloadManifest.setAttribute("namespaceURI",
						"http://www.starstandards.org/webservices/2005/10/transport");
				attachmentPayloadManifest.setNamespace(payloadManifest.getNamespace());
				payloadManifest.addContent(attachmentPayloadManifest);
			}
            Element contractSignatureConfirmation = null;
            Element eVaultIndicator = null;
            Element creditContract = payLoad.getChildren().get(0).getChildren().get(0).getChildren().get(1)
                .getChildren().get(1);
			
            // create ContractSignatureConfirmation
            if (additionalContractAttributeData.containsKey("ContractSignatureConfirmation")) {
                contractSignatureConfirmation = new Element("AdditionalContractAttribute");
                contractSignatureConfirmation.setNamespace(creditContract.getNamespace());

                Element attributeName = new Element("AttributeName");
                attributeName.setText("ContractSignatureConfirmation");
                attributeName.setNamespace(creditContract.getNamespace());
                contractSignatureConfirmation.addContent(attributeName);

                Element attributeValue = new Element("AttributeValue");
                attributeValue.setText(additionalContractAttributeData.get("ContractSignatureConfirmation"));
                attributeValue.setNamespace(creditContract.getNamespace());
                contractSignatureConfirmation.addContent(attributeValue);
            }

            // create eVaultIndicator
            if (additionalContractAttributeData.containsKey("eVaultIndicator")) {
                eVaultIndicator = new Element("AdditionalContractAttribute");
                eVaultIndicator.setNamespace(creditContract.getNamespace());

                Element attributeName = new Element("AttributeName");
                attributeName.setText("eVaultIndicator");
                attributeName.setNamespace(creditContract.getNamespace());
                eVaultIndicator.addContent(attributeName);

                Element attributeValue = new Element("AttributeValue");
                attributeValue.setText(additionalContractAttributeData.get("eVaultIndicator"));
                attributeValue.setNamespace(creditContract.getNamespace());
                eVaultIndicator.addContent(attributeValue);
            }

            // insert ContractSignatureConfirmation and eVaultIndicator into XML
            if (null != contractSignatureConfirmation || null != eVaultIndicator) {
                List<Element> creditContractChildren = creditContract.getChildren();
                Element lastChild = creditContractChildren.get(creditContractChildren.size() - 1);
                Element detachedLastChild = null;
                logger.debug("lastChild:{}", lastChild);
                logger.debug("lastChild.getName():{}", lastChild.getName());
                if (lastChild.getName().equalsIgnoreCase("Guarantor")) {
                    logger.debug("lastChild is guarantor");
                    detachedLastChild = lastChild.detach();
                    creditContract.removeChild("Guarantor");
                }
                if (null != contractSignatureConfirmation) {
                    creditContract.addContent(contractSignatureConfirmation);
                }
                if (null != eVaultIndicator) {
                    creditContract.addContent(eVaultIndicator);
                }
                if (lastChild.getName().equalsIgnoreCase("Guarantor")) {
                    creditContract.addContent(detachedLastChild);
                }
            }

        } catch (Exception e) {
            logger.error("Error when creating outgoing XML with distribution schema v3 ", e);
        }
        return outDoc;
    }

    // Modify Party Id to be VCI for AFS & BFS
    public void modifyFinanceCompanyForVCI(List<Element> children) {
        for (Element child : children) {
            if (child.getName().equals("PartyId")) {
                child.setText("VCI");
            }
        }
    }

}
