
package com.ode.pen.ws.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AftermarketAuthenticationHeader complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AftermarketAuthenticationHeader"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://exchange.opendealerexchange.com}AuthenticationHeader"&gt;
 *       &lt;anyAttribute/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AftermarketAuthenticationHeader")
public class AftermarketAuthenticationHeader extends AuthenticationHeader {
	
	public AftermarketAuthenticationHeader() {};

	public AftermarketAuthenticationHeader(String userid, String password) {
		super(userid, password);
	}
}