
package com.ode.pen.ws.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for AftermarketData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AftermarketData"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClientName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DealNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PENProviderID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="PENProviderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PENProductID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="PENProductName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ContractNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductMileage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductDeductible" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductDeductibleDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductPremium" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="ProductSellPrice" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="FIManagerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FormNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FormRevision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EffectiveDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="BuyerFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerMiddleInitial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BuyerPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerMiddleInitial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CoBuyerPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LienholderPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleVIN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleMake" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleYear" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="VehicleOdometer" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="VehicleInServiceDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="VehicleStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FinanceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AmountFinanced" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="FinanceTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AftermarketData", propOrder = {
    "clientName",
    "dealNumber",
    "penProviderID",
    "penProviderName",
    "penProductID",
    "penProductName",
    "contractNumber",
    "productType",
    "productDescription",
    "productTerm",
    "productMileage",
    "productDeductible",
    "productDeductibleDescription",
    "productPremium",
    "productSellPrice",
    "fiManagerName",
    "formNumber",
    "formRevision",
    "effectiveDate",
    "buyerFirstName",
    "buyerMiddleInitial",
    "buyerLastName",
    "buyerAddress",
    "buyerAddress2",
    "buyerCity",
    "buyerState",
    "buyerZip",
    "buyerPhone",
    "coBuyerFirstName",
    "coBuyerMiddleInitial",
    "coBuyerLastName",
    "coBuyerAddress",
    "coBuyerAddress2",
    "coBuyerCity",
    "coBuyerState",
    "coBuyerZip",
    "coBuyerPhone",
    "lienholderName",
    "lienholderAddress",
    "lienholderAddress2",
    "lienholderCity",
    "lienholderState",
    "lienholderZip",
    "lienholderPhone",
    "vehicleVIN",
    "vehicleMake",
    "vehicleModel",
    "vehicleYear",
    "vehicleOdometer",
    "vehicleInServiceDate",
    "vehicleStatus",
    "financeType",
    "amountFinanced",
    "financeTerm"
})
public class AftermarketData {

    @XmlElement(name = "ClientName")
    protected String clientName;
    @XmlElement(name = "DealNumber")
    protected String dealNumber;
    @XmlElement(name = "PENProviderID")
    protected int penProviderID;
    @XmlElement(name = "PENProviderName")
    protected String penProviderName;
    @XmlElement(name = "PENProductID")
    protected int penProductID;
    @XmlElement(name = "PENProductName")
    protected String penProductName;
    @XmlElement(name = "ContractNumber")
    protected String contractNumber;
    @XmlElement(name = "ProductType")
    protected String productType;
    @XmlElement(name = "ProductDescription")
    protected String productDescription;
    @XmlElement(name = "ProductTerm")
    protected String productTerm;
    @XmlElement(name = "ProductMileage")
    protected String productMileage;
    @XmlElement(name = "ProductDeductible")
    protected String productDeductible;
    @XmlElement(name = "ProductDeductibleDescription")
    protected String productDeductibleDescription;
    @XmlElement(name = "ProductPremium")
    protected double productPremium;
    @XmlElement(name = "ProductSellPrice")
    protected double productSellPrice;
    @XmlElement(name = "FIManagerName")
    protected String fiManagerName;
    @XmlElement(name = "FormNumber")
    protected String formNumber;
    @XmlElement(name = "FormRevision")
    protected String formRevision;
    @XmlElement(name = "EffectiveDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar effectiveDate;
    @XmlElement(name = "BuyerFirstName")
    protected String buyerFirstName;
    @XmlElement(name = "BuyerMiddleInitial")
    protected String buyerMiddleInitial;
    @XmlElement(name = "BuyerLastName")
    protected String buyerLastName;
    @XmlElement(name = "BuyerAddress")
    protected String buyerAddress;
    @XmlElement(name = "BuyerAddress2")
    protected String buyerAddress2;
    @XmlElement(name = "BuyerCity")
    protected String buyerCity;
    @XmlElement(name = "BuyerState")
    protected String buyerState;
    @XmlElement(name = "BuyerZip")
    protected String buyerZip;
    @XmlElement(name = "BuyerPhone")
    protected String buyerPhone;
    @XmlElement(name = "CoBuyerFirstName")
    protected String coBuyerFirstName;
    @XmlElement(name = "CoBuyerMiddleInitial")
    protected String coBuyerMiddleInitial;
    @XmlElement(name = "CoBuyerLastName")
    protected String coBuyerLastName;
    @XmlElement(name = "CoBuyerAddress")
    protected String coBuyerAddress;
    @XmlElement(name = "CoBuyerAddress2")
    protected String coBuyerAddress2;
    @XmlElement(name = "CoBuyerCity")
    protected String coBuyerCity;
    @XmlElement(name = "CoBuyerState")
    protected String coBuyerState;
    @XmlElement(name = "CoBuyerZip")
    protected String coBuyerZip;
    @XmlElement(name = "CoBuyerPhone")
    protected String coBuyerPhone;
    @XmlElement(name = "LienholderName")
    protected String lienholderName;
    @XmlElement(name = "LienholderAddress")
    protected String lienholderAddress;
    @XmlElement(name = "LienholderAddress2")
    protected String lienholderAddress2;
    @XmlElement(name = "LienholderCity")
    protected String lienholderCity;
    @XmlElement(name = "LienholderState")
    protected String lienholderState;
    @XmlElement(name = "LienholderZip")
    protected String lienholderZip;
    @XmlElement(name = "LienholderPhone")
    protected String lienholderPhone;
    @XmlElement(name = "VehicleVIN")
    protected String vehicleVIN;
    @XmlElement(name = "VehicleMake")
    protected String vehicleMake;
    @XmlElement(name = "VehicleModel")
    protected String vehicleModel;
    @XmlElement(name = "VehicleYear")
    protected int vehicleYear;
    @XmlElement(name = "VehicleOdometer")
    protected int vehicleOdometer;
    @XmlElement(name = "VehicleInServiceDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar vehicleInServiceDate;
    @XmlElement(name = "VehicleStatus")
    protected String vehicleStatus;
    @XmlElement(name = "FinanceType")
    protected String financeType;
    @XmlElement(name = "AmountFinanced")
    protected double amountFinanced;
    @XmlElement(name = "FinanceTerm")
    protected String financeTerm;

    /**
     * Gets the value of the clientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the value of the clientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientName(String value) {
        this.clientName = value;
    }

    /**
     * Gets the value of the dealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealNumber() {
        return dealNumber;
    }

    /**
     * Sets the value of the dealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealNumber(String value) {
        this.dealNumber = value;
    }

    /**
     * Gets the value of the penProviderID property.
     * 
     */
    public int getPENProviderID() {
        return penProviderID;
    }

    /**
     * Sets the value of the penProviderID property.
     * 
     */
    public void setPENProviderID(int value) {
        this.penProviderID = value;
    }

    /**
     * Gets the value of the penProviderName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPENProviderName() {
        return penProviderName;
    }

    /**
     * Sets the value of the penProviderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPENProviderName(String value) {
        this.penProviderName = value;
    }

    /**
     * Gets the value of the penProductID property.
     * 
     */
    public int getPENProductID() {
        return penProductID;
    }

    /**
     * Sets the value of the penProductID property.
     * 
     */
    public void setPENProductID(int value) {
        this.penProductID = value;
    }

    /**
     * Gets the value of the penProductName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPENProductName() {
        return penProductName;
    }

    /**
     * Sets the value of the penProductName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPENProductName(String value) {
        this.penProductName = value;
    }

    /**
     * Gets the value of the contractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNumber() {
        return contractNumber;
    }

    /**
     * Sets the value of the contractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNumber(String value) {
        this.contractNumber = value;
    }

    /**
     * Gets the value of the productType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductType() {
        return productType;
    }

    /**
     * Sets the value of the productType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductType(String value) {
        this.productType = value;
    }

    /**
     * Gets the value of the productDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Sets the value of the productDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDescription(String value) {
        this.productDescription = value;
    }

    /**
     * Gets the value of the productTerm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTerm() {
        return productTerm;
    }

    /**
     * Sets the value of the productTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTerm(String value) {
        this.productTerm = value;
    }

    /**
     * Gets the value of the productMileage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductMileage() {
        return productMileage;
    }

    /**
     * Sets the value of the productMileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductMileage(String value) {
        this.productMileage = value;
    }

    /**
     * Gets the value of the productDeductible property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDeductible() {
        return productDeductible;
    }

    /**
     * Sets the value of the productDeductible property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDeductible(String value) {
        this.productDeductible = value;
    }

    /**
     * Gets the value of the productDeductibleDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDeductibleDescription() {
        return productDeductibleDescription;
    }

    /**
     * Sets the value of the productDeductibleDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDeductibleDescription(String value) {
        this.productDeductibleDescription = value;
    }

    /**
     * Gets the value of the productPremium property.
     * 
     */
    public double getProductPremium() {
        return productPremium;
    }

    /**
     * Sets the value of the productPremium property.
     * 
     */
    public void setProductPremium(double value) {
        this.productPremium = value;
    }

    /**
     * Gets the value of the productSellPrice property.
     * 
     */
    public double getProductSellPrice() {
        return productSellPrice;
    }

    /**
     * Sets the value of the productSellPrice property.
     * 
     */
    public void setProductSellPrice(double value) {
        this.productSellPrice = value;
    }

    /**
     * Gets the value of the fiManagerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIManagerName() {
        return fiManagerName;
    }

    /**
     * Sets the value of the fiManagerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIManagerName(String value) {
        this.fiManagerName = value;
    }

    /**
     * Gets the value of the formNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormNumber() {
        return formNumber;
    }

    /**
     * Sets the value of the formNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormNumber(String value) {
        this.formNumber = value;
    }

    /**
     * Gets the value of the formRevision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormRevision() {
        return formRevision;
    }

    /**
     * Sets the value of the formRevision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormRevision(String value) {
        this.formRevision = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEffectiveDate(XMLGregorianCalendar value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the buyerFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerFirstName() {
        return buyerFirstName;
    }

    /**
     * Sets the value of the buyerFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerFirstName(String value) {
        this.buyerFirstName = value;
    }

    /**
     * Gets the value of the buyerMiddleInitial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerMiddleInitial() {
        return buyerMiddleInitial;
    }

    /**
     * Sets the value of the buyerMiddleInitial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerMiddleInitial(String value) {
        this.buyerMiddleInitial = value;
    }

    /**
     * Gets the value of the buyerLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerLastName() {
        return buyerLastName;
    }

    /**
     * Sets the value of the buyerLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerLastName(String value) {
        this.buyerLastName = value;
    }

    /**
     * Gets the value of the buyerAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerAddress() {
        return buyerAddress;
    }

    /**
     * Sets the value of the buyerAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerAddress(String value) {
        this.buyerAddress = value;
    }

    /**
     * Gets the value of the buyerAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerAddress2() {
        return buyerAddress2;
    }

    /**
     * Sets the value of the buyerAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerAddress2(String value) {
        this.buyerAddress2 = value;
    }

    /**
     * Gets the value of the buyerCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerCity() {
        return buyerCity;
    }

    /**
     * Sets the value of the buyerCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerCity(String value) {
        this.buyerCity = value;
    }

    /**
     * Gets the value of the buyerState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerState() {
        return buyerState;
    }

    /**
     * Sets the value of the buyerState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerState(String value) {
        this.buyerState = value;
    }

    /**
     * Gets the value of the buyerZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerZip() {
        return buyerZip;
    }

    /**
     * Sets the value of the buyerZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerZip(String value) {
        this.buyerZip = value;
    }

    /**
     * Gets the value of the buyerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyerPhone() {
        return buyerPhone;
    }

    /**
     * Sets the value of the buyerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyerPhone(String value) {
        this.buyerPhone = value;
    }

    /**
     * Gets the value of the coBuyerFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerFirstName() {
        return coBuyerFirstName;
    }

    /**
     * Sets the value of the coBuyerFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerFirstName(String value) {
        this.coBuyerFirstName = value;
    }

    /**
     * Gets the value of the coBuyerMiddleInitial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerMiddleInitial() {
        return coBuyerMiddleInitial;
    }

    /**
     * Sets the value of the coBuyerMiddleInitial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerMiddleInitial(String value) {
        this.coBuyerMiddleInitial = value;
    }

    /**
     * Gets the value of the coBuyerLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerLastName() {
        return coBuyerLastName;
    }

    /**
     * Sets the value of the coBuyerLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerLastName(String value) {
        this.coBuyerLastName = value;
    }

    /**
     * Gets the value of the coBuyerAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerAddress() {
        return coBuyerAddress;
    }

    /**
     * Sets the value of the coBuyerAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerAddress(String value) {
        this.coBuyerAddress = value;
    }

    /**
     * Gets the value of the coBuyerAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerAddress2() {
        return coBuyerAddress2;
    }

    /**
     * Sets the value of the coBuyerAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerAddress2(String value) {
        this.coBuyerAddress2 = value;
    }

    /**
     * Gets the value of the coBuyerCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerCity() {
        return coBuyerCity;
    }

    /**
     * Sets the value of the coBuyerCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerCity(String value) {
        this.coBuyerCity = value;
    }

    /**
     * Gets the value of the coBuyerState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerState() {
        return coBuyerState;
    }

    /**
     * Sets the value of the coBuyerState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerState(String value) {
        this.coBuyerState = value;
    }

    /**
     * Gets the value of the coBuyerZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerZip() {
        return coBuyerZip;
    }

    /**
     * Sets the value of the coBuyerZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerZip(String value) {
        this.coBuyerZip = value;
    }

    /**
     * Gets the value of the coBuyerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBuyerPhone() {
        return coBuyerPhone;
    }

    /**
     * Sets the value of the coBuyerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBuyerPhone(String value) {
        this.coBuyerPhone = value;
    }

    /**
     * Gets the value of the lienholderName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderName() {
        return lienholderName;
    }

    /**
     * Sets the value of the lienholderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderName(String value) {
        this.lienholderName = value;
    }

    /**
     * Gets the value of the lienholderAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderAddress() {
        return lienholderAddress;
    }

    /**
     * Sets the value of the lienholderAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderAddress(String value) {
        this.lienholderAddress = value;
    }

    /**
     * Gets the value of the lienholderAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderAddress2() {
        return lienholderAddress2;
    }

    /**
     * Sets the value of the lienholderAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderAddress2(String value) {
        this.lienholderAddress2 = value;
    }

    /**
     * Gets the value of the lienholderCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderCity() {
        return lienholderCity;
    }

    /**
     * Sets the value of the lienholderCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderCity(String value) {
        this.lienholderCity = value;
    }

    /**
     * Gets the value of the lienholderState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderState() {
        return lienholderState;
    }

    /**
     * Sets the value of the lienholderState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderState(String value) {
        this.lienholderState = value;
    }

    /**
     * Gets the value of the lienholderZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderZip() {
        return lienholderZip;
    }

    /**
     * Sets the value of the lienholderZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderZip(String value) {
        this.lienholderZip = value;
    }

    /**
     * Gets the value of the lienholderPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLienholderPhone() {
        return lienholderPhone;
    }

    /**
     * Sets the value of the lienholderPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLienholderPhone(String value) {
        this.lienholderPhone = value;
    }

    /**
     * Gets the value of the vehicleVIN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleVIN() {
        return vehicleVIN;
    }

    /**
     * Sets the value of the vehicleVIN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleVIN(String value) {
        this.vehicleVIN = value;
    }

    /**
     * Gets the value of the vehicleMake property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleMake() {
        return vehicleMake;
    }

    /**
     * Sets the value of the vehicleMake property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleMake(String value) {
        this.vehicleMake = value;
    }

    /**
     * Gets the value of the vehicleModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleModel() {
        return vehicleModel;
    }

    /**
     * Sets the value of the vehicleModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleModel(String value) {
        this.vehicleModel = value;
    }

    /**
     * Gets the value of the vehicleYear property.
     * 
     */
    public int getVehicleYear() {
        return vehicleYear;
    }

    /**
     * Sets the value of the vehicleYear property.
     * 
     */
    public void setVehicleYear(int value) {
        this.vehicleYear = value;
    }

    /**
     * Gets the value of the vehicleOdometer property.
     * 
     */
    public int getVehicleOdometer() {
        return vehicleOdometer;
    }

    /**
     * Sets the value of the vehicleOdometer property.
     * 
     */
    public void setVehicleOdometer(int value) {
        this.vehicleOdometer = value;
    }

    /**
     * Gets the value of the vehicleInServiceDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVehicleInServiceDate() {
        return vehicleInServiceDate;
    }

    /**
     * Sets the value of the vehicleInServiceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVehicleInServiceDate(XMLGregorianCalendar value) {
        this.vehicleInServiceDate = value;
    }

    /**
     * Gets the value of the vehicleStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleStatus() {
        return vehicleStatus;
    }

    /**
     * Sets the value of the vehicleStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleStatus(String value) {
        this.vehicleStatus = value;
    }

    /**
     * Gets the value of the financeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinanceType() {
        return financeType;
    }

    /**
     * Sets the value of the financeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinanceType(String value) {
        this.financeType = value;
    }

    /**
     * Gets the value of the amountFinanced property.
     * 
     */
    public double getAmountFinanced() {
        return amountFinanced;
    }

    /**
     * Sets the value of the amountFinanced property.
     * 
     */
    public void setAmountFinanced(double value) {
        this.amountFinanced = value;
    }

    /**
     * Gets the value of the financeTerm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinanceTerm() {
        return financeTerm;
    }

    /**
     * Sets the value of the financeTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinanceTerm(String value) {
        this.financeTerm = value;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AftermarketData [clientName=");
		builder.append(clientName);
		builder.append(", dealNumber=");
		builder.append(dealNumber);
		builder.append(", penProviderID=");
		builder.append(penProviderID);
		builder.append(", penProviderName=");
		builder.append(penProviderName);
		builder.append(", penProductID=");
		builder.append(penProductID);
		builder.append(", penProductName=");
		builder.append(penProductName);
		builder.append(", contractNumber=");
		builder.append(contractNumber);
		builder.append(", productType=");
		builder.append(productType);
		builder.append(", productDescription=");
		builder.append(productDescription);
		builder.append(", productTerm=");
		builder.append(productTerm);
		builder.append(", productMileage=");
		builder.append(productMileage);
		builder.append(", productDeductible=");
		builder.append(productDeductible);
		builder.append(", productDeductibleDescription=");
		builder.append(productDeductibleDescription);
		builder.append(", productPremium=");
		builder.append(productPremium);
		builder.append(", productSellPrice=");
		builder.append(productSellPrice);
		builder.append(", fiManagerName=");
		builder.append(fiManagerName);
		builder.append(", formNumber=");
		builder.append(formNumber);
		builder.append(", formRevision=");
		builder.append(formRevision);
		builder.append(", effectiveDate=");
		builder.append(effectiveDate);
		builder.append(", buyerFirstName=");
		builder.append(buyerFirstName);
		builder.append(", buyerMiddleInitial=");
		builder.append(buyerMiddleInitial);
		builder.append(", buyerLastName=");
		builder.append(buyerLastName);
		builder.append(", buyerAddress=");
		builder.append(buyerAddress);
		builder.append(", buyerAddress2=");
		builder.append(buyerAddress2);
		builder.append(", buyerCity=");
		builder.append(buyerCity);
		builder.append(", buyerState=");
		builder.append(buyerState);
		builder.append(", buyerZip=");
		builder.append(buyerZip);
		builder.append(", buyerPhone=");
		builder.append(buyerPhone);
		builder.append(", coBuyerFirstName=");
		builder.append(coBuyerFirstName);
		builder.append(", coBuyerMiddleInitial=");
		builder.append(coBuyerMiddleInitial);
		builder.append(", coBuyerLastName=");
		builder.append(coBuyerLastName);
		builder.append(", coBuyerAddress=");
		builder.append(coBuyerAddress);
		builder.append(", coBuyerAddress2=");
		builder.append(coBuyerAddress2);
		builder.append(", coBuyerCity=");
		builder.append(coBuyerCity);
		builder.append(", coBuyerState=");
		builder.append(coBuyerState);
		builder.append(", coBuyerZip=");
		builder.append(coBuyerZip);
		builder.append(", coBuyerPhone=");
		builder.append(coBuyerPhone);
		builder.append(", lienholderName=");
		builder.append(lienholderName);
		builder.append(", lienholderAddress=");
		builder.append(lienholderAddress);
		builder.append(", lienholderAddress2=");
		builder.append(lienholderAddress2);
		builder.append(", lienholderCity=");
		builder.append(lienholderCity);
		builder.append(", lienholderState=");
		builder.append(lienholderState);
		builder.append(", lienholderZip=");
		builder.append(lienholderZip);
		builder.append(", lienholderPhone=");
		builder.append(lienholderPhone);
		builder.append(", vehicleVIN=");
		builder.append(vehicleVIN);
		builder.append(", vehicleMake=");
		builder.append(vehicleMake);
		builder.append(", vehicleModel=");
		builder.append(vehicleModel);
		builder.append(", vehicleYear=");
		builder.append(vehicleYear);
		builder.append(", vehicleOdometer=");
		builder.append(vehicleOdometer);
		builder.append(", vehicleInServiceDate=");
		builder.append(vehicleInServiceDate);
		builder.append(", vehicleStatus=");
		builder.append(vehicleStatus);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", amountFinanced=");
		builder.append(amountFinanced);
		builder.append(", financeTerm=");
		builder.append(financeTerm);
		builder.append("]");
		return builder.toString();
	}
}