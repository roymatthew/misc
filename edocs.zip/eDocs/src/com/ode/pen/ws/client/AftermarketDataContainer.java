
package com.ode.pen.ws.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AftermarketDataContainer complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AftermarketDataContainer"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DealNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VehicleVIN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductSellPrice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PENProductID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AftermarketDataset" type="{http://exchange.opendealerexchange.com}ArrayOfAftermarketData" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AftermarketDataContainer", propOrder = {
    "dealNumber",
    "vehicleVIN",
    "productSellPrice",
    "penProductID",
    "aftermarketDataset"
})

@XmlRootElement
public class AftermarketDataContainer {

    @XmlElement(name = "DealNumber")
    protected String dealNumber;
    @XmlElement(name = "VehicleVIN")
    protected String vehicleVIN;
    @XmlElement(name = "ProductSellPrice")
    protected String productSellPrice;
    @XmlElement(name = "PENProductID")
    protected String penProductID;
    @XmlElement(name = "AftermarketDataset")
    protected ArrayOfAftermarketData aftermarketDataset;

    /**
     * Gets the value of the dealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDealNumber() {
        return dealNumber;
    }

    /**
     * Sets the value of the dealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDealNumber(String value) {
        this.dealNumber = value;
    }

    /**
     * Gets the value of the vehicleVIN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVehicleVIN() {
        return vehicleVIN;
    }

    /**
     * Sets the value of the vehicleVIN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVehicleVIN(String value) {
        this.vehicleVIN = value;
    }

    /**
     * Gets the value of the productSellPrice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSellPrice() {
        return productSellPrice;
    }

    /**
     * Sets the value of the productSellPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSellPrice(String value) {
        this.productSellPrice = value;
    }

    /**
     * Gets the value of the penProductID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPENProductID() {
        return penProductID;
    }

    /**
     * Sets the value of the penProductID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPENProductID(String value) {
        this.penProductID = value;
    }

    /**
     * Gets the value of the aftermarketDataset property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAftermarketData }
     *     
     */
    public ArrayOfAftermarketData getAftermarketDataset() {
        return aftermarketDataset;
    }

    /**
     * Sets the value of the aftermarketDataset property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAftermarketData }
     *     
     */
    public void setAftermarketDataset(ArrayOfAftermarketData value) {
        this.aftermarketDataset = value;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AftermarketDataContainer [dealNumber=");
		builder.append(dealNumber);
		builder.append(", vehicleVIN=");
		builder.append(vehicleVIN);
		builder.append(", productSellPrice=");
		builder.append(productSellPrice);
		builder.append(", penProductID=");
		builder.append(penProductID);
		builder.append(", aftermarketDataset=");
		builder.append(aftermarketDataset);
		builder.append("]");
		return builder.toString();
	}
}