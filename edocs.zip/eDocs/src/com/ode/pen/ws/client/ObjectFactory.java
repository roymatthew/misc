
package com.ode.pen.ws.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ode.pen.ws.client package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AftermarketAuthenticationHeader_QNAME = new QName("http://exchange.opendealerexchange.com", "AftermarketAuthenticationHeader");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ode.pen.ws.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AftermarketAuthenticationHeader }
     * 
     */
    public AftermarketAuthenticationHeader createAftermarketAuthenticationHeader() {
        return new AftermarketAuthenticationHeader();
    }
    
    /**
     * Create an instance of {@link AftermarketAuthenticationHeader }
     * 
     */
    public AftermarketAuthenticationHeader createAftermarketAuthenticationHeader(String userId, String password) {
        return new AftermarketAuthenticationHeader(userId, password);
    }

    /**
     * Create an instance of {@link AftermarketDataContainer }
     * 
     */
    public AftermarketDataContainer createAftermarketDataContainer() {
        return new AftermarketDataContainer();
    }

    /**
     * Create an instance of {@link ArrayOfAftermarketData }
     * 
     */
    public ArrayOfAftermarketData createArrayOfAftermarketData() {
        return new ArrayOfAftermarketData();
    }

    /**
     * Create an instance of {@link AftermarketData }
     * 
     */
    public AftermarketData createAftermarketData() {
        return new AftermarketData();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AftermarketAuthenticationHeader }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://exchange.opendealerexchange.com", name = "AftermarketAuthenticationHeader")
    public JAXBElement<AftermarketAuthenticationHeader> createAftermarketAuthenticationHeader(AftermarketAuthenticationHeader value) {
        return new JAXBElement<AftermarketAuthenticationHeader>(_AftermarketAuthenticationHeader_QNAME, AftermarketAuthenticationHeader.class, null, value);
    }

}
