@javax.xml.bind.annotation.XmlSchema(namespace = "http://exchange.opendealerexchange.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ode.pen.ws.client;
