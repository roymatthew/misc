package com.ode.vault.db.entity;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "CRGATE.VAULT_REGISTER_DOCUMENT")
public class VaultRegisterDocument {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "VAULT_REGISTER_ID")
	private int vaultRegisterId;

	@Column(name = "DOCUMENT_ID")
	private String documentId;

	@Column(name = "DEAL_ID")
	private String dealId;

	@Column(name = "DEALER_ID")
	private String dealerId;

	@Column(name = "CREATED_TS")
	private Date createdTs;

	@Column(name = "MODIFIED_TS")
	private Date modifiedTs;

	public int getVaultRegisterId() {
		return vaultRegisterId;
	}

	public void setVaultRegisterId(int vaultRegisterId) {
		this.vaultRegisterId = vaultRegisterId;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getModifiedTs() {
		return modifiedTs;
	}

	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VaultRegisterDocument [vaultRegisterId=");
		builder.append(vaultRegisterId);
		builder.append(", documentId=");
		builder.append(documentId);
		builder.append(", dealId=");
		builder.append(dealId);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append("]");
		return builder.toString();
	}

}