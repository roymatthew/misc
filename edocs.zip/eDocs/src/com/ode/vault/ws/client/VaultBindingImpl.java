package com.ode.vault.ws.client;

import java.net.URL;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@javax.jws.WebService(endpointInterface = "com.ode.vault.ws.client.VaultPortType", targetNamespace = "http://vault.ws.opendealerexchange.com/Vault", serviceName = "VaultService", portName = "VaultPort")
public class VaultBindingImpl {
	private static final Logger LOGGER = LogManager.getLogger(VaultBindingImpl.class);

	@Value("${vaultServiceUrl}")
	private String vaultServiceUrl;

	public VaultBindingImpl() {
	}

	public AssignDocumentResponse assignDocument(AssignDocumentRequest assignDocumentRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			AssignDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.assignDocument(assignDocumentRequestPart);
			return response;
		} catch (Exception ex) {
			// ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - assignDocument");
		}
	}

	public WithdrawDocumentResponse withdrawDocument(WithdrawDocumentRequest withdrawDocumentRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			WithdrawDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.withdrawDocument(withdrawDocumentRequestPart);
			return response;
		} catch (Exception ex) {
			// ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - withdrawDocument");
		}

	}

	public AcceptDocumentResponse acceptDocument(AcceptDocumentRequest acceptDocumentRequestPart) {
		LOGGER.debug(acceptDocumentRequestPart);
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			LOGGER.info("Invoking Accept Document........");
			AcceptDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.acceptDocument(acceptDocumentRequestPart);
			return (response);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - acceptDocument");
		}
	}

	public RejectDocumentResponse rejectDocument(RejectDocumentRequest rejectDocumentRequestPart) {
		LOGGER.debug(rejectDocumentRequestPart);
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			RejectDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.rejectDocument(rejectDocumentRequestPart);
			return (response);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - rejectDocument");
		}

	}

	public VoidDocumentResponse voidDocument(VoidDocumentRequest voidDocumentRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			VoidDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.voidDocument(voidDocumentRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - voidDocument");
		}
	}

	public ViewDocumentResponse viewDocument(ViewDocumentRequest viewDocumentRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			ViewDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.viewDocument(viewDocumentRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - viewDocument");
		}
	}

	public ListPartnersResponse listPartners(ListPartnersRequest listPartnersRequestPart) {

		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			ListPartnersResponse response = new VaultService(wsdlUrl).getVaultPort()
					.listPartners(listPartnersRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - listPartners");
		}

	}

	public AuditTrailResponse auditTrail(AuditTrailRequest auditTrailRequestPart) {

		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			AuditTrailResponse response = new VaultService(wsdlUrl).getVaultPort().auditTrail(auditTrailRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - auditTrail");
		}

	}

	public SearchResponse search(SearchRequest searchRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			SearchResponse response = new VaultService(wsdlUrl).getVaultPort().search(searchRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - search");
		}
	}

	public LoginResponse login(LoginRequest loginRequestPart) {
		LOGGER.debug(loginRequestPart);
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			LOGGER.debug("wsdl:{}", wsdlUrl);
			VaultService service = new VaultService(wsdlUrl);
			LOGGER.debug("service:{}", service);
			VaultPortType vaultPortType = service.getVaultPort();
			LOGGER.debug("vaultPortType:{}", vaultPortType);
			LoginResponse response = vaultPortType.login(loginRequestPart);
			return (response);
		} catch (Exception ex) {
			LOGGER.error("Webservice call failure - login", ex);
			throw new RuntimeException("Webservice call failure - login");
		}
	}

	public LogoutResponse logout(LogoutRequest logoutRequestPart) {
		LOGGER.debug(logoutRequestPart);
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			LogoutResponse response = new VaultService(wsdlUrl).getVaultPort().logout(logoutRequestPart);
			return (response);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - logout");
		}

	}

	public String getVault_service_url() {
		return vaultServiceUrl;
	}

	public void setVault_service_url(String vault_service_url) {
		this.vaultServiceUrl = vault_service_url;
	}

	public CompletePaperOutResponse completePaperOut(CompletePaperOutRequest completePaperOutRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			CompletePaperOutResponse response = new VaultService(wsdlUrl).getVaultPort()
					.completePaperOut(completePaperOutRequestPart);
			return response;

		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - completePaperOut");
		}

	}

	public BeginPaperOutResponse beginPaperOut(BeginPaperOutRequest beginPaperOutRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			BeginPaperOutResponse response = new VaultService(wsdlUrl).getVaultPort()
					.beginPaperOut(beginPaperOutRequestPart);
			return response;

		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - beginPaperOut");
		}
	}

	public CancelPaperOutResponse cancelPaperOut(CancelPaperOutRequest cancelPaperOutRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			CancelPaperOutResponse response = new VaultService(wsdlUrl).getVaultPort()
					.cancelPaperOut(cancelPaperOutRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - cancelPaperOut");
		}
	}

	public RegisterDocumentResponse registerDocument(RegisterDocumentRequest registerDocumentRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			RegisterDocumentResponse response = new VaultService(wsdlUrl).getVaultPort()
					.registerDocument(registerDocumentRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - registerDocument");
		}
	}

	public CreateUserResponse createUser(CreateUserRequest createUserRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			CreateUserResponse response = new VaultService(wsdlUrl).getVaultPort().createUser(createUserRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - createUser");
		}
	}

	public GetUsersResponse getUsers(GetUsersRequest getUsersRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			GetUsersResponse response = new VaultService(wsdlUrl).getVaultPort().getUsers(getUsersRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - getUsers");
		}
	}

	public UpdateUserResponse updateUser(UpdateUserRequest updateUserRequestPart) {
		try {
			LOGGER.debug("vaultServiceUrl:{}", vaultServiceUrl);
			URL wsdlUrl = new URL(vaultServiceUrl);
			UpdateUserResponse response = new VaultService(wsdlUrl).getVaultPort().updateUser(updateUserRequestPart);
			return response;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("Webservice call failure - updateUser");
		}
	}

	public String getVaultServiceUrl() {
		return vaultServiceUrl;
	}

	public void setVaultServiceUrl(String vaultServiceUrl) {
		this.vaultServiceUrl = vaultServiceUrl;
	}

}