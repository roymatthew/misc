# RE-2-API

This project is the source code for phase 2 of Open Dealer Exchange Rules Engine.  
This project uses Spring boot 2.1.6,  ORM Hibernate 5, Gradle 5.x as build Tool.

The project from Phase 1 utilized Maven that has been converted to use Gradle.
The existing Maven dependencies from Phase 1 are automatically converted and added to Gradle build file to be used in Phase 2
