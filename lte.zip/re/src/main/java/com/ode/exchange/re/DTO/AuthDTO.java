package com.ode.exchange.re.DTO;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AuthDTO {

	@JsonProperty("userDetails")	
	private UserDTO userDTO;
	
	@JsonProperty("functionalityMappingList")	
	private List<FunctionalityUserRoleMappingDTO> functionalitylistmapperDTO;

	public UserDTO getUserDTO() {
		return userDTO;
	}

	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}
	@JsonProperty("functionalityMappingList")
	public List<FunctionalityUserRoleMappingDTO> getFunctionalitymapperDTO() {
		return functionalitylistmapperDTO;
	}
	
	@JsonProperty("functionalityMappingList")
	public void setFunctionalitymapperDTO(List<FunctionalityUserRoleMappingDTO> functionalitylistmapperDTO) {
		this.functionalitylistmapperDTO = functionalitylistmapperDTO;
	}

	@Override
	public String toString() {
		return "AuthDTO [userDTO=" + userDTO + ", functionalitylistmapperDTO=" + functionalitylistmapperDTO + "]";
	}
	
	
	
}
