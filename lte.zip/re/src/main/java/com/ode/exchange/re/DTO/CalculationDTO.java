package com.ode.exchange.re.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.sql.Timestamp;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "createdDate", "updatedDate"})
public class CalculationDTO {


	@JsonProperty("calculationID")
	private int id;

	@JsonProperty("financeType")
	private String financeType;

	@JsonProperty("calculationName")
	private String calculationName;


	@JsonProperty("calculationJSON")
	private String calculationJSON;


	@JsonProperty("remarks")
	private String remarks;

	@JsonProperty("state")
	private String state;

	@JsonProperty("lender")
	private String lender;

	@JsonProperty("createdDate")
	private Timestamp createdDate;

	@JsonProperty("createdBy")
	private int createdBy;

	@JsonProperty("updatedBy")
	private int updatedBy;

	@JsonProperty("updatedDate")
	private Timestamp updatedDate;

	@JsonProperty("preventNegativeValue")
	private Boolean preventNegativeValue;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public String getCalculationName() {
		return calculationName;
	}

	public void setCalculationName(String calculationName) {
		this.calculationName = calculationName;
	}

	public String getCalculationJSON() {
		return calculationJSON;
	}

	public void setCalculationJSON(String calculationJSON) {
		this.calculationJSON = calculationJSON;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}



	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLender() {
		return lender;
	}

	public void setLender(String lender) {
		this.lender = lender;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Boolean getPreventNegativeValue() {
		return preventNegativeValue;
	}

	public void setPreventNegativeValue(Boolean preventNegativeValue) {
		this.preventNegativeValue = preventNegativeValue;
	}

	@Override
	public String toString() {
		return "CalculationDTO [id=" + id + ", financeType=" + financeType + ", calculationName=" + calculationName
				+ ", calculationJSON=" + calculationJSON + ", remarks=" + remarks + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", preventNegativeValue=" + preventNegativeValue + ", updatedBy="
				+ updatedBy
				+ ", updatedDate=" + updatedDate + "]";
	}





}
