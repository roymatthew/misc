package com.ode.exchange.re.DTO;

import java.sql.Timestamp;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties({ "CreditDecisionId","CreatedBy", "ModifiedBy", "CreatedTs", "ModifiedTs", "SubmittedTs", "DecisionTs", "StatusTs", "ConversationId", "SequenceId","vin","ltv"})
public class CreditDecisionDTO implements java.io.Serializable{
	private static final long serialVersionUID = 1L;
	@JsonProperty("CreditDecisionId")
	private int id;
	
	@JsonProperty("DmsDealerId")
	private String dmsDealerId;	
	
	@JsonProperty("LenderDealerId")
	private String lenderDealerId;	
	
	@JsonProperty("DmsDealNum")
	private String dmsDealNum;
	
	@JsonProperty("LenderId")
	private String lenderId;
	
	@JsonProperty("DeDealId")
	private String deDealId;
	
	@JsonProperty("SequenceId")
	private String sequenceId;
	
	@JsonProperty("R1lenderId")
	private String r1lenderId;
	
	@JsonProperty("ConversationId")
	private String conversationId;
	
	@JsonProperty("R1SequenceNum")
	private String r1SequenceNum;
	
	@JsonProperty("StatusTs")
	private Timestamp statusTs;
	
	@JsonProperty("SubmittedTs")	
	private Timestamp submittedTs;
	
	@JsonProperty("DecisionTs")
	private Timestamp decisionTs;
	
	@JsonProperty("VIN")	
	private String VIN;
	
	@JsonProperty("BuyerSSN")
	private String buyerSSN;
	
	@JsonProperty("BuyerFirstName")
	private String buyerFirstName;
	
	@JsonProperty("BuyerLastName")	
	private String buyerLastName;
	
	@JsonProperty("BuyerApplicationAddressLine")
	private String buyerApplicationAddressLine;
	
	@JsonProperty("BuyerApplicationAddressCity")
	private String buyerApplicationAddressCity;
	
	@JsonProperty("BuyerApplicationAddressState")
	private String buyerApplicationAddressState;
	
	@JsonProperty("BuyerApplicationAddressZipCode")
	private String buyerApplicationAddressZipCode;
	
	@JsonProperty("CoBuyerSSN")
	private String coBuyerSSN;
	
	@JsonProperty("CobuyerFirstName")
	private String cobuyerFirstName;
	
	@JsonProperty("CobuyerLastName")
	private String cobuyerLastName;
	
	@JsonProperty("CobuyerApplicationAddressLine")
	private String cobuyerApplicationAddressLine;
	
	@JsonProperty("CobuyerApplicationAddressCity")
	private String cobuyerApplicationAddressCity;
	
	@JsonProperty("CobuyerApplicationAddressState")
	private String cobuyerApplicationAddressState ;
	
	@JsonProperty("CobuyerApplicationAddressZipcode")
	private String cobuyerApplicationAddressZipcode;
	
	@JsonProperty("ApplicationStatus")
	private String applicationStatus;
	
	@JsonProperty("ApplicationNumber")
	private String applicationNumber;
	
	@JsonProperty("Model")
	private String model;
	
	@JsonProperty("ModelYear")
	private int modelYear;
	
	@JsonProperty("AmountFinanced")
	private Double amountFinanced;
	
	@JsonProperty("LTV")
	private String LTV;
	
	@JsonProperty("ApplicationType")
	private String applicationType;
	
	@JsonProperty("ModelDescription")
	private String modelDescription;
	
	@JsonProperty("Make")
	private String make;
	
	@JsonProperty("SalesClass")
	private String salesClass;
	
	@JsonProperty("CertifiedPreOwned")
	private boolean certifiedPreOwned;
	
	@JsonProperty("DeliveryMileage")
	private Double deliveryMileage ;
	
	@JsonProperty("VehicleStock")
	private String vehicleStock;
	
	@JsonProperty("BodyStyle")
	private String bodyStyle;
	
	@JsonProperty("FinanceType")	
	private String financeType;
	
	@JsonProperty("PaymentAmount")	
	private Double paymentAmount;
	
	@JsonProperty("BalanceAmount")	
	private Double balanceAmount;
	
	@JsonProperty("ResidualAmount")	
	private Double residualAmount;
	
	@JsonProperty("PurchasePrice")	
	private Double purchasePrice;
	
	@JsonProperty("Term")
	private Double term;
	
	@JsonProperty("DownpaymentAmount")	
	private Double downpaymentAmount;
	
	@JsonProperty("ManufacturerRebateAmount")
	private Double manufacturerRebateAmount;
	
	@JsonProperty("AnnualPercentageRate")
	private Double annualPercentageRate;
	
	@JsonProperty("NetTradeAmount")
	private Double netTradeAmount;
	
	@JsonProperty("InsuranceTotalExtendedWarrantyAmount")
	private Double insuranceTotalExtendedWarrantyAmount;
	
	@JsonProperty("DisabilityPremiumAmount")
	private Double disabilityPremiumAmount;
	
	@JsonProperty("CreditLifePremiumAmount")
	private Double creditLifePremiumAmount;
	
	@JsonProperty("SecurityDepositAmount")
	private Double securityDepositAmount;
	
	@JsonProperty("Tier")
	private String tier;
	
	@JsonProperty("Stipulations")
	private String stipulations;
	
	@JsonProperty("CreatedBy")
	private String createdBy;
	
	@JsonProperty("ModifiedBy")
	private String  modifiedBy;
	
	@JsonProperty("CreatedTs")
	private Timestamp createdTs;
	
	@JsonProperty("ModifiedTs")
	private Timestamp modifiedTs;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDmsDealerId() {
		return dmsDealerId;
	}

	public void setDmsDealerId(String dmsDealerId) {
		this.dmsDealerId = dmsDealerId;
	}

	public String getLenderDealerId() {
		return lenderDealerId;
	}

	public void setLenderDealerId(String lenderDealerId) {
		this.lenderDealerId = lenderDealerId;
	}

	public String getDmsDealNum() {
		return dmsDealNum;
	}

	public void setDmsDealNum(String dmsDealNum) {
		this.dmsDealNum = dmsDealNum;
	}

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public String getDeDealId() {
		return deDealId;
	}

	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}

	public String getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getR1lenderId() {
		return r1lenderId;
	}

	public void setR1lenderId(String r1lenderId) {
		this.r1lenderId = r1lenderId;
	}

	public String getConversationId() {
		return conversationId;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	public String getR1SequenceNum() {
		return r1SequenceNum;
	}

	public void setR1SequenceNum(String r1SequenceNum) {
		this.r1SequenceNum = r1SequenceNum;
	}

	public Timestamp getStatusTs() {
		return statusTs;
	}

	public void setStatusTs(Timestamp statusTs) {
		this.statusTs = statusTs;
	}

	public Timestamp getSubmittedTs() {
		return submittedTs;
	}

	public void setSubmittedTs(Timestamp submittedTs) {
		this.submittedTs = submittedTs;
	}

	public Timestamp getDecisionTs() {
		return decisionTs;
	}

	public void setDecisionTs(Timestamp decisionTs) {
		this.decisionTs = decisionTs;
	}

	

	public String getBuyerSSN() {
		return buyerSSN;
	}

	public void setBuyerSSN(String buyerSSN) {
		this.buyerSSN = buyerSSN;
	}

	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	public String getBuyerLastName() {
		return buyerLastName;
	}

	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	public String getBuyerApplicationAddressLine() {
		return buyerApplicationAddressLine;
	}

	public void setBuyerApplicationAddressLine(String buyerApplicationAddressLine) {
		this.buyerApplicationAddressLine = buyerApplicationAddressLine;
	}

	public String getBuyerApplicationAddressCity() {
		return buyerApplicationAddressCity;
	}

	public void setBuyerApplicationAddressCity(String buyerApplicationAddressCity) {
		this.buyerApplicationAddressCity = buyerApplicationAddressCity;
	}

	public String getBuyerApplicationAddressState() {
		return buyerApplicationAddressState;
	}

	public void setBuyerApplicationAddressState(String buyerApplicationAddressState) {
		this.buyerApplicationAddressState = buyerApplicationAddressState;
	}

	public String getBuyerApplicationAddressZipCode() {
		return buyerApplicationAddressZipCode;
	}

	public void setBuyerApplicationAddressZipCode(String buyerApplicationAddressZipCode) {
		this.buyerApplicationAddressZipCode = buyerApplicationAddressZipCode;
	}

	public String getCoBuyerSSN() {
		return coBuyerSSN;
	}

	public void setCoBuyerSSN(String coBuyerSSN) {
		this.coBuyerSSN = coBuyerSSN;
	}

	public String getCobuyerFirstName() {
		return cobuyerFirstName;
	}

	public void setCobuyerFirstName(String cobuyerFirstName) {
		this.cobuyerFirstName = cobuyerFirstName;
	}

	public String getCobuyerLastName() {
		return cobuyerLastName;
	}

	public void setCobuyerLastName(String cobuyerLastName) {
		this.cobuyerLastName = cobuyerLastName;
	}

	public String getCobuyerApplicationAddressLine() {
		return cobuyerApplicationAddressLine;
	}

	public void setCobuyerApplicationAddressLine(String cobuyerApplicationAddressLine) {
		this.cobuyerApplicationAddressLine = cobuyerApplicationAddressLine;
	}

	public String getCobuyerApplicationAddressCity() {
		return cobuyerApplicationAddressCity;
	}

	public void setCobuyerApplicationAddressCity(String cobuyerApplicationAddressCity) {
		this.cobuyerApplicationAddressCity = cobuyerApplicationAddressCity;
	}

	public String getCobuyerApplicationAddressState() {
		return cobuyerApplicationAddressState;
	}

	public void setCobuyerApplicationAddressState(String cobuyerApplicationAddressState) {
		this.cobuyerApplicationAddressState = cobuyerApplicationAddressState;
	}

	public String getCobuyerApplicationAddressZipcode() {
		return cobuyerApplicationAddressZipcode;
	}

	public void setCobuyerApplicationAddressZipcode(String cobuyerApplicationAddressZipcode) {
		this.cobuyerApplicationAddressZipcode = cobuyerApplicationAddressZipcode;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public Double getAmountFinanced() {
		return amountFinanced;
	}

	public String getVIN() {
		return VIN;
	}

	public void setVIN(String vIN) {
		VIN = vIN;
	}

	public String getLTV() {
		return LTV;
	}

	public void setLTV(String lTV) {
		LTV = lTV;
	}

	public void setAmountFinanced(Double amountFinanced) {
		this.amountFinanced = amountFinanced;
	}

	

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getModelDescription() {
		return modelDescription;
	}

	public void setModelDescription(String modelDescription) {
		this.modelDescription = modelDescription;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getSalesClass() {
		return salesClass;
	}

	public void setSalesClass(String salesClass) {
		this.salesClass = salesClass;
	}

	public boolean isCertifiedPreOwned() {
		return certifiedPreOwned;
	}

	public void setCertifiedPreOwned(boolean certifiedPreOwned) {
		this.certifiedPreOwned = certifiedPreOwned;
	}

	public Double getDeliveryMileage() {
		return deliveryMileage;
	}

	public void setDeliveryMileage(Double deliveryMileage) {
		this.deliveryMileage = deliveryMileage;
	}

	public String getVehicleStock() {
		return vehicleStock;
	}

	public void setVehicleStock(String vehicleStock) {
		this.vehicleStock = vehicleStock;
	}

	public String getBodyStyle() {
		return bodyStyle;
	}

	public void setBodyStyle(String bodyStyle) {
		this.bodyStyle = bodyStyle;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public Double getResidualAmount() {
		return residualAmount;
	}

	public void setResidualAmount(Double residualAmount) {
		this.residualAmount = residualAmount;
	}

	public Double getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(Double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public Double getTerm() {
		return term;
	}

	public void setTerm(Double term) {
		this.term = term;
	}

	public Double getDownpaymentAmount() {
		return downpaymentAmount;
	}

	public void setDownpaymentAmount(Double downpaymentAmount) {
		this.downpaymentAmount = downpaymentAmount;
	}

	public Double getManufacturerRebateAmount() {
		return manufacturerRebateAmount;
	}

	public void setManufacturerRebateAmount(Double manufacturerRebateAmount) {
		this.manufacturerRebateAmount = manufacturerRebateAmount;
	}

	public Double getAnnualPercentageRate() {
		return annualPercentageRate;
	}

	public void setAnnualPercentageRate(Double annualPercentageRate) {
		this.annualPercentageRate = annualPercentageRate;
	}

	public Double getNetTradeAmount() {
		return netTradeAmount;
	}

	public void setNetTradeAmount(Double netTradeAmount) {
		this.netTradeAmount = netTradeAmount;
	}

	public Double getInsuranceTotalExtendedWarrantyAmount() {
		return insuranceTotalExtendedWarrantyAmount;
	}

	public void setInsuranceTotalExtendedWarrantyAmount(Double insuranceTotalExtendedWarrantyAmount) {
		this.insuranceTotalExtendedWarrantyAmount = insuranceTotalExtendedWarrantyAmount;
	}

	public Double getDisabilityPremiumAmount() {
		return disabilityPremiumAmount;
	}

	public void setDisabilityPremiumAmount(Double disabilityPremiumAmount) {
		this.disabilityPremiumAmount = disabilityPremiumAmount;
	}

	public Double getCreditLifePremiumAmount() {
		return creditLifePremiumAmount;
	}

	public void setCreditLifePremiumAmount(Double creditLifePremiumAmount) {
		this.creditLifePremiumAmount = creditLifePremiumAmount;
	}

	public Double getSecurityDepositAmount() {
		return securityDepositAmount;
	}

	public void setSecurityDepositAmount(Double securityDepositAmount) {
		this.securityDepositAmount = securityDepositAmount;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getStipulations() {
		return stipulations;
	}

	public void setStipulations(String stipulations) {
		this.stipulations = stipulations;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	public Timestamp getModifiedTs() {
		return modifiedTs;
	}

	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}

	@Override
	public String toString() {
		return "CreditDecisionDTO [id=" + id + ", dmsDealerId=" + dmsDealerId + ", lenderDealerId=" + lenderDealerId
				+ ", dmsDealNum=" + dmsDealNum + ", lenderId=" + lenderId + ", deDealId=" + deDealId + ", sequenceId="
				+ sequenceId + ", r1lenderId=" + r1lenderId + ", conversationId=" + conversationId + ", r1SequenceNum="
				+ r1SequenceNum + ", statusTs=" + statusTs + ", submittedTs=" + submittedTs + ", decisionTs="
				+ decisionTs + ", VIN=" + VIN + ", buyerSSN=" + buyerSSN + ", buyerFirstName=" + buyerFirstName
				+ ", buyerLastName=" + buyerLastName + ", buyerApplicationtAddressLine=" + buyerApplicationAddressLine
				+ ", buyerApplicationtAddressCity=" + buyerApplicationAddressCity + ", buyerApplicationtAddressState="
				+ buyerApplicationAddressState + ", buyerApplicationtAddressZipCode=" + buyerApplicationAddressZipCode
				+ ", coBuyerSSN=" + coBuyerSSN + ", cobuyerFirstName=" + cobuyerFirstName + ", cobuyerLastName="
				+ cobuyerLastName + ", cobuyerApplicationtAddressLine=" + cobuyerApplicationAddressLine
				+ ", cobuyerApplicationtAddressCity=" + cobuyerApplicationAddressCity
				+ ", cobuyerApplicationtAddressState=" + cobuyerApplicationAddressState
				+ ", cobuyerApplicationtAddressZipcode=" + cobuyerApplicationAddressZipcode + ", applicationStatus="
				+ applicationStatus + ", applicationNumber=" + applicationNumber + ", model=" + model + ", modelYear="
				+ modelYear + ", amountFinanced=" + amountFinanced + ", LTV=" + LTV + ", applicationType="
				+ applicationType + ", modelDescription=" + modelDescription + ", make=" + make + ", salesClass="
				+ salesClass + ", certifiedPreOwned=" + certifiedPreOwned + ", deliveryMileage=" + deliveryMileage
				+ ", vehicleStock=" + vehicleStock + ", bodyStyle=" + bodyStyle + ", financeType=" + financeType
				+ ", paymentAmount=" + paymentAmount + ", balanceAmount=" + balanceAmount + ", residualAmount="
				+ residualAmount + ", purchasePrice=" + purchasePrice + ", term=" + term + ", downpaymentAmount="
				+ downpaymentAmount + ", manufacturerRebateAmount=" + manufacturerRebateAmount
				+ ", annualPercentageRate=" + annualPercentageRate + ", netTradeAmount=" + netTradeAmount
				+ ", insuranceTotalExtendedWarrantyAmount=" + insuranceTotalExtendedWarrantyAmount
				+ ", disabilityPremiumAmount=" + disabilityPremiumAmount + ", creditLifePremiumAmount="
				+ creditLifePremiumAmount + ", securityDepositAmount=" + securityDepositAmount + ", tier=" + tier
				+ ", stipulations=" + stipulations + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy
				+ ", createdTs=" + createdTs + ", modifiedTs=" + modifiedTs + "]";
	}
	
	
	
}
