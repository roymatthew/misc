package com.ode.exchange.re.DTO;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "fieldNameID" , "createdDate" })
public class DropDownDTO {

	@JsonProperty("DDID")
	private int id;

	@JsonProperty("fieldNameID")
	private int fieldNameID;

	@JsonProperty("value")
	private String value;

	@JsonProperty("code")
	private String code;

	@JsonProperty("sortOrder")
	private int sortOrder;

	@JsonProperty("displayField")
	private char displayField;

	@JsonProperty("status")
	private boolean status;

	@JsonProperty("createdBy")
	private int createdBy;

	@JsonProperty("createdDate")
	private Timestamp createdDate;	


	@Override
	public String toString() {
		return "DropDownDTO [id=" + id + ", fieldNameID=" + fieldNameID + ", value=" + value + ", code=" + code
				+ ", sortOrder=" + sortOrder + ", displayField=" + displayField + ", status=" + status + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + "]";
	}

	@JsonProperty("DDID")
	public int getId() {
		return id;
	}

	@JsonProperty("DDID")
	public void setId(int id) {
		this.id = id;
	}

	@JsonProperty("fieldNameID")
	public int getFieldNameID() {
		return fieldNameID;
	}

	@JsonProperty("fieldNameID")
	public void setFieldNameID(int fieldNameID) {
		this.fieldNameID = fieldNameID;
	}

	@JsonProperty("value")
	public String getValue() {
		return value;
	}

	@JsonProperty("value")
	public void setValue(String value) {
		this.value = value;
	}

	@JsonProperty("code")
	public String isCode() {
		return code;
	}

	@JsonProperty("code")
	public void setCode(String code) {
		this.code = code;
	}

	@JsonProperty("sortOrder")
	public int getSortOrder() {
		return sortOrder;
	}

	@JsonProperty("sortOrder")
	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	@JsonProperty("displayField")
	public char getDisplayField() {
		return displayField;
	}

	@JsonProperty("displayField")
	public void setDisplayField(char displayField) {
		this.displayField = displayField;
	}

	@JsonProperty("status")
	public boolean getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(boolean status) {
		this.status = status;
	}

	@JsonProperty("createdBy")
	public int getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("createdBy")
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("createdDate")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	@JsonProperty("createdDate")
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}


}
