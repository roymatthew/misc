package com.ode.exchange.re.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FieldDTO implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	@JsonProperty("fieldNameID")
	private int id;

	@JsonProperty("fieldName")
	private String fieldName;


	@JsonProperty("dataType")
	private String datatype;

	@JsonProperty("xPath")
	private String xPath;

	@JsonProperty("lookupUsage")
	private boolean lookupUsage;


	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}

	public String getDatatype() {
		return datatype;
	}

	@JsonProperty("fieldNameID")
	public int getId() {
		return id;
	}

	@JsonProperty("fieldNameID")
	public void setId(int id) {
		this.id = id;
	}

	@JsonProperty("fieldName")
	public String getFieldName() {
		return fieldName;
	}

	@JsonProperty("fieldName")
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	@JsonProperty("dataType")
	public String isDatatype() {
		return datatype;
	}

	@JsonProperty("dataType")
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	@JsonProperty("xPath")
	public String getxPath() {
		return xPath;
	}

	@JsonProperty("xPath")
	public void setxPath(String xPath) {
		this.xPath = xPath;
	}

	@Override
	public String toString() {
		return "FieldDTO [id=" + id + ", fieldName=" + fieldName + ", datatype=" + datatype + ", xPath=" + xPath
				+ ", lookupUsage="
				+ lookupUsage + "]";
	}


}
