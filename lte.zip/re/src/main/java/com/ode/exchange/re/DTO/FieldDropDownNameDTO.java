package com.ode.exchange.re.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FieldDropDownNameDTO {
	
	@JsonProperty("fieldNameDetails")
	private FieldDTO fieldDTO;
	
	@JsonProperty("fieldNameDropDownDetails")
	private FieldNameDTO fieldNameDTO;
	
	public FieldDTO getFieldDTO() {
		return fieldDTO;
	}
	public void setFieldDTO(FieldDTO fieldDTO) {
		this.fieldDTO = fieldDTO;
	}
	public FieldNameDTO getFieldNameDTO() {
		return fieldNameDTO;
	}
	public void setFieldNameDTO(FieldNameDTO fieldNameDTO) {
		this.fieldNameDTO = fieldNameDTO;
	}
	
	@Override
	public String toString() {
		return "FieldDropDownNameDTO [fieldDTO=" + fieldDTO + ", fieldNameDTO=" + fieldNameDTO + "]";
	}
	
	
	

}
