package com.ode.exchange.re.DTO;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "DataType" , "fieldNameID", "REUsage" ,"LookupUsage","XPath","Repeatable"})
public class FieldNameDTO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("fieldNameID")
	private int id;

	@JsonProperty("REUsage")
	private boolean reUsage;

	@JsonProperty("LookupUsage")
	private boolean lookupUsage;

	@JsonProperty( "fieldName")
	private String aliasFieldName;	

	@JsonProperty("DataType")
	private String dataType;

	@JsonProperty( "XPath")
	private String xPath;
	
	@JsonProperty("Repeatable")
	private Boolean repeatable;

	@JsonProperty("values")
	private List<DropDownDTO> dropdownDTOlist=new ArrayList<DropDownDTO>();
	
	@JsonProperty("fieldNameID")
	public int getId() {
		return id;
	}

	@JsonProperty("fieldNameID")
	public void setId(int id) {
		this.id = id;
	}


	@JsonProperty("values")
	public List<DropDownDTO> getDropdownDTOlist() {
		return dropdownDTOlist;
	}

	@JsonProperty("values")
	public void setDropdownDTOlist(List<DropDownDTO> dropdownDTOlist) {
		this.dropdownDTOlist = dropdownDTOlist;
	}

	public boolean isReUsage() {
		return reUsage;
	}

	public void setReUsage(boolean reUsage) {
		this.reUsage = reUsage;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}
	@Column(name = "fieldName")
	public String getAliasFieldName() {
		return aliasFieldName;
	}
	@Column(name = "fieldName")
	public void setAliasFieldName(String aliasFieldName) {
		this.aliasFieldName = aliasFieldName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}

	public Boolean getRepeatable() {
		return repeatable;
	}

	public void setRepeatable(Boolean repeatable) {
		this.repeatable = repeatable;
	}

	

	
	
}
