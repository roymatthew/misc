package com.ode.exchange.re.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FunctionalityDTO {
	
	@JsonProperty("functionalityID")
	private int id;
	
	@JsonProperty("funtionalityName")
	private String functionalityName;
	
	
	
	public String getFunctionalityName() {
		return functionalityName;
	}

	public void setFunctionalityName(String functionalityName) {
		this.functionalityName = functionalityName;
	}

	@Override
	public String toString() {
		return "FunctionalityDTO [id=" + id + ", functionalityName=" + functionalityName + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	
	
}
