package com.ode.exchange.re.DTO;

import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FunctionalityMapDTO {

	@JsonProperty("userRoleID")	
	private int userroleID;
	
	@JsonProperty("Functionalities")	
	private HashMap<Integer,List<FunctionalityDTO>> Functionalitymap;

	
	@JsonProperty("Functionalities")
	public HashMap<Integer, List<FunctionalityDTO>> getFunctionalitymap() {
		return Functionalitymap;
	}
	@JsonProperty("Functionalities")
	public void setFunctionalitymap(HashMap<Integer, List<FunctionalityDTO>> functionalitymap) {
		Functionalitymap = functionalitymap;
	}

	public int getUserroleID() {
		return userroleID;
	}

	public void setUserroleID(int userroleID) {
		this.userroleID = userroleID;
	}



	@Override
	public String toString() {
		return "FunctionalityMapDTO [userroleID=" + userroleID + ", Functionalitymap=" + Functionalitymap + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Functionalitymap == null) ? 0 : Functionalitymap.hashCode());
		result = prime * result + userroleID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FunctionalityMapDTO other = (FunctionalityMapDTO) obj;
		if (Functionalitymap == null) {
			if (other.Functionalitymap != null)
				return false;
		} else if (!Functionalitymap.equals(other.Functionalitymap))
			return false;
		if (userroleID != other.userroleID)
			return false;
		return true;
	}



	
	
	

	
	
}
