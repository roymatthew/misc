package com.ode.exchange.re.DTO;

import java.util.List;

public class FunctionalityMappingListDTO {
	
	private List<FunctionalityUserRoleMappingDTO> functionalityMappingList;

	public List<FunctionalityUserRoleMappingDTO> getFunctionalityMappingList() {
		return functionalityMappingList;
	}

	public void setFunctionalityMappingList(List<FunctionalityUserRoleMappingDTO> functionalityMappingList) {
		this.functionalityMappingList = functionalityMappingList;
	}
}
