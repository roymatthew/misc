package com.ode.exchange.re.DTO;

import java.sql.Timestamp;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({"functionalityMappingID", "createdDate" ,"createdBy", "updatedDate", "updatedBy" })
public class FunctionalityUserRoleMappingDTO {
	
	@JsonProperty("functionalityMappingID")
	private int id;
	
	@JsonProperty("functionalityID")
	private int functionalityid;
	
	@JsonProperty("functionalityName")
	private String functionalityName;
	
	@JsonProperty("userRoleID")	
	private int userroleID;
	
	@JsonProperty("createddate")	
	private Timestamp createdDate;	
	
	
	@JsonProperty("privilegeView")
	private boolean privilegeView;
	
	@JsonProperty("privilegeEdit")
	private boolean privilegeEdit;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public boolean isPrivilegeView() {
		return privilegeView;
	}

	public void setPrivilegeView(boolean privilegeView) {
		this.privilegeView = privilegeView;
	}

	public boolean isPrivilegeEdit() {
		return privilegeEdit;
	}

	public void setPrivilegeEdit(boolean privilegeEdit) {
		this.privilegeEdit = privilegeEdit;
	}

	public int getFunctionalityid() {
		return functionalityid;
	}

	public void setFunctionalityid(int functionalityid) {
		this.functionalityid = functionalityid;
	}

	public int getUserroleID() {
		return userroleID;
	}

	public void setUserroleID(int userroleID) {
		this.userroleID = userroleID;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}


	public String getFunctionalityName() {
		return functionalityName;
	}



	public void setFunctionalityName(String functionalityName) {
		this.functionalityName = functionalityName;
	}
	
	
	
	@Override
	public String toString() {
		return "FunctionalityUserRoleMappingDTO [id=" + id + ", functionalityid=" + functionalityid
				+ ", functionalityName=" + functionalityName + ", userroleID=" + userroleID + ", createdDate="
				+ createdDate + "]";
	}
	

	
	
}