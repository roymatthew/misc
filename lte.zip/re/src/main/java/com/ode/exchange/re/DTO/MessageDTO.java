package com.ode.exchange.re.DTO;

import java.sql.Timestamp;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "createdDate" })
public class MessageDTO {

	@JsonProperty("messageID")
	private int id;

	@JsonProperty("message")
	private String Message;

	@JsonProperty("messageName")
	private String messageName;

	@JsonProperty("remarks")
	private String remarks;

	@JsonProperty("status")
	private boolean status;

	@JsonProperty("createdDate")
	private Timestamp createdDate;

	@JsonProperty("createdBy")
	private int createdBy;
	
	@JsonProperty("messageType")
	private MessageTypeDTO messageType;
	
	@JsonProperty("reasonCode")
	private int reasonCode;

	@JsonProperty("ruleClassification")
	private RuleClassificationDTO ruleClassification;
	
	public int getId() {
		return id;
	}
	

	public void setId(int id) {
		this.id = id;
	}

	public MessageTypeDTO getMessageType() {
		return messageType;
	}

	public void setMessageType(MessageTypeDTO messageType) {
		this.messageType = messageType;
	}

	public RuleClassificationDTO getRuleClassification() {
		return ruleClassification;
	}

	public void setRuleClassification(RuleClassificationDTO ruleClassification) {
		this.ruleClassification = ruleClassification;
	}

	public int getReasonCode() {
		return reasonCode;
	}


	public void setReasonCode(int reasonCode) {
		this.reasonCode = reasonCode;
	}


	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public String getMessageName() {
		return messageName;
	}

	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	
	

}
