package com.ode.exchange.re.DTO;

import java.sql.Timestamp;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessAuditDTO {	

	@JsonProperty("xmlId")
	private long xmlId;
	
	@JsonProperty("etlStart")
	private Timestamp etlStart;
	
	@JsonProperty("etlEnd")
	private Timestamp etlEnd;
	
	@JsonProperty("rfValidationStart")
	private Timestamp rfValidationStart;
	
	@JsonProperty("rfValidationEnd")
	private Timestamp rfValidationEnd;
	
	@JsonProperty("rfValidationResult")
	private String rfValidationResult;
	
	@JsonProperty("fnValidationStart")
	private Timestamp fnValidationStart;
	
	@JsonProperty("fnValidationEnd")
	private Timestamp fnValidationEnd;	
	
	@JsonProperty("fnValidationResult")
	private String fnValidationResult;	
	
	@JsonProperty("tValidationStart")
	private Timestamp tValidationStart;
	
	@JsonProperty("tValidationEnd")
	private Timestamp tValidationEnd;
	
	@JsonProperty("tValidationResult")
	private String tValidationResult;
	
	@JsonProperty( "rValidationStart")
	private Timestamp rValidationStart;
	
	@JsonProperty("rValidationEnd")
	private Timestamp rValidationEnd;
	
	@JsonProperty("rValidationResult")
	private String rValidationResult;
	
	@JsonProperty("rflValidationStart")
	private Timestamp rflValidationStart;
	
	@JsonProperty("rflValidationEnd")
	private Timestamp rflValidationEnd;
	
	@JsonProperty("rflValidationResult")
	private String rflValidationResult;
	
	@JsonProperty( "finalValidationResult")
	private String finalValidationResult;
	
	@JsonProperty("outputXmlStart")
	private Timestamp outputXMLStart;
	
	@JsonProperty( "outputXmlEnd")
	private Timestamp outputXMLEnd;
	
	@JsonProperty("outputXmlResult")
	private String outputXMLResult;



	public long getXmlId() {
		return xmlId;
	}

	public void setXmlId(long xmlId) {
		this.xmlId = xmlId;
	}

	public Timestamp getEtlStart() {
		return etlStart;
	}

	public void setEtlStart(Timestamp etlStart) {
		this.etlStart = etlStart;
	}

	public Timestamp getEtlEnd() {
		return etlEnd;
	}

	public void setEtlEnd(Timestamp etlEnd) {
		this.etlEnd = etlEnd;
	}

	public Timestamp getRfValidationStart() {
		return rfValidationStart;
	}

	public void setRfValidationStart(Timestamp rfValidationStart) {
		this.rfValidationStart = rfValidationStart;
	}

	public Timestamp getRfValidationEnd() {
		return rfValidationEnd;
	}

	public void setRfValidationEnd(Timestamp rfValidationEnd) {
		this.rfValidationEnd = rfValidationEnd;
	}

	public String getRfValidationResult() {
		return rfValidationResult;
	}

	public void setRfValidationResult(String rfValidationResult) {
		this.rfValidationResult = rfValidationResult;
	}

	public Timestamp getFnValidationStart() {
		return fnValidationStart;
	}

	public void setFnValidationStart(Timestamp fnValidationStart) {
		this.fnValidationStart = fnValidationStart;
	}

	public Timestamp getFnValidationEnd() {
		return fnValidationEnd;
	}

	public void setFnValidationEnd(Timestamp fnValidationEnd) {
		this.fnValidationEnd = fnValidationEnd;
	}

	public String getFnValidationResult() {
		return fnValidationResult;
	}

	public void setFnValidationResult(String fnValidationResult) {
		this.fnValidationResult = fnValidationResult;
	}

	public Timestamp gettValidationStart() {
		return tValidationStart;
	}

	public void settValidationStart(Timestamp tValidationStart) {
		this.tValidationStart = tValidationStart;
	}

	public Timestamp gettValidationEnd() {
		return tValidationEnd;
	}

	public void settValidationEnd(Timestamp tValidationEnd) {
		this.tValidationEnd = tValidationEnd;
	}

	public String gettValidationResult() {
		return tValidationResult;
	}

	public void settValidationResult(String tValidationResult) {
		this.tValidationResult = tValidationResult;
	}

	public Timestamp getrValidationStart() {
		return rValidationStart;
	}

	public void setrValidationStart(Timestamp rValidationStart) {
		this.rValidationStart = rValidationStart;
	}

	public Timestamp getrValidationEnd() {
		return rValidationEnd;
	}

	public void setrValidationEnd(Timestamp rValidationEnd) {
		this.rValidationEnd = rValidationEnd;
	}

	public String getrValidationResult() {
		return rValidationResult;
	}

	public void setrValidationResult(String rValidationResult) {
		this.rValidationResult = rValidationResult;
	}

	public Timestamp getRflValidationStart() {
		return rflValidationStart;
	}

	public void setRflValidationStart(Timestamp rflValidationStart) {
		this.rflValidationStart = rflValidationStart;
	}

	public Timestamp getRflValidationEnd() {
		return rflValidationEnd;
	}

	public void setRflValidationEnd(Timestamp rflValidationEnd) {
		this.rflValidationEnd = rflValidationEnd;
	}

	public String getRflValidationResult() {
		return rflValidationResult;
	}

	public void setRflValidationResult(String rflValidationResult) {
		this.rflValidationResult = rflValidationResult;
	}

	public String getFinalValidationResult() {
		return finalValidationResult;
	}

	public void setFinalValidationResult(String finalValidationResult) {
		this.finalValidationResult = finalValidationResult;
	}

	public Timestamp getOutputXMLStart() {
		return outputXMLStart;
	}

	public void setOutputXMLStart(Timestamp outputXMLStart) {
		this.outputXMLStart = outputXMLStart;
	}

	public Timestamp getOutputXMLEnd() {
		return outputXMLEnd;
	}

	public void setOutputXMLEnd(Timestamp outputXMLEnd) {
		this.outputXMLEnd = outputXMLEnd;
	}

	public String getOutputXMLResult() {
		return outputXMLResult;
	}

	public void setOutputXMLResult(String outputXMLResult) {
		this.outputXMLResult = outputXMLResult;
	}

	@Override
	public String toString() {
		return "ProcessAuditDTO [ xmlId=" + xmlId + ", etlStart=" + etlStart + ", etlEnd=" + etlEnd
				+ ", rfValidationStart=" + rfValidationStart + ", rfValidationEnd=" + rfValidationEnd
				+ ", rfValidationResult=" + rfValidationResult + ", fnValidationStart=" + fnValidationStart
				+ ", fnValidationEnd=" + fnValidationEnd + ", fnValidationResult=" + fnValidationResult
				+ ", tValidationStart=" + tValidationStart + ", tValidationEnd=" + tValidationEnd
				+ ", tValidationResult=" + tValidationResult + ", rValidationStart=" + rValidationStart
				+ ", rValidationEnd=" + rValidationEnd + ", rValidationResult=" + rValidationResult
				+ ", rflValidationStart=" + rflValidationStart + ", rflValidationEnd=" + rflValidationEnd
				+ ", rflValidationResult=" + rflValidationResult + ", finalValidationResult=" + finalValidationResult
				+ ", outputXMLStart=" + outputXMLStart + ", outputXMLEnd=" + outputXMLEnd + ", outputXMLResult="
				+ outputXMLResult + "]";
	}
	

}
