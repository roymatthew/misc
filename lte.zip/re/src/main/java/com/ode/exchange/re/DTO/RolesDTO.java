package com.ode.exchange.re.DTO;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "createdDate" })
public class RolesDTO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("userRoleID")
	private int id;
	
	@JsonProperty("userRoleName")
	private String userRoleName;
	
	@JsonProperty("status")
	private boolean status;
	
	@JsonProperty("remarks")
	private String remarks;

	@JsonProperty("createdBy")
	private int createdBy;	
	
	@JsonProperty("createdDate")
	private Timestamp createdDate;

	 @JsonProperty("remarks")
	public String getRemarks() {
		return remarks;
	}
	 
	 @JsonProperty("remarks")
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	 @JsonProperty("createdBy")
	public int getCreatedBy() {
		return createdBy;
	}
	 
	 @JsonProperty("createdBy")
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("createdDate")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	@JsonProperty("createdDate")
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@JsonProperty("status")
	public boolean isStatus() {
		return status;
	}
	 
	@JsonProperty("status")
	public void setStatus(boolean status) {
		this.status = status;
	}

	@JsonProperty("userRoleID")
	public int getId() {
		return id;
	}

	@JsonProperty("userRoleID")
	public void setId(int id) {
		this.id = id;
	}
	
	@JsonProperty("userRoleName")
	public String getUserRoleName() {
		return userRoleName;
	}

	@JsonProperty("userRoleName")
	public void setUserRoleName(String userRoleName) {
		this.userRoleName = userRoleName;
	}

	@Override
	public String toString() {
		return "RolesDTO [id=" + id + ", userRoleName=" + userRoleName + ", status=" + status + ", remarks=" + remarks
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}


	
	
}
