package com.ode.exchange.re.DTO;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuleAuditDTO {

	@JsonProperty("ruleAuditid")
	private int id;

	@JsonProperty("xmlId")	
	private int xmlId;
	
	@JsonProperty("rcid")		
	private int rcid;
	
	@JsonProperty("lookupCriteria")	
	private String lookupCriteria;
	
	@JsonProperty("fixedFieldsCriteria")
	private String fixedFieldsCriteria;
	
	@JsonProperty("requiredFieldsCriteria")	
	private String requiredFieldsCriteria;
	
	@JsonProperty("rulelogic")	
	private String rulelogic;
	
	@JsonProperty("ruleExecutionResult")	
	private String ruleExecutionResult;
	
	@JsonProperty("messageResponse")
	private String messageResponse;	
	
	@JsonProperty("rule")
	private RuleDTO ruledto;
	
	@JsonProperty("createdDate")
	private Date createddate;
	
	

	public Date getCreateddate() {
		return createddate;
	}

	public void setCreateddate(Date createddate) {
		this.createddate = createddate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getXmlId() {
		return xmlId;
	}

	public void setXmlId(int xmlId) {
		this.xmlId = xmlId;
	}

	public int getRcid() {
		return rcid;
	}

	public void setRcid(int rcid) {
		this.rcid = rcid;
	}

	public String getLookupCriteria() {
		return lookupCriteria;
	}

	public void setLookupCriteria(String lookupCriteria) {
		this.lookupCriteria = lookupCriteria;
	}

	public String getFixedFieldsCriteria() {
		return fixedFieldsCriteria;
	}

	public void setFixedFieldsCriteria(String fixedFieldsCriteria) {
		this.fixedFieldsCriteria = fixedFieldsCriteria;
	}

	public String getRequiredFieldsCriteria() {
		return requiredFieldsCriteria;
	}

	public void setRequiredFieldsCriteria(String requiredFieldsCriteria) {
		this.requiredFieldsCriteria = requiredFieldsCriteria;
	}

	public String getRulelogic() {
		return rulelogic;
	}

	public void setRulelogic(String rulelogic) {
		this.rulelogic = rulelogic;
	}

	public String getRuleExecutionResult() {
		return ruleExecutionResult;
	}

	public void setRuleExecutionResult(String ruleExecutionResult) {
		this.ruleExecutionResult = ruleExecutionResult;
	}

	public String getMessageResponse() {
		return messageResponse;
	}

	public void setMessageResponse(String messageResponse) {
		this.messageResponse = messageResponse;
	}

	public RuleDTO getRuledto() {
		return ruledto;
	}

	public void setRuledto(RuleDTO ruledto) {
		this.ruledto = ruledto;
	}

	@Override
	public String toString() {
		return "RuleAuditDTO [id=" + id + ", xmlId=" + xmlId + ", rcid=" + rcid + ", lookupCriteria=" + lookupCriteria
				+ ", fixedFieldsCriteria=" + fixedFieldsCriteria + ", requiredFieldsCriteria=" + requiredFieldsCriteria
				+ ", rulelogic=" + rulelogic + ", ruleExecutionResult=" + ruleExecutionResult + ", messageResponse="
				+ messageResponse + ", ruledto=" + ruledto + "]";
	}
	
	
	
}
