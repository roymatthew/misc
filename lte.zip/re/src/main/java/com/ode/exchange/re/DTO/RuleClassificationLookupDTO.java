package com.ode.exchange.re.DTO;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuleClassificationLookupDTO {

	@JsonProperty("rcId")
	private int id;

	@JsonProperty("rcName")
	private String rcName;

	@JsonProperty("hierarchy")
	private int hierarchy;

	@JsonProperty("remarks")
	private String remarks;

	@JsonProperty("status")
	private boolean status;	

	@JsonProperty("createdBy")
	private int createdBy;

	@JsonProperty("createdDate")
	private Timestamp createdDate;
	
	@JsonProperty("updatedBy")
	private int updatedBy;

	@JsonProperty("updatedDate")
	private Timestamp updatedDate;	
	
	@JsonProperty("requiredFields")
	private boolean requiredFields;
	
	@JsonProperty("computeRule")
	private boolean computerule;
	
	@JsonProperty("fixedFieldValues")
	private boolean fixedFieldValues;
	
	@JsonProperty("lookupFields")	
	private List<FieldDropDownNameDTO> fieldDropDownNameDTO;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRcName() {
		return rcName;
	}

	public void setRcName(String rcName) {
		this.rcName = rcName;
	}

	public int getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(int hierarchy) {
		this.hierarchy = hierarchy;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public boolean isRequiredFields() {
		return requiredFields;
	}

	public void setRequiredFields(boolean requiredFields) {
		this.requiredFields = requiredFields;
	}

	public boolean isComputerule() {
		return computerule;
	}

	public void setComputerule(boolean computerule) {
		this.computerule = computerule;
	}

	public boolean isFixedFieldValues() {
		return fixedFieldValues;
	}

	public void setFixedFieldValues(boolean fixedFieldValues) {
		this.fixedFieldValues = fixedFieldValues;
	}

	public List<FieldDropDownNameDTO> getFieldDropDownNameDTO() {
		return fieldDropDownNameDTO;
	}

	public void setFieldDropDownNameDTO(List<FieldDropDownNameDTO> fieldDropDownNameDTO) {
		this.fieldDropDownNameDTO = fieldDropDownNameDTO;
	}

	@Override
	public String toString() {
		return "RuleClassificationLookupDTO [id=" + id + ", rcName=" + rcName + ", hierarchy=" + hierarchy
				+ ", remarks=" + remarks + ", status=" + status + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", requiredFields="
				+ requiredFields + ", computerule=" + computerule + ", fixedFieldValues=" + fixedFieldValues
				+ ", fieldDropDownNameDTO=" + fieldDropDownNameDTO + "]";
	}
	
	
}
