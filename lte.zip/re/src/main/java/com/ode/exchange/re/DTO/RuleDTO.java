package com.ode.exchange.re.DTO;

import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


//@JsonInclude(JsonInclude.Include.NON_NULL)

public class RuleDTO {
	
@JsonProperty("ruleID")	
private int id;
	
@JsonProperty("ruleClassification")	
private RuleClassificationDTO ruleClassificationDTO;


@JsonProperty("ruleType")	
private RuleTypeDTO ruleTypeDTO;

@JsonProperty("ruleSubtype")	
private RuleSubtypeDTO ruleSubtypeDTO;

@JsonProperty("passMessage")	
private PassFailMessageDTO passmessageDTO;

@JsonProperty("failMessage")
private PassFailMessageDTO failmessageDTO;

@JsonProperty("ruleName")
private String ruleName;

@JsonProperty("lookupCriteria")
private String lookupCriteria;

/*@JsonProperty("requiredFields")
private String requiredFields;

@JsonProperty("fixedFieldValues")
private String fixedFieldValues;*/

@JsonProperty("ruleLogic")
private String ruleLogic;

@JsonProperty("passRuleValue")
private String passRuleValue;

@JsonProperty("failRuleValue")
private String failRuleValue;

@JsonProperty("effectiveDate")
private Timestamp effectiveDate;

@JsonProperty("expirationDate")
private Timestamp expirationDate;


@JsonProperty("remarks")
private String remarks;

@JsonProperty("status")
private char status;

@JsonProperty("createdDate")
private Date createdDate;

@JsonProperty("createdBy")
private int createdBy;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public RuleClassificationDTO getRuleClassificationDTO() {
	return ruleClassificationDTO;
}

public void setRuleClassificationDTO(RuleClassificationDTO ruleClassificationDTO) {
	this.ruleClassificationDTO = ruleClassificationDTO;
}

public RuleTypeDTO getRuleTypeDTO() {
	return ruleTypeDTO;
}

public void setRuleTypeDTO(RuleTypeDTO ruleTypeDTO) {
	this.ruleTypeDTO = ruleTypeDTO;
}

public RuleSubtypeDTO getRuleSubtypeDTO() {
	return ruleSubtypeDTO;
}

public void setRuleSubtypeDTO(RuleSubtypeDTO ruleSubtypeDTO) {
	this.ruleSubtypeDTO = ruleSubtypeDTO;
}

public PassFailMessageDTO getPassmessageDTO() {
	return passmessageDTO;
}

public void setPassmessageDTO(PassFailMessageDTO passmessageDTO) {
	this.passmessageDTO = passmessageDTO;
}

public PassFailMessageDTO getFailmessageDTO() {
	return failmessageDTO;
}

public void setFailmessageDTO(PassFailMessageDTO failmessageDTO) {
	this.failmessageDTO = failmessageDTO;
}

public String getRuleName() {
	return ruleName;
}

public void setRuleName(String ruleName) {
	this.ruleName = ruleName;
}

public String getLookupCriteria() {
	return lookupCriteria;
}

public void setLookupCriteria(String lookupCriteria) {
	this.lookupCriteria = lookupCriteria;
}

/*public String getRequiredFields() {
	return requiredFields;
}

public void setRequiredFields(String requiredFields) {
	this.requiredFields = requiredFields;
}

public String getFixedFieldValues() {
	return fixedFieldValues;
}

public void setFixedFieldValues(String fixedFieldValues) {
	this.fixedFieldValues = fixedFieldValues;
}*/

public String getRuleLogic() {
	return ruleLogic;
}

public void setRuleLogic(String ruleLogic) {
	this.ruleLogic = ruleLogic;
}

public Timestamp getEffectiveDate() {
	return effectiveDate;
}

public void setEffectiveDate(Timestamp effectiveDate) {
	this.effectiveDate = effectiveDate;
}

public Timestamp getExpirationDate() {
	return expirationDate;
}

public void setExpirationDate(Timestamp expirationDate) {
	this.expirationDate = expirationDate;
}

public String getRemarks() {
	return remarks;
}

public void setRemarks(String remarks) {
	this.remarks = remarks;
}

public char getStatus() {
	return status;
}

public void setStatus(char status) {
	this.status = status;
}

public Date getCreatedDate() {
	return createdDate;
}

public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}

public int getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(int createdBy) {
	this.createdBy = createdBy;
}

public String getPassRuleValue() {
	return passRuleValue;
}

public void setPassRuleValue(String passRuleValue) {
	this.passRuleValue = passRuleValue;
}

public String getFailRuleValue() {
	return failRuleValue;
}

public void setFailRuleValue(String failRuleValue) {
	this.failRuleValue = failRuleValue;
}

@Override
public String toString() {
	return "RuleDTO [id=" + id + ", ruleClassificationDTO=" + ruleClassificationDTO + ", ruleTypeDTO=" + ruleTypeDTO
			+ ", ruleSubtypeDTO=" + ruleSubtypeDTO + ", passmessageDTO=" + passmessageDTO + ", failmessageDTO="
			+ failmessageDTO + ", ruleName=" + ruleName + ", lookupCriteria=" + lookupCriteria + ", ruleLogic="
			+ ruleLogic + ", passRuleValue=" + passRuleValue + ", failRuleValue=" + failRuleValue + ", effectiveDate="
			+ effectiveDate + ", expirationDate=" + expirationDate + ", remarks=" + remarks + ", status=" + status
			+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
}





 


}
