package com.ode.exchange.re.DTO;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "createdDate" })
public class RuleSubtypeDTO {
	
	@JsonProperty("ruleSubTypeID")	
	private int id;
	
	@JsonProperty("ruleSubType")
	private String ruleSubtype;		
	
	@JsonProperty("remarks")
	private String remarks;
	
	@JsonProperty("status")
	private boolean status;
	
	
	@JsonProperty("createdBy")
	private int createdBy;

	@JsonProperty("ruleType")
	private RuleTypeDTO ruleType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRuleSubtype() {
		return ruleSubtype;
	}

	public void setRuleSubtype(String ruleSubtype) {
		this.ruleSubtype = ruleSubtype;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("ruleType")
	public RuleTypeDTO getRuleType() {
		return ruleType;
	}
	
	@JsonProperty("ruleType")
	public void setRuleType(RuleTypeDTO ruleType) {
		this.ruleType = ruleType;
	}

	@Override
	public String toString() {
		return "RuleSubtypeDTO [id=" + id + ", ruleSubtype=" + ruleSubtype + ", remarks=" + remarks + ", status="
				+ status + ", createdBy=" + createdBy + ", ruleType=" + ruleType + "]";
	}

	
}
