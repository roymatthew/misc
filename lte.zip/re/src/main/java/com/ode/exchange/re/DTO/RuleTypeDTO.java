package com.ode.exchange.re.DTO;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "createdDate" })
public class RuleTypeDTO {	
	
	@JsonProperty("ruleTypeID")	
	private int id;
	
	@JsonProperty("ruleTypeName")
	private	String ruleTypeName;
	
	@JsonProperty("remarks")
	private String remarks;
	
	@JsonProperty("status")
	private boolean status;
	
	@JsonProperty("createdDate")
	private Timestamp createdDate;
	
	@JsonProperty("createdBy")
	private int createdBy;

	
	@JsonProperty("ruleTypeID")	
	public int getId() {
		return id;
	}

	@JsonProperty("ruleTypeID")	
	public void setId(int id) {
		this.id = id;
	}


	@JsonProperty("ruleTypeName")
	public String getRuleTypeName() {
		return ruleTypeName;
	}

	@JsonProperty("ruleTypeName")
	public void setRuleTypeName(String ruleTypeName) {
		this.ruleTypeName = ruleTypeName;
	}

	@JsonProperty("remarks")
	public String getRemarks() {
		return remarks;
	}

	@JsonProperty("remarks")
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@JsonProperty("status")
	public boolean isStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(boolean status) {
		this.status = status;
	}

	@JsonProperty("createdDate")
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	@JsonProperty("createdDate")
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@JsonProperty("createdBy")
	public int getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("createdBy")
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "RuleTypeDTO [id=" + id + ", ruleType=" + ruleTypeName + ", remarks=" + remarks + ", status=" + status
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
	}
	
	


}
