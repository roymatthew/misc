package com.ode.exchange.re.DTO;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDTO {

	public UserDTO() {
		super();
	}

	@JsonProperty("userID")	
	private int id;
	
	@JsonProperty("firstName")
	private String firstName;
	
	@JsonProperty("middleName")
	private String middleName;
	
	@JsonProperty("lastName")
	private String lastName;
	
	@JsonProperty("email")
	private String emailAddress;
	
	@JsonProperty("userName")
	private String username;
	
	@JsonProperty("status")
	private boolean active;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("userRoleID")
	private int userRoleID;
	
	
	
	@JsonProperty("createdBy")
	private int createdBy;	
	
	@JsonProperty("createdDate")
	private Timestamp createdDate;
	
	@JsonProperty("userRole")
	private RolesDTO role = new RolesDTO();
	
	
	@JsonProperty("password")
	public String getPassword() {
		return password;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	@JsonProperty("password")
	public void setPassword(String password) {
		this.password = password;
	}


	@JsonProperty("userID")
	public int getId() {
		return id;
	}

	@JsonProperty("userID")
	public void setId(int id) {
		this.id = id;
	}

	@JsonProperty("firstName")
	public String getFirstName() {
		return firstName;
	}

	@JsonProperty("firstName")
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@JsonProperty("lastName")
	public String getLastName() {
		return lastName;
	}

	@JsonProperty("lastName")
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	@JsonProperty("email")
	public String getEmailAddress() {
		return emailAddress;
	}
	
	@JsonProperty("email")
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@JsonProperty("userName")
	public String getUserName() {
		return username;
	}

	@JsonProperty("userName")
	public void setUserName(String username) {
		this.username = username;
	}

	@JsonProperty("status")
	public boolean getEnabled() {
		return active;
	}

	@JsonProperty("userRoleID")
	public int getUserRoleID() {
		return userRoleID;
	}

	@JsonProperty("userRoleID")
	public void setUserRoleID(int userRoleID) {
		this.userRoleID = userRoleID;
	}

	@JsonProperty("status")
	public void setEnabled(boolean enabled) {
		this.active = enabled;
	}

	@JsonProperty("userRole")
	public RolesDTO getRole() {
		return role;
	}

	@JsonProperty("userRole")
	public void setRole(RolesDTO role) {
		this.role = role;
	}
	
	

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", emailAddress=" + emailAddress + ", username=" + username + ", active=" + active + ", password="
				+ password + ", userRoleID=" + userRoleID + ",  role=" + role + "]";
	}

	
	
}
