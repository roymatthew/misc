package com.ode.exchange.re.DTO;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class XMLFieldsDTO {

	@JsonProperty("id")
	private int id;

	@JsonProperty("xmlId")
	public long xmlId;

	@JsonProperty("fieldName")
	private String fieldName;

	@JsonProperty("fieldValue")
	private String fieldValue;

	@JsonProperty("fieldType")
	private String fieldType;

	@JsonProperty("lookupUsage")
	public boolean lookupUsage;
	
	@JsonProperty("groupLevel")
	public int groupLevel;

	public int isGroupLevel() {
		return groupLevel;
	}

	public void setGroupLevel(int groupLevel) {
		this.groupLevel = groupLevel;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public long getXmlId() {
		return xmlId;
	}

	public void setXmlId(int xmlId) {
		this.xmlId = xmlId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "XMLFieldsDTO [xmlId=" + xmlId + ", fieldName=" + fieldName + ", fieldValue=" + fieldValue
				+ ", fieldType=" + fieldType + ", lookupUsage=" + lookupUsage + "]";
	}

}
