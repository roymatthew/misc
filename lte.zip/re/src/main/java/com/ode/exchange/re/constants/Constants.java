package com.ode.exchange.re.constants;

public class Constants {

    public static final long ACCESS_TOKEN_VALIDITY_SECONDS = 2*60*60 ;
    public static final String SIGNING_KEY = "Secret"; 
    public static final String HEADER_STRING = "token";
    public static final String AUTHORITIES_KEY = "scopes";
}
