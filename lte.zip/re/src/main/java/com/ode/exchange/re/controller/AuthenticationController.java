package com.ode.exchange.re.controller;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.AuthDTO;
import com.ode.exchange.re.DTO.FunctionalityDTO;
import com.ode.exchange.re.DTO.FunctionalityUserRoleMappingDTO;
import com.ode.exchange.re.DTO.LoginDto;
import com.ode.exchange.re.DTO.RolesDTO;
import com.ode.exchange.re.DTO.UserDTO;
import com.ode.exchange.re.config.TokenProvider;
import com.ode.exchange.re.entity.FunctionalityUserRoleMapping;

import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.entity.AppUser;
import com.ode.exchange.re.serviceimpl.FunctionalityMappingServiceImpl;
import com.ode.exchange.re.serviceimpl.UserServiceImpl;

/**
 * This Controller Class for AuthenticationController. Handles requests related
 * to the REST resource "login" Username and Password Authentication, returns
 * JWT token in response header on success
 * 
 * @author
 * 
 */

@CrossOrigin(origins = "*", exposedHeaders = "token")
@RestController
public class AuthenticationController {
	public static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private TokenProvider jwtTokenUtil;

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private FunctionalityMappingServiceImpl functionalityService;

	@Autowired
	private ModelMapper modelMapper;

	@Value("${ode.secret.encoding.key}")
	private String secret;

	/**
	 * Authenticates the User
	 *
	 * @param Login Details - UserName and Password.
	 * @return JWT token in response header on success & User and UserRole and
	 *         Functionality Details for the UserName and Password
	 */

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public AuthDTO login(@RequestBody LoginDto loginDto, HttpServletResponse response) {
		List<FunctionalityUserRoleMappingDTO> functionalityusermapdtoList = new ArrayList<>();
		AuthDTO authdto = new AuthDTO();
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] decodedByteArray = decoder.decode(loginDto.getPassword());
		String decodedString = new String(decodedByteArray);

		final Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getUserName(),decodedString.replaceFirst(secret, "")));

		AppUser appUser = userService.findByUser(authentication.getName());
		AppUser userDTOUsername = userService.findByUser(loginDto.getUserName());
		if (appUser == null || userDTOUsername == null) {
			throw new UsernameNotFoundException("User not found");
		}
		if (!appUser.isActive()) {
			throw new BadRequestException("Inactive user");
		}
		if (appUser.getUserRoles() != null) {
			List<FunctionalityUserRoleMapping> functionalityUserRoleMapperList = functionalityService
					.getFunctionalityAll(appUser.getUserRoles().getId());

			functionalityUserRoleMapperList.forEach(functionalityMap -> {
				FunctionalityDTO functionalityDTO = modelMapper.map(functionalityMap.getFunctionality(),
						FunctionalityDTO.class);
				FunctionalityUserRoleMappingDTO fUMDTO = modelMapper.map(functionalityMap,
						FunctionalityUserRoleMappingDTO.class);
				fUMDTO.setFunctionalityid(functionalityDTO.getId());
				fUMDTO.setFunctionalityName((functionalityDTO.getFunctionalityName()));
				functionalityusermapdtoList.add(fUMDTO);
			});
		}

		SecurityContextHolder.getContext().setAuthentication(authentication);
		final String token = jwtTokenUtil.generateToken(authentication);
		response.setHeader("token", token);
		RolesDTO rolesDTO = modelMapper.map(appUser.getUserRoles(), RolesDTO.class);
		UserDTO userDTO = modelMapper.map(appUser, UserDTO.class);
		userDTO.setRole(rolesDTO);
		authdto.setUserDTO(userDTO);
		authdto.setFunctionalitymapperDTO(functionalityusermapdtoList);
		logger.info("Logged in User Details {}", authdto);
		return authdto;
	}

}