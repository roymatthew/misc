package com.ode.exchange.re.controller;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.CalculationDTO;
import com.ode.exchange.re.DTO.RuleClassificationDTO;
import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.DuplicateRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.CalculationServiceImpl;

@CrossOrigin
@RestController
public class CalculationController {
	
	public static final Logger logger = LoggerFactory.getLogger(CalculationController.class);
	
	
	@Autowired
	private  CalculationServiceImpl calculationService;


	@Autowired
	private ModelMapper modelMapper;
	
	@GetMapping("/calculations")
	public ResponseEntity<List<CalculationDTO>> getCalculationAll() {		
		List<Calculation> calculationList = calculationService.getCalculationAll();
		java.lang.reflect.Type targetListType = new TypeToken<List<CalculationDTO>>() {
		}.getType();
		
		List<CalculationDTO> calculationDTOList = modelMapper.map(calculationList, targetListType);
		if (calculationList == null) {
			throw new NotFoundException("No Calculations found");
		}
		return new ResponseEntity<List<CalculationDTO>>(calculationDTOList, HttpStatus.OK);
	}
	
	@GetMapping("/calculations/{id}")
	public ResponseEntity<?> getCalculationsById(@PathVariable("id") int calculationID) {
		Calculation calculation = new Calculation();
		try {
			calculation = calculationService.findCalculationById(calculationID);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<CalculationDTO>(modelMapper.map(calculation, CalculationDTO.class),
				HttpStatus.OK);

	}
	
	
	@PostMapping("/calculations")
	public ResponseEntity<?> createCalculation(@RequestBody @NotNull Calculation calculation) {
		try {
		String calcName = calculation.getCalculationName();
		List<Calculation> allcalcs = calculationService.getCalculationAll();
		if (allcalcs.stream().filter(calc -> calc.getCalculationName().equals(calcName)).findAny()
				.orElse(null) != null) {
			throw new DuplicateRequestException("Duplicate Calculation Name Exists");
		} else {
			calculation = calculationService.createCalculation(calculation);
		}		
		}catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		if (calculation == null) {
			throw new BadRequestException("failed to save  Calculation");
		}
		return new ResponseEntity<CalculationDTO>(modelMapper.map(calculation, CalculationDTO.class),
				HttpStatus.CREATED);

	}

	
	
	
	@PutMapping("/calculations/{id}")
	public ResponseEntity<?> updateRuleclassification(@PathVariable("id") int calculationID,
			@RequestBody  Calculation calculation) {

		try {
			calculation = calculationService.updateById(calculationID, calculation);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<CalculationDTO>(modelMapper.map(calculation, CalculationDTO.class), HttpStatus.OK);
	}
}
