package com.ode.exchange.re.controller;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.CalculationDTO;
import com.ode.exchange.re.DTO.CreditDecisionDTO;
import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.entity.CreditDecision;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.CalculationServiceImpl;
import com.ode.exchange.re.serviceimpl.CreditDecisionServiceImpl;

@CrossOrigin
@RestController
public class CreditDecisionController {
public static final Logger logger = LoggerFactory.getLogger(CreditDecisionController.class);
	
	
	@Autowired
	private  CreditDecisionServiceImpl creditDecisionService;


	@Autowired
	private ModelMapper modelMapper;
	
	@GetMapping("/creditdecision")
	public ResponseEntity<List<CreditDecisionDTO>> getCreditDecisionAll() {		
	//	List<CreditDecision> creditDecisionList = creditDecisionService.getCreditDecisionAll();	
		
		List<CreditDecisionDTO> creditNamesList = new ArrayList();
		
		 List<String> Columns = new ArrayList<String>();
		 Field[] fields = CreditDecision.class.getDeclaredFields();
		 
		 for (Field field : fields) {
	            Column col = field.getAnnotation(Column.class);
	            if (col != null) {
	                Columns.add(col.name());	               
	            }
	         }
		 
		java.lang.reflect.Type targetListType = new TypeToken<List<CreditDecisionDTO>>() {
		}.getType();
		List<CreditDecisionDTO> creditDecisionDTOList = modelMapper.map(Columns, targetListType);
		creditNamesList.add(creditDecisionDTOList.get(0));
				
		
/*
		if (creditDecisionList == null) {
			throw new NotFoundException("No Credit Decision found");
		}*/
		return new ResponseEntity<List<CreditDecisionDTO>>(creditNamesList, HttpStatus.OK);		
		
	}
	

}
