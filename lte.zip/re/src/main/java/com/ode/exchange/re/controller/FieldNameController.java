package com.ode.exchange.re.controller;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.FieldDTO;
import com.ode.exchange.re.DTO.FieldNameDTO;
import com.ode.exchange.re.entity.ETLConfiguration;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.FieldNameServiceImpl;

/**
 * This Controller Class for FieldNameController. Handles requests related to
 * the REST resource "dropdowns" and "fieldnames"
 * 
 * @author
 * 
 */
@CrossOrigin
@RestController
public class FieldNameController {
	public static final Logger logger = LoggerFactory.getLogger(FieldNameController.class);

	@Autowired
	private FieldNameServiceImpl fieldNameService;

	/**
	 * Get All Dropdowns
	 * 
	 * @return Get All Dropdowns along with FieldNames
	 */

	@GetMapping("/dropdowns")
	public ResponseEntity<List<FieldNameDTO>> getFieldDropDownAll() {
		List<FieldNameDTO> fieldNameDTOlist = fieldNameService.getFieldNameDropDownAll();
		if (fieldNameDTOlist == null) {
			throw new NotFoundException("No fieldNames found");
		}
		return new ResponseEntity<List<FieldNameDTO>>(fieldNameDTOlist, HttpStatus.OK);
	}

	/**
	 * Get Dropdown By id
	 *
	 * @param fieldDropDownID - field id
	 * @return Dropdowns associated with a FieldName
	 */

	@GetMapping("/dropdowns/{id}")
	public ResponseEntity<?> getFieldDropDownById(@PathVariable("id") int fieldDropDownID) {
		FieldNameDTO fieldDropdownDTOObj = new FieldNameDTO();
		try {
			fieldDropdownDTOObj = fieldNameService.findFieldDropDownById(fieldDropDownID);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<FieldNameDTO>(fieldDropdownDTOObj, HttpStatus.OK);

	}

	/**
	 * Create Dropdown.
	 * 
	 * If dropdown is successfully created, success message is displayed else error message is
	 * displayed accordingly. If there are any existing dropdowns with the fieldName
	 * as passed fieldName to the API, existing dropdowns will be removed from the
	 * dropdown table and newly entered dropdowns are saved in DropDown Table.
	 * 
	 * @param fieldnameDTO - Dropdown to be created
	 * @return "Dropdown created" on successful dropdown creation
	 */

	@PostMapping("/dropdowns")
	public ResponseEntity<?> createFieldDropDown(@RequestBody @NotNull FieldNameDTO fieldnameDTO) {
		try {
		 fieldNameService.createFieldDropDown(fieldnameDTO);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.OK).body("Dropdown created.");

	}

	/**
	 * Get All FieldNames
	 * 
	 * @return all FieldNames
	 */

	@GetMapping("/fieldnames")
	public ResponseEntity<List<FieldDTO>> getFieldAll() {
		List<FieldDTO> fieldDTOlist = fieldNameService.getFieldAll();
		if (fieldDTOlist == null) {
			throw new NotFoundException("No fieldNames found");
		}
		return new ResponseEntity<List<FieldDTO>>(fieldDTOlist, HttpStatus.OK);
	}

	/**
	 * Get FieldName By Id
	 *
	 * @param fieldID - field id
	 * @return FieldName associated with a FieldName
	 */

	@GetMapping("/fieldnames/{id}")
	public ResponseEntity<?> getFieldById(@PathVariable("id") int fieldID) {
		FieldDTO fieldDTOObj = new FieldDTO();
		try {
			fieldDTOObj = fieldNameService.getFieldById(fieldID);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		return new ResponseEntity<FieldDTO>(fieldDTOObj, HttpStatus.OK);
	}

}
