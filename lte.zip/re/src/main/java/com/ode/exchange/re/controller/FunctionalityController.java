package com.ode.exchange.re.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ode.exchange.re.DTO.FunctionalityUserRoleMappingDTO;
import com.ode.exchange.re.entity.Functionality;
import com.ode.exchange.re.entity.FunctionalityUserRoleMapping;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.FunctionalityMappingServiceImpl;
import com.ode.exchange.re.serviceimpl.FunctionalityServiceImpl;

/**
 * This Controller Class for FunctionalityController.  Handles requests related to the REST resource "functionalities" and "functionalitiesmap" 
 * @author 
 * 
 */

@CrossOrigin
@RestController
public class FunctionalityController {

	public static final Logger logger = LoggerFactory.getLogger(FunctionalityController.class);
	
	@Autowired
	private FunctionalityServiceImpl functionalityService;
	
	@Autowired
	private FunctionalityMappingServiceImpl functionalityMappingService;
	
	/**Get All Functionalities
	 * @return Get All Functionalities
	 */	

	@GetMapping("/functionalities")
	public ResponseEntity<List<Functionality>> getFunctionalityAll() {
		List<Functionality> functionalityList = functionalityService.getFunctionalityAll();
		if (functionalityList == null) {
			throw new NotFoundException("No functionalities found");
		}

		return new ResponseEntity<List<Functionality>>(functionalityList, HttpStatus.OK);
	}

	/**
	 * Get Functionality By id
	 *
	 * @param functionalityID - functionality id 
	 * @return Functionality associated with a functionalityID
	 */

	
	@GetMapping("/functionalities/{id}")
	public ResponseEntity<Functionality> getFunctionalityById(@PathVariable("id") int functionalityID) {
		Functionality functionality = functionalityService.getFunctionality(functionalityID);
		if (functionality == null) {
			throw new NotFoundException("No functionality found");
		}

		return new ResponseEntity<Functionality>(functionality, HttpStatus.OK);
	}
	
	
	/**Get All Functionalities along with their associated UserRoles
	 * @return list of Functionalities along with their associated UserRole
	 */	
	
	
	@GetMapping("/functionalitiesmap")
	public ResponseEntity<List<FunctionalityUserRoleMappingDTO>> getFunctionalityMappingAll() {
		List<FunctionalityUserRoleMappingDTO> functionalityList = functionalityMappingService.getFunctionalityMappingAll();
		if (functionalityList == null) {
			throw new NotFoundException("No functionality Map found");
		}

		return new ResponseEntity<List<FunctionalityUserRoleMappingDTO>>(functionalityList, HttpStatus.OK);
	}
	
	
	/**
	 * Create Functionality Map.
	 * 
	 * This API also saves the entered data to FunctionalityUserRoleMapping History table. If Functionality
	 * is successfully created, success message is displayed else error message is
	 * displayed accordingly. If there are any existing Functionalities with the UserRole
	 * existing Functionalities will be removed from the
	 * FunctionalityUserRoleMapping table and newly entered Functionalities are saved in FunctionalityUserRoleMapping Table.
	 * 
	 * @param fumDTOList - List of FunctionalityUserRoleMapping .
	 * @return "FunctionalityMapping created" on successful FunctionalityMapping creation
	 */
	
	@PostMapping("/functionalitiesmap")
	public ResponseEntity<List<FunctionalityUserRoleMappingDTO>> createFunctionalityMapping(@RequestBody List<FunctionalityUserRoleMappingDTO> fumDTOList) {
		List<FunctionalityUserRoleMapping>  fUMIterableList = new ArrayList();
		List<FunctionalityUserRoleMappingDTO> functionalityList = new ArrayList();
		try {
			fUMIterableList = functionalityMappingService.createFunctionalityMapping(fumDTOList);
			if (fUMIterableList == null) {
				throw new NotFoundException("No functionality Map Created");
			}
			 
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		if(!fUMIterableList.isEmpty())
		{ functionalityList = functionalityMappingService.getFunctionalityMappingAll();
			if (functionalityList == null) {
				throw new NotFoundException("No functionality Map found");
			}
		}
		return new ResponseEntity<List<FunctionalityUserRoleMappingDTO>>(functionalityList, HttpStatus.OK);
	}
	
}