package com.ode.exchange.re.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.ode.exchange.re.DTO.MessageDTO;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.MessageServiceImpl;

/**
 * This Controller Class for MessageController. Handles requests related to the
 * REST resource "messages"
 * 
 * @author
 * 
 */
@CrossOrigin
@RestController
public class MessageController {

	public static final Logger logger = LoggerFactory.getLogger(MessageController.class);

	@Autowired
	private MessageServiceImpl messageService;

	/**
	 * Get All Messages
	 * 
	 * @return lists all Messages
	 */

	@GetMapping("/messages")
	public ResponseEntity<List<MessageDTO>> getMessagesAll() {
		List<MessageDTO> messageList = messageService.getMessagesAll();
		if (messageList == null) {
			throw new NotFoundException("No Messages found");
		}
		return new ResponseEntity<List<MessageDTO>>(messageList, HttpStatus.OK);
	}

	/**
	 * Get Message By id
	 *
	 * @param messageId - message id
	 * @return message associated with the messageId
	 */

	@GetMapping("/messages/{id}")
	public ResponseEntity<?> getMessagesById(@PathVariable("id") int messageId) {
		MessageDTO messageDTO = new MessageDTO();
		try {
			messageDTO = messageService.findMessageById(messageId);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		return new ResponseEntity<MessageDTO>(messageDTO, HttpStatus.OK);

	}

	/**
	 * Get Message By Rule Classification id
	 *
	 * @param ruleClassificationId - Rule Classification id
	 * @return message associated with the ruleClassificationId
	 */

	@GetMapping("/messages/ruleclassifications/{id}")
	public ResponseEntity<?> getMessagesByRuleClassificationId(@PathVariable("id") int ruleClassificationId) {
		List<MessageDTO> messageList = new ArrayList<>();
		try {
			messageList = messageService.findMessagesByRuleClassificationId(ruleClassificationId);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		return new ResponseEntity<List<MessageDTO>>(messageList, HttpStatus.OK);

	}
	
	/**
	 * Get Default Messages By Rule Classification id
	 *
	 * @param ruleClassificationId - Rule Classification id
	 * @return message associated with the ruleClassificationId
	 */
	
	@GetMapping("/defaultmessages/ruleclassifications/{id}")
	public ResponseEntity<?> getDefaultMessagesByRuleClassificationId(@PathVariable("id") int ruleClassificationId) {
		List<MessageDTO> messageList = new ArrayList<>();
		try {
			messageList = messageService.findDefaultMessagesByRuleClassificationId(ruleClassificationId);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		return new ResponseEntity<List<MessageDTO>>(messageList, HttpStatus.OK);

	}

	/**
	 * Create Message
	 * 
	 * 
	 * @param messageDTO - Message to be created
	 * @return messageDTO - created Message
	 */

	@PostMapping("/messages")
	public ResponseEntity<?> createMessage(@RequestBody @NotNull MessageDTO messageDTO) {
		try {
			messageDTO = messageService.createMessages(messageDTO);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<MessageDTO>(messageDTO, HttpStatus.OK);
	}

	/**
	 * Update Message by id
	 * 
	 * 
	 * @param messageDTO - Message to be updated
	 * @param messageId  - message id
	 * @return messageDTO - Message updated
	 */

	@PutMapping("/messages/{id}")
	public @ResponseBody ResponseEntity<?> UpdateMessage(@PathVariable("id") int messageId,
			@RequestBody @NotNull MessageDTO messageDTO) {

		MessageDTO message = new MessageDTO();
		try {
			message = messageService.updateById(messageId, messageDTO);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<MessageDTO>(message, HttpStatus.OK);

	}
	
	
	

}
