package com.ode.exchange.re.controller;

import java.util.List;
import javax.validation.constraints.NotNull;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ode.exchange.re.DTO.RuleClassificationDTO;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.RuleClassificationServiceImpl;

/**
 * This Controller Class for RuleClassificationController. Handles requests related to
 * the REST resource "ruleclassifications"
 * 
 * @author
 * 
 */

@CrossOrigin(origins = "*")
@RestController
public class RuleClassificationController {
	public static final Logger logger = LoggerFactory.getLogger(RuleClassificationController.class);
	@Autowired
	private RuleClassificationServiceImpl ruleClassificationService;


	@Autowired
	private ModelMapper modelMapper;

	/**
	 * Get All RuleClassifications
	 * 
	 * @return lists all RuleClassifications
	 */

	@GetMapping("/ruleclassifications")
	public ResponseEntity<List<RuleClassificationDTO>> getRuleClassificationAll() {
		List<RuleClassification> ruleClassificationList = ruleClassificationService.getRuleClassificationAll();
		java.lang.reflect.Type targetListType = new TypeToken<List<RuleClassificationDTO>>() {
		}.getType();
		List<RuleClassificationDTO> ruleClassificationDTOList = modelMapper.map(ruleClassificationList, targetListType);
		if (ruleClassificationList == null) {
			throw new NotFoundException("No RuleClassification found");
		}
		return new ResponseEntity<List<RuleClassificationDTO>>(ruleClassificationDTOList, HttpStatus.OK);
	}

	 
	/**
	 * Get RuleClassification By Id
	 *
	 * @param rcID - RuleClassification id
	 * @return RuleClassification associated with the rcID
	 */

	@GetMapping("/ruleclassifications/{id}")
	public ResponseEntity<?> getRuleClassificationById(@PathVariable("id") int rcID) {
		RuleClassification rc = new RuleClassification();
		try {
			rc = ruleClassificationService.findRuleClassificationById(rcID);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<RuleClassificationDTO>(modelMapper.map(rc, RuleClassificationDTO.class),
				HttpStatus.OK);

	}

	
	

	/**
	 * // Create RuleClassification 
	 * 
	 * @param rc  - RuleClassification to be created	 
	 * @return RuleClassificationDTO - created RuleClassification
	 */

	@PostMapping("/ruleclassifications")
	public ResponseEntity<?> createRuleclassification(@RequestBody @NotNull RuleClassification rc) {
		rc = ruleClassificationService.createRuleclassification(rc);
		if (rc == null) {
			throw new BadRequestException("failed to save  Ruleclassification");
		}
		return new ResponseEntity<RuleClassificationDTO>(modelMapper.map(rc, RuleClassificationDTO.class),
				HttpStatus.CREATED);

	}

	
	/**
	 * // Update RuleClassification By id
	 * 
	 * 
	 * @param rc - RuleClassification to be updated 
	 * @param rcID  - RuleClassification id
	 * @return RuleClassificationDTO - RuleClassification updated
	 */

	@PutMapping("/ruleclassifications/{id}")
	public ResponseEntity<?> updateRuleclassification(@PathVariable("id") int rcID,
			@RequestBody RuleClassification rc) {

		try {
			rc = ruleClassificationService.updateById(rcID, rc);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<RuleClassificationDTO>(modelMapper.map(rc, RuleClassificationDTO.class), HttpStatus.OK);
	}


}
