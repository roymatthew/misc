package com.ode.exchange.re.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.ode.exchange.re.DTO.RuleClassificationLookupDTO;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.serviceimpl.RuleClassificationLookupServiceImpl;
import com.ode.exchange.re.serviceimpl.RuleClassificationServiceImpl;

/**
 * This Controller Class for RuleClassificationLookupController. Handles
 * requests related to the REST resource "/ruleclassifications/{id}/dropdowns"
 * 
 * @author
 * 
 */
@CrossOrigin
@RestController
public class RuleClassificationLookupController {

	public static final Logger logger = LoggerFactory.getLogger(RuleClassificationLookupController.class);

	@Autowired
	private RuleClassificationLookupServiceImpl rclService;

	@Autowired
	private RuleClassificationServiceImpl ruleClassificationService;


	/**
	 * // Get All Lookups with Names with associated RuleClassification id
	 *
	 * @param rcID - RuleClassification id
	 * @return RuleClassificationLookupDTO - Lookups with Names with associated with
	 *         the rcID
	 */

	@GetMapping("/ruleclassifications/{id}/dropdowns")
	public ResponseEntity<?> getRuleClassificationLookupById(@PathVariable("id") int rcid) {
		RuleClassification rc = new RuleClassification();
		RuleClassificationLookupDTO rclDTO = new RuleClassificationLookupDTO();
		try {
			rc = ruleClassificationService.findRuleClassificationById(rcid);
		} catch (Exception e) {

			throw new BadRequestException(e.getMessage());
		}

		if (rc.getLookupFieldsID() != null && rc.getLookupFieldsID().length() != 0) {

			List<String> lookupFieldsStringIDs = Arrays.asList(rc.getLookupFieldsID().split(","));

			List<Integer> lookupFields = lookupFieldsStringIDs.stream().map(Integer::parseInt)
					.collect(Collectors.toList());

			rclDTO = rclService.findFieldDropDownByRuleClassificationId(lookupFields, rc);

		} else {
			rclDTO = rclService.findRuleClassification(rc);
		}
		return new ResponseEntity<RuleClassificationLookupDTO>(rclDTO, HttpStatus.OK);
	}

}
