package com.ode.exchange.re.controller;

import com.ode.exchange.re.DTO.RuleDTO;
import com.ode.exchange.re.entity.Rule;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.DuplicateRequestException;
import com.ode.exchange.re.serviceimpl.RuleServiceImpl;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * This Controller Class for RuleController. Handles requests related to the
 * REST resource "rules"
 *
 * @author
 *
 */

@CrossOrigin
@RestController
public class RuleController {

	public static final Logger logger =  LoggerFactory.getLogger(RuleController.class);

	@Autowired
	private RuleServiceImpl ruleService;

	/**
	 * // Get All Rules
	 *
	 * @return lists all Rules
	 */

	@GetMapping("/rules")
	public ResponseEntity<List<RuleDTO>> getRuleAll() {
		List<RuleDTO> rulelist = ruleService.getRuleAll();
		if (rulelist == null) {
			throw new BadRequestException("No rulelist found");
		}
		return new ResponseEntity<List<RuleDTO>>(rulelist, HttpStatus.OK);
	}

	/**
	 * Get Rule By id
	 *
	 * @param ruleid - Rule id
	 * @return Rule associated with the ruleid
	 */

	@GetMapping("/rules/{id}")
	public ResponseEntity<?> getRule(@PathVariable("id") int ruleid) {
		RuleDTO ruleDTO = null;
		try {
			ruleDTO = ruleService.getRuleById(ruleid);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		logger.info("Fetching Rule with id {}", ruleDTO);
		if (ruleDTO == null) {
			logger.error("Rule with id {} not found.", ruleid);
			return new ResponseEntity<RuleDTO>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<RuleDTO>(ruleDTO, HttpStatus.OK);
	}

	/**
	 * // Create Rule
	 *
	 *
	 * @param ruleDTO - Rule to be created
	 * @return ruleDTO - created Rule
	 */

	@PostMapping("/rules")
	public ResponseEntity<?> createRule(@RequestBody RuleDTO ruleDTO) {

		if (ruleDTO != null) {

			try {
				String ruleName = ruleDTO.getRuleName();
				String lookUpCriteria = ruleDTO.getLookupCriteria();
				List<RuleDTO> allRuleDTO = ruleService.getRuleByRCId(ruleDTO.getRuleClassificationDTO().getId());

				if (ruleDTO.getRuleClassificationDTO().getId() == 66) {
					if (allRuleDTO.stream().filter(rule -> rule.getLookupCriteria().equals(lookUpCriteria)
							&& rule.getRuleName().equals(ruleName)).findAny().orElse(null) != null) {
						throw new DuplicateRequestException("Duplicate Rule Name Exists");
					} else {
						ruleDTO = ruleService.createRule(ruleDTO);
					}
				} else {
					if (allRuleDTO.stream().filter(rule -> rule.getRuleName().equals(ruleName)).findAny()
							.orElse(null) != null) {
						throw new DuplicateRequestException("Duplicate Rule Name Exists");
					} else {
						ruleDTO = ruleService.createRule(ruleDTO);
					}

				}

			} catch (Exception e) {
				throw new BadRequestException(e.getMessage());
			}

			if (ruleDTO == null) {
				return new ResponseEntity<RuleDTO>(HttpStatus.CONFLICT);
			}
			return new ResponseEntity<RuleDTO>(ruleDTO, HttpStatus.CREATED);

		} else {
			throw new BadRequestException("Rule input is empty");
		}

	}

	/**
	 * // Update Rule By id
	 *
	 *
	 * @param ruleDTO - Rule to be updated
	 * @param ruleid  - message id
	 * @return ruleDTO - Rule updated
	 */

	@PutMapping("/rules/{id}")
	public ResponseEntity<?> updateRule(@PathVariable("id") int ruleid, @RequestBody RuleDTO ruleDTO) {
		Rule rule;
		if (ruleDTO != null) {
			try {
				String ruleName = ruleDTO.getRuleName();
				String lookUpCriteria = ruleDTO.getLookupCriteria();
				List<RuleDTO> allRuleDTO = ruleService.getRuleByRCId(ruleDTO.getRuleClassificationDTO().getId());

				if (ruleDTO.getRuleClassificationDTO().getId() == 66) {
					if (allRuleDTO.stream().filter(rules -> rules.getLookupCriteria().equals(lookUpCriteria)
							&& rules.getRuleName().equals(ruleName) && rules.getId() != ruleDTO.getId()).findAny()
							.orElse(null) != null) {
						throw new DuplicateRequestException("Duplicate Rule Name Exists");
					} else {
						rule = ruleService.updateById(ruleid, ruleDTO);
					}
				} else {
					rule = ruleService.updateById(ruleid, ruleDTO);
				}
			} catch (Exception e) {
				throw new BadRequestException(e.getMessage());
			}
			return new ResponseEntity<Rule>(rule, HttpStatus.OK);

		} else {
			throw new BadRequestException("Rule input is empty");
		}

	}


	@GetMapping("ruleclassifications/{rcName}/activerules/{id}")
	public ResponseEntity<?> getActiveRulesByMessageId(@PathVariable("rcName") String rcName,@PathVariable("id") int messageId ) {
		List<RuleDTO> activeRuleList = new ArrayList<>();
		try {
			activeRuleList = ruleService.getActiveRulesByMessageId(rcName,messageId);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		return new ResponseEntity<List<RuleDTO>>(activeRuleList, HttpStatus.OK);

	}

}
