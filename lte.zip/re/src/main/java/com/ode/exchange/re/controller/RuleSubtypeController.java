package com.ode.exchange.re.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.RuleSubtypeDTO;
import com.ode.exchange.re.entity.RuleSubtype;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.RuleSubtypeServiceImpl;

/**
 * This Controller Class for MessageController. Handles requests related to the
 * REST resource "rulesubtypes"
 * 
 * @author
 * 
 */
@CrossOrigin
@RestController
public class RuleSubtypeController {

	@Autowired
	private RuleSubtypeServiceImpl ruleSubtypeService;

	private RuleSubtypeDTO ruleSubtypeDTOObj;

	/**
	 * Get All Rulesubtypes
	 * 
	 * @return lists all Rulesubtypes
	 */

	@GetMapping("/rulesubtypes")
	public ResponseEntity<List<RuleSubtypeDTO>> getRuleSubtypeAll() {
		List<RuleSubtypeDTO> ruleSubtypelist = ruleSubtypeService.getRuleSubtypeAll();
		if (ruleSubtypelist == null) {
			throw new NotFoundException("No RuleSubtypelist found");
		}
		return new ResponseEntity<List<RuleSubtypeDTO>>(ruleSubtypelist, HttpStatus.OK);
	}

	/**
	 * // Get Rulesubtypes by id
	 *
	 * @param ruleSubTypeID - Rulesubtype id
	 * @return Rulesubtype associated with the ruleSubTypeID
	 */

	@GetMapping("/rulesubtypes/{id}")
	public ResponseEntity<?> getRuleSubtypeById(@PathVariable("id") int ruleSubTypeID) {

		try {
			ruleSubtypeDTOObj = ruleSubtypeService.findById(ruleSubTypeID);
		} catch (Exception e) {

			throw new BadRequestException("No RuleSubtype found");
		}
		return new ResponseEntity<RuleSubtypeDTO>(ruleSubtypeDTOObj, HttpStatus.OK);
	}

	/**
	 * // Get RuleSubtypes by RuleType
	 *
	 * @param ruleType - ruleType
	 * @return ruleSubtypelist associated with the ruleType
	 */

	@GetMapping("/rulesubtypes/ruletype/{ruletype}")
	public ResponseEntity<?> getRuleSubtypeByRuleType(@PathVariable("ruletype") String ruleType)
			throws UnsupportedEncodingException {
		String decoded = URLDecoder.decode(ruleType, "UTF-8");
		List<RuleSubtypeDTO> ruleSubtypelist = ruleSubtypeService.findRuleSubtypeByRuleType(decoded);
		if (ruleSubtypelist == null) {
			throw new NotFoundException("No RuleSubtypelist found");
		}
		return new ResponseEntity<List<RuleSubtypeDTO>>(ruleSubtypelist, HttpStatus.OK);
	}

	/**
	 * // Create Rulesubtypes
	 * 
	 * 
	 * @param ruleSubtypeDTO - Rulesubtype to be created
	 * @return ruleSubtypeDTO - created Rulesubtype
	 */

	@PostMapping("/rulesubtypes")
	public ResponseEntity<?> createRuleSubtype(@RequestBody @NotNull RuleSubtypeDTO ruleSubtypeDTO) {
		try {
			ruleSubtypeDTOObj = ruleSubtypeService.createRuleSubtype(ruleSubtypeDTO);
		} catch (Exception e) {

			throw new BadRequestException("No RuleSubtype found");
		}

		return new ResponseEntity<RuleSubtypeDTO>(ruleSubtypeDTOObj, HttpStatus.CREATED);

	}

	/**
	 * // Update Rulesubtypes by id
	 * 
	 * 
	 * @param ruleSubtypeDTO - Rulesubtype to be updated
	 * @param ruleSubTypeID  - Rulesubtype id
	 * @return ruleSubtypeDTO - Rulesubtype updated
	 */

	@PutMapping("/rulesubtypes/{id}")
	public @ResponseBody ResponseEntity<?> updateRuleSubtype(@PathVariable("id") int ruleSubTypeID,
			@RequestBody @NotNull RuleSubtypeDTO ruleSubtypeDTO) {
		try {
			ruleSubtypeDTOObj = ruleSubtypeService.updateById(ruleSubTypeID, ruleSubtypeDTO);
		} catch (Exception e) {
			throw new BadRequestException("No RuleSubtype found");
		}

		return new ResponseEntity<RuleSubtypeDTO>(ruleSubtypeDTOObj, HttpStatus.OK);

	}
}