package com.ode.exchange.re.controller;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.RuleTypeDTO;

import com.ode.exchange.re.entity.RuleType;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.RuleTypeServiceImpl;


/**
 * This Controller Class for RuleTypeController. Handles requests related to the
 * REST resource "ruletypes"
 * 
 * @author
 * 
 */

@CrossOrigin
@RestController
public class RuleTypeController {
	public static final Logger logger = LoggerFactory.getLogger(RuleTypeController.class);
	@Autowired
	private RuleTypeServiceImpl ruleTypeService;
	
	 @Autowired
	    private ModelMapper modelMapper;

	
		/**
		 * // Get All Ruletypes
		 * 
		 * @return lists all Ruletypes
		 */
	 
	@GetMapping("/ruletypes")
	public ResponseEntity<List<RuleTypeDTO>> getRuleTypeAll() {
		List<RuleType> ruleTypeList = ruleTypeService.getRuleTypeAll();
		java.lang.reflect.Type targetListType = new TypeToken<List<RuleTypeDTO>>() {}.getType();
		List<RuleTypeDTO> ruleTypeDTOList = modelMapper.map(ruleTypeList, targetListType);		
		if (ruleTypeList == null) {
			throw new NotFoundException("No ruletypes found");
		}

		return new ResponseEntity<List<RuleTypeDTO>>(ruleTypeDTOList, HttpStatus.OK);
	}

	
	
	/**
	 * Get Ruletypes By id
	 *
	 * @param ruleTypeID - message id
	 * @return RuleType associated with the ruleTypeID
	 */
	
	@GetMapping("/ruletypes/{id}")
	public ResponseEntity<?> getRuleTypeById(@PathVariable("id") int ruleTypeID) {
		RuleType ruleType = new RuleType();
		try {
			ruleType = ruleTypeService.findRuleTypeById(ruleTypeID);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
			}
		return new ResponseEntity<RuleTypeDTO>(modelMapper.map(ruleType, RuleTypeDTO.class), HttpStatus.OK);
	}

	
	/**
	 * // Create Ruletype
	 * 
	 * 
	 * @param ruleType  - RuleType to be created	 
	 * @return RuleTypeDTO - RuleType Message
	 */

	
	@PostMapping("/ruletypes")
	public ResponseEntity<?> createRuleType(@RequestBody @NotNull RuleType ruleType) {		
		ruleType = ruleTypeService.createRuleType(ruleType);
			if (ruleType == null) {
				throw new BadRequestException("failed to save  RuleType");
			}
			return new ResponseEntity<RuleTypeDTO>(modelMapper.map(ruleType, RuleTypeDTO.class), HttpStatus.CREATED);
		
	}
	

	
	/**
	 *Update Ruletype By id
	 * 
	 * 
	 * @param ruleType - Ruletype to be updated 
	 * @param ruleTypeID  - Ruletype id
	 * @return RuleTypeDTO - Ruletype updated
	 */
	
	@PutMapping("/ruletypes/{id}")
	public ResponseEntity<?> updateRuleType(@PathVariable("id") int ruleTypeID,@RequestBody @NotNull RuleType ruleType) {		
		try {
			ruleType = ruleTypeService.updateRuleTypeById(ruleTypeID, ruleType);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
			}
			

			return new ResponseEntity<RuleTypeDTO>(modelMapper.map(ruleType, RuleTypeDTO.class), HttpStatus.OK);
		
	}
}