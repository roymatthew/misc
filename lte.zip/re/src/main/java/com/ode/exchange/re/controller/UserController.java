package com.ode.exchange.re.controller;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.modelmapper.ModelMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ode.exchange.re.DTO.ResetPasswordDTO;
import com.ode.exchange.re.DTO.RolesDTO;
import com.ode.exchange.re.DTO.UserDTO;

import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.entity.AppUser;

import com.ode.exchange.re.serviceimpl.UserServiceImpl;

import com.ode.exchange.re.entity.UserRole;

import javax.validation.constraints.NotNull;

/**
 * This Controller Class for UserController. Handles requests related to the
 * REST resource "users"
 * 
 * @author
 * 
 */
@RestController
@CrossOrigin
public class UserController {
	public static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private ModelMapper modelMapper;

	@Value("${ode.secret.encoding.key}")
	private String secret;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	/**
	 * // Get All Users
	 * 
	 * @return lists all Users
	 */

	@GetMapping("/users")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<UserDTO> getUserAll() {
		List<AppUser> appUserlist = new ArrayList<>();
		logger.debug("--get User all --");
		Iterable<AppUser> userList = userService.getUserAll();
		if (userList == null) {
			throw new NotFoundException("No users found");
		}
		userList.forEach(appUserlist::add);
		logger.debug("get list of user  : {} ", userList);

		List<UserDTO> userDTOList = new ArrayList<>();
		logger.debug("convert list to userdto list ");

		appUserlist.forEach(appuser -> {
			RolesDTO rolesDTO = modelMapper.map(appuser.getUserRoles(), RolesDTO.class);
			StringBuilder encodedPass = new StringBuilder();
			encodedPass.append(secret);
			encodedPass.append(appuser.getPassword());
			appuser.setPassword(Base64.getEncoder().encodeToString(encodedPass.toString().getBytes()));
			UserDTO userDTO = modelMapper.map(appuser, UserDTO.class);
			userDTO.setRole(rolesDTO);

			userDTOList.add(userDTO);
		});
		return userDTOList;
	}

	/**
	 * Create User
	 * 
	 * 
	 * @param userDTO - User to be created
	 * @return userDTOobj - User created
	 */

	@PostMapping(value = "/users")
	@ResponseStatus(HttpStatus.CREATED)
	@ResponseBody
	public UserDTO saveUser(@RequestBody @NotNull UserDTO userDTO) {
		UserRole userRole = modelMapper.map(userDTO.getRole(), UserRole.class);
		AppUser appUser = modelMapper.map(userDTO, AppUser.class);
		appUser.setUserRoles(userRole);
		try {
			appUser = userService.save(appUser);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		RolesDTO rolesDTO = modelMapper.map(appUser.getUserRoles(), RolesDTO.class);
		UserDTO userDTOobj = modelMapper.map(appUser, UserDTO.class);
		userDTOobj.setRole(rolesDTO);
		return userDTOobj;

	}

	/**
	 * // Get User By id
	 *
	 * @param userID - User id
	 * @return userDTO - User associated with the userID
	 */

	@GetMapping("/users/{id}")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public UserDTO getUserById(@PathVariable("id") int userID) {
		AppUser appUser = new AppUser();
		try {
			appUser = userService.findById(userID);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		RolesDTO rolesDTO = modelMapper.map(appUser.getUserRoles(), RolesDTO.class);
		StringBuilder encodedPass = new StringBuilder();
		encodedPass.append(secret);
		encodedPass.append(appUser.getPassword());
		appUser.setPassword(Base64.getEncoder().encodeToString(encodedPass.toString().getBytes()));
		UserDTO userDTO = modelMapper.map(appUser, UserDTO.class);
		userDTO.setRole(rolesDTO);
		return userDTO;

	}

	/**
	 * // Update User By id
	 * 
	 * 
	 * @param userDTO - User to be updated
	 * @param userID  - User id
	 * @return userDTOobj - User updated
	 */

	@PutMapping("/users/{id}")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public UserDTO updateUser(@PathVariable("id") int userID, @RequestBody UserDTO userDTO) {
		UserRole userRole = modelMapper.map(userDTO.getRole(), UserRole.class);
		AppUser appUser = modelMapper.map(userDTO, AppUser.class);
		AppUser appUserEntity = userService.findById(userID);
		appUser.setCreatedDate(appUserEntity.getCreatedDate());
		appUser.setId(userID);
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] decodedByteArray = decoder.decode(userDTO.getPassword());
		String decodedString = new String(decodedByteArray);
		String pass = decodedString.replaceFirst(secret, "");
		if (appUserEntity.getPassword().equals(pass)) {
			appUser.setPassword(appUserEntity.getPassword());
		} else if (!appUserEntity.getPassword().equals(pass)) {
			appUser.setPassword(bcryptEncoder.encode(pass));
		}
		appUser.setUserRoles(userRole);
		appUser = userService.save(appUser);
		if (appUser == null) {
			throw new BadRequestException("Failed to update user");
		}
		RolesDTO rolesDTO = modelMapper.map(appUser.getUserRoles(), RolesDTO.class);
		StringBuilder encodedPass = new StringBuilder();
		encodedPass.append(secret);
		encodedPass.append(appUser.getPassword());
		appUser.setPassword(Base64.getEncoder().encodeToString(encodedPass.toString().getBytes()));
		UserDTO userDTOobj = modelMapper.map(appUser, UserDTO.class);
		userDTOobj.setRole(rolesDTO);
		return userDTOobj;

	}

	@PutMapping("/users/updatepassword")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public UserDTO updateUserPass(@RequestBody ResetPasswordDTO resetPasswordDTO) {
		AppUser appUsernewPassword = new AppUser();
		AppUser appUserEntity = userService.findByUser(resetPasswordDTO.getUserName()); // hashed pass
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] decodedByteArray = decoder.decode(resetPasswordDTO.getOldPassword());
		String decodedString = new String(decodedByteArray);
		String pass = decodedString.replaceFirst(secret, "");
		if (bcryptEncoder.matches(pass, appUserEntity.getPassword())) {
			Base64.Decoder decoderNewPassword = Base64.getDecoder();
			byte[] decodedByteArrayNewPassword = decoderNewPassword.decode(resetPasswordDTO.getNewPassword());
			String decodedStringNewPassword = new String(decodedByteArrayNewPassword);
			String newPassword = decodedStringNewPassword.replaceFirst(secret, "");
			appUserEntity.setPassword(bcryptEncoder.encode(newPassword));
			appUsernewPassword = userService.save(appUserEntity);
		} else if (!appUserEntity.getPassword().equals(pass)) {
			throw new BadRequestException("Failed to Validate the Password. Password do not match");
		}
		if (appUsernewPassword == null) {
			throw new BadRequestException("Failed to update user");
		}
		RolesDTO rolesDTO = modelMapper.map(appUsernewPassword.getUserRoles(), RolesDTO.class);
		StringBuilder encodedPass = new StringBuilder();
		encodedPass.append(secret);
		encodedPass.append(appUsernewPassword.getPassword());
		appUsernewPassword.setPassword(Base64.getEncoder().encodeToString(encodedPass.toString().getBytes()));
		UserDTO userDTOobj = modelMapper.map(appUsernewPassword, UserDTO.class);
		userDTOobj.setRole(rolesDTO);
		return userDTOobj;

	}

}
