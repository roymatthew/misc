package com.ode.exchange.re.controller;

import java.util.List;
import javax.validation.constraints.NotNull;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.ode.exchange.re.DTO.RolesDTO;
import com.ode.exchange.re.entity.UserRole;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.serviceimpl.UserroleServiceImpl;

/**
 * This Controller Class for UserRoleController. Handles requests related to the
 * REST resource "userroles"
 * 
 * @author
 * 
 */
@CrossOrigin
@RestController
public class UserRoleController {
	public static final Logger logger = LoggerFactory.getLogger(UserRoleController.class);

	@Autowired
	private UserroleServiceImpl userroleService;

	@Autowired
	private ModelMapper modelMapper;

	/**
	 * // Get All Roles
	 * 
	 * @return lists all Roles
	 */

	@GetMapping("/userroles")
	public ResponseEntity<List<RolesDTO>> getRolesAll() {
		logger.info("--get Roles all --");
		Iterable<UserRole> rolesList = userroleService.getRolesAll();
		if (rolesList == null) {
			throw new NotFoundException("No roles found");
		}
		logger.debug("get list of roles : {} ", rolesList);
		java.lang.reflect.Type targetListType = new TypeToken<List<RolesDTO>>() {
		}.getType();
		List<RolesDTO> roleDTOList = modelMapper.map(rolesList, targetListType);
		logger.debug("convert list to userdto list : {} ", roleDTOList);

		return new ResponseEntity<>(roleDTOList, HttpStatus.OK);
	}

	/**
	 * // Get Roles By id
	 *
	 * @param roleID - Role id
	 * @return RolesDTO - Role associated with the roleID
	 */

	@GetMapping("/userroles/{id}")
	public ResponseEntity<RolesDTO> getRoleById(@PathVariable("id") int roleID) {
		UserRole roles = userroleService.findById(roleID);
		if (roles == null) {
			throw new NotFoundException("role not found");

		}
		return new ResponseEntity<>(modelMapper.map(roles, RolesDTO.class), HttpStatus.OK);
	}

	/**
	 * Create Role
	 * 
	 * 
	 * @param rolesDTO - Role to be created
	 * @return RolesDTO - Role created
	 */

	@PostMapping("userroles")
	public ResponseEntity<RolesDTO> saveUserrole(@RequestBody @NotNull RolesDTO rolesDTO) {
		UserRole userRole = modelMapper.map(rolesDTO, UserRole.class);
		userRole = userroleService.saveRole(userRole);
		if (userRole == null) {
			throw new BadRequestException("Failed to save role");
		}
		return new ResponseEntity<>(modelMapper.map(userRole, RolesDTO.class), HttpStatus.CREATED);

	}

	/**
	 * // Update Role By id
	 * 
	 * 
	 * @param rolesDTO - Role to be updated
	 * @param roleID   - Role id
	 * @return RolesDTO - Role updated
	 */

	@PutMapping("/userroles/{id}")
	public @ResponseBody ResponseEntity<RolesDTO> updateUserrole(@PathVariable("id") int roleID,
			@RequestBody RolesDTO rolesDTO) {
		UserRole userRole = modelMapper.map(rolesDTO, UserRole.class);
		userRole.setId(roleID);
		userRole = userroleService.updateUserrole(roleID, userRole);
		if (userRole == null) {
			throw new BadRequestException("Failed to update user");

		}
		return new ResponseEntity<>(modelMapper.map(userRole, RolesDTO.class), HttpStatus.OK);

	}

}