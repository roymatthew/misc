package com.ode.exchange.re.controller;

import com.ode.exchange.re.DTO.ProcessAuditDTO;
import com.ode.exchange.re.DTO.XMLFieldsDTO;
import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.entity.CreditDecision;
import com.ode.exchange.re.entity.ProcessAudit;
import com.ode.exchange.re.entity.RFLRuleResponse;
import com.ode.exchange.re.entity.RequiredFieldRule;
import com.ode.exchange.re.entity.Rule;
import com.ode.exchange.re.entity.RuleAudit;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.RequestXML;
import com.ode.exchange.re.etlentity.XMLFields;
import com.ode.exchange.re.etlservice.IETLConfigurationService;
import com.ode.exchange.re.etlservice.IRequestXMLService;
import com.ode.exchange.re.etlservice.IXMLFieldsService;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.serviceimpl.CalculationServiceImpl;
import com.ode.exchange.re.serviceimpl.CreditDecisionServiceImpl;
import com.ode.exchange.re.serviceimpl.ProcessRuleServiceImpl;
import com.ode.exchange.re.serviceimpl.RuleAuditServiceImpl;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * This Controller Class for XMLDataController. Handles requests related to the
 * REST resource "processrules"
 *
 * @author
 *
 */
@CrossOrigin
@RestController
//@PropertySource(value = "file:/data/ode/derulesengine/application.properties")
public class XMLDataController {

	private static final Logger logger = LoggerFactory.getLogger(XMLDataController.class);

	@Value("${ode.qualified-rule-pass}")
	private String pass;

	@Value("${ode.qualified-rule-fail}")
	private String fail;

	@Value("${ode.no-rule-failure}")
	private String norule;

	@Value("${ode.requiredfield-missingfield}")
	private String messageformat;

	@Value("${ode.formvalidation-form}")
	private String formNumberTag;

	@Value("${ode.processaudit-pass}")
	private String auditPass;

	@Value("${ode.qualified-rule-fail-message}")
	private String failmessage;

	@Value("${ode.qualified-rule-pass-message}")
	private String passmessage;

	@Autowired
	private ModelMapper modelMapper;

	@Value("${ode.formvalidation-revisiondate}")
	private String formRevisionTag;

	@Autowired
	private ProcessRuleServiceImpl processRuleService;

	@Autowired
	private RuleAuditServiceImpl ruleAuditService;

	@Autowired
	private CalculationServiceImpl calcService;

	@Autowired
	private CreditDecisionServiceImpl creditDecisionService;
	
	@Autowired
	private IRequestXMLService requestXmlService;
	
	@Autowired
	private IETLConfigurationService etlConfigurationService;
	
	@Autowired
	private IXMLFieldsService xmlFieldsService;
	
	@Value("${ode.ETL.API}")
	private String uri;

	@GetMapping("/processrules/{id}")
	public ResponseEntity<ProcessAuditDTO> processRulesAll(@PathVariable("id") long xmlID) throws Exception {
		logger.debug("Entered processRulesAll() method of XMLDataController. xmlId: {}", xmlID);
		RestTemplate restTemplate = new RestTemplate();
		List<XMLFieldsDTO> xmlfieldsDTOList = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		ProcessAudit processAudit = new ProcessAudit();
		RFLRuleResponse rflPassMessage = new RFLRuleResponse();

		sb.append(uri);
		sb.append(xmlID);

		try {
/*			try {
				ResponseEntity<List<XMLFieldsDTO>> response = restTemplate.exchange(sb.toString(), HttpMethod.GET, null,
						new ParameterizedTypeReference<List<XMLFieldsDTO>>() {
				});
				xmlfieldsDTOList = response.getBody();
			} catch (Exception e) {
				logger.debug("Error While Getting ETL Data ", e.getMessage());
				throw new BadRequestException("Error While Getting ETL Data " + e.getMessage());

			}*/
			
			xmlfieldsDTOList = xmlFieldsService.getXMLFieldsDTOByXMLId(xmlID);
			if (xmlfieldsDTOList == null || xmlfieldsDTOList.isEmpty()) {
				logger.debug("No Data in XML for the XMLID " + xmlID);
				throw new BadRequestException("No Data in XML for the XMLID " + xmlID);
			}

			List<String> xmlFieldsList = new ArrayList<>();
			List<String> requiredFieldsList = new ArrayList<>();
			StringBuilder failedrequiredFieldsString = new StringBuilder();
			LinkedHashMap<String, String> xmlLookUpFieldMap = new LinkedHashMap<>();
			LinkedHashMap<String, String> xmlFieldValueMap = new LinkedHashMap<>();

			LinkedHashMap<String, String> formValidationMap = new LinkedHashMap<>();
			
			Optional<RequestXML> requestXMLObj = requestXmlService.getRequestXML(xmlID);
			if (null != requestXMLObj) {
				logger.debug("Found RequestXML with xmlid: {}", xmlID);
			}
						// get all calculations
			List<Calculation> calcList = calcService.getCalculationAll();
			logger.info("Getting data from XML for Processing ");
			XMLFields spotDeliveryIndDTO = null;
			for (XMLFieldsDTO xmlfield : xmlfieldsDTOList) {

				if (!xmlFieldsList.contains(xmlfield.getFieldName())) {
					xmlFieldsList.add(xmlfield.getFieldName());
				}

				if (!xmlFieldValueMap.containsKey(xmlfield.getFieldName())) {
					xmlFieldValueMap.put(xmlfield.getFieldName(), xmlfield.getFieldValue());
				}
				// Keep reference to XMLFieldsDTO for SpotDeliveryInd for later
				if (xmlfield.getFieldName().contentEquals(Constants.SPOT_DELIVERY_IND_TAG_NAME)) {
					spotDeliveryIndDTO = new XMLFields();
					spotDeliveryIndDTO.setFieldName(xmlfield.getFieldName());
					spotDeliveryIndDTO.setFieldType(xmlfield.getFieldType());
					spotDeliveryIndDTO.setFieldValue(xmlfield.getFieldValue());
					spotDeliveryIndDTO.setGroupLevel(xmlfield.isGroupLevel());
					spotDeliveryIndDTO.setId(xmlfield.getId());
					spotDeliveryIndDTO.setLookupUsage(xmlfield.isLookupUsage());
					spotDeliveryIndDTO.setXmlId(xmlfield.getXmlId());
				}

				if (xmlfield.isLookupUsage() && !xmlfield.getFieldValue().isEmpty()) {
					if (!xmlLookUpFieldMap.containsKey(xmlfield.getFieldName())) {
						xmlLookUpFieldMap.put(xmlfield.getFieldName(), xmlfield.getFieldValue());
					}

				}
			}

			xmlfieldsDTOList.forEach(xmlfield -> {
				if (xmlfield.getFieldName().equals(formNumberTag) && !xmlfield.getFieldValue().isEmpty()) {

					formValidationMap.put(xmlfield.getFieldName(), xmlfield.getFieldValue());
				}
				if (xmlfield.getFieldName().equals(formRevisionTag) && !xmlfield.getFieldValue().isEmpty()) {

					formValidationMap.put(xmlfield.getFieldName(), xmlfield.getFieldValue());
				}

			});

			processAudit.setXmlId(xmlfieldsDTOList.get(0).getXmlId());

			Optional<RequiredFieldRule> requiredFieldRuleRetured = processRuleService
					.getRuleByRequiredField(xmlLookUpFieldMap, processAudit);

			if (requiredFieldRuleRetured.isPresent()) {
				RequiredFieldRule requiredFieldRule = requiredFieldRuleRetured.get();

				Rule rule = requiredFieldRule.getRule();
				processAudit = requiredFieldRule.getProcessAudit();
				RuleAudit ruleAudit = new RuleAudit();

				ruleAudit.setRcid(rule.getRuleClassification().getId());
				ruleAudit.setXmlId(xmlfieldsDTOList.get(1).getXmlId());
				ruleAudit.setLookupCriteria(rule.getLookupCriteria());
				ruleAudit.setRulelogic(rule.getRuleLogic()); // code change for
				// required
				// field, fixed
				// field
				// merge to Rule
				// Logic

				String requiredFields = rule.getRuleLogic(); // code change for
				// required
				// field, fixed
				// field merge
				// to
				// Rule Logic
				String[] requiredFieldsarray = requiredFields.split("\\|\\|");
				requiredFieldsList = new ArrayList<>(Arrays.asList(requiredFieldsarray));
				if (!xmlFieldsList.containsAll(requiredFieldsList)) {
					logger.debug("xmlFieldsList does not contain all required fields.");

					for (String requiredField : requiredFieldsList) {
						//ecinFieldValue - Content of XML tag in the incoming XML
						//with tag name equal to requiredField
						String ecinFieldValue = xmlFieldValueMap.get(requiredField);
						logger.debug("Value of requiredField: {} is {}", requiredField, ecinFieldValue);
						if (StringUtils.isBlank(ecinFieldValue)) {							
							logger.debug("Checking if parent exists for missing required field: {}", requiredField);
							if (etlConfigurationService.doesParentExist(requiredField, requestXMLObj)) {

								logger.debug("Parent element found for {}. Adding to failed validation list.",
										requiredField);

								if (failedrequiredFieldsString.length() > 0) {
									failedrequiredFieldsString.append(",");
								}
								failedrequiredFieldsString.append(requiredField);
							} else {
								logger.debug("No parent element found for {}. Will not add to failed validation list.",
										requiredField);
							}
						}
					}
					if (failedrequiredFieldsString.length() > 0)
					{
						logger.debug("There were required field validation errors!");
						ruleAudit.setRuleExecutionResult(fail);
						
						if (rule.getFailmessage() != null) {
							String failMessage = rule.getFailmessage().getMessage();

							String replacedfailMessage = failMessage.replace(messageformat,
									failedrequiredFieldsString.toString());

							ruleAudit.setMessageResponse(replacedfailMessage);
							processAudit.setRfValidationResult(
									passmessage + " " + " || " + failmessage + " " + replacedfailMessage);
							processAudit.setRfValidationEnd(new Timestamp(System.currentTimeMillis()));
							logger.info("Required Field Rule Failed {}", rule);
						} else if (rule.getFailmessage() == null) {
							ruleAudit.setMessageResponse("");
							processAudit.setRfValidationResult(passmessage + " " + " || " + failmessage + " " + "");
							processAudit.setRfValidationEnd(new Timestamp(System.currentTimeMillis()));
							logger.info("Required Field Rule Failed! {}", rule);
						}
					}

				}
				else
				{
					logger.debug("No required fields missing in xmlFieldsList.");
				}
				if (failedrequiredFieldsString.length() == 0) {
					logger.debug("There were ***NO*** required field validation errors.");
					ruleAudit.setRuleExecutionResult(pass);
					if (rule.getPassmessage() != null) {
						ruleAudit.setMessageResponse(rule.getPassmessage().getMessage());
						processAudit.setRfValidationResult(passmessage + " " + rule.getPassmessage().getMessage()
								+ auditPass + " || " + failmessage + " ");
					} else if (rule.getPassmessage() == null) {
						processAudit.setRfValidationResult(passmessage + " " + auditPass + " || " + failmessage + " ");
						ruleAudit.setMessageResponse("");
					}

					processAudit.setRfValidationEnd(new Timestamp(System.currentTimeMillis()));
					logger.info("Required Field Rule Passed {}", rule);
				}
				
				ruleAudit.setRule(rule);
				ruleAuditService.saveRuleAudit(ruleAudit);
				logger.info("Required Field Rules Processing End...");

			}
			else
			{
				logger.info("No Required Field Rules returned");
			}

			if (formValidationMap.size() <= 1) {
				processAudit.setFnValidationStart(new Timestamp(System.currentTimeMillis()));
				processAudit.setFnValidationResult(norule);
				processAudit.setFnValidationEnd(new Timestamp(System.currentTimeMillis()));
			}
			if (formValidationMap.size() > 1) {
				logger.info("Form Number and Revision Date on the XML {}", formValidationMap);
				processRuleService.getRuleByFormValidation(formValidationMap, xmlLookUpFieldMap, processAudit);

			}

			List<CreditDecision> creditDecisionList;
			String fsAppNumber = xmlFieldValueMap.get("ApplicationNumber");
			if (fsAppNumber != null && !fsAppNumber.isEmpty()) {
				try {
					// perform query using appnum
					logger.debug("Looking up credit decisions by fsAppNumber: {}", fsAppNumber);
					creditDecisionList = creditDecisionService
							.findCreditDecisionByAppNumber(fsAppNumber);
					logger.debug("Credit Decision List by App number lookup: {}", creditDecisionList);
				} catch (final Exception e) {
					throw new BadRequestException("Credit App Not Found for fsAppNumber: " + fsAppNumber);
				}

			} else {
				// perform query using VIN (if one record is returned, use it)
				logger.info("No Application Number Used, searching by VIN");
				creditDecisionList = creditDecisionService
						.findCreditDecisionByVinNumber(xmlFieldValueMap.get("VehicleVIN"));
				logger.info("Credit Decision List by VIN number lookup: {}", creditDecisionList);

			}

			Optional<RFLRuleResponse> rFLReturned = Optional.empty();
			Boolean creditDecisionOrSpotValid = processRuleService.validateCreditDecisionOrSpot(xmlFieldValueMap, 
																	processAudit, creditDecisionList);
			if (creditDecisionOrSpotValid) {
				// SpotDeliveryInd may have been updated during validateCreditDecisionOrSpot
				if (spotDeliveryIndDTO != null) {
					spotDeliveryIndDTO.setFieldValue(xmlFieldValueMap.get(Constants.SPOT_DELIVERY_IND_TAG_NAME));
					xmlFieldsService.saveXMLFields(spotDeliveryIndDTO);
				}
				
				processRuleService.getRuleByRegulation(xmlfieldsDTOList, xmlFieldValueMap, xmlLookUpFieldMap, processAudit,
						calcList, creditDecisionList);

				processRuleService.getTolerance(xmlfieldsDTOList, xmlLookUpFieldMap, xmlFieldValueMap, processAudit,
						calcList, creditDecisionList);

				rFLReturned = processRuleService.getRuleByRFL(xmlfieldsDTOList, xmlFieldsList,
						xmlLookUpFieldMap, xmlFieldValueMap, processAudit, calcList, creditDecisionList);
			}
			
			if ((processAudit.getRfValidationResult().contains(auditPass)
					|| processAudit.getRfValidationResult().contains(norule))
					&& (processAudit.getFnValidationResult().contains(auditPass)
							|| processAudit.getFnValidationResult().contains(norule))
					&& (processAudit.getrValidationResult().contains(auditPass)
							|| processAudit.getrValidationResult().contains(norule))
					&& (processAudit.gettValidationResult().contains(auditPass)
							|| processAudit.gettValidationResult().contains(norule))) {
				processAudit.setFinalValidationResult(pass);
				if (rFLReturned.isPresent()) {
					rflPassMessage = rFLReturned.get();

					if (rflPassMessage.getPassedRFLs() != null) {
						if(!rflPassMessage.getPassedRFLs().isEmpty() ) {
							processAudit.setRflValidationResult(rflPassMessage.getPassedRFLs());
							processAudit.setRflValidationResult(rflPassMessage.getPassedRFLs());
						}
						if (rflPassMessage.getPassedRFLs().isEmpty()) {
							processAudit.setRflValidationResult("");
						}
					}
				}
				else
				{
					logger.debug("processRuleService.getRuleByRFL() did not return any results!");
				}

			}

			else {
				processAudit.setFinalValidationResult(fail);
				processAudit.setRflValidationResult("");
			}

			if (processAudit.getRfValidationResult().contains(auditPass)) {

				String passmsg = processAudit.getRfValidationResult();
				passmsg = passmsg.replaceAll(auditPass, " ");
				processAudit.setRfValidationResult(passmsg);

			}
			if (processAudit.getFnValidationResult().contains(auditPass)) {

				String passmsg = processAudit.getFnValidationResult();
				passmsg = passmsg.replaceAll(auditPass, " ");
				processAudit.setFnValidationResult(passmsg);

			}
			if (processAudit.getrValidationResult().contains(auditPass)) {

				String passmsg = processAudit.getrValidationResult();
				passmsg = passmsg.replaceAll(auditPass, " ");
				processAudit.setrValidationResult(passmsg);

			}
			if (processAudit.gettValidationResult().contains(auditPass)) {

				String passmsg = processAudit.gettValidationResult();
				passmsg = passmsg.replaceAll(auditPass, " ");
				processAudit.settValidationResult(passmsg);

			}

		} catch (Exception e) {
			logger.debug("Exeption while executing process rule API " + e.getMessage());
		}

		ProcessAuditDTO processAuditDTO = modelMapper.map(processAudit, ProcessAuditDTO.class);
		logger.debug("Exit processRulesAll() method of XMLDataController. xmlId: {}", xmlID);
		return new ResponseEntity<>(processAuditDTO, HttpStatus.OK);
	}	

}
