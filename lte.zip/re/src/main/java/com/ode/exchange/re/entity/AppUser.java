package com.ode.exchange.re.entity;



import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;






/**
 * This is an Entity Class for Application User. Maps User and UserRole Table
 * 
 * @author 
 *
 */

@Entity
@Table(name = "\"USER\"" )
public class AppUser implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "UserID")
	private int id;
	
	@Column(name = "Username")
	private String username;

	@Column(name = "UserroleID")
	private int userRoleID;

	@Column(name = "Password")
	private String password;

	@Column(name = "Firstname")
	private String firstName;

	@Column(name = "Middlename")
	private String middleName;

	@Column(name = "Lastname")
	private String lastName;

	@Column(name = "Emailaddress")
	private String emailAddress;
	

	
	@Column(name = "Active")
	private boolean active;
	
	@Column(name = "createddate")
	private Date createdDate;

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "UserroleID" , insertable = false, updatable = false)
	private UserRole userRoles;

	public AppUser() {
		super();
	}
	
	public int getId() {
		return id;
	}

	
	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public int getUserroleid() {
		return userRoleID;
	}

	public void setUserroleid(int userRoleID) {
		this.userRoleID = userRoleID;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstName;
	}

	public void setFirstname(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddlename() {
		return middleName;
	}

	public void setMiddlename(String middleName) {
		this.middleName = middleName;
	}

	public String getLastname() {
		return lastName;
	}

	public void setLastname(String lastname) {
		this.lastName = lastname;
	}

	public String getEmailaddress() {
		return emailAddress;
	}

	public void setEmailaddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
	public UserRole getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(UserRole userRoles) {
		this.userRoles = userRoles;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "AppUser [id=" + id + ", username=" + username + ", userRoleID=" + userRoleID + ", password=" + password
				+ ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", emailAddress=" + emailAddress + ", active=" + active + ", createdDate="
				+ createdDate + ", createdBy=" + createdBy + ", userRoles=" + userRoles + "]";
	}


}
