package com.ode.exchange.re.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;

/**//**
 * This is an Entity Class for Calculation. Maps Calculation Table
 *
 * @author
 *
 *//*
 */
@Entity
@Table(name = "Calculation")
public class Calculation implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "CalculationID")
	private int id;

	@Column(name = "FinanceType")
	private String financeType;

	@Column(name = "CalculationName")
	private String calculationName;

	@Column(name = "CalculationJSON")
	private String calculationJSON;

	@Column(name = "Remarks")
	private String remarks;

	@Column(name = "State")
	private String state;

	@Column(name = "Lender")
	private String lender;

	@Column(name = "PreventNegativeValue")
	private Boolean preventNegativeValue;

	@Transient
	@Column(name = "createddate")
	private Date createdDate;

	@Column(name = "createdby")
	private int createdBy;

	@Column(name = "updatedby")
	private int updatedBy;

	@Column(name = "updateddate")
	private Date updatedDate;

	@PrePersist
	protected void onCreate() {
		updatedDate = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		updatedDate = new Date();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public String getCalculationName() {
		return calculationName;
	}

	public void setCalculationName(String calculationName) {
		this.calculationName = calculationName;
	}

	public String getCalculationJSON() {
		return calculationJSON;
	}

	public void setCalculationJSON(String calculationJSON) {
		this.calculationJSON = calculationJSON;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}



	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}


	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLender() {
		return lender;
	}

	public void setLender(String lender) {
		this.lender = lender;
	}

	public Boolean getPreventNegativeValue() {
		return preventNegativeValue;
	}

	public void setPreventNegativeValue(Boolean preventNegativeValue) {
		this.preventNegativeValue = preventNegativeValue;
	}

	@Override
	public String toString() {
		return "Calculation [id=" + id + ", financeType=" + financeType + ", calculationName=" + calculationName
				+ ", calculationJSON=" + calculationJSON + ", remarks=" + remarks + ",  createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", preventNegativeValue=" + preventNegativeValue + ", updatedBy="
				+ updatedBy
				+ ", updatedDate=" + updatedDate + "]";
	}

}
