package com.ode.exchange.re.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CreditDecision")
public class CreditDecision implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "CreditDecisionId")
	private int id;
	
	@Column(name = "Dmsdealerid")
	private String dmsDealerId;	
	
	@Column(name = "Lenderdealerid")
	private String lenderDealerId;	
	
	@Column(name = "Dmsdealnum")
	private String dmsDealNum;
	
	@Column(name = "Lenderid")
	private String lenderId;
	
	@Column(name = "Dedealid")
	private String deDealId;
	
	@Column(name = "Sequenceid")
	private String sequenceId;
	
	@Column(name = "R1lenderid")
	private String r1lenderId;
	
	@Column(name = "Conversationid")
	private String conversationId;
	
	@Column(name = "R1sequencenum")
	private String r1SequenceNum;
	
	@Column(name = "Statusts")
	private Timestamp statusTs;
	
	@Column(name = "SubmittedTs")	
	private Timestamp submittedTs;
	
	@Column(name = "DecisionTs")
	private Timestamp decisionTs;
	
	@Column(name = "VIN")	
	private String VIN;
	
	@Column(name = "Buyerssn")
	private String buyerSSN;
	
	@Column(name = "Buyerfirstname")
	private String buyerFirstName;
	
	@Column(name = "Buyerlastname")	
	private String buyerLastName;
	
	@Column(name = "Buyerapplicationaddressline")
	private String buyerApplicationAddressLine;
	
	@Column(name = "Buyerapplicationaddresscity")
	private String buyerApplicationAddressCity;
	
	@Column(name = "Buyerapplicationaddressstate")
	private String buyerApplicationAddressState;
	
	@Column(name = "Buyerapplicationaddresszipcode")
	private String buyerApplicationAddressZipCode;
	
	@Column(name = "Cobuyerssn")
	private String coBuyerSSN;
	
	@Column(name = "Cobuyerfirstname")
	private String cobuyerFirstName;
	
	@Column(name = "Cobuyerlastname")
	private String cobuyerLastName;
	
	@Column(name = "Cobuyerapplicationaddressline")
	private String cobuyerApplicationAddressLine;
	
	@Column(name = "Cobuyerapplicationaddresscity")
	private String cobuyerApplicationAddressCity;
	
	@Column(name = "Cobuyerapplicationaddressstate")
	private String cobuyerApplicationAddressState ;
	
	@Column(name = "Cobuyerapplicationaddresszipcode")
	private String cobuyerApplicationAddressZipcode;
	
	@Column(name = "Applicationstatus")
	private String applicationStatus;
	
	@Column(name = "Applicationnumber")
	private String applicationNumber;
	
	@Column(name = "Model")
	private String model;
	
	@Column(name = "Modelyear")
	private int modelYear;
	
	@Column(name = "Amountfinanced")
	private Double amountFinanced;
	
	@Column(name = "LTV")
	private String LTV;
	
	@Column(name = "Applicationtype")
	private String applicationType;
	
	@Column(name = "Modeldescription")
	private String modelDescription;
	
	@Column(name = "Make")
	private String make;
	
	@Column(name = "Salesclass")
	private String salesClass;
	
	@Column(name = "Certifiedpreowned")
	private boolean certifiedPreOwned;
	
	@Column(name = "Deliverymileage")
	private Double deliveryMileage ;
	
	@Column(name = "Vehiclestock")
	private String vehicleStock;
	
	@Column(name = "Bodystyle")
	private String bodyStyle;
	
	@Column(name = "Financetype")	
	private String financeType;
	
	@Column(name = "Paymentamount")	
	private Double paymentAmount;
	
	@Column(name = "Balanceamount")	
	private Double balanceAmount;
	
	@Column(name = "Residualamount")	
	private Double residualAmount;
	
	@Column(name = "Purchaseprice")	
	private Double purchasePrice;
	
	@Column(name = "Term")
	private Double term;
	
	@Column(name = "Downpaymentamount")	
	private Double downpaymentAmount;
	
	@Column(name = "ManufacturerrebateAmount")
	private Double manufacturerRebateAmount;
	
	@Column(name = "Annualpercentagerate")
	private Double annualPercentageRate;
	
	@Column(name = "Nettradeamount")
	private Double netTradeAmount;
	
	@Column(name = "Insurancetotalextendedwarrantyamount")
	private Double insuranceTotalExtendedWarrantyAmount;
	
	@Column(name = "Disabilitypremiumamount")
	private Double disabilityPremiumAmount;
	
	@Column(name = "creditlifepremiumamount")
	private Double creditLifePremiumAmount;
	
	@Column(name = "securitydepositamount")
	private Double securityDepositAmount;
	
	@Column(name = "Tier")
	private String tier;
	
	@Column(name = "Stipulations")
	private String stipulations;
	
	@Column(name = "Createdby")
	private String createdBy;
	
	@Column(name = "Modifiedby")
	private String  modifiedBy;
	
	@Column(name = "Createdts")
	private Timestamp createdTs;
	
	@Column(name = "Modifiedts")
	private Timestamp modifiedTs;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDmsDealerId() {
		return dmsDealerId;
	}
	public void setDmsDealerId(String dmsDealerId) {
		this.dmsDealerId = dmsDealerId;
	}
	public String getLenderDealerId() {
		return lenderDealerId;
	}
	public void setLenderDealerId(String lenderDealerId) {
		this.lenderDealerId = lenderDealerId;
	}
	public String getDmsDealNum() {
		return dmsDealNum;
	}
	public void setDmsDealNum(String dmsDealNum) {
		this.dmsDealNum = dmsDealNum;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}
	public String getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}
	public String getR1lenderId() {
		return r1lenderId;
	}
	public void setR1lenderId(String r1lenderId) {
		this.r1lenderId = r1lenderId;
	}
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	public String getR1SequenceNum() {
		return r1SequenceNum;
	}
	public void setR1SequenceNum(String r1SequenceNum) {
		this.r1SequenceNum = r1SequenceNum;
	}
	public Timestamp getStatusTs() {
		return statusTs;
	}
	public void setStatusTs(Timestamp statusTs) {
		this.statusTs = statusTs;
	}
	public Timestamp getSubmittedTs() {
		return submittedTs;
	}
	public void setSubmittedTs(Timestamp submittedTs) {
		this.submittedTs = submittedTs;
	}
	public Timestamp getDecisionTs() {
		return decisionTs;
	}
	public void setDecisionTs(Timestamp decisionTs) {
		this.decisionTs = decisionTs;
	}
	public String getVIN() {
		return VIN;
	}
	public void setVIN(String vIN) {
		VIN = vIN;
	}
	public String getBuyerSSN() {
		return buyerSSN;
	}
	public void setBuyerSSN(String buyerSSN) {
		this.buyerSSN = buyerSSN;
	}
	public String getBuyerFirstName() {
		return buyerFirstName;
	}
	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}
	public String getBuyerLastName() {
		return buyerLastName;
	}
	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}
	public String getBuyerApplicationAddressLine() {
		return buyerApplicationAddressLine;
	}
	public void setBuyerApplicationAddressLine(String buyerApplicationAddressLine) {
		this.buyerApplicationAddressLine = buyerApplicationAddressLine;
	}
	public String getBuyerApplicationAddressCity() {
		return buyerApplicationAddressCity;
	}
	public void setBuyerApplicationAddressCity(String buyerApplicationAddressCity) {
		this.buyerApplicationAddressCity = buyerApplicationAddressCity;
	}
	public String getBuyerApplicationAddressState() {
		return buyerApplicationAddressState;
	}
	public void setBuyerApplicationAddressState(String buyerApplicationAddressState) {
		this.buyerApplicationAddressState = buyerApplicationAddressState;
	}
	public String getBuyerApplicationAddressZipCode() {
		return buyerApplicationAddressZipCode;
	}
	public void setBuyerApplicationAddressZipCode(String buyerApplicationAddressZipCode) {
		this.buyerApplicationAddressZipCode = buyerApplicationAddressZipCode;
	}
	public String getCoBuyerSSN() {
		return coBuyerSSN;
	}
	public void setCoBuyerSSN(String coBuyerSSN) {
		this.coBuyerSSN = coBuyerSSN;
	}
	public String getCobuyerFirstName() {
		return cobuyerFirstName;
	}
	public void setCobuyerFirstName(String cobuyerFirstName) {
		this.cobuyerFirstName = cobuyerFirstName;
	}
	public String getCobuyerLastName() {
		return cobuyerLastName;
	}
	public void setCobuyerLastName(String cobuyerLastName) {
		this.cobuyerLastName = cobuyerLastName;
	}
	public String getCobuyerApplicationAddressLine() {
		return cobuyerApplicationAddressLine;
	}
	public void setCobuyerApplicationAddressLine(String cobuyerApplicationAddressLine) {
		this.cobuyerApplicationAddressLine = cobuyerApplicationAddressLine;
	}
	public String getCobuyerApplicationAddressCity() {
		return cobuyerApplicationAddressCity;
	}
	public void setCobuyerApplicationAddressCity(String cobuyerApplicationAddressCity) {
		this.cobuyerApplicationAddressCity = cobuyerApplicationAddressCity;
	}
	public String getCobuyerApplicationAddressState() {
		return cobuyerApplicationAddressState;
	}
	public void setCobuyerApplicationAddressState(String cobuyerApplicationAddressState) {
		this.cobuyerApplicationAddressState = cobuyerApplicationAddressState;
	}
	public String getCobuyerApplicationAddressZipcode() {
		return cobuyerApplicationAddressZipcode;
	}
	public void setCobuyerApplicationAddressZipcode(String cobuyerApplicationAddressZipcode) {
		this.cobuyerApplicationAddressZipcode = cobuyerApplicationAddressZipcode;
	}
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	public String getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getModelYear() {
		return modelYear;
	}
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}
	public Double getAmountFinanced() {
		return amountFinanced;
	}
	public void setAmountFinanced(Double amountFinanced) {
		this.amountFinanced = amountFinanced;
	}
	public String getLTV() {
		return LTV;
	}
	public void setLTV(String lTV) {
		LTV = lTV;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getModelDescription() {
		return modelDescription;
	}
	public void setModelDescription(String modelDescription) {
		this.modelDescription = modelDescription;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getSalesClass() {
		return salesClass;
	}
	public void setSalesClass(String salesClass) {
		this.salesClass = salesClass;
	}
	public boolean isCertifiedPreOwned() {
		return certifiedPreOwned;
	}
	public void setCertifiedPreOwned(boolean certifiedPreOwned) {
		this.certifiedPreOwned = certifiedPreOwned;
	}
	public Double getDeliveryMileage() {
		return deliveryMileage;
	}
	public void setDeliveryMileage(Double deliveryMileage) {
		this.deliveryMileage = deliveryMileage;
	}
	public String getVehicleStock() {
		return vehicleStock;
	}
	public void setVehicleStock(String vehicleStock) {
		this.vehicleStock = vehicleStock;
	}
	public String getBodyStyle() {
		return bodyStyle;
	}
	public void setBodyStyle(String bodyStyle) {
		this.bodyStyle = bodyStyle;
	}
	public String getFinanceType() {
		return financeType;
	}
	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}
	public Double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public Double getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	public Double getResidualAmount() {
		return residualAmount;
	}
	public void setResidualAmount(Double residualAmount) {
		this.residualAmount = residualAmount;
	}
	public Double getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(Double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public Double getTerm() {
		return term;
	}
	public void setTerm(Double term) {
		this.term = term;
	}
	public Double getDownpaymentAmount() {
		return downpaymentAmount;
	}
	public void setDownpaymentAmount(Double downpaymentAmount) {
		this.downpaymentAmount = downpaymentAmount;
	}
	public Double getManufacturerRebateAmount() {
		return manufacturerRebateAmount;
	}
	public void setManufacturerRebateAmount(Double manufacturerRebateAmount) {
		this.manufacturerRebateAmount = manufacturerRebateAmount;
	}
	public Double getAnnualPercentageRate() {
		return annualPercentageRate;
	}
	public void setAnnualPercentageRate(Double annualPercentageRate) {
		this.annualPercentageRate = annualPercentageRate;
	}
	public Double getNetTradeAmount() {
		return netTradeAmount;
	}
	public void setNetTradeAmount(Double netTradeAmount) {
		this.netTradeAmount = netTradeAmount;
	}
	public Double getInsuranceTotalExtendedWarrantyAmount() {
		return insuranceTotalExtendedWarrantyAmount;
	}
	public void setInsuranceTotalExtendedWarrantyAmount(Double insuranceTotalExtendedWarrantyAmount) {
		this.insuranceTotalExtendedWarrantyAmount = insuranceTotalExtendedWarrantyAmount;
	}
	public Double getDisabilityPremiumAmount() {
		return disabilityPremiumAmount;
	}
	public void setDisabilityPremiumAmount(Double disabilityPremiumAmount) {
		this.disabilityPremiumAmount = disabilityPremiumAmount;
	}
	public Double getCreditLifePremiumAmount() {
		return creditLifePremiumAmount;
	}
	public void setCreditLifePremiumAmount(Double creditLifePremiumAmount) {
		this.creditLifePremiumAmount = creditLifePremiumAmount;
	}
	public Double getSecurityDepositAmount() {
		return securityDepositAmount;
	}
	public void setSecurityDepositAmount(Double securityDepositAmount) {
		this.securityDepositAmount = securityDepositAmount;
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getStipulations() {
		return stipulations;
	}
	public void setStipulations(String stipulations) {
		this.stipulations = stipulations;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}
	public Timestamp getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	@Override
	public String toString() {
		return "CreditDecision [id=" + id + ", dmsDealerId=" + dmsDealerId + ", lenderDealerId=" + lenderDealerId
				+ ", dmsDealNum=" + dmsDealNum + ", lenderId=" + lenderId + ", deDealId=" + deDealId + ", sequenceId="
				+ sequenceId + ", r1lenderId=" + r1lenderId + ", conversationId=" + conversationId + ", r1SequenceNum="
				+ r1SequenceNum + ", statusTs=" + statusTs + ", submittedTs=" + submittedTs + ", decisionTs="
				+ decisionTs + ", VIN=" + VIN + ", buyerSSN=" + buyerSSN + ", buyerFirstName=" + buyerFirstName
				+ ", buyerLastName=" + buyerLastName + ", buyerApplicationtAddressLine=" + buyerApplicationAddressLine
				+ ", buyerApplicationtAddressCity=" + buyerApplicationAddressCity + ", buyerApplicationtAddressState="
				+ buyerApplicationAddressState + ", buyerApplicationtAddressZipCode=" + buyerApplicationAddressZipCode
				+ ", coBuyerSSN=" + coBuyerSSN + ", cobuyerFirstName=" + cobuyerFirstName + ", cobuyerLastName="
				+ cobuyerLastName + ", cobuyerApplicationtAddressLine=" + cobuyerApplicationAddressLine
				+ ", cobuyerApplicationtAddressCity=" + cobuyerApplicationAddressCity
				+ ", cobuyerApplicationtAddressState=" + cobuyerApplicationAddressState
				+ ", cobuyerApplicationtAddressZipcode=" + cobuyerApplicationAddressZipcode + ", applicationStatus="
				+ applicationStatus + ", applicationNumber=" + applicationNumber + ", model=" + model + ", modelYear="
				+ modelYear + ", amountFinanced=" + amountFinanced + ", LTV=" + LTV + ", applicationType="
				+ applicationType + ", modelDescription=" + modelDescription + ", make=" + make + ", salesClass="
				+ salesClass + ", certifiedPreOwned=" + certifiedPreOwned + ", deliveryMileage=" + deliveryMileage
				+ ", vehicleStock=" + vehicleStock + ", bodyStyle=" + bodyStyle + ", financeType=" + financeType
				+ ", paymentAmount=" + paymentAmount + ", balanceAmount=" + balanceAmount + ", residualAmount="
				+ residualAmount + ", purchasePrice=" + purchasePrice + ", term=" + term + ", downpaymentAmount="
				+ downpaymentAmount + ", manufacturerRebateAmount=" + manufacturerRebateAmount
				+ ", annualPercentageRate=" + annualPercentageRate + ", netTradeAmount=" + netTradeAmount
				+ ", insuranceTotalExtendedWarrantyAmount=" + insuranceTotalExtendedWarrantyAmount
				+ ", disabilityPremiumAmount=" + disabilityPremiumAmount + ", creditLifePremiumAmount="
				+ creditLifePremiumAmount + ", securityDepositAmount=" + securityDepositAmount + ", tier=" + tier
				+ ", stipulations=" + stipulations + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy
				+ ", createdTs=" + createdTs + ", modifiedTs=" + modifiedTs + "]";
	}

	
	
	
}
