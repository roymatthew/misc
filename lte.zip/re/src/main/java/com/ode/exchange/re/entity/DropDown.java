package com.ode.exchange.re.entity;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.PrePersist;
import javax.persistence.Table;


/**
 * This is an Entity Class for DropDown. Maps DropDown Table
 * 
 * @author 
 *
 */

@Entity
@Table(name = "Dropdown")
public class DropDown implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "DDID")
	private int id;

	@Column(name = "Fieldnameid")
	private int fieldNameID;

	@Column(name = "Value")
	private String value;

	@Column(name = "Code")
	private String code;

	@Column(name = "Sortorder")
	private int sortOrder;

	@Column(name = "Displayfield")
	private char displayField;

	@Column(name = "Status")
	private boolean status;

	@Column(name = "createddate")
	private Date createdDate;
	

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;

	public DropDown() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFieldNameID() {
		return fieldNameID;
	}

	public void setFieldNameID(int fieldNameID) {
		this.fieldNameID = fieldNameID;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	public char getDisplayField() {
		return displayField;
	}

	public void setDisplayField(char displayField) {
		this.displayField = displayField;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "DropDown [id=" + id + ",  value=" + value + ", code=" + code + ", sortOrder=" + sortOrder
				+ ", displayField=" + displayField + ", status=" + status + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", fieldNameID=" + fieldNameID + "]";
	}

}
