package com.ode.exchange.re.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ctennant
 *
 */
@Entity
@Table(name = "ETLConfiguration")
public class ETL implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FieldID", unique = true, nullable = false)
	private int id;

	@Column(name = "REUsage")
	private boolean reUsage;

	@Column(name = "LookupUsage")
	private boolean lookupUsage;

	@Column(name = "AliasFieldName")
	private String aliasFieldName;

	@Column(name = "FieldName")
	private String FieldName;

	@Column(name = "DataType")
	private String dataType;

	@Column(name = "XPath")
	private String xPath;

	@Column(name = "Repeatable")
	private boolean repeatable;

	@Column(name = "Currency")
	private boolean currency;

	@Column(name = "XpathOrder")
	private int xpathOrder;

	public boolean isReUsage() {
		return reUsage;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public String getAliasFieldName() {
		return aliasFieldName;
	}

	public String getDataType() {
		return dataType;
	}

	public String getxPath() {
		return xPath;
	}

	public String getFieldName() {
		return FieldName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setReUsage(boolean reUsage) {
		this.reUsage = reUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}

	public void setAliasFieldName(String aliasFieldName) {
		this.aliasFieldName = aliasFieldName;
	}

	public void setFieldName(String fieldName) {
		FieldName = fieldName;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}

	public boolean isRepeatable() {
		return repeatable;
	}

	public void setRepeatable(boolean repeatable) {
		this.repeatable = repeatable;
	}

	public boolean isCurrency() {
		return currency;
	}

	public void setCurrency(boolean currency) {
		this.currency = currency;
	}

	public int getXpathOrder() {
		return xpathOrder;
	}

	public void setXpathOrder(int xpathOrder) {
		this.xpathOrder = xpathOrder;
	}

	public ETL() {
		super();
	}

}