package com.ode.exchange.re.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ETLConfiguration")
public class ETLConfiguration implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = -7060934938098458552L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FieldID", unique = true, nullable = false)
	private int id;

	@Column(name = "REUsage")
	private boolean reUsage;

	@Column(name = "LookupUsage")
	private boolean lookupUsage;

	@Column(name = "AliasFieldName")
	private String aliasFieldName;

	@Column(name = "DataType")
	private String dataType;

	@Column(name = "XPath")
	private String xPath;

	@Column(name = "Repeatable")
	private Boolean repeatable;

	@Column(name = "Currency")
	private Boolean currency;

	@Column(name = "XpathOrder")
	private Integer xpathOrder;

	public boolean isReUsage() {
		return reUsage;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public String getAliasFieldName() {
		return aliasFieldName;
	}

	public String getDataType() {
		return dataType;
	}

	public String getxPath() {
		return xPath;
	}

	public Boolean getRepeatable() {
		return repeatable;
	}

	public void setRepeatable(Boolean repeatable) {
		repeatable = repeatable;
	}

	public ETLConfiguration() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		id = id;
	}

	public Boolean getCurrency() {
		return currency;
	}

	public void setCurrency(Boolean currency) {
		currency = currency;
	}


	public Integer getXpathOrder() {
		return xpathOrder;
	}

	public void setXpathOrder(Integer xpathOrder) {
		xpathOrder = xpathOrder;
	}


}
