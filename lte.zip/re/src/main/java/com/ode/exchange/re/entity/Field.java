package com.ode.exchange.re.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is an Entity Class for Field. Maps FieldName Table
 * 
 * @author 
 *
 */

@Entity
@Table(name = "Fieldname")
public class Field implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@Column(name = "Fieldnameid")
	private int id;

	@Column(name = "Fieldname")
	private String fieldName;

	@Column(name = "Datatype")
	private String datatype;
	
	@Column(name = "Lookupusage")
	private boolean lookupUsage;

	public Field() {
		super();

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}

	@Override
	public String toString() {
		return "Field [id=" + id + ", fieldName=" + fieldName + ", datatype=" + datatype + ", lookupUsage="
				+ lookupUsage + "]";
	}

	
}
