package com.ode.exchange.re.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This is an Entity Class for FieldName. Maps FieldName Table and DropDown Table
 * 
 * @author 
 *
 */

@Entity
@Table(name = "ETLConfiguration")
public class FieldName implements java.io.Serializable  {
	private static final long serialVersionUID = 4910225916550731448L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FieldID", unique = true, nullable = false)
	private int id;

	@Column(name = "REUsage")
	private boolean reUsage;

	@Column(name = "LookupUsage")
	private boolean lookupUsage;

	@Column(name = "AliasFieldName")
	private String aliasFieldName;	

	@Column(name = "DataType")
	private String dataType;

	@Column(name = "XPath")
	private String xPath;
	
	@Column(name = "Repeatable")
	private Boolean repeatable;
		
	@OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.MERGE)
	@JoinColumn(name = "Fieldnameid" )
	private List<DropDown> dropDownlist;
	
	public FieldName() {
		super();
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public List<DropDown> getDropDownlist() {
		return dropDownlist;
	}

	public void setDropDownlist(List<DropDown> dropDownlist) {
		this.dropDownlist = dropDownlist;
	}

	public boolean isReUsage() {
		return reUsage;
	}

	public void setReUsage(boolean reUsage) {
		this.reUsage = reUsage;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}

	public String getAliasFieldName() {
		return aliasFieldName;
	}

	public void setAliasFieldName(String aliasFieldName) {
		this.aliasFieldName = aliasFieldName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}

	public Boolean getRepeatable() {
		return repeatable;
	}

	public void setRepeatable(Boolean repeatable) {
		this.repeatable = repeatable;
	}
	




}
