package com.ode.exchange.re.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is an Entity Class for Functionality. Maps Functionality Table
 * 
 * @author 
 *
 */

@Entity
@Table(name = "Functionality")
public class Functionality implements java.io.Serializable {
	
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@Column(name = "Funtionalityid")
	private int id;

	@Column(name = "Funtionalityname")
	private String functionalityName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFunctionalityName() {
		return functionalityName;
	}

	public void setFunctionalityName(String functionalityName) {
		this.functionalityName = functionalityName;
	}

	@Override
	public String toString() {
		return "Functionality [id=" + id + ", functionalityName=" + functionalityName + "]";
	}



	
	

}
