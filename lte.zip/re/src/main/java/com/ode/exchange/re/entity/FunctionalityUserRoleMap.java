package com.ode.exchange.re.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 * This is an Entity Class for FunctionalityUserRoleMap. Maps FunctionalityUserRoleMapping Table
 * 
 * @author 
 *
 */
@Entity
@Table(name = "Functionalityuserrolemapping")
public class FunctionalityUserRoleMap {	
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@Column(name = "FUMID")
	private int id;

	@Column(name = "funtionalityid")
	private int funtionalityid;
	
	@Column(name = "Userroleid")
	private int userroleID;

	@Column(name = "createddate")
	private Date createdDate;	
	
	@Column(name = "PrivilegeView")
	private boolean privilegeView;
	
	@Column(name = "PrivilegeEdit")
	private boolean privilegeEdit;
	
	
	public boolean isPrivilegeView() {
		return privilegeView;
	}

	public void setPrivilegeView(boolean privilegeView) {
		this.privilegeView = privilegeView;
	}

	public boolean isPrivilegeEdit() {
		return privilegeEdit;
	}

	public void setPrivilegeEdit(boolean privilegeEdit) {
		this.privilegeEdit = privilegeEdit;
	}

	
	
		
	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFuntionalityid() {
		return funtionalityid;
	}

	public void setFuntionalityid(int funtionalityid) {
		this.funtionalityid = funtionalityid;
	}

	public int getUserroleID() {
		return userroleID;
	}

	public void setUserroleID(int userroleID) {
		this.userroleID = userroleID;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "FunctionalityUserRoleMap [id=" + id + ", funtionalityid=" + funtionalityid + ", userroleID="
				+ userroleID + ", createdDate=" + createdDate + ", privilegeView=" + privilegeView + ", privilegeEdit="
				+ privilegeEdit + "]";
	}

	
	

}