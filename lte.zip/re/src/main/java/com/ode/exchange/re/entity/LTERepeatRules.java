package com.ode.exchange.re.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LTERepeatRules")
public class LTERepeatRules implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 3270928370788675848L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;

	@Column(name = "Destination")
	private String destination;

	@Column(name = "LookupCriteria")
	private String lookupCriteria;

	@Column(name = "EtlSourceAlias")
	private String etlSourceAlias;

	@Column(name = "EtlTargetAlias")
	private String etlTargetAlias;

	@Column(name = "Operator")
	private String operator;

	@Column(name = "TranslationValue")
	private String translationValue;

	@Column(name = "CalculatedValue")
	private boolean calculatedValue;

	@Column(name = "Lender")
	private String lender;

	@Column(name = "RuleOrder")
	private int ruleOrder;

	@Column(name = "RuleName")
	private String ruleName;

	@Column(name = "Remarks")
	private String remarks;

	@Column(name = "Status")
	private String status;

	@Column(name = "CreatedBy")
	private String createdBy;

	@Column(name = "CreatedDate")
	private String createdDate;

	public LTERepeatRules() {

	}

	public int getId() {
		return id;
	}

	public String getDestination() {
		return destination;
	}

	public String getLookupCriteria() {
		return lookupCriteria;
	}

	public String getEtlSourceAlias() {
		return etlSourceAlias;
	}

	public String getEtlTargetAlias() {
		return etlTargetAlias;
	}

	public String getOperator() {
		return operator;
	}

	public String getTranslationValue() {
		return translationValue;
	}

	public boolean isCalculatedValue() {
		return calculatedValue;
	}

	public String getLender() {
		return lender;
	}

	public int getRuleOrder() {
		return ruleOrder;
	}

	public String getRuleName() {
		return ruleName;
	}

	public String getRemarks() {
		return remarks;
	}

	public String getStatus() {
		return status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setLookupCriteria(String lookupCriteria) {
		this.lookupCriteria = lookupCriteria;
	}

	public void setEtlSourceAlias(String etlSourceAlias) {
		this.etlSourceAlias = etlSourceAlias;
	}

	public void setEtlTargetAlias(String etlTargetAlias) {
		this.etlTargetAlias = etlTargetAlias;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public void setTranslationValue(String translationValue) {
		this.translationValue = translationValue;
	}

	public void setCalculatedValue(boolean calculatedValue) {
		this.calculatedValue = calculatedValue;
	}

	public void setLender(String lender) {
		this.lender = lender;
	}

	public void setRuleOrder(int ruleOrder) {
		this.ruleOrder = ruleOrder;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "LTERepeatRules [id=" + id + ", destination=" + destination + ", lookupCriteria=" + lookupCriteria
				+ ", etlSourceAlias=" + etlSourceAlias + ", etlTargetAlias=" + etlTargetAlias + ", operator=" + operator
				+ ", translationValue=" + translationValue + ", calculatedValue=" + calculatedValue + ", lender="
				+ lender + ", ruleOrder=" + ruleOrder + ", ruleName=" + ruleName + ", remarks=" + remarks + ", status="
				+ status + ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}

}
