package com.ode.exchange.re.entity;

import java.util.List;

public class LookUpCriteriaPassRules {
	List<StringentRuleQualification> stringentQualifyRuleList;
	List<Rule> masterPassedMap;

	public LookUpCriteriaPassRules() {
		super();
	}

	public List<StringentRuleQualification> getStringentQualifyRuleList() {
		return stringentQualifyRuleList;
	}

	public void setStringentQualifuRuleList(List<StringentRuleQualification> stringentQualifyRuleList) {
		this.stringentQualifyRuleList = stringentQualifyRuleList;
	}

	public List<Rule> getMasterPassedMap() {
		return masterPassedMap;
	}

	public void setMasterPassedMap(List<Rule> masterPassedMap) {
		this.masterPassedMap = masterPassedMap;
	}

	@Override
	public String toString() {
		return "LookUpCriteriaPassRules [stringentQualifuRuleList=" + stringentQualifyRuleList + ", masterPassedMap="
				+ masterPassedMap + "]";
	}

}
