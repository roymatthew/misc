package com.ode.exchange.re.entity;

import java.util.Arrays;

public class MapperResult {
	private boolean proceed;
	RegulationRuleLogicExpression[] ruleExpression;
	
	public boolean isProceed() {
		return proceed;
	}
	
	public void setProceed(boolean proceed) {
		this.proceed = proceed;
	}
	
	public RegulationRuleLogicExpression[] getRuleExpression() {
		return ruleExpression;
	}
	
	public void setRuleExpression(RegulationRuleLogicExpression[] ruleExpression) {
		this.ruleExpression = ruleExpression;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (proceed ? 1231 : 1237);
		result = prime * result + Arrays.hashCode(ruleExpression);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MapperResult other = (MapperResult) obj;
		if (proceed != other.proceed)
			return false;
		if (!Arrays.equals(ruleExpression, other.ruleExpression))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "MapperResult [proceed=" + proceed + ", ruleExpression=" + Arrays.toString(ruleExpression) + "]";
	}
}
