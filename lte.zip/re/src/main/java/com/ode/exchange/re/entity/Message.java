package com.ode.exchange.re.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;



/**
 * This is an Entity Class for Message.  Maps Message, MessageType and RuleClassification Table
 * 
 * @author 
 *
 */

@Entity
@Table(name = "Message")
public class Message implements java.io.Serializable {
	
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "Messageid")
	private int id;

	@OneToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "Messagetypeid")
	private MessageType messageType;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "RCID")
	private RuleClassification ruleClassification;

	@Column(name = "Message")
	private String Message;

	@Column(name = "Messagename")
	private String messageName;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "status")
	private boolean status;
	
	@Column(name = "Reasoncode")
	private int reasonCode;

	@Column(name = "createddate")
	private Date createdDate;
	

	public int getReasonCode() {
		return reasonCode;
	}


	public void setReasonCode(int reasonCode) {
		this.reasonCode = reasonCode;
	}


	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;	

	public Message() {
		super();
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public MessageType getMessageType() {
		return messageType;
	}

	public void setMessageType(MessageType messageType) {
		this.messageType = messageType;
	}

	public RuleClassification getRuleClassification() {
		return ruleClassification;
	}

	public void setRuleClassification(RuleClassification ruleClassification) {
		this.ruleClassification = ruleClassification;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		this.Message = message;
	}

	public String getMessageName() {
		return messageName;
	}

	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	
	
	

}
