package com.ode.exchange.re.entity;

import java.sql.Timestamp;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is an Entity Class for MessageType.  Has PASS and FAIL Values
 * 
 * @author 
 *
 */

@Entity
@Table(name = "Messagetype") 
public class MessageType  implements java.io.Serializable{
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "MessagetypeID")
	private int id;
	
	@Column(name = "Messagetype")
	private String messageType;
	
	@Column(name = "remarks")
	private String remarks;
	
	@Column(name = "status")
	private boolean status;	
	
	
	@Column(name = "createddate")	
	private Timestamp createdDate;
	
	@Column(name = "createdby")	
	private int createdBy;


	public MessageType() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "MessageType [id=" + id + ", messageType=" + messageType + ", remarks=" + remarks + ", status=" + status
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
	}
	
	
	
}
