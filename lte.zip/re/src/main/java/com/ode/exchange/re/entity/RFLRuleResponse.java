package com.ode.exchange.re.entity;

import java.util.List;

/**
 * This is an Entity Class for RFLRuleResponse.
 * 
 * @author
 *
 */

public class RFLRuleResponse {

	private String passedRFLs;

	public String getPassedRFLs() {
		return passedRFLs;
	}

	public void setPassedRFLs(String passedRFLs) {
		this.passedRFLs = passedRFLs;
	}

	@Override
	public String toString() {
		return "RFLRuleResponse [passedRFLs=" + passedRFLs + "]";
	}
	
	

}
