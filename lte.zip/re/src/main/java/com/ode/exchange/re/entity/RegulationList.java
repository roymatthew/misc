package com.ode.exchange.re.entity;

import java.util.List;

public class RegulationList {
	private List<RegulationRuleLogicExpression> regulation;

	public List<RegulationRuleLogicExpression> getRegulation() {
		return regulation;
	}

	public void setRegulation(List<RegulationRuleLogicExpression> regulation) {
		this.regulation = regulation;
	}

	public RegulationList(List<RegulationRuleLogicExpression> regulation) {
		super();
		this.regulation = regulation;
	}
	
}
