package com.ode.exchange.re.entity;

import java.util.List;

/**
 * This is an Entity Class for RuleLogicExpression. Used for Regulation Rule and
 * RFL
 * 
 * @author
 *
 */

public class RegulationRuleLogicExpression {

	public enum ExpressionType {
		FIELD, OPERATOR, VALUE, FIELDROLLUP, NODE, NODESET, ROLLUPSOURCE, ROLLUPTARGET

	}

	protected String value;
	protected ExpressionType expressionType;
	protected String fieldExpressionPrefix;
	protected RollupInfo tagValue;
	/*one or many RollupSource, only set for ExpressionType.ROLLUPSOURCE*/
	protected List<RollupSource> rollupSources;
	/*one RollupTarget, only set for ExpressionType.ROLLUPTARGET*/
	protected RollupTarget rollupTarget; 
	
	public RollupInfo getTagValue() {
		return tagValue;
	}
	
	public void setTagValue(RollupInfo tagValue) {
		this.tagValue = tagValue;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public ExpressionType getExpressionType() {
		return expressionType;
	}
	
	public void setExpressionType(ExpressionType expressionType) {
		this.expressionType = expressionType;
	}
	
	public RegulationRuleLogicExpression() {
		super();
	}
	
	public RegulationRuleLogicExpression( String value, ExpressionType expressionType) {
		super();
		this.value = value;
		this.expressionType = expressionType;
	}
	
	public String getFieldExpressionPrefix() {
		return fieldExpressionPrefix;
	}
	
	public void setFieldExpressionPrefix(String fieldExpressionPrefix) {
		this.fieldExpressionPrefix = fieldExpressionPrefix;
	}	
	
	public List<RollupSource> getRollupSources() {
		return rollupSources;
	}

	public RollupTarget getRollupTarget() {
		return rollupTarget;
	}

	public void setRollupSources(List<RollupSource> rollupSources) {
		this.rollupSources = rollupSources;
	}

	public void setRollupTarget(RollupTarget rollupTarget) {
		this.rollupTarget = rollupTarget;
	}

	public RegulationRuleLogicExpression(String value, ExpressionType expressionType, String fieldExpressionPrefix) {
		super();
		this.value = value;
		this.expressionType = expressionType;
		this.fieldExpressionPrefix = fieldExpressionPrefix;
	}
	
	public RegulationRuleLogicExpression( ExpressionType expressionType, String fieldExpressionPrefix) {
		super();
		this.value = value;
		this.expressionType = expressionType;
		this.fieldExpressionPrefix = fieldExpressionPrefix;
	}
}
