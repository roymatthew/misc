package com.ode.exchange.re.entity;

/**
 * This is an Entity Class for RequiredFieldRule.
 * 
 * @author
 *
 */

public class RequiredFieldRule {

	private Rule rule;
	private ProcessAudit processAudit;

	public Rule getRule() {
		return rule;
	}

	public void setRule(Rule rule) {
		this.rule = rule;
	}

	public ProcessAudit getProcessAudit() {
		return processAudit;
	}

	public void setProcessAudit(ProcessAudit processAudit) {
		this.processAudit = processAudit;
	}

	@Override
	public String toString() {
		return "RequiredFieldRule [rule=" + rule + ", processAudit=" + processAudit + "]";
	}

}
