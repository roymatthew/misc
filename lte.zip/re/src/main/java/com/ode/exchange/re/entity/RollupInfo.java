package com.ode.exchange.re.entity;

import java.util.List;

public class RollupInfo {
	private String rollupTag;
	private List<Tag> staticTags;
	
	public String getRollupTag() {
		return rollupTag;
	}
	
	public void setRollupTag(String rollupTag) {
		this.rollupTag = rollupTag;
	}
	
	public List<Tag> getStaticTags() {
		return staticTags;
	}
	
	public void setStaticTags(List<Tag> staticTags) {
		this.staticTags = staticTags;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rollupTag == null) ? 0 : rollupTag.hashCode());
		result = prime * result + ((staticTags == null) ? 0 : staticTags.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RollupInfo other = (RollupInfo) obj;
		if (rollupTag == null) {
			if (other.rollupTag != null)
				return false;
		} else if (!rollupTag.equals(other.rollupTag))
			return false;
		if (staticTags == null) {
			if (other.staticTags != null)
				return false;
		} else if (!staticTags.equals(other.staticTags))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RollupInfo [rollupTag=" + rollupTag
				+ ", staticTags=" + staticTags + "]";
	}
}
