/**
 * 
 */
package com.ode.exchange.re.entity;

/**
 * @author rmathew
 *
 */
public class RollupMapping {
	/**
	 * ExpressionType.FIELD
	 */
	private RegulationRuleLogicExpression source; 
	/**
	 * ExpressionType.FIELD
	 */
	private RegulationRuleLogicExpression target;
	public RegulationRuleLogicExpression getSource() {
		return source;
	}
	public RegulationRuleLogicExpression getTarget() {
		return target;
	}
	public void setSource(RegulationRuleLogicExpression source) {
		this.source = source;
	}
	public void setTarget(RegulationRuleLogicExpression target) {
		this.target = target;
	}	

}
