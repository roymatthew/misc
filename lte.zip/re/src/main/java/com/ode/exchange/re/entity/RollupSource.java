/**
 * 
 */
package com.ode.exchange.re.entity;

import java.util.List;

/**
 * @author rmathew
 *
 */
public class RollupSource {
	
	/**
	 * one ExpressionType.NODESET OR one or many ExpressionType.NODE
	 */
	private List<RegulationRuleLogicExpression> rollupSourceNodes;
	/**
	 * conditional logic expression made up of ExpressionType.FIELD, ExpressionType.OPERATOR, and ExpressionType.VALUE
	 */
	private List<RegulationRuleLogicExpression> rollupConditionalLogic; // 
	/**
	 * pairs of ExpressionType.FIELD
	 */
	private List<RollupMapping> rollupMapping;
	public List<RegulationRuleLogicExpression> getRollupSourceNodes() {
		return rollupSourceNodes;
	}
	public List<RegulationRuleLogicExpression> getRollupConditionalLogic() {
		return rollupConditionalLogic;
	}
	public List<RollupMapping> getRollupMapping() {
		return rollupMapping;
	}
	public void setRollupSourceNodes(List<RegulationRuleLogicExpression> rollupSourceNodes) {
		this.rollupSourceNodes = rollupSourceNodes;
	}
	public void setRollupConditionalLogic(List<RegulationRuleLogicExpression> rollupConditionalLogic) {
		this.rollupConditionalLogic = rollupConditionalLogic;
	}
	public void setRollupMapping(List<RollupMapping> rollupMapping) {
		this.rollupMapping = rollupMapping;
	} 
	
	

}
