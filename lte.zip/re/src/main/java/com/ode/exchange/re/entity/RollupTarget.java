/**
 * 
 */
package com.ode.exchange.re.entity;

import java.util.List;

/**
 * @author rmathew
 *
 */
public class RollupTarget {
	
	/**
	 * name of target NODESET (e.g. "Fee" or "Tax")
	 */
	private String rollupTargetNode; 
	/**
	 * name-value pairs
	 */
	private List<Tag> staticTags;
	public String getRollupTargetNode() {
		return rollupTargetNode;
	}
	public List<Tag> getStaticTags() {
		return staticTags;
	}
	public void setRollupTargetNode(String rollupTargetNode) {
		this.rollupTargetNode = rollupTargetNode;
	}
	public void setStaticTags(List<Tag> staticTags) {
		this.staticTags = staticTags;
	}	

}
