package com.ode.exchange.re.entity;

import java.sql.Timestamp;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;


/**
 * This is an Entity Class for Rule. Maps Rule , RuleClassification , RuleType ,
 * RuleSubtype , Message Table
 * 
 * @author
 *
 */

@Entity
@Table(name = "\"RULE\"")
public class Rule implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "ruleid")
	private int id;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "rcid")
	private RuleClassification ruleClassification;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "RuletypeID",nullable=true)
	private RuleType ruleType;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "RulesubtypeID",nullable=true)
	private RuleSubtype ruleSubtype;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "PassmessageID", nullable=true)
	private Message passmessage;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "FailmessageID",nullable=true)
	private Message failmessage;

	@Column(name = "rulename")
	private String ruleName;

	@Column(name = "lookupcriteria")
	private String lookupCriteria;

	/*@Column(name = "requiredfields")
	private String requiredFields;

	@Column(name = "fixedfieldvalues")
	private String fixedFieldValues;*/

	@Column(name = "rulelogic")
	private String ruleLogic;

	@Column(name = "passrulevalue")
	private String passRuleValue;
	
	@Column(name = "failrulevalue")
	private String failRuleValue;

	@Column(name = "effectivedate")
	private Timestamp effectiveDate;

	@Column(name = "expirationdate")
	private Timestamp expirationDate;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "status")
	private char status;

	@Column(name = "createddate")
	private Date createdDate;

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;

	public Rule() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public RuleClassification getRuleClassification() {
		return ruleClassification;
	}

	public void setRuleClassification(RuleClassification ruleClassification) {
		this.ruleClassification = ruleClassification;
	}

	public RuleType getRuleType() {
		return ruleType;
	}

	public void setRuleType(RuleType ruleType) {
		this.ruleType = ruleType;
	}

	public RuleSubtype getRuleSubtype() {
		return ruleSubtype;
	}

	public void setRuleSubtype(RuleSubtype ruleSubtype) {
		this.ruleSubtype = ruleSubtype;
	}

	public Message getPassmessage() {
		return passmessage;
	}

	public void setPassmessage(Message passmessage) {
		this.passmessage = passmessage;
	}

	public Message getFailmessage() {
		return failmessage;
	}

	public void setFailmessage(Message failmessage) {
		this.failmessage = failmessage;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getLookupCriteria() {
		return lookupCriteria;
	}

	public void setLookupCriteria(String lookupCriteria) {
		this.lookupCriteria = lookupCriteria;
	}

/*	public String getRequiredFields() {
		return requiredFields;
	}

	public void setRequiredFields(String requiredFields) {
		this.requiredFields = requiredFields;
	}

	public String getFixedFieldValues() {
		return fixedFieldValues;
	}

	public void setFixedFieldValues(String fixedFieldValues) {
		this.fixedFieldValues = fixedFieldValues;
	}*/

	public String getRuleLogic() {
		return ruleLogic;
	}

	public void setRuleLogic(String ruleLogic) {
		this.ruleLogic = ruleLogic;
	}

	public Timestamp getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Timestamp effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Timestamp getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Timestamp expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public String getPassRuleValue() {
		return passRuleValue;
	}

	public void setPassRuleValue(String passRuleValue) {
		this.passRuleValue = passRuleValue;
	}

	public String getFailRuleValue() {
		return failRuleValue;
	}

	public void setFailRuleValue(String failRuleValue) {
		this.failRuleValue = failRuleValue;
	}

	@Override
	public String toString() {
		return "Rule [id=" + id + ", ruleClassification=" + ruleClassification + ", ruleType=" + ruleType
				+ ", ruleSubtype=" + ruleSubtype + ", passmessage=" + passmessage + ", failmessage=" + failmessage
				+ ", ruleName=" + ruleName + ", lookupCriteria=" + lookupCriteria + ", ruleLogic=" + ruleLogic
				+ ", passRuleValue=" + passRuleValue + ", failRuleValue=" + failRuleValue + ", effectiveDate="
				+ effectiveDate + ", expirationDate=" + expirationDate + ", remarks=" + remarks + ", status=" + status
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
	}

	


}
