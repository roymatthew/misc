package com.ode.exchange.re.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 * This is an Entity Class for RuleAudit. Maps RuleAudit Table
 * 
 * @author
 *
 */

@Entity
@Table(name = "Ruleaudit")
public class RuleAudit implements java.io.Serializable {

	private static final long serialVersionUID = 4910225916550731448L;


	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "Ruleauditid")
	private int id;

	@Column(name = "Xmlid")
	private long xmlId;

	@Column(name = "Rcid")
	private int rcid;

	@Column(name = "Lookupcriteria")
	private String lookupCriteria;

	/*@Column(name = "Fixedfieldscriteria")
	private String fixedFieldsCriteria;

	@Column(name = "Requiredfieldscriteria")
	private String requiredFieldsCriteria;*/

	@Column(name = "Rulelogic")
	private String rulelogic;

	@Column(name = "Ruleexecutionresult")
	private String ruleExecutionResult;

	@Column(name = "Messageresponse")
	private String messageResponse;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "Ruleid")
	private Rule rule;

	@Column(name = "createddate")
	private Date createdDate;

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	public RuleAudit() {
		super();
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getXmlId() {
		return xmlId;
	}

	public void setXmlId(long xmlId) {
		this.xmlId = xmlId;
	}

	public int getRcid() {
		return rcid;
	}

	public void setRcid(int rcid) {
		this.rcid = rcid;
	}

	public String getLookupCriteria() {
		return lookupCriteria;
	}

	public void setLookupCriteria(String lookupCriteria) {
		this.lookupCriteria = lookupCriteria;
	}

	/*public String getFixedFieldsCriteria() {
		return fixedFieldsCriteria;
	}

	public void setFixedFieldsCriteria(String fixedFieldsCriteria) {
		this.fixedFieldsCriteria = fixedFieldsCriteria;
	}

	public String getRequiredFieldsCriteria() {
		return requiredFieldsCriteria;
	}

	public void setRequiredFieldsCriteria(String requiredFieldsCriteria) {
		this.requiredFieldsCriteria = requiredFieldsCriteria;
	}
*/
	public String getRulelogic() {
		return rulelogic;
	}

	public void setRulelogic(String rulelogic) {
		this.rulelogic = rulelogic;
	}

	public String getRuleExecutionResult() {
		return ruleExecutionResult;
	}

	public void setRuleExecutionResult(String ruleExecutionResult) {
		this.ruleExecutionResult = ruleExecutionResult;
	}

	public String getMessageResponse() {
		return messageResponse;
	}

	public void setMessageResponse(String messageResponse) {
		this.messageResponse = messageResponse;
	}

	public Rule getRule() {
		return rule;
	}

	public void setRule(Rule rule) {
		this.rule = rule;
	}

	@Override
	public String toString() {
		return "RuleAudit [id=" + id + ", xmlId=" + xmlId + ", rcid=" + rcid + ", lookupCriteria=" + lookupCriteria
				+  ", rulelogic=" + rulelogic + ", ruleExecutionResult=" + ruleExecutionResult + ", messageResponse="
				+ messageResponse + "]";
	}

}
