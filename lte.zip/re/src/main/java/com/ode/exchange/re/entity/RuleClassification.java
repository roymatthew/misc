package com.ode.exchange.re.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * This is an Entity Class for RuleClassification. Maps RuleClassification Table
 * 
 * @author
 *
 */

@Entity
@JsonIgnoreProperties({ "createddate" })
@Table(name = "Ruleclassification")
public class RuleClassification implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "RCID")
	private int id;

	@Column(name = "RCName")
	private String rcName;
	
	// Removed in Phase 2  
	/*@Column(name = "hierarchy") 
	private int hierarchy;*/

	@Column(name = "remarks")
	private String remarks;
	
	// Removed in Phase 2  
	/*@Column(name = "status")
	private boolean status;*/
	
	
	

	@Transient
	@Column(name = "createddate")
	private Timestamp createdDate;

	@Column(name = "createdby")
	private int createdBy;

	@Column(name = "updatedby")
	private int updatedBy;

	@Column(name = "updateddate")
	private Date updatedDate;

	@PrePersist
	protected void onCreate() {
		updatedDate = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		updatedDate = new Date();
	}

	@Column(name = "Lookupfieldsid")
	private String lookupFieldsID;
	
	
	@Column(name ="ReasonCodeLow")
	private int reasonCodeLow;
	
	@Column(name ="ReasonCodeHigh")
	private int reasonCodeHigh;
	
	@Column(name ="ReasonCodeDivision")
	private int reasonCodeDivision;
	
	
	// Removed in Phase 2  

	/*@Column(name = "Requiredfields")
	private boolean requiredFields;

	@Column(name = "Computerule")
	private boolean computerule;

	@Column(name = "Fixedfieldvalues")
	private boolean fixedFieldValues;*/

	public RuleClassification() {
		super();
	}



	public int getReasonCodeLow() {
		return reasonCodeLow;
	}

	public void setReasonCodeLow(int reasonCodeLow) {
		this.reasonCodeLow = reasonCodeLow;
	}

	public int getReasonCodeHigh() {
		return reasonCodeHigh;
	}

	public void setReasonCodeHigh(int reasonCodeHigh) {
		this.reasonCodeHigh = reasonCodeHigh;
	}

	public int getReasonCodeDivision() {
		return reasonCodeDivision;
	}

	public void setReasonCodeDivision(int reasonCodeDivision) {
		this.reasonCodeDivision = reasonCodeDivision;
	}

	public String getLookupFieldsID() {
		return lookupFieldsID;
	}

	public void setLookupFieldsID(String lookupFieldsID) {
		this.lookupFieldsID = lookupFieldsID;
	}

	/*public boolean isRequiredFields() {
		return requiredFields;
	}

	public void setRequiredFields(boolean requiredFields) {
		this.requiredFields = requiredFields;
	}

	public boolean isFixedFieldValues() {
		return fixedFieldValues;
	}

	public void setFixedFieldValues(boolean fixedFieldValues) {
		this.fixedFieldValues = fixedFieldValues;
	}

	public boolean isComputeRule() {
		return computerule;
	}

	public void setComputeRule(boolean computerule) {
		this.computerule = computerule;
	}*/

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRcName() {
		return rcName;
	}

	public void setRcName(String rcName) {
		this.rcName = rcName;
	}

	/*public int getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(int hierarchy) {
		this.hierarchy = hierarchy;
	}*/

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/*public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}*/

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	@JsonIgnore
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "RuleClassification [id=" + id + ", rcName=" + rcName + ", remarks=" + remarks + ", createdDate="
				+ createdDate + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate
				+ ", lookupFieldsID=" + lookupFieldsID + ", reasonCodeLow=" + reasonCodeLow + ", reasonCodeHigh="
				+ reasonCodeHigh + ", reasonCodeDivision=" + reasonCodeDivision + "]";
	}

}
