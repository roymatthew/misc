package com.ode.exchange.re.entity;


public class RuleLogic {

	public enum ExpressionType {
		FIELD, OPERATOR, VALUE

	}

	private static final long serialVersionUID = 4910225916550731448L;

	protected String value;
	protected ExpressionType expressionType;
	protected RuleLogic next;

	public RuleLogic() {

	}

	public RuleLogic(String value, ExpressionType expressionType) {

		this.value = value;
		this.expressionType = expressionType;

	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ExpressionType getExpressionType() {
		return expressionType;
	}

	public void setExpressionType(ExpressionType expressionType) {
		this.expressionType = expressionType;
	}

	public RuleLogic getNext() {
		return next;
	}

	public void setNext(RuleLogic next) {
		this.next = next;
	}
	/*
	 * public Boolean getValid() { return valid; } public void setValid(Boolean
	 * valid) { this.valid = valid; }
	 */

	@Override
	public String toString() {
		return "RuleLogic [value=" + value + ", expressionType=" + expressionType + ", next=" + next + "]";
	}

}
