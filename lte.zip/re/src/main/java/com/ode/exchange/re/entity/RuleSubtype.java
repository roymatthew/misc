package com.ode.exchange.re.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;


/**
 * This is an Entity Class for RuleSubtype. Maps RuleSubtype Table
 * 
 * @author
 *
 */
@Entity
@Table(name = "Rulesubtype")
public class RuleSubtype implements java.io.Serializable {
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "RulesubtypeID")
	private int id;

	@Column(name = "Rulesubtype")
	private String ruleSubtype;

	@Column(name = "Remarks")
	private String remarks;

	@Column(name = "Status")
	private boolean status;

	@Column(name = "createddate")
	private Date createdDate;

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "RuletypeID")
	private RuleType ruleType;

	public RuleSubtype() {
		super();
	}

	public String getRuleSubtype() {
		return ruleSubtype;
	}

	public void setRuleSubtype(String ruleSubtype) {
		this.ruleSubtype = ruleSubtype;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public RuleType getRuleType() {
		return ruleType;
	}

	public void setRuleType(RuleType ruleType) {
		this.ruleType = ruleType;
	}

	@Override
	public String toString() {
		return "RuleSubtype [id=" + id + ", remarks=" + remarks + ", status=" + status + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", ruleType=" + ruleType + "]";
	}

}
