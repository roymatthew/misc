package com.ode.exchange.re.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;


/**
 * This is an Entity Class for RuleType. Maps RuleType Table
 * 
 * @author
 *
 */

@Entity
@Table(name = "Ruletype")
public class RuleType  implements java.io.Serializable {
	
	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "RuletypeID")
	private int id;

	@Column(name = "Ruletype")
	private String ruleTypeName;

	@Column(name = "Remarks")
	private String remarks;

	@Column(name = "Status")
	private boolean status;

	@Column(name = "createddate")
	private Date createdDate;

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;

	public RuleType() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRuleTypeName() {
		return ruleTypeName;
	}

	public void setRuleTypeName(String ruleTypeName) {
		this.ruleTypeName = ruleTypeName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "RuleType [id=" + id + ", ruleTypeName=" + ruleTypeName + ", remarks=" + remarks + ", status=" + status
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
	}

}
