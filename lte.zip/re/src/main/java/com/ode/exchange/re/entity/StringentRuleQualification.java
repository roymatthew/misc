package com.ode.exchange.re.entity;

import java.util.List;

/**
 * This is an Entity Class for StringentRuleQualification.
 * 
 * @author
 *
 */

public class StringentRuleQualification {

	private int stringentRuleLookUpCount;
	private List<Integer> stringentRuleHierarchyList;

	private Rule stringentRule;
	private int totalLookUpCount;

	public Rule getStringentRule() {
		return stringentRule;
	}

	public void setStringentRule(Rule stringentRule) {
		this.stringentRule = stringentRule;
	}

	public int getStringentRuleLookUpCount() {
		return stringentRuleLookUpCount;
	}

	public void setStringentRuleLookUpCount(int stringentRuleLookUpCount) {
		this.stringentRuleLookUpCount = stringentRuleLookUpCount;
	}

	public List<Integer> getStringentRuleHierarchyList() {
		return stringentRuleHierarchyList;
	}

	public void setStringentRuleHierarchyList(List<Integer> stringentRuleHierarchyList) {
		this.stringentRuleHierarchyList = stringentRuleHierarchyList;
	}

	public int getTotalLookUpCount() {
		return totalLookUpCount;
	}

	public void setTotalLookUpCount(int totalLookUpCount) {
		this.totalLookUpCount = totalLookUpCount;
	}

	@Override
	public String toString() {
		return "StringentRuleQualification [stringentRuleLookUpCount=" + stringentRuleLookUpCount
				+ ", stringentRuleHierarchyCount=" + stringentRuleHierarchyList + ", stringentRule=" + stringentRule
				+ ", totalLookUpCount=" + totalLookUpCount + "]";
	}

}
