package com.ode.exchange.re.entity;

import java.util.HashMap;
import java.util.List;

public class ToleranceGetValues {
	
	private List valuesList; 
	private HashMap<String,String> calcValues;
	
	
	public ToleranceGetValues() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ToleranceGetValues(List valuesList, HashMap<String, String> calcValues) {
		super();
		this.valuesList = valuesList;
		this.calcValues = calcValues;
	}
	public List getValuesList() {
		return valuesList;
	}
	public void setValuesList(List valuesList) {
		this.valuesList = valuesList;
	}
	public HashMap<String, String> getCalcValues() {
		return calcValues;
	}
	public void setCalcValues(HashMap<String, String> calcValues) {
		this.calcValues = calcValues;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((calcValues == null) ? 0 : calcValues.hashCode());
		result = prime * result + ((valuesList == null) ? 0 : valuesList.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToleranceGetValues other = (ToleranceGetValues) obj;
		if (calcValues == null) {
			if (other.calcValues != null)
				return false;
		} else if (!calcValues.equals(other.calcValues))
			return false;
		if (valuesList == null) {
			if (other.valuesList != null)
				return false;
		} else if (!valuesList.equals(other.valuesList))
			return false;
		return true;
	}
	
	

}
