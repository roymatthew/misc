package com.ode.exchange.re.entity;

public class ToleranceRule {

	public enum ExpressionType {
		FIELD, OPERATOR, VALUE

	}

	
	protected String value;
	protected ExpressionType expressionType;
protected String fieldExpressionPrefix;
	public ToleranceRule() {

	}

	
	public ToleranceRule(ExpressionType expressionType, String value,String fieldExpressionPrefix ) {
		super();		
		this.value = value;
		this.expressionType = expressionType;
		this.fieldExpressionPrefix = fieldExpressionPrefix;
	}

	
	public ToleranceRule(ExpressionType expressionType, String value ) {
		super();
		
		this.value = value;
		this.expressionType = expressionType;
	}



	

	public String getFieldExpressionPrefix() {
		return fieldExpressionPrefix;
	}

	public void setFieldExpressionPrefix(String fieldExpressionPrefix) {
		this.fieldExpressionPrefix = fieldExpressionPrefix;
	}


	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ExpressionType getExpressionType() {
		return expressionType;
	}

	public void setExpressionType(ExpressionType expressionType) {
		this.expressionType = expressionType;
	}

	@Override
	public String toString() {
		return "ToleranceRule [ value=" + value + ", expressionType=" + expressionType + "]";
	}

}
