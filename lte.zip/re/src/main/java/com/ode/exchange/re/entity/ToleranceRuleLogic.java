package com.ode.exchange.re.entity;

import java.util.List;

public class ToleranceRuleLogic {
	
	private List<ToleranceRule> lowTolerance;
	private List<ToleranceRule> lowComparsionOperator;
	private List<ToleranceRule> fieldExpression;
	private List<ToleranceRule> highComparsionOperator;

	private List<ToleranceRule> highTolerance;

	public ToleranceRuleLogic() {
		
	}

	public ToleranceRuleLogic(List<ToleranceRule> lowTolerance, List<ToleranceRule> lowComparsionOperator,
			List<ToleranceRule> fieldExpression, List<ToleranceRule> highComparsionOperator,
			List<ToleranceRule> highTolerance) {
		super();
		this.lowTolerance = lowTolerance;
		this.lowComparsionOperator = lowComparsionOperator;
		this.fieldExpression = fieldExpression;
		this.highComparsionOperator = highComparsionOperator;
		this.highTolerance = highTolerance;
	}

	public List<ToleranceRule> getLowTolerance() {
		return lowTolerance;
	}

	public void setLowTolerance(List<ToleranceRule> lowTolerance) {
		this.lowTolerance = lowTolerance;
	}

	public List<ToleranceRule> getLowComparsionOperator() {
		return lowComparsionOperator;
	}

	public void setLowComparsionOperator(List<ToleranceRule> lowComparsionOperator) {
		this.lowComparsionOperator = lowComparsionOperator;
	}

	

	public List<ToleranceRule> getFieldExpression() {
		return fieldExpression;
	}

	public void setFieldExpression(List<ToleranceRule> fieldExpression) {
		this.fieldExpression = fieldExpression;
	}

	public List<ToleranceRule> getHighComparsionOperator() {
		return highComparsionOperator;
	}

	public void setHighComparsionOperator(List<ToleranceRule> highComparsionOperator) {
		this.highComparsionOperator = highComparsionOperator;
	}

	public List<ToleranceRule> getHighTolerance() {
		return highTolerance;
	}

	public void setHighTolerance(List<ToleranceRule> highTolerance) {
		this.highTolerance = highTolerance;
	}



	
	
	
	

}
