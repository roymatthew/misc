package com.ode.exchange.re.entity;

import java.util.List;

/**
 * This is an Entity Class for ToleranceRuleLogicExpression.
 * 
 * @author
 *
 */

public class ToleranceRuleLogicExpression {

	public enum Operator {
		Between_higher_and_lower_value, Greater_than_lower_value, Greater_than_higher_value, Less_than_higher_value, Less_than_lower_value
	}

	public enum ValueList {
		Value, Percentage
	}

	private String fieldName;

	private Operator operator;	
	
	private ValueList parameter; 
	
	private String value;
	
	private String percentage;

	private String comparedAgainstField; 
	
	private String higherTolerance;

	private String lowerTolerance;

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public Operator getOperator() {
		return operator;
	}

	public void setOperator(Operator operator) {
		this.operator = operator;
	}

	public ValueList getParameter() {
		return parameter;
	}

	public void setParameter(ValueList parameter) {
		this.parameter = parameter;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public String getComparedAgainstField() {
		return comparedAgainstField;
	}

	public void setComparedAgainstField(String comparedAgainstField) {
		this.comparedAgainstField = comparedAgainstField;
	}

	public String getHigherTolerance() {
		return higherTolerance;
	}

	public void setHigherTolerance(String higherTolerance) {
		this.higherTolerance = higherTolerance;
	}

	public String getLowerTolerance() {
		return lowerTolerance;
	}

	public void setLowerTolerance(String lowerTolerance) {
		this.lowerTolerance = lowerTolerance;
	}

	@Override
	public String toString() {
		return "ToleranceRuleLogicExpression [fieldName=" + fieldName + ", operator=" + operator + ", parameter="
				+ parameter + ", value=" + value + ", percentage=" + percentage + ", comparedAgainstField="
				+ comparedAgainstField + ", higherTolerance=" + higherTolerance + ", lowerTolerance=" + lowerTolerance
				+ "]";
	}


	
	
	

}
