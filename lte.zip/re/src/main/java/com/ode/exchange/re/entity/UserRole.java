
package com.ode.exchange.re.entity;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 * This is an Entity Class for Application UserRole. Maps UserRole Table
 * 
 * @author
 *
 */

@Entity
@Table(name = "Userrole")
public class UserRole implements java.io.Serializable {

	private static final long serialVersionUID = 4910225916550731448L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "UserroleID")
	private int id;

	@Column(name = "userrolename")
	private String userRoleName;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "status")
	private boolean status;

	@Column(name = "createddate")
	private Date createdDate;

	@PrePersist
	protected void onCreate() {
		createdDate = new Date();
	}

	@Column(name = "createdby")
	private int createdBy;

	public UserRole() {
		super();		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserrolename() {
		return userRoleName;
	}

	public void setUserrolename(String userRoleName) {
		this.userRoleName = userRoleName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "Userrole [roleid=" + id + ", userrolename=" + userRoleName + ", remarks=" + remarks + ", status="
				+ status + ", createddate=" + createdDate + ", createdBy=" + createdBy + "]";
	}

}
