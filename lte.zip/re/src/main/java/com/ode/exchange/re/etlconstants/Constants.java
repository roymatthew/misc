package com.ode.exchange.re.etlconstants;

/**
 *
 * @author Mohamad
 *
 */
public class Constants {

	public static final String DOCUMENTIDXPATH = "/AcknowledgeCreditContractResponse/DataArea/CreditContractResponse/Header/DocumentId";
	public static final String CREATEDATEXPATH = "/AcknowledgeCreditContractResponse/ApplicationArea/CreationDateTime";
	public static final String TASKXPATH = "/AcknowledgeCreditContractResponse/ApplicationArea/Sender/Task";
	public static final String SENDERNAMECODEXPATH = "/AcknowledgeCreditContractResponse/ApplicationArea/Sender/SenderNameCode";
	public static final String COMPONENTXPATH = "/AcknowledgeCreditContractResponse/ApplicationArea/Sender/Component";
	public static final String CONTRACTMVPXPATH = "/AcknowledgeCreditContractResponse/DataArea/CreditContractResponse/Financing/ContractMVP";
	public static final String ROOT = "payload";
	public static final String BASE_XPATH = "/" + ROOT + "/content";
	public static final String SLASH = "/";
	public static final String R_BRACKET = "]";
	public static final String L_BRACKET = "[";


	public static final String ValidationResults = "/AcknowledgeCreditContractResponse/DataArea/CreditContractResponse/Header/ValidationResults";
	public static final String ValidationDescription = "/AcknowledgeCreditContractResponse/DataArea/CreditContractResponse/Header/ValidationMessage[i]/Description";
	public static final String ValidationErrorCriticality = "/AcknowledgeCreditContractResponse/DataArea/CreditContractResponse/Header/ValidationMessage[i]/ErrorCriticality";

	public static final String DESTINATION_NAME_CODE_XPATH = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/ApplicationArea/Destination/DestinationNameCode";
	public static final String FINAL_VALIDATION_RESULT_PASSED = "Passed";
	public static final String DESTINATION_NAME_CODE_ROUTEONE = "RO";
	//	public static final String SUCCESS_RESPONSE = "<response>Success</response>";

	// Constant XPath for BODXML
	public static final String BOD_ROOT = "ConfirmBOD";
	public static final String BOD_APPAREA_COMPONENT = "/ApplicationArea/Sender/Component";
	public static final String BOD_APPAREA_TASK = "/ApplicationArea/Sender/Task";
	public static final String BOD_APPAREA_CREATORNAMECODE = "/ApplicationArea/Sender/CreatorNameCode";
	public static final String BOD_APPAREA_SENDERNAMECODE = "/ApplicationArea/Sender/SenderNameCode";
	public static final String BOD_APPAREA_CREATIONDATETIME = "/ApplicationArea/CreationDateTime";
	public static final String BOD_APPAREA_DESTINATIONNAMECODE = "/ApplicationArea/Destination/DestinationNameCode";
	public static final String BOD_DATAAREA_CONFIRM = "/DataArea/Confirm";
	public static final String BOD_DATAAREA_COMPONENT = "/DataArea/BOD/Header/OriginalApplicationArea/Sender/Component";
	public static final String BOD_DATAAREA_TASK = "/DataArea/BOD/Header/OriginalApplicationArea/Sender/Task";
	public static final String BOD_DATAAREA_AUTHORIZATIONID = "/DataArea/BOD/Header/OriginalApplicationArea/Sender/AuthorizationId";
	public static final String BOD_DATAAREA_CREATORNAMECODE = "/DataArea/BOD/Header/OriginalApplicationArea/Sender/CreatorNameCode";
	public static final String BOD_DATAAREA_SENDERNAMECODE = "/DataArea/BOD/Header/OriginalApplicationArea/Sender/SenderNameCode";
	public static final String BOD_DATAAREA_CREATIONDATETIME = "/DataArea/BOD/Header/OriginalApplicationArea/CreationDateTime";
	public static final String BOD_DATAAREA_DESTINATIONNAMECODE = "/DataArea/BOD/Header/OriginalApplicationArea/Destination/DestinationNameCode";
	public static final String BOD_DATAAREA_SUCCESS_APPREASONCODE = "/DataArea/BOD/Header/BODSuccess/SuccessMessage/ApplicationReasonCode";
	public static final String BOD_DATAAREA_SUCCESS_DESCRIPTION = "/DataArea/BOD/Header/BODSuccess/SuccessMessage/Description";
	public static final String BOD_DATAAREA_SUCCESS_MESSAGEREASONCODE = "/DataArea/BOD/Header/BODSuccess/SuccessMessage/MessageReasonCode";
	public static final String BOD_DATAAREA_BODID = "/DataArea/BOD/Header/OriginalApplicationArea/BODId";
	public static final String LTE_OPERATOR_SEND = "SEND";
	public static final String LTE_OPERATOR_SENDTO = "SENDTO";
	public static final String LTE_OPERATOR_DROP = "DROP";
	public static final String LTE_OPERATOR_DROPSET = "DROPSET";
	public static final String LTE_OPERATOR_COPY = "COPY";

	public static final String ROLLUP = "ROLLUP";
	public static final String FIELD = "FIELD";
	public static final String CHANGETO = "CHANGETO";
	public static final String VALUE = "VALUE";
	public static final String OR = "OR";
	public static final String FINANCE_PROCESSING_DATE = "FinancePlanProcessingDate";
	public static final String APPLICATION_NUMBER = "ApplicationNumber";
	public static final String MISSING_QUALIFYING_RULES = "NO QUALIFYING RULE FOUND";
	
	public static final String SPOT_DELIVERY_IND_TAG_NAME = "SpotDeliveryInd";
}
