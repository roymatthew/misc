package com.ode.exchange.re.etlcontroller;

import com.ode.exchange.re.entity.ETL;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlentity.RequestXML;
import com.ode.exchange.re.etlentity.RulesEngineBO;
import com.ode.exchange.re.etlentity.XMLFields;
import com.ode.exchange.re.etlservice.IETLMappingService;
import com.ode.exchange.re.etlservice.IRequestXMLService;
import com.ode.exchange.re.etlservice.IResponseXMLService;
import com.ode.exchange.re.etlservice.IXMLFieldsService;
import com.ode.exchange.re.exceptions.BadRequestException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.apache.logging.log4j.ThreadContext;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

/**
 * This class is for ETL process APIs that contains methods to extract the
 * values form request XML and create respsonse XML.
 *
 * @author Mohammad
 *
 */

@RestController

public class ETLMappingController {

	@Autowired
	private IETLMappingService etlMappingService;

	@Autowired
	private IRequestXMLService requestXMLService;

	@Autowired
	private IXMLFieldsService xmlFieldsService;

	@Autowired
	private IResponseXMLService responseXMLService;

	@Autowired
	private ModelMapper modelMapper;

	private final Logger log = LoggerFactory.getLogger(ETLMappingController.class);

	/**
	 * Get ETLConfiguration values
	 *
	 * @return All ETLMapping data.
	 */

	@GetMapping("/etl-mapping")
	public ResponseEntity<List<ETLMapping>> getETLMappingList() {
		log.debug("Entered getETLMappingList() method of ETLMappingController class");
		List<ETLMapping> list = etlMappingService.findAllETLMapping();
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@PutMapping(value = "/etl-ordering")
	public ResponseEntity<List<ETLMapping>> getETLOrderingList(@RequestBody ETL etl) {
		log.debug("Entered getETLOrderingList() method of ETLMappingController class");
		String xpath = etl.getxPath();
		List<ETLMapping> orderedlist = etlMappingService.findAllETLOrdering(xpath);
		return new ResponseEntity<>(orderedlist, HttpStatus.OK);
	}

	@PutMapping("/etl-mapping")
	public ResponseEntity<?> saveOrUpdateETL(@RequestBody ETL etl) {

		log.debug("Entered saveOrUpdateETL() method of ETLMappingController class");
		try {
			etl = etlMappingService.updateById(etl);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return new ResponseEntity<ETL>(modelMapper.map(etl, ETL.class), HttpStatus.OK);
	}

	@PutMapping("/etl-mapping-order")
	public void saveOrUpdateETLOrder(@RequestBody List<ETL> etl) {

		log.debug("Entered saveOrUpdateETLOrder() method of ETLMappingController class");
		ETL etlordered = null;
		for (ETL orderedRecord : etl) {
			try {
				etlMappingService.updateById(orderedRecord);

			} catch (Exception e) {
				throw new BadRequestException(e.getMessage());
			}
		}

	}

	@PutMapping("/etl-mapping/{id}")
	public void deleteETLById(@PathVariable("id") int id) {

		log.debug("Entered deleteETLById() method of ETLMappingController class");

		try {
			etlMappingService.delete(id);
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

	}

	@RequestMapping(value = "/request-xml", method = RequestMethod.POST, consumes = { "application/xml" })
	public ResponseEntity<Long> saveRequestXML(@RequestBody String xml) {

		log.debug("Entered saveRequestXML() method of ETLMappingController class");

		RequestXML requestxml = new RequestXML();
		requestxml.setXmlData(xml);
		Long xmlId = requestXMLService.saveRequestXML(requestxml);
		return new ResponseEntity<>(xmlId, HttpStatus.OK);
	}

	/**
	 * Get XML values, Save to XMLFields table.
	 *
	 * @param xml RequestXML that comes as requestBody.
	 * @return string "Values are saved"
	 */

	@RequestMapping(value = "/xml-values", method = RequestMethod.POST, consumes = { "application/xml" })
	public ResponseEntity<String> saveXMLFields(@RequestBody String xml) {

		log.debug("Entered saveXMLFields() method of ETLMappingController class");

		try {
			xmlFieldsService.saveXMLValues(xml);
		} catch (ParserConfigurationException | SAXException | XPathExpressionException | IOException e) {
			log.error(e.toString());
			log.error("XML format is not correct");
			return ResponseEntity.status(HttpStatus.CONFLICT).body("XML format is not correct");

		}
		return new ResponseEntity<>("Values are saved", HttpStatus.OK);
	}

	@ExceptionHandler
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ResponseEntity<?> handleException(HttpMessageNotReadableException exception) {
		log.info("Error Message: complete body");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("XML body is empty");
	}

	/**
	 * Get ETLConfiguration values, Save RequestXML, Extract XML values and save to
	 * XMLFields and XMLFieldsHistory tables, Call processrule API and get the
	 * validation results. Empty the XMLFields table. Generate Response XML. Fill
	 * ProcessAudit table.
	 *
	 * @return responseXML
	 * @throws Exception
	 */

	@RequestMapping(value = "/process-cv", method = RequestMethod.POST, consumes = { "application/xml" })
	public ResponseEntity<String> createResponse(@RequestBody String xml) throws Exception {
		ThreadContext.put("uuid", UUID.randomUUID().toString());
		final LocalDateTime start = LocalDateTime.now();
		log.debug("Entered createResponse() method of ETLMappingController class. Begin LTE processing at {}", start);
		log.debug("XML received: {}", xml);
		String responseXML;
		RulesEngineBO rulesEngineBO = null;
		String dmsDealId = "";

		try {
			rulesEngineBO = xmlFieldsService.saveXMLValues(xml);
			responseXML = responseXMLService.buildXml(rulesEngineBO);
		} catch (ParserConfigurationException | SAXException | XPathExpressionException | IOException e) {
			log.debug("XML format is not correct", e);
			return ResponseEntity.status(HttpStatus.CONFLICT).body("XML format is not correct");
		} catch (final Exception e) {
			log.debug("Unexpected Error during LTE Processing", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		} finally {

			if (null != rulesEngineBO)
			{
				dmsDealId = rulesEngineBO.getDmsDealId();
			}
			final LocalDateTime end = LocalDateTime.now();
			log.debug("Exit createResponse() method of ETLMappingController class. End LTE processing at {}", end);
			log.debug("LTE processing for dmsDealId: {}, took {} MILLISECONDS", dmsDealId, ChronoUnit.MILLIS.between(start, end));

			ThreadContext.clearAll();
		}

		return new ResponseEntity<>(responseXML, HttpStatus.OK);
	}

	/**
	 * Return XMLFields Values by XML ID
	 *
	 * @return All XMLFields data.
	 */

	@GetMapping("/xmlfields/{id}")
	public ResponseEntity<?> getXMLFieldsByXMLId(@PathVariable("id") long id) {
		log.debug("Entered getXMLFieldsByXMLId() method of ETLMappingController class");
		List<XMLFields> listFields = new ArrayList<>();
		try {
			listFields = xmlFieldsService.getXMLFieldsByXMLId(Long.valueOf(id));
		} catch (Exception e) {
			log.error(e.toString());
			log.error("No Data in the XMLFields");
			return ResponseEntity.status(HttpStatus.CONFLICT).body("No Data in the XMLFields");
		}
		return new ResponseEntity<List<XMLFields>>(listFields, HttpStatus.OK);

	}

}
