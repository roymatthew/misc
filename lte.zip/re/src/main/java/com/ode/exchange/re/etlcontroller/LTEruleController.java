package com.ode.exchange.re.etlcontroller;

import com.ode.exchange.re.entity.LTERepeatRules;
import com.ode.exchange.re.etlentity.LTErule;
import com.ode.exchange.re.etlrepository.ILTEruleDAO;
import com.ode.exchange.re.etlservice.ILTEruleService;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.DuplicateRequestException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

// @CrossOrigin(origins = "*")
@CrossOrigin
@RestController
public class LTEruleController {

	public static final Logger logger = LoggerFactory.getLogger(LTEruleController.class);

	@Autowired
	private ILTEruleService lteRuleService;

	@Autowired
	ILTEruleDAO lteRuleDao;

	/**
	 * Get all LTE Rule from LTERule Table
	 * @return list of all LTE rules
	 */
	@GetMapping("/lterules")
	public ResponseEntity<List<LTErule>> getLTEruleList() {
		List<LTErule> list = lteRuleService.findAllLTErule();

		if (list == null) {
			throw new BadRequestException("No LTE rulelist found");
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	/**
	 * Get LTE Rule by ID
	 * @param lteruleid
	 * @return LTE rule corresponding to the lteruleid
	 */
	@GetMapping("/lterules/{id}")
	public ResponseEntity<?> getLTERule(@PathVariable("id") int lteruleid) {

		LTErule lteRule = lteRuleService.getLTERuleById(lteruleid);

		if (lteRule == null) {
			logger.debug("LTERule with id {} not found.", lteruleid);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(lteRule, HttpStatus.OK);
	}

	@GetMapping("/repeatablerules/{id}")
	public ResponseEntity<?> getRepeatableRule(@PathVariable("id") int lteruleid) {

		LTERepeatRules lteRule = lteRuleService.getRepeatableRuleById(lteruleid);

		if (lteRule == null) {
			logger.debug("RepeatableRule with id {} not found.", lteruleid);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(lteRule, HttpStatus.OK);
	}

	/**
	 * Create a new LTE rule
	 * @param lteRule
	 * @return created LTE rule
	 */
	@RequestMapping(value = "/create-lterule", method = RequestMethod.POST, consumes = { "application/json" })
	public ResponseEntity<LTErule> createLTERule(@RequestBody LTErule lteRule) {
		List<LTErule> list = lteRuleService.findAllLTErule();
		LTErule savedLTErule;

		if (list.stream().filter(rule -> rule.getLteRuleName().equals(lteRule.getLteRuleName())).findAny().orElse(null) != null) {
			throw new DuplicateRequestException("Duplicate LTE Rule Name Exists");
		} else {
			savedLTErule = lteRuleService.save(lteRule);
		}
		return new ResponseEntity<>(savedLTErule, HttpStatus.OK);
	}


	@RequestMapping(value = "/create-repeatablerule", method = RequestMethod.POST, consumes = { "application/json" })
	public ResponseEntity<LTERepeatRules> createRepeatableRule(@RequestBody LTERepeatRules lteRule) {
		List<LTERepeatRules> list = lteRuleService.findAllLTERepeatablerules();
		LTERepeatRules savedLTErule;

		if (list.stream().filter(rule -> rule.getRuleName().equals(lteRule.getRuleName())).findAny()
				.orElse(null) != null) {
			throw new DuplicateRequestException("Duplicate Repeatable Rule Name Exists");
		} else {
			savedLTErule = lteRuleService.save(lteRule);
		}
		return new ResponseEntity<>(savedLTErule, HttpStatus.OK);
	}

	/**
	 * Update an existing LTE rule by id
	 * @param lteruleid
	 * @param lteRule
	 * @return updated LTE rule
	 */

	@PutMapping("/lterules/{id}")
	public ResponseEntity<?> createLTERule(@PathVariable("id") int lteruleid, @RequestBody LTErule lteRule) {

		List<LTErule> list = lteRuleService.findAllLTErule();
		lteRuleService.updateBulk(lteruleid, list, lteRule);

		return new ResponseEntity<LTErule>(lteRule, HttpStatus.OK);

	}

	@PostMapping("/delete-lterule/{id}")
	public ResponseEntity<?> deleteLTERule(@PathVariable("id") int id) {

		lteRuleService.deleteLTErule(id);

		return new ResponseEntity<Integer>(id, HttpStatus.OK);

	}

	@PutMapping("/repeatablerules/{id}")
	public ResponseEntity<?> updateRepeatableRule(@PathVariable("id") int lteruleid,
			@RequestBody LTERepeatRules lteRule) {

		List<LTERepeatRules> list = lteRuleService.findAllLTERepeatablerules();
		lteRuleService.updateBulk(lteruleid, list, lteRule);

		return new ResponseEntity<LTERepeatRules>(lteRule, HttpStatus.OK);

	}

	/**
	 * Save all updated rules
	 * @param lteRuleList
	 * @return List of all rules
	 */
	@RequestMapping(value = "/lterules", method = RequestMethod.PUT, consumes = { "application/json" })
	public ResponseEntity<List<LTErule>> updateOrderedList(@RequestBody List<LTErule> lteRuleList) {

		lteRuleDao.saveAll(lteRuleList);

		return new ResponseEntity<>(lteRuleList, HttpStatus.OK);
	}

	/**
	 * Get all LTE Repeatable Rule from LTERepeatRules Table
	 *
	 * @return list of all Repeatable rules
	 */
	@GetMapping("/repeatablerules")
	public ResponseEntity<List<LTERepeatRules>> getRepeatableruleList() {
		List<LTERepeatRules> list = lteRuleService.findAllLTERepeatablerules();

		if (list == null) {
			throw new BadRequestException("No LTE rulelist found");
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

}
