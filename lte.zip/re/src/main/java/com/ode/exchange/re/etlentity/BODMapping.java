package com.ode.exchange.re.etlentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class is an entity for the BOD XML Mapping. BODMapping entity has
 * BodXpath and Field Name. BodXpath is the xpath that is being created in the
 * BOD XML. Field Name shows which field Name from XMLFields table should be
 * used for generating response value. The value of FieldName will be assigned
 * to the XPath
 * 
 * @author Mohamad
 *
 */
@Entity
@Table(name = "BODMapping")

public class BODMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", unique = true, nullable = false)
	private int id;

	@Column(name = "bodXpath")
	private String responseXpath;

	@Column(name = "fieldName")
	private String fieldName;

	public String getBodXpath() {
		return responseXpath;
	}

	public String getFieldName() {
		return fieldName;
	}

	public BODMapping() {
		super();
	}
}
