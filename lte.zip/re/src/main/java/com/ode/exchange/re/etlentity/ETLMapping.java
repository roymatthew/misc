package com.ode.exchange.re.etlentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Where;

/**
 * This class is for ETLConfiguration data which helps to map the XML to get field name
 * values. This class is an entity. ETLConfiguration is the primary table for
 * the annotated entity. This class gets only ETLConfigurations with REUsage 1
 * which means they are being used in the rules engine. LookupUsage determines
 * if the record is being used for lookup purposes. Data Type could be TEXT,
 * DATETIME and NUMERIC. XPath is the address of the field name in the XML.
 *
 * @author Mohammad
 *
 */

@Where(clause = "REUsage =1")
@Entity
@Table(name = "ETLConfiguration")

public class ETLMapping implements java.io.Serializable {

	private static final long serialVersionUID = -8393611452086915504L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FieldID", unique = true, nullable = false)
	private int id;

	@Column(name = "REUsage")
	private boolean reUsage;

	@Column(name = "LookupUsage")
	private boolean lookupUsage;

	@Column(name = "AliasFieldName")
	private String aliasFieldName;

	@Column(name = "FieldName")
	private String FieldName;

	@Column(name = "DataType")
	private String dataType;

	@Column(name = "XPath")
	private String xPath;

	@Column(name = "Repeatable")
	private Boolean repeatable;

	@Column(name = "Currency")
	private boolean currency;

	@Column(name = "XpathOrder")
	private int xpathOrder;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isReUsage() {
		return reUsage;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public String getAliasFieldName() {
		return aliasFieldName;
	}

	public String getDataType() {
		return dataType;
	}

	public String getxPath() {
		return xPath;
	}

	public Boolean getRepeatable() {
		return repeatable;
	}

	public void setRepeatable(Boolean repeatable) {
		this.repeatable = repeatable;
	}

	public String getFieldName() {
		return FieldName;
	}

	public boolean isRepeatable() {
		return repeatable;
	}

	public boolean isCurrency() {
		return currency;
	}

	public void setCurrency(boolean currency) {
		this.currency = currency;
	}

	public int getXpathOrder() {
		return xpathOrder;
	}

	public void setXpathOrder(int xpathOrder) {
		this.xpathOrder = xpathOrder;
	}

	public ETLMapping() {
		super();
	}

}
