package com.ode.exchange.re.etlentity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "LTERule")

public class LTErule {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LTERuleID")
	private int lteRuleId;
	
	@Column(name = "LTERuleName")
	private String lteRuleName;	
	
	@Column(name = "LookupCriteria")
	private String lookupCriteria;	
	
	@Column(name = "LTERuleLogic")
	private String lteRuleLogic;
	
	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "CreatedDate")
	@CreationTimestamp
	private Timestamp createdDate;
	
	@Column(name = "CreatedBy")
	private String createdBy;
	
	@Column(name = "LTEOrder")
	private int lteOrder;
	
	@Column(name = "Lender")
	private String lender;

	public int getId() {
		return lteRuleId;
	}

	public void setId(int id) {
		this.lteRuleId = id;
	}

	public String getLteRuleName() {
		return lteRuleName;
	}

	public void setLteRuleName(String lteRuleName) {
		this.lteRuleName = lteRuleName;
	}

	public String getLookupCriteria() {
		return lookupCriteria;
	}

	public void setLookupCriteria(String lookupCriteria) {
		this.lookupCriteria = lookupCriteria;
	}

	public String getLteRuleLogic() {
		return lteRuleLogic;
	}

	public void setLteRuleLogic(String lteRuleLogic) {
		this.lteRuleLogic = lteRuleLogic;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getLteOrder() {
		return lteOrder;
	}

	public void setLteOrder(int lteOrder) {
		this.lteOrder = lteOrder;
	}

	public String getLender() {
		return lender;
	}

	public void setLender(String lender) {
		this.lender = lender;
	}

	@Override
	public String toString() {
		return "LTErule [lteRuleId=" + lteRuleId + ", lteRuleName=" + lteRuleName + ", lookupCriteria=" + lookupCriteria
				+ ", lteRuleLogic=" + lteRuleLogic + ", remarks=" + remarks + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + "]";
	}	
}
