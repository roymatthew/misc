package com.ode.exchange.re.etlentity;

import java.util.List;



public class LookUpCriteriaPassRulesLTE {
	List<StringentRuleQualificationLTE> stringentQualifyRuleList;
	List<LTErule> masterPassedMap;
	
	
	public List<StringentRuleQualificationLTE> getStringentQualifyRuleList() {
		return stringentQualifyRuleList;
	}
	
	
	public void setStringentQualifyRuleList(List<StringentRuleQualificationLTE> stringentQualifyRuleList) {
		this.stringentQualifyRuleList = stringentQualifyRuleList;
	}
	public List<LTErule> getMasterPassedMap() {
		return masterPassedMap;
	}
	public void setMasterPassedMap(List<LTErule> masterPassedMap) {
		this.masterPassedMap = masterPassedMap;
	}
	
	
	public LookUpCriteriaPassRulesLTE(List<StringentRuleQualificationLTE> stringentQualifyRuleList,
			List<LTErule> masterPassedMap) {
		super();
		this.stringentQualifyRuleList = stringentQualifyRuleList;
		this.masterPassedMap = masterPassedMap;
	}
	public LookUpCriteriaPassRulesLTE() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LookUpCriteriaPassRulesLTE [stringentQualifyRuleList=" + stringentQualifyRuleList + ", masterPassedMap="
				+ masterPassedMap + "]";
	}
	
	
}
