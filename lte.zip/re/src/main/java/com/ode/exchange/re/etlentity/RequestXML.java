package com.ode.exchange.re.etlentity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;

/**
 * This class is an entity for Request XML. Request XML is saved and an Integer
 * XMLID is assigned to that.
 * 
 * @author Mohammad
 *
 */

@Entity
@Table(name = "RequestXML")

public class RequestXML {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "XMLID")
	private Long xmlId;

	@Column(name = "XMLData")
	private String xmlData;

	@Column(name = "CreatedDate")
	@CreationTimestamp
	private Timestamp createdDate;

	public Long getXmlId() {
		return xmlId;
	}

	/**
	 * an XMLID is assigned to each Request XML. The same XMLID is saved in the
	 * XMLFields and Response XML.
	 * 
	 * @param xmlId identifier for request xml
	 */
	public void setXmlId(Long xmlId) {
		this.xmlId = xmlId;
	}

	public String getXmlData() {
		return xmlData;
	}

	/**
	 * XMLData is the Whole XML in string format
	 * 
	 * @param xmlData XML in string format
	 */
	public void setXmlData(String xmlData) {
		this.xmlData = xmlData;
	}

	public RequestXML() {
		super();

	}

}
