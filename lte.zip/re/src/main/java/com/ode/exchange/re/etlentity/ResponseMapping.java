package com.ode.exchange.re.etlentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class is an entity for the Response XML Mapping. ResponseMapping entity has
 * responseXpath, Field Name, Field Name condition and Field Value.
 * responseXpath is the xpath that is being created in the Response XML. Field
 * Name shows which field Name should be used for generating response value. A condition
 * is defined in the ResponseXMLServiceImpl which is declaring if
 * the FieldNameCondition is equal to the Field Value, then fieldName will be
 * used for getting the value.
 * 
 * @author Mohammad
 *
 */

@Entity
@Table(name = "ResponseMapping")

public class ResponseMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "responseID", unique = true, nullable = false)
	private int id;

	@Column(name = "responseXpath")
	private String responseXpath;

	@Column(name = "fieldName")
	private String fieldName;

	@Column(name = "fieldNameCondition")
	private String fieldNameCondition;

	@Column(name = "fieldValue")
	private String fieldValue;

	public String getResponseXpath() {
		return responseXpath;
	}

	public String getFieldName() {
		return fieldName;
	}

	public String getFieldNameCondition() {
		return fieldNameCondition;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public ResponseMapping() {
		super();
	}

}
