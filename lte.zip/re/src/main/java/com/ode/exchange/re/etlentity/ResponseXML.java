package com.ode.exchange.re.etlentity;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;

/**
 *
 * This class is an entity for Response XML. Response XML is saved. XMLID comes
 * from Request XML's XMLID.
 *
 * @author Mohammad
 *
 */

@Entity
@Table(name = "ResponseXML")

public class ResponseXML {

	@Id
	@Column(name = "XMLID")
	private Long xmlId;

	@Column(name = "LTE_OUTPUT")
	private String lteOutput;

	@Column(name = "ACCR_XML")
	private String accrXml;

	@Column(name = "CreatedDate")
	@CreationTimestamp
	private LocalDateTime createdDate;

	public void setXmlId(Long xmlId) {
		this.xmlId = xmlId;
	}

	public Long getXmlId() {
		return xmlId;
	}

	public String getLteOutput() {
		return lteOutput;
	}

	public void setLteOutput(String lteOutput) {
		this.lteOutput = lteOutput;
	}

	public String getAccrXml() {
		return accrXml;
	}

	public void setAccrXml(String accrXml) {
		this.accrXml = accrXml;
	}

	public ResponseXML() {
		super();

	}

}
