package com.ode.exchange.re.etlentity;


public class RulesEngineBO {
	
	private EtlProcessAudit processAudit;
	private String destinationNameCode;
	private String dmsDealId;
	
	public EtlProcessAudit getProcessAudit() {
		return processAudit;
	}
	public void setProcessAudit(EtlProcessAudit processAudit) {
		this.processAudit = processAudit;
	}
	public String getDestinationNameCode() {
		return destinationNameCode;
	}
	public void setDestinationNameCode(String destinationNameCode) {
		this.destinationNameCode = destinationNameCode;
	}
	
	public String getDmsDealId() {
		return dmsDealId;
	}
	public void setDmsDealId(String dmsDealId) {
		this.dmsDealId = dmsDealId;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RulesEngineBO [processAudit=");
		builder.append(processAudit);
		builder.append(", destinationNameCode=");
		builder.append(destinationNameCode);
		builder.append("]");
		return builder.toString();
	}
	
}