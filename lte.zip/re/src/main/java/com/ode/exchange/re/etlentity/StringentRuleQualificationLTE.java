package com.ode.exchange.re.etlentity;

import java.util.List;


public class StringentRuleQualificationLTE {
	private int stringentRuleLookUpCount;
	private List<Integer> stringentRuleHierarchyList;

	private LTErule stringentRule;
	private int totalLookUpCount;
	public int getStringentRuleLookUpCount() {
		return stringentRuleLookUpCount;
	}
	public void setStringentRuleLookUpCount(int stringentRuleLookUpCount) {
		this.stringentRuleLookUpCount = stringentRuleLookUpCount;
	}
	public List<Integer> getStringentRuleHierarchyList() {
		return stringentRuleHierarchyList;
	}
	public void setStringentRuleHierarchyList(List<Integer> stringentRuleHierarchyList) {
		this.stringentRuleHierarchyList = stringentRuleHierarchyList;
	}
	public LTErule getStringentRule() {
		return stringentRule;
	}
	public void setStringentRule(LTErule stringentRule) {
		this.stringentRule = stringentRule;
	}
	public int getTotalLookUpCount() {
		return totalLookUpCount;
	}
	public void setTotalLookUpCount(int totalLookUpCount) {
		this.totalLookUpCount = totalLookUpCount;
	}
	public StringentRuleQualificationLTE(int stringentRuleLookUpCount, List<Integer> stringentRuleHierarchyList,
			LTErule stringentRule, int totalLookUpCount) {
		super();
		this.stringentRuleLookUpCount = stringentRuleLookUpCount;
		this.stringentRuleHierarchyList = stringentRuleHierarchyList;
		this.stringentRule = stringentRule;
		this.totalLookUpCount = totalLookUpCount;
	}
	public StringentRuleQualificationLTE() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "StringentRuleQualificationLTE [stringentRuleLookUpCount=" + stringentRuleLookUpCount
				+ ", stringentRuleHierarchyList=" + stringentRuleHierarchyList + ", stringentRule=" + stringentRule
				+ ", totalLookUpCount=" + totalLookUpCount + "]";
	}
	
	
}
