package com.ode.exchange.re.etlentity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class TranslationPath {
	LinkedHashMap <String,LinkedHashMap<String,List<Integer>>> translatedSendVal;
	LinkedHashMap<String,List<Integer>>  finalDrop; 
	LinkedHashMap<String,List<Integer>>   finalDropSet;
	public LinkedHashMap <String, LinkedHashMap<String,List<Integer>>> getTranslatedSendVal() {
		return translatedSendVal;
	}
	public void setTranslatedSendVal(LinkedHashMap <String, LinkedHashMap<String,List<Integer>>> translatedSendVal) {
		this.translatedSendVal = translatedSendVal;
	}
	public LinkedHashMap<String,List<Integer>>   getFinalDrop() {
		return finalDrop;
	}
	public void setFinalDrop(LinkedHashMap<String,List<Integer>>   finalDrop) {
		this.finalDrop = finalDrop;
	}
	public LinkedHashMap<String,List<Integer>>   getFinalDropSet() {
		return finalDropSet;
	}
	public void setFinalDropSet(LinkedHashMap<String,List<Integer>>   finalDropSet) {
		this.finalDropSet = finalDropSet;
	}
	public TranslationPath(LinkedHashMap <String, LinkedHashMap<String,List<Integer>>> translatedSendVal, LinkedHashMap<String,List<Integer>>   finalDrop, LinkedHashMap<String,List<Integer>>   finalDropSet) {
		super();
		this.translatedSendVal = translatedSendVal;
		this.finalDrop = finalDrop;
		this.finalDropSet = finalDropSet;
	}
	public TranslationPath() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TranslationPath [translatedSendVal=" + translatedSendVal + ", finalDrop=" + finalDrop
				+ ", finalDropSet=" + finalDropSet + "]";
	} 

}
