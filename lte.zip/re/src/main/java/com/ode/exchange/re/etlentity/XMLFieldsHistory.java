package com.ode.exchange.re.etlentity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class is an entity for XMLFieldsHistory. 
 * XMLFieldHiestory entity has exact same values as XMLFields.
 * Field Name, Field Type and Field Value comes from Request XML.
 * 
 * @author Mohammad
 *
 */

@Entity
@Table(name = "XMLFieldsHistory")

public class XMLFieldsHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)

	@Column(name = "FieldHID")
	private int id;
	
	@Column(name = "XMLID")
	private Long xmlId;

	@Column(name = "FieldName")
	private String fieldName;

	@Column(name = "FieldValue")
	private String fieldValue;

	@Column(name = "FieldType")
	private String fieldType;

	@Column(name = "LookupUsage")
	private boolean lookupUsage;	
	
	@Column(name = "GroupLevel")
	private int groupLevel;
	
	public XMLFieldsHistory() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getXmlId() {
		return xmlId;
	}

	public void setXmlId(Long xmlId) {
		this.xmlId = xmlId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public boolean isLookupUsage() {
		return lookupUsage;
	}

	public void setLookupUsage(boolean lookupUsage) {
		this.lookupUsage = lookupUsage;
	}

	public int getGroupLevel() {
		return groupLevel;
	}

	public void setGroupLevel(int groupLevel) {
		this.groupLevel = groupLevel;
	}
}
