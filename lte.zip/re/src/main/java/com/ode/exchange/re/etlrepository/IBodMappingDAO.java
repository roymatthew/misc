package com.ode.exchange.re.etlrepository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.etlentity.BODMapping;

@Repository
public interface IBodMappingDAO extends CrudRepository<BODMapping, Integer>{

}
