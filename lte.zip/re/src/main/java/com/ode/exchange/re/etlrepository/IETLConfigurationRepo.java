package com.ode.exchange.re.etlrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.ETLConfiguration;

/**
 * @author rmathew
 *
 */
@Repository
public interface IETLConfigurationRepo extends JpaRepository<ETLConfiguration, Integer> {

	@Query(value = "select ec from ETLConfiguration ec where ec.xPath = :xpath ")
	public ETLConfiguration findByXpath(@Param("xpath") String xpath);

	@Query("select ec from ETLConfiguration ec where ec.aliasFieldName = :requiredField")
	public ETLConfiguration findByFieldName(@Param("requiredField") String requiredField);

	@Query("select ec from ETLConfiguration ec where ec.dataType = :dataType")
	public List<ETLConfiguration> findByDataType(@Param("dataType") String dataType);

	@Query(value = "SELECT * FROM dbo.ETLConfiguration WHERE Currency = 1", nativeQuery = true)
	public List<ETLConfiguration> findAllCurrencyFields();
	
	@Query(value = "SELECT TOP 1 * FROM dbo.ETLConfiguration "
			+ "WHERE XPath like :xpath AND XpathOrder is not null AND XpathOrder > :xpathOrder "
			+ "ORDER BY XpathOrder", nativeQuery = true)
	public ETLConfiguration findByMatchingXpath(@Param("xpath") String xpath, @Param("xpathOrder") int xpathOrder);

}
