package com.ode.exchange.re.etlrepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.entity.ETL;

/**
 * Interface for generic CRUD operations on a repository for ETLMapping.
 * 
 * @author Mohammad
 *
 */

@Repository

public interface IETLMappingDAO extends CrudRepository<ETLMapping, Integer> {
	
	/**
	 * @param etlEntity
	 * @return
	 */
	ETL findById(int id);
	ETL save(ETL etlEntity);
	@Query(value = "SELECT * FROM dbo.ETLConfiguration where REUsage = 1", nativeQuery = true)
	public List<ETLMapping> findAllEtlMappings();	

}
