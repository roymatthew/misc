package com.ode.exchange.re.etlrepository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.ode.exchange.re.etlentity.EtlProcessAudit;

/**
 * Interface for generic CRUD operations on a repository for ProcessAudit.
 * 
 * @author Mohammad
 *
 */
@Repository

public interface IEtlProcessAuditDAO extends CrudRepository<EtlProcessAudit, Integer> {

}
