package com.ode.exchange.re.etlrepository;

import com.ode.exchange.re.entity.LTERepeatRules;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ILTERepeatRulesRepo extends JpaRepository<LTERepeatRules, Integer> {

	@Query("select lterr from LTERepeatRules lterr where lterr.destination = :destinationCode and lterr.status = :status")
	public List<LTERepeatRules> findAllActiveRulesByDestination(final @Param("destinationCode") String destinationCode,
			final @Param("status") String status);


	@Override
	@Query("select lterr from LTERepeatRules lterr ORDER BY lterr.createdDate DESC")
	List<LTERepeatRules> findAll();

}
