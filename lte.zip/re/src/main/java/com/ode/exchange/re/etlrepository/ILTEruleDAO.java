package com.ode.exchange.re.etlrepository;

import com.ode.exchange.re.etlentity.LTErule;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ILTEruleDAO extends CrudRepository<LTErule, Integer>{

	@Override
	@Query("select lterule from LTErule lterule ORDER BY lterule.createdDate DESC")
	List<LTErule> findAll();

	@Query("select lterule from LTErule lterule where lterule.status in ('A') ORDER BY lterule.lteOrder ASC")
	List<LTErule> findAllActive();

	void deleteById(int id);
}
