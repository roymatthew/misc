package com.ode.exchange.re.etlrepository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.ode.exchange.re.etlentity.RequestXML;

/**
 * Interface for generic CRUD operations on a repository for RequestXML.
 * 
 * @author Mohammad
 *
 */

@Repository

public interface IRequestXMLDAO extends CrudRepository<RequestXML, Integer>  {

}
