package com.ode.exchange.re.etlrepository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ode.exchange.re.etlentity.RequestXML;

public interface IRequestXMLRepo extends JpaRepository<RequestXML, Long>  {

	Optional<RequestXML> findById(Long xmlID);

}
