package com.ode.exchange.re.etlrepository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.etlentity.ResponseMapping;

/**
 * Interface for generic CRUD operations on a repository for ResponseMapping.
 * 
 * @author Mohammad
 *
 */
@Repository

public interface IResponseMappingDAO extends CrudRepository<ResponseMapping, Integer> {

}