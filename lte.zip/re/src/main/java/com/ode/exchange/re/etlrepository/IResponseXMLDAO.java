package com.ode.exchange.re.etlrepository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.etlentity.ResponseXML;

/**
 * Interface for generic CRUD operations on a repository for ResponseXML.
 * 
 * @author Mohammad
 *
 */
@Repository

public interface IResponseXMLDAO extends CrudRepository<ResponseXML, Integer> {

}
