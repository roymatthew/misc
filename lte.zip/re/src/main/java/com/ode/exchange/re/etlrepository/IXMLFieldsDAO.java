package com.ode.exchange.re.etlrepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.ode.exchange.re.etlentity.XMLFields;

/**
 * Interface for generic CRUD operations on a repository for XMLFields.
 * 
 * @author Mohammad
 *
 */
@Repository
public interface IXMLFieldsDAO extends CrudRepository<XMLFields, Integer> {
	
	//@Query(value = "DELETE FROM dbo.XMLFields WHERE XMLID = :xmlId", nativeQuery = true)
	//public void deleteByXmlId(@Param("xmlId") Long xmlId);
	
}
