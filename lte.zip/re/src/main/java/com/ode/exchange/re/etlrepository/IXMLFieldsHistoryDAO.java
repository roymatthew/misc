package com.ode.exchange.re.etlrepository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ode.exchange.re.etlentity.XMLFieldsHistory;

/**
 * Interface for generic CRUD operations on a repository for XMLFieldsHistory.
 * 
 * @author Mohammad
 *
 */
@Repository
@Transactional
public interface IXMLFieldsHistoryDAO extends CrudRepository<XMLFieldsHistory, Integer> {
	
	@Query(value = "INSERT INTO XMLFieldsHistory(xmlId, fieldName, fieldValue, fieldType, lookupUsage) " 
			+ "SELECT xmlfields.xmlId, xmlfields.fieldName, xmlfields.fieldValue, xmlfields.fieldType, xmlfields.lookupUsage " 
			+ "FROM XMLFields xmlfields where xmlid = :xmlId")
	@Modifying
	void saveXmlFieldHistory(@Param("xmlId") Long xmlId);	
}


