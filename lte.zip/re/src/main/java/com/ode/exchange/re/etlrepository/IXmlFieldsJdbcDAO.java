/**
 * 
 */
package com.ode.exchange.re.etlrepository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ode.exchange.re.etlentity.XMLFields;

/**
 * @author rmathew
 *
 */
public interface IXmlFieldsJdbcDAO {
	
	int doXmlFieldsBatchInsert(final List<XMLFields> listOfXmlFields);
	int doDeleteXmlFieldsById(final Long xmlId);
	void doDeleteAllXmlFields();

}
