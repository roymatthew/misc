/**
 * 
 */
package com.ode.exchange.re.etlrepository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ode.exchange.re.etlentity.XMLFields;

/**
 * @author rmathew
 *
 */
@Repository
public class XmlFieldsJdbcDAOImpl implements IXmlFieldsJdbcDAO {

	private static final Logger logger = LoggerFactory.getLogger(XmlFieldsJdbcDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	@Transactional
	public int doXmlFieldsBatchInsert(final List<XMLFields> listOfXmlFields) {

		logger.debug("Entered doXmlFieldsBatchInsert() method of XmlFieldsJdbcDAOImpl class");

		String insertSql = "INSERT INTO XMLFields(fieldId, xmlId, fieldName, fieldValue, fieldType, lookupUsage, groupLevel) "
				+ " VALUES(?, ?, ?, ?, ?, ?, ?)";

		int numRowsInserted = 0;

		int[] rowsInserted = jdbcTemplate.batchUpdate(insertSql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				XMLFields xmlField = listOfXmlFields.get(i);
				ps.setInt(1, i);
				ps.setLong(2, xmlField.getXmlId());
				ps.setString(3, xmlField.getFieldName());
				ps.setString(4, xmlField.getFieldValue());
				ps.setString(5, xmlField.getFieldType());
				ps.setBoolean(6, xmlField.isLookupUsage());
				ps.setInt(7, xmlField.getGroupLevel());
			}

			@Override
			public int getBatchSize() {
				return listOfXmlFields.size();
			}

		});
		numRowsInserted = rowsInserted != null ? rowsInserted.length : 0;
		logger.debug("Exit doXmlFieldsBatchInsert() method of XmlFieldsJdbcDAOImpl class. No. of XMLFields inserted: {}", numRowsInserted);
		return numRowsInserted;
	}

	@Override
	@Transactional
	public int doDeleteXmlFieldsById(final Long xmlId) {
		logger.debug("Entered doDeleteXmlFieldsById() method of XmlFieldsJdbcDAOImpl class. xmlId: {}", xmlId);
		String deleteSql = "DELETE FROM dbo.XMLFields WHERE XMLID = ?";
		return jdbcTemplate.update(deleteSql, xmlId);
	}

	@Override
	@Transactional
	public void doDeleteAllXmlFields() {
		logger.debug("Entered doDeleteAllXmlFields() method of XmlFieldsJdbcDAOImpl class");
		String deleteSql = "DELETE FROM dbo.XMLFields";
		int count = jdbcTemplate.update(deleteSql);
		logger.debug("Deleted {} records from XMLFields table", count);
		
	}

}
