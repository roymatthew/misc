package com.ode.exchange.re.etlservice;

import java.io.IOException;
import java.util.Optional;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

import com.ode.exchange.re.etlentity.RequestXML;


public interface IETLConfigurationService {
	
	/**
	 * @param requiredField
	 * @param requestXMLObj
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws XPathExpressionException 
	 */
	boolean doesParentExist(String requiredField, Optional<RequestXML> requestXMLObj)
			throws ParserConfigurationException, SAXException, IOException, XPathExpressionException;
}