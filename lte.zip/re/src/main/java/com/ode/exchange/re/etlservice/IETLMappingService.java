package com.ode.exchange.re.etlservice;

import com.ode.exchange.re.entity.ETL;
import com.ode.exchange.re.etlentity.ETLMapping;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * Service interface for ETLMapping. It has one method called findAllETLMapping.
 *
 * @author Mohammad
 *
 */

@Service
public interface IETLMappingService {
	/**
	 * @return List of All ETLMapping
	 */
	List<ETLMapping> findAllETLMapping();

	List<ETLMapping> findAllETLOrdering(String xpath);

	public ETL updateById(ETL etl);

	/**
	 * @param id
	 * @return
	 */
	void delete(int id);
}
