package com.ode.exchange.re.etlservice;

import com.ode.exchange.re.entity.LTERepeatRules;
import com.ode.exchange.re.etlentity.LTErule;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface ILTEruleService {

	List<LTErule> findAllLTErule();

	List<LTErule> findActiveLteALL();

	LTErule save(LTErule lteRule);

	LTERepeatRules save(LTERepeatRules lteRule);

	LTErule getLTERuleById(int lteruleid);

	LTERepeatRules getRepeatableRuleById(int lteruleid);

	//	LTErule updateLTERuleById(int lteruleid, LTErule lteRule);

	LTErule updateBulk(int lteruleid, List<LTErule> list, LTErule lteRule);

	LTERepeatRules updateBulk(int lteruleid, List<LTERepeatRules> list, LTERepeatRules lteRule);

	List<LTERepeatRules> findAllLTERepeatablerules();

	void deleteLTErule(int id);

}
