package com.ode.exchange.re.etlservice;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.ode.exchange.re.entity.LTERepeatRules;

public interface IRepeatableElementsTranslationService {
	
	/**
	 * @return
	 */
	List<LTERepeatRules> getAllRepeatRules();
	
	/**
	 * @param document
	 */
	void applyRepeatRulesTranslations(final Document document, final LinkedHashMap<String, String> xmlFieldValueMap);
	
	/**
	 * @param xml
	 * @return 
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * @throws Exception 
	 */
	String applyRepeatRulesTranslations(final String xml, final LinkedHashMap<String, String> xmlFieldValueMap) throws ParserConfigurationException, SAXException, IOException, Exception;

}
