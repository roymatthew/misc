package com.ode.exchange.re.etlservice;



import java.util.Optional;

import org.springframework.stereotype.Service;
import com.ode.exchange.re.etlentity.RequestXML;

/**
 * Service interface for RequestXML. It has one method called saveRequestXML.
 * 
 * @author Mohammad
 * 
 */

@Service
public interface IRequestXMLService {
	
	/** 
	 * @param xml request xml that comes as a request body.
	 * @return Integer XMLID
	 */
	
	Long saveRequestXML(RequestXML xml);

	/**
	 * @param long1
	 * @return
	 */
	Optional<RequestXML> getRequestXML(final Long long1);

}
