package com.ode.exchange.re.etlservice;

import java.util.List;
import org.springframework.stereotype.Service;

import com.ode.exchange.re.etlentity.BODMapping;
import com.ode.exchange.re.etlentity.ResponseMapping;
import com.ode.exchange.re.etlentity.XMLFields;
import com.ode.exchange.re.etlentity.RulesEngineBO;

/**
 * Service interface for ResponseXML. It has one method called saveRequestXML.
 * 
 * @author Mohammad
 * 
 */

@Service
public interface IResponseXMLService {

	  String buildXml(RulesEngineBO rulesEngineBO) throws Exception;
	  List <ResponseMapping> getAllResponseMapping();
	  List <BODMapping> getAllBODMapping();
	  List <XMLFields> getAllXMLFields();	  	  
}
