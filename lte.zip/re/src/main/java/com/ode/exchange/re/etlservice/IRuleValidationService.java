/**
 * 
 */
package com.ode.exchange.re.etlservice;

import com.ode.exchange.re.entity.ProcessAudit;

/**
 * @author rmathew
 *
 */
public interface IRuleValidationService {
	
	ProcessAudit processValidationRules(final Long xmlID);

}
