package com.ode.exchange.re.etlservice;

import com.ode.exchange.re.DTO.XMLFieldsDTO;
import com.ode.exchange.re.etlentity.*;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;
import com.ode.exchange.re.etlentity.RulesEngineBO;

@Service
public interface IXMLFieldsService {

	RulesEngineBO saveXMLValues(String xml) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException;
	List<XMLFields> getAllXMLFields();
	XMLFields saveXMLFields(XMLFields xmlFields);
	List<XMLFields> getXMLFieldsByXMLId(final Long xmlId);
	List<XMLFieldsDTO> getXMLFieldsDTOByXMLId(final Long xmlId);
}
