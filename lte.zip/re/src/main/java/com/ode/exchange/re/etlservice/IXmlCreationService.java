package com.ode.exchange.re.etlservice;

import javax.xml.xpath.XPathExpressionException;

import org.w3c.dom.Document;

import com.ode.exchange.re.entity.ETLConfiguration;

/**
 * @author rmathew
 *
 */
public interface IXmlCreationService {
	
	Boolean addElementAtGivenOrder(Document document, final ETLConfiguration etlConfiguration, final String elementValue) throws XPathExpressionException;

}
