package com.ode.exchange.re.etlserviceimpl;

import java.io.IOException;
import java.util.Optional;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ode.exchange.re.entity.ETLConfiguration;
import com.ode.exchange.re.etlentity.RequestXML;
import com.ode.exchange.re.etlrepository.IETLConfigurationRepo;
import com.ode.exchange.re.etlrepository.IRequestXMLRepo;
import com.ode.exchange.re.etlservice.IETLConfigurationService;
import com.ode.exchange.re.etlutils.XMLCreationUtils;

@Service
public class ETLConfigurationServiceImpl implements IETLConfigurationService {
	
	private static final Logger logger = LogManager.getLogger(ETLConfigurationServiceImpl.class);
	
	@Autowired
	private IRequestXMLRepo requestXmlRepo;

	@Autowired
	private IETLConfigurationRepo etlConfigurationRepo;

	@Override
	public boolean doesParentExist(String requiredField, Optional<RequestXML> requestXMLObj)
			throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {

		logger.debug("Entered doesParentExist. requiredField: {}", requiredField);
		ETLConfiguration newETLConfig = etlConfigurationRepo.findByFieldName(requiredField);
		if (null == newETLConfig) {

			logger.debug("No ETLConfiguration found with aliasFieldName: {}", requiredField);
			return false;
		}
		String xpath = newETLConfig.getxPath();
		int pos = xpath.lastIndexOf("/");
		String parentXpath = xpath.substring(0, pos);
		logger.debug("xpath: {}", xpath);
		logger.debug("parent xpath: {}", parentXpath);
		String xml = "";
		if (requestXMLObj.isPresent()) {
			xml = requestXMLObj.get().getXmlData();
			logger.debug("Got xml string from requestXMLObj");
		}
		Document document = XMLCreationUtils.getDocumentFromXmlString(xml);
		logger.debug("Document created from xml string");
		XPath xpathObj = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpathObj.compile(parentXpath);
		NodeList nodeList =  (NodeList) expr.evaluate(document, XPathConstants.NODESET);
		if (nodeList != null && nodeList.getLength() > 0) {
			logger.debug("Nodelist found with xpath: {}", parentXpath);
			return true;
		} else {
			logger.debug("Nodelist **NOT** found with xpath: {}", parentXpath);
		}
		return false;
	}
	
	/**
	 * @param parentXpath
	 * @param parentXpath
	 * @return
	 */
	private String getElementTagName(String parentXpath) {

		String elementTagName;
		int pos = parentXpath.lastIndexOf("/");
		elementTagName = parentXpath.substring(pos + 1);
		logger.debug("elementTagName: {}", elementTagName);
		return elementTagName;
	}

}
