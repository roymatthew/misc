package com.ode.exchange.re.etlserviceimpl;

import com.ode.exchange.re.entity.ETL;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlrepository.IETLMappingDAO;
import com.ode.exchange.re.etlservice.IETLMappingService;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Implementation of IETLMappingService.
 *
 * @author Mohammad
 *
 */

@Service
@Transactional
public class ETLMappingServiceImpl implements IETLMappingService {

	@Autowired
	IETLMappingDAO etlMappingDAO;

	@Autowired
	private EntityManager entityManager;

	private Session getSession() {
		return entityManager.unwrap(Session.class);
	}

	@Override
	public List<ETLMapping> findAllETLMapping() {

		return (List<ETLMapping>) etlMappingDAO.findAll();
	}

	@Override
	public ETL updateById(ETL etl) {
		ETL etlEntity = new ETL();

		etlEntity = etlMappingDAO.save(etl);

		return etl;

	}

	@Override
	public void delete(int id) {

		etlMappingDAO.deleteById(id);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ode.exchange.re.etlservice.IETLMappingService#findAllETLOrdering()
	 */
	@Override
	public List<ETLMapping> findAllETLOrdering(String xpath) {
		// Removes child path
		String newxpath = null;
		if (null != xpath && xpath.length() > 0) {
			int endIndex = xpath.lastIndexOf("/");
			if (endIndex != -1) {
				newxpath = xpath.substring(0, endIndex) + '%';

			} else {
				newxpath = xpath;
			}
		}

		Session session = getSession();
		String hql = "SELECT etlconfiguration FROM ETLConfiguration etlconfiguration WHERE etlconfiguration.xPath LIKE :xpath";
		Query query = session.createQuery(hql);
		query.setParameter("xpath", newxpath);
		List<ETLMapping> allXmlOrders = query.getResultList();

		return allXmlOrders;
	}
}
