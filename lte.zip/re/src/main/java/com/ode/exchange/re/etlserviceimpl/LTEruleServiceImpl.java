package com.ode.exchange.re.etlserviceimpl;


import com.ode.exchange.re.entity.LTERepeatRules;
import com.ode.exchange.re.etlentity.LTErule;
import com.ode.exchange.re.etlrepository.ILTERepeatRulesRepo;
import com.ode.exchange.re.etlrepository.ILTEruleDAO;
import com.ode.exchange.re.etlservice.ILTEruleService;
import com.ode.exchange.re.exceptions.NotFoundException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LTEruleServiceImpl implements ILTEruleService {

	@Autowired
	ILTEruleDAO lteRuleDao;

	@Autowired
	ILTERepeatRulesRepo lteRepeatRuleDao;

	// Get all rules
	@Override
	public List<LTErule> findAllLTErule() {

		return lteRuleDao.findAll();
	}

	// delete rule by id
	@Override
	public void deleteLTErule(int id) {

		lteRuleDao.deleteById(id);
	}

	// Get all repeatablerules
	@Override
	public List<LTERepeatRules> findAllLTERepeatablerules() {

		return lteRepeatRuleDao.findAll();
	}



	@Override
	public List<LTErule> findActiveLteALL() {

		return lteRuleDao.findAllActive();
	}

	// Creating a rule
	@Override
	public LTErule save(LTErule lteRule) {

		LTErule createdLteRule = lteRuleDao.save(lteRule);
		return createdLteRule;
	}

	// Creating a repeatable rule
	@Override
	public LTERepeatRules save(LTERepeatRules lteRule) {

		LTERepeatRules createdLteRule = lteRepeatRuleDao.save(lteRule);
		return createdLteRule;
	}

	// get a rule by id
	@Override
	public LTErule getLTERuleById(int lteruleid) {

		return lteRuleDao.findById(lteruleid).map(record -> record).orElse(null);
	}

	@Override
	public LTERepeatRules getRepeatableRuleById(int lteruleid) {

		return lteRepeatRuleDao.findById(lteruleid).map(record -> record).orElse(null);
	}

	// update a rule by id
	//	@Override
	//	public LTErule updateLTERuleById(int lteruleid, LTErule lteRule) {
	//
	//		LTErule existinglteRule = lteRuleDao.findById(lteruleid).map(record -> record).orElse(null);
	//
	//		if (existinglteRule == null) {
	//			throw new NotFoundException("LTE rule does not exist");
	//		}
	//		existinglteRule.setLteRuleName(lteRule.getLteRuleName());
	//		existinglteRule.setLookupCriteria(lteRule.getLookupCriteria());
	//		existinglteRule.setLteRuleLogic(lteRule.getLteRuleLogic());
	//		existinglteRule.setRemarks(lteRule.getRemarks());
	////		existinglteRule.setStatus(lteRule.getStatus());
	//		existinglteRule.setCreatedBy(lteRule.getCreatedBy());
	//		existinglteRule.setLteOrder(lteRule.getLteOrder());
	//		existinglteRule.setLender(lteRule.getLender());
	//
	//		return lteRuleDao.save(existinglteRule);
	//	}

	// Update a rule by Id and update the LTEOrder of all rules
	@Override
	public LTErule updateBulk(int lteruleid, List<LTErule> lteRuleList, LTErule updatedRule) {
		LTErule existinglteRule = lteRuleDao.findById(lteruleid).map(record -> record).orElse(null);

		if (existinglteRule == null) {
			throw new NotFoundException("LTE rule does not exist");
		}

		int updatedRuleOrder = updatedRule.getLteOrder();

		for (int i = 0; i < lteRuleList.size(); i++) {

			if (lteRuleList.get(i).getLteOrder() >= updatedRuleOrder
					&& lteRuleList.get(i).getLteOrder() < existinglteRule.getLteOrder()) {

				lteRuleList.get(i).setLteOrder(lteRuleList.get(i).getLteOrder() + 1);
			}
		}

		for (int i = 0; i < lteRuleList.size(); i++) {
			if (lteRuleList.get(i).getId() == existinglteRule.getId()) {

				lteRuleList.get(i).setLteRuleName(updatedRule.getLteRuleName());
				lteRuleList.get(i).setLookupCriteria(updatedRule.getLookupCriteria());
				lteRuleList.get(i).setLteRuleLogic(updatedRule.getLteRuleLogic());
				lteRuleList.get(i).setRemarks(updatedRule.getRemarks());
				lteRuleList.get(i).setCreatedBy(updatedRule.getCreatedBy());
				lteRuleList.get(i).setLteOrder(updatedRule.getLteOrder());
				lteRuleList.get(i).setLender(updatedRule.getLender());
				lteRuleList.get(i).setStatus(updatedRule.getStatus());
			}
		}

		lteRuleDao.saveAll(lteRuleList);

		return updatedRule;
	}

	// Update a repeatable rule by Id and update the LTEOrder of all rules
	@Override
	public LTERepeatRules updateBulk(int lteruleid, List<LTERepeatRules> lteRuleList, LTERepeatRules updatedRule) {
		LTERepeatRules existinglteRule = lteRepeatRuleDao.findById(lteruleid).map(record -> record).orElse(null);

		if (existinglteRule == null) {
			throw new NotFoundException("Repeatable rule does not exist");
		}

		int updatedRuleOrder = updatedRule.getRuleOrder();

		for (int i = 0; i < lteRuleList.size(); i++) {

			if (lteRuleList.get(i).getRuleOrder() >= updatedRuleOrder
					&& lteRuleList.get(i).getRuleOrder() < existinglteRule.getRuleOrder()) {

				lteRuleList.get(i).setRuleOrder(lteRuleList.get(i).getRuleOrder() + 1);
			}
		}

		for (int i = 0; i < lteRuleList.size(); i++) {
			if (lteRuleList.get(i).getId() == existinglteRule.getId()) {

				lteRuleList.get(i).setRuleName(updatedRule.getRuleName());
				lteRuleList.get(i).setLookupCriteria(updatedRule.getLookupCriteria());
				lteRuleList.get(i).setEtlSourceAlias(updatedRule.getEtlSourceAlias());
				lteRuleList.get(i).setRemarks(updatedRule.getRemarks());
				lteRuleList.get(i).setCreatedBy(updatedRule.getCreatedBy());
				lteRuleList.get(i).setRuleOrder(updatedRule.getRuleOrder());
				lteRuleList.get(i).setLender(updatedRule.getLender());
				lteRuleList.get(i).setStatus(updatedRule.getStatus());
				lteRuleList.get(i).setEtlTargetAlias(updatedRule.getEtlTargetAlias());
				lteRuleList.get(i).setDestination(updatedRule.getDestination());
				lteRuleList.get(i).setLookupCriteria(updatedRule.getLookupCriteria());

			}
		}

		lteRepeatRuleDao.saveAll(lteRuleList);

		return updatedRule;
	}
}
