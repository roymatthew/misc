package com.ode.exchange.re.etlserviceimpl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.exchange.re.entity.ETLConfiguration;
import com.ode.exchange.re.entity.LTERepeatRules;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlrepository.IETLConfigurationRepo;
import com.ode.exchange.re.etlrepository.ILTERepeatRulesRepo;
import com.ode.exchange.re.etlservice.IRepeatableElementsTranslationService;
import com.ode.exchange.re.etlutils.XMLCreationUtils;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author rmathew
 *
 */
@Service
public class RepeatableElementsTranslationServiceImpl implements IRepeatableElementsTranslationService{

	private final Logger logger = LoggerFactory.getLogger(RepeatableElementsTranslationServiceImpl.class);

	@Autowired
	private ILTERepeatRulesRepo lteRepeatRulesRepo;

	@Autowired
	private IETLConfigurationRepo etlRepo;

	/**
	 * @return
	 */
	@Override
	public List<LTERepeatRules> getAllRepeatRules() {

		logger.debug("Entered getAllActiveRepeatRulesForRouteOne method of RepeatableElementsTranslationServiceImpl class");

		List<LTERepeatRules> listOfLTERepeatRules = null;

		try {
			listOfLTERepeatRules = lteRepeatRulesRepo.findAll();
		} catch (Exception e) {
			logger.debug("Exception from getAllRepeatRules(): " + e.getMessage());
		}

		return listOfLTERepeatRules;

	}

	/**
	 * @return
	 */
	public List<LTERepeatRules> getAllActiveRepeatRulesForRouteOne() {

		logger.debug("Entered getAllActiveRepeatRulesForRouteOne method of RepeatableElementsTranslationServiceImpl class");

		List<LTERepeatRules> listOfLTERepeatRules = null;

		try {
			listOfLTERepeatRules = lteRepeatRulesRepo.findAllActiveRulesByDestination("RO", "A");

			logger.debug("Found {} active LTERepeatRules for RouteOne: ", listOfLTERepeatRules == null ? 0 : listOfLTERepeatRules.size());

		} catch (Exception e) {
			logger.debug("Exception from getAllRepeatRules(): " + e.getMessage());
		}

		return listOfLTERepeatRules;

	}

	/*
	 * @param document
	 */
	@Override
	public String applyRepeatRulesTranslations(final String xml, final LinkedHashMap<String, String> xmlFieldValueMap) throws Exception {

		logger.debug("Entered applyRepeatRulesTranslations(String xml) method");

		Document document = XMLCreationUtils.getDocumentFromXmlString(xml);

		applyRepeatRulesTranslations(document, xmlFieldValueMap);

		return XMLCreationUtils.doctoString(document);
	}


	/**
	 * @param document
	 */
	@Override
	public void applyRepeatRulesTranslations(final Document document, final LinkedHashMap<String, String> xmlFieldValueMap) {

		logger.debug("Entered applyRepeatRulesTranslations(Document document) method of RepeatableElementsTranslationServiceImpl class");

		List<LTERepeatRules> listOfLTERepeatRules = null;

		try {
			listOfLTERepeatRules = getAllActiveRepeatRulesForRouteOne();
			for (LTERepeatRules rule : listOfLTERepeatRules) {

				ObjectMapper mapper = new ObjectMapper();
				Map<String, String> criteriaMap
				= mapper.readValue(rule.getLookupCriteria(), new TypeReference<Map<String,Object>>(){});

				if (!validateLookupCriteria(criteriaMap, xmlFieldValueMap))
				{
					logger.debug("Skipping LTERepeatRule with ruleName: {}", rule.getRuleName());
					continue;
				}

				String aliasName = rule.getEtlSourceAlias();
				logger.debug("Source Alias: " + aliasName);
				ETLConfiguration etlConfig = etlRepo.findByFieldName(aliasName);
				if (null == etlConfig)
				{
					logger.debug("Could not find Source etlConfig with aliasName: {}", aliasName);
					continue;
				}
				logger.debug("Found Source etlConfig");
				if (Constants.LTE_OPERATOR_DROPSET.equals(rule.getOperator())) {
					logger.debug("Processing DropSet");
					processDropSet(rule, etlConfig, document);
				} else if (Constants.LTE_OPERATOR_DROP.equals(rule.getOperator())) {
					logger.debug("Processing Drop");
					processDrop(rule, etlConfig, document);
				} else if (Constants.LTE_OPERATOR_SEND.equals(rule.getOperator())) {
					logger.debug("Processing Send");
					processSend(rule, etlConfig, document);
				} else if (Constants.LTE_OPERATOR_COPY.equals(rule.getOperator())) {
					logger.debug("Processing Copy");
					ETLConfiguration parentEtlConfig = etlRepo.findByFieldName(rule.getEtlTargetAlias());
					processCopy(rule, etlConfig, parentEtlConfig, document);
				}
			}
		} catch (Exception e) {
			logger.debug("Exception from applyRepeatRulesTranslations(): " + e.getMessage());
		}
	}

	/**
	 * @param criteriaMap
	 * @param xmlFieldValueMap
	 * @return
	 */
	private boolean validateLookupCriteria(final Map<String, String> criteriaMap,
			final LinkedHashMap<String, String> xmlFieldValueMap) {

		logger.debug("Entered validateLookupCriteria() method of RepeatableElementsTranslationServiceImpl class");
		boolean validationPassed = true;
		for (String criteriaKey : criteriaMap.keySet())
		{
			String criteriaValue = criteriaMap.get(criteriaKey);
			String xmlFieldValue = xmlFieldValueMap.get(criteriaKey);
			if (StringUtils.isNotBlank(xmlFieldValue) && !criteriaValue.equalsIgnoreCase(xmlFieldValue))
			{
				logger.debug("Validation failed!");
				validationPassed = false;
				break;
			}
		}
		return validationPassed;
	}

	/**
	 * @param rule
	 * @param etlConfig
	 * @param parentEtlConfig
	 * @param document
	 * @throws XPathExpressionException
	 * @throws IOException
	 */
	private void processCopy(final LTERepeatRules rule, final ETLConfiguration etlConfig, final ETLConfiguration parentEtlConfig, final Document document) throws XPathExpressionException, IOException {
		logger.debug("Entered processCopy() method of RepeatableElementsTranslationServiceImpl class");
		// find the source node
		Node sourceNode = getNode(document, etlConfig.getxPath());
		Node parentNode = getNode(document, parentEtlConfig.getxPath());
		if (sourceNode instanceof Element) {
			Element sourceElement = (Element) sourceNode;

			Element newElementToAdd = (Element) sourceElement.cloneNode(true);
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> translationValues
			= mapper.readValue(rule.getTranslationValue(), new TypeReference<Map<String,Object>>(){});
			NodeList childNodes = newElementToAdd.getChildNodes();
			for (int i = 0; i< childNodes.getLength(); i++)
			{
				if (childNodes.item(i) instanceof Element)
				{
					Element childNode = (Element)childNodes.item(i);
					Object objValue = translationValues.get(childNode.getNodeName());
					if (null != objValue)
					{
						childNode.setTextContent(objValue.toString());
					}
				}
			}
			logger.debug("Adding Node with Name: " + newElementToAdd.getNodeName());
			parentNode.appendChild(newElementToAdd);
		}

	}

	/**
	 * @param rule
	 * @param etlConfig
	 * @param document
	 * @throws XPathExpressionException
	 */
	private void processSend(final LTERepeatRules rule, final ETLConfiguration etlConfig, final Document document) throws XPathExpressionException {
		logger.debug("Entered processSend() method of RepeatableElementsTranslationServiceImpl class");
		// find the source node
		Node sourceNode = getNode(document, etlConfig.getxPath());
		if (sourceNode instanceof Element) {
			Element sendElement = (Element) sourceNode;
			logger.debug("Replacing Node Text Content with Name: " + rule.getTranslationValue());
			sendElement.setTextContent(rule.getTranslationValue());
		}

	}

	/**
	 * @param rule
	 * @param etlConfig
	 * @param document
	 * @throws XPathExpressionException
	 */
	private void processDrop(final LTERepeatRules rule, final ETLConfiguration etlConfig, final Document document) throws XPathExpressionException {
		logger.debug("Entered processDrop() method of RepeatableElementsTranslationServiceImpl class");
		// find the source node
		Node sourceNode = getNode(document, etlConfig.getxPath());
		if (sourceNode instanceof Element) {
			Element dropElement = (Element) sourceNode;
			Node parentNode = sourceNode.getParentNode();
			logger.debug("Removing Node with Name: " + sourceNode.getNodeName());
			parentNode.removeChild(dropElement);
		}

	}

	/**
	 * @param rule
	 * @param etlConfig
	 * @param document
	 * @throws XPathExpressionException
	 */
	private void processDropSet(final LTERepeatRules rule, final ETLConfiguration etlConfig, final Document document)
			throws XPathExpressionException {
		logger.debug("Entered processDropSet() method of RepeatableElementsTranslationServiceImpl class");
		// find the source node
		Node sourceNode = getNode(document, etlConfig.getxPath());
		if (sourceNode instanceof Element) {
			Element dropElement = (Element) sourceNode;
			Node parentNode = sourceNode.getParentNode();
			logger.debug("Removing Node with Name: " + sourceNode.getNodeName());
			parentNode.removeChild(dropElement);
		}

	}

	/**
	 * @param document
	 * @param xpathString
	 * @return
	 * @throws XPathExpressionException
	 */
	private Node getNode(final org.w3c.dom.Document document, final String xpathString) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(xpathString);
		return (Node) expr.evaluate(document, XPathConstants.NODE);
	}
}
