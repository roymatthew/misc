package com.ode.exchange.re.etlserviceimpl;


import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.exchange.re.etlentity.RequestXML;
import com.ode.exchange.re.etlrepository.IRequestXMLDAO;
import com.ode.exchange.re.etlrepository.IRequestXMLRepo;
import com.ode.exchange.re.etlservice.IRequestXMLService;

/**
 * Implementation of IRequestXMLService.
 * @author Mohammad
 *
 */

@Service
public class RequestXMLServiceImpl implements IRequestXMLService {
	
	private final Logger log = LoggerFactory.getLogger(RequestXMLServiceImpl.class);

	@Autowired
	IRequestXMLDAO requestXMLDAO;	
	
	@Autowired
	private IRequestXMLRepo requestXmlRepo;

	/**
	 * Save method from CRUD operations returns RequestXML Type.
	 * getXMLId() method is used to return XMLId
	 */
	
	@Override
	@Transactional
	public Long saveRequestXML(RequestXML xml) {

		RequestXML requestxml = requestXMLDAO.save(xml);
		return requestxml.getXmlId();		
	}

	@Override
	public Optional<RequestXML> getRequestXML(final Long xmlID) {
		
		log.debug("Entered getRequestXML() method of RequestXMLServiceImpl.class");
		return requestXmlRepo.findById(xmlID);
	}
}
