package com.ode.exchange.re.etlserviceimpl;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ode.exchange.re.entity.ProcessAudit;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.BODMapping;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlentity.EtlProcessAudit;
import com.ode.exchange.re.etlentity.RequestXML;
import com.ode.exchange.re.etlentity.ResponseMapping;
import com.ode.exchange.re.etlentity.ResponseXML;
import com.ode.exchange.re.etlentity.RulesEngineBO;
import com.ode.exchange.re.etlentity.XMLFields;
import com.ode.exchange.re.etlrepository.IBodMappingDAO;
import com.ode.exchange.re.etlrepository.IETLMappingDAO;
import com.ode.exchange.re.etlrepository.IEtlProcessAuditDAO;
import com.ode.exchange.re.etlrepository.IRequestXMLDAO;
import com.ode.exchange.re.etlrepository.IResponseMappingDAO;
import com.ode.exchange.re.etlrepository.IResponseXMLDAO;
import com.ode.exchange.re.etlrepository.IXMLFieldsDAO;
import com.ode.exchange.re.etlrepository.IXmlFieldsJdbcDAO;
import com.ode.exchange.re.etlservice.ILTEruleService;
import com.ode.exchange.re.etlservice.IRequestXMLService;
import com.ode.exchange.re.etlservice.IResponseXMLService;
import com.ode.exchange.re.etlservice.IRuleValidationService;
import com.ode.exchange.re.etlutils.ACCRXMLUtils;
import com.ode.exchange.re.etlutils.BODXMLUtils;
import com.ode.exchange.re.etlutils.LTEProcessUtils;

/**
 * This class implements IResponseXMLService.
 *
 * @author Mohammad
 *
 */

@Service
@Transactional
public class ResponseXMLServiceImpl implements IResponseXMLService {

	private final Logger log = LoggerFactory.getLogger(ResponseXMLServiceImpl.class);

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private IResponseMappingDAO responseMapping;

	@Autowired
	IResponseXMLDAO responseXMLDAO;

	@Autowired
	private IResponseXMLService responseXMLService;

	@Autowired
	IEtlProcessAuditDAO processAuditDAO;

	@Autowired
	private IBodMappingDAO bodMappingDAO;

	@Autowired
	private IRequestXMLService requestXMLService;

	@Autowired
	IXMLFieldsDAO xmlFieldsDAO;
	
	@Autowired
	IXmlFieldsJdbcDAO xmlFieldsJdbcDAO;

	@Autowired
	LTEProcessUtils lteProcessUtil;

	private Session getSession() {
		return entityManager.unwrap(Session.class);
	}

	@Autowired
	ILTEruleService lteRuleService;

	@Autowired
	private IETLMappingDAO etlMappingDAO;

	@Autowired
	private IRequestXMLDAO requestxmlDAO;

	@Autowired
	private IRuleValidationService ruleValidationService;

	@Autowired
	ModelMapper modelMapper;

	@Value("${processrule.url}")
	private String processRuleUrl;

	@Override
	public List<ResponseMapping> getAllResponseMapping() {

		return (List<ResponseMapping>) responseMapping.findAll();
	}

	@Override
	public List<BODMapping> getAllBODMapping() {

		return (List<BODMapping>) bodMappingDAO.findAll();
	}

	@Override
	public List<XMLFields> getAllXMLFields() {

		return (List<XMLFields>) xmlFieldsDAO.findAll();
	}

	public List<ETLMapping> getAllETLMapping() {
		return (List<ETLMapping>) etlMappingDAO.findAll();
	}

	public List<RequestXML> getAllRequestXML() {
		return (List<RequestXML>) requestxmlDAO.findAll();
	}

	/**
	 * This method builds XML by getting info from ResponseMapping, BODMapping and
	 * XMLFields tables, and utilizing classes in etlutils package.
	 *
	 * @return response XML in string format.
	 * @throws Exception
	 */
	@Override
	public String buildXml(final RulesEngineBO rulesEngineBO) throws Exception {
		final LocalDateTime start = LocalDateTime.now();
		LocalDateTime end = null;
		Long xmlId = null;
		if (null != rulesEngineBO && null != rulesEngineBO.getProcessAudit()) {
			xmlId = rulesEngineBO.getProcessAudit().getXmlId();
		}
		log.info("Entered buildXml() method of ResponseXMLServiceImpl class. xmlId: {}", xmlId);
		Session session = getSession();
		ProcessAudit processAudit = null;

		// Call ruleValidationService
		try {
			processAudit = ruleValidationService.processValidationRules(rulesEngineBO.getProcessAudit().getXmlId());
			log.debug("ProcessAuditDTO: {}", processAudit);
		} catch (Exception e) {
			log.debug("Unable to get processRule data {}", e);
			return "Unable to get processRule data. xmlId: " + xmlId;
		}
		
		setDefaultsForProcessAudit(processAudit, rulesEngineBO);

		HashMap<String, Object> result = null;
		ResponseXML accrResponse = null;
		try {
			// Generate ACCR
			List<ResponseMapping> responseMappingList = responseXMLService.getAllResponseMapping();
			EtlProcessAudit etlProcessAudit = modelMapper.map(processAudit, EtlProcessAudit.class);
			result = ACCRXMLUtils.buildAccr(rulesEngineBO, etlProcessAudit, responseMappingList, session);
			accrResponse = (ResponseXML) result.get("ResponseXML");
			log.debug("ACCR: {} ", accrResponse.getAccrXml());
		} catch (final Exception e) {
			String msg = "ACCR Generation Failed for xmlId: " + xmlId;
			log.debug(msg, e);
			return msg;
		}

		if (null != processAudit.getFinalValidationResult() && !processAudit.getFinalValidationResult().isEmpty()
				&& processAudit.getFinalValidationResult().equalsIgnoreCase(Constants.FINAL_VALIDATION_RESULT_PASSED)) {
			log.debug("Final Validation Result: " + processAudit.getFinalValidationResult());

			Optional<RequestXML> requestXML = requestXMLService
					.getRequestXML(rulesEngineBO.getProcessAudit().getXmlId());
			String inputxml = requestXML.get().getXmlData();
			String lteResult = null;
			try {
				lteResult = lteProcessUtil.buildLTE(getAllXMLFields(), getAllETLMapping(), inputxml);
			} catch (final Exception e1) {
				String msg = "LTEOutput Generation Failed for xmlId: " + xmlId + " Root Cause: " + e1.getMessage();
				log.debug(msg, e1);
				return msg;
			}

			ResponseXML lteResponse = new ResponseXML();

			lteResponse.setXmlId(rulesEngineBO.getProcessAudit().getXmlId());
			lteResponse.setLteOutput(lteResult);
			lteResponse.setAccrXml(accrResponse.getAccrXml());
			// log.info("LTE Response: {} ", lteResponse.getLteOutput());
			try {
				responseXMLDAO.save(lteResponse);
			} catch (final Exception e) {
				String msg = "Failed to save LTE response. xmlId: " + xmlId;
				log.debug(msg, e);
				return msg;
			}

			// Return BOD XML
			List<BODMapping> bodMappingList = responseXMLService.getAllBODMapping();

			try {
				// Empty XMLFields table.
				try {
					log.debug("Deleting xmlFields");
					xmlFieldsJdbcDAO.doDeleteXmlFieldsById(xmlId);
					log.debug("xmlFields with xmlid: {} deleted!", xmlId);
				} catch (Exception e) {
					log.debug("Caught exception when deleting xmlFields", e);
				}
				EtlProcessAudit etlProcessAuditToSave = (EtlProcessAudit) result.get("ProcessAudit");
				log.debug("Saving EtlProcessAudit: {}", etlProcessAuditToSave);
				EtlProcessAudit etlProcessAudit = processAuditDAO.save(etlProcessAuditToSave);
				if (null != etlProcessAudit) {
					log.debug("EtlProcessAudit was saved successfully with Id: {}", etlProcessAudit.getId());
				}

			} catch (final Exception e) {
				log.debug("Caught exception when saving EtlProcessAudit", e);
			}

			String confirmBOD = "";

			try {
				confirmBOD = BODXMLUtils.confirmBOD(rulesEngineBO, bodMappingList, session, log);
			} catch (final Exception e) {
				log.debug("Caught exception when building confirmBOD", e);
			}
			
			end = LocalDateTime.now();
			log.debug("***** End buildXml at: " + end + " *****");
			log.debug("buildXml took " + ChronoUnit.MILLIS.between(start, end) + " MILLISECONDS");

			return confirmBOD;

		}
		
		end = LocalDateTime.now();
		log.debug("***** End buildXml at: " + end + " *****");
		log.debug("buildXml took " + ChronoUnit.MILLIS.between(start, end) + " MILLISECONDS");

		return accrResponse.getAccrXml();

	}

	/**
	 * @param processAudit
	 * @param rulesEngineBO
	 */
	private void setDefaultsForProcessAudit(ProcessAudit processAudit, final RulesEngineBO rulesEngineBO) {
		
		log.debug("Entered setDefaultsForProcessAudit() method of ResponseXMLServiceImpl class.");
		
		if (!Constants.DESTINATION_NAME_CODE_ROUTEONE.equalsIgnoreCase(rulesEngineBO.getDestinationNameCode())) {

			if (null == processAudit) {
				processAudit = new ProcessAudit();
			}
			if (StringUtils.isBlank(processAudit.getFinalValidationResult())) {
				processAudit.setFinalValidationResult(Constants.FINAL_VALIDATION_RESULT_PASSED);
			}
			if (StringUtils.isBlank(processAudit.getRfValidationResult())) {
				processAudit.setRfValidationResult(Constants.MISSING_QUALIFYING_RULES);
			}
			if (StringUtils.isBlank(processAudit.getFnValidationResult())) {
				processAudit.setFnValidationResult(Constants.MISSING_QUALIFYING_RULES);
			}
			if (StringUtils.isBlank(processAudit.gettValidationResult())) {
				processAudit.settValidationResult(Constants.MISSING_QUALIFYING_RULES);
			}
			if (StringUtils.isBlank(processAudit.getrValidationResult())) {
				processAudit.setrValidationResult(Constants.MISSING_QUALIFYING_RULES);
			}
			if (StringUtils.isBlank(processAudit.getRflValidationResult())) {
				processAudit.setRflValidationResult(Constants.MISSING_QUALIFYING_RULES);
			}
			
		}
		
	}
}