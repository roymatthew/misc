/**
 * 
 */
package com.ode.exchange.re.etlserviceimpl;

import static org.junit.Assert.assertEquals;

import com.ode.exchange.re.etlentity.RulesEngineBO;
import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for ResponseXMLServiceImpl
 *
 * @see com.ode.exchange.re.etlserviceimpl.ResponseXMLServiceImpl
 * @author rmathew
 */
public class ResponseXMLServiceImplTest {

	/**
	 * Parasoft Jtest UTA: Test for buildXml(RulesEngineBO)
	 *
	 * @see com.ode.exchange.re.etlserviceimpl.ResponseXMLServiceImpl#buildXml(RulesEngineBO)
	 * @author rmathew
	 */
	@Test
	public void testBuildXml() throws Throwable {
		// Given
		ResponseXMLServiceImpl underTest = new ResponseXMLServiceImpl();

		// When
		RulesEngineBO rulesEngineBO = null; // UTA: default value
		String result = underTest.buildXml(rulesEngineBO);

		// Then
		// assertEquals("", result);
	}
}