package com.ode.exchange.re.etlserviceimpl;

import com.ode.exchange.re.DTO.XMLFieldsDTO;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlentity.EtlProcessAudit;
import com.ode.exchange.re.etlentity.RequestXML;
import com.ode.exchange.re.etlentity.RulesEngineBO;
import com.ode.exchange.re.etlentity.XMLFields;
import com.ode.exchange.re.etlentity.XMLFieldsHistory;
import com.ode.exchange.re.etlrepository.IETLConfigurationRepo;
import com.ode.exchange.re.etlrepository.IETLMappingDAO;
import com.ode.exchange.re.etlrepository.IXMLFieldsDAO;
import com.ode.exchange.re.etlrepository.IXMLFieldsHistoryDAO;
import com.ode.exchange.re.etlservice.IETLMappingService;
import com.ode.exchange.re.etlservice.IRequestXMLService;
import com.ode.exchange.re.etlservice.IXMLFieldsService;
import java.io.IOException;
import java.io.StringReader;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ode.exchange.re.etlrepository.IXmlFieldsJdbcDAO;

/**
 * This class implements IXMLFieldsService.
 *
 * @author Mohammad
 *
 */
@Service
public class XMLFieldsServiceImpl implements IXMLFieldsService {

	@Autowired
	private EntityManager entityManager;

	private Session getSession() {
		return entityManager.unwrap(Session.class);
	}

	@Autowired
	private IETLMappingService etlMappingService;

	@Autowired
	private IRequestXMLService requestXMLService;

	@Autowired
	IXMLFieldsDAO xmlFieldsDAO;

	@Autowired
	IXMLFieldsHistoryDAO xmlFieldsHDAO;
	
	@Autowired
	IXmlFieldsJdbcDAO xmlFieldsJdbcDAO;
	
	@Autowired
	IXMLFieldsHistoryDAO xmlFieldsHistoryDAO;
	
	@Autowired
	IETLMappingDAO etlMappingDAO;
	
	@Autowired
	ModelMapper modelMapper;

	private final Logger log = LoggerFactory.getLogger(XMLFieldsServiceImpl.class);

	/**
	 * This method extracts all xmlvalues and save the values to the XMLFields
	 * table. First the xml will be converted to a document. Second, it gets all
	 * ETLMapping values. Third, it saves RequestXML and returns XMLID. Fourth, it
	 * extracts XML values. Fifth, it saves XML values to the XMLFields table and
	 * copies the values to the XMLFieldsHistory.
	 */

	@Override
	public RulesEngineBO saveXMLValues(String xml)
			throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		log.debug("Enter saveXMLValues() method of XMLFieldsServiceImpl class");
        final LocalDateTime start = LocalDateTime.now();
		Session session = getSession();
		RulesEngineBO rulesEngineBO = new RulesEngineBO();

		// Empty the XMLFields table.
		try {
			xmlFieldsJdbcDAO.doDeleteAllXmlFields();
		} catch (Exception e) {
			log.debug("Exception caught when trying to clear XMLFields table", e);
		}
		
		Timestamp startETL = new Timestamp(System.currentTimeMillis());
		XPathFactory xpathFactory = XPathFactory.newInstance();
		XPath xpath = xpathFactory.newXPath();

		// Convert xml to document

		InputSource source = new InputSource(new StringReader(xml));
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse(source);

		// find Destination name code
		XPathExpression exp = xpath.compile(Constants.DESTINATION_NAME_CODE_XPATH);
		String destinationNameCode = (String) exp.evaluate(document, XPathConstants.STRING);
		rulesEngineBO.setDestinationNameCode(destinationNameCode);

		// Get All ETLMapping Values
        final LocalDateTime etlFetchStart = LocalDateTime.now();
		//List<ETLMapping> etlMappingList = etlMappingService.findAllETLMapping();
		List<ETLMapping> etlMappingList = etlMappingDAO.findAllEtlMappings();
		if (etlMappingList == null || etlMappingList.isEmpty()) {
			log.error("ETLConfiguration Data is not available");
			return null;
		} else {
			log.info("No. of ETLConfiguration records fetched from table: {}", etlMappingList.size());
		}
        final LocalDateTime etlFetchEnd = LocalDateTime.now();
        log.debug("Fetching etl took {} MILLISECONDS", ChronoUnit.MILLIS.between(etlFetchStart, etlFetchEnd));

		// Save RequestXML and return XMLID
        final LocalDateTime requestXMLStart = LocalDateTime.now();
		RequestXML requestXML = new RequestXML();
		requestXML.setXmlData(xml);
		Long xmlId = requestXMLService.saveRequestXML(requestXML);

		if (xmlId == null) {
			log.error("XMLID is Null");
			return null;
		}

		log.info("Request XML has been saved with XmlId: {}", xmlId);
        final LocalDateTime requestXMLEnd = LocalDateTime.now();
        log.debug("Saving requestXML took {} MILLISECONDS", ChronoUnit.MILLIS.between(requestXMLStart, requestXMLEnd));
		
		String dealId = "";

		List<XMLFields> listOfXmlFields = new ArrayList<>();

		// Extract XML values. The nodeValue is xml value for a specific xpath
        final LocalDateTime xmlFieldsExtractionStart = LocalDateTime.now();
		for (ETLMapping etlMapping : etlMappingList) {
			
			if ("NODE".equals(etlMapping.getDataType())
					|| "NODESET".equals(etlMapping.getDataType())) {
				log.info("ETLConfiguration with data type Node/NodeSet will not be saved. Alias Name: {}",
						etlMapping.getAliasFieldName());
				continue;
			}
			XPathExpression expr = xpath.compile(etlMapping.getxPath());

			if (!etlMapping.getRepeatable()) {

				String nodeValue = (String) expr.evaluate(document, XPathConstants.STRING);

				// Evaluate expression result on XML document
				NodeList nodes = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
				
				for (int i = 0; i < nodes.getLength(); i++) {

					// check if the node value is null in requestXML
					if (nodeValue == "" && nodes.item(i).getTextContent().equals(nodeValue)) {

						XMLFields xmlFields = new XMLFields();
						xmlFields.setXmlId(xmlId);
						xmlFields.setFieldName(etlMapping.getAliasFieldName());
						xmlFields.setFieldValue("");
						xmlFields.setFieldType(etlMapping.getDataType());
						xmlFields.setLookupUsage(etlMapping.isLookupUsage());
						xmlFields.setGroupLevel(0);

						listOfXmlFields.add(xmlFields);
					}
				}

				if (nodeValue != "") {

					XMLFields xmlFields = new XMLFields();
					xmlFields.setXmlId(xmlId);
					xmlFields.setFieldName(etlMapping.getAliasFieldName());
					xmlFields.setFieldValue(nodeValue);
					xmlFields.setFieldType(etlMapping.getDataType());
					xmlFields.setLookupUsage(etlMapping.isLookupUsage());
					xmlFields.setGroupLevel(0);
					
					if ("DealId".equals(xmlFields.getFieldName()))
					{
						dealId = xmlFields.getFieldValue();
					}

					listOfXmlFields.add(xmlFields);
				}

			} else {

				// parse and extract values of repeatable elements
				NodeList parentNodeList = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
				
				for (int i = 0; i < parentNodeList.getLength(); i++) {

					Node blockElement = parentNodeList.item(i);

					for (int j = 0; j < blockElement.getChildNodes().getLength(); j++) {

						XMLFields xmlFields = new XMLFields();
						Node childNode = blockElement.getChildNodes().item(j);
						xmlFields.setXmlId(xmlId);
						xmlFields.setFieldName(etlMapping.getAliasFieldName());
						xmlFields.setFieldValue(childNode.getTextContent());
						xmlFields.setFieldType(etlMapping.getDataType());
						xmlFields.setLookupUsage(etlMapping.isLookupUsage());
						xmlFields.setGroupLevel(i + 1);

						listOfXmlFields.add(xmlFields);
					}
				}
			}
		}
		
		if (listOfXmlFields.isEmpty()) {
			log.debug("XMLFields list is empty");
		}
		else
		{
			log.info("Values are extracted from XML successfully. No. of XMLFields to be saved to DB: {}", listOfXmlFields.size());
		}
        final LocalDateTime xmlFieldsExtractionEnd = LocalDateTime.now();
        log.debug("Extracting XmlFields from document took {} MILLISECONDS", ChronoUnit.MILLIS.between(xmlFieldsExtractionStart, xmlFieldsExtractionEnd));

		// Save XML Values to XMLFields Table
        final LocalDateTime batchInsertStart = LocalDateTime.now();
		//xmlFieldsDAO.saveAll(listFields);
        xmlFieldsJdbcDAO.doXmlFieldsBatchInsert(listOfXmlFields);
        final LocalDateTime batchInsertEnd = LocalDateTime.now();
		log.info("XMLFields are saved successfully");
        log.debug("Batch Insert of XMLFIelds took {} MILLISECONDS", ChronoUnit.MILLIS.between(batchInsertStart, batchInsertEnd));

		// copy XMLFields to XMLFieldsHistory
		log.info("About to insert XMLFieldHistory");
        final LocalDateTime historyInsertStart = LocalDateTime.now();
        xmlFieldsHistoryDAO.saveXmlFieldHistory(xmlId);
        final LocalDateTime historyInsertEnd = LocalDateTime.now();
        log.debug("Insert of XMLFieldHistory took {} MILLISECONDS", ChronoUnit.MILLIS.between(historyInsertStart, historyInsertEnd));
        
		Timestamp endETL = new Timestamp(System.currentTimeMillis());
		EtlProcessAudit processAudit = new EtlProcessAudit();
		processAudit.setEtlStart(startETL);
		processAudit.setEtlEnd(endETL);
		processAudit.setXmlId(xmlId);

		rulesEngineBO.setProcessAudit(processAudit);
		if (StringUtils.isNotBlank(dealId))
		{
			rulesEngineBO.setDmsDealId(dealId);
		}
		
        final LocalDateTime end = LocalDateTime.now();
        log.debug("***** End saveXMLValues() at: {} *****" , end);
        log.debug("DealId: {}, XmlId: {} :: saveXMLValues() took {} MILLISECONDS", dealId, xmlId, ChronoUnit.MILLIS.between(start, end));

		return rulesEngineBO;
	}

	@Override
	public List<XMLFields> getAllXMLFields() {
		return (List<XMLFields>) xmlFieldsDAO.findAll();

	}
	
	@Override
	public XMLFields saveXMLFields(XMLFields xmlFields) {
		// Update row in XMLFields table
		XMLFields savedXMLFields = xmlFieldsDAO.save(xmlFields);
		// Create new row in XMLFieldsHistory table
		XMLFieldsHistory xmlFieldsHistory = new XMLFieldsHistory();
		xmlFieldsHistory.setFieldName(xmlFields.getFieldName());
		xmlFieldsHistory.setFieldType(xmlFields.getFieldType());
		xmlFieldsHistory.setFieldValue(xmlFields.getFieldValue());
		xmlFieldsHistory.setGroupLevel(xmlFields.getGroupLevel());
		xmlFieldsHistory.setLookupUsage(xmlFields.isLookupUsage());
		xmlFieldsHistory.setXmlId(xmlFields.getXmlId());
		xmlFieldsHDAO.save(xmlFieldsHistory);
		// Return updated row from XMLFields table
		return savedXMLFields;
	}

	@Override
	public List<XMLFields> getXMLFieldsByXMLId(final Long xmlId) {
		log.debug("Entered getXMLFieldsByXMLId() method of XMLFieldsServiceImpl class. xmlId: {}", xmlId); 
		Session session = getSession();
		String hql = "SELECT xmlfields FROM XMLFields xmlfields WHERE xmlfields.xmlId = :id";
		Query query = session.createQuery(hql);
		query.setParameter("id", xmlId);
		List<XMLFields> allXmlFields = query.getResultList();
		return allXmlFields;
	}

	@Override
	public List<XMLFieldsDTO> getXMLFieldsDTOByXMLId(final Long xmlId) {
		log.debug("Entered getXMLFieldsDTOByXMLId() method of XMLFieldsServiceImpl class. xmlId: {}", xmlId); 
		List<XMLFieldsDTO> listOfXmlFieldsDTOs = null;
		List<XMLFields> xmlFields = getXMLFieldsByXMLId(xmlId);
		if (null != xmlFields && !xmlFields.isEmpty()) {
			listOfXmlFieldsDTOs = xmlFields.stream().map(item -> modelMapper.map(item, XMLFieldsDTO.class))
					.collect(Collectors.toList());
		}
		return listOfXmlFieldsDTOs;
	}
}
