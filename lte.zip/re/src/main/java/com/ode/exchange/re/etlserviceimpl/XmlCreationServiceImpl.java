package com.ode.exchange.re.etlserviceimpl;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.ode.exchange.re.entity.ETLConfiguration;
import com.ode.exchange.re.etlrepository.IETLConfigurationRepo;
import com.ode.exchange.re.etlservice.IXmlCreationService;
import com.ode.exchange.re.etlutils.XPathUtils;

/**
 * @author rmathew
 *
 */
@Service
public class XmlCreationServiceImpl implements IXmlCreationService {

	private final Logger log = LoggerFactory.getLogger(XmlCreationServiceImpl.class);

	@Autowired
	private IETLConfigurationRepo etConfigurationRepo;

	@Override
	public Boolean addElementAtGivenOrder(final Document document, final ETLConfiguration etlConfiguration,
			final String elementValue) throws XPathExpressionException {
		log.debug("Enter addElementAtGivenOrder() method of XmlCreationServiceImpl class");
		String xpath = etlConfiguration.getxPath();
		String parentXPath = XPathUtils.getParentXPath(xpath);
		Node childNode = getNode(document, xpath);
		Node parentNode = getNode(document, parentXPath);
		if (null == childNode) {
			if (null == parentNode)
			{
				parentNode = addParentNode(document, parentXPath);
			}
			String xpathPredicate = parentXPath + "%";
			log.debug("xpathPredicate: {}, xpathOrder: {}", xpathPredicate,
					Integer.valueOf(etlConfiguration.getXpathOrder()));
			ETLConfiguration youngerETLConfig = etConfigurationRepo.findByMatchingXpath(xpathPredicate,
					Integer.valueOf(etlConfiguration.getXpathOrder()));
			Element element = null;
			if (null != etlConfiguration) {
				if (etlConfiguration.getRepeatable() && xpath.indexOf("[") < 0) {
					NodeList parentNodeList = getNodes(document, parentXPath);
					element = addElementToParents(document, parentNodeList, parentXPath, etlConfiguration, elementValue,
							youngerETLConfig);
				} else {
					element = addElementToParent(document, parentNode, parentXPath, etlConfiguration, elementValue,
							youngerETLConfig);
				}
			}

			if (null != element) {
				log.debug("Exit addElementAtGivenOrder() method of XmlCreationServiceImpl class. Return value: {}",
						Boolean.TRUE);
				return Boolean.TRUE;
			}
		}
		log.debug("Exit addElementAtGivenOrder() method of XmlCreationServiceImpl class. Return value: {}",
				Boolean.FALSE);
		return Boolean.FALSE;

	}

	/**
	 * @param document
	 * @param parentXPath
	 * @return
	 * @throws XPathExpressionException 
	 */
	private Node addParentNode(Document document, final String xpath) throws XPathExpressionException {

		log.debug("Entered addParentNode() method of XmlCreationServiceImpl class.");
		String nodeName = xpath.substring(xpath.lastIndexOf("/") + 1);
		String parentXPath = XPathUtils.getParentXPath(xpath);
		Node parentNode = getNode(document, parentXPath);
		Node node = null;
		if (null != parentNode)
		{
			log.debug("New parent element name: {}", nodeName);
			Element requestedElement = document.createElement(nodeName);
			Element parentElement = (Element)parentNode;
			node = parentElement.appendChild(requestedElement);
			if (null != node)
			{
				log.debug("{} added under {}", nodeName, parentElement.getNodeName());
			}
			return node;
		}
		
		return null;
	}

	/**
	 * @param document
	 * @param parentNode
	 * @param parentXpath
	 * @param xmlField
	 * @param value
	 * @param youngerETLConfig
	 * @return
	 * @throws XPathExpressionException
	 */
	private Element addElementToParent(final Document document, final Node parentNode, final String parentXpath,
			final ETLConfiguration requesteETLConfig, final String value, final ETLConfiguration youngerETLConfig)
			throws XPathExpressionException {

		log.debug("Entered addElementToParent() method of XmlCreationServiceImpl class. xmlField: {}, value: {}",
				requesteETLConfig.getAliasFieldName(), value);

		String youngerSiblingTagName;
		Element youngerSibling = null;
		Element requestedElement = null;

		try {
			if (null == youngerETLConfig || youngerETLConfig.getxPath().endsWith("@currency")) {
				log.debug("next lower sibling is null/invalid");
			} else {
				log.debug("next lower sibling: {}, xpath: {}", youngerETLConfig.getAliasFieldName(),
						youngerETLConfig.getxPath());
				Node youngerSiblingNode = getNode(document, youngerETLConfig.getxPath());
				if (null != youngerSiblingNode) {
					youngerSibling = (Element) youngerSiblingNode;
					log.debug("Found youngerSiblingNode: {}", youngerSiblingNode.getNodeName());
				}
			}
			String requestedElementTagName = requesteETLConfig.getxPath()
					.substring(requesteETLConfig.getxPath().lastIndexOf("/") + 1);
			requestedElement = document.createElement(requestedElementTagName);
			if (Boolean.TRUE.equals(requesteETLConfig.getCurrency())) {
				requestedElement.setAttribute("currency", "USD");
			}
			Text txt = document.createTextNode(value);
			requestedElement.appendChild(txt);
			Element parentElement = (Element) parentNode;

			if (null != youngerSibling
					&& youngerSibling.getParentNode().getNodeName().equals(parentElement.getNodeName())) {
				log.debug("Inserting {} before {}", requestedElement.getNodeName(), youngerSibling.getNodeName());
				parentElement.insertBefore(requestedElement, youngerSibling);
			} else {
				
				if (null != parentNode) {
					parentNode.appendChild(requestedElement);
					log.debug("Inserted {} as the last child", requestedElement.getNodeName());
				} else {
					log.debug("Could not insert {} into the DOC as it's parent element is not available",
							requestedElement.getNodeName());
				}
				
			}

			return requestedElement;
		} catch (final Exception e) {
			log.debug("Failed to insert new element: {}", requestedElement.getNodeName());
		}

		return null;

	}

	/**
	 * @param document
	 * @param parentNodeList
	 * @param parentXPath
	 * @param requesteETLConfig
	 * @param elementValue
	 * @param youngerETLConfig
	 * @return
	 * @throws XPathExpressionException
	 */
	private Element addElementToParents(final Document document, final NodeList parentNodeList,
			final String parentXPath, final ETLConfiguration requesteETLConfig, final String elementValue,
			final ETLConfiguration youngerETLConfig) throws XPathExpressionException {
		log.debug("Entered addElementToParents() method of XmlCreationServiceImpl class. xmlField: {}, value: {}",
				requesteETLConfig.getAliasFieldName(), elementValue);

		String youngerSiblingTagName;
		Element youngerSibling = null;
		Element requestedElement = null;

		try {
			if (null == youngerETLConfig || youngerETLConfig.getxPath().endsWith("@currency")) {
				log.debug("next lower sibling is null/invalid");
			} else {
				log.debug("next lower sibling: {}, xpath: {}", youngerETLConfig.getAliasFieldName(),
						youngerETLConfig.getxPath());
				Node youngerSiblingNode = getNode(document, youngerETLConfig.getxPath());
				if (null != youngerSiblingNode) {
					youngerSibling = (Element) youngerSiblingNode;
					log.debug("Found youngerSiblingNode: {}", youngerSiblingNode.getNodeName());
				}

			}

			String requestedElementTagName = requesteETLConfig.getxPath()
					.substring(requesteETLConfig.getxPath().lastIndexOf("/") + 1);

			for (int i = 0; i < parentNodeList.getLength(); i++) {
				Node parentNode = parentNodeList.item(i);
				requestedElement = document.createElement(requestedElementTagName);
				if (Boolean.TRUE.equals(requesteETLConfig.getCurrency())) {
					requestedElement.setAttribute("currency", "USD");
				}
				Text txt = document.createTextNode(elementValue);
				requestedElement.appendChild(txt);
				Element parentElement = (Element) parentNode;

				if (null != youngerSibling) {
					log.debug("Inserting {} before {}", requestedElement.getNodeName(), youngerSibling.getNodeName());
					parentElement.insertBefore(requestedElement, youngerSibling);
				} else {
					log.debug("Inserting {} as the last child", requestedElement.getNodeName());
					parentNode.appendChild(requestedElement);
				}
			}

			return requestedElement;
		} catch (final DOMException e) {
			log.debug("Failed to insert new element: {}", requestedElement.getNodeName());
		}

		return null;
	}

	/**
	 * @param document
	 * @param xpathString
	 * @return
	 * @throws XPathExpressionException
	 */
	private Node getNode(org.w3c.dom.Document document, String xpathString) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(xpathString);
		return (Node) expr.evaluate(document, XPathConstants.NODE);
	}

	/**
	 * @param document
	 * @param xpathString
	 * @return
	 * @throws XPathExpressionException
	 */
	private NodeList getNodes(final Document document, final String xpathString) throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(xpathString);
		return (NodeList) expr.evaluate(document, XPathConstants.NODESET);
	}

}
