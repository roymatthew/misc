package com.ode.exchange.re.etlutils;

import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.EtlProcessAudit;
import com.ode.exchange.re.etlentity.ResponseMapping;
import com.ode.exchange.re.etlentity.ResponseXML;
import com.ode.exchange.re.etlentity.RulesEngineBO;
import com.ode.exchange.re.etlentity.XMLFields;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.Query;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Namespace;
import org.dom4j.io.DOMWriter;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ACCRXMLUtils {

	private static final Logger log = LoggerFactory.getLogger(ACCRXMLUtils.class);

	/**
	 * @param rulesEngineBO
	 * @param processAudit
	 * @param responseMappingList
	 * @param session
	 * @param log
	 * @return
	 */
	public static HashMap<String, Object> buildAccr(final RulesEngineBO rulesEngineBO,
			final EtlProcessAudit processAudit, final List<ResponseMapping> responseMappingList,
			final Session session) {
		final LocalDateTime start = LocalDateTime.now();
		log.debug("Enter buildAccr() method of ACCRXMLUtils class. rulesEngineBO: {} ", rulesEngineBO);
		Timestamp responseStartTime = new Timestamp(System.currentTimeMillis());

		// Create a document and create root element inside the document.

		String nodeValue = "";
		Namespace nameSpace = new Namespace("ns3", "");

		Document document = DocumentHelper.createDocument(DocumentHelper.createElement(Constants.ROOT));

		XMLCreationUtils.addElementToParent(document, prependBase(Constants.TASKXPATH),
				"AcknowledgeCreditContractResponse", nameSpace);
		XMLCreationUtils.addElementToParent(document, prependBase(Constants.SENDERNAMECODEXPATH), "OD", nameSpace);
		XMLCreationUtils.addElementToParent(document, prependBase(Constants.COMPONENTXPATH), "OD", nameSpace);

		if (null != processAudit.getFinalValidationResult() && !processAudit.getFinalValidationResult().isEmpty()) {
			XMLCreationUtils.addElementToParent(document, prependBase(Constants.ValidationResults),
					processAudit.getFinalValidationResult(), nameSpace);
		}

		Timestamp now = new Timestamp(System.currentTimeMillis());
		Date date = new Date();
		date.setTime(now.getTime());
		String finalTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);

		XMLCreationUtils.addElementToParent(document, prependBase(Constants.CREATEDATEXPATH), finalTime, nameSpace);

		// Get Validation Results

		String rfResult = processAudit.getRfValidationResult();
		String fnResult = processAudit.getFnValidationResult();
		String tResult = processAudit.gettValidationResult();
		String rResult = processAudit.getrValidationResult();
		String rflResult = processAudit.getRflValidationResult();

		// Split rfResults by || and then by ?

		String[] rfResultArray = new String[0];
		String passedRequiredField = "";
		String failedRequiredField = "";

		String passedRequiredFieldItem = "";
		String failedRequiredFieldItem = "";

		if (rfResult != null && !rfResult.contains("NO QUALIFYING RULE FOUND")) {
			rfResultArray = rfResult.split("\\|\\|");
			passedRequiredField = rfResultArray[0];
			failedRequiredField = rfResultArray[1];
			passedRequiredFieldItem = passedRequiredField.split("\\?")[1];
			failedRequiredFieldItem = failedRequiredField.split("\\?")[1];
		}

		// Split fnResults by || and then by ?

		String[] fnResultArray = new String[0];
		String passedFormNumber = "";
		String failedFormNumber = "";

		String passedFormNumberItem = "";
		String failedFormNumberItem = "";

		if (fnResult != null && !fnResult.contains("NO QUALIFYING RULE FOUND")) {
			fnResultArray = fnResult.split("\\|\\|");
			passedFormNumber = fnResultArray[0];
			failedFormNumber = fnResultArray[1];
			passedFormNumberItem = passedFormNumber.split("\\?")[1];
			failedFormNumberItem = failedFormNumber.split("\\?")[1];
		}

		// Split tResults by || and then by ? and +

		String[] tResultArray = new String[0];
		String passedTolerance = "";
		String failedTolerance = "";

		String passedToleranceArray = "";
		String failedToleranceArray = "";

		String[] passedToleranceItems = new String[] {};
		String[] failedToleranceItems = new String[] {};

		if (tResult != null && !tResult.contains("NO QUALIFYING RULE FOUND")) {
			tResultArray = tResult.split("\\|\\|");
			passedTolerance = tResultArray[0];
			failedTolerance = tResultArray[1];
			passedToleranceArray = passedTolerance.split("\\?")[1];
			failedToleranceArray = failedTolerance.split("\\?")[1];

			if (passedToleranceArray != "") {

				passedToleranceItems = passedToleranceArray.split("\\+");
			}

			if (failedToleranceArray != "") {

				failedToleranceItems = failedToleranceArray.split("\\+");
			}
		}

		// Split rResults by || and then by ? and +

		String[] rResultArray = new String[0];
		String passedRuleBuilder = "";
		String failedRuleBuilder = "";

		String passedRuleBuilderArray = "";
		String failedRuleBuilderArray = "";

		String[] passedRuleBuilderItems = new String[0];
		String[] failedRuleBuilderItems = new String[0];

		if (rResult != null && !rResult.contains("NO QUALIFYING RULE FOUND")) {
			rResultArray = rResult.split("\\|\\|");
			passedRuleBuilder = rResultArray[0];
			failedRuleBuilder = rResultArray[1];
			passedRuleBuilderArray = passedRuleBuilder.split("\\?")[1];
			failedRuleBuilderArray = failedRuleBuilder.split("\\?")[1];

			if (passedRuleBuilderArray != "") {

				passedRuleBuilderItems = passedRuleBuilderArray.split("\\+");
			}

			if (failedRuleBuilderArray != "") {

				failedRuleBuilderItems = failedRuleBuilderArray.split("\\+");
			}
		}

		// Split rflResult by ,

		String[] requiredFormListItems = new String[0];
		if (null != rflResult && !rflResult.contains("NO QUALIFYING RULE FOUND")) {
			requiredFormListItems = rflResult.split(",");
		}

		// Creating ValidationMessage for Required Field
		log.debug("Required Field Validation Message creation started..");

		Integer rfPassLength = 0;
		Integer rfFailLength = 0;

		if (!passedRequiredFieldItem.replaceAll("\\s+", "").isEmpty()) {

			rfPassLength = 1;

			String rfDescription = Constants.ValidationDescription.replace("[i]", "[" + rfPassLength + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(rfDescription), passedRequiredFieldItem.trim(),
					nameSpace);
			String rfError = Constants.ValidationErrorCriticality.replace("[i]", "[" + rfPassLength + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(rfError), "I", nameSpace);
			log.debug("Completed passedRequiredFieldItem.");

		}

		if (!failedRequiredFieldItem.replaceAll("\\s+", "").isEmpty()) {

			rfFailLength = 1;

			String rfDescription = Constants.ValidationDescription.replace("[i]",
					"[" + (rfPassLength + rfFailLength) + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(rfDescription),
					"Error-" + failedRequiredFieldItem.trim(), nameSpace);
			String rfError = Constants.ValidationErrorCriticality.replace("[i]",
					"[" + (rfPassLength + rfFailLength) + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(rfError), "E", nameSpace);
			log.debug("Completed failedRequiredFieldItem.");

		}

		// Creating ValidationMessage for Form Number

		Integer fnPassLength = 0;
		Integer fnFailLength = 0;

		if (!passedFormNumberItem.replaceAll("\\s+", "").isEmpty()) {

			fnPassLength = 1;

			String fnDescription = Constants.ValidationDescription.replace("[i]",
					"[" + (rfPassLength + rfFailLength + fnPassLength) + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(fnDescription), passedFormNumberItem.trim(),
					nameSpace);
			String fnError = Constants.ValidationErrorCriticality.replace("[i]",
					"[" + (rfPassLength + rfFailLength + fnPassLength) + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(fnError), "I", nameSpace);
			log.debug("Completed passedFormNumberItem.");
		}

		if (!failedFormNumberItem.replaceAll("\\s+", "").isEmpty()) {

			fnFailLength = 1;
			String fnDescription = Constants.ValidationDescription.replace("[i]",
					"[" + (rfPassLength + rfFailLength + fnPassLength + fnFailLength) + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(fnDescription),
					"Error-" + failedFormNumberItem.trim(), nameSpace);
			String fnError = Constants.ValidationErrorCriticality.replace("[i]",
					"[" + (rfPassLength + rfFailLength + fnPassLength + fnFailLength) + "]");
			XMLCreationUtils.addElementToParent(document, prependBase(fnError), "E", nameSpace);
			log.debug("Completed failedFormNumberItem.");
		}

		// Creating ValidationMessage for Tolerance

		Integer tPassLength = 0;
		Integer tFailLength = 0;

		if (passedToleranceItems.length != 0 && !passedToleranceItems[0].replaceAll("\\s+", "").isEmpty()) {

			tPassLength = passedToleranceItems.length;

			for (int i = 0; i < passedToleranceItems.length; i++) {

				String tDescription = Constants.ValidationDescription.replace("[i]",
						"[" + (i + 1 + rfPassLength + rfFailLength + fnPassLength + fnFailLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(tDescription), passedToleranceItems[i].trim(),
						nameSpace);
				String tError = Constants.ValidationErrorCriticality.replace("[i]",
						"[" + (i + 1 + rfPassLength + rfFailLength + fnPassLength + fnFailLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(tError), "I", nameSpace);
				log.debug("Completed passedToleranceItems.");
			}
		}

		if (failedToleranceItems.length != 0 && !failedToleranceItems[0].replaceAll("\\s+", "").isEmpty()) {

			tFailLength = failedToleranceItems.length;

			for (int i = 0; i < failedToleranceItems.length; i++) {

				String tDescription = Constants.ValidationDescription.replace("[i]",
						"[" + (i + 1 + rfPassLength + rfFailLength + fnPassLength + fnFailLength + tPassLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(tDescription),
						"Error-" + failedToleranceItems[i].trim(), nameSpace);
				String tError = Constants.ValidationErrorCriticality.replace("[i]",
						"[" + (i + 1 + rfPassLength + rfFailLength + fnPassLength + fnFailLength + tPassLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(tError), "E", nameSpace);
				log.debug("Completed failedToleranceItems.");
			}
		}

		// Creating ValidationMessage for Rule Builder

		Integer rPassLength = 0;
		Integer rFailLength = 0;

		if (passedRuleBuilderItems.length != 0 && !passedRuleBuilderItems[0].replaceAll("\\s+", "").isEmpty()) {

			rPassLength = passedRuleBuilderItems.length;

			for (int i = 0; i < passedRuleBuilderItems.length; i++) {

				String rDescription = Constants.ValidationDescription.replace("[i]", "[" + (i + 1 + rfPassLength
						+ rfFailLength + fnPassLength + fnFailLength + tPassLength + tFailLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(rDescription),
						passedRuleBuilderItems[i].trim(), nameSpace);
				String rError = Constants.ValidationErrorCriticality.replace("[i]", "[" + (i + 1 + rfPassLength
						+ rfFailLength + fnPassLength + fnFailLength + tPassLength + tFailLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(rError), "I", nameSpace);
				log.debug("Completed passedRuleBuilderItems.");
			}
		}

		if (failedRuleBuilderItems.length != 0 && !failedRuleBuilderItems[0].replaceAll("\\s+", "").isEmpty()) {
			rFailLength = failedRuleBuilderItems.length;

			for (int i = 0; i < failedRuleBuilderItems.length; i++) {

				String rDescription = Constants.ValidationDescription.replace("[i]", "[" + (i + 1 + rfPassLength
						+ rfFailLength + fnPassLength + fnFailLength + tPassLength + tFailLength + rPassLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(rDescription),
						"Error-" + failedRuleBuilderItems[i].trim(), nameSpace);
				String rError = Constants.ValidationErrorCriticality.replace("[i]", "[" + (i + 1 + rfPassLength
						+ rfFailLength + fnPassLength + fnFailLength + tPassLength + tFailLength + rPassLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(rError), "E", nameSpace);
				log.debug("Completed failedRuleBuilderItems.");
			}
		}

		// Creating ValidationMessage for Required Form List

		if (requiredFormListItems.length != 0 && !requiredFormListItems[0].replaceAll("\\s+", "").isEmpty()) {

			for (int i = 0; i < requiredFormListItems.length; i++) {

				String rflDescription = Constants.ValidationDescription.replace("[i]",
						"[" + (i + 1 + rfPassLength + rfFailLength + fnPassLength + fnFailLength + tPassLength
								+ tFailLength + rPassLength + rFailLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(rflDescription),
						"Required Form-" + requiredFormListItems[i].trim(), nameSpace);
				String rflError = Constants.ValidationErrorCriticality.replace("[i]",
						"[" + (i + 1 + rfPassLength + rfFailLength + fnPassLength + fnFailLength + tPassLength
								+ tFailLength + rPassLength + rFailLength) + "]");
				XMLCreationUtils.addElementToParent(document, prependBase(rflError), "I", nameSpace);
				log.debug("Completed requiredFormListItems.");
			}
		}

		// Xpaths with unique condition.
		String hql = "SELECT xmlfields FROM XMLFields xmlfields WHERE xmlfields.fieldName = :fieldName";
		Query query = session.createQuery(hql);

		addDocumentIdToDocument(document, query, log);
		log.debug("DocumentId added to ACCR document");

		addContractMvpToDocument(document, query, log);
		log.debug("ContractMvp added to ACCR document");

		/*
		 * In the ResponseMapping table, if the fieldCondition is not null, a record
		 * with where clause fieldName = fieldNameCondition would be selected from
		 * XMLFields table. If the fieldValue from ResponseMapping is equal to the
		 * fieldValue from XMLFields, then the record with where clause fieldName =
		 * fieldName(From ResponseMapping) would be selected from XMLFields Table and
		 * the fieldValue of this record would be xml value for the corresponding
		 * responseXpath. If the fieldCondition is null, the record with where clause
		 * fieldName = fieldName(from ResponseMapping) would be selected from XMLFields
		 * table and the fieldValue of this record would be the final xml value.
		 */
		addElementToParentXMLFromResponseMapping(responseMappingList, session, query, document, log);
		log.debug("Elements from response mapping added to ACCR document");

		String stringXML = null;

		try {

			/*
			 * Convert dom4j document to w3c document. Use setAttribute method to add
			 * attribute to the existing elements.
			 */

			org.w3c.dom.Document w3cDoc = new DOMWriter().write(document);

			org.w3c.dom.Element upfrontMileageRateElement = (org.w3c.dom.Element) w3cDoc
					.getElementsByTagName("ns3:UpfrontMileageRate").item(0);
			if (upfrontMileageRateElement != null) {
				query.setParameter("fieldName", "ProgramsAndRatesUpfrontMileageRatecurrency");
				List<XMLFields> resultRateCurrency = query.getResultList();
				String rateCurrency = resultRateCurrency.get(0).getFieldValue();
				upfrontMileageRateElement.setAttribute("currency", rateCurrency);
				log.debug("Completed upfrontMileageRateElement.");
			}

			org.w3c.dom.Element upfrontMilesElement = (org.w3c.dom.Element) w3cDoc
					.getElementsByTagName("ns3:UpfrontMiles").item(0);
			if (upfrontMilesElement != null) {
				query.setParameter("fieldName", "ProgramsAndRatesUpfrontMilesuom");
				List<XMLFields> resultUOM = query.getResultList();
				String uom = resultUOM.get(0).getFieldValue();
				upfrontMilesElement.setAttribute("uom", uom);
				log.debug("Completed upfrontMilesElement.");
			}

			org.w3c.dom.Element upfrontMilesAmountElement = (org.w3c.dom.Element) w3cDoc
					.getElementsByTagName("ns3:UpfrontMilesAmount").item(0);
			if (upfrontMilesAmountElement != null) {
				query.setParameter("fieldName", "ProgramsAndRatesUpfrontMilesAmountcurrency");
				List<XMLFields> resultAmountCurrency = query.getResultList();
				String amountCurrency = resultAmountCurrency.get(0).getFieldValue();
				upfrontMilesAmountElement.setAttribute("currency", amountCurrency);
				log.debug("Completed upfrontMilesAmountElement.");
			}

			stringXML = XMLCreationUtils.doctoString(w3cDoc);

			if (stringXML.contains("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>")) {
				stringXML = stringXML.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>", "");
			} else if (stringXML.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {
				stringXML = stringXML.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
			}

			stringXML = stringXML.replace("payload", "ns1:payload");
			stringXML = stringXML.replace("ns3:content", "ns1:content");
			stringXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'><soap:Body>"
					+ "<ns1:ProcessMessageResponse xmlns:ns1='http://www.starstandards.org/webservices/2005/10/transport' "
					+ "xmlns:ns2='http://www.starstandards.org/STAR' xmlns:ns3='http://www.starstandards.org/STARACCR'>"
					+ stringXML + "</ns1:ProcessMessageResponse></soap:Body></soap:Envelope>";

		} catch (final Exception e) {
			log.error("Exception caught while generating ACCR XML", e);
		}

		ResponseXML responseXML = new ResponseXML();
		responseXML.setLteOutput(stringXML);

		responseXML.setXmlId(rulesEngineBO.getProcessAudit().getXmlId());

		Timestamp responseEndTime = new Timestamp(System.currentTimeMillis());

		processAudit.setXmlId(rulesEngineBO.getProcessAudit().getXmlId());
		processAudit.setOutputXMLStart(responseStartTime);
		processAudit.setOutputXMLEnd(responseEndTime);
		processAudit.setOutputXMLResult(stringXML);
		processAudit.setEtlEnd(responseEndTime);
		processAudit.setEtlStart(rulesEngineBO.getProcessAudit().getEtlStart());
		processAudit.setEtlEnd(rulesEngineBO.getProcessAudit().getEtlEnd());

		if (stringXML != null) {
			responseXML.setAccrXml(stringXML);
			log.info("Response XML has been created successfully");

		}

		HashMap<String, Object> mapResponseProcessAudit = new HashMap<>();
		mapResponseProcessAudit.put("ResponseXML", responseXML);
		mapResponseProcessAudit.put("ProcessAudit", processAudit);
		
		LocalDateTime end = LocalDateTime.now();
		log.debug("buildACCR took " + ChronoUnit.MILLIS.between(start, end) + " MILLISECONDS");

		return mapResponseProcessAudit;
	}

	/**
	 * @param document
	 * @param query
	 * @param log
	 */
	private static void addContractMvpToDocument(final Document document, final Query query, final Logger log) {
		log.debug("Entered addContractMvpToDocument() method of ACCRXMLUtils class.");
		Namespace nameSpace = new Namespace("ns3", "");
		query.setParameter("fieldName", "ProgramDescription");
		List<XMLFields> resultProgramDescription = query.getResultList();

		if (!resultProgramDescription.isEmpty()
				&& resultProgramDescription.get(0).getFieldValue().equals("Spot Program")) {
			query.setParameter("fieldName", "ProgramSpecial");
			List<XMLFields> resultProgramSpecial = query.getResultList();
			String detail = resultProgramSpecial.get(0).getFieldValue();
			String contractMvpValue = detail.substring(detail.length() - 1);
			XMLCreationUtils.addElementToParent(document, prependBase(Constants.CONTRACTMVPXPATH), contractMvpValue,
					nameSpace);
		}

	}

	/**
	 * @param document
	 * @param session
	 */
	private static void addDocumentIdToDocument(final Document document, final Query query, final Logger log) {
		log.debug("Entered addDocumentIdToDocument() method of ACCRXMLUtils class.");
		query.setParameter("fieldName", "LenderPartyId");
		Namespace nameSpace = new Namespace("ns3", "");
		List<XMLFields> resultPartyId = query.getResultList();
		if (!resultPartyId.isEmpty()) {
			String partyIdValue = resultPartyId.get(0).getFieldValue();
			long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
			String documentIdValue = partyIdValue + number;

			XMLCreationUtils.addElementToParent(document, prependBase(Constants.DOCUMENTIDXPATH), documentIdValue,
					nameSpace);
		}

	}

	/**
	 * @param responseMappingList
	 * @param session
	 * @param query
	 * @param document
	 */
	public static void addElementToParentXMLFromResponseMapping(final List<ResponseMapping> responseMappingList,
			final Session session, final Query query, final Document document, final Logger log) {
		log.debug("Entered addElementToParentXMLFromResponseMapping() method of ACCRXMLUtils class.");
		String nodeValue = "";
		Namespace nameSpace = new Namespace("ns3", "");

		try {
			for (ResponseMapping mapping : responseMappingList) {

				String xpath = mapping.getResponseXpath();
				String fieldName = mapping.getFieldName();
				String fieldNameCondition = mapping.getFieldNameCondition();
				String fieldNameValue = mapping.getFieldValue();

				if (fieldNameCondition != null && !fieldNameCondition.isEmpty()) {
					String hqlCondition = "SELECT xmlfields FROM XMLFields xmlfields WHERE xmlfields.fieldName = :fieldNameCondition";
					Query queryCondition = session.createQuery(hqlCondition);
					queryCondition.setParameter("fieldNameCondition", fieldNameCondition);
					List<XMLFields> resultFieldNameCondition = queryCondition.getResultList();
					if (!resultFieldNameCondition.isEmpty()
							&& resultFieldNameCondition.get(0).getFieldValue().equals(fieldNameValue)) {
						query.setParameter("fieldName", fieldName);
						List<XMLFields> resultfieldName = query.getResultList();
						if (!resultfieldName.isEmpty()) {
							nodeValue = resultfieldName.get(0).getFieldValue();

							XMLCreationUtils.addElementToParent(document, prependBase(xpath), nodeValue, nameSpace);
						}
					}
				} else {
					query.setParameter("fieldName", fieldName);
					List<XMLFields> resultList = query.getResultList();
					if (!resultList.isEmpty()) {
						nodeValue = resultList.get(0).getFieldValue();
						XMLCreationUtils.addElementToParent(document, prependBase(xpath), nodeValue, nameSpace);
					}
				}
			}
		} catch (final Exception e) {

			log.debug("Exception caught within addElementToParentXMLFromResponseMapping method of ACCRXMLUtils class.",
					e);
		}

		log.debug("Exit addElementToParentXMLFromResponseMapping() method of ACCRXMLUtils class.");

	}

	/**
	 * @param string
	 * @return
	 */
	private static String prependBase(String string) {
		return Constants.BASE_XPATH + string;
	}
}
