package com.ode.exchange.re.etlutils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Namespace;
import org.dom4j.io.DOMWriter;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.BODMapping;
import com.ode.exchange.re.etlentity.RulesEngineBO;
import com.ode.exchange.re.etlentity.XMLFields;

@Transactional
public  class BODXMLUtils {
	
	private final Logger log = LoggerFactory.getLogger(BODXMLUtils.class);
		
	/**
	 * @param rulesEngineBO
	 * @param bodMappingList
	 * @param session
	 * @param log
	 * @return
	 */
	public static String confirmBOD(RulesEngineBO rulesEngineBO, 
			List<BODMapping> bodMappingList, Session session, Logger log) {
		
		log.debug("Entered confirmBOD() method of BODXMLUtils class");
		
		Namespace nameSpace = new Namespace("", "");

		Document document = DocumentHelper.createDocument(DocumentHelper.createElement(Constants.BOD_ROOT));

		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_APPAREA_COMPONENT, "CV", nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_APPAREA_TASK, "ConfirmBOD", nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_APPAREA_CREATORNAMECODE, "ODE",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_APPAREA_SENDERNAMECODE, "ODE", nameSpace);

		Timestamp now = new Timestamp(System.currentTimeMillis());
		Date date = new Date();
		date.setTime(now.getTime());
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);

		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_APPAREA_CREATIONDATETIME, timeStamp,
				nameSpace);

		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_APPAREA_DESTINATIONNAMECODE, "CV",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_CONFIRM, " ", nameSpace); 
		// check the above one is just coming as </confirm> without <confirm>
		 
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_COMPONENT, "eValidation",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_TASK, "CreditContract",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_AUTHORIZATIONID, "RE",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_CREATORNAMECODE, "ODE",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_SENDERNAMECODE, "ODE",
				nameSpace);

		Timestamp now2 = new Timestamp(System.currentTimeMillis());
		Date date2 = new Date();
		date2.setTime(now2.getTime());
		String timeStamp2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date2);

		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_CREATIONDATETIME, timeStamp2,
				nameSpace);

		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_DESTINATIONNAMECODE, "CV",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_SUCCESS_APPREASONCODE, "I0000",
				nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_SUCCESS_DESCRIPTION,
				"Operation Successful", nameSpace);
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_SUCCESS_MESSAGEREASONCODE,
				"Other", nameSpace);
		
		Long xmlid = rulesEngineBO.getProcessAudit().getXmlId();
		
		XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + Constants.BOD_DATAAREA_BODID,
				String.valueOf(xmlid), nameSpace);

		String hql = "SELECT xmlfields FROM XMLFields xmlfields WHERE xmlfields.fieldName = :fieldName";
		Query query = session.createQuery(hql);
		String nodeValue = "";
		
		/*
		 * In the BODMapping table, the record with where clause fieldName = fieldName(from BODMapping) 
		 * would be selected from XMLFields table and the fieldValue of this record would be the final xml 
		 * value for the corresponding BODXpath.
		 */

		for (BODMapping mapping : bodMappingList) {

			String xpath = mapping.getBodXpath();
			String fieldName = mapping.getFieldName();
			query.setParameter("fieldName", fieldName);
			List<XMLFields> resultList = query.getResultList();
			if (!resultList.isEmpty()) {
				nodeValue = resultList.get(0).getFieldValue();
				XMLCreationUtils.addElementToParent(document, "/" + Constants.BOD_ROOT + xpath, nodeValue, nameSpace);
			}
			else
			{
				log.debug("No rows were returned from XMLFields table!");
			}
		}

		String stringXML = null;

		try {

			/*
			 * Convert dom4j document to w3c document. Use setAttribute method to add
			 * attribute to the existing elements.
			 */

			org.w3c.dom.Document w3cDoc = new DOMWriter().write(document);

			stringXML = XMLCreationUtils.doctoString(w3cDoc);
			
		} catch (Exception e) {
			log.error(e.toString());
		}
		
		log.debug("Exit confirmBOD() method of BODXMLUtils class");

		return stringXML;
	}
}
