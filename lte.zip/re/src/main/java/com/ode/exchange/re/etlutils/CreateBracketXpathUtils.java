package com.ode.exchange.re.etlutils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.ode.exchange.re.etlentity.XpathValueGroupLevel;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.List;

public class CreateBracketXpathUtils {
	
	private static final Logger log = LoggerFactory.getLogger(CreateBracketXpathUtils.class);

	/**
	 * @param xml
	 * @param xpathValueList
	 * @return
	 * @throws Exception
	 */
	public static Document createWithBracketElement(String xml, List<XpathValueGroupLevel> xpathValueList)
			throws Exception {
		log.debug("Enter createWithBracketElement() method of CreateBracketXpathUtils class");
		InputSource source = new InputSource(new StringReader(xml));

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		org.w3c.dom.Document w3cdocument = db.parse(source);
		
		int xpathValueListSize = xpathValueList.size();
		log.debug("xpathValueListSize: {}", xpathValueListSize);

		for (int j = 0; j < xpathValueListSize; j++) {

			String xpath = xpathValueList.get(j).getXpath();
			String value = xpathValueList.get(j).getValue();

			Node node = LTEXMLUtils.nodeExist(w3cdocument, xpath);
			
			if (node == null && xpath.contains("[@"))
			{
				createElementWithAtrribute(w3cdocument, xpath, value);
				
			} else if (node == null && xpath.contains("[")) {
				String xpathInput = createXpathToCheck(xpath);
				log.debug("xpathInput: {}", xpathInput);
				XPath xpathfac = XPathFactory.newInstance().newXPath();
				XPathExpression expr = xpathfac.compile(xpathInput);

				Node blockContainingTargetNode = (Node) expr.evaluate(w3cdocument, XPathConstants.NODE);

				if (blockContainingTargetNode != null) {
					
					log.debug("blockContainingTargetNode is not null");
					Node targetNode = w3cdocument.createElement(getFinalElement(xpath));	
					targetNode.appendChild(w3cdocument.createTextNode(value));
					blockContainingTargetNode.appendChild(targetNode);

				} else {

					// parentXpath is the xpath before the block containing target node
					String parentXpath = getParentPath(xpathInput);
					XPath xpathfacP = XPathFactory.newInstance().newXPath();
					XPathExpression exprP = xpathfacP.compile(parentXpath);
					
					// parentNode is the last node of parentXpath or the node before block containing targetNode
					Node parentNode = (Node) exprP.evaluate(w3cdocument, XPathConstants.NODE);
					Node blockParentNode = w3cdocument.createElement(getFirstNewNode(xpath));
					try {
						Node blockParentNodeIdentifier = w3cdocument.createElement(getInsideBracketElementName(xpath));					
						blockParentNodeIdentifier.appendChild(w3cdocument.createTextNode(getInsideBracketElementValue(xpath)));
						blockParentNode.appendChild(blockParentNodeIdentifier);
					} catch (Exception e) {
						log.debug("Caught exception when working on blockParentNodeIdentifier. xpath: {}", xpath, e);
					}
					try {
						Node targetNode = w3cdocument.createElement(getFinalElement(xpath));
						targetNode.appendChild(w3cdocument.createTextNode(value));
						blockParentNode.appendChild(targetNode);
					} catch (Exception e) {
						log.debug("Caught exception when working on targetNode. xpath: {}", xpath, e);
					}
					if (null != parentNode) {
						parentNode.appendChild(blockParentNode);
					}
				}

				return w3cdocument;
			}
		}

		return w3cdocument;
	}

	/**
	 * @param w3cdocument
	 * @param value 
	 * @throws XPathExpressionException 
	 */
	public static void createElementWithAtrribute(final Document w3cdocument,final String xpathInput, final String value) throws XPathExpressionException {
		log.debug("Enter createElementWithAtrribute() method of CreateBracketXpathUtils class");
		String attributeString;
		String xpathWithoutAttribute;
		String xpath;
		log.debug("Xpath containing '[@': {}", xpathInput);
		attributeString = "";
		int pos = xpathInput.lastIndexOf("[@");
		attributeString = xpathInput.substring(pos);
		xpathWithoutAttribute = xpathInput.substring(0, pos);
		log.debug("xpath after removing attribute string: {}", xpathWithoutAttribute);
		log.debug("attributeString: {}", attributeString);
		
		String parentXpath = getParentPath(xpathWithoutAttribute);
		log.debug("parentXpath: {}", parentXpath);
		XPath xpathfacP = XPathFactory.newInstance().newXPath();
		XPathExpression exprP = xpathfacP.compile(parentXpath);
		
		// parentNode is the last node of parentXpath or the node before block containing targetNode
		Node parentNode = (Node) exprP.evaluate(w3cdocument, XPathConstants.NODE);
		if (null == parentNode)
		{
			log.debug("parentNode is null, creating parentNode");
			String grandParentXpath = getParentPath(parentXpath);
			log.debug("grandParentXpath: {}", grandParentXpath);			
			exprP = xpathfacP.compile(grandParentXpath);
			Node grandParentNode = (Node) exprP.evaluate(w3cdocument, XPathConstants.NODE);
			if (null != grandParentNode)
			{
				parentNode = w3cdocument.createElement(getFinalElement(parentXpath));
				grandParentNode.appendChild(parentNode);
			}
		}
		Node targetNode = w3cdocument.createElement(getFinalElement(xpathWithoutAttribute));
		targetNode.appendChild(w3cdocument.createTextNode(value));
		
		if (StringUtils.isNotBlank(attributeString)) {
			attributeString = attributeString.replace("[@", "");
			attributeString = attributeString.replace("]", "");
			String[] attributeTokens = attributeString.split("=");
			Element targetElement = (Element) targetNode;
			targetElement.setAttribute(attributeTokens[0], StringUtils.substringBetween(attributeTokens[1], "'", "'"));
		}
		if (null != parentNode)
		{
			parentNode.appendChild(targetNode);
		}
		else
		{
			log.debug("Could not add element, parentNode was null");
		}

		
	}

	public static String getParentPath(String inputXpath) {
		
		String[] xpathArray = inputXpath.split("/");
		String ParentPath = "";
		
		for (int i = 0; i < xpathArray.length; i++) {
			
			if (i <= xpathArray.length - 3) {
				
				ParentPath = ParentPath + xpathArray[i] + "/";
			} 
			else if (i == xpathArray.length - 2) {
				
				ParentPath = ParentPath + xpathArray[i];
			}
		}
		return ParentPath;
	}

	public static String getFirstNewNode(String inputXpath) {
		
		String[] xpathArray = inputXpath.split("\\[");
		String[] xpathArray2 = xpathArray[0].split("/");
		
		return xpathArray2[xpathArray2.length - 1];
	}

	/**
	 * @param inputXpath
	 * @return
	 */
	public static String getInsideBracketElementName(String inputXpath) {
		
		log.debug("Enter getInsideBracketElementName() method of CreateBracketXpathUtils class");
		
		String result = StringUtils.substringBetween(inputXpath, "[", "]");
		String[] arr = result.split("=");
		String bracketElementName = arr[0];
		if (StringUtils.isNotBlank(bracketElementName) && bracketElementName.length() >= 2 && bracketElementName.startsWith("@") )
		{
			bracketElementName = bracketElementName.substring(1);
		}
		log.debug("Exit getInsideBracketElementName() method. bracketElementName: {}", bracketElementName);
		return bracketElementName;
	}

	public static String getInsideBracketElementValue(String inputXpath) {
		
		log.debug("Enter getInsideBracketElementValue() method of CreateBracketXpathUtils class");
		
//		String result = StringUtils.substringBetween(inputXpath, "[", "]");
		
		return StringUtils.substringBetween(inputXpath, "'", "'");
	}

	public static String getFinalElement(String inputXpath) {
		
		String[] xpathArray = inputXpath.split("/");
		
		return xpathArray[xpathArray.length - 1];
	}

	public static String createXpathToCheck(String inputXpath) {
		
		String[] xpathArray = inputXpath.split("\\]");
		
		return xpathArray[0] + "]";
	}
}
