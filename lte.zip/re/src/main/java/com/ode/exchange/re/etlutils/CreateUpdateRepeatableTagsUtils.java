package com.ode.exchange.re.etlutils;

import java.io.StringReader;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.dom4j.DocumentHelper;
import org.dom4j.Namespace;

import com.ode.exchange.re.etlentity.XpathValueGroupLevel;

public class CreateUpdateRepeatableTagsUtils {

	public static String updateRepeatableTag(Document w3cdocument, List<XpathValueGroupLevel> xpathValueList)
			throws Exception {

		for (int k = 0; k < xpathValueList.size(); k++) {

			String xpath = xpathValueList.get(k).getXpath();
			String value = xpathValueList.get(k).getValue();
			int groupId = xpathValueList.get(k).getGroupLevel();
			
			if (groupId > 0) {
				
				// breaking given xpath with /
				String[] splittedPath = xpath.split("/");
				String parentNodeXpath = "";
				String lastNode = "";

				for (int i = 0; i < splittedPath.length; i++) {

					if (i < splittedPath.length - 2) {

						parentNodeXpath = parentNodeXpath + splittedPath[i] + "/";
						
					} else if (i == splittedPath.length - 2) {

						parentNodeXpath = parentNodeXpath + splittedPath[i];
						
					} else {

						lastNode = splittedPath[splittedPath.length - 1];
					}

				}

				XPath xpathfac = XPathFactory.newInstance().newXPath();
				XPathExpression expr = xpathfac.compile(parentNodeXpath);

				NodeList dealerProductsNodeListqq = (NodeList) expr.evaluate(w3cdocument, XPathConstants.NODESET);
				Node dealerProductsElementee = (Node) dealerProductsNodeListqq.item(groupId - 1);
				
				if (dealerProductsElementee != null) {
					
					for (int j = 0; j < dealerProductsElementee.getChildNodes().getLength(); j++) {

						Node childNode = (Node) dealerProductsElementee.getChildNodes().item(j);

						if (childNode.getNodeName().equals(lastNode)) {
							
							childNode.setTextContent(value);
						}
					}
				}
			}
		}
		return XMLCreationUtils.doctoString(w3cdocument);
	}

	public static String createRepeatableTags(String xml, List<XpathValueGroupLevel> xpathValueList) throws Exception {

		org.dom4j.Document dom4jdocument = DocumentHelper.parseText(xml);
		Namespace nameSpace = new Namespace("", "");
			
		InputSource source = new InputSource(new StringReader(xml));

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		org.w3c.dom.Document w3cdocument = db.parse(source);
		

		
		for (int k = 0; k < xpathValueList.size(); k++) {

			String xpath = xpathValueList.get(k).getXpath();
			String value = xpathValueList.get(k).getValue();
			int groupId = xpathValueList.get(k).getGroupLevel();
			
			String parentXpath = getParentPath(xpath);
			XPath xpathfac = XPathFactory.newInstance().newXPath();
			XPathExpression expr = xpathfac.compile(parentXpath);

			NodeList blockNodeList = (NodeList) expr.evaluate(w3cdocument, XPathConstants.NODESET);
			int totalNumberOfBlocks = blockNodeList.getLength();
			
			if (groupId > 0) {

				String block = "";
				String[] xpathArray = xpath.split("/");

				for (int i = 0; i < xpathArray.length; i++) {

					if (i < xpathArray.length - 2) {

						block = block + xpathArray[i] + "/";

					} else if (i == xpathArray.length - 2) {

						block = block + xpathArray[i];

						// At least a block of repeatable is present in request xml like Fee Block
						if (LTEXMLUtils.nodeExist(w3cdocument, xpath) != null) {

							int newNodeGroupLevel = totalNumberOfBlocks + 1;
							block = block + "[" + newNodeGroupLevel + "]/";
						
						} 
						// The requested repeatable block is not present in request xml like OtherCharges Block
						else {
							
							block = block + "[" + groupId + "]/";
						}

					} else {

						block = block + xpathArray[i];
					}
				}

				XMLCreationUtils.addElementToParent(dom4jdocument, block, value, nameSpace);
			}
		}
		return dom4jdocument.asXML();
	}
	
	public static String getParentPath(String inputXpath) {
		
		String[] xpathArray = inputXpath.split("/");
		String ParentPath = "";
		
		for (int i = 0; i < xpathArray.length; i++) {
			
			if (i <= xpathArray.length - 3) {
				
				ParentPath = ParentPath + xpathArray[i] + "/";
			} 
			else if (i == xpathArray.length - 2) {
				
				ParentPath = ParentPath + xpathArray[i];
			}
		}
		return ParentPath;
	}	
}
