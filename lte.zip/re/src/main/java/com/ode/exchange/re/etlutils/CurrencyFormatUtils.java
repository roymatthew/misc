package com.ode.exchange.re.etlutils;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ode.exchange.re.entity.ETLConfiguration;

@Component
public class CurrencyFormatUtils {

	private static final Logger log = LogManager.getLogger(CurrencyFormatUtils.class);

	@Autowired
	private com.ode.exchange.re.etlrepository.IETLConfigurationRepo etlConfigurationRepo;

	public String applyCurrencyFormat(final String xmlString) throws Exception {
		final LocalDateTime start = LocalDateTime.now();
		log.debug("Enter applyCurrencyFormat() method of CurrencyFormatUtils class");
		final Document document = XMLCreationUtils.getDocumentFromXmlString(xmlString);
		List<com.ode.exchange.re.entity.ETLConfiguration> listOfCurrencyFields = etlConfigurationRepo
				.findAllCurrencyFields();
		if (null == listOfCurrencyFields || listOfCurrencyFields.isEmpty()) {
			return xmlString;
		} else {
			log.debug("Count of currency fileds: {}", listOfCurrencyFields.size());
		}
		listOfCurrencyFields.forEach(etl -> {

			javax.xml.xpath.XPath xpath = XPathFactory.newInstance().newXPath();
			String xpathExpr = etl.getxPath();
			int currIndex = xpathExpr.indexOf("@currency");
			if (currIndex > 0) {

				xpathExpr = xpathExpr.substring(0, currIndex - 1);
			}
			if (xpathExpr.indexOf("\\") > 0) {
				xpathExpr = xpathExpr.replace("\\", "/");
			}
			try {
				XPathExpression expr = xpath.compile(xpathExpr);
				org.w3c.dom.NodeList nodeList = (org.w3c.dom.NodeList) expr.evaluate(document, XPathConstants.NODESET);
				if (null != nodeList && nodeList.getLength() > 0) {
					for (int i = 0; i < nodeList.getLength(); i++) {
						org.w3c.dom.Node node = nodeList.item(i);
						if (node instanceof Element) {
							Element element = (Element) node;
							String formattedAmount = NumberFormatUtils
									.getAmountRoundedToTwoDecimalPlacesAsString(element.getTextContent());
							element.setTextContent(formattedAmount);
							if (null == element.getAttributes().getNamedItem("currency")) {
								element.setAttribute("currency", "USD");
							}

						}
					}

				}
			} catch (Exception e) {
				log.debug("Exception caught when evaluating xpath: {}", etl.getxPath(), e);
			}
		});
		final LocalDateTime end = LocalDateTime.now();
		log.debug("***** End applyCurrencyFormat at: " + end + " *****");
		log.debug("applyCurrencyFormat took " + ChronoUnit.MILLIS.between(start, end) + " MILLISECONDS");
		return XMLCreationUtils.doctoString(document);
	}

}
