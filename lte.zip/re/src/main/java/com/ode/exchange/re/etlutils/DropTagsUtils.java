package com.ode.exchange.re.etlutils;

import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlentity.XpathValueGroupLevel;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * @author Anantics 
 * rmathew 10/12/2020 (modified this class)
 *
 */
public class DropTagsUtils {
	private final static Logger log = LoggerFactory.getLogger(DropTagsUtils.class);

	/**
	 * @param xml
	 * @param translatedDropList
	 * @param translatedDropSetList
	 * @param etlMappingList
	 * @return
	 * @throws Exception
	 */
	public static String implementDrop(String xml, LinkedHashMap<String, List<Integer>> translatedDropList,
			LinkedHashMap<String, List<Integer>> translatedDropSetList, List<ETLMapping> etlMappingList)
					throws Exception {

		List<XpathValueGroupLevel> fieldNameGroupIdDropList = DropTagsUtils
				.getDropFieldGroupFromTranslationPath(translatedDropList);

		List<XpathValueGroupLevel> xpathgroupDropList = LTEXMLUtils.getXpathFromFieldName(etlMappingList,
				fieldNameGroupIdDropList);

		List<XpathValueGroupLevel> fieldNameGroupIdDropSetList = DropTagsUtils
				.getDropFieldGroupFromTranslationPath(translatedDropSetList);

		List<XpathValueGroupLevel> xpathgroupDropSetList = LTEXMLUtils.getXpathFromFieldName(etlMappingList,
				fieldNameGroupIdDropSetList);

		Document docafterdropregular = dropRegularTag(xml, xpathgroupDropList);

		Document docafterdroprepeatable = dropRepeatableTag(docafterdropregular, xpathgroupDropList);

		String xmlAfterDropSet = dropSetRepeatableBlock(docafterdroprepeatable, xpathgroupDropSetList);

		return xmlAfterDropSet;
	}

	/**
	 * @param xml
	 * @param xpathGroupIdDropList
	 * @return
	 * @throws Exception
	 */
	public static Document dropRegularTag(String xml, List<XpathValueGroupLevel> xpathGroupIdDropList)
			throws Exception {
		log.info("Entering dropRegularTag();");

		InputSource source = new InputSource(new StringReader(xml));

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		org.w3c.dom.Document w3cdocument = db.parse(source);

		for (int i = 0; i < xpathGroupIdDropList.size(); i++) {

			String xpath = xpathGroupIdDropList.get(i).getXpath();
			int groupId = xpathGroupIdDropList.get(i).getGroupLevel();
			log.debug("Log group id : {}", groupId);

			if (groupId == 0) {

				XPath xpathfac = XPathFactory.newInstance().newXPath();
				XPathExpression expr = xpathfac.compile(xpath);
				log.debug("xpath : {}", xpath);

				Node targetNode = (Node) expr.evaluate(w3cdocument, XPathConstants.NODE);
				if (null != targetNode)
				{
					log.debug("targetNode to drop : {}", targetNode.getNodeName());
					targetNode.getParentNode().removeChild(targetNode);
				}
				else
				{
					log.debug("targetNode to drop could not be found!");
				}
				
			}
		}

		return w3cdocument;
	}

	/**
	 * @param w3cdocument
	 * @param xpathGroupIdDropList
	 * @return
	 * @throws Exception
	 */
	public static Document dropRepeatableTag(Document w3cdocument, List<XpathValueGroupLevel> xpathGroupIdDropList)
			throws Exception {
		log.debug("Enter dropRepeatableTag() method of DropTagsUtils class");

		List<Node> removeableTagList = new ArrayList<>();

		// drop repeatable element from one of the repeatable blocks
		for (int i = 0; i < xpathGroupIdDropList.size(); i++) {

			String xpath = xpathGroupIdDropList.get(i).getXpath();
			int groupId = xpathGroupIdDropList.get(i).getGroupLevel();

			if (groupId > 0) {

				XPath xpathfac = XPathFactory.newInstance().newXPath();
				XPathExpression expr = xpathfac.compile(xpath);

				NodeList nodeListContainingTargetNode = (NodeList) expr.evaluate(w3cdocument, XPathConstants.NODESET);

				Node targetNode = nodeListContainingTargetNode.item(groupId - 1);

				removeableTagList.add(targetNode);
			}
		}

		for (int i = 0; i < removeableTagList.size(); i++) {

			removeableTagList.get(i).getParentNode().removeChild(removeableTagList.get(i));
		}

		return w3cdocument;
	}

	/**
	 * @param w3cdocument
	 * @param xpathGroupIdDropSetList
	 * @return
	 * @throws Exception
	 */
	public static String dropSetRepeatableBlock(Document w3cdocument,
			List<XpathValueGroupLevel> xpathGroupIdDropSetList) throws Exception {
		
		log.debug("Enter dropSetRepeatableBlock() method of DropTagsUtils class");

		List<Node> removeableTagList = new ArrayList<>();

		// drop a set of the repeatable blocks containing a given groupLevel

		for (int i = 0; i < xpathGroupIdDropSetList.size(); i++) {

			String xpath = xpathGroupIdDropSetList.get(i).getXpath();
			
			log.debug("xpath: {}", xpath);

			int groupId = xpathGroupIdDropSetList.get(i).getGroupLevel();
			
			log.debug("groupId: {}", groupId);
			
			String parentXpath = getParentPath(xpath);
			log.debug("parentXpath: {}", parentXpath);
			XPath xpathfac1 = XPathFactory.newInstance().newXPath();
			XPathExpression expr1 = xpathfac1.compile(parentXpath);

			if (groupId > 0) {

				NodeList nodeListContainingChildTragetNode = (NodeList) expr1.evaluate(w3cdocument, XPathConstants.NODESET);

				Node childTargetNode = nodeListContainingChildTragetNode.item(groupId - 1);

				removeableTagList.add(childTargetNode);
			}
			else
			{
				Node parentNode = (Node) expr1.evaluate(w3cdocument, XPathConstants.NODE);
				removeableTagList.add(parentNode);
				log.debug("Added node: {} to removeableTagList", parentNode.getNodeName());
			}
		}

		for (int i = 0; i < removeableTagList.size(); i++) {

			removeableTagList.get(i).getParentNode().removeChild(removeableTagList.get(i));
		}

		return XMLCreationUtils.doctoString(w3cdocument);
	}

	/**
	 * @param dropList
	 * @return
	 */
	public static List<XpathValueGroupLevel> getDropFieldGroupFromTranslationPath(
			LinkedHashMap<String, List<Integer>> dropList) {

		List<XpathValueGroupLevel> xpathValueGroupList = new ArrayList<>();

		for (Map.Entry<String, List<Integer>> entry : dropList.entrySet()) {

			String fieldName = entry.getKey();
			List<Integer> groupLevel = entry.getValue();

			if (groupLevel.size() == 1) {

				XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();
				lteEntityItem.setFieldName(fieldName);
				lteEntityItem.setGroupLevel(groupLevel.get(0));
				xpathValueGroupList.add(lteEntityItem);
			}

			if (groupLevel.size() > 1) {

				for (int i = 0; i < groupLevel.size(); i++) {

					XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();
					lteEntityItem.setFieldName(fieldName);
					lteEntityItem.setGroupLevel(groupLevel.get(i));
					xpathValueGroupList.add(lteEntityItem);
				}
			}

		}

		return xpathValueGroupList;
	}

	public static String getParentPath(String inputXpath) {

		String[] xpathArray = inputXpath.split("/");
		String ParentPath = "";

		for (int i = 0; i < xpathArray.length; i++) {

			if (i <= xpathArray.length - 3) {

				ParentPath = ParentPath + xpathArray[i] + "/";

			} else if (i == xpathArray.length - 2) {

				ParentPath = ParentPath + xpathArray[i];
			}
		}
		return ParentPath;
	}
}
