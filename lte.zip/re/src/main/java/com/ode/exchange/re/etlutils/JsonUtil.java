package com.ode.exchange.re.etlutils;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.exchange.re.entity.MapperResult;
import com.ode.exchange.re.entity.RegulationRuleLogicExpression;

public class JsonUtil {
	private static final Logger log = LoggerFactory.getLogger(JsonUtil.class);
	
	public static MapperResult mapJson(String ruleLogic) {
		RegulationRuleLogicExpression[] ruleExpression = null;
		ObjectMapper mapper = new ObjectMapper();
		MapperResult result = new MapperResult();
		boolean proceed = false;
		
		// Convert JSON to Object
		try {
			ruleExpression = mapper.readValue(ruleLogic, RegulationRuleLogicExpression[].class);
			proceed = true;
		} catch (JsonParseException e) {
			log.debug("Rule Expression processing failed!. Failed Rule: {}. ", ruleLogic);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			log.debug("Rule Expression processing failed!. Failed Rule: {}. ", ruleLogic);
			e.printStackTrace();
		} catch (IOException e) {
			log.debug("Rule Expression processing failed!. Failed Rule: {}. ", ruleLogic);
			e.printStackTrace();
		}
		
		result.setProceed(proceed);
		result.setRuleExpression(ruleExpression);
		return result;
	}
}
