package com.ode.exchange.re.etlutils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.entity.CreditDecision;
import com.ode.exchange.re.entity.MapperResult;
import com.ode.exchange.re.entity.RegulationRuleLogicExpression;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlentity.LTErule;
import com.ode.exchange.re.etlentity.LookUpCriteriaPassRulesLTE;
import com.ode.exchange.re.etlentity.StringentRuleQualificationLTE;
import com.ode.exchange.re.etlentity.TranslationPath;
import com.ode.exchange.re.etlentity.XMLFields;
import com.ode.exchange.re.etlentity.XpathValueGroupLevel;
import com.ode.exchange.re.etlservice.ILTEruleService;
import com.ode.exchange.re.etlservice.IRepeatableElementsTranslationService;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.serviceimpl.CalculationServiceImpl;
import com.ode.exchange.re.serviceimpl.CreditDecisionServiceImpl;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LTEProcessUtils {
	private final Logger log = LoggerFactory.getLogger(LTEProcessUtils.class);

	@Autowired
	ILTEruleService lteRuleService;

	@Autowired
	private CalculationServiceImpl calcService;

	@Autowired
	private IRepeatableElementsTranslationService repeatableElementsTranslationService;

	@Autowired
	private CurrencyFormatUtils currencyFormatUtils;

	@Autowired
	private LTEXMLUtils lteXmlUtils;

	@Autowired
	private CreditDecisionServiceImpl creditDecisionService;

	/**
	 * @param lteRuleList
	 * @param xmlFieldsList
	 * @param etlMappingList
	 * @param inputxml
	 * @return
	 * @throws Exception
	 */
	public String buildLTE(List<XMLFields> xmlFieldsList, List<ETLMapping> etlMappingList, String inputxml)
			throws Exception {

		log.debug("Enter buildLTE() method of LTEProcessUtils class");
		final LocalDateTime start = LocalDateTime.now();
		String exceptionMessage = "Exception caught when processing LTE Rules.";

		LinkedHashMap<String, String> xmlFieldValueMap = new LinkedHashMap<>();
		LinkedHashMap<String, String> xmlLookUpFieldMap = new LinkedHashMap<>();

		xmlFieldsList.forEach(xmlfield -> {
			if (!xmlFieldValueMap.containsKey(xmlfield.getFieldName())) {
				xmlFieldValueMap.put(xmlfield.getFieldName(), xmlfield.getFieldValue());
			}

			if (xmlfield.isLookupUsage() && !xmlfield.getFieldValue().isEmpty()) {
				if (!xmlLookUpFieldMap.containsKey(xmlfield.getFieldName())) {
					xmlLookUpFieldMap.put(xmlfield.getFieldName(), xmlfield.getFieldValue());
				}

			}

		});

		String lteXML = inputxml;
		Map<String, String> sendValueConditions = new HashMap<>();
		try {
			List<LTErule> rollUpRules = new ArrayList<>();
			List<XpathValueGroupLevel> xpathValueList = null;

			TranslationPath translatedpaths = processLTERules(xmlFieldsList, xmlLookUpFieldMap, xmlFieldValueMap, sendValueConditions, rollUpRules);
			log.debug("TranslationPath: {}", translatedpaths);
			if (translatedpaths.getTranslatedSendVal() != null || translatedpaths.getFinalDrop() != null ||
					translatedpaths.getFinalDropSet() != null) {

				List<XpathValueGroupLevel> xpathValueGroupList = LTEXMLUtils
						.createXpathValueGroupFromTranslationPath(translatedpaths.getTranslatedSendVal());

				String applicationNumber = xmlFieldValueMap.get("ApplicationNumber");
				List<CreditDecision> listOfCreditDecisions = creditDecisionService
						.findCreditDecisionByAppNumber(applicationNumber);

				XpathValueGroupLevel decisionTime = new XpathValueGroupLevel();
				decisionTime.setFieldName(Constants.FINANCE_PROCESSING_DATE);
				SimpleDateFormat decisionDate = new SimpleDateFormat("yyyy-MM-dd");

				XpathValueGroupLevel conversationNumber = new XpathValueGroupLevel();
				conversationNumber.setFieldName(Constants.APPLICATION_NUMBER);

				if (null != listOfCreditDecisions && !listOfCreditDecisions.isEmpty()) {
					CreditDecision creditDecision = listOfCreditDecisions.get(0);
					if (null != creditDecision && null != creditDecision.getDecisionTs())
					{
						String decisionTs = decisionDate.format(creditDecision.getDecisionTs());

						if (decisionTs != null) {
							decisionTime.setValue(decisionTs);
							xpathValueGroupList.add(decisionTime);
						}

					}
					else
					{
						log.debug("CreditDecision or decisionTs is null for applicationNumber: {}", applicationNumber);
					}

					// Setting Application Number Field to most recent
					// ConversationId
					if (null != creditDecision && null != creditDecision.getConversationId()) {
						String conversationId = creditDecision.getConversationId();
						log.debug("ConversationId for applicationNumber: {}", conversationId);
						if (conversationId != null) {
							conversationNumber.setValue(conversationId);
							xpathValueGroupList.add(conversationNumber);
						}

					} else {
						log.debug("CreditDecision or conversationId is null for applicationNumber: {}",
								applicationNumber);
					}

				}

				xpathValueList = lteXmlUtils.getXpathFromFieldName(etlMappingList, xpathValueGroupList);

				lteXML = lteXmlUtils.createLTEXML(inputxml, xpathValueList, xmlFieldValueMap, sendValueConditions, rollUpRules);
				//log.debug("First LTE XML: {}", lteXML);

				lteXML = DropTagsUtils.implementDrop(lteXML, translatedpaths.getFinalDrop(),
						translatedpaths.getFinalDropSet(), etlMappingList);

				//Temporary fix for RouteOne testing with Co-Applicant Address qualifier.
				//Will be removed once we have a LTE Rule based solution.
				String destinationNameCode = xmlFieldValueMap.get("DestinationNameCode");
				if ("RO".equalsIgnoreCase(destinationNameCode))
				{
					lteXML = LTEXMLUtils.addAddressQualifierToCoApplicant(lteXML);
				}

				//apply repeat rules translations
				lteXML = repeatableElementsTranslationService.applyRepeatRulesTranslations(lteXML, xmlFieldValueMap);

				lteXML = currencyFormatUtils.applyCurrencyFormat(lteXML);
			}

			// Rollup Logic
			if (rollUpRules.size()>0) {
				lteXML = lteXmlUtils.createLTEXMLWithRollUp(lteXML, etlMappingList, xmlFieldValueMap, rollUpRules);
			}

			// Drop duplicate service contracts
			lteXML = lteXmlUtils.dropDuplicateServiceContracts(lteXML);
			
			// Update SpotDeliveryInd
			String spotDeliveryInd = xmlFieldValueMap.get(Constants.SPOT_DELIVERY_IND_TAG_NAME);
			if (spotDeliveryInd != null && !spotDeliveryInd.isEmpty()) {
				String spotDeliveryXml = lteXmlUtils.updateSpotDeliveryInd(lteXML, spotDeliveryInd);
				if (spotDeliveryXml != null && !spotDeliveryXml.isEmpty()) {
					lteXML = spotDeliveryXml;
				}
			}
			log.debug("LTE Output: {}", lteXML);

		} catch (JsonParseException e) {
			log.error(exceptionMessage, e);
		} catch (JsonMappingException e) {
			log.error(exceptionMessage, e);
		} catch (IOException e) {
			log.error(exceptionMessage, e);
		} catch (Exception e) {
			log.error(exceptionMessage, e);
		}
		final LocalDateTime end = LocalDateTime.now();
		log.debug("***** End buildLTE at: " + end + " *****");
		log.debug("buildLTE took " + ChronoUnit.MILLIS.between(start, end) + " MILLISECONDS");
		return LTEXMLUtils.trim(lteXML);
	}

	/**
	 * @param xmlFieldsList
	 * @param xmlFieldValueMap
	 * @param xmlLookUpFieldMap
	 * @param sendValueConditions
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public TranslationPath processLTERules(List<XMLFields> xmlFieldsList, Map<String, String> xmlFieldValueMap,
			Map<String, String> xmlLookUpFieldMap, Map<String, String> sendValueConditions, List<LTErule> rollUpRules) throws JsonParseException, JsonMappingException, IOException {

		log.debug("Enter processLTERules() method of LTEProcessUtils class.");

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		List<LTErule> lteRuleList = lteRuleService.findActiveLteALL();

		List<Calculation> calcList = calcService.getCalculationAll();

		TranslationPath transalationPaths = new TranslationPath();

		List<StringentRuleQualificationLTE> stringentRuleList = new ArrayList<>();
		LookUpCriteriaPassRulesLTE lookUpCriteriaPassRule = new LookUpCriteriaPassRulesLTE();
		LinkedHashMap<String, String> translatedSendValues = new LinkedHashMap<String, String>();

		LinkedHashSet<LTErule> passedLookupset = new LinkedHashSet<>();
		LinkedHashSet<LTErule> sortedPassedLookupset = new LinkedHashSet<>();

		if (lteRuleList.isEmpty()) {
			// No LTE Rules
		}

		log.info("LTE Rule LookUp Fields Processing...");
		Optional<LookUpCriteriaPassRulesLTE> lookUpCriteriaPassRules = lookupFieldCheck(lteRuleList, xmlLookUpFieldMap);
		if (lookUpCriteriaPassRules.isPresent()) {
			lookUpCriteriaPassRule = lookUpCriteriaPassRules.get();
			log.debug("Found lookUpCriteriaPassRule");
		}

		// no master and stringent
		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			log.debug("No master or stringent lookUpCriteriaPassRule found!");
		}

		if (null != lookUpCriteriaPassRule && lookUpCriteriaPassRule.getStringentQualifyRuleList() != null) {
			stringentRuleList = lookUpCriteriaPassRule.getStringentQualifyRuleList();
			stringentRuleList = stringentRuleList.stream()
					.sorted((StringentRuleQualificationLTE o1, StringentRuleQualificationLTE o2) -> {
						int min = Math.min(o1.getStringentRuleHierarchyList().size(),
								o2.getStringentRuleHierarchyList().size());
						for (int i = 0; i < min; i++) {
							int higest = o1.getStringentRuleHierarchyList().get(i)
									.compareTo(o2.getStringentRuleHierarchyList().get(i));
							if (higest != 0) {
								return higest;
							}
						}
						return Integer.compare(o2.getStringentRuleHierarchyList().size(),
								o1.getStringentRuleHierarchyList().size());
					}).collect(Collectors.toList());
			Boolean sameStringentHirearchy = false;

			for (StringentRuleQualificationLTE stringentRule : stringentRuleList.subList(1, stringentRuleList.size())) {
				if (stringentRule.getStringentRuleHierarchyList()
						.equals(stringentRuleList.get(0).getStringentRuleHierarchyList())) {
					sameStringentHirearchy = true;
					break;

				}
			}

			/*
			 * If there exists two rules with highest stringent rule priority, then sort
			 * based on the number of lookup fields matched
			 */
			if (sameStringentHirearchy) {

				stringentRuleList.sort((StringentRuleQualificationLTE s1,
						StringentRuleQualificationLTE s2) -> s2.getTotalLookUpCount() - s1.getTotalLookUpCount());
				for (StringentRuleQualificationLTE stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getTotalLookUpCount() == stringentRule.getTotalLookUpCount()) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			} else if (!sameStringentHirearchy) {
				for (StringentRuleQualificationLTE stringentRule : stringentRuleList) {
					/*
					 * if (stringentRuleList.get(0).getStringentRuleHierarchyList()
					 * .equals(stringentRule.getStringentRuleHierarchyList())) {
					 */ // here
					passedLookupset.add(stringentRule.getStringentRule());
					// }
				}

			}
		}

		if (passedLookupset.isEmpty() && lookUpCriteriaPassRule.getMasterPassedMap() != null) {
			passedLookupset.addAll(lookUpCriteriaPassRule.getMasterPassedMap());
		}

		List<LTErule> lteruleList = passedLookupset.stream()
				.sorted((e1, e2) -> Integer.compare(e1.getLteOrder(), e2.getLteOrder())).collect(Collectors.toList());
		sortedPassedLookupset.addAll(lteruleList);

		if (null != lteRuleList && !lteRuleList.isEmpty()) {
			log.debug("No. of active LTERules: {}", lteRuleList.size());
		}

		if (null != sortedPassedLookupset && !sortedPassedLookupset.isEmpty()) {
			log.debug("No. of LTERules after stringent rule filtering: {}", sortedPassedLookupset.size());
		}

		log.debug("Entering nextRule loop..");

		int countOfSENDTOs;
		boolean multiSENDTORule;

		nextRule: for (LTErule rule : sortedPassedLookupset) {
			HashMap<String, String> calcValues = new HashMap();
			List sendList = new ArrayList();
			List sendValueList = new ArrayList();
			List dropList = new ArrayList();
			List sumList = new ArrayList();
			// HashMap<String,String> sendValue = new HashMap();
			List<XMLFields> xmlFieldsthenList = new ArrayList();
			List<XMLFields> xmlFieldsthenFinalList = new ArrayList();
			HashMap<String, HashMap<String, ArrayList>> repeatedFields = new HashMap();
			Boolean ifIsPresent = false;
			Boolean multiCombinedRule = false;
			Boolean groupedData = false;
			Boolean groupedThenData = false;
			LinkedHashMap<String, LinkedHashMap<String, List<Integer>>> sendValue = new LinkedHashMap();
			Boolean thenKey = false;
			Boolean arithmaticOperator = false;
			String pathOf = new String();
			List dropSetList = new ArrayList();
			List thenSetList = new ArrayList();
			Boolean sendflag = false;
			Boolean fuzzySearch = false;
			Boolean sendGroup = false;
			StringBuilder calculation = new StringBuilder();
			List ruleExpressionList = new ArrayList<>();
			String ruleLogic = rule.getLteRuleLogic();
			LinkedHashMap<String, List<Integer>> dropValues = new LinkedHashMap();
			LinkedHashMap<String, List<Integer>> dropSetValues = new LinkedHashMap();
			ArrayList<Integer> finalValuesGroup = new ArrayList();
			countOfSENDTOs = 0;
			multiSENDTORule = false;


			log.info("Start processing LTERule RuleID: {}, RuleName: {}", rule.getId(), rule.getLteRuleName());

			// Convert JSON to Object
			MapperResult result = JsonUtil.mapJson(ruleLogic);

			if (result.isProceed()) {
				try {
					RegulationRuleLogicExpression[] ruleExpression = result.getRuleExpression();
					log.debug("Begin ruleExpression parsing for RuleID: {}, RuleName: {}", rule.getId(), rule.getLteRuleName());
					int ruleExpressionLength = ruleExpression.length;
					log.debug("ruleExpression array length: {}", ruleExpressionLength);
					for (int i = 0; i < ruleExpressionLength; i++) {

						if ("SENDTO".equals(ruleExpression[i].getValue()))
						{
							countOfSENDTOs++;
						}
					}
					multiSENDTORule = countOfSENDTOs > 1 ? true : false;
					log.debug("Is this a multiSENDTORule? {}", multiSENDTORule);
					for (int i = 0; i < ruleExpressionLength; i++) {
						Boolean[] regulationRuleQualifier = { false };

						log.debug("Processing ruleExpression[{}]: {}", i, ruleExpression[i]);

						// ExpressionType > FIELD
						if (ruleExpression[i].getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
							if (ruleExpression[i].getFieldExpressionPrefix().equals("CA")) {
								String field = ruleExpression[i].getValue();
								for (int j = 0; j < calcList.size(); j++) {

									if (calcList.get(j).getCalculationName().equals(field)) {
										if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
												|| calcList.get(j).getFinanceType().isEmpty()
												|| calcList.get(j).getFinanceType() == null) {
											if (calcList.get(j).getState()
													.equals(xmlFieldValueMap.get("ContractExecutionState"))
													|| calcList.get(j).getState().isEmpty()
													|| calcList.get(j).getState() == null) {
												if (calcList.get(j).getLender()
														.equals(xmlFieldValueMap.get("LenderPartyId"))
														|| calcList.get(j).getLender().isEmpty()
														|| calcList.get(j).getLender() == null) {
													regulationRuleQualifier[0] = true;
													try {
														String reResult = getCalculatedValue(
																calcList.get(j).getCalculationJSON(), xmlFieldsList,
																xmlFieldValueMap, calcList);

														log.debug("PreventNegativeValue of {} is {}", calcList.get(j).getCalculationName(), calcList.get(j).getPreventNegativeValue());
														if (calcList.get(j).getPreventNegativeValue() && reResult.startsWith("-"))
														{
															String negativeValue = reResult;
															reResult = "0.00";
															log.debug("Updated value of {} from {} to {}", calcList.get(j).getCalculationName(), negativeValue, reResult);
														}
														if (reResult.equals("Skip Rule")) {
															regulationRuleQualifier[0] = false;
															continue nextRule;
														}
														calcValues.put(calcList.get(j).getCalculationName().toString(),
																reResult);
														ruleExpressionList.add(reResult);
													} catch (IOException e) {
														log.error(
																"Exception while LTE Rule Expression Proccessing, in Calculation",
																e.getMessage());
													}
												} else {
													regulationRuleQualifier[0] = false;
													continue nextRule;
												}
											} else {
												regulationRuleQualifier[0] = false;
												continue nextRule;
											}
										} else {
											regulationRuleQualifier[0] = false;
											continue nextRule;
										}
									}

								}

							}
							if (ruleExpression[i].getFieldExpressionPrefix().equals("CR")) {

								continue nextRule;

							}
							if (ruleExpression[i].getFieldExpressionPrefix().equals("CO")) {

								String field = ruleExpression[i].getValue();
								log.debug("Looking for matching field: {} within xmlFieldsList", field);
								boolean fieldMatch = false;

								fieldSearch: for (XMLFields xmlField : xmlFieldsList) {
									if (field.equals(xmlField.getFieldName())) {
										fieldMatch = true;
										log.debug("*** Match found for field: {} within xmlFieldsList ***", field);
										if (xmlField.getGroupLevel() == 0) {

											log.info("FieldName: {}, FieldValue: {}", xmlField.getFieldName(), xmlField.getFieldValue());
											regulationRuleQualifier[0] = true;
											log.info("xmlField.getFieldType() : {}", xmlField.getFieldType());
											if (xmlField.getFieldType().equals("DATETIME")) {

												Date dateFromXML = new Date();
												try {
													dateFromXML = formatter.parse(xmlField.getFieldValue());
												} catch (ParseException e) {
													log.error(
															"Exception while LTE Rule Expression Proccessing:  Wrong Date Format on XML "
																	+ e.getMessage());
													throw new BadRequestException(
															"Exception while LTE Rule Expression Proccessing:  Wrong Date Format on XML "
																	+ e.getMessage());
												}

												ruleExpressionList.add(xmlField.getFieldValue());

											} else if (xmlField.getFieldType().equals("NUMERIC")
													|| xmlField.getFieldType().equals("TEXT")) {
												ruleExpressionList.add(xmlField.getFieldValue());
												log.debug("***Added field: {} to ruleExpressionList ***", field);
											}
											break;
										}
										if (xmlField.getGroupLevel() > 0) {
											groupedData = true;
											sendGroup = true;

											regulationRuleQualifier[0] = true;
											if (!repeatedFields.containsKey(xmlField.getFieldName())) {
												ruleExpressionList.add("FIELD");
												ruleExpressionList.add(xmlField.getFieldName());

												ArrayList al = new ArrayList();
												HashMap<String, ArrayList> listOfFieldsGrouped = new HashMap();
												al.add(xmlField.getGroupLevel());
												listOfFieldsGrouped.put(xmlField.getFieldValue(), al);
												repeatedFields.put(xmlField.getFieldName(), listOfFieldsGrouped);
												continue fieldSearch;

											} else if (repeatedFields.containsKey(xmlField.getFieldName())) {

												if (repeatedFields.get(xmlField.getFieldName())
														.containsKey(xmlField.getFieldValue())) {
													if (!repeatedFields.get(xmlField.getFieldName())
															.get(xmlField.getFieldValue())
															.contains(xmlField.getGroupLevel())) {
														repeatedFields.get(xmlField.getFieldName())
														.get(xmlField.getFieldValue())
														.add(xmlField.getGroupLevel());
													}
												} else if (!repeatedFields.get(xmlField.getFieldName())
														.containsKey(xmlField.getFieldValue())) {
													ArrayList newal = new ArrayList();
													newal.add(xmlField.getGroupLevel());

													HashMap<String, ArrayList> existingOfFieldsGrouped = repeatedFields
															.get(xmlField.getFieldName());
													existingOfFieldsGrouped.put(xmlField.getFieldValue(), newal);

													repeatedFields.put(xmlField.getFieldName(), existingOfFieldsGrouped);

												}

											}

										}

									}

								}

								if (!fieldMatch) {
									log.debug("Match not found for field: {} within xmlFieldsList", field);
								}

								if (!regulationRuleQualifier[0] && !multiSENDTORule) {
									continue nextRule;
								}
							}

						}

						// ExpressionType > OPERATOR
						if (ruleExpression[i].getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.OPERATOR)) {
							String op = ruleExpression[i].getValue();

							// RollUp, skip this for later processing
							if (Constants.ROLLUP.equals(op)) {
								rollUpRules.add(rule);
								continue nextRule;
							}

							// if (Constants.CHANGETO.equals(op)) {
							// if
							// (!ruleExpressionList.contains(Constants.CHANGETO))
							// {
							// ruleExpressionList.add(op);
							// }
							// }

							if (op.startsWith("SUBSTRING")) {
								String[] values = op.split("\\(");
								String[] splitValues = values[1].split(",");
								int beginIdx = Integer.parseInt(splitValues[0]);
								int endIdx = Integer.parseInt(splitValues[1].replace(")", "").trim());

								i++;
								String field = ruleExpression[i].getValue();
								fieldSearch: for (XMLFields xmlField : xmlFieldsList) {

									if (field.equals(xmlField.getFieldName())) {
										if (xmlField.getGroupLevel() == 0) {

											log.info("FieldName {} and FieldValue from XML {}", xmlField.getFieldName(),
													field);
											regulationRuleQualifier[0] = true;
											if (xmlField.getFieldType().equals("DATETIME")) {
												Date dateFromXML = new Date();
												try {
													dateFromXML = formatter.parse(xmlField.getFieldValue());
													log.info("Date after parsing: {}", dateFromXML);
												} catch (ParseException e) {
													log.error(
															"Exception while LTE Rule Expression Proccessing:  Wrong Date Format on XML "
																	+ e.getMessage());
													throw new BadRequestException(
															"Exception while LTE Rule Expression Proccessing:  Wrong Date Format on XML "
																	+ e.getMessage());
												}

												ruleExpressionList.add("DATETIME");

												ruleExpressionList.add(dateFromXML);

											} else if (xmlField.getFieldType().equals("NUMERIC")
													|| xmlField.getFieldType().equals("TEXT")) {

												ruleExpressionList.add(xmlField.getFieldValue().toString()
														.substring(beginIdx - 1, endIdx));

											}
											break;
										}
										if (xmlField.getGroupLevel() > 0) {
											groupedData = true;

											regulationRuleQualifier[0] = true;
											if (!repeatedFields.containsKey(xmlField.getFieldName())) {
												ruleExpressionList.add("FIELD");
												ruleExpressionList.add(xmlField.getFieldName());

												ArrayList al = new ArrayList();
												HashMap<String, ArrayList> listOfFieldsGrouped = new HashMap();
												al.add(xmlField.getGroupLevel());
												listOfFieldsGrouped
												.put(xmlField.getFieldValue().substring(beginIdx - 1, endIdx), al);
												repeatedFields.put(xmlField.getFieldName(), listOfFieldsGrouped);
												continue fieldSearch;

											} else if (repeatedFields.containsKey(xmlField.getFieldName())) {

												HashMap<String, ArrayList> existingOfFieldsGroupedwithoutSubstring = repeatedFields
														.get(xmlField.getFieldName());
												HashMap<String, ArrayList> existingOfFieldsGroupedwithSubstring = repeatedFields
														.get(xmlField.getFieldName());
												for (Map.Entry<String, ArrayList> entry : existingOfFieldsGroupedwithoutSubstring
														.entrySet()) {
													existingOfFieldsGroupedwithSubstring.put(
															entry.getKey().substring(beginIdx - 1, endIdx),
															entry.getValue());
												}

												repeatedFields.replace(xmlField.getFieldName(),
														existingOfFieldsGroupedwithoutSubstring,
														existingOfFieldsGroupedwithSubstring);

												if (repeatedFields.get(xmlField.getFieldName()).containsKey(
														xmlField.getFieldValue().substring(beginIdx - 1, endIdx))) {
													if (!repeatedFields.get(xmlField.getFieldName())
															.get(xmlField.getFieldValue().substring(beginIdx - 1, endIdx))
															.contains(xmlField.getGroupLevel())) {
														repeatedFields.get(xmlField.getFieldName())
														.get(xmlField.getFieldValue().toString()
																.substring(beginIdx - 1, endIdx))
														.add(xmlField.getGroupLevel());
													}
												} else if (!repeatedFields.get(xmlField.getFieldName()).containsKey(
														xmlField.getFieldValue().substring(beginIdx - 1, endIdx))) {
													ArrayList newal = new ArrayList();
													newal.add(xmlField.getGroupLevel());

													HashMap<String, ArrayList> existingOfFieldsGrouped = repeatedFields
															.get(xmlField.getFieldName());
													existingOfFieldsGrouped.put(
															xmlField.getFieldValue().substring(beginIdx - 1, endIdx),
															newal);

													repeatedFields.put(xmlField.getFieldName(), existingOfFieldsGrouped);

												}

											}

										}

									}

								}
							}
							if (op.equals("IF")) {
								log.debug("Entered IF block");
								ifIsPresent = true;
								if (i != 0) {
									multiCombinedRule = true;
								}
								if (!ruleExpression[i + 1].getValue().startsWith("SUBSTRING")) {
									pathOf = ruleExpression[i + 1].getValue();
								}
								if (ruleExpression[i + 1].getValue().startsWith("SUBSTRING")) {
									pathOf = ruleExpression[i + 2].getValue();
								}

								log.debug("pathOf: {}", pathOf);

							} else if (op.equals("THEN")) {
								log.debug("Entered THEN block");
								thenKey = true;
								ruleExpressionList.add(op);
								for (int k = i; k < ruleExpression.length; k++) {
									if (ruleExpression[k].getValue().equals("SENDTO")) {
										k++;
										sendList.add(ruleExpression[k].getValue());
										if (k == ruleExpression.length) {
											i = k;
											break;

										}
									}

									if (ruleExpression[k].getValue().equals("SEND")) {

										log.debug("Entered THEN SEND block");
										k++;
										sendflag = true;
										ruleExpressionList.add("SEND");

										sendValueList.add("SEND");
										sendValueList.add(thenSetList.get(thenSetList.size() - 1));
										sendValueList.add(ruleExpression[k].getValue());
										thenSetList.remove(thenSetList.size() - 1);
										if (k == ruleExpression.length) {
											i = k;
											break;

										}
									}

									if (ruleExpression[k].getValue().equals("DROPSET")
											|| ruleExpression[k].getValue().equals("DROP")) {
										i = k - 1;
										break;
									}
									if (ruleExpression[k].getValue().equals(",")) {
										k++;
										if (!ruleExpression[k].getValue().equals("SUM")
												&& !ruleExpression[k].getValue().startsWith("SUBSTRING")) {
											thenSetList.add(ruleExpression[k].getValue());
										}
										if (ruleExpression[k].getValue().equals("SUM")) {
											k++;
											ruleExpressionList.add("SUM");
											sumList.add(ruleExpression[k].getValue());

											String field = ruleExpression[k].getValue();

											fieldSearch: for (XMLFields xmlField : xmlFieldsList) {

												if (field.equals(xmlField.getFieldName())) {

													if (xmlField.getGroupLevel() > 0) {
														groupedData = true;

														regulationRuleQualifier[0] = true;
														if (!repeatedFields.containsKey(xmlField.getFieldName())) {
															ruleExpressionList.add("FIELD");
															ruleExpressionList.add(xmlField.getFieldName());

															ArrayList al = new ArrayList();
															HashMap<String, ArrayList> listOfFieldsGrouped = new HashMap();
															al.add(xmlField.getGroupLevel());
															listOfFieldsGrouped.put(xmlField.getFieldValue(), al);
															repeatedFields.put(xmlField.getFieldName(),
																	listOfFieldsGrouped);
															continue fieldSearch;

														} else if (repeatedFields.containsKey(xmlField.getFieldName())) {

															if (repeatedFields.get(xmlField.getFieldName())
																	.containsKey(xmlField.getFieldValue())) {
																if (!repeatedFields.get(xmlField.getFieldName())
																		.get(xmlField.getFieldValue())
																		.contains(xmlField.getGroupLevel())) {
																	repeatedFields.get(xmlField.getFieldName())
																	.get(xmlField.getFieldValue())
																	.add(xmlField.getGroupLevel());
																}

															} else if (!repeatedFields.get(xmlField.getFieldName())
																	.containsKey(xmlField.getFieldValue())) {
																ArrayList newal = new ArrayList();
																newal.add(xmlField.getGroupLevel());

																HashMap<String, ArrayList> existingOfFieldsGrouped = repeatedFields
																		.get(xmlField.getFieldName());
																existingOfFieldsGrouped.put(xmlField.getFieldValue(),
																		newal);

																repeatedFields.put(xmlField.getFieldName(),
																		existingOfFieldsGrouped);

															}

														}

													}

												}

											}

											if (!regulationRuleQualifier[0]) {
												continue nextRule;
											}

											k++;
											k++;
											sumList.add(ruleExpression[k].getValue());

										}
										if (ruleExpression[k].getValue().startsWith("SUBSTRING")) {
											thenSetList
											.add(ruleExpression[k].getValue() + ruleExpression[k + 1].getValue());
											k++;
										}
									}

									if (ruleExpression[k].getValue().equals("THEN")) {
										k++;
										if (!ruleExpression[k].getValue().startsWith("SUBSTRING")) {
											thenSetList.add(ruleExpression[k].getValue());
										}
										if (ruleExpression[k].getValue().startsWith("SUBSTRING")) {
											thenSetList
											.add(ruleExpression[k].getValue() + ruleExpression[k + 1].getValue());
											k++;
										}

									}

								}

							}

							else if (op.equals("SEND")) {
								log.debug("Entered SEND block");
								if (ifIsPresent) {
									log.debug("Entered SEND ifIsPresent block");
									if (ruleExpressionList.contains(Constants.CHANGETO)) {
										sendList.add(ruleExpressionList.get(ruleExpressionList.size() - 1));
										ruleExpressionList.add(op);
									} else {
										ruleExpressionList.add(op);
										sendList.add(pathOf);
										i++;
									}


								} else {
									log.debug("Entered SEND else block");
									sendList.add(ruleExpression[i - 1].getValue());
									ruleExpressionList.add(op);
								}

							} else if (op.equals("DROPSET")) {
								ruleExpressionList.add(op);
								if (ifIsPresent && !thenKey) {
									ruleExpressionList.add(pathOf);
								}

								i++;
								dropSetList.add(ruleExpression[i].getValue());

							} else if (op.equals("DROP")) {
								log.info("Processing DROP operator.....");
								ruleExpressionList.add(op);
								if (ifIsPresent && !thenKey) {
									ruleExpressionList.add(pathOf);
								}
								i++;
								dropList.add(ruleExpression[i].getValue());
								log.info("Added {} to DROP list", ruleExpression[i].getValue());
								log.info("DROP list: {}", dropList);
							} else if (op.equals("SENDTO")) {

								ruleExpressionList.add(op);
								i++;

								sendList.add(ruleExpression[i].getValue());

							}

							else {
								if (op.equals("+") || op.equals("-") || op.equals("*") || op.equals("/")) {
									arithmaticOperator = true;
								}
								if (op.startsWith("%")) {
									fuzzySearch = true;
									ruleExpressionList.add("VALUE");
								}
								if (!op.startsWith("SUBSTRING")) {
									if (!op.equals(ruleExpressionList.size() - 1)) {
										ruleExpressionList.add(op);
									}
								}
							}

							log.debug("Finished ExpressionType.OPERATOR {}", op);

						}

						// ExpressionType > VALUE
						if (ruleExpression[i].getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.VALUE)) {
							String value = ruleExpression[i].getValue();
							if (groupedData) {
								ruleExpressionList.add("VALUE");
								ruleExpressionList.add(value);
							} else {
								ruleExpressionList.add(value);
							}

						}

					}

					log.debug("Items in ruleExpressionList");
					int itemIndex = 0;
					for (Object item : ruleExpressionList)
					{
						log.debug("item[{}]: {}", itemIndex, item);
						itemIndex++;
					}

					log.debug("End ruleExpression parsing for RuleID: {}, RuleName: {}", rule.getId(),
							rule.getLteRuleName());

					log.debug("Check if ruleExpressionList.contains SUM");
					if (ruleExpressionList.contains("SUM")) {
						if (!thenKey) {
							int indexOffield = ruleExpressionList.indexOf("FIELD");
							String fieldName = ruleExpressionList.get(indexOffield + 1).toString();
							HashMap<String, ArrayList> groupedValuetobeSum = repeatedFields.get(fieldName);

							List repeatedValues = new ArrayList();
							List repeatedValuesSum = new ArrayList();

							for (Map.Entry<String, ArrayList> tobeAddedSUMKeys : groupedValuetobeSum.entrySet()) {

								if (tobeAddedSUMKeys.getValue().size() > 1) {
									String finalVal = new String();
									String sumVal = tobeAddedSUMKeys.getKey() + "*" + tobeAddedSUMKeys.getValue().size();
									ScriptEngineManager mgr = new ScriptEngineManager();
									ScriptEngine engine = mgr.getEngineByName("nashorn");
									try {
										finalVal = engine.eval(sumVal).toString();
									} catch (ScriptException e) {
										log.info("Error Evaluating Final ExpressionList", e.getMessage());
									}
									repeatedValues.add(finalVal.toString());
								} else if (tobeAddedSUMKeys.getValue().size() == 1) {
									repeatedValues.add(tobeAddedSUMKeys.getKey().toString());
								}

							}
							for (int i = 0; i < repeatedValues.size(); i++) {
								repeatedValuesSum.add(repeatedValues.get(i).toString());
								if (i != repeatedValues.size() - 1) {
									repeatedValuesSum.add("+");
								}
							}
							String repeatedfieldSumValue = new String();
							String listString = String.join("", repeatedValuesSum);
							ScriptEngineManager mgr = new ScriptEngineManager();
							ScriptEngine engine = mgr.getEngineByName("nashorn");
							try {
								repeatedfieldSumValue = engine.eval(listString).toString();
							} catch (ScriptException e) {
								log.info("Error Evaluating Final ExpressionList", e.getMessage());
							}

							List ruleExpressionSUM = new ArrayList();
							for (int i = 0; i < ruleExpressionList.size(); i++) {
								if (ruleExpressionList.get(i).equals("SUM")) {
									if (i == 0) {
										ruleExpressionSUM.add(repeatedfieldSumValue);
									} else {
										ruleExpressionSUM.set(i, repeatedfieldSumValue);
									}

								} else if (ruleExpressionList.get(i).equals("FIELD")) {
									i++;
								} else {
									ruleExpressionSUM.add(ruleExpressionList.get(i));
								}
							}
							ruleExpressionList.clear();
							ruleExpressionList.addAll(ruleExpressionSUM);
						}
					}

					log.debug("Check if ruleExpressionList.contains DROP and not SEND");
					if (ruleExpressionList.contains("DROP") && !ruleExpressionList.contains("SEND")
							&& !ruleExpressionList.contains("SENDTO") && !thenKey) {
						if (!ifIsPresent) {
							log.debug("List to be dropped: , {}", dropList);
							for (int i = 0; i < dropList.size(); i++) {
								if (!dropValues.containsKey(dropList.get(i).toString())) {
									ArrayList<Integer> al = new ArrayList();
									al.add(0);
									dropValues.put(dropList.get(i).toString(), al);
								} else if (dropValues.containsKey(dropList.get(i).toString())) {
									List<Integer> nw = dropValues.get(dropList.get(i));
									if (!nw.contains(0)) {
										dropValues.get(dropList.get(i)).add(0);
									}
									log.debug("Not wanted values: , {}", nw);
								}
							}
							log.debug("Values to be dropped: , {}", dropValues);
						}
						if (ifIsPresent) {
							int indexOfDROP = 0;
							Object expEval = false;
							if (ruleExpressionList.contains("=")) {
								indexOfDROP = ruleExpressionList.indexOf("DROP");

								if (ruleExpressionList.get(0).equals(ruleExpressionList.get(indexOfDROP - 1))) {
									expEval = true;
								} else {
									expEval = false;
								}

							} else if (ruleExpressionList.contains("<")) {
								indexOfDROP = ruleExpressionList.indexOf("DROP");

								if (Double.parseDouble(ruleExpressionList.get(0).toString()) < Double
										.parseDouble(ruleExpressionList.get(indexOfDROP - 1).toString())) {
									expEval = true;
								} else {
									expEval = false;
								}

							} else if (ruleExpressionList.contains(">")) {
								indexOfDROP = ruleExpressionList.indexOf("DROP");

								if (Double.parseDouble(ruleExpressionList.get(0).toString()) > Double
										.parseDouble(ruleExpressionList.get(indexOfDROP - 1).toString())) {
									expEval = true;
								} else {
									expEval = false;
								}

							} else {
								String evalString = String.join("", ruleExpressionList);
								ScriptEngineManager mgr = new ScriptEngineManager();
								ScriptEngine engine = mgr.getEngineByName("nashorn");
								try {
									expEval = engine.eval(evalString);
									log.debug("Expression List did not contain = < >: , {}", expEval);
								} catch (ScriptException e) {
									log.info("Error Evaluating ruleExpression", e.getMessage());
								}
							}

							if (expEval.equals(true)) {

								for (int i = 0; i < dropList.size(); i++) {
									if (!dropValues.containsKey(dropList.get(i).toString())) {
										ArrayList<Integer> al = new ArrayList();
										al.add(0);
										dropValues.put(dropList.get(i).toString(), al);
										log.debug("Put in hashmap key: " + dropList.get(i).toString() + ": Value: " + al);
									} else if (dropValues.containsKey(dropList.get(i).toString())) {
										List<Integer> nw = dropValues.get(dropList.get(i));
										if (!nw.contains(0)) {
											dropValues.get(dropList.get(i)).add(0);
											log.debug("Get from hashmap : " + dropList.get(i));
										}
									}
								}

							}
						}
					}
					log.debug("Check if ruleExpressionList.contains DROPSET and not SEND");
					if (ruleExpressionList.contains("DROPSET") && !ruleExpressionList.contains("SEND")
							&& !ruleExpressionList.contains("SENDTO") && !thenKey) {
						if (!ifIsPresent) {
							for (int i = 0; i < dropSetList.size(); i++) {
								if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
									ArrayList<Integer> al = new ArrayList();
									al.add(0);
									dropSetValues.put(dropList.get(i).toString(), al);
								} else if (dropSetValues.containsKey(dropSetList.get(i).toString())) {
									List<Integer> nw = dropValues.get(dropSetList.get(i));
									if (!nw.contains(0)) {
										dropSetValues.get(dropSetList.get(i)).add(0);
									}
								}
							}
						}

						if (ifIsPresent) {
							int indexOfDROPSET = 0;
							Object expEval = false;
							if (ruleExpressionList.contains("=")) {
								indexOfDROPSET = ruleExpressionList.indexOf("DROPSET");

								if (ruleExpressionList.get(0).equals(ruleExpressionList.get(indexOfDROPSET - 1))) {
									expEval = true;
								} else {
									expEval = false;
								}

							} else if (ruleExpressionList.contains("<")) {
								indexOfDROPSET = ruleExpressionList.indexOf("DROPSET");

								if (Double.parseDouble(ruleExpressionList.get(0).toString()) < Double
										.parseDouble(ruleExpressionList.get(indexOfDROPSET - 1).toString())) {
									expEval = true;
								} else {
									expEval = false;
								}

							} else if (ruleExpressionList.contains(">")) {
								indexOfDROPSET = ruleExpressionList.indexOf("DROPSET");

								if (Double.parseDouble(ruleExpressionList.get(0).toString()) > Double
										.parseDouble(ruleExpressionList.get(indexOfDROPSET - 1).toString())) {
									expEval = true;
								} else {
									expEval = false;
								}

							} else {
								String evalString = String.join("", ruleExpressionList);
								ScriptEngineManager mgr = new ScriptEngineManager();
								ScriptEngine engine = mgr.getEngineByName("nashorn");
								try {
									expEval = engine.eval(evalString);
								} catch (ScriptException e) {
									log.info("Error Evaluating ruleExpression", e.getMessage());
								}
							}

							if (expEval.equals(true)) {

								for (int i = 0; i < dropSetList.size(); i++) {
									if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
										ArrayList<Integer> al = new ArrayList();
										al.add(0);
										dropSetValues.put(dropSetList.get(i).toString(), al);
									} else if (dropSetValues.containsKey(dropSetList.get(i).toString())) {
										List<Integer> nw = dropValues.get(dropSetList.get(i));
										if (!nw.contains(0)) {
											dropSetValues.get(dropSetList.get(i)).add(0);
										}
									}
								}

							}
						}

					}

					log.debug("Check if ruleExpressionList.contains SEND");
					if (ruleExpressionList.contains("SEND")) {
						if (!thenKey) {

							if (ifIsPresent) {
								if (multiCombinedRule) {
									List<List> ruleLogicExp = new ArrayList<>();
									List<String> logicalOperatorList = new ArrayList<>();

									int j = 0;
									for (int i = 0; i < ruleExpressionList.size(); i++) {
										if (ruleExpressionList.get(i).equals("OR")) {
											ruleLogicExp.add(ruleExpressionList.subList(j, i));

											j = i + 1;
											logicalOperatorList.add((String) ruleExpressionList.get(i));
										}
										if (i == ruleExpressionList.size() - 1) {
											ruleLogicExp.add(ruleExpressionList.subList(j, i + 1));
										}

									}
									for (int i = 0; i < ruleLogicExp.size(); i++) {
										int indexOfSEND = 0;
										Object expEval = false;

										if (ruleLogicExp.get(i).contains("=")) {
											indexOfSEND = ruleLogicExp.get(i).indexOf("SEND");

											if (ruleLogicExp.get(i).get(0)
													.equals(ruleLogicExp.get(i).get(indexOfSEND - 1))) {
												expEval = true;
											} else {
												expEval = false;
											}

										} else if (ruleLogicExp.get(i).contains(">")) {
											indexOfSEND = ruleLogicExp.get(i).indexOf("SEND");

											if (Double.parseDouble(ruleLogicExp.get(i).get(0).toString()) > Double
													.parseDouble(ruleLogicExp.get(i).get(indexOfSEND - 1).toString())) {
												expEval = true;
											} else {
												expEval = false;
											}

										} else if (ruleLogicExp.get(i).contains("<")) {
											indexOfSEND = ruleLogicExp.get(i).indexOf("SEND");

											if (Double.parseDouble(ruleLogicExp.get(i).get(0).toString()) < Double
													.parseDouble(ruleLogicExp.get(i).get(indexOfSEND - 1).toString())) {
												expEval = true;
											} else {
												expEval = false;
											}

										} else {

											String evalString = String.join("", ruleLogicExp.get(i));
											ScriptEngineManager mgr = new ScriptEngineManager();
											ScriptEngine engine = mgr.getEngineByName("nashorn");
											try {
												expEval = engine.eval(evalString);
											} catch (ScriptException e) {
												log.info("Error Evaluating ruleExpression", e.getMessage());
											}
										}
										if (expEval.equals(true)) {
											if (!sendValue.containsKey(sendList.get(i).toString())) {
												log.debug("expEval true, !sendValue contains key");
												ArrayList<Integer> al = new ArrayList();
												LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
												al.add(0);
												valAndGroup.put(ruleLogicExp.get(i).get(indexOfSEND + 1).toString(), al);
												sendValue.put(sendList.get(i).toString(), valAndGroup);
											} else if (sendValue.containsKey(sendList.get(i).toString())) {
												LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
														.get(sendList.get(i).toString());
												if (!valAndGroup.containsKey(ruleLogicExp.get(i).get(indexOfSEND + 1))) {

													ArrayList<Integer> al = new ArrayList();
													LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
													al.add(0);
													nwvalAndGroup.put(ruleLogicExp.get(i).get(indexOfSEND + 1).toString(),
															al);
													sendValue.put(sendList.get(i).toString(), nwvalAndGroup);
												} else if (valAndGroup
														.containsKey(ruleLogicExp.get(i).get(indexOfSEND + 1))) {
													List<Integer> existingArray = valAndGroup.get(indexOfSEND + 1);
													if (!existingArray.contains(0)) {
														ArrayList<Integer> al = new ArrayList();
														LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
														al.add(0);
														nwvalAndGroup.put(
																ruleLogicExp.get(i).get(indexOfSEND + 1).toString(), al);
														sendValue.put(sendList.get(i).toString(), nwvalAndGroup);
													}
												}

											}
											if (ruleExpressionList.contains("DROP")) {
												for (int k = 0; k < dropList.size(); k++) {
													if (!dropValues.containsKey(dropList.get(k).toString())) {
														ArrayList<Integer> al = new ArrayList();
														al.add(0);
														dropValues.put(dropList.get(k).toString(), al);
													} else if (dropValues.containsKey(dropList.get(k).toString())) {
														List<Integer> nw = dropValues.get(dropList.get(k));
														if (!nw.contains(0)) {
															dropValues.get(dropList.get(k)).add(0);
														}
													}
												}
											}
											if (ruleExpressionList.contains("DROPSET")) {
												for (int k = 0; k < dropSetList.size(); k++) {
													if (!dropSetValues.containsKey(dropSetList.get(k).toString())) {
														ArrayList<Integer> al = new ArrayList();
														al.add(0);
														dropSetValues.put(dropList.get(k).toString(), al);
													} else if (dropSetValues.containsKey(dropSetList.get(k).toString())) {
														List<Integer> nw = dropValues.get(dropSetList.get(k));
														if (!nw.contains(0)) {
															dropSetValues.get(dropSetList.get(k)).add(0);
														}
													}
												}
											}
										}
									}

								} else if (!multiCombinedRule) {

									log.debug("Entered !multiCombinedRule block ");

									int indexOfSEND = 0;
									Object expEval = false;
									if (ruleExpressionList.contains("=")) {
										log.debug("1");
										indexOfSEND = ruleExpressionList.indexOf("SEND");

										if (ruleExpressionList.get(0).equals(ruleExpressionList.get(indexOfSEND - 1))) {
											expEval = true;
										} else if ("FIELD".equals(ruleExpressionList.get(0))
												&& "=".equals(ruleExpressionList.get(2))
												&& "VALUE".equals(ruleExpressionList.get(3))
												&& "SEND".equals(ruleExpressionList.get(5))
												&& "VALUE".equals(ruleExpressionList.get(6))) {
											String newValue = String.valueOf(rule.getId()) + ";"
													+ String.valueOf(ruleExpressionList.get(7));
											sendValueConditions.put(newValue,
													String.valueOf(ruleExpressionList.get(4)));
											ruleExpressionList.add(6, newValue);
											ruleExpressionList.remove(7);
											expEval = true;

										} else if (ruleExpressionList.contains("CHANGETO")) {
											List<XMLFields> oldFieldList = new ArrayList();

											oldFieldList = xmlFieldsList.stream()
													.filter(p -> p.getFieldName().equals(ruleExpressionList.get(1))
															&& p.getFieldValue().equals(ruleExpressionList.get(4)))
													.collect(Collectors.toList());
											log.debug("oldFieldlist: " + oldFieldList);
											// for (int i = 0; i <
											// oldFieldList.size(); i++) {
											int grouplevel;
											grouplevel = oldFieldList.get(0).getGroupLevel();

											List<XMLFields> newEtlField = new ArrayList();
											if (Constants.FIELD
													.equals(ruleExpressionList.get(ruleExpressionList.size() - 4))
													|| Constants.VALUE.equals(
															ruleExpressionList.get(ruleExpressionList.size() - 4))) {

												newEtlField = xmlFieldsList.stream()
														.filter(p -> p.getFieldName().equals(
																ruleExpressionList.get(ruleExpressionList.size() - 3))
																&& p.getGroupLevel() == grouplevel)
														.collect(Collectors.toList());
												log.debug(
														(String) ruleExpressionList.get(ruleExpressionList.size() - 3));
												log.debug("newEtlField: " + newEtlField);
											} else {

												newEtlField = xmlFieldsList.stream()
														.filter(p -> p.getFieldName().equals(
																ruleExpressionList.get(ruleExpressionList.size() - 4))
																&& p.getGroupLevel() == grouplevel)
														.collect(Collectors.toList());
												log.debug(
														(String) ruleExpressionList.get(ruleExpressionList.size() - 4));
												log.debug("newEtlField: " + newEtlField);

											}

											sendValueConditions.put(
													String.valueOf(
															ruleExpressionList.get(ruleExpressionList.size() - 1)),
													newEtlField.get(0).getFieldValue());
											// }

											expEval = true;
										} else {
											expEval = false;
										}


									} else if (ruleExpressionList.contains("<")) {
										indexOfSEND = ruleExpressionList.indexOf("SEND");

										if (Double.parseDouble(ruleExpressionList.get(0).toString()) < Double
												.parseDouble(ruleExpressionList.get(indexOfSEND - 1).toString())) {
											expEval = true;
										} else {
											expEval = false;
										}

									} else if (ruleExpressionList.contains(">")) {
										indexOfSEND = ruleExpressionList.indexOf("SEND");

										if (ruleExpressionList.contains("CHANGETO")) {
											List<XMLFields> oldFieldList = new ArrayList();

											oldFieldList = xmlFieldsList.stream()
													.filter(p -> p.getFieldName().equals(ruleExpressionList.get(1))
															&& Double.parseDouble(p.getFieldValue().toString()) > Double
															.parseDouble(ruleExpressionList.get(4).toString()))
													.collect(Collectors.toList());
											log.debug("oldFieldlist: " + oldFieldList);
											// for (int i = 0; i <
											// oldFieldList.size(); i++) {
											int grouplevel;
											grouplevel = oldFieldList.get(0).getGroupLevel();

											List<XMLFields> newEtlField = new ArrayList();
											newEtlField = xmlFieldsList.stream()
													.filter(p -> p.getFieldName().equals(
															ruleExpressionList.get(ruleExpressionList.size() - 3))
															&& p.getGroupLevel() == grouplevel)
													.collect(Collectors.toList());
											log.debug((String) ruleExpressionList.get(ruleExpressionList.size() - 3));
											log.debug("newEtlField: " + newEtlField);
											sendValueConditions.put(
													String.valueOf(
															ruleExpressionList.get(ruleExpressionList.size() - 1)),
													newEtlField.get(0).getFieldValue());
											// }

											expEval = true;
										} else if (Double.parseDouble(ruleExpressionList.get(0).toString()) > Double
												.parseDouble(ruleExpressionList.get(indexOfSEND - 1).toString())) {
											expEval = true;
										} else {
											expEval = false;
										}

									} else {
										log.debug("2");
										String evalString = String.join("", ruleExpressionList);
										log.debug("evalString: {}", evalString);
										ScriptEngineManager mgr = new ScriptEngineManager();
										ScriptEngine engine = mgr.getEngineByName("nashorn");
										try {
											expEval = engine.eval(evalString);
										} catch (ScriptException e) {
											log.info("Error Evaluating ruleExpression", e.getMessage());
										}
									}

									log.debug("expEval: {}", expEval);

									if (expEval.equals(true)) {
										log.debug("1");

										if (!sendValue.containsKey(sendList.get(0).toString())) {

											if (ruleExpressionList.contains(Constants.CHANGETO)) {
												ArrayList<Integer> al = new ArrayList();
												LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
												al.add(0);
												if (ruleExpressionList.get(9).equals(Constants.VALUE)) {
													ruleExpressionList.remove(9);
												}
												valAndGroup.put(ruleExpressionList.get(indexOfSEND + 1).toString(), al);
												int pathIndex = ruleExpressionList.size() - 3;
												Object path = ruleExpressionList.get(pathIndex);
												sendValue.put((String) path, valAndGroup);
											} else {
												log.debug("2");
												ArrayList<Integer> al = new ArrayList();
												LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
												al.add(0);
												valAndGroup.put(ruleExpressionList.get(indexOfSEND + 1).toString(), al);
												sendValue.put(sendList.get(0).toString(), valAndGroup);
											}

										} else if (sendValue.containsKey(sendList.get(0).toString())) {
											log.debug("3");
											LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
													.get(sendList.get(0).toString());
											if (!valAndGroup.containsKey(ruleExpressionList.get(indexOfSEND + 1))) {
												log.debug("4");
												ArrayList<Integer> al = new ArrayList();
												LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
												al.add(0);
												nwvalAndGroup.put(ruleExpressionList.get(indexOfSEND + 1).toString(), al);
												sendValue.put(sendList.get(0).toString(), nwvalAndGroup);
											} else if (valAndGroup.containsKey(ruleExpressionList.get(indexOfSEND + 1))) {
												log.debug("5");
												List<Integer> existingArray = valAndGroup.get(indexOfSEND + 1);
												if (!existingArray.contains(0)) {
													log.debug("6");
													ArrayList<Integer> al = new ArrayList();
													LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
													al.add(0);
													nwvalAndGroup.put(ruleExpressionList.get(indexOfSEND + 1).toString(),
															al);
													sendValue.put(sendList.get(0).toString(), nwvalAndGroup);
												}
											}

										}

										if (ruleExpressionList.contains("DROP")) {
											for (int i = 0; i < dropList.size(); i++) {
												if (!dropValues.containsKey(dropList.get(i).toString())) {
													ArrayList<Integer> al = new ArrayList();
													al.add(0);
													dropValues.put(dropList.get(i).toString(), al);
												} else if (dropValues.containsKey(dropList.get(i).toString())) {
													List<Integer> nw = dropValues.get(dropList.get(i));
													if (!nw.contains(0)) {
														dropValues.get(dropList.get(i)).add(0);
													}
												}
											}
										}
										if (ruleExpressionList.contains("DROPSET")) {
											for (int i = 0; i < dropSetList.size(); i++) {
												if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
													ArrayList<Integer> al = new ArrayList();
													al.add(0);
													dropSetValues.put(dropList.get(i).toString(), al);
												} else if (dropSetValues.containsKey(dropSetList.get(i).toString())) {
													List<Integer> nw = dropValues.get(dropSetList.get(i));
													if (!nw.contains(0)) {
														dropSetValues.get(dropSetList.get(i)).add(0);
													}
												}
											}
										}

									}
									else
									{
										log.debug("Did not add anything to sendValue");
									}
								}
							}
							if (!ifIsPresent) {

								if (!sendValue.containsKey(sendList.get(0).toString())) {
									if (ruleExpressionList.contains(Constants.CHANGETO)) {
										ArrayList<Integer> al = new ArrayList();
										LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
										al.add(0);
										valAndGroup.put(
												ruleExpressionList.get(ruleExpressionList.size() - 1).toString(), al);
										sendValue.put(sendList.get(0).toString(), valAndGroup);
									} else {
										ArrayList<Integer> al = new ArrayList();
										LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
										al.add(0);
										valAndGroup.put(ruleExpressionList.get(2).toString(), al);
										sendValue.put(sendList.get(0).toString(), valAndGroup);
									}

								} else if (sendValue.containsKey(sendList.get(0).toString())) {
									LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
											.get(sendList.get(0).toString());
									if (!valAndGroup.containsKey(ruleExpressionList.get(2))) {

										ArrayList<Integer> al = new ArrayList();
										LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
										al.add(0);
										nwvalAndGroup.put(ruleExpressionList.get(2).toString(), al);
										sendValue.put(sendList.get(0).toString(), nwvalAndGroup);
									} else if (valAndGroup.containsKey(ruleExpressionList.get(2))) {
										List<Integer> existingArray = valAndGroup.get(2);
										if (!existingArray.contains(0)) {
											ArrayList<Integer> al = new ArrayList();
											LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
											al.add(0);
											nwvalAndGroup.put(ruleExpressionList.get(2).toString(), al);
											sendValue.put(sendList.get(0).toString(), nwvalAndGroup);
										}
									}

								}

							}
							if (ruleExpressionList.contains("DROP")) {
								for (int i = 0; i < dropList.size(); i++) {
									if (!dropValues.containsKey(dropList.get(i).toString())) {
										ArrayList<Integer> al = new ArrayList();
										al.add(0);
										dropValues.put(dropList.get(i).toString(), al);
									} else if (dropValues.containsKey(dropList.get(i).toString())) {
										List<Integer> nw = dropValues.get(dropList.get(i));
										if (!nw.contains(0)) {
											dropValues.get(dropList.get(i)).add(0);
										}
									}
								}
							}
							if (ruleExpressionList.contains("DROPSET")) {
								for (int i = 0; i < dropSetList.size(); i++) {
									if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
										ArrayList<Integer> al = new ArrayList();
										al.add(0);
										dropSetValues.put(dropList.get(i).toString(), al);
									} else if (dropSetValues.containsKey(dropSetList.get(i).toString())) {
										List<Integer> nw = dropValues.get(dropSetList.get(i));
										if (!nw.contains(0)) {
											dropSetValues.get(dropSetList.get(i)).add(0);
										}
									}
								}
							}

						}
					}
					log.debug("Check if ruleExpressionList.contains SENDTO");
					if (ruleExpressionList.contains("SENDTO")) {

						// if(!groupedData)
						// {
						if (!thenKey) {
							if (arithmaticOperator) {
								String val = null;
								List ruleList = new ArrayList();
								for (int i = 0; i < ruleExpressionList.size(); i++) {
									if (ruleExpressionList.get(i).equals("SENDTO")) {

										break;
									} else {
										ruleList.add(ruleExpressionList.get(i));
									}
								}
								String eString = String.join("", ruleList);
								log.debug("Within SENDTO block. eString: {}", eString);
								ScriptEngineManager mgr = new ScriptEngineManager();
								ScriptEngine engine = mgr.getEngineByName("nashorn");
								try {
									val = engine.eval(eString).toString();
									val = NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val);
								} catch (ScriptException e) {
									log.info("Error Evaluating ruleExpression", e.getMessage());
								}

								if (val != null) {
									log.debug("Within SENDTO val != null block. val: {}", val);
									for (int i = 0; i < sendList.size(); i++) {

										log.debug("Iteration {} sendList.get(i): {}", i, sendList.get(i).toString());

										if (!sendValue.containsKey(sendList.get(i).toString())) {
											log.debug("within if block 1");
											ArrayList<Integer> al = new ArrayList();

											LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
											al.add(0);
											valAndGroup.put(val, al);
											sendValue.put(sendList.get(i).toString(), valAndGroup);
										} else if (sendValue.containsKey(sendList.get(i).toString())) {
											log.debug("within if block 2");
											LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
													.get(sendList.get(i).toString());
											if (!valAndGroup.containsKey(val)) {
												log.debug("within if block 3");
												ArrayList<Integer> al = new ArrayList();
												LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
												al.add(0);
												nwvalAndGroup.put(val, al);
												sendValue.put(sendList.get(i).toString(), nwvalAndGroup);
											} else if (valAndGroup.containsKey(val)) {
												log.debug("within if block 4");
												List<Integer> existingArray = valAndGroup.get(val);
												if (!existingArray.contains(0)) {
													log.debug("within if block 5");
													valAndGroup.get(val).add(0);
													sendValue.put(sendList.get(i).toString(), valAndGroup);
												}
											}

										}

									}

									if (ruleExpressionList.contains("DROP")) {
										for (int i = 0; i < dropList.size(); i++) {
											if (!dropValues.containsKey(dropList.get(i).toString())) {
												ArrayList<Integer> al = new ArrayList();
												al.add(0);
												dropValues.put(dropList.get(i).toString(), al);
											} else if (dropValues.containsKey(dropList.get(i).toString())) {
												List<Integer> nw = dropValues.get(dropList.get(i));
												if (!nw.contains(0)) {
													dropValues.get(dropList.get(i)).add(0);
												}
											}
										}

									}
									if (ruleExpressionList.contains("DROPSET")) {
										for (int i = 0; i < dropSetList.size(); i++) {
											if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
												ArrayList<Integer> al = new ArrayList();
												al.add(0);
												dropSetValues.put(dropList.get(i).toString(), al);
											} else if (dropSetValues.containsKey(dropSetList.get(i).toString())) {
												List<Integer> nw = dropValues.get(dropSetList.get(i));
												if (!nw.contains(0)) {
													dropSetValues.get(dropSetList.get(i)).add(0);
												}
											}
										}

									}

								}
								else
								{
									log.debug("nashorn script engine evaluated expression: {} to null!", eString);
								}
							}
							if (!arithmaticOperator) {
								log.debug("Within SENDTO !arithmaticOperator block");
								List ruleList = new ArrayList();
								for (int i = 0; i < ruleExpressionList.size(); i++) {
									if (!ruleExpressionList.get(i).equals("SENDTO")) {
										ruleList.add(ruleExpressionList.get(i));
									}
								}
								for (int i = 0; i < sendList.size(); i++) {
									/*
									 * MultiValueMap<String,Integer> valAndGroup = new LinkedMultiValueMap();
									 * valAndGroup.put(val.toString(), 0); sendValue.put(sendList.get(i).toString(),
									 * valAndGroup);
									 */
									if (!sendValue.containsKey(sendList.get(i).toString())) {
										ArrayList<Integer> al = new ArrayList();
										LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
										al.add(0);
										valAndGroup.put(ruleList.get(i).toString(), al);
										sendValue.put(sendList.get(i).toString(), valAndGroup);
									} else if (sendValue.containsKey(sendList.get(i).toString())) {
										LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
												.get(sendList.get(i).toString());
										if (!valAndGroup.containsKey(ruleList.get(i))) {

											ArrayList<Integer> al = new ArrayList();
											LinkedHashMap<String, List<Integer>> nwvalAndGroup = new LinkedHashMap();
											al.add(0);
											nwvalAndGroup.put(ruleList.get(i).toString(), al);
											sendValue.put(sendList.get(i).toString(), nwvalAndGroup);
										} else if (valAndGroup.containsKey(ruleList.get(i))) {
											List<Integer> existingArray = valAndGroup.get(ruleList.get(i));
											if (!existingArray.contains(0)) {
												valAndGroup.get(ruleList.get(i)).add(0);
												sendValue.put(sendList.get(i).toString(), valAndGroup);
											}
										}

									}

								}
								if (ruleExpressionList.contains("DROP")) {
									for (int i = 0; i < dropList.size(); i++) {
										if (!dropValues.containsKey(dropList.get(i).toString())) {
											ArrayList<Integer> al = new ArrayList();
											al.add(0);
											dropValues.put(dropList.get(i).toString(), al);
										} else if (dropValues.containsKey(dropList.get(i).toString())) {
											List<Integer> nw = dropValues.get(dropList.get(i));
											if (!nw.contains(0)) {
												dropValues.get(dropList.get(i)).add(0);
											}
										}
									}

								}
								if (ruleExpressionList.contains("DROPSET")) {
									for (int i = 0; i < dropSetList.size(); i++) {
										if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
											ArrayList<Integer> al = new ArrayList();
											al.add(0);
											dropSetValues.put(dropList.get(i).toString(), al);
										} else if (dropSetValues.containsKey(dropSetList.get(i).toString())) {
											List<Integer> nw = dropValues.get(dropSetList.get(i));
											if (!nw.contains(0)) {
												dropSetValues.get(dropSetList.get(i)).add(0);
											}
										}
									}

								}
							}
						}
						// }
						if (groupedData) {

							if (thenKey) {

								// No rule

							}

						}
					}

					log.debug("Check if ruleExpressionList.contains THEN");
					if (ruleExpressionList.contains("THEN")) {
						if (thenKey) {
							if (ruleExpressionList.contains("SUM")) {
								groupedData = false;
							}

							if (groupedData) {

								List fieldValues = new ArrayList();
								List fieldNames = new ArrayList();
								List operators = new ArrayList();
								for (int i = 0; i < ruleExpressionList.size(); i++) {

									if (!ruleExpressionList.get(i).equals("THEN")) {

										if (ruleExpressionList.get(i).equals("FIELD")) {
											fieldNames.add(ruleExpressionList.get(i + 1));
											operators.add(ruleExpressionList.get(i + 2));

										}
										if (ruleExpressionList.get(i).equals("VALUE")) {

											fieldValues.add(ruleExpressionList.get(i + 1));

										}

									}

									if (ruleExpressionList.get(i).equals("THEN")) {

										break;
									}

								}
								if (operators.get(0).equals("=")) {
									for (int i = 0; i < fieldNames.size(); i++) {
										// AND ??
										HashMap<String, ArrayList> getValues = repeatedFields
												.get(fieldNames.get(i).toString());
										if (!fuzzySearch) {
											if (getValues.containsKey(fieldValues.get(i))) {
												ArrayList<Integer> valuesGroup = getValues.get(fieldValues.get(i));
												finalValuesGroup = valuesGroup;
											}
										}
										if (fuzzySearch) {
											List filteredValues = new ArrayList();
											String fieldVal = fieldValues.get(i).toString();
											fieldVal = fieldVal.replace("%", "");
											for (Map.Entry<String, ArrayList> entry : getValues.entrySet()) {
												if (entry.getKey().contains(fieldVal)) {
													filteredValues.addAll(entry.getValue());
												}

											}
											ArrayList<Integer> valuesGroup = new ArrayList<>(filteredValues.size());
											valuesGroup.addAll(filteredValues);
											finalValuesGroup = valuesGroup;
										}

									}
								}

								if (operators.get(0).equals("<")) {
									for (int i = 0; i < fieldNames.size(); i++) {
										// AND ??
										double vald = Double.parseDouble(fieldValues.get(i).toString());

										HashMap<String, ArrayList> getValues = repeatedFields
												.get(fieldNames.get(i).toString());
										List filteredValues = new ArrayList();
										for (Map.Entry<String, ArrayList> entry : getValues.entrySet()) {
											if (Double.parseDouble(entry.getKey()) < vald) {
												filteredValues.addAll(entry.getValue());
											}
										}
										ArrayList<Integer> valuesGroup = new ArrayList<>(filteredValues.size());
										valuesGroup.addAll(filteredValues);
										finalValuesGroup = valuesGroup;

									}
								}
								if (operators.get(0).equals(">")) {
									for (int i = 0; i < fieldNames.size(); i++) {
										// AND ??
										double vald = Double.parseDouble(fieldValues.get(i).toString());

										HashMap<String, ArrayList> getValues = repeatedFields
												.get(fieldNames.get(i).toString());
										List filteredValues = new ArrayList();
										for (Map.Entry<String, ArrayList> entry : getValues.entrySet()) {
											if (Double.parseDouble(entry.getKey()) > vald) {
												filteredValues.addAll(entry.getValue());
											}
										}
										ArrayList<Integer> valuesGroup = new ArrayList<>(filteredValues.size());
										valuesGroup.addAll(filteredValues);
										finalValuesGroup = valuesGroup;

									}
								}

								HashMap<String, ArrayList<Integer>> substringIndexes = new HashMap();

								for (int j = 0; j < thenSetList.size(); j++) {
									for (XMLFields xmlField : xmlFieldsList) {
										if (thenSetList.get(j).toString().startsWith("SUBSTRING")) {
											String[] values = thenSetList.get(j).toString().split("\\)");
											String[] splitValues = values[0].split("\\(");
											String[] indeexes = splitValues[1].split(",");
											int beginIdx = Integer.parseInt(indeexes[0].trim());
											int endIdx = Integer.parseInt(indeexes[1].trim());
											if (values[1].equals(xmlField.getFieldName())) {
												xmlFieldsthenList.add(xmlField);
												ArrayList<Integer> indices = new ArrayList();
												indices.add(beginIdx);
												indices.add(endIdx);
												substringIndexes.put(xmlField.getFieldName(), indices);
											}
										} else if (!thenSetList.get(j).toString().startsWith("SUBSTRING")) {
											if (thenSetList.get(j).equals(xmlField.getFieldName())) {
												xmlFieldsthenList.add(xmlField);
											}
										}

									}
								}

								if (finalValuesGroup.isEmpty()) {
									continue nextRule;
								}

								for (int i = 0; i < finalValuesGroup.size(); i++) {
									for (XMLFields xmlField : xmlFieldsthenList)

									{
										if (finalValuesGroup.get(i).equals(xmlField.getGroupLevel())) {
											xmlFieldsthenFinalList.add(xmlField);
										}

									}

								}
								if (sendflag) {
									for (int i = 0; i < sendValueList.size(); i++) {

										if (!sendValue.containsKey(sendValueList.get(i + 1))) {

											LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
											List<Integer> al = new ArrayList();
											al.addAll(finalValuesGroup);
											if (substringIndexes.containsKey(sendValueList.get(i + 1))) {
												valAndGroup.put(sendValueList.get(i + 1).toString().substring(
														substringIndexes.get(sendValueList.get(i + 1)).get(0),
														substringIndexes.get(sendValueList.get(i + 1)).get(1)), al);
											}
											if (!substringIndexes.containsKey(sendValueList.get(i + 1))) {
												valAndGroup.put(sendValueList.get(i + 2).toString(), al);
											}
											sendValue.put(sendValueList.get(i + 1).toString(), valAndGroup);

										} else if (sendValue.containsKey(sendValueList.get(i + 1))) {
											if (sendValue.get(sendValueList.get(i + 1))
													.containsKey(sendValueList.get(i + 2))) {

												for (int j = 0; j < finalValuesGroup.size(); j++) {

													if (!sendValue.get(sendValueList.get(i + 1))
															.get(sendValueList.get(i + 2))
															.contains(finalValuesGroup.get(j))) {
														sendValue.get(sendValueList.get(i + 1))
														.get(sendValueList.get(i + 2)).add(finalValuesGroup.get(j));
													}
												}
											}
											if (!sendValue.get(sendValueList.get(i + 1))
													.containsKey(sendValueList.get(i + 2))) {
												ArrayList newal = new ArrayList();
												newal.add(finalValuesGroup);
												LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
														.get(sendValueList.get(i + 1));
												valAndGroup.put(sendValueList.get(i + 2).toString(), newal);

												sendValue.put(sendValueList.get(i + 1).toString(), valAndGroup);
											}

										}
										i = i + 2;
									}

								}
								for (int j = 0; j < thenSetList.size(); j++) {
									for (XMLFields xmlField : xmlFieldsthenFinalList) {

										if (!thenSetList.get(j).toString().startsWith("SUBSTRING")) {
											if (thenSetList.get(j).equals(xmlField.getFieldName())) {

												if (!sendValue.containsKey(sendList.get(j))) {
													LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
													List<Integer> al = new ArrayList();
													al.add(xmlField.getGroupLevel());
													valAndGroup.put(xmlField.getFieldValue(), al);
													sendValue.put(sendList.get(j).toString(), valAndGroup);
												} else if (sendValue.containsKey(sendList.get(j))) {
													if (sendValue.get(sendList.get(j))
															.containsKey(xmlField.getFieldValue())) {
														sendValue.get(sendList.get(j)).get(xmlField.getFieldValue())
														.add(xmlField.getGroupLevel());
													}
													if (!sendValue.get(sendList.get(j))
															.containsKey(xmlField.getFieldValue())) {
														ArrayList newal = new ArrayList();
														newal.add(xmlField.getGroupLevel());
														LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
																.get(sendList.get(j));
														valAndGroup.put(xmlField.getFieldValue(), newal);

														sendValue.put(sendList.get(j).toString(), valAndGroup);
													}

												}

											}
										}
										if (thenSetList.get(j).toString().startsWith("SUBSTRING")) {

											String[] values = thenSetList.get(j).toString().split("\\)");
											String[] splitValues = values[0].split("\\(");
											String[] indeexes = splitValues[1].split(",");

											if (values[1].equals(xmlField.getFieldName())) {

												if (!sendValue.containsKey(sendList.get(j))) {
													LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
													List<Integer> al = new ArrayList();
													al.add(xmlField.getGroupLevel());
													ArrayList<Integer> indices = substringIndexes
															.get(xmlField.getFieldName());
													if (xmlField.getFieldValue().length() > indices.get(1)) {
														valAndGroup.put(xmlField.getFieldValue()
																.substring(indices.get(0) - 1, indices.get(1)), al);
													}
													sendValue.put(sendList.get(j).toString(), valAndGroup);
												} else if (sendValue.containsKey(sendList.get(j))) {

													LinkedHashMap<String, List<Integer>> valGroupWithoutSubstring = sendValue
															.get(sendList.get(j));
													LinkedHashMap<String, List<Integer>> valGroupWithSubstring = new LinkedHashMap();
													for (Map.Entry<String, List<Integer>> tobeAddedvalGroupWithoutSubstring : valGroupWithoutSubstring
															.entrySet()) {

														ArrayList<Integer> indices = substringIndexes
																.get(xmlField.getFieldName());
														if (tobeAddedvalGroupWithoutSubstring.getKey()
																.length() > indices.get(1) - 1) {
															if (valGroupWithSubstring.containsKey(
																	tobeAddedvalGroupWithoutSubstring.getKey().substring(
																			indices.get(0) - 1, indices.get(1)))) {
																valGroupWithSubstring
																.get(tobeAddedvalGroupWithoutSubstring.getKey()
																		.substring(indices.get(0) - 1,
																				indices.get(1)))
																.addAll(tobeAddedvalGroupWithoutSubstring
																		.getValue());
															}
															if (!valGroupWithSubstring.containsKey(
																	tobeAddedvalGroupWithoutSubstring.getKey().substring(
																			indices.get(0) - 1, indices.get(1)))) {
																valGroupWithSubstring.put(
																		tobeAddedvalGroupWithoutSubstring.getKey()
																		.substring(indices.get(0) - 1,
																				indices.get(1)),
																		tobeAddedvalGroupWithoutSubstring.getValue());
															}

														}
													}
													sendValue.replace(sendList.get(j).toString(), valGroupWithSubstring);
													ArrayList<Integer> indices = substringIndexes
															.get(xmlField.getFieldName());

													if (sendValue.get(sendList.get(j)).containsKey(xmlField.getFieldValue()
															.substring(indices.get(0) - 1, indices.get(1)))) {

														sendValue
														.get(sendList.get(j)).get(xmlField.getFieldValue()
																.substring(indices.get(0) - 1, indices.get(1)))
														.add(xmlField.getGroupLevel());
													}

													if (!sendValue.get(sendList.get(j)).containsKey(xmlField.getFieldValue()
															.substring(indices.get(0) - 1, indices.get(1)))) {
														ArrayList newal = new ArrayList();
														newal.add(xmlField.getGroupLevel());
														LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
																.get(sendList.get(j));
														valAndGroup.put(xmlField.getFieldValue()
																.substring(indices.get(0) - 1, indices.get(1)), newal);

														sendValue.put(sendList.get(j).toString(), valAndGroup);
													}

												}

											}
										}
									}

								}

								if (ruleExpressionList.contains("DROP")) {
									log.debug("Rule expression contains drop");
									for (int i = 0; i < dropList.size(); i++) {

										for (int j = 0; j < finalValuesGroup.size(); j++) {
											if (!dropValues.containsKey(dropList.get(i).toString())) {
												dropValues.put(dropList.get(i).toString(),
														new ArrayList(finalValuesGroup.get(j)));

											}
											if (dropValues.containsKey(dropList.get(i).toString())) {

												List<Integer> nw = dropValues.get(dropList.get(i));
												if (!nw.contains(finalValuesGroup.get(j))) {
													dropValues.get(dropList.get(i)).add(finalValuesGroup.get(j));
												}

											}

										}

									}

								}
								if (ruleExpressionList.contains("DROPSET")) {
									for (int i = 0; i < dropSetList.size(); i++) {

										for (int j = 0; j < finalValuesGroup.size(); j++) {
											if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
												dropSetValues.put(dropSetList.get(i).toString(),
														new ArrayList(finalValuesGroup.get(j)));

											}
											if (dropSetValues.containsKey(dropSetList.get(i).toString())) {

												List<Integer> nw = dropSetValues.get(dropSetList.get(i));
												if (!nw.contains(finalValuesGroup.get(j))) {
													dropSetValues.get(dropSetList.get(i)).add(finalValuesGroup.get(j));
												}

											}

										}

									}

								}

							}

						}

						if (!groupedData) {
							if (thenKey) {
								List fieldValues = new ArrayList();
								List fieldNames = new ArrayList();
								List operators = new ArrayList();
								for (int i = 0; i < ruleExpressionList.size(); i++) {

									if (!ruleExpressionList.get(i).equals("THEN")) {
										log.debug("If rule expression does not equal THEN");
										if (ruleExpressionList.get(i).equals("FIELD")) {
											fieldNames.add(ruleExpressionList.get(i + 1));
											operators.add(ruleExpressionList.get(i + 2));

										}
										if (ruleExpressionList.get(i).equals("VALUE")) {
											fieldValues.add(ruleExpressionList.get(i + 1));

										}

									}

									if (ruleExpressionList.get(i).equals("THEN")) {
										log.debug("If rule expression equals THEN");
										break;
									}

								}

								Boolean subsstringCalVal = false;
								if (operators.isEmpty() && fieldValues.isEmpty() && fieldNames.isEmpty()) {

									if (ruleExpressionList.get(1).equals(">")) {
										if (Double.parseDouble(ruleExpressionList.get(0).toString()) > Double
												.parseDouble(ruleExpressionList.get(2).toString())) {
											subsstringCalVal = true;
											finalValuesGroup.add(0);
										}
									} else if (ruleExpressionList.get(1).equals("<")) {
										if (Double.parseDouble(ruleExpressionList.get(0).toString()) < Double
												.parseDouble(ruleExpressionList.get(2).toString())) {
											subsstringCalVal = true;
											finalValuesGroup.add(0);
										}

									} else if (ruleExpressionList.get(0).toString()
											.equalsIgnoreCase(ruleExpressionList.get(2).toString())) {
										subsstringCalVal = true;
										finalValuesGroup.add(0);
									}

									if (!subsstringCalVal) {
										// continue nextRule;
										log.info("!subsstringCalVal entered");
									}

								}
								if (!operators.isEmpty() && !fieldValues.isEmpty() && !fieldNames.isEmpty()) {
									if (operators.get(0).equals("=")) {

										subsstringCalVal = true;
										for (int i = 0; i < fieldNames.size(); i++) {
											// AND ??
											HashMap<String, ArrayList> getValues = repeatedFields
													.get(fieldNames.get(i).toString());
											if (!fuzzySearch) {
												if (getValues.containsKey(fieldValues.get(i))) {
													ArrayList<Integer> valuesGroup = getValues.get(fieldValues.get(i));
													finalValuesGroup = valuesGroup;
												}
											}
											if (fuzzySearch) {
												List filteredValues = new ArrayList();
												String fieldVal = fieldValues.get(i).toString();
												fieldVal = fieldVal.replace("%", "");
												for (Map.Entry<String, ArrayList> entry : getValues.entrySet()) {
													if (entry.getKey().contains(fieldVal)) {
														filteredValues.addAll(entry.getValue());
													}

												}
												ArrayList<Integer> valuesGroup = new ArrayList<>(filteredValues.size());
												valuesGroup.addAll(filteredValues);
												finalValuesGroup = valuesGroup;
											}

										}
									}

									if (operators.get(0).equals("<")) {
										subsstringCalVal = true;
										for (int i = 0; i < fieldNames.size(); i++) {
											// AND ??
											double vald = Double.parseDouble(fieldValues.get(i).toString());

											HashMap<String, ArrayList> getValues = repeatedFields
													.get(fieldNames.get(i).toString());
											List filteredValues = new ArrayList();
											for (Map.Entry<String, ArrayList> entry : getValues.entrySet()) {
												if (Double.parseDouble(entry.getKey()) < vald) {
													filteredValues.addAll(entry.getValue());
												}
											}
											ArrayList<Integer> valuesGroup = new ArrayList<>(filteredValues.size());
											valuesGroup.addAll(filteredValues);
											finalValuesGroup = valuesGroup;

										}
									}
									if (operators.get(0).equals(">")) {
										subsstringCalVal = true;
										for (int i = 0; i < fieldNames.size(); i++) {
											// AND ??
											double vald = Double.parseDouble(fieldValues.get(i).toString());

											HashMap<String, ArrayList> getValues = repeatedFields
													.get(fieldNames.get(i).toString());
											List filteredValues = new ArrayList();
											for (Map.Entry<String, ArrayList> entry : getValues.entrySet()) {
												if (Double.parseDouble(entry.getKey()) > vald) {
													filteredValues.addAll(entry.getValue());
												}
											}
											ArrayList<Integer> valuesGroup = new ArrayList<>(filteredValues.size());
											valuesGroup.addAll(filteredValues);
											finalValuesGroup = valuesGroup;

										}
									}

								}

								if (subsstringCalVal) {

									Set<String> set = new LinkedHashSet<>();

									set.addAll(sendList);
									sendList.clear();
									sendList.addAll(set);

									set.clear();

									if (finalValuesGroup.isEmpty()) {
										continue nextRule;
									}

									HashMap<String, ArrayList<Integer>> substringIndexes = new HashMap();
									for (int j = 0; j < thenSetList.size(); j++) {
										for (XMLFields xmlField : xmlFieldsList) {
											if (thenSetList.get(j).toString().startsWith("SUBSTRING")) {
												String[] values = thenSetList.get(j).toString().split("\\)");
												String[] splitValues = values[0].split("\\(");
												String[] indeexes = splitValues[1].split(",");
												int beginIdx = Integer.parseInt(indeexes[0].trim());
												int endIdx = Integer.parseInt(indeexes[1].trim());
												if (values[1].equals(xmlField.getFieldName())) {
													xmlFieldsthenList.add(xmlField);
													ArrayList<Integer> indices = new ArrayList();
													indices.add(beginIdx);
													indices.add(endIdx);
													substringIndexes.put(xmlField.getFieldName(), indices);
												}
											} else if (!thenSetList.get(j).toString().startsWith("SUBSTRING")) {
												if (thenSetList.get(j).equals(xmlField.getFieldName())) {
													xmlFieldsthenList.add(xmlField);
												}
											}

										}
									}

									for (int i = 0; i < finalValuesGroup.size(); i++) {
										for (XMLFields xmlField : xmlFieldsthenList)

										{
											if (finalValuesGroup.get(i).equals(xmlField.getGroupLevel())) {
												xmlFieldsthenFinalList.add(xmlField);
											}

										}

									}

									for (int i = 0; i < sumList.size(); i++) {
										HashMap<String, ArrayList> groupedValuetobeSum = repeatedFields.get(sumList.get(i));

										List repeatedValues = new ArrayList();
										List repeatedValuesSum = new ArrayList();

										HashMap<String, ArrayList> tobeAddedSUMKey = new HashMap();

										for (Map.Entry<String, ArrayList> sumofOnlyGrouped : groupedValuetobeSum
												.entrySet()) {
											List<Integer> allgroups = sumofOnlyGrouped.getValue();
											for (int k = 0; k < allgroups.size(); k++) {
												if (finalValuesGroup.contains(allgroups.get(k))) {
													if (tobeAddedSUMKey.containsKey(sumofOnlyGrouped.getKey())) {
														tobeAddedSUMKey.get(sumofOnlyGrouped.getKey())
														.add(allgroups.get(k));
													} else if (!tobeAddedSUMKey.containsKey(sumofOnlyGrouped.getKey())) {
														ArrayList newal = new ArrayList();
														newal.add(allgroups.get(k));
														tobeAddedSUMKey.put(sumofOnlyGrouped.getKey(), newal);

													}
												}
											}
										}

										for (Map.Entry<String, ArrayList> tobeAddedSUMKeys : tobeAddedSUMKey.entrySet()) {

											if (tobeAddedSUMKeys.getValue().size() > 1) {
												String finalVal = "";
												String sumVal = tobeAddedSUMKeys.getKey() + "*"
														+ tobeAddedSUMKeys.getValue().size();
												ScriptEngineManager mgr = new ScriptEngineManager();
												ScriptEngine engine = mgr.getEngineByName("nashorn");
												try {
													finalVal = engine.eval(sumVal).toString();
												} catch (ScriptException e) {
													log.info("Error Evaluating Final ExpressionList", e.getMessage());
												}
												repeatedValues.add(finalVal.toString());
											} else if (tobeAddedSUMKeys.getValue().size() == 1) {
												repeatedValues.add(tobeAddedSUMKeys.getKey().toString());
											}
										}
										for (int j = 0; j < repeatedValues.size(); j++) {
											repeatedValuesSum.add(repeatedValues.get(j).toString());
											if (j != repeatedValues.size() - 1) {
												repeatedValuesSum.add("+");
											}
										}
										String repeatedfieldSumValue = new String();
										String listString = String.join("", repeatedValuesSum);
										ScriptEngineManager mgr = new ScriptEngineManager();
										ScriptEngine engine = mgr.getEngineByName("nashorn");
										try {
											repeatedfieldSumValue = engine.eval(listString).toString();
										} catch (ScriptException e) {
											log.info("Error Evaluating Final ExpressionList", e.getMessage());
										}

										if (!sendValue.containsKey(sumList.get(i + 1))) {
											LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
											List<Integer> al = new ArrayList();
											if (sendGroup) {
												al.add(1);
											} else {
												al.add(0);
											}
											valAndGroup.put(repeatedfieldSumValue, al);
											sendValue.put(sumList.get(i + 1).toString(), valAndGroup);
										} else if (sendValue.containsKey(sumList.get(i + 1))) {
											if (sendValue.get(sumList.get(i + 1)).containsKey(repeatedfieldSumValue)) {
												if (sendGroup) {

													if (!sendValue.get(sumList.get(i + 1)).get(repeatedfieldSumValue)
															.contains(1)) {
														sendValue.get(sumList.get(i + 1)).get(repeatedfieldSumValue).add(1);
													}
												} else {
													if (!sendValue.get(sumList.get(i + 1)).get(repeatedfieldSumValue)
															.contains(0)) {
														sendValue.get(sumList.get(i + 1)).get(repeatedfieldSumValue).add(0);
													}
												}
											}
											if (!sendValue.get(sumList.get(i + 1)).containsKey(repeatedfieldSumValue)) {
												ArrayList newal = new ArrayList();
												if (sendGroup) {

													newal.add(1);
												} else {
													newal.add(0);
												}
												LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
														.get(sumList.get(i + 1));
												valAndGroup.put(repeatedfieldSumValue, newal);

												sendValue.put(sumList.get(i + 1).toString(), valAndGroup);
											}

										}
										i++;
									}

									if (sendflag) {
										for (int i = 0; i < sendValueList.size(); i++) {

											if (!sendValue.containsKey(sendValueList.get(i + 1))) {
												LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
												List<Integer> al = new ArrayList();
												if (sendGroup) {
													al.add(1);
												} else {
													al.add(0);
												}
												valAndGroup.put(sendValueList.get(i + 2).toString(), al);
												sendValue.put(sendValueList.get(i + 1).toString(), valAndGroup);

											} else if (sendValue.containsKey(sendValueList.get(i + 1))) {
												if (sendValue.get(sendValueList.get(i + 1))
														.containsKey(sendValueList.get(i + 2))) {
													if (sendGroup) {
														if (!sendValue.get(sendValueList.get(i + 1))
																.get(sendValueList.get(i + 2)).contains(1)) {
															sendValue.get(sendValueList.get(i + 1))
															.get(sendValueList.get(i + 2)).add(1);
														}
													} else {
														if (!sendValue.get(sendValueList.get(i + 1))
																.get(sendValueList.get(i + 2)).contains(0)) {
															sendValue.get(sendValueList.get(i + 1))
															.get(sendValueList.get(i + 2)).add(0);
														}
													}
												}
												if (!sendValue.get(sendValueList.get(i + 1))
														.containsKey(sendValueList.get(i + 2))) {
													ArrayList newal = new ArrayList();
													if (sendGroup) {
														newal.add(1);
													} else {
														newal.add(0);
													}
													LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
															.get(sendValueList.get(i + 1));
													valAndGroup.put(sendValueList.get(i + 2).toString(), newal);

													sendValue.put(sendValueList.get(i + 1).toString(), valAndGroup);
												}

											}
											i = i + 2;
										}

									}

									for (int j = 0; j < thenSetList.size(); j++) {
										for (XMLFields xmlField : xmlFieldsthenFinalList) {

											if (!thenSetList.get(j).toString().startsWith("SUBSTRING")) {
												if (thenSetList.get(j).equals(xmlField.getFieldName())) {

													if (!sendValue.containsKey(sendList.get(j))) {
														LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
														List<Integer> al = new ArrayList();
														if (sendGroup) {
															al.add(1);
														} else {
															al.add(0);
														}
														valAndGroup.put(xmlField.getFieldValue(), al);
														sendValue.put(sendList.get(j).toString(), valAndGroup);
													} else if (sendValue.containsKey(sendList.get(j))) {

														if (sendValue.get(sendList.get(j))
																.containsKey(xmlField.getFieldValue())) {
															if (sendGroup) {
																if (!sendValue.get(sendList.get(j))
																		.get(xmlField.getFieldValue()).contains(1)) {
																	sendValue.get(sendList.get(j))
																	.get(xmlField.getFieldValue()).add(1);
																}
															} else {
																if (!sendValue.get(sendList.get(j))
																		.get(xmlField.getFieldValue()).contains(0)) {
																	sendValue.get(sendList.get(j))
																	.get(xmlField.getFieldValue()).add(0);
																}
															}

														}
														if (!sendValue.get(sendList.get(j))
																.containsKey(xmlField.getFieldValue())) {
															ArrayList newal = new ArrayList();
															if (sendGroup) {
																newal.add(1);
															} else {
																newal.add(0);
															}
															LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
																	.get(sendList.get(j));
															valAndGroup.put(xmlField.getFieldValue(), newal);

															sendValue.put(sendList.get(j).toString(), valAndGroup);
														}

													}

												}
											}
											if (thenSetList.get(j).toString().startsWith("SUBSTRING")) {

												String[] values = thenSetList.get(j).toString().split("\\)");
												String[] splitValues = values[0].split("\\(");
												String[] indeexes = splitValues[1].split(",");

												if (values[1].equals(xmlField.getFieldName())) {

													if (!sendValue.containsKey(sendList.get(j))) {
														LinkedHashMap<String, List<Integer>> valAndGroup = new LinkedHashMap();
														List<Integer> al = new ArrayList();
														if (sendGroup) {
															al.add(1);
														} else {
															al.add(0);
														}
														ArrayList<Integer> indices = substringIndexes
																.get(xmlField.getFieldName());
														if (xmlField.getFieldValue().length() > indices.get(1)) {
															valAndGroup.put(xmlField.getFieldValue()
																	.substring(indices.get(0) - 1, indices.get(1)), al);
														}
														sendValue.put(sendList.get(j).toString(), valAndGroup);
													} else if (sendValue.containsKey(sendList.get(j))) {

														LinkedHashMap<String, List<Integer>> valGroupWithoutSubstring = sendValue
																.get(sendList.get(j));
														LinkedHashMap<String, List<Integer>> valGroupWithSubstring = new LinkedHashMap();
														for (Map.Entry<String, List<Integer>> tobeAddedvalGroupWithoutSubstring : valGroupWithoutSubstring
																.entrySet()) {

															ArrayList<Integer> indices = substringIndexes
																	.get(xmlField.getFieldName());
															if (tobeAddedvalGroupWithoutSubstring.getKey()
																	.length() > indices.get(1) - 1) {
																if (valGroupWithSubstring
																		.containsKey(tobeAddedvalGroupWithoutSubstring
																				.getKey().substring(indices.get(0) - 1,
																						indices.get(1)))) {
																	valGroupWithSubstring
																	.get(tobeAddedvalGroupWithoutSubstring.getKey()
																			.substring(indices.get(0) - 1,
																					indices.get(1)))
																	.addAll(tobeAddedvalGroupWithoutSubstring
																			.getValue());
																}
																if (!valGroupWithSubstring
																		.containsKey(tobeAddedvalGroupWithoutSubstring
																				.getKey().substring(indices.get(0) - 1,
																						indices.get(1)))) {
																	valGroupWithSubstring.put(
																			tobeAddedvalGroupWithoutSubstring.getKey()
																			.substring(indices.get(0) - 1,
																					indices.get(1)),
																			tobeAddedvalGroupWithoutSubstring.getValue());
																}

															}
														}
														sendValue.replace(sendList.get(j).toString(),
																valGroupWithSubstring);
														ArrayList<Integer> indices = substringIndexes
																.get(xmlField.getFieldName());

														if (sendValue.get(sendList.get(j))
																.containsKey(xmlField.getFieldValue()
																		.substring(indices.get(0) - 1, indices.get(1)))) {
															if (sendGroup) {
																if (!sendValue.get(sendList.get(j))
																		.get(xmlField.getFieldValue().substring(
																				indices.get(0) - 1, indices.get(1)))
																		.contains(1)) {
																	sendValue.get(sendList.get(j))
																	.get(xmlField.getFieldValue().substring(
																			indices.get(0) - 1, indices.get(1)))
																	.add(1);
																}
															} else {
																if (!sendValue.get(sendList.get(j))
																		.get(xmlField.getFieldValue().substring(
																				indices.get(0) - 1, indices.get(0)))
																		.contains(1)) {
																	sendValue.get(sendList.get(j))
																	.get(xmlField.getFieldValue().substring(
																			indices.get(0) - 1, indices.get(1)))
																	.add(0);
																}
															}
														}

														if (!sendValue.get(sendList.get(j))
																.containsKey(xmlField.getFieldValue()
																		.substring(indices.get(0) - 1, indices.get(1)))) {
															ArrayList newal = new ArrayList();
															if (sendGroup) {
																newal.add(1);
															} else {
																newal.add(0);
															}
															LinkedHashMap<String, List<Integer>> valAndGroup = sendValue
																	.get(sendList.get(j));
															valAndGroup.put(xmlField.getFieldValue()
																	.substring(indices.get(0) - 1, indices.get(1)), newal);

															sendValue.put(sendList.get(j).toString(), valAndGroup);
														}

													}

												}
											}
										}

									}

									if (ruleExpressionList.contains("DROP")) {
										for (int i = 0; i < dropList.size(); i++) {

											for (int j = 0; j < finalValuesGroup.size(); j++) {
												if (!dropValues.containsKey(dropList.get(i).toString())) {
													dropValues.put(dropList.get(i).toString(),
															new ArrayList(finalValuesGroup.get(j)));

												}
												if (dropValues.containsKey(dropList.get(i).toString())) {

													List<Integer> nw = dropValues.get(dropList.get(i));
													if (!nw.contains(finalValuesGroup.get(j))) {
														dropValues.get(dropList.get(i)).add(finalValuesGroup.get(j));
													}

												}

											}

										}

									}
									if (ruleExpressionList.contains("DROPSET")) {
										for (int i = 0; i < dropSetList.size(); i++) {

											for (int j = 0; j < finalValuesGroup.size(); j++) {
												if (!dropSetValues.containsKey(dropSetList.get(i).toString())) {
													dropSetValues.put(dropSetList.get(i).toString(),
															new ArrayList(finalValuesGroup.get(j)));

												}
												if (dropSetValues.containsKey(dropSetList.get(i).toString())) {

													List<Integer> nw = dropSetValues.get(dropSetList.get(i));
													if (!nw.contains(finalValuesGroup.get(j))) {
														dropSetValues.get(dropSetList.get(i)).add(finalValuesGroup.get(j));
													}

												}

											}

										}

									}
								}

							}
						}
					}

					log.debug("Check transalationPaths FinalDropSet");
					if (transalationPaths.getFinalDropSet() != null) {
						LinkedHashMap<String, List<Integer>> existingDropSet = transalationPaths.getFinalDropSet();
						LinkedHashMap<String, List<Integer>> tobeAddedDropSet = dropSetValues;
						for (Map.Entry<String, List<Integer>> tobeAddedDropSetKeys : tobeAddedDropSet.entrySet()) {
							if (existingDropSet.containsKey(tobeAddedDropSetKeys.getKey())) {

								List<Integer> existingDroppedSetGroups = existingDropSet.get(tobeAddedDropSetKeys.getKey());
								List<Integer> tobeAddedDropSetKeysGroups = tobeAddedDropSetKeys.getValue();
								for (int i = 0; i < tobeAddedDropSetKeysGroups.size(); i++) {
									if (!existingDroppedSetGroups.contains(tobeAddedDropSetKeysGroups.get(i))) {
										existingDroppedSetGroups.add(tobeAddedDropSetKeysGroups.get(i));
									}

								}
							} else if (!existingDropSet.containsKey(tobeAddedDropSetKeys.getKey()))

							{
								existingDropSet.put(tobeAddedDropSetKeys.getKey(), tobeAddedDropSetKeys.getValue());
							}
						}
					} else if (transalationPaths.getFinalDropSet() == null) {
						transalationPaths.setFinalDropSet(dropSetValues);
					}

					log.debug("Check transalationPaths FinalDrop");
					if (transalationPaths.getFinalDrop() != null) {
						LinkedHashMap<String, List<Integer>> existingDrop = transalationPaths.getFinalDrop();
						LinkedHashMap<String, List<Integer>> tobeAddedDrop = dropValues;
						for (Map.Entry<String, List<Integer>> tobeAddedDropKeys : tobeAddedDrop.entrySet()) {
							if (existingDrop.containsKey(tobeAddedDropKeys.getKey())) {

								List<Integer> existingDroppedGroups = existingDrop.get(tobeAddedDropKeys.getKey());
								List<Integer> tobeAddedDropKeysGroups = tobeAddedDropKeys.getValue();
								for (int i = 0; i < tobeAddedDropKeysGroups.size(); i++) {
									if (!existingDroppedGroups.contains(tobeAddedDropKeysGroups.get(i))) {
										existingDroppedGroups.add(tobeAddedDropKeysGroups.get(i));
									}

								}
							} else if (!existingDrop.containsKey(tobeAddedDropKeys.getKey()))

							{
								existingDrop.put(tobeAddedDropKeys.getKey(), tobeAddedDropKeys.getValue());
							}
						}
					} else if (transalationPaths.getFinalDrop() == null) {
						log.debug("DropValues before setting in translation path: {}", dropValues);
						transalationPaths.setFinalDrop(dropValues);
					}

					log.debug("Check transalationPaths TranslatedSendVal");
					if (transalationPaths.getTranslatedSendVal() != null) {
						LinkedHashMap<String, LinkedHashMap<String, List<Integer>>> listOfFieldsGrouped = transalationPaths
								.getTranslatedSendVal();

						for (Map.Entry<String, LinkedHashMap<String, List<Integer>>> replacementKeys : sendValue
								.entrySet()) {
							if (!listOfFieldsGrouped.containsKey(replacementKeys.getKey())) {

								listOfFieldsGrouped.put(replacementKeys.getKey().toString(), replacementKeys.getValue());
							} else if (listOfFieldsGrouped.containsKey(replacementKeys.getKey())) {

								LinkedHashMap<String, List<Integer>> existingMap = listOfFieldsGrouped
										.get(replacementKeys.getKey());
								LinkedHashMap<String, List<Integer>> tobeAddedMap = replacementKeys.getValue();
								for (Map.Entry<String, List<Integer>> tobeAddedMapKeys : tobeAddedMap.entrySet()) {
									if (existingMap.containsKey(tobeAddedMapKeys.getKey())) {
										List<Integer> existingGroups = existingMap.get(tobeAddedMapKeys.getKey());
										List<Integer> tobeAddedGroups = tobeAddedMapKeys.getValue();
										for (int i = 0; i < tobeAddedGroups.size(); i++) {
											if (!existingGroups.contains(tobeAddedGroups.get(i))) {
												existingGroups.add(tobeAddedGroups.get(i));
											}
										}

									} else if (!existingMap.containsKey(tobeAddedMapKeys.getKey())) {
										listOfFieldsGrouped.get(replacementKeys.getKey()).put(tobeAddedMapKeys.getKey(),
												tobeAddedMapKeys.getValue());
									}
								}
							}

						}

					} else if (transalationPaths.getTranslatedSendVal() == null) {
						transalationPaths.setTranslatedSendVal(sendValue);
					}

					log.info("End processing LTERule RuleID: {}, RuleName: {}", rule.getId(), rule.getLteRuleName());

				}catch (final Exception e) {
					log.debug("Rule Expression processing failed!. Failed Rule: {}. ", rule, e);
				}
			}


		} // end for loop for LTERule
		log.debug("Finished nextRule loop.");
		log.debug("Exit processLTERules() method of LTEProcessUtils class.");
		return transalationPaths;
	}
	/**
	 * @param calculationJSON
	 * @param xmlFieldsList
	 * @param xmlFieldValueMap
	 * @param calcList
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String getCalculatedValue(String calculationJSON, List<XMLFields> xmlFieldsList,
			Map<String, String> xmlFieldValueMap, List<Calculation> calcList)
					throws JsonParseException, JsonMappingException, IOException {
		log.debug("Enter getCalculatedValue() method of LTEProcessUtils class.");

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List ruleExpressionList = new ArrayList();
		ScriptEngineManager mgr = new ScriptEngineManager();

		ScriptEngine engine = mgr.getEngineByName("nashorn");
		String ruleLogic = calculationJSON;
		StringBuilder calculation = new StringBuilder();
		log.debug("Proccessing Calculation...{}", ruleLogic);

		ObjectMapper mapper = new ObjectMapper();

		RegulationRuleLogicExpression[] ruleExpression = mapper.readValue(ruleLogic,
				RegulationRuleLogicExpression[].class);

		log.debug("Size of elements in calculationJSON: {}", ruleExpression != null ? ruleExpression.length : 0);
		Boolean[] regulationRuleQualifier = { false };
		Boolean fieldFound = Boolean.FALSE;
		for (RegulationRuleLogicExpression element : ruleExpression) {

			if (element.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
				log.debug("Processing Field: {}", element.getValue());
				if (element.getFieldExpressionPrefix().equals("CA")) {
					regulationRuleQualifier[0] = true;
					String field = element.getValue();
					for (int j = 0; j < calcList.size(); j++) {

						if (calcList.get(j).getCalculationName().equals(field)) {
							log.debug("Proccessing Calculation for field: {}", field);
							if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
									|| calcList.get(j).getFinanceType().isEmpty()
									|| calcList.get(j).getFinanceType() == null) {
								if (calcList.get(j).getState().equals(xmlFieldValueMap.get("ContractExecutionState"))
										|| calcList.get(j).getState().isEmpty() || calcList.get(j).getState() == null) {
									if (calcList.get(j).getLender().equals(xmlFieldValueMap.get("LenderPartyId"))
											|| calcList.get(j).getLender().isEmpty()
											|| calcList.get(j).getLender() == null) {
										regulationRuleQualifier[0] = true;
										try {
											String reResult = getCalculatedValue(calcList.get(j).getCalculationJSON(),
													xmlFieldsList, xmlFieldValueMap, calcList);
											log.debug("Calculated result for field: {} is {}", field, reResult);
											if (reResult.equals("Skip Rule")) {
												regulationRuleQualifier[0] = false;
												break;
											}
											else
											{
												log.debug("PreventNegativeValue of {} is {}", calcList.get(j).getCalculationName(), calcList.get(j).getPreventNegativeValue());
												if (calcList.get(j).getPreventNegativeValue() && reResult.startsWith("-"))
												{
													String negativeValue = reResult;
													reResult = "0.00";
													log.debug("Updated value of {} from {} to {}", calcList.get(j).getCalculationName(), negativeValue, reResult);
												}
											}

											ruleExpressionList.add(reResult);

										} catch (IOException e) {
											log.error("Exception while LTE Rule Expression Proccessing, in Calculation",
													e.getMessage());
										}
									} else {
										regulationRuleQualifier[0] = false;
										break;
									}
								} else {
									regulationRuleQualifier[0] = false;
									break;
								}
							} else {
								regulationRuleQualifier[0] = false;
								break;
							}
						}

					}

				}
				if (element.getFieldExpressionPrefix().equals("CR")) {
					regulationRuleQualifier[0] = true;

					return "Skip Rule";

				}
				if (element.getFieldExpressionPrefix().equals("CO")) {

					String field = element.getValue();
					log.debug("Trying to match {} with available fields in xmlFieldsList", field);

					for (XMLFields xmlField : xmlFieldsList) {

						if (field.equalsIgnoreCase(xmlField.getFieldName())) {
							fieldFound = Boolean.TRUE;
							log.info("FieldName {} and FieldValue from XML {}", xmlField.getFieldName(), field);
							regulationRuleQualifier[0] = true;
							if (xmlField.getFieldType().equals("DATETIME")) {
								Date dateFromXML = new Date();
								try {
									dateFromXML = formatter.parse(xmlField.getFieldValue());
								} catch (ParseException e) {
									log.error(
											"Exception while LTE Rule Expression Proccessing:  Wrong Date Format on XML "
													+ e.getMessage());
									throw new BadRequestException(
											"Exception while LTE Rule Expression Proccessing:  Wrong Date Format on XML "
													+ e.getMessage());
								}

								ruleExpressionList.add("DATETIME");
								ruleExpressionList.add(dateFromXML);

							} else if (xmlField.getFieldType().equals("NUMERIC")
									|| xmlField.getFieldType().equals("TEXT")) {
								ruleExpressionList.add(xmlField.getFieldValue());

							}
							break;

						}
						else
						{
							fieldFound = Boolean.FALSE;
						}

					}

					if (!fieldFound)
					{
						log.debug("Field {} not available in xmlFieldsList", field);
					}

				}

			}

			if (element.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.OPERATOR)) {

				String lastItem = "";
				if (ruleExpressionList.size() > 0)
				{
					lastItem = String.valueOf(ruleExpressionList.get(ruleExpressionList.size() - 1));
				}

				if (!lastItem.equals("+") && !lastItem.equals("-") && !lastItem.equals("*") && !lastItem.equals("/"))
				{
					String op = element.getValue();
					ruleExpressionList.add(op);
				}


			}

			if (element.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.VALUE)) {
				String value = element.getValue();
				ruleExpressionList.add(value);

			}

		}

		if (!regulationRuleQualifier[0]) {
			return "Skip Rule";
		}

		if (ruleExpressionList.contains("DATETIME")) {
			List ruleExpressionDate = new ArrayList();
			for (int i = 0; i < ruleExpressionList.size(); i++) {
				if (ruleExpressionList.get(i).equals("DATETIME")) {
					if (!String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
						if (ruleExpressionList.get(i + 2).equals("=")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException("LTE Rule : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.equals(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 3;

						} else if (ruleExpressionList.get(i + 2).equals(">")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException("LTE Rule : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.before(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 3;
						} else if (ruleExpressionList.get(i + 2).equals("<")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException("LTE Rule : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.after(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 3;
						}
					} else if (String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
						if (ruleExpressionList.get(i + 2).equals("=")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException("LTE Rule : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.equals(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 4;

						} else if (ruleExpressionList.get(i + 2).equals(">")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException("LTE Rule : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.before(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 4;
						} else if (ruleExpressionList.get(i + 2).equals("<")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException("LTE Rule : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.after(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 4;
						}
					}

				} else {
					ruleExpressionDate.add(ruleExpressionList.get(i));
				}
			}
			ruleExpressionList.clear();
			ruleExpressionList.addAll(ruleExpressionDate);

		}
		String listString = String.join("", ruleExpressionList);
		log.debug("Arithmetic expression for calculation: {}", listString);
		String lastItem = String.valueOf(ruleExpressionList.get(ruleExpressionList.size() - 1));
		if (lastItem.equals("+") || lastItem.equals("-") || lastItem.equals("*") || lastItem.equals("/"))
		{
			log.debug("Removing obsolete opertor [{}] from end of arithmetic expression", lastItem);
			ruleExpressionList.remove(ruleExpressionList.size() - 1);
			listString = String.join("", ruleExpressionList);
			log.debug("Corrected Arithmetic expression: {}", listString);
		}
		String result = "";
		try {
			result = engine.eval(listString).toString();
		} catch (ScriptException e) {
			log.debug("Error Evaluating Final ExpressionList", e.getMessage());
		}
		log.debug("Exit getCalculatedValue() method of LTEProcessUtils class. result: {}", result);
		return result;
	}

	/**
	 * @param rulelist
	 * @param xmlLookUpFieldMap
	 * @return
	 */
	public Optional<LookUpCriteriaPassRulesLTE> lookupFieldCheck(List<LTErule> rulelist,
			Map<String, String> xmlLookUpFieldMap) {

		log.debug("Enter lookupFieldCheck() method of LTEProcessUtils class.");

		LookUpCriteriaPassRulesLTE lookUpCriteriaPassRules = new LookUpCriteriaPassRulesLTE();
		List<StringentRuleQualificationLTE> stringentRuleList = new ArrayList<>();

		TreeMap<Integer, String> hirerachyTreeMap = new TreeMap<>();
		hirerachyTreeMap.put(1, "ContractExecutionState");
		hirerachyTreeMap.put(2, "FinanceType");
		hirerachyTreeMap.put(3, "ApplicationType");
		hirerachyTreeMap.put(4, "ProductType");
		hirerachyTreeMap.put(5, "LenderPartyId");
		hirerachyTreeMap.put(6, "SenderCreatorNameCode");
		hirerachyTreeMap.put(7, "DestinationNameCode");

		List<LTErule> masterrulelist = new ArrayList<>();

		outerloop: for (LTErule rule : rulelist) {
			log.debug("LookUp Criteria Proccessing for rule with RuleID: {}, RuleName: {}", rule.getId(),
					rule.getLteRuleName());

			HashMap<String, String> lookupWithHirearchy = new HashMap<>();
			HashMap<String, String> lookupNoHirearchy = new HashMap<>();
			ObjectMapper mapper = new ObjectMapper();
			LinkedHashMap<String, String> lookupCriteriaMap = new LinkedHashMap<>();

			Boolean stringentRule = false;

			int stringentlookupFieldCount = 0;
			TreeMap<Integer, Boolean> stringentRuleQualifier = new TreeMap<>();
			StringentRuleQualificationLTE sRQ = new StringentRuleQualificationLTE();
			List<Integer> stringentRuleHierarchyList = new ArrayList<>();

			Boolean ruleQualifier = false;
			int lookupFieldCount = 0;

			String lookupCriteria = rule.getLookupCriteria();

			TypeReference<LinkedHashMap<String, String>> typeRef = new TypeReference<LinkedHashMap<String, String>>() {
			};

			try {
				lookupCriteriaMap = mapper.readValue(lookupCriteria, typeRef);
			} catch (Exception e) {
				log.debug("Exception while parsing lookup fields " + e.getMessage());
				throw new BadRequestException("Exception while parsing lookup fields " + e.getMessage());
			}
			StringBuilder masterRuleString = new StringBuilder();
			masterRuleString
			.append(lookupCriteriaMap.toString().substring(1, lookupCriteriaMap.toString().length() - 1));

			if (masterRuleString.length() == 0) {
				masterrulelist.add(rule);
				continue;
			}

			for (String lookupName : lookupCriteriaMap.keySet()) {

				if (xmlLookUpFieldMap.containsKey(lookupName)) {

					if (hirerachyTreeMap.containsValue(lookupName)) {
						lookupWithHirearchy.put(lookupName, lookupCriteriaMap.get(lookupName));
					} else if (!hirerachyTreeMap.containsValue(lookupName)) {
						lookupNoHirearchy.put(lookupName, lookupCriteriaMap.get(lookupName));
					}
				} else {
					log.debug("xmlLookUpFieldMap does not contain lookupName: {}. Skipping rule: {}", lookupName,
							rule.getLteRuleName());
					continue outerloop;

				}

			}

			if (!lookupWithHirearchy.isEmpty()) {
				lookupWithHirearchy = lookupWithHirearchy.entrySet().stream()
						.sorted((e1, e2) -> Integer.compare(getKeysFromValue(hirerachyTreeMap, e1.getKey()),
								getKeysFromValue(hirerachyTreeMap, e2.getKey())))
						.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1,
								LinkedHashMap::new));
			}

			log.debug("Iterating lookupWithHirearchy list to qualify stringentRule");
			for (String lookupName : hirerachyTreeMap.values()) {

				if (lookupWithHirearchy.containsKey(lookupName)) {

					if (xmlLookUpFieldMap.get(lookupName).equals(lookupWithHirearchy.get(lookupName))) {

						stringentRule = true;
						stringentlookupFieldCount++;
						stringentRuleQualifier.put(getKeysFromValue(hirerachyTreeMap, lookupName), true);
						stringentRuleHierarchyList.add(getKeysFromValue(hirerachyTreeMap, lookupName));

					}

					if (!xmlLookUpFieldMap.get(lookupName).equals(lookupWithHirearchy.get(lookupName))) {
						log.debug(
								"Within lookupWithHirearchy block. xmlLookUpFieldMap does not contain lookupName: {}. Skipping rule: {}",
								lookupName, rule.getLteRuleName());
						continue outerloop;

					}

				} else {

					if (stringentRuleQualifier.isEmpty()) {
						stringentRule = false;
					} else {
						stringentRule = true;
					}

				}

			}

			sRQ.setStringentRuleLookUpCount(stringentlookupFieldCount);
			sRQ.setStringentRuleHierarchyList(stringentRuleHierarchyList);
			sRQ.setStringentRule(rule);

			log.debug("Iterating lookupNoHirearchy list");
			for (String lookupName : lookupNoHirearchy.keySet()) {
				if (xmlLookUpFieldMap.containsKey(lookupName)) {

					if (xmlLookUpFieldMap.get(lookupName).equals(lookupNoHirearchy.get(lookupName))) {
						lookupFieldCount++;
						ruleQualifier = true;

					}

					if (!xmlLookUpFieldMap.get(lookupName).equals(lookupNoHirearchy.get(lookupName))) {
						continue outerloop;
					}
				} else {
					log.debug(
							"Within lookupNoHirearchy block. xmlLookUpFieldMap does not contain lookupName: {}. Skipping rule: {}",
							lookupName, rule.getLteRuleName());
					continue outerloop;
				}

			}
			sRQ.setTotalLookUpCount(lookupFieldCount);

			if (stringentRule && ruleQualifier) {
				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}

			}
			if (!stringentRule && ruleQualifier) {
				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}
			}

			if (stringentRule && lookupNoHirearchy.isEmpty()) {

				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}

			}
			if (lookupWithHirearchy.isEmpty() && ruleQualifier) {
				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}
			}

		}
		if (stringentRuleList.isEmpty() && !masterrulelist.isEmpty()) {
			log.info("No Stringent Rules Qualified, Generic Rules Qualified : {}", masterrulelist);
			lookUpCriteriaPassRules.setMasterPassedMap(masterrulelist);
		}
		if (!stringentRuleList.isEmpty()) {
			log.info("Stringent Rules Qualified : {} ", stringentRuleList);
			lookUpCriteriaPassRules.setStringentQualifyRuleList(stringentRuleList);
		}
		log.debug("Exit lookupFieldCheck() method of LTEProcessUtils class.");
		return Optional.of(lookUpCriteriaPassRules);
	}

	/**
	 * @param hirearchyMap
	 * @param value
	 * @return
	 */
	public int getKeysFromValue(TreeMap<Integer, String> hirearchyMap, String value) {
		int valfromKey = 0;
		for (Integer val : hirearchyMap.keySet()) {
			if (hirearchyMap.get(val).equals(value)) {
				valfromKey = val;
			}
		}
		return valfromKey;
	}

}