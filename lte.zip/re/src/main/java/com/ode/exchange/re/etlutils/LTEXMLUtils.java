package com.ode.exchange.re.etlutils;

import com.ode.exchange.re.entity.ETLConfiguration;
import com.ode.exchange.re.entity.MapperResult;
import com.ode.exchange.re.entity.RegulationRuleLogicExpression;
import com.ode.exchange.re.entity.RollupInfo;
import com.ode.exchange.re.entity.RollupMapping;
import com.ode.exchange.re.entity.RollupSource;
import com.ode.exchange.re.entity.RollupTarget;
import com.ode.exchange.re.entity.Rule;
import com.ode.exchange.re.entity.Tag;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlentity.ETLMapping;
import com.ode.exchange.re.etlentity.LTErule;
import com.ode.exchange.re.etlentity.XpathValueGroupLevel;
import com.ode.exchange.re.etlservice.IXmlCreationService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Namespace;
import org.dom4j.io.DOMWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

@Component
public class LTEXMLUtils {

	private static final Logger log = LoggerFactory.getLogger(LTEXMLUtils.class);

	@Autowired
	private com.ode.exchange.re.etlrepository.IETLConfigurationRepo etlConfigurationRepo;

	@Autowired
	private IXmlCreationService xmlCreationService;

	/**
	 * @param etlMappingList
	 * @param lteValueList
	 * @return
	 */
	public static List<XpathValueGroupLevel> getXpathFromFieldName(List<ETLMapping> etlMappingList,
			List<XpathValueGroupLevel> lteValueList) {

		log.debug("Enter getXpathFromFieldName() method of LTEXMLUtils class");

		log.debug("etlMappingList size: {}, lteValueList size: {}", etlMappingList.size(), lteValueList.size());

		List<XpathValueGroupLevel> xpathValueList = new ArrayList<>();

		for (int j = 0; j < lteValueList.size(); j++) {

			for (int i = 0; i < etlMappingList.size(); i++) {

				if (lteValueList.get(j).getFieldName().equals(etlMappingList.get(i).getAliasFieldName())) {

					XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();
					lteEntityItem.setFieldName(lteValueList.get(j).getFieldName());
					lteEntityItem.setXpath(etlMappingList.get(i).getxPath());
					lteEntityItem.setValue(lteValueList.get(j).getValue());
					lteEntityItem.setGroupLevel(lteValueList.get(j).getGroupLevel());

					xpathValueList.add(lteEntityItem);
					break;
				}
			}
		}

		return xpathValueList;
	}

	/**
	 * If there are more than one <ServiceContract> element having same value in
	 * "ContractType" tag, then drop those and move over those service contracts to
	 * <OtherCharges> section Keep the order of <OtherCharges> element (after <Fee>)
	 * 
	 * @param requestXML
	 * @return
	 */
	public String dropDuplicateServiceContracts(String requestXML) {
		log.debug("Enter dropDuplicateServiceContracts() method of LTEXMLUtils class");
		String duplicateNodeXPath = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/Financing/ServiceContract";
		org.w3c.dom.Document w3cdocument = null;
		try {
			XPath factory = XPathFactory.newInstance().newXPath();
			XPathExpression exprDuplicate = factory.compile(duplicateNodeXPath);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db;
			InputSource source = new InputSource(new StringReader(requestXML));
			db = dbf.newDocumentBuilder();
			w3cdocument = db.parse(source);

			NodeList nodeValueDuplicate = (NodeList) exprDuplicate.evaluate(w3cdocument, XPathConstants.NODESET);
			if (null != nodeValueDuplicate && nodeValueDuplicate.getLength() > 1) {
				log.debug("Total <ServiceContract> elements > {}", nodeValueDuplicate.getLength());
				List<String> tagValues = new ArrayList<>();
				String childNodeName = null;
				String childNodeValue = null;
				String duplicateValueElement = "ContractType";
				List<Node> toBeAddedNodes = new ArrayList<>();
				for (int i = 0; i < nodeValueDuplicate.getLength(); i++) {
					Node node = nodeValueDuplicate.item(i);
					NodeList childNodes = node.getChildNodes();
					if (null != childNodes && childNodes.getLength() > 0) {
						for (int j = 0; j < childNodes.getLength(); j++) {
							Node childNode = childNodes.item(j);
							if (childNode instanceof Element) {
								childNodeName = childNode.getNodeName();
								childNodeValue = childNode.getTextContent();
								if (duplicateValueElement.equals(childNodeName)) {
									if (tagValues.contains(childNodeValue)) {
										// This is a duplicate, store this for later and delete it
										log.debug("Duplicate value '{}' found for duplicateValueElement '{}'",
												childNodeValue, duplicateValueElement);
										toBeAddedNodes.add(node);
										node.getParentNode().removeChild(node);
									} else {
										tagValues.add(childNodeValue);
									}
								}
							}
						}
					}
				}
				log.debug("Total toBeAddedNodes: {}", toBeAddedNodes == null ? 0 : toBeAddedNodes.size());
				if (toBeAddedNodes.size() > 0) {
					log.debug("Looking for adjacent elements to place <OtherCharges> element.");
					// Find the Node next to the nodes to be added in the order
					// OtherCreditorCharges,Insurance,ServiceContract
					String xPath = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/Financing/OtherCreditorCharges";
					XPathExpression exprNextNode = factory.compile(xPath);
					Node nodeNext = (Node) exprNextNode.evaluate(w3cdocument, XPathConstants.NODE);
					if (nodeNext == null) {
						log.debug("Didn't find OtherCreditorCharges node");
						xPath = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/Financing/Insurance";
						exprNextNode = factory.compile(xPath);
						NodeList insuranceNodeList = (NodeList) exprNextNode.evaluate(w3cdocument,
								XPathConstants.NODESET);
						nodeNext = insuranceNodeList.item(insuranceNodeList.getLength() - 1);
						if (nodeNext == null) {
							log.debug("Didn't find Insurance node");
							exprNextNode = factory.compile(duplicateNodeXPath);
							nodeNext = (Node) exprNextNode.evaluate(w3cdocument, XPathConstants.NODE);
						} else {
							log.debug(
									"Found Insurance node. <OtherCharges> elements will be added next to <Insurance>");
						}
					} else {
						log.debug("Found OtherCreditorCharges node");
					}

					if (nodeNext != null) {
						log.debug("Iterating toBeAddedNodes List");
						for (Node node : toBeAddedNodes) {
							if (node instanceof Element) {
								Map<String, String> valuesMap = retrieveNodeValues(node);

								Node newNode = w3cdocument.createElement("OtherCharges");
								Element element = null;
								Text text = null;

								// OtherChargesAmount Node
								element = w3cdocument.createElement("OtherChargesAmount");
								element.setAttribute("currency", "USD");
								text = w3cdocument.createTextNode(valuesMap.get("CustomerSalePrice"));
								element.appendChild(text);
								newNode.appendChild(element);

								// OtherChargesPaidFor Node
								element = w3cdocument.createElement("OtherChargesPaidFor");
								text = w3cdocument.createTextNode(valuesMap.get("ContractType"));
								element.appendChild(text);
								newNode.appendChild(element);

								// OtherChargesPaidTo Node
								element = w3cdocument.createElement("OtherChargesPaidTo");
								text = w3cdocument.createTextNode(valuesMap.get("ContractCompanyName"));
								element.appendChild(text);
								newNode.appendChild(element);

								// OtherChargesCapitalizedInd Node
								element = w3cdocument.createElement("OtherChargesCapitalizedInd");
								text = w3cdocument.createTextNode(valuesMap.get("FinancedInd"));
								element.appendChild(text);
								newNode.appendChild(element);

								nodeNext.getParentNode().insertBefore(newNode, nodeNext);
								log.debug("Added <OtherCharges> for {}", valuesMap.get("ContractType"));
							}

						}
					} else {
						log.debug("<OtherCharges> tags not added");
					}
				} else {
					log.debug("No duplicate <ServiceContract> found!");
				}

				// Convert the new document structure to XML
				if (w3cdocument != null) {
					try {
						requestXML = XMLCreationUtils.doctoString(w3cdocument);
					} catch (Exception e) {
						log.error("Error occured while converting document to xml, ", e);
					}
				}
			} else {
				log.debug("No more than 1 <ServiceContract> found!");
			}
		} catch (Exception e) {
			log.error("Error occured while removing duplicate service contracts, ", e);
		}
		return requestXML;
	}

	private Map<String, String> retrieveNodeValues(Node node) {
		Map<String, String> valuesMap = new HashMap<>();
		NodeList childNodes = node.getChildNodes();
		String childNodeName = null;
		String childNodeValue = null;
		if (null != childNodes && childNodes.getLength() > 0) {
			for (int j = 0; j < childNodes.getLength(); j++) {
				Node childNode = childNodes.item(j);
				if (childNode instanceof Element) {
					childNodeName = childNode.getNodeName();
					childNodeValue = childNode.getTextContent();
					valuesMap.put(childNodeName, childNodeValue);
				}
			}
		}
		return valuesMap;
	}

	/**
	 * Create a roll up structure, by adding the specified elements to a new
	 * structure Delete all the rolled up elements
	 * 
	 * @param requestXML
	 * @param etlMappingList
	 * @param xmlFieldValueMap
	 * @param sendValueConditions
	 * @param rollUpRules
	 * @return
	 */
	public String createLTEXMLWithRollUp(String requestXML, List<ETLMapping> etlMappingList,
			LinkedHashMap<String, String> xmlFieldValueMap, List<LTErule> rollUpRules) {
		log.debug("createLTEXMLWithRollUp > Rolling up {} set of nodes", rollUpRules.size());
		org.w3c.dom.Document w3cdocument = null;
		try {
			InputSource source = new InputSource(new StringReader(requestXML));
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db;

			db = dbf.newDocumentBuilder();
			w3cdocument = db.parse(source);

			for (LTErule rule : rollUpRules) {
				// Convert JSON to Object
				MapperResult result = JsonUtil.mapJson(rule.getLteRuleLogic());
				Node rollupNode = null;
				Node firstSourceNode = null;
				Double rollUpAmount = new Double(0);
				List<RollupMapping> mapping = null;
				if (result.isProceed()) {
					RegulationRuleLogicExpression[] ruleExpression = result.getRuleExpression();
					for (RegulationRuleLogicExpression expression : ruleExpression) {
						// Elements to be rolled up and drop
						if (expression.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
							String etlFieldName = expression.getValue();
							String fieldValue = xmlFieldValueMap.get(etlFieldName);
							log.debug("FieldName > {}, Value > {}", etlFieldName, fieldValue);
							if (fieldValue != null) {
								rollUpAmount = Double.sum(rollUpAmount, new Double(fieldValue));
							} else {
								log.debug("Rollup value not found for field > {}", etlFieldName);
							}

							ETLMapping field = null;
							if (etlMappingList != null) {
								Predicate<ETLMapping> predicate = p -> p.getFieldName().equals(etlFieldName);
								field = etlMappingList.stream().filter(predicate).findFirst().orElse(null);
							}

							if (field != null) {
								try {
									XPath factory = XPathFactory.newInstance().newXPath();
									XPathExpression xpathExpression;

									String xpath = field.getxPath();
									xpath = xpath.substring(0, xpath.lastIndexOf("/"));

									xpathExpression = factory.compile(xpath);
									Node targetNode = (Node) xpathExpression.evaluate(w3cdocument, XPathConstants.NODE);
									if (null != targetNode) {

										if (rollupNode == null) {
											// The first node we will keep as the roll up node, and replace the content
											// later
											rollupNode = targetNode;
											log.debug("Keeping first node for roll up values");
										} else {
											// Drop this node
											log.debug("Droping node associated to : {}", etlFieldName);
											targetNode.getParentNode().removeChild(targetNode);
										}
									} else {
										log.debug("targetNode to drop could not be found for path> {}", xpath);
									}
								} catch (XPathExpressionException e) {
									log.error("Error occured while dropping nodes, ", e);
								}
							} else {
								log.debug("{} not found in ETL Mapping", etlFieldName);
							}
						} else if (expression.getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.FIELDROLLUP)) {
							// Fill roll up values to the node we have identified
							RollupInfo rollupInfo = expression.getTagValue();
							String rollupElementName = rollupInfo.getRollupTag();
							Map<String, String> tagMap = new HashMap<>();
							for (Tag tag : rollupInfo.getStaticTags()) {
								tagMap.put(tag.getTag(), tag.getValue());
							}
							if (rollupNode != null) {
								NodeList nodeList = rollupNode.getChildNodes();
								if (null != nodeList && nodeList.getLength() > 0) {
									for (int i = 0; i < nodeList.getLength(); i++) {
										Node node = nodeList.item(i);
										// Put roll up value and static values to the roll up node
										if (node instanceof Element) {
											String nodeName = node.getNodeName();
											if (tagMap.containsKey(nodeName)) {
												String newTagValue = tagMap.get(nodeName);
												log.debug("Node name > {}, New content > {}", nodeName, newTagValue);
												node.setTextContent(newTagValue);
											} else if (rollupElementName.equals(nodeName)) {
												BigDecimal formattedRollUpAmount = new BigDecimal(rollUpAmount)
														.setScale(2, RoundingMode.HALF_UP);
												log.debug("Node name > {}, Rollup value > {}", nodeName,
														formattedRollUpAmount);
												node.setTextContent(String.valueOf(formattedRollUpAmount));
											}
										}
									}
								}
							} else {
								log.debug(">> No roll up node found, did not rollup");
							}
						} else if (expression.getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.ROLLUPSOURCE)) {

							List<RollupSource> rollupSources = expression.getRollupSources();
							List<RegulationRuleLogicExpression> conditions = rollupSources.get(0)
									.getRollupConditionalLogic();
							/* evaluate conditions here */
							String conditionFieldName = "";
							String conditionOperator = "";
							/* the value set in the rollup rule condition. */
							String conditionValueFromRule = "";
							String conditionalExprString = "%s%s%s";
							for (RegulationRuleLogicExpression conditionalExpression : conditions) {
								if (RegulationRuleLogicExpression.ExpressionType.FIELD
										.equals(conditionalExpression.getExpressionType())) {

									conditionFieldName = conditionalExpression.getValue();
								} else if (RegulationRuleLogicExpression.ExpressionType.OPERATOR
										.equals(conditionalExpression.getExpressionType())) {
									conditionOperator = conditionalExpression.getValue();
									if ("=".equals(conditionOperator)) {
										conditionOperator = "==";
									}
								} else if (RegulationRuleLogicExpression.ExpressionType.VALUE
										.equals(conditionalExpression.getExpressionType())) {
									conditionValueFromRule = conditionalExpression.getValue();
								}
							}

							mapping = rollupSources.get(0).getRollupMapping();
							List<RegulationRuleLogicExpression> sourceNodes = rollupSources.get(0)
									.getRollupSourceNodes();
							Node xmlSourceNode = null;
							for (RegulationRuleLogicExpression sourceNode : sourceNodes) {
								String fieldName = sourceNode.getValue();
								String fieldValue = xmlFieldValueMap.get(fieldName);
								// Use fieldName as AliasName and fetch XPATH from DB. Evaluate XPATH and get
								// XML Node
								xmlSourceNode = null;
								String conditionPassed = "false";
								try {
									xmlSourceNode = getXmlSourceNodeByAliasName(w3cdocument, fieldName);
									if (null != xmlSourceNode && null == firstSourceNode) {
										firstSourceNode = xmlSourceNode;
									}
									RollupMapping theMapping = mapping.get(0);
									String sourceAmountFieldName = theMapping.getSource().getValue();
									String sourceAmountFieldValue = getTagValueByTagName(xmlSourceNode,
											sourceAmountFieldName);
									if (StringUtils.isNotBlank(conditionFieldName)) {
										/*
										 * conditionFieldValue is the value that must satisfy the condition from Rule.
										 * It comes from the source xml node.
										 */
										String conditionFieldValue = getTagValueByTagName(xmlSourceNode,
												conditionFieldName);
										/* Build conditionalExpresssion and evaluate */
										String currentConditionalExpression = String.format(conditionalExprString,
												conditionFieldValue, conditionOperator, conditionValueFromRule);
										ScriptEngineManager mgr = new ScriptEngineManager();
										ScriptEngine engine = mgr.getEngineByName("nashorn");
										try {
											conditionPassed = engine.eval(currentConditionalExpression).toString();
										} catch (ScriptException e) {
											log.info("Error Evaluating Final ExpressionList", e.getMessage());
										}
									} else {
										/*
										 * when there is no conditionFieldName available, we can assume there is no
										 * condition to evaluate. So we set conditionPassed to true so that the amount
										 * can be added to rollUpAmount.
										 */
										conditionPassed = "true";
									}
									log.info("conditionPassed: {}, sourceAmountFieldValue: {}", conditionPassed,
											sourceAmountFieldValue);

									if (sourceAmountFieldValue != null) {
										if (conditionPassed.equals("true")) {
											rollUpAmount = Double.sum(rollUpAmount, new Double(sourceAmountFieldValue));
											log.info("Current rollUpAmount: {}", rollUpAmount);
										}
									} else {
										log.debug("sourceAmountFieldValue not found for field > {}", fieldName);
									}
								} catch (final NumberFormatException e) {
									log.debug("NumberFormatException caught while processing {} for RollUp.",
											fieldName);
								} catch (final XPathExpressionException e) {
									log.debug("XPathExpressionException caught while processing {} for RollUp.",
											fieldName);
								} catch (final Exception e) {
									log.debug("Exception caught while processing {} for RollUp.", fieldName);
								}
							}

						} else if (expression.getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.ROLLUPTARGET)) {
							log.info("Begin processing ROLLUPTARGET block");
							RollupMapping theMapping = mapping.get(0);
							RollupTarget target = expression.getRollupTarget();
							log.info("RollupTargetNode : {}", target.getRollupTargetNode());
							BigDecimal formattedRollUpAmount = null;
							if (null != rollUpAmount) {
								formattedRollUpAmount = new BigDecimal(rollUpAmount).setScale(2, RoundingMode.HALF_UP);
								log.info("formattedRollUpAmount: {}", formattedRollUpAmount);
								/* clone a root element from targetNode */
								Element rootElement = w3cdocument.createElement(target.getRollupTargetNode());
								Element newElement = w3cdocument.createElement(theMapping.getTarget().getValue());
								newElement.setTextContent(String.valueOf(formattedRollUpAmount));
								rootElement.appendChild(newElement);
								/* add all static tags */
								for (Tag staticTag : target.getStaticTags()) {
									Element staticElement = w3cdocument.createElement(staticTag.getTag());
									staticElement.setTextContent(staticTag.getValue());
									rootElement.appendChild(staticElement);
								}
								if (null != firstSourceNode) {
									firstSourceNode.getParentNode().appendChild(rootElement);
								} else {
									log.info("Could not add ROLLUP node!");
								}
								// TODO
								// implement drop nodes here..
							} else {
								log.info("rollUpAmount is null. Did not add a new ROLLUP node!");
							}

						}
					}
				}
			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
			log.error("Error occured while doing roll up, ", e);
		}

		// Convert the new document structure to XML
		if (w3cdocument != null) {
			try {
				requestXML = XMLCreationUtils.doctoString(w3cdocument);
			} catch (Exception e) {
				log.error("Error occured while converting document to xml, ", e);
			}
		}

		return requestXML;
	}

	/**
	 * @param xmlSourceNode
	 * @param fieldName
	 * @return
	 */
	private String getTagValueByTagName(final Node xmlSourceNode, final String fieldName) {
		log.debug("Enter getTagValueByTagName() method of LTEXMLUtils class. fieldName: {}", fieldName);
		NodeList nodes = xmlSourceNode.getChildNodes();
		String nodeValue = null;
		for (int i = 0; i < nodes.getLength(); i++) {
			Node aNode = nodes.item(i);
			if (aNode instanceof Element) {
				Element anElement = (Element) aNode;
				log.debug("Found tag with name: {}", anElement.getNodeName());
				if (fieldName.equals(anElement.getNodeName())) {
					nodeValue = anElement.getTextContent();
					log.debug("Field Name: {}, Value: {}", anElement.getNodeName(), nodeValue);
					break;
				}
			}
		}
		return nodeValue;
	}

	/**
	 * @param document
	 * @param fieldName
	 * @return
	 * @throws XPathExpressionException
	 */
	private Node getXmlSourceNodeByAliasName(final org.w3c.dom.Document document, final String fieldName)
			throws XPathExpressionException {
		log.debug("Enter getXmlSourceNodeByAliasName() method of LTEXMLUtils class. fieldName: {}", fieldName);
		ETLConfiguration etlConfiguration = etlConfigurationRepo.findByFieldName(fieldName);
		if (etlConfiguration != null) {
			log.debug("Found ETLConfiguration with XPATH: {}", etlConfiguration.getxPath());
			String xpathString = "Envelope/Body/ProcessMessage/payload/content/" + etlConfiguration.getxPath();
			log.debug("Evaluating XPATH: {}", xpathString);
			XPath xpath = XPathFactory.newInstance().newXPath();
			XPathExpression expr = xpath.compile(xpathString);
			return (Node) expr.evaluate(document, XPathConstants.NODE);
		} else {
			log.debug("Could not find ETLConfiguration with XPATH: {}", etlConfiguration.getxPath());
		}
		return null;

	}

	/**
	 * @param requestXML
	 * @param xpathValueList
	 * @param xmlFieldValueMap
	 * @param sendValueConditions
	 * @return
	 */
	public String createLTEXML(String requestXML, List<XpathValueGroupLevel> xpathValueList,
			LinkedHashMap<String, String> xmlFieldValueMap, Map<String, String> sendValueConditions,
			List<LTErule> rollUpRules) {

		log.debug("Enter createLTEXML() method of LTEXMLUtils class");
		org.w3c.dom.Document document = null;
		Document newXML = null;
		org.w3c.dom.Document w3cDocAfterBracket = null;
		String afterupdategroup = null;
		String aftercreategroup = null;

		try {

			InputSource source = new InputSource(new StringReader(requestXML));
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			document = db.parse(source);

			List<XpathValueGroupLevel> xpathValueListWithIndex = new ArrayList<>();
			List<XpathValueGroupLevel> xpathValueListWithoutIndex = new ArrayList<>();

			log.debug("Processing items in xpathValueList");
			for (int j = 0; j < xpathValueList.size(); j++) {

				int groupLevel = xpathValueList.get(j).getGroupLevel();
				log.debug("xpathValueList[{}]: {}, groupLevel: {}", j, xpathValueList.get(j).getFieldName(),
						groupLevel);

				if (groupLevel == 0) {

					String xpath = xpathValueList.get(j).getXpath();
					String value = xpathValueList.get(j).getValue();
					String predicate = sendValueConditions.get(value);

					NodeList nodeList = LTEXMLUtils.getRepeatedNodes(document, xpath);
					if (null != nodeList && nodeList.getLength() > 0) {

						for (int i = 0; i < nodeList.getLength(); i++) {
							Node node = nodeList.item(i);
							if (node instanceof Element) {
								if (StringUtils.isNotBlank(predicate)) {
									if (predicate.equals(node.getTextContent())) {
										if (value.contains(";")) {
											String[] splitValues = value.split(";");
											value = splitValues[1];
										}
										node.setTextContent(value);
										log.debug("Condition check passed. Setting node text content to: {}", value);
										break;
									}

								} else {
									node.setTextContent(value);
									log.debug("No condition to check. Setting node text content to: {}", value);
								}
							}
						}
					} else {

						Node node = LTEXMLUtils.nodeExist(document, xpath);

						if (node != null) {
							log.debug("Found node at xpath: {}", xpath);
							// update regular and bracket node value
							if (StringUtils.isNotBlank(predicate)) {
								if (predicate.equals(node.getTextContent())) {
									node.setTextContent(value);
									log.debug("Condition check passed. Setting node text content to: {}", value);
								}

							} else {
								node.setTextContent(value);
								log.debug("No condition to check. Setting node text content to: {}", value);
							}

						}

					}
				}

				Integer childIndex = XPathUtils.getChildElementIndex(xpathValueList.get(j).getXpath());
				if (childIndex > 1) {
					xpathValueListWithIndex.add(xpathValueList.get(j));
				} else {
					log.debug("Adding XpathValueGroupLevel with group level: {} to xpathValueListWithoutIndex",
							groupLevel);
					xpathValueListWithoutIndex.add(xpathValueList.get(j));
				}
			}

			log.debug("Size of xpathValueListWithIndex: {}", xpathValueListWithIndex.size());
			log.debug("Size of xpathValueListWithoutIndex: {}", xpathValueListWithoutIndex.size());

			// create nodes with xpath order
			try

			{
				addTranslatedElementsWithXpathOrder(document, xpathValueListWithoutIndex);
			} catch (final Exception e) {
				log.debug(
						"Exception caught from within addTranslatedElementsWithXpathOrder() method of LTEXMLUtils class",
						e);
			}

			String financeType = xmlFieldValueMap.get("FinanceType");

			log.debug("FinanceType: {}", financeType);

			if (StringUtils.isNotBlank(financeType) && ("R".equals(financeType) || "1".equals(financeType))) {
				addVehiclePricingElementToCreditVehicle(document);
			}

			// create regular nodes
			if (!xpathValueListWithIndex.isEmpty()) {
				newXML = createNewElement(document, xpathValueListWithIndex);
			} else {
				String destinationNameCode = xmlFieldValueMap.get("DestinationNameCode");
				log.debug("Destination Name Code: {}", destinationNameCode);
				newXML = XMLCreationUtils.docToDom4JDocument(document, destinationNameCode);
			}

			// create bracket nodes
			w3cDocAfterBracket = CreateBracketXpathUtils.createWithBracketElement(newXML.asXML(), xpathValueList);

			// update repeatable
			// afterupdategroup =
			// CreateUpdateRepeatableTagsUtils.updateRepeatableTag(w3cDocAfterBracket,
			// xpathValueList);

			// create repeatable
			aftercreategroup = CreateUpdateRepeatableTagsUtils
					.createRepeatableTags(XMLCreationUtils.doctoString(w3cDocAfterBracket), xpathValueList);

		} catch (final Exception e) {
			log.debug("Exception caught from within createLTEXML() method of LTEXMLUtils class", e);
		}
		log.debug("Exit createLTEXML() method of LTEXMLUtils class");
		return aftercreategroup;
	}

	/**
	 * This is a temporary fix as a workaround for a translation issue. This needs
	 * to be removed ASAP.
	 *
	 * @param document
	 */
	public void addVehiclePricingElementToCreditVehicle(final org.w3c.dom.Document document) {
		log.debug("Enter addVehiclePricingElementToCreditVehicle() method of LTEXMLUtils class");
		String creditVehicleXpath = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/CreditVehicle";
		String invoiceXpathExpression = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/CreditVehicle/Pricing[VehiclePricingType='Invoice']/VehiclePrice";
		String vehicleUseXpathExpression = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/CreditVehicle/VehicleUse";

		try {
			Node invoiceVehiclePrice = nodeExist(document, invoiceXpathExpression);
			if (null != invoiceVehiclePrice && invoiceVehiclePrice instanceof Element) {
				Element invoiceElement = (Element) invoiceVehiclePrice;
				String invoicePrice = invoiceElement.getTextContent();
				log.debug("Invoice Price: {}", invoicePrice);

				Node creditVehicleNode = nodeExist(document, creditVehicleXpath);

				if (null != creditVehicleNode) {
					log.debug("Found creditVehicleNode");
					Element vehiclePricingElement = document.createElement("Pricing");

					Element vehiclePriceElement = document.createElement("VehiclePrice");
					vehiclePriceElement.setAttribute("currency", "USD");
					Text vehiclePriceValue = document.createTextNode(invoiceVehiclePrice.getTextContent());
					vehiclePriceElement.appendChild(vehiclePriceValue);

					Element vehiclePricingTypeElement = document.createElement("VehiclePricingType");
					vehiclePricingTypeElement.setTextContent("Wholesale Price");

					vehiclePricingElement.appendChild(vehiclePriceElement);
					vehiclePricingElement.appendChild(vehiclePricingTypeElement);

					Node vehicleUseNode = nodeExist(document, vehicleUseXpathExpression);
					if (null != vehicleUseNode) {
						creditVehicleNode.insertBefore(vehiclePricingElement, vehicleUseNode);
						log.debug("Added  vehiclePricingElement to creditVehicleNode before vehicleUseNode");
					} else {
						creditVehicleNode.appendChild(vehiclePricingElement);
						log.debug(
								"vehicleUseNode not found. Added  vehiclePricingElement to creditVehicleNode at random position.");
					}

				} else {
					log.debug("Could not find creditVehicleNode");
				}

			}

		} catch (final XPathExpressionException e) {
			log.debug(
					"XPathExpressionException caught from addVehiclePricingElementToCreditVehicle() method of LTEXMLUtils class. VehicePricingType **NOT** updated!");
		}

	}

	/**
	 * Update the value of SpotDeliveryInd, since it may have been changed during
	 * LTE processing
	 * 
	 * @param requestXml      - the request XML to be updated
	 * @param spotDeliveryInd - the new value of SpotDeliveryInd
	 * @return newXml - the XML with the value of SpotDeliveryInd updated, or null
	 *         if updating SpotDeliveryInd fails
	 */
	public String updateSpotDeliveryInd(String requestXml, String spotDeliveryInd) {
		log.debug("Enter updateSpotDeliveryInd() method of LTEXMLUtils class");
		if (requestXml == null || requestXml.isEmpty()) {
			// Return if requestXml is null or empty
			log.debug("requestXml is null or empty");
			return null;
		}

		if (spotDeliveryInd == null || spotDeliveryInd.isEmpty()) {
			// Return if spotDeliveryInd is null or empty
			log.debug("spotDeliveryInd is null or empty");
			return null;
		}

		org.w3c.dom.Document document;
		try {
			document = XMLCreationUtils.getDocumentFromXmlString(requestXml);
		} catch (Exception e) {
			// Creating XML document failed
			log.debug("Error creating XML document from request XML: " + e);
			return null;
		}

		NodeList nodeList = document.getElementsByTagName(Constants.SPOT_DELIVERY_IND_TAG_NAME);
		if (nodeList == null || nodeList.getLength() == 0) {
			// SpotDeliveryInd not set, so add to document
			// Find parent of SpotDeliveryInd
			ETLConfiguration etlConfiguration = etlConfigurationRepo
					.findByFieldName(Constants.SPOT_DELIVERY_IND_TAG_NAME);
			String spotXPath = etlConfiguration.getxPath();
			int lastIndex = spotXPath.lastIndexOf("/");
			String parentXPath = spotXPath.substring(0, lastIndex);
			Node parentNode;
			try {
				XPath xpath = XPathFactory.newInstance().newXPath();
				XPathExpression expr = xpath.compile(parentXPath);
				parentNode = (Node) expr.evaluate(document, XPathConstants.NODE);
			} catch (XPathExpressionException xpee) {
				// Finding parent of SpotDeliveryInd failed
				log.debug("Error finding parent of SpotDeliveryInd in request XML: " + xpee);
				return null;
			}
			// Add SpotDeliveryInd to parent
			Element spotDeliveryIndElement = document.createElement(Constants.SPOT_DELIVERY_IND_TAG_NAME);
			Text spotDeliveryIndText = document.createTextNode(spotDeliveryInd);
			spotDeliveryIndElement.appendChild(spotDeliveryIndText);
			parentNode.appendChild(spotDeliveryIndElement);
			log.debug("Added new SpotDeliveryInd tag with value " + spotDeliveryInd);
			String newXml;
			try {
				newXml = XMLCreationUtils.doctoString(document);
			} catch (Exception e) {
				// Creating XML String failed
				log.debug("Error converting updated XML document to String: " + e);
				return null;
			}
			return newXml;

		} else {
			// SpotDeliveryInd found
			// There should be only one SpotDeliveryInd, but even if there are multiple, get
			// the last one
			Node node = nodeList.item(nodeList.getLength() - 1);
			node.setTextContent(spotDeliveryInd);
			log.debug("Updated existing SpotDeliveryInd tag with value " + spotDeliveryInd);
			String newXml;
			try {
				newXml = XMLCreationUtils.doctoString(document);
			} catch (Exception e) {
				// Creating XML String failed
				log.debug("Error converting updated XML document to String: " + e);
				return null;
			}
			return newXml;
		}
	}

	/**
	 * @param document
	 * @param xpathValueList
	 * @return
	 * @throws Exception
	 */
	public void addTranslatedElementsWithXpathOrder(final org.w3c.dom.Document document,
			List<XpathValueGroupLevel> xpathValueList) throws Exception {

		log.debug("Enter addTranslatedElementsWithXpathOrder() method of LTEXMLUtils class");

		for (int j = 0; j < xpathValueList.size(); j++) {

			if (xpathValueList.get(j).getGroupLevel() == 0) {

				String xpath = xpathValueList.get(j).getXpath();
				String value = xpathValueList.get(j).getValue();

				Node node = nodeExist(document, xpath);

				Namespace nameSpace = new Namespace("", "");

				if (node == null && !xpath.contains("@") && !xpath.contains("=")) {

					log.debug("Node DOES NOT exist at xpath: {}. About to fetch ETLConfiguration..", xpath);

					com.ode.exchange.re.entity.ETLConfiguration etlConfiguration = etlConfigurationRepo
							.findByXpath(xpath);
					if (null != etlConfiguration && null != etlConfiguration.getXpathOrder()) {
						log.debug("Found ETLConfiguration with xpath: {}, xpathOrder: {}", xpath,
								Integer.valueOf(etlConfiguration.getXpathOrder()));
						xmlCreationService.addElementAtGivenOrder(document, etlConfiguration, value);
					} else {
						log.debug("ETLConfiguration not found. Will not add requested element.");
					}

				} else {
					log.debug("Node exists at xpath: {}", xpath);
				}
			}
		}
	}

	/**
	 * This method creates regular element.
	 *
	 * @param xmldoc
	 * @param xpathValueList
	 * @return
	 * @throws Exception
	 */
	public Document createNewElement(org.w3c.dom.Document xmldoc, List<XpathValueGroupLevel> xpathValueList)
			throws Exception {
		log.debug("Enter createNewElement() method of LTEXMLUtils class");
		String xml = XMLCreationUtils.doctoString(xmldoc);
		xml = removeNameSpaces(xml);
		xml = xml.replace("soap:", "");
		xml = xml.trim();
		org.dom4j.Document dom4jdocument = DocumentHelper.parseText(xml);

		for (int j = 0; j < xpathValueList.size(); j++) {

			if (xpathValueList.get(j).getGroupLevel() == 0) {

				String xpath = xpathValueList.get(j).getXpath();
				String value = xpathValueList.get(j).getValue();

				Node node = nodeExist(xmldoc, xpath);

				Namespace nameSpace = new Namespace("", "");

				if (node == null && !xpath.contains("@") && !xpath.contains("=")) {
					log.debug("Adding {} to parent", xpath);
					XMLCreationUtils.addElementToParent(dom4jdocument, "/" + xpath, value, nameSpace);
				}
			}
		}
		log.debug("Exit createNewElement() method of LTEXMLUtils class");
		return dom4jdocument;
	}

	/**
	 * @param dom4jdoc
	 * @return
	 * @throws DocumentException
	 */
	public org.w3c.dom.Document dom4jToW3c(Document dom4jdoc) throws DocumentException {

		return new DOMWriter().write(dom4jdoc);
	}

	/**
	 * @param requestXML
	 * @return
	 */
	public String removeNameSpaces(String requestXML) {

		log.debug("Enter removeNameSpaces() method of LTEXMLUtils class");

		requestXML = requestXML.replaceAll("xmlns.*?(\"|\').*?(\"|\')", "");
		requestXML = requestXML.replace(
				"<ProcessMessage xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\">",
				"<ProcessMessage>");
		requestXML = requestXML.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>", "");
		requestXML = requestXML.replace(
				" <ProcessCreditContract  environment=\"Production\" lang=\"en-US\" release=\"8.1-Lite\" revision=\"3.0.2\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\STAR\\Rev4.4.4\\BODs\\Standalone\\ProcessCreditContract.xsd\">",
				"<ProcessCreditContract>");

		// Handling different request XML when Envelope content is different
		requestXML = requestXML.replace(
				"<ProcessCreditContract  environment=\"Production\" lang=\"en-US\" release=\"8.1-Lite\" revision=\"3.0.2\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\STAR\\Rev4.4.4\\BODs\\Standalone\\ProcessCreditContract.xsd\">",
				"<ProcessCreditContract>");

		return requestXML;
	}

	// method to check whether a node exists in xml
	/**
	 * @param document
	 * @param ruleXpath
	 * @return
	 * @throws XPathExpressionException
	 */
	public static Node nodeExist(org.w3c.dom.Document document, String ruleXpath) throws XPathExpressionException {

		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(ruleXpath);

		return (Node) expr.evaluate(document, XPathConstants.NODE);
	}

	/**
	 * @param document
	 * @param ruleXpath
	 * @return
	 * @throws XPathExpressionException
	 */
	public static NodeList getRepeatedNodes(org.w3c.dom.Document document, String ruleXpath)
			throws XPathExpressionException {

		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(ruleXpath);

		return (NodeList) expr.evaluate(document, XPathConstants.NODESET);
	}

	// convert lteresult map format to object

	public static List<XpathValueGroupLevel> createXpathValueGroupFromTranslationPath(
			LinkedHashMap<String, LinkedHashMap<String, List<Integer>>> translatedSendVal) {

		log.debug("Enter createXpathValueGroupFromTranslationPath() method of LTEXMLUtils class");

		List<XpathValueGroupLevel> xpathValueGroupList = new ArrayList<>();

		for (Map.Entry<String, LinkedHashMap<String, List<Integer>>> entry : translatedSendVal.entrySet()) {

			String fieldName = entry.getKey();

			LinkedHashMap<String, List<Integer>> valueGroup = entry.getValue();

			if (valueGroup.size() == 1) {
				String value = valueGroup.keySet().toArray()[0].toString();
				List<Integer> groupLevel = valueGroup.values().iterator().next();

				if (groupLevel.size() == 1) {

					XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();

					lteEntityItem.setFieldName(fieldName);
					lteEntityItem.setValue(value);
					lteEntityItem.setGroupLevel(groupLevel.get(0));

					xpathValueGroupList.add(lteEntityItem);
				} else {
					for (int i = 0; i < groupLevel.size(); i++) {

						XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();

						lteEntityItem.setFieldName(fieldName);
						lteEntityItem.setValue(value);
						lteEntityItem.setGroupLevel(groupLevel.get(i));

						xpathValueGroupList.add(lteEntityItem);
					}
				}
			}

			if (valueGroup.size() > 1) {

				for (Map.Entry<String, List<Integer>> vgentry : valueGroup.entrySet()) {

					List<Integer> groupLevel = vgentry.getValue();
					String value = vgentry.getKey();

					if (groupLevel.size() == 1) {

						XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();

						lteEntityItem.setFieldName(fieldName);
						lteEntityItem.setValue(value);
						lteEntityItem.setGroupLevel(groupLevel.get(0));

						xpathValueGroupList.add(lteEntityItem);

					} else {

						for (int i = 0; i < groupLevel.size(); i++) {

							XpathValueGroupLevel lteEntityItem = new XpathValueGroupLevel();

							lteEntityItem.setFieldName(fieldName);
							lteEntityItem.setValue(value);
							lteEntityItem.setGroupLevel(groupLevel.get(i));

							xpathValueGroupList.add(lteEntityItem);
						}
					}
				}
			}
		}

		return xpathValueGroupList;
	}

	// To remove white space after dropping tags in xml
	public static String trim(String input) {

		BufferedReader reader = new BufferedReader(new StringReader(input));
		StringBuffer result = new StringBuffer();

		try {
			String line;

			while ((line = reader.readLine()) != null) {
				result.append(line.trim());
			}
			return result.toString();

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param lteXML
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	static String addAddressQualifierToCoApplicant(final String lteXML) {
		log.debug("Enter addAddressQualifierToCoApplicant() method of LTEXMLUtils class");
		String coAppAddressXpath = "Envelope/Body/ProcessMessage/payload/content/ProcessCreditContract/DataArea/CreditContract/Co-Applicant/Address";
		String errorMessage = "Exception caught when trying to add address qualifier to co-applicant";
		try {
			org.w3c.dom.Document document = XMLCreationUtils.getDocumentFromXmlString(lteXML);
			Node address = nodeExist(document, coAppAddressXpath);
			if (null != address) {
				Element addressElement = (Element) address;
				addressElement.setAttribute("qualifier", "HomeAddress");
				log.debug("Attribute qualifier added to Address");
				return XMLCreationUtils.doctoString(document);
			} else {
				log.debug("Could not find Address element at xpath: {}", coAppAddressXpath);
			}
		} catch (final XPathExpressionException e) {
			log.debug(errorMessage, e);
		} catch (final ParserConfigurationException e) {
			log.debug(errorMessage, e);
		} catch (final SAXException e) {
			log.debug(errorMessage, e);
		} catch (final IOException e) {
			log.debug(errorMessage, e);
		} catch (final Exception e) {
			log.debug(errorMessage, e);
		}

		return lteXML;

	}
}