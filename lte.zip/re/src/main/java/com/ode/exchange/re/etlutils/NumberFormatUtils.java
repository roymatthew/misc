package com.ode.exchange.re.etlutils;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author rmathew
 *
 */
public class NumberFormatUtils {
	
	private static final Logger log = LoggerFactory.getLogger(NumberFormatUtils.class);
	
	public static String getAmountRoundedToTwoDecimalPlacesAsString(final String amount)	{
		log.debug("Entered getAmountRoundedToTwoDecimalPlacesAsString() amount: {}", amount);
		String formattedAmount = amount;
		if (NumberUtils.isCreatable(amount))
		{			
			BigDecimal bigDec = new BigDecimal(amount).setScale(2, RoundingMode.HALF_UP);
			formattedAmount = String.valueOf(bigDec);
		}
		return formattedAmount;
		
	}

}
