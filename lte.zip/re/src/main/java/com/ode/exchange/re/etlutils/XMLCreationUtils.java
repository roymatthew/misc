package com.ode.exchange.re.etlutils;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.Node;
import org.dom4j.QName;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLCreationUtils {
	/**
	 * This method appends child element to the corresponding parent node.
	 * 
	 * @param document document is the document that holds all nodes and values.
	 * @param xpath    xpath is the xpath that is created inside document.
	 * @param value    value is the xml value for a specific xpath.
	 * @return xml node with its value.
	 */

	public static Node addElementToParent(Document document, String xpath, String value, Namespace ns3) {

		String elementName = XPathUtils.getChildElementName(xpath);
		String parentXPath = XPathUtils.getParentXPath(xpath);
		Node parentNode = document.selectSingleNode(parentXPath);
		if (parentNode == null) {
			parentNode = addElementToParent(document, parentXPath, null, ns3);
		}

		// create younger siblings if needed
		Integer childIndex = XPathUtils.getChildElementIndex(xpath);
		if (childIndex > 1) {
			List<?> nodelist = document.selectNodes(XPathUtils.createPositionXpath(xpath, childIndex));
			// how many to create = (index wanted - existing - 1 to account for the new
			// element we will create)
			int nodesToCreate = childIndex - nodelist.size() - 1;
			for (int i = 0; i < nodesToCreate; i++) {
				((Element) parentNode).addElement(new QName(elementName, ns3));
			}
		}

		// create requested element
		Element created = ((Element) parentNode).addElement(new QName(elementName, ns3));
		if (null != value) {
			created.addText(value);
		}
		return created;
	}

	/**
	 * This method converts w3c document to string.
	 * 
	 * @param newDoc
	 * @return xml in string format.
	 * @throws Exception
	 */
	public static String doctoString(org.w3c.dom.Document newDoc) throws Exception {
		DOMSource domSource = new DOMSource(newDoc);
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(domSource, sr);
		return sw.toString();
	}
	
	/**
	 * @param xmlString
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public static org.w3c.dom.Document getDocumentFromXmlString(final String xmlString)
			throws ParserConfigurationException, SAXException, IOException {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xmlString));
		return docBuilder.parse(is);

	}

	/**
	 * @param document
	 * @return
	 * @throws Exception
	 */
	public static Document docToDom4JDocument(org.w3c.dom.Document document, String destinationNameCode) throws Exception {
		String xml = doctoString(document);
		if ("RO".equalsIgnoreCase(destinationNameCode)) {
			xml = removeNameSpaces(xml);
			xml = xml.replace("soap:", "");
		}
		xml = xml.trim();
		org.dom4j.Document dom4jdocument = DocumentHelper.parseText(xml);
		return dom4jdocument;
	}
	
	/**
	 * @param requestXML
	 * @return
	 */
	public static String removeNameSpaces(String requestXML) {
		
		requestXML = requestXML.replaceAll("xmlns.*?(\"|\').*?(\"|\')", "");
		requestXML = requestXML.replace(
				"<ProcessMessage xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\">",
				"<ProcessMessage>");
		requestXML = requestXML.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>", "");
		requestXML = requestXML.replace(
				" <ProcessCreditContract  environment=\"Production\" lang=\"en-US\" release=\"8.1-Lite\" revision=\"3.0.2\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\STAR\\Rev4.4.4\\BODs\\Standalone\\ProcessCreditContract.xsd\">",
				"<ProcessCreditContract>");
		
		// Handling different request XML when Envelope content is different
		requestXML = requestXML.replace(
				"<ProcessCreditContract  environment=\"Production\" lang=\"en-US\" release=\"8.1-Lite\" revision=\"3.0.2\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\STAR\\Rev4.4.4\\BODs\\Standalone\\ProcessCreditContract.xsd\">",
				"<ProcessCreditContract>");
		
		return requestXML;
	}

}
