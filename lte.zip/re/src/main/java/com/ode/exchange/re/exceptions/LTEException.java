package com.ode.exchange.re.exceptions;

/**
 * @author rmathew
 *
 */
public class LTEException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7014560401134126116L;
	
	/**
	 * Default Constructor
	 */
	public LTEException() {
	}

	/**
	 * @param arg0
	 */
	public LTEException(final String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public LTEException(final Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public LTEException(final String arg0, final Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 */
	public LTEException(final String arg0, final Throwable arg1, final boolean arg2, final boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}


}
