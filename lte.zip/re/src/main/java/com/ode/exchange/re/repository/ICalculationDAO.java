package com.ode.exchange.re.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.Calculation;

@Repository
public interface ICalculationDAO extends CrudRepository<Calculation, String> {
	Calculation findById(int calculationID);
}
