package com.ode.exchange.re.repository;

import com.ode.exchange.re.entity.CreditDecision;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ICreditDecisionDAO extends CrudRepository<CreditDecision, String>{
	@Query("select creditapp from CreditDecision creditapp where creditapp.conversationId = :creditAppNumber order by creditapp.createdTs DESC")
	List<CreditDecision> findFieldByCA(@Param("creditAppNumber") String creditAppNumber);

	@Query("select creditapp from CreditDecision creditapp where creditapp.VIN = :vehicleVinNumber")
	List<CreditDecision> findFieldByVin(@Param("vehicleVinNumber") String vehicleVinNumber);
	
	@Query("select cd from CreditDecision cd where cd.applicationNumber = :fsAppNumber order by cd.createdTs DESC")
	List<CreditDecision> findCreditDecisionsByFsAppNumber(@Param("fsAppNumber") String fsAppNumber);

}
