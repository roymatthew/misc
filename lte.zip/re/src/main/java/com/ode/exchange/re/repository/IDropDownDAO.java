package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.ode.exchange.re.entity.DropDown;


public interface IDropDownDAO extends CrudRepository<DropDown, String> {

	void deleteById(int id);
	
	@Query("select dropdown from DropDown dropdown  ORDER BY dropdown.createdDate DESC")
	List<DropDown> findAll();
	
}
