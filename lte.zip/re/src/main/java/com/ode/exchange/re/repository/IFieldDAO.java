package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ode.exchange.re.entity.ETLConfiguration;

public interface IFieldDAO extends CrudRepository<ETLConfiguration,String>{

	ETLConfiguration findById(int fieldID);

	@Query("select field from ETLConfiguration field where field.aliasFieldName = :aliasFieldName" )
	ETLConfiguration findFieldByName(@Param("aliasFieldName")String fieldName);
	
	@Query("select field from ETLConfiguration field ORDER BY field.aliasFieldName ASC" )
	List<ETLConfiguration> findAll();

	
}
