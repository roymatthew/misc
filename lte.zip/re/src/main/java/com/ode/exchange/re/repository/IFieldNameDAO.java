package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.FieldName;

@Repository
public interface IFieldNameDAO extends CrudRepository<FieldName,String> {

	@Query("select DISTINCT fieldname  from FieldName fieldname INNER join fieldname.dropDownlist dropdown" )
	List<FieldName>	findFieldAll();
	
	@Query("select DISTINCT fieldname from FieldName fieldname INNER JOIN fieldname.dropDownlist dropdown where fieldname.id = :fieldID" )
	FieldName findById(@Param("fieldID") int fieldID);

	@Query("select fieldname from FieldName fieldname where fieldname.aliasFieldName = :aliasFieldName" )
	FieldName findByNameId(@Param("aliasFieldName")String fieldName);
	
}


