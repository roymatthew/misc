package com.ode.exchange.re.repository;

import org.springframework.data.repository.CrudRepository;

import com.ode.exchange.re.entity.Functionality;

public interface IFunctionalityDAO extends CrudRepository<Functionality,String> {

	Functionality findById(int functionalityid);

}
