package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.FunctionalityUserRoleMapping;

@Repository
public interface IFunctionalityUserMappingDAO extends CrudRepository<FunctionalityUserRoleMapping,String> {

	@Query("select  functionalitymap  from FunctionalityUserRoleMapping  functionalitymap  where functionalitymap.userroleID = :userroleID ORDER BY functionalitymap.createdDate DESC" )
	List<FunctionalityUserRoleMapping> findMappingAll(@Param("userroleID") int userroleID);
	
	
	@Query("select Distinct functionalitymap  from FunctionalityUserRoleMapping functionalitymap  where functionalitymap.userroleID = :userroleID" )
	List<FunctionalityUserRoleMapping> findByFunctionalityUserRoleId(@Param("userroleID") int userroleID);
	
	
	@Query("SELECT CASE WHEN COUNT(u) > 0 THEN 'true' ELSE 'false' END FROM FunctionalityUserRoleMapping functionalitymap WHERE functionalitymap.userroleID = :userroleID")
	Boolean existsFunctionalityByUserRole(@Param("userroleID") int userroleID);


	void deleteById(int id);
	
}
