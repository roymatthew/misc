package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ode.exchange.re.entity.FunctionalityUserRoleMap;

public interface IFunctionalityUserRoleMapDAO extends CrudRepository<FunctionalityUserRoleMap,String>{

	
	@Query("select Distinct functionalitymap  from FunctionalityUserRoleMap functionalitymap  where functionalitymap.userroleID = :userroleID ORDER BY functionalitymap.createdDate DESC" )
	List<FunctionalityUserRoleMap> findByFunctionalityUserRoleId(@Param("userroleID") int userroleID);

	void deleteById(int id);
	
}
