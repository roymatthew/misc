package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ode.exchange.re.entity.Message;

public interface IMessageDAO extends CrudRepository<Message, String> {

	Message findById(int messageId);

	@Query("select msg from Message msg JOIN FETCH msg.ruleClassification rc  where rc.id = :ruleClassificationId ORDER BY msg.createdDate DESC")
	List<Message> findRuleClassificationId(@Param("ruleClassificationId")int ruleClassificationId);

	@Query("select msg from Message msg  ORDER BY msg.createdDate DESC")
	List<Message> findAll();

	@Query("select msg from Message msg JOIN FETCH msg.ruleClassification rc  where rc.id = :ruleClassificationId and  msg.id < 0")
	List<Message> findDefaultMessageRuleClassificationId(@Param("ruleClassificationId")int ruleClassificationId);

}
