package com.ode.exchange.re.repository;

import org.springframework.data.repository.CrudRepository;

import com.ode.exchange.re.entity.MessageType;

public interface IMessageTypeDAO extends CrudRepository<MessageType,String> {

	MessageType findById(int id);

}
