package com.ode.exchange.re.repository;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.ProcessAudit;

@Repository
public interface IProcessAuditDAO extends CrudRepository<ProcessAudit,String>  {

	@Query("select  processaudit from ProcessAudit processaudit  where processaudit.id = (Select max(audit.id)from ProcessAudit audit)")
	ProcessAudit find();

}
