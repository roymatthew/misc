package com.ode.exchange.re.repository;

import org.springframework.data.repository.CrudRepository;

import com.ode.exchange.re.entity.RuleAudit;

public interface IRuleAuditDAO extends CrudRepository<RuleAudit,String> {

}
