package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.ode.exchange.re.entity.Rule;

public interface IRuleDAO extends CrudRepository<Rule, String> {

	Rule findById(int ruleid);

	@Query("select rule from Rule rule ORDER BY rule.createdDate DESC")
	List<Rule> findAll();

	@Query("select rule from Rule rule JOIN FETCH rule.ruleClassification rc where  rc.rcName = 'Required Field' and rule.status='A'and CURRENT_DATE() between rule.effectiveDate and rule.expirationDate ORDER BY rule.createdDate DESC")
	List<Rule> findByRequiredField();

	@Query("select rule from Rule rule JOIN FETCH rule.ruleClassification rc where  rc.rcName = 'Form Number' and rule.status='A'and CURRENT_DATE() between rule.effectiveDate and rule.expirationDate ORDER BY rule.createdDate DESC")
	List<Rule> findByFormNumber();

	@Query("select rule from Rule rule JOIN FETCH rule.ruleClassification rc where  rc.rcName = 'Rule Builder' and rule.status='A'and CURRENT_DATE() between rule.effectiveDate and rule.expirationDate ORDER BY rule.createdDate DESC")
	List<Rule> findByRegulation();

	@Query("select rule from Rule rule JOIN FETCH rule.ruleClassification rc where  rc.rcName = 'Tolerance' and rule.status='A'and CURRENT_DATE() between rule.effectiveDate and rule.expirationDate ORDER BY rule.createdDate DESC")
	List<Rule> findByTolerance();

	@Query("select rule from Rule rule JOIN FETCH rule.ruleClassification rc where  rc.rcName = 'Required Form List' and rule.status='A'and CURRENT_DATE() between rule.effectiveDate and rule.expirationDate ORDER BY rule.createdDate DESC")
	List<Rule> findByRFL();

	@Query("select rule from Rule rule JOIN FETCH rule.ruleClassification rc where  rc.id =:rcid and rule.status in ('A', 'P')")
	List<Rule> findByRCId(@Param("rcid") int rcid);

	
	
}
