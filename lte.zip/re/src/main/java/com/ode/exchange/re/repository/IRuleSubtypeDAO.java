package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ode.exchange.re.entity.RuleSubtype;

public interface IRuleSubtypeDAO extends CrudRepository<RuleSubtype, String> {

	RuleSubtype findById(int ruleTypeID);

	@Query("select rulesubtype from RuleSubtype rulesubtype JOIN FETCH rulesubtype.ruleType ruletype where ruletype.ruleTypeName = :ruleType  ")
	List<RuleSubtype> findRuleSubtypeByRuleType(@Param("ruleType") String ruleType);

	@Query("select rulesubtype from RuleSubtype rulesubtype  ORDER BY rulesubtype.createdDate DESC")
	List<RuleSubtype> findAll();

}
