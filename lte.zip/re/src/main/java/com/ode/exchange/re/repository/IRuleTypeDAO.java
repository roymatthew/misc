package com.ode.exchange.re.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.ode.exchange.re.entity.RuleType;

@Repository
public interface IRuleTypeDAO extends CrudRepository<RuleType, String> {

	RuleType findById(int ruleTypeID);

	@Query("select ruletype from RuleType ruletype  ORDER BY ruletype.createdDate DESC")
	List<RuleType> findAll();

}
