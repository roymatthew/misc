package com.ode.exchange.re.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.AppUser;


@Repository
public interface IUserDAO extends CrudRepository<AppUser, String> {

	AppUser findById(int userID);

	@Query("select appusr from AppUser appusr where appusr.username = :username and appusr.password = :password")
	AppUser findByUserPass(@Param("username") String username, @Param("password") String password);

	@Query("select appusr from AppUser appusr where appusr.username = :username")
	AppUser findByUserName(@Param("username") String username);

	@Query("SELECT CASE WHEN COUNT(u) > 0 THEN 'true' ELSE 'false' END FROM AppUser appusr WHERE appusr.username = :username")
	Boolean existsByUserName(@Param("username") String username);
	
	@Query("select appusr from AppUser appusr ORDER BY appusr.createdDate DESC")
	Iterable<AppUser> findAll();

}
