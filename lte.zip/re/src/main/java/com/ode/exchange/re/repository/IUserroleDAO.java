package com.ode.exchange.re.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ode.exchange.re.entity.UserRole;
@Repository
public interface IUserroleDAO extends CrudRepository<UserRole,String> {

	UserRole findById(int roleID);
	
	@Query("select usrrole from UserRole usrrole ORDER BY usrrole.createdDate DESC")
	Iterable<UserRole> findAll();
}
