package com.ode.exchange.re.service;

import org.hibernate.ObjectNotFoundException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.ode.exchange.re.entity.AppUser;
@Service
public interface UserService extends UserDetailsService {

    Iterable<AppUser> getUserAll();

    AppUser findById(int userId);

    AppUser save(AppUser appUser)  throws ObjectNotFoundException;


    AppUser findByUser(String username);
}
