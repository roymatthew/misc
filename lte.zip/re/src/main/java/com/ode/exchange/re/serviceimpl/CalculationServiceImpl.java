package com.ode.exchange.re.serviceimpl;

import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.ICalculationDAO;
import java.util.List;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class CalculationServiceImpl {

	public static final Logger logger = LoggerFactory.getLogger(CalculationServiceImpl.class);

	@Autowired
	ICalculationDAO calculationDAO;

	public List<Calculation> getCalculationAll() {
		return (List<Calculation>) calculationDAO.findAll();

	}

	public Calculation findCalculationById(int calculationID) {
		Calculation calculation = calculationDAO.findById(calculationID);
		if (calculation == null) {
			throw new NotFoundException("Calculation does not exist");
		}
		return calculation;

	}

	public Calculation createCalculation(Calculation calculation) {
		Calculation calculationEntity = calculation;
		if (calculationEntity != null) {
			calculation = calculationDAO.save(calculationEntity);
		}
		return calculation;
	}

	public Calculation updateById(int calculationID, Calculation calculation) {
		Calculation calculationEntity = calculationDAO.findById(calculationID);
		Calculation calcEntity = new Calculation();
		if (calculationEntity == null) {

			throw new NotFoundException("Calculation does not exist");
		} else {
			calculationEntity.setFinanceType(calculation.getFinanceType());
			calculationEntity.setPreventNegativeValue(calculation.getPreventNegativeValue());
			calculationEntity.setRemarks(calculation.getRemarks());
			calculationEntity.setLender(calculation.getLender());
			calculationEntity.setState(calculation.getState());
			calculationEntity.setCalculationJSON(calculation.getCalculationJSON());
			calculationEntity.setCalculationName(calculation.getCalculationName());
			calculationEntity.setUpdatedBy(calculation.getUpdatedBy());
			calcEntity = calculationDAO.save(calculationEntity);

		}

		return calcEntity;

	}





}
