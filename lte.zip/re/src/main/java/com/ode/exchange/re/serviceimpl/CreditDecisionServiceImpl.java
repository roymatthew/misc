package com.ode.exchange.re.serviceimpl;

import com.ode.exchange.re.entity.CreditDecision;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.ICreditDecisionDAO;
import java.util.List;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class CreditDecisionServiceImpl {

	public static final Logger logger = LoggerFactory.getLogger(CreditDecisionServiceImpl.class);

	@Autowired
	ICreditDecisionDAO creditDecisionDAO;

	/**
	 * @return
	 */
	public List<CreditDecision> getCreditDecisionAll() {
		return (List<CreditDecision>) creditDecisionDAO.findAll();

	}

	/**
	 * @param creditAppNumber
	 * @return
	 */
	public List<CreditDecision> findCreditDecisionByAppNumber(final String creditAppNumber) {
		logger.debug(
				"Entered findCreditDecisionByAppNumber method of CreditDecisionServiceImpl class. creditAppNumber: {}",
				creditAppNumber);
		List<CreditDecision> lisOfCreditDecisions = creditDecisionDAO.findCreditDecisionsByFsAppNumber(creditAppNumber);
		if (lisOfCreditDecisions == null) {
			throw new NotFoundException("No CreditDecisions found for the given creditAppNumber: " + creditAppNumber);
		}
		return lisOfCreditDecisions;
	}

	/**
	 * @param vehicleVinNumber
	 * @return
	 */
	public List<CreditDecision> findCreditDecisionByVinNumber(String vehicleVinNumber) {
		List<CreditDecision> vinNumber = creditDecisionDAO.findFieldByVin(vehicleVinNumber);
		if (vinNumber == null) {
			throw new NotFoundException("vehicle does not exist");
		}
		return vinNumber;

	}

}
