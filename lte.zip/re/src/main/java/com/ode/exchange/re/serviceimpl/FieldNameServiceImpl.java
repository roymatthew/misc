package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.exchange.re.DTO.DropDownDTO;
import com.ode.exchange.re.DTO.FieldDTO;
import com.ode.exchange.re.DTO.FieldNameDTO;
import com.ode.exchange.re.entity.DropDown;
import com.ode.exchange.re.entity.ETLConfiguration;
import com.ode.exchange.re.entity.FieldName;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IDropDownDAO;
import com.ode.exchange.re.repository.IFieldDAO;
import com.ode.exchange.re.repository.IFieldNameDAO;

/**
 * This Service Implementation Class for FieldNameServiceImpl.
 * 
 * @author
 * 
 */
@Service
@Transactional
public class FieldNameServiceImpl {

	public static final Logger logger = LoggerFactory.getLogger(FieldNameServiceImpl.class);

	@Autowired
	IFieldNameDAO fieldNameDAO;

	@Autowired
	IFieldDAO fieldDAO;

	@Autowired
	IDropDownDAO dropDownDAO;
	
	/**
	 * 
	 * Removed DropDownHistory for Phase 2
	 */

	/*@Autowired
	IDropDownHistoryDAO dropDownHistoryDAO;*/

	@Autowired
	private ModelMapper modelMapper;

	/**
	 * Fetch all Fields associated with Dropdowns from DB
	 * 
	 * @return Get All Dropdowns along with FieldNames
	 */

	public List<FieldNameDTO> getFieldNameDropDownAll() {
		List<FieldNameDTO> fieldDTOlist = new ArrayList<>();
		List<FieldName> fieldNamelist = fieldNameDAO.findFieldAll();

		fieldNamelist.forEach(fieldName -> {
			FieldNameDTO fieldNameDTO = modelMapper.map(fieldName, FieldNameDTO.class);
			java.lang.reflect.Type targetListType = new TypeToken<List<DropDownDTO>>() {
			}.getType();
			List<DropDownDTO> dropdownDTOlist = modelMapper.map(fieldName.getDropDownlist(), targetListType);

			fieldNameDTO.setDropdownDTOlist(dropdownDTOlist);
			fieldDTOlist.add(fieldNameDTO);
		});

		return fieldDTOlist;

	}

	/**
	 * // Fetch Field and associated with Dropdowns based on fieldID
	 *
	 * @param fieldDropDownID - field id
	 * @return Dropdowns associated with a FieldName
	 */

	public FieldNameDTO findFieldDropDownById(int fieldDropDownID) {
		FieldName fieldNameEntity = fieldNameDAO.findById(fieldDropDownID);
		if (fieldNameEntity == null) {
			throw new NotFoundException("FieldName does not have any Dropdown");
		}
		java.lang.reflect.Type targetListType = new TypeToken<List<DropDownDTO>>() {
		}.getType();
		List<DropDownDTO> dropdownDTOlist = modelMapper.map(fieldNameEntity.getDropDownlist(), targetListType);
		FieldNameDTO fieldNameDTOObj = modelMapper.map(fieldNameEntity, FieldNameDTO.class);
		fieldNameDTOObj.setDropdownDTOlist(dropdownDTOlist);
		return fieldNameDTOObj;
	}

	/**
	 * // // Fetch all Fields
	 *
	 *
	 * @return all FieldNames
	 */
	public List<FieldDTO> getFieldAll() {

		List<ETLConfiguration> fieldlist = fieldDAO.findAll();
		java.lang.reflect.Type targetListType = new TypeToken<List<FieldDTO>>() {
		}.getType();
		return modelMapper.map(fieldlist, targetListType);

	}

	/**
	 * // Fetch Fields based fieldID
	 *
	 *
	 * @return all FieldNames based fieldID
	 */

	public FieldDTO getFieldById(int fieldID) {
		ETLConfiguration fieldEntity = fieldDAO.findById(fieldID);

		if (fieldEntity == null) {
			throw new NotFoundException("FieldName does not exist");
		}

		return modelMapper.map(fieldEntity, FieldDTO.class);

	}

	/**
	 * Create Dropdown.
	 * 
	 * If dropdown is successfully created, success message is displayed else error
	 * message is displayed accordingly. If there are any existing dropdowns with
	 * the fieldName as passed fieldName to the API, existing dropdowns will be
	 * removed from the dropdown table and newly entered dropdowns are saved in
	 * DropDown Table.
	 * 
	 * @param fieldnameDTO - Dropdown to be created
	 * @return dropDownEntitylistdb - list of dropdowns created.
	 */
	
	/**
	 * 
	 * Removed DropDownHistory for Phase 2
	 */

	public List<DropDown> createFieldDropDown(FieldNameDTO fieldnameDTO) {
		List<DropDown> dropDownEntitylist = new ArrayList<>();
		List<DropDown> dropDownEntitylistdb = new ArrayList<>();
		//List<DropDownHistory> dropDownHistoryEntitylist = new ArrayList<>();

		ETLConfiguration fieldEntity = fieldDAO.findFieldByName(fieldnameDTO.getAliasFieldName());
		if (fieldEntity == null) {
			throw new NotFoundException("Field does not exist");
		}
		int fieldid = fieldEntity.getId();

		List<DropDown> dropDownlist = dropDownDAO.findAll();
		if (dropDownlist != null) {
			for (Iterator<DropDown> i = dropDownlist.iterator(); i.hasNext();) {
				DropDown dropdown = i.next();

				if (dropdown.getFieldNameID() == fieldid) {
					i.remove();
					dropDownDAO.deleteById(dropdown.getId());

				}

			}
		}
		if (fieldnameDTO.getDropdownDTOlist() != null) {
			fieldnameDTO.getDropdownDTOlist().forEach(dropDownDTO -> {
				DropDown dropDownEntity = modelMapper.map(dropDownDTO, DropDown.class);

				FieldName fieldNameEntity = fieldNameDAO.findByNameId(fieldnameDTO.getAliasFieldName());
				if (fieldNameEntity == null) {
					throw new NotFoundException("FieldName does not exist");
				}
				dropDownEntity.setFieldNameID(fieldNameEntity.getId());
				dropDownEntitylist.add(dropDownEntity);

				//DropDownHistory dropDownHistoryEntity = modelMapper.map(dropDownDTO, DropDownHistory.class);
				//dropDownHistoryEntity.setFieldNameID((fieldNameEntity.getId()));
				//dropDownHistoryEntitylist.add(dropDownHistoryEntity);

			});
		}
		dropDownEntitylistdb = (List<DropDown>) dropDownDAO.saveAll(dropDownEntitylist);
		//dropDownHistoryDAO.saveAll(dropDownHistoryEntitylist);
		return dropDownEntitylistdb;

	}

}
