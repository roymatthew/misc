package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.DTO.FunctionalityUserRoleMappingDTO;
import com.ode.exchange.re.entity.Functionality;
import com.ode.exchange.re.entity.FunctionalityUserRoleMap;
import com.ode.exchange.re.entity.FunctionalityUserRoleMapping;
import com.ode.exchange.re.repository.IFunctionalityUserMappingDAO;
import com.ode.exchange.re.repository.IFunctionalityUserRoleMapDAO;
/**
 * This Service Implementation Class for FunctionalityMappingServiceImpl.
 * @author 
 * 
 */
@Service
@Transactional
public class FunctionalityMappingServiceImpl {

	public static final Logger logger = LoggerFactory.getLogger(FunctionalityMappingServiceImpl.class);

	@Autowired
	IFunctionalityUserMappingDAO functionalitymappingDAO;
	

	@Autowired
	IFunctionalityUserRoleMapDAO functionalityUserRoleMapDAO;

	/**
	 * 
	 * Removed FunctionalityUserRoleMappingHistory for Phase 2
	 */
	
	/*@Autowired
	IFunctionalityUserRoleMappingHistoryDAO functionalitymappinghistoryDAO;*/

	/**Get All Functionalities based on userroleID
	 * @return Get All Functionalities based on userroleID
	 */	

	
	public List<FunctionalityUserRoleMapping> getFunctionalityAll(int userroleID) {
		return  functionalitymappingDAO.findMappingAll(userroleID);

	}
	
	/**
	 * Create Functionality Map.
	 * 
	 * This API also saves the entered data to FunctionalityUserRoleMapping History table. If Functionality
	 * is successfully created, success message is displayed else error message is
	 * displayed accordingly. If there are any existing Functionalities with the UserRole
	 * existing Functionalities will be removed from the
	 * FunctionalityUserRoleMapping table and newly entered Functionalities are saved in FunctionalityUserRoleMapping Table.
	 * 
	 * @param fumDTOList - List of FunctionalityUserRoleMapping .
	 * @return fUMIterableList List of FunctionalityUserRoleMapping on successful FunctionalityMapping creation
	 */
	
	/**
	 * 
	 * Removed FunctionalityUserRoleMappingHistory for Phase 2
	 */

	public List<FunctionalityUserRoleMapping> createFunctionalityMapping(List<FunctionalityUserRoleMappingDTO> fumDTO) {
		List<FunctionalityUserRoleMapping> fUMlist = new ArrayList<>();
		List<FunctionalityUserRoleMapping> fUMIterableList = new ArrayList<>();
		//List<FunctionalityUserRoleMappingHistory> fUMHlist = new ArrayList<>();		
		
		Set<Integer> userRoleIdSet = new HashSet<>();

		for (int j = 0; j < fumDTO.size(); j++) {

			if (!userRoleIdSet.contains((fumDTO.get(j).getUserroleID()))) {
				userRoleIdSet.add((fumDTO.get(j).getUserroleID()));
			}
		}
		for (int userRoleID : userRoleIdSet) {
			List<FunctionalityUserRoleMap> fUMByUserRole = functionalityUserRoleMapDAO.findByFunctionalityUserRoleId(userRoleID);
			if (fUMByUserRole != null) {
				for (Iterator<FunctionalityUserRoleMap> i = fUMByUserRole.iterator(); i.hasNext();) {
					FunctionalityUserRoleMap functionalityUserRoleMap = i.next();
					i.remove();
					functionalityUserRoleMapDAO.deleteById(functionalityUserRoleMap.getId());

				}
			}
		}

		if (fumDTO != null) {
			for (int i = 0; i < fumDTO.size(); i++) {
				Functionality functionality = new Functionality();
				FunctionalityUserRoleMapping fUM = new FunctionalityUserRoleMapping();
			//	FunctionalityUserRoleMappingHistory fUMH = new FunctionalityUserRoleMappingHistory();

				//fUMH.setFunctionalityid(fumDTO.get(i).getFunctionalityid());
			//	fUMH.setUserroleID(fumDTO.get(i).getUserroleID());
			//	fUMHlist.add(fUMH);

				functionality.setFunctionalityName(fumDTO.get(i).getFunctionalityName());
				functionality.setId(fumDTO.get(i).getFunctionalityid());
				fUM.setFunctionality(functionality);
				fUM.setUserroleID(fumDTO.get(i).getUserroleID());
				fUM.setPrivilegeEdit(fumDTO.get(i).isPrivilegeEdit());
				fUM.setPrivilegeView(fumDTO.get(i).isPrivilegeView());
				fUMlist.add(fUM);
			}

		}
		//functionalitymappinghistoryDAO.saveAll(fUMHlist);
		fUMIterableList = (List<FunctionalityUserRoleMapping>) functionalitymappingDAO.saveAll(fUMlist);
		
		return fUMIterableList;
	}
	
	/**Get All Functionalities along with their associated UserRoles
	 * @return list of Functionalities along with their associated UserRole
	 */	

	public List<FunctionalityUserRoleMappingDTO> getFunctionalityMappingAll() {
		List<FunctionalityUserRoleMappingDTO> fUMDTOlist = new ArrayList<>();

		List<FunctionalityUserRoleMapping> fUMlist = (List<FunctionalityUserRoleMapping>) functionalitymappingDAO
				.findAll();

		for (int i = 0; i < fUMlist.size(); i++) {
			FunctionalityUserRoleMappingDTO fUMDTO = new FunctionalityUserRoleMappingDTO();
			fUMDTO.setFunctionalityName(fUMlist.get(i).getFunctionality().getFunctionalityName());
			fUMDTO.setFunctionalityid((fUMlist.get(i).getFunctionality().getId()));
			fUMDTO.setUserroleID(fUMlist.get(i).getUserroleID());
			fUMDTO.setPrivilegeEdit(fUMlist.get(i).isPrivilegeEdit());
			fUMDTO.setPrivilegeView(fUMlist.get(i).isPrivilegeView());
			fUMDTOlist.add(fUMDTO);
		}
		
		return fUMDTOlist;
	}

}