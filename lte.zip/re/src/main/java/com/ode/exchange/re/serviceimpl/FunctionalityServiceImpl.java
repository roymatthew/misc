package com.ode.exchange.re.serviceimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.entity.Functionality;
import com.ode.exchange.re.repository.IFunctionalityDAO;

/**
 * This Service Implementation Class for FunctionalityServiceImpl.
 * @author 
 * 
 */
@Service
@Transactional
public class FunctionalityServiceImpl {
	public static final Logger logger = LoggerFactory.getLogger(FunctionalityServiceImpl.class);
	
	@Autowired
	IFunctionalityDAO functionalityDAO;

	/**Get All Functionalities
	 * @return Get All Functionalities
	 */	

	public List<Functionality> getFunctionalityAll()
	{
		return  (List<Functionality>) functionalityDAO.findAll();

	}
	
	/**
	 * Get Functionality By id
	 *
	 * @param functionalityID - functionality id 
	 * @return Functionality associated with a functionalityID
	 */

	
	public Functionality getFunctionality(int functionalityid)
	{
		return  functionalityDAO.findById(functionalityid);

	}
	
	
}