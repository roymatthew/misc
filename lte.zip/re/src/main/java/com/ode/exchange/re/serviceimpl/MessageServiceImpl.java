package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.DTO.MessageDTO;
import com.ode.exchange.re.DTO.MessageTypeDTO;
import com.ode.exchange.re.DTO.RuleClassificationDTO;
import com.ode.exchange.re.entity.Message;
import com.ode.exchange.re.entity.MessageType;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IMessageDAO;
import com.ode.exchange.re.repository.IMessageTypeDAO;
import com.ode.exchange.re.repository.IRuleClassificationDAO;
/**
 * This Service Implementation Class for MessageServiceImpl.
 * @author 
 * 
 */
@Service
@Transactional
public class MessageServiceImpl {
	public static final Logger logger =  LoggerFactory.getLogger(MessageServiceImpl.class);

	@Autowired
	IRuleClassificationDAO ruleClassificationDAO;

	@Autowired
	IMessageDAO messageDAO;

	@Autowired
	IMessageTypeDAO messagetypeDAO;
	
	@Autowired
	    private ModelMapper modelMapper;

	@Autowired
	IRuleClassificationDAO rcDAO;

	/**
	 * Get All Messages
	 * 
	 * @return lists all Messages
	 */
	public List<MessageDTO> getMessagesAll() {
		List<MessageDTO> messageDTOlist = new ArrayList<>();
		List<Message> messageList =  messageDAO.findAll();
		if (messageList != null) {
			java.lang.reflect.Type targetListType = new TypeToken<List<MessageDTO>>() {
			}.getType();
			messageDTOlist = modelMapper.map(messageList, targetListType);
			for (int i = 0; i < messageList.size(); i++) {
				MessageTypeDTO messageTypeDTO = modelMapper.map(messageList.get(i).getMessageType(),
						MessageTypeDTO.class);
				RuleClassificationDTO ruleClassificationDTODTO = modelMapper
						.map(messageList.get(i).getRuleClassification(), RuleClassificationDTO.class);
				MessageDTO messageDTO = modelMapper.map(messageList.get(i), MessageDTO.class);
				messageDTO.setMessageType(messageTypeDTO);
				messageDTO.setRuleClassification(ruleClassificationDTODTO);
				
			}
		}
		return messageDTOlist;

	}

	/**
	 * Get Message By id
	 *
	 * @param messageId - message id
	 * @return message associated with the messageId
	 */

	
	public MessageDTO findMessageById(int messageId) {
		MessageDTO messageDTO = new MessageDTO();	
		Message messageEntity = messageDAO.findById(messageId);			
		if (messageEntity == null) {
			throw new NotFoundException("Message does not exist");
		}
			MessageTypeDTO messageTypeDTO = modelMapper.map(messageEntity.getMessageType(), MessageTypeDTO.class);
			RuleClassificationDTO ruleClassificationDTODTO = modelMapper.map(messageEntity.getRuleClassification(),
					RuleClassificationDTO.class);
			messageDTO = modelMapper.map(messageEntity, MessageDTO.class);
			messageDTO.setMessageType(messageTypeDTO);
			messageDTO.setRuleClassification(ruleClassificationDTODTO);
		
		return messageDTO;
	}
	
	/**
	 * Create Message
	 * 
	 * 
	 * @param messageDTO  - Message to be created	 
	 * @return messageDTO - created Message
	 */

	
	public MessageDTO createMessages(MessageDTO messageDTO)  {
		if (messageDTO != null) {				
			Message messageEntity = modelMapper.map(messageDTO, Message.class);
			if (messageDTO.getRuleClassification() != null) {
				RuleClassification rcEntity = rcDAO.findById(messageDTO.getRuleClassification().getId());
				
				if (rcEntity == null) {
					throw new  NotFoundException("RuleClassification does not exist");
				}
				messageEntity.setRuleClassification(rcEntity);
			}
			if (messageDTO.getMessageType() != null) {
				MessageType messagetypeEntity = messagetypeDAO.findById(messageDTO.getMessageType().getId());
				if (messagetypeEntity == null) {
					throw new NotFoundException("MessageType does not exist");
				}
				messageEntity.setMessageType(messagetypeEntity);
			}
			
			messageEntity =	messageDAO.save(messageEntity);

			MessageTypeDTO messageTypeDTO = modelMapper.map(messageEntity.getMessageType(), MessageTypeDTO.class);
			RuleClassificationDTO ruleClassificationDTODTO = modelMapper.map(messageEntity.getRuleClassification(),
					RuleClassificationDTO.class);
			messageDTO = modelMapper.map(messageEntity, MessageDTO.class);
			messageDTO.setMessageType(messageTypeDTO);
			messageDTO.setRuleClassification(ruleClassificationDTODTO);	
		}
		return messageDTO;
	}
	
	
	/**
	 * Update Message by id
	 * 
	 * 
	 * @param messageDTO - Message to be updated 
	 * @param messageId  - message id
	 * @return messageDTO - Message updated
	 */
	
	
	public MessageDTO updateById(int messageId, MessageDTO messageDTO) throws Exception {
		Message messageEntity = messageDAO.findById(messageId);
		if (messageEntity == null) {
			throw new NotFoundException("Message does not exist");
		}
		messageEntity.setMessageName(messageDTO.getMessageName());
		messageEntity.setMessage(messageDTO.getMessage());
		messageEntity.setRemarks(messageDTO.getRemarks());
		messageEntity.setStatus(messageDTO.isStatus());		
		messageEntity =	messageDAO.save(messageEntity);

		// changed to update message type and rule classifications
		
		MessageType messageType = messagetypeDAO.findById(messageDTO.getMessageType().getId());
		MessageTypeDTO messageTypeDTO = modelMapper.map(messageType, MessageTypeDTO.class);
		
		RuleClassification ruleClassification = ruleClassificationDAO.findById(messageDTO.getRuleClassification().getId());
		RuleClassificationDTO ruleClassificationDTODTO = modelMapper.map(ruleClassification,
				RuleClassificationDTO.class);
		
		messageDTO = modelMapper.map(messageEntity, MessageDTO.class);
		messageDTO.setMessageType(messageTypeDTO);
		messageDTO.setRuleClassification(ruleClassificationDTODTO);	
		return messageDTO;

	}
	
	
	/**
	 * Get Message By Rule Classification id
	 *
	 * @param ruleClassificationId - Rule Classification id
	 * @return message associated with the ruleClassificationId
	 */

	public List<MessageDTO> findMessagesByRuleClassificationId(int ruleClassificationId) throws Exception {
		List<MessageDTO> messageDTOlist = new ArrayList<>();
		List<Message> messageList = messageDAO.findRuleClassificationId(ruleClassificationId);
		if (messageList == null) {

			throw new NotFoundException("Message does not exist for this Classification");
		}
		if (!messageList.isEmpty()) {
			java.lang.reflect.Type targetListType = new TypeToken<List<MessageDTO>>() {
			}.getType();
			messageDTOlist = modelMapper.map(messageList, targetListType);
			for (int i = 0; i < messageList.size(); i++) {
				MessageTypeDTO messageTypeDTO = modelMapper.map(messageList.get(i).getMessageType(),
						MessageTypeDTO.class);
				RuleClassificationDTO ruleClassificationDTODTO = modelMapper
						.map(messageList.get(i).getRuleClassification(), RuleClassificationDTO.class);
				MessageDTO messageDTO = modelMapper.map(messageList.get(i), MessageDTO.class);
				messageDTO.setMessageType(messageTypeDTO);
				messageDTO.setRuleClassification(ruleClassificationDTODTO);
			}
		}
		return messageDTOlist;
	}
	
	/**
	 * Get Default Messages By Rule Classification id
	 *
	 * @param ruleClassificationId - Rule Classification id
	 * @return messageDTOlist associated with the ruleClassificationId
	 */
	
	public List<MessageDTO> findDefaultMessagesByRuleClassificationId(int ruleClassificationId) throws Exception {
		List<MessageDTO> messageDTOlist = new ArrayList<>();
		List<Message> messageList = messageDAO.findDefaultMessageRuleClassificationId(ruleClassificationId);
		if (messageList == null) {

			throw new NotFoundException("Message does not exist for this Classification");
		}
		if (!messageList.isEmpty()) {
			java.lang.reflect.Type targetListType = new TypeToken<List<MessageDTO>>() {
			}.getType();
			messageDTOlist = modelMapper.map(messageList, targetListType);
			for (int i = 0; i < messageList.size(); i++) {
				MessageTypeDTO messageTypeDTO = modelMapper.map(messageList.get(i).getMessageType(),
						MessageTypeDTO.class);
				RuleClassificationDTO ruleClassificationDTODTO = modelMapper
						.map(messageList.get(i).getRuleClassification(), RuleClassificationDTO.class);
				
				MessageDTO messageDTO = modelMapper.map(messageList.get(i), MessageDTO.class);
				messageDTO.setMessageType(messageTypeDTO);
				messageDTO.setRuleClassification(ruleClassificationDTODTO);
			}
		}
		return messageDTOlist;
	}
	
	
	
}
