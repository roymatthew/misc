package com.ode.exchange.re.serviceimpl;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.exchange.re.DTO.XMLFieldsDTO;
import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.entity.CreditDecision;
import com.ode.exchange.re.entity.LookUpCriteriaPassRules;
import com.ode.exchange.re.entity.ProcessAudit;
import com.ode.exchange.re.entity.RFLRuleResponse;
import com.ode.exchange.re.entity.RegulationRuleLogicExpression;
import com.ode.exchange.re.entity.RequiredFieldRule;
import com.ode.exchange.re.entity.Rule;
import com.ode.exchange.re.entity.RuleAudit;
import com.ode.exchange.re.entity.StringentRuleQualification;
import com.ode.exchange.re.entity.ToleranceGetValues;
import com.ode.exchange.re.entity.ToleranceRule;
import com.ode.exchange.re.entity.ToleranceRuleLogic;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.etlutils.NumberFormatUtils;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IRuleDAO;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.transaction.Transactional;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@Transactional
@PropertySource(value = "file:/data/ode/derulesengine/application.properties")
public class ProcessRuleServiceImpl {
	private static final Logger logger = LoggerFactory.getLogger(ProcessRuleServiceImpl.class);

	@Value("${ode.no-rule-failure}")
	private String norule;

	@Value("${ode.formvalidation-form}")
	private String formNumberTag;

	@Value("${ode.formvalidation-revisiondate}")
	private String formRevisionTag;

	@Value("${ode.qualified-rule-pass}")
	private String pass;

	@Value("${ode.processaudit-pass}")
	private String auditPass;

	@Value("${ode.qualified-rule-fail}")
	private String fail;

	@Value("${ode.qualified-rule-fail-message}")
	private String failmessage;

	@Value("${ode.qualified-rule-pass-message}")
	private String passmessage;

	@Value("${ode.tolerance.amount}")
	private String amount;

	@Value("${ode.tolerance.number}")
	private String number;

	@Value("${ode.tolerance.percent}")
	private String percent;

	@Value("${ode.tolerance.character}")
	private String character;

	@Autowired
	private RuleAuditServiceImpl ruleAuditService;


	@Autowired
	private IRuleDAO ruleDAO;

	/**
	 * Process Required Field Rules.
	 *
	 * Single rule is qualified for Required Field. Qualified rule is checked
	 * for the existence of the fields in xml
	 *
	 * @return if all fields exists return pass else missing fields are returned
	 */

	public Optional<RequiredFieldRule> getRuleByRequiredField(Map<String, String> xmlLookUpFieldMap,
			ProcessAudit processAudit) {
		logger.info("Entered getRuleByRequiredField() method of ProcessRuleServiceImpl.class");
		List<StringentRuleQualification> stringentRuleList = new ArrayList<>();
		List<Rule> masterPassedList = new ArrayList<>();
		LookUpCriteriaPassRules lookUpCriteriaPassRule = new LookUpCriteriaPassRules();
		Rule finalrule = new Rule();

		processAudit.setRfValidationStart(new Timestamp(System.currentTimeMillis()));
		logger.info("Required Field Rules Processing...");
		List<Rule> rulelist = ruleDAO.findByRequiredField();

		if (rulelist == null || rulelist.isEmpty()) {
			processAudit.setRfValidationResult(norule);
			processAudit.setRfValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/* Get the rules which pass the Stringent lookup criteria */
		logger.info("Invoking lookupFieldCheck for Stringent filtering of Required Field Rules...");
		Optional<LookUpCriteriaPassRules> lookUpCriteriaPassRules = lookupFieldCheck(rulelist, xmlLookUpFieldMap);
		if (lookUpCriteriaPassRules.isPresent()) {
			lookUpCriteriaPassRule = lookUpCriteriaPassRules.get();
		}
		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			processAudit.setRfValidationResult(norule);
			processAudit.setRfValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/*
		 * Look up fields qualified rules are sorted based on the Stringent
		 * Rules hierarchy
		 */

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() != null) {
			stringentRuleList = lookUpCriteriaPassRule.getStringentQualifyRuleList();
			stringentRuleList = stringentRuleList.stream()
					.sorted((StringentRuleQualification o1, StringentRuleQualification o2) -> {

						int min = Math.min(o1.getStringentRuleHierarchyList().size(),
								o2.getStringentRuleHierarchyList().size());
						for (int i = 0; i < min; i++) {
							int higher = o1.getStringentRuleHierarchyList().get(i)
									.compareTo(o2.getStringentRuleHierarchyList().get(i));
							if (higher != 0) {
								return higher;
							}
						}
						return Integer.compare(o2.getStringentRuleHierarchyList().size(),
								o1.getStringentRuleHierarchyList().size());
					}).collect(Collectors.toList());

			Boolean sameStringentHirearchy = false;

			/*
			 * If there exists two rules with highest stringent rule priority,
			 * then sort based on the number of lookup fields matched
			 */

			for (StringentRuleQualification stringentRule : stringentRuleList.subList(1, stringentRuleList.size())) {
				if (stringentRule.getStringentRuleHierarchyList()
						.equals(stringentRuleList.get(0).getStringentRuleHierarchyList())) {
					sameStringentHirearchy = true;

				}
			}
			if (sameStringentHirearchy) {

				stringentRuleList.sort((StringentRuleQualification s1,
						StringentRuleQualification s2) -> s2.getTotalLookUpCount() - s1.getTotalLookUpCount());
				finalrule = stringentRuleList.get(0).getStringentRule();
			} else {
				finalrule = stringentRuleList.get(0).getStringentRule();
			}

		}

		/*
		 * if no stringent rules and only master rule exists, then final rule is
		 * the recently created master rule
		 */

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() != null) {
			masterPassedList = lookUpCriteriaPassRule.getMasterPassedMap();
			finalrule = masterPassedList.get(0);
		}

		/*
		 * if no stringent rule and no master rule, return norule
		 *
		 */
		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			processAudit.setRflValidationResult(norule);
			processAudit.setRflValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}
		RequiredFieldRule requiredFieldRule = new RequiredFieldRule();
		requiredFieldRule.setRule(finalrule);
		requiredFieldRule.setProcessAudit(processAudit);

		return Optional.of(requiredFieldRule);

	}

	/**
	 * Process Form Number Validation Rules.
	 *
	 * Single rule is qualified for Form Number. Qualified rule is checked for
	 * the existence of the Form Number and Revision Date value in xml
	 *
	 * @return if all fields exists return pass else appropriate fail message
	 */

	public Optional<Integer> getRuleByFormValidation(Map<String, String> formValidationXMLMap,
			Map<String, String> xmlLookUpFieldMap, ProcessAudit processAudit) {

		logger.debug("Entered getRuleByFormValidation() method of ProcessRuleServiceImpl class");

		LinkedHashSet<Rule> passedLookupset = new LinkedHashSet<>();

		Map<Rule, String> passRuleItems = new HashMap();
		Map<Rule, String> failRuleItems = new HashMap();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		logger.info("Form Validation Rules Processing...");
		List<StringentRuleQualification> stringentRuleList = new ArrayList<>();

		List<Rule> masterPassedMap = new ArrayList<>();

		LookUpCriteriaPassRules lookUpCriteriaPassRule = new LookUpCriteriaPassRules();

		processAudit.setFnValidationStart(new Timestamp(System.currentTimeMillis()));

		List<Rule> formValidationRulelist = ruleDAO.findByFormNumber();

		if (formValidationRulelist == null || formValidationRulelist.isEmpty()) {

			processAudit.setFnValidationResult(norule);
			processAudit.setFnValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();

		}

		/* Get the rules which pass the Stringent lookup criteria */
		logger.info("Invoking lookupFieldCheck for Stringent filtering of Form Validation Rules...");
		Optional<LookUpCriteriaPassRules> lookUpCriteriaPassRules = lookupFieldCheck(formValidationRulelist,
				xmlLookUpFieldMap);
		if (lookUpCriteriaPassRules.isPresent()) {
			lookUpCriteriaPassRule = lookUpCriteriaPassRules.get();

		}

		/* No Stringent rule or Master rule return norule */

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			processAudit.setFnValidationResult(norule);
			processAudit.setFnValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/*
		 * Look up fields qualified rules are sorted based on the Stringent
		 * Rules hierarchy
		 */

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() != null) {
			stringentRuleList = lookUpCriteriaPassRule.getStringentQualifyRuleList();
			stringentRuleList = stringentRuleList.stream()
					.sorted((StringentRuleQualification o1, StringentRuleQualification o2) -> {
						int min = Math.min(o1.getStringentRuleHierarchyList().size(),
								o2.getStringentRuleHierarchyList().size());
						for (int i = 0; i < min; i++) {
							int higest = o1.getStringentRuleHierarchyList().get(i)
									.compareTo(o2.getStringentRuleHierarchyList().get(i));
							if (higest != 0) {
								return higest;
							}
						}
						return Integer.compare(o2.getStringentRuleHierarchyList().size(),
								o1.getStringentRuleHierarchyList().size());
					}).collect(Collectors.toList());
			Boolean sameStringentHirearchy = false;

			/*
			 * If there exists two rules with highest stringent rule priority,
			 * then sort based on the number of lookup fields matched
			 */
			for (StringentRuleQualification stringentRule : stringentRuleList.subList(1, stringentRuleList.size())) {
				if (stringentRule.getStringentRuleHierarchyList()
						.equals(stringentRuleList.get(0).getStringentRuleHierarchyList())) {
					sameStringentHirearchy = true;
					break;

				}
			}

			if (sameStringentHirearchy) {

				stringentRuleList.sort((StringentRuleQualification s1,
						StringentRuleQualification s2) -> s2.getTotalLookUpCount() - s1.getTotalLookUpCount());
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getTotalLookUpCount() == stringentRule.getTotalLookUpCount()) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			} else if (!sameStringentHirearchy) {
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getStringentRuleHierarchyList()
							.equals(stringentRule.getStringentRuleHierarchyList())) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			}
		}
		/*
		 * if no stringent rules and only master rule exists, then master rules
		 * are qualified for the Form Number processing
		 */
		if (passedLookupset.isEmpty() && lookUpCriteriaPassRule.getMasterPassedMap() != null) {
			masterPassedMap = lookUpCriteriaPassRule.getMasterPassedMap();
			passedLookupset.addAll(masterPassedMap);

		}

		/*
		 * if only one rule is qualified, check form number and revision(month
		 * and year) if Form number is fails, No rule is qualified; if Revision
		 * Date is not matching then, Fail message is returned
		 */

		if (!passedLookupset.isEmpty()) {
			passedLookupset.forEach(formValidationPassRule -> {

				logger.info("Form Validation Rule for processing Form Number and Revision Date...Rule ID: {}, Rule Name: {}",
						formValidationPassRule.getId(), formValidationPassRule.getRuleName());

				String fixedFieldValues = formValidationPassRule.getRuleLogic();

				fixedFieldValues = fixedFieldValues.substring(1, fixedFieldValues.length() - 1);

				ObjectMapper mapper = new ObjectMapper();
				RuleAudit ruleAudit = new RuleAudit();
				TypeReference<LinkedHashMap<String, String>> typeRef = new TypeReference<LinkedHashMap<String, String>>() {
				};
				LinkedHashMap<String, String> fixedFieldValuesRulesMap = new LinkedHashMap<>();
				try {
					fixedFieldValuesRulesMap = mapper.readValue(fixedFieldValues, typeRef);
				} catch (IOException e) {
					logger.error("Form Number Rule Exception while conversion of look up field {} ",
							fixedFieldValuesRulesMap);
					throw new NotFoundException("Form Number Rule Exception while conversion of look up field "
							+ fixedFieldValuesRulesMap + " " + e.getMessage());
				}

				Boolean formNumber = true;
				Boolean formRevisionDate = false;
				if (fixedFieldValuesRulesMap.containsKey(formNumberTag)
						&& formValidationXMLMap.containsKey(formNumberTag)
						&& fixedFieldValuesRulesMap.containsKey(formRevisionTag)
						&& formValidationXMLMap.containsKey(formRevisionTag)) {

					if (!fixedFieldValuesRulesMap.get(formNumberTag)
							.equalsIgnoreCase(formValidationXMLMap.get(formNumberTag))) {
						formNumber = false;
					}
					Calendar calContractRevisonRule = Calendar.getInstance();
					Calendar calContractRevisonXMLDateTime = Calendar.getInstance();
					Date contractRevisonXMLDateTime = new Date();
					Date contractRevisonRuleDateTime = new Date();
					try {
						contractRevisonRuleDateTime = formatter.parse(fixedFieldValuesRulesMap.get(formRevisionTag));
						contractRevisonXMLDateTime = formatter.parse(formValidationXMLMap.get(formRevisionTag));
					} catch (ParseException e) {
						logger.error("Form Number Rule Exception: Date Conversion of Revision Date" + e.getMessage());
						throw new BadRequestException(
								"Form Number Rule Exception: Date Conversion of Revision Date " + e.getMessage());

					}
					calContractRevisonXMLDateTime.setTime(contractRevisonXMLDateTime);
					calContractRevisonRule.setTime(contractRevisonRuleDateTime);
					if (Integer.compare(calContractRevisonXMLDateTime.get(Calendar.YEAR),
							calContractRevisonRule.get(Calendar.YEAR)) == 0
							&& Integer.compare(calContractRevisonXMLDateTime.get(Calendar.MONTH),
									calContractRevisonRule.get(Calendar.MONTH)) == 0
									&& Integer.compare(calContractRevisonXMLDateTime.get(Calendar.DAY_OF_MONTH),
											calContractRevisonRule.get(Calendar.DAY_OF_MONTH)) == 0) {
						formRevisionDate = true;
					}

					if (formNumber && formRevisionDate) {
						ruleAudit.setRuleExecutionResult(pass);
						logger.info("Form Validation Rule Passed...Rule ID: {}, Rule Name: {}",
								formValidationPassRule.getId(), formValidationPassRule.getRuleName());
						ruleAudit.setRcid(formValidationPassRule.getRuleClassification().getId());
						ruleAudit.setXmlId(processAudit.getXmlId());
						ruleAudit.setLookupCriteria(formValidationPassRule.getLookupCriteria());
						ruleAudit.setRulelogic(formValidationPassRule.getRuleLogic());
						ruleAudit.setRule(formValidationPassRule);

						if (formValidationPassRule.getPassmessage() != null) {
							ruleAudit.setMessageResponse(formValidationPassRule.getPassmessage().getMessage());

						} else if (formValidationPassRule.getPassmessage() == null) {
							ruleAudit.setMessageResponse("");
						}

						ruleAuditService.saveRuleAudit(ruleAudit);
						passRuleItems.put(formValidationPassRule, ruleAudit.getMessageResponse());

					} else if (!formNumber && formRevisionDate || formNumber && !formRevisionDate
							|| !formNumber && !formRevisionDate) {

						ruleAudit.setRuleExecutionResult(fail);
						ruleAudit.setRcid(formValidationPassRule.getRuleClassification().getId());
						ruleAudit.setXmlId(processAudit.getXmlId());
						ruleAudit.setLookupCriteria(formValidationPassRule.getLookupCriteria());
						ruleAudit.setRulelogic(formValidationPassRule.getRuleLogic());
						logger.info("Form Number on Rule is :  " + fixedFieldValuesRulesMap.get(formNumberTag)
						+ "Form Number on XML is : " + formValidationXMLMap.get(formNumberTag)
						+ "Revision Date on Rule  is :  " + fixedFieldValuesRulesMap.get(formRevisionTag)
						+ "Revision Date on XML is :  " + formValidationXMLMap.get(formRevisionTag));
						if (formValidationPassRule.getFailmessage() != null) {

							ruleAudit.setMessageResponse(formValidationPassRule.getFailmessage().getMessage());
						}
						if (formValidationPassRule.getFailmessage() == null) {
							ruleAudit.setMessageResponse("");
						}

						ruleAudit.setRule(formValidationPassRule);
						ruleAuditService.saveRuleAudit(ruleAudit);
						failRuleItems.put(formValidationPassRule, ruleAudit.getMessageResponse());

						logger.info("Form Validation Rule Failed...{}", formValidationPassRule);
					}

				}
			});

		}

		if (!failRuleItems.isEmpty() && !passRuleItems.isEmpty()) {

			processAudit.setFnValidationResult(
					passmessage + " || " + failmessage + " FormValidation Failure: Qualified Rules Failed");

		}
		if (!failRuleItems.isEmpty() && passRuleItems.isEmpty()) {
			if (failRuleItems.size() == 1) {
				for (Entry<Rule, String> rulemsgpair : failRuleItems.entrySet()) {
					processAudit
					.setFnValidationResult(passmessage + " || " + failmessage + " " + rulemsgpair.getValue());
				}
			}
			if (failRuleItems.size() > 1) {
				processAudit.setFnValidationResult(
						passmessage + " || " + failmessage + " FormValidation Failure:All Qualified Rules Failed");

			}

		}
		if (failRuleItems.isEmpty() && !passRuleItems.isEmpty()) {
			if (passRuleItems.size() == 1) {
				// fail if only one pass rule, pass that else generic
				for (Entry<Rule, String> rulemsgpair : passRuleItems.entrySet()) {
					processAudit.setFnValidationResult(
							passmessage + " " + rulemsgpair.getValue() + auditPass + " || " + failmessage + " ");
				}
			}

			if (passRuleItems.size() > 1) {
				processAudit.setFnValidationResult(passmessage + " FormValidation Pass:All Qualified Rules Passed"
						+ auditPass + " || " + failmessage + " ");

			}

		}

		processAudit.setFnValidationEnd(new Timestamp(System.currentTimeMillis()));

		logger.debug("Exit getRuleByFormValidation() method of ProcessRuleServiceImpl class");
		return Optional.empty();
	}

	/**
	 * Process Regulation Rules.
	 *
	 * Multiple rules can be qualified for Regulation Rules. Qualified rules
	 * are/is checked for the rule logic
	 *
	 * @return if rule logic pass return pass else appropriate fail message
	 */

	public Optional<Integer> getRuleByRegulation(List<XMLFieldsDTO> xmlfieldsDTOList,
			Map<String, String> xmlFieldValueMap, Map<String, String> xmlLookUpFieldMap, ProcessAudit processAudit,
			List<Calculation> calcList, List<CreditDecision> creditDecisionList) throws Exception {

		logger.debug("Entered getRuleByRegulation() method of ProcessRuleServiceImpl class");

		LinkedHashSet<Rule> passedLookupset = new LinkedHashSet<>();
		HashSet<Rule> passedRuleSet = new HashSet<>();
		HashSet<Rule> failedRuleSet = new HashSet<>();
		List<Boolean> boolresultList = new ArrayList<>();
		StringBuilder failureAuditMessage = new StringBuilder();
		StringBuilder passAuditMessage = new StringBuilder();

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		LinkedHashMap<Rule, String> failRuleMessage = new LinkedHashMap<>();
		LinkedHashMap<Rule, String> passRuleMessage = new LinkedHashMap<>();

		List<StringentRuleQualification> stringentRuleList = new ArrayList<>();
		LookUpCriteriaPassRules lookUpCriteriaPassRule = new LookUpCriteriaPassRules();

		processAudit.setrValidationStart(new Timestamp(System.currentTimeMillis()));
		logger.debug("Rule Builder Rules Processing...");
		List<Rule> regulationRulelist = ruleDAO.findByRegulation();
		if (regulationRulelist.isEmpty()) {
			processAudit.setrValidationResult(norule);
			processAudit.setrValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}
		/* Get the rules which pass the Stringent lookup criteria */
		logger.debug("Invoking lookupFieldCheck for Stringent filtering of Regulation Rules...");
		Optional<LookUpCriteriaPassRules> lookUpCriteriaPassRules = lookupFieldCheck(regulationRulelist,
				xmlLookUpFieldMap);
		if (lookUpCriteriaPassRules.isPresent()) {
			lookUpCriteriaPassRule = lookUpCriteriaPassRules.get();

		}

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			processAudit.setrValidationResult(norule);
			processAudit.setrValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/*
		 * Look up fields qualified rules are sorted based on the Stringent
		 * Rules hierarchy
		 */

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() != null) {
			stringentRuleList = lookUpCriteriaPassRule.getStringentQualifyRuleList();
			stringentRuleList = stringentRuleList.stream()
					.sorted((StringentRuleQualification o1, StringentRuleQualification o2) -> {
						int min = Math.min(o1.getStringentRuleHierarchyList().size(),
								o2.getStringentRuleHierarchyList().size());
						for (int i = 0; i < min; i++) {
							int higest = o1.getStringentRuleHierarchyList().get(i)
									.compareTo(o2.getStringentRuleHierarchyList().get(i));
							if (higest != 0) {
								return higest;
							}
						}
						return Integer.compare(o2.getStringentRuleHierarchyList().size(),
								o1.getStringentRuleHierarchyList().size());
					}).collect(Collectors.toList());
			Boolean sameStringentHirearchy = false;

			for (StringentRuleQualification stringentRule : stringentRuleList.subList(1, stringentRuleList.size())) {
				if (stringentRule.getStringentRuleHierarchyList()
						.equals(stringentRuleList.get(0).getStringentRuleHierarchyList())) {
					sameStringentHirearchy = true;
					break;

				}
			}

			/*
			 * If there exists two rules with highest stringent rule priority,
			 * then sort based on the number of lookup fields matched
			 */
			if (sameStringentHirearchy) {

				stringentRuleList.sort((StringentRuleQualification s1,
						StringentRuleQualification s2) -> s2.getTotalLookUpCount() - s1.getTotalLookUpCount());
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getTotalLookUpCount() == stringentRule.getTotalLookUpCount()) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			} else if (!sameStringentHirearchy) {
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getStringentRuleHierarchyList()
							.equals(stringentRule.getStringentRuleHierarchyList())) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			}
		}
		/*
		 * if no stringent rules and only master rule exists, then master rules
		 * are qualified for the Regulation processing
		 */

		if (passedLookupset.isEmpty() && lookUpCriteriaPassRule.getMasterPassedMap() != null) {
			passedLookupset.addAll(lookUpCriteriaPassRule.getMasterPassedMap());
		}

		Boolean spotValidation = null;
		List<CreditDecision> creditList = null;
		Boolean creditDecisionOrSpotValid = validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit,
												creditDecisionList);
		if (creditDecisionOrSpotValid) {
			// Deal is valid, set spotValidation flag and creditList
			spotValidation = isSpotValidation(xmlFieldValueMap, creditDecisionList);
			creditList = getCreditList(xmlFieldValueMap, creditDecisionList);
		}
		else {
			// Deal is invalid
			return Optional.empty();
		}

		nextRule: for (Rule rule : passedLookupset) {
			HashMap<String, String> calcValues = new HashMap();
			StringBuilder calculation = new StringBuilder();
			List ruleExpressionList = new ArrayList();
			String ruleLogic = rule.getRuleLogic();
			logger.info("Rule for Rule Builder Rule Logic Proccessing...RuleID: {}, Rule Name: {}", rule.getId(), rule.getRuleName());

			ObjectMapper mapper = new ObjectMapper();

			RegulationRuleLogicExpression[] ruleExpression = mapper.readValue(ruleLogic,
					RegulationRuleLogicExpression[].class);

			for (int i = 0; i < ruleExpression.length; i++) {
				Boolean[] regulationRuleQualifier = { false };

				if (ruleExpression[i].getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
					if (ruleExpression[i].getFieldExpressionPrefix().equals("CA")) {
						String field = ruleExpression[i].getValue();
						for (int j = 0; j < calcList.size(); j++) {

							if (calcList.get(j).getCalculationName().equals(field)) {
								if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
										|| calcList.get(j).getFinanceType().isEmpty()
										|| calcList.get(j).getFinanceType() == null) {
									if (calcList.get(j).getState()
											.equals(xmlFieldValueMap.get("ContractExecutionState"))
											|| calcList.get(j).getState().isEmpty()
											|| calcList.get(j).getState() == null) {
										if (calcList.get(j).getLender().equals(xmlFieldValueMap.get("LenderPartyId"))
												|| calcList.get(j).getLender().isEmpty()
												|| calcList.get(j).getLender() == null) {
											regulationRuleQualifier[0] = true;
											try {
												String reResult = getCalculatedValue(
														calcList.get(j).getCalculationJSON(), xmlfieldsDTOList,
														xmlFieldValueMap, calcList, spotValidation, creditList);
												if (reResult.equals("Skip Rule")) {
													regulationRuleQualifier[0] = false;
													continue nextRule;
												}
												calcValues.put(calcList.get(j).getCalculationName().toString(),
														reResult);
												ruleExpressionList.add(reResult);
											} catch (IOException e) {
												logger.error(
														"Exception while Rule Builder Rule Logic Expression Proccessing, in Calculation",
														e.getMessage());
											}
										} else {
											regulationRuleQualifier[0] = false;
											continue nextRule;
										}
									} else {
										regulationRuleQualifier[0] = false;
										continue nextRule;
									}
								} else {
									regulationRuleQualifier[0] = false;
									continue nextRule;
								}
							}

						}

					}
					if (ruleExpression[i].getFieldExpressionPrefix().equals("CR")) {

						// if spot validation is sent dont run credit rules
						if (spotValidation) {
							regulationRuleQualifier[0] = false;
							continue nextRule;
						}
						if (!spotValidation) {
							CreditDecision creditDecision = creditList.get(0);
							String creditfield = ruleExpression[i].getValue();
							HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
							if (map.get(creditfield) != null) {
								ruleExpressionList.add(map.get(creditfield).toString());
							} else if (map.get(creditfield) == null) {
								regulationRuleQualifier[0] = false;
								continue nextRule;
							}

						}

					}
					if (ruleExpression[i].getFieldExpressionPrefix().equals("CO")) {

						String field = ruleExpression[i].getValue();

						for (XMLFieldsDTO xmlField : xmlfieldsDTOList) {

							if (field.equals(xmlField.getFieldName())) {
								logger.info("FieldName {} and FieldValue from XML {}", xmlField.getFieldName(), field);
								regulationRuleQualifier[0] = true;
								if (xmlField.getFieldType().equals("DATETIME")) {
									Date dateFromXML = new Date();
									try {
										dateFromXML = formatter.parse(xmlField.getFieldValue());
									} catch (ParseException e) {
										logger.error(
												"Exception while Rule Builder Rule Logic Expression Proccessing:  Wrong Date Format on XML "
														+ e.getMessage());
										throw new BadRequestException(
												"Exception while Rule Builder Rule Logic Expression Proccessing:  Wrong Date Format on XML "
														+ e.getMessage());
									}

									ruleExpressionList.add("DATETIME");
									ruleExpressionList.add(dateFromXML);

								} else if (xmlField.getFieldType().equals("NUMERIC")
										|| xmlField.getFieldType().equals("TEXT")) {
									ruleExpressionList.add(xmlField.getFieldValue());

								}
								break;

							}

						}

						if (!regulationRuleQualifier[0]) {
							continue nextRule;
						}
					}

				}

				if (ruleExpression[i].getExpressionType()
						.equals(RegulationRuleLogicExpression.ExpressionType.OPERATOR)) {
					String op = ruleExpression[i].getValue();
					if (op.equals("IFEXIST")) {
						i++;
						if (ruleExpression[i].getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
							if (ruleExpression[i].getFieldExpressionPrefix().equals("CO")) {
								String field = ruleExpression[i].getValue();
								regulationRuleQualifier[0] = true;

								if (xmlFieldValueMap.containsKey(field)) {
									if (!xmlFieldValueMap.get(field).equals("")) {
										ruleExpressionList.add(true);
									} else {
										ruleExpressionList.add(false);

									}

								} else {
									ruleExpressionList.add(false);

								}
							}

							if (ruleExpression[i].getFieldExpressionPrefix().equals("CR")) {
								regulationRuleQualifier[0] = true;
								String field = ruleExpression[i].getValue();
								if (spotValidation) {
									regulationRuleQualifier[0] = false;

									continue nextRule;
								}
								if (!spotValidation) {
									CreditDecision creditDecision = creditList.get(0);

									HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);

									if (map.get(field) != null) {
										ruleExpressionList.add(true);

									} else {
										ruleExpressionList.add(false);

									}
								}
							}

							if (ruleExpression[i].getFieldExpressionPrefix().equals("CA")) {
								regulationRuleQualifier[0] = true;
								String field = ruleExpression[i].getValue();
								for (int j = 0; j < calcList.size(); j++) {

									if (calcList.get(j).getCalculationName().equals(field)) {
										if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
												|| calcList.get(j).getFinanceType().isEmpty()
												|| calcList.get(j).getFinanceType() == null) {
											if (calcList.get(j).getState()
													.equals(xmlFieldValueMap.get("ContractExecutionState"))
													|| calcList.get(j).getState().isEmpty()
													|| calcList.get(j).getState() == null) {
												if (calcList.get(j).getLender()
														.equals(xmlFieldValueMap.get("LenderPartyId"))
														|| calcList.get(j).getLender().isEmpty()
														|| calcList.get(j).getLender() == null) {
													regulationRuleQualifier[0] = true;
													try {
														String reResult = getCalculatedValue(
																calcList.get(j).getCalculationJSON(), xmlfieldsDTOList,
																xmlFieldValueMap, calcList, spotValidation, creditList);
														if (reResult.equals("Skip Rule")) {
															regulationRuleQualifier[0] = false;
															break;
															// ruleExpressionList.add(false);
														}
														ruleExpressionList.add(true);
													} catch (IOException e) {
														logger.error(
																"Exception while Rule Builder Rule Logic Expression Proccessing, in Calculation",
																e.getMessage());
													}
												} else {
													regulationRuleQualifier[0] = false;
													break;
												}
											} else {
												regulationRuleQualifier[0] = false;
												break;
											}
										} else {
											regulationRuleQualifier[0] = false;
											break;
										}
									}

								}

							}

							if (!regulationRuleQualifier[0]) {
								ruleExpressionList.add(false);
							}

						}
					} else {
						ruleExpressionList.add(op);
					}

				}

				if (ruleExpression[i].getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.VALUE)) {
					String value = ruleExpression[i].getValue();
					ruleExpressionList.add(value);

				}

			}

			if (ruleExpressionList.contains("DATETIME")) {
				List ruleExpressionDate = new ArrayList();
				for (int i = 0; i < ruleExpressionList.size(); i++) {
					if (ruleExpressionList.get(i).equals("DATETIME")) {
						if (!String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
							if (ruleExpressionList.get(i + 2).equals("=")) {
								Date lhs = new Date();
								Date rhs = new Date();
								try {
									lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
									rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
								} catch (ParseException e) {
									throw new BadRequestException(
											"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
								}
								Boolean dateevaluation = lhs.equals(rhs);
								ruleExpressionDate.add(i, dateevaluation);
								i = i + 3;

							} else if (ruleExpressionList.get(i + 2).equals(">")) {
								Date lhs = new Date();
								Date rhs = new Date();
								try {
									lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
									rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
								} catch (ParseException e) {
									throw new BadRequestException(
											"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
								}
								Boolean dateevaluation = lhs.before(rhs);
								ruleExpressionDate.add(i, dateevaluation);
								i = i + 3;
							} else if (ruleExpressionList.get(i + 2).equals("<")) {
								Date lhs = new Date();
								Date rhs = new Date();
								try {
									lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
									rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
								} catch (ParseException e) {
									throw new BadRequestException(
											"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
								}
								Boolean dateevaluation = lhs.after(rhs);
								ruleExpressionDate.add(i, dateevaluation);
								i = i + 3;
							}
						} else if (String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
							if (ruleExpressionList.get(i + 2).equals("=")) {
								Date lhs = new Date();
								Date rhs = new Date();
								try {
									lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
									rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
								} catch (ParseException e) {
									throw new BadRequestException(
											"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
								}
								Boolean dateevaluation = lhs.equals(rhs);
								ruleExpressionDate.add(i, dateevaluation);
								i = i + 4;

							} else if (ruleExpressionList.get(i + 2).equals(">")) {
								Date lhs = new Date();
								Date rhs = new Date();
								try {
									lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
									rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
								} catch (ParseException e) {
									throw new BadRequestException(
											"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
								}
								Boolean dateevaluation = lhs.before(rhs);
								ruleExpressionDate.add(i, dateevaluation);
								i = i + 4;
							} else if (ruleExpressionList.get(i + 2).equals("<")) {
								Date lhs = new Date();
								Date rhs = new Date();
								try {
									lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
									rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
								} catch (ParseException e) {
									throw new BadRequestException(
											"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
								}
								Boolean dateevaluation = lhs.after(rhs);
								ruleExpressionDate.add(i, dateevaluation);
								i = i + 4;
							}
						}

					} else {
						ruleExpressionDate.add(ruleExpressionList.get(i));
					}
				}
				ruleExpressionList.clear();
				ruleExpressionList.addAll(ruleExpressionDate);

			}

			if (ruleExpressionList.contains("% of")) {

				ruleExpressionList = getPercentageEval(ruleExpressionList);

			}

			List<List> ruleLogicExp = new ArrayList<>();
			List<String> logicalOperatorList = new ArrayList<>();

			int j = 0;

			if (ruleExpressionList.contains("AND") || ruleExpressionList.contains("OR")) {

				for (int i = 0; i < ruleExpressionList.size(); i++) {
					if (ruleExpressionList.get(i).equals("AND") || ruleExpressionList.get(i).equals("OR")) {
						ruleLogicExp.add(ruleExpressionList.subList(j, i));

						j = i + 1;
						logicalOperatorList.add((String) ruleExpressionList.get(i));
					}
					if (i == ruleExpressionList.size() - 1) {
						ruleLogicExp.add(ruleExpressionList.subList(j, i + 1));
					}
				}

				ruleLogicExp.forEach(expression -> {

					if (expression.contains(true) || expression.contains(false)) {
						if (expression.contains(true)) {
							boolresultList.add(true);
						} else if (expression.contains(false)) {
							boolresultList.add(false);
						}
					}

					else {
						try {
							boolean result = eval(expression);
							boolresultList.add(result);
						} catch (ScriptException e) {
							logger.error("Rule Builder: Exception while Evaluation Logic " + e.getMessage());
							throw new BadRequestException(
									"Rule Builder: Exception while Evaluation Logic " + e.getMessage());
						}
					}
				});

			} else {
				boolean result = false;
				if (ruleExpressionList.get(0) instanceof Boolean) {
					if (ruleExpressionList.get(0).equals(true)) {

						result = true;
					} else if (ruleExpressionList.get(0).equals(false)) {
						result = false;
					}
				} else {
					try {
						result = eval(ruleExpressionList);
					} catch (ScriptException e) {
						logger.error("Rule Builder: Exception while Evaluation Logic " + e.getMessage());
						throw new BadRequestException(
								"Rule Builder: Exception while Evaluation Logic " + e.getMessage());
					}
				}
				if (result) {

					failedRuleSet.add(rule);
					if (rule.getFailmessage() != null) {
						String failMsg = rule.getFailmessage().getMessage();
						if (rule.getFailRuleValue() != null) {
							String[] failruleValuesArray = rule.getFailRuleValue().split(",");
							Pattern regex = Pattern.compile("\\{(RV.*?)\\}");
							Matcher regexMatcher = regex.matcher(failMsg);
							int i = 0;

							while (regexMatcher.find() && i < failruleValuesArray.length) {
								failMsg = regexMatcher.replaceFirst(failruleValuesArray[i]);
								i++;
								regexMatcher = regex.matcher(failMsg);

							}
						}
						Pattern regexCofield = Pattern.compile("\\{(Contract.*?)\\}");
						Matcher regexMatcherCofield = regexCofield.matcher(failMsg);

						while (regexMatcherCofield.find()) {

							String field = regexMatcherCofield.group(1).toString();
							String segments[] = field.split("Contract.");
							field = segments[segments.length - 1];
							String value = xmlFieldValueMap.get(field);
							failMsg = regexMatcherCofield.replaceFirst(value);
							regexMatcherCofield = regexCofield.matcher(failMsg);

						}
						Pattern regexCafield = Pattern.compile("\\{(Calculation.*?)\\}");
						Matcher regexMatcherCafield = regexCafield.matcher(failMsg);

						while (regexMatcherCafield.find()) {

							String field = regexMatcherCafield.group(1).toString();
							String segments[] = field.split("Calculation.");
							field = segments[segments.length - 1];
							String value = calcValues.get(field);
							failMsg = regexMatcherCafield.replaceFirst(value);
							regexMatcherCafield = regexCafield.matcher(failMsg);

						}
						Pattern regexCrfield = Pattern.compile("\\{(Credit.*?)\\}");
						Matcher regexMatcherCrfield = regexCrfield.matcher(failMsg);

						while (regexMatcherCrfield.find()) {

							String field = regexMatcherCrfield.group(1).toString();
							String segments[] = field.split("Credit.");
							field = segments[segments.length - 1];
							CreditDecision creditDecision = creditList.get(0);
							HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
							if (map.get(field) != null) {
								String value = map.get(field).toString();
								failMsg = regexMatcherCrfield.replaceFirst(value);
								regexMatcherCrfield = regexCrfield.matcher(failMsg);
							}

						}

						failRuleMessage.put(rule, failMsg);
					} else {
						failRuleMessage.put(rule, "NO VAL");
					}

				}
				if (!result) {

					passedRuleSet.add(rule);
					if (rule.getPassmessage() != null) {
						if (rule.getPassmessage() != null) {
							String passMsg = rule.getPassmessage().getMessage();
							if (rule.getPassRuleValue() != null) {
								String[] passruleValuesArray = rule.getPassRuleValue().split(",");
								Pattern regex = Pattern.compile("\\{(RV.*?)\\}");
								Matcher regexMatcher = regex.matcher(passMsg);
								int i = 0;

								while (regexMatcher.find() && i < passruleValuesArray.length) {
									passMsg = regexMatcher.replaceFirst(passruleValuesArray[i]);
									i++;
									regexMatcher = regex.matcher(passMsg);

								}
							}

							Pattern regexCofield = Pattern.compile("\\{(Contract.*?)\\}");
							Matcher regexMatcherCofield = regexCofield.matcher(passMsg);

							while (regexMatcherCofield.find()) {

								String field = regexMatcherCofield.group(1).toString();
								String segments[] = field.split("Contract.");
								field = segments[segments.length - 1];
								String value = xmlFieldValueMap.get(field);
								passMsg = regexMatcherCofield.replaceFirst(value);
								regexMatcherCofield = regexCofield.matcher(passMsg);

							}
							Pattern regexCafield = Pattern.compile("\\{(Calculation.*?)\\}");
							Matcher regexMatcherCafield = regexCafield.matcher(passMsg);

							while (regexMatcherCafield.find()) {

								String field = regexMatcherCafield.group(1).toString();
								String segments[] = field.split("Calculation.");
								field = segments[segments.length - 1];
								String value = calcValues.get(field);
								passMsg = regexMatcherCafield.replaceFirst(value);
								regexMatcherCafield = regexCafield.matcher(passMsg);

							}
							Pattern regexCrfield = Pattern.compile("\\{(Credit.*?)\\}");
							Matcher regexMatcherCrfield = regexCrfield.matcher(passMsg);

							while (regexMatcherCrfield.find()) {

								String field = regexMatcherCrfield.group(1).toString();
								String segments[] = field.split("Credit.");
								field = segments[segments.length - 1];
								CreditDecision creditDecision = creditList.get(0);
								HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
								if (map.get(field) != null) {
									String value = map.get(field).toString();
									passMsg = regexMatcherCrfield.replaceFirst(value);
									regexMatcherCrfield = regexCrfield.matcher(passMsg);
								}
							}

							passRuleMessage.put(rule, passMsg);
						}
					} else {
						passRuleMessage.put(rule, "NO VAL");
					}
				}

			}
			if (!boolresultList.isEmpty() && !logicalOperatorList.isEmpty()) {
				int min = Math.min(boolresultList.size(), logicalOperatorList.size());
				StringBuilder logicalResult = new StringBuilder();
				for (int i = 0; i <= min; i++) {
					if (i < min) {
						logicalResult.append(boolresultList.get(i));
						if (logicalOperatorList.get(i).equals("AND")) {
							logicalResult.append("&&");
						}
						if (logicalOperatorList.get(i).equals("OR")) {
							logicalResult.append("||");
						}

					}
					if (i == min) {
						logicalResult.append(boolresultList.get(i));
					}

				}
				ScriptEngineManager mgr = new ScriptEngineManager();
				ScriptEngine engine = mgr.getEngineByName("nashorn");

				Object result = new Object();

				try {
					result = engine.eval(logicalResult.toString());
				} catch (ScriptException e) {
					logger.error("Rule Builder: Exception while Evaluation Logic " + e.getMessage());
					throw new BadRequestException("Rule Builder: Exception while Evaluation Logic " + e.getMessage());

				}

				if (result instanceof Boolean) {
					if (result.equals(true)) {
						failedRuleSet.add(rule);
						if (rule.getFailmessage() != null) {
							String failMsg = rule.getFailmessage().getMessage();
							if (rule.getFailRuleValue() != null) {
								String[] failruleValuesArray = rule.getFailRuleValue().split(",");
								Pattern regex = Pattern.compile("\\{(RV.*?)\\}");
								Matcher regexMatcher = regex.matcher(failMsg);
								int i = 0;

								while (regexMatcher.find() && i < failruleValuesArray.length) {
									failMsg = regexMatcher.replaceFirst(failruleValuesArray[i]);
									i++;
									regexMatcher = regex.matcher(failMsg);

								}
							}
							Pattern regexCofield = Pattern.compile("\\{(Contract.*?)\\}");
							Matcher regexMatcherCofield = regexCofield.matcher(failMsg);

							while (regexMatcherCofield.find()) {

								String field = regexMatcherCofield.group(1).toString();
								String segments[] = field.split("Contract.");
								field = segments[segments.length - 1];
								String value = xmlFieldValueMap.get(field);
								failMsg = regexMatcherCofield.replaceFirst(value);
								regexMatcherCofield = regexCofield.matcher(failMsg);

							}
							Pattern regexCafield = Pattern.compile("\\{(Calculation.*?)\\}");
							Matcher regexMatcherCafield = regexCafield.matcher(failMsg);

							while (regexMatcherCafield.find()) {

								String field = regexMatcherCafield.group(1).toString();
								String segments[] = field.split("Calculation.");
								field = segments[segments.length - 1];
								String value = calcValues.get(field);
								failMsg = regexMatcherCafield.replaceFirst(value);
								regexMatcherCafield = regexCafield.matcher(failMsg);

							}
							Pattern regexCrfield = Pattern.compile("\\{(Credit.*?)\\}");
							Matcher regexMatcherCrfield = regexCrfield.matcher(failMsg);

							while (regexMatcherCrfield.find()) {

								String field = regexMatcherCrfield.group(1).toString();
								String segments[] = field.split("Credit.");
								field = segments[segments.length - 1];
								CreditDecision creditDecision = creditList.get(0);
								HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
								if (map.get(field) != null) {
									String value = map.get(field).toString();
									failMsg = regexMatcherCrfield.replaceFirst(value);
									regexMatcherCrfield = regexCrfield.matcher(failMsg);
								}
							}

							failRuleMessage.put(rule, failMsg);
						} else {
							failRuleMessage.put(rule, "NO VAL");
						}
					}
					if (result.equals(false)) {
						passedRuleSet.add(rule);
						if (rule.getPassmessage() != null) {
							if (rule.getPassmessage() != null) {
								String passMsg = rule.getPassmessage().getMessage();
								if (rule.getPassRuleValue() != null) {
									String[] passruleValuesArray = rule.getPassRuleValue().split(",");
									Pattern regex = Pattern.compile("\\{(RV.*?)\\}");
									Matcher regexMatcher = regex.matcher(passMsg);
									int i = 0;

									while (regexMatcher.find() && i < passruleValuesArray.length) {
										passMsg = regexMatcher.replaceFirst(passruleValuesArray[i]);
										i++;
										regexMatcher = regex.matcher(passMsg);

									}
								}
								Pattern regexCofield = Pattern.compile("\\{(Contract.*?)\\}");
								Matcher regexMatcherCofield = regexCofield.matcher(passMsg);

								while (regexMatcherCofield.find()) {

									String field = regexMatcherCofield.group(1).toString();
									String segments[] = field.split("Contract.");
									field = segments[segments.length - 1];
									String value = xmlFieldValueMap.get(field);
									passMsg = regexMatcherCofield.replaceFirst(value);
									regexMatcherCofield = regexCofield.matcher(passMsg);

								}
								Pattern regexCafield = Pattern.compile("\\{(Calculation.*?)\\}");
								Matcher regexMatcherCafield = regexCafield.matcher(passMsg);

								while (regexMatcherCafield.find()) {

									String field = regexMatcherCafield.group(1).toString();
									String segments[] = field.split("Calculation.");
									field = segments[segments.length - 1];
									String value = calcValues.get(field);
									passMsg = regexMatcherCafield.replaceFirst(value);
									regexMatcherCafield = regexCafield.matcher(passMsg);

								}
								Pattern regexCrfield = Pattern.compile("\\{(Credit.*?)\\}");
								Matcher regexMatcherCrfield = regexCrfield.matcher(passMsg);
								while (regexMatcherCrfield.find()) {

									String field = regexMatcherCrfield.group(1).toString();
									String segments[] = field.split("Credit.");
									field = segments[segments.length - 1];
									CreditDecision creditDecision = creditList.get(0);
									HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
									if (map.get(field) != null) {
										String value = map.get(field).toString();
										passMsg = regexMatcherCrfield.replaceFirst(value);
										regexMatcherCrfield = regexCrfield.matcher(passMsg);
									}
								}

								passRuleMessage.put(rule, passMsg);
							}
						} else {
							passRuleMessage.put(rule, "NO VAL");
						}
					}
				}
			}
		}

		if (failRuleMessage.size() > 1) {
			int failCount = 0;

			for (Entry<Rule, String> rulemsgpair : failRuleMessage.entrySet()) {

				RuleAudit ruleAudit = new RuleAudit();
				logger.info("Failed Regulation Rule {}", rulemsgpair.getKey());

				ruleAudit.setRuleExecutionResult(fail);
				ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
				ruleAudit.setXmlId(processAudit.getXmlId());
				ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
				ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
				ruleAudit.setMessageResponse(rulemsgpair.getValue());
				ruleAudit.setRule(rulemsgpair.getKey());
				if (rulemsgpair.getValue().equals("NO VAL")) {
					ruleAuditService.saveRuleAudit(ruleAudit);
					failCount++;
					continue;
				}
				failureAuditMessage.append(rulemsgpair.getValue());
				failureAuditMessage.append("  +  ");
				ruleAuditService.saveRuleAudit(ruleAudit);

			}
			if (failCount == failRuleMessage.size()) {
				failureAuditMessage.append("");
				failureAuditMessage.append("  +  ");
			}

		} else if (failRuleMessage.size() == 1) {
			for (Entry<Rule, String> rulemsgpair : failRuleMessage.entrySet()) {
				String val = "";
				RuleAudit ruleAudit = new RuleAudit();
				logger.info("Failed Regulation Rule {}", rulemsgpair.getKey());

				ruleAudit.setRuleExecutionResult(fail);
				ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
				ruleAudit.setXmlId(processAudit.getXmlId());
				ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
				ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
				ruleAudit.setMessageResponse(rulemsgpair.getValue());
				ruleAudit.setRule(rulemsgpair.getKey());
				val = rulemsgpair.getValue();
				if (rulemsgpair.getValue().equals("NO VAL")) {
					val = val.replace("NO VAL", "");
				}
				failureAuditMessage.append(val);
				failureAuditMessage.append("  +  ");

				ruleAuditService.saveRuleAudit(ruleAudit);
			}
		}

		if (passRuleMessage.size() > 1) {
			int passCount = 0;
			for (Entry<Rule, String> rulemsgpair : passRuleMessage.entrySet()) {
				RuleAudit ruleAudit = new RuleAudit();
				logger.info("Passed Regulation Rule {}", rulemsgpair.getKey());
				ruleAudit.setRuleExecutionResult(pass);
				ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
				ruleAudit.setXmlId(processAudit.getXmlId());
				ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
				ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
				ruleAudit.setRule(rulemsgpair.getKey());
				ruleAudit.setMessageResponse(rulemsgpair.getValue());
				if (rulemsgpair.getValue().equals("NO VAL")) {
					ruleAuditService.saveRuleAudit(ruleAudit);
					passCount++;
					continue;
				}
				passAuditMessage.append(rulemsgpair.getValue());
				passAuditMessage.append("  +  ");
				ruleAuditService.saveRuleAudit(ruleAudit);

			}
			if (passCount == passRuleMessage.size()) {
				passAuditMessage.append("");
				passAuditMessage.append("  +  ");
			}
		} else if (passRuleMessage.size() == 1) {
			for (Entry<Rule, String> rulemsgpair : passRuleMessage.entrySet()) {
				String val = "";
				RuleAudit ruleAudit = new RuleAudit();
				logger.info("Passed Regulation Rule {}", rulemsgpair.getKey());
				ruleAudit.setRuleExecutionResult(pass);
				ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
				ruleAudit.setXmlId(processAudit.getXmlId());
				ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
				ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
				ruleAudit.setRule(rulemsgpair.getKey());
				val = rulemsgpair.getValue();
				if (rulemsgpair.getValue().equals("NO VAL")) {
					val = val.replace("NO VAL", "");
				}
				ruleAudit.setMessageResponse(val);
				passAuditMessage.append(val);
				passAuditMessage.append("  +  ");
				ruleAuditService.saveRuleAudit(ruleAudit);

			}
		}

		processAudit.setrValidationEnd(new Timestamp(System.currentTimeMillis()));

		if (passedRuleSet.isEmpty() && !failedRuleSet.isEmpty()) {
			processAudit.setrValidationResult(passmessage + " || " + failmessage + " "
					+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
		} else if (!passedRuleSet.isEmpty() && !failedRuleSet.isEmpty()) {
			if (!passAuditMessage.toString().isEmpty()) {
				processAudit.setrValidationResult(passmessage + " "
						+ passAuditMessage.toString().substring(0, passAuditMessage.toString().length() - 3) + " || "
						+ failmessage + " "
						+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
			} else if (passAuditMessage.toString().isEmpty()) {
				processAudit.setrValidationResult(passmessage + " " + " || " + failmessage + " "
						+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
			}
		} else if (failedRuleSet.isEmpty() && !passedRuleSet.isEmpty()) {
			if (!passAuditMessage.toString().isEmpty()) {
				processAudit.setrValidationResult(passmessage + " "
						+ passAuditMessage.toString().substring(0, passAuditMessage.toString().length() - 3) + auditPass
						+ " || " + failmessage + " ");
			} else if (passAuditMessage.toString().isEmpty()) {
				processAudit.setrValidationResult(passmessage + " " + auditPass + " || " + failmessage + " ");
			}
		}
		if (failedRuleSet.isEmpty() && passedRuleSet.isEmpty()) {
			processAudit.setrValidationResult(norule);
		}
		logger.debug("Exit getRuleByRegulation() method of ProcessRuleServiceImpl class");
		return Optional.empty();
	}

	/**
	 * @param creditDecision
	 * @return
	 */
	private HashMap<String, Object> getCreditDecisionMapping(CreditDecision creditDecision) {

		HashMap<String, Object> map = new HashMap();
		map.put("DmsDealerId", creditDecision.getDmsDealerId());
		map.put("LenderDealerId", creditDecision.getLenderDealerId());
		map.put("DmsDealNum", creditDecision.getDmsDealNum());
		map.put("LenderId", creditDecision.getLenderDealerId());
		map.put("DeDealId", creditDecision.getDeDealId());
		map.put("SequenceId", creditDecision.getSequenceId());
		map.put("R1lenderId", creditDecision.getR1lenderId());
		map.put("ConversationId", creditDecision.getConversationId());
		map.put("R1SequenceNum", creditDecision.getR1SequenceNum());
		map.put("VIN", creditDecision.getVIN());
		map.put("BuyerSSN", creditDecision.getBuyerSSN());
		map.put("BuyerFirstName", creditDecision.getBuyerFirstName());
		map.put("BuyerLastName", creditDecision.getBuyerLastName());
		map.put("BuyerApplicationAddressLine", creditDecision.getBuyerApplicationAddressLine());
		map.put("BuyerApplicationAddressCity", creditDecision.getBuyerApplicationAddressCity());
		map.put("BuyerApplicationAddressState", creditDecision.getBuyerApplicationAddressState());
		map.put("BuyerApplicationAddressZipCode", creditDecision.getBuyerApplicationAddressZipCode());
		map.put("CoBuyerSSN", creditDecision.getCoBuyerSSN());
		map.put("CobuyerFirstName", creditDecision.getCobuyerFirstName());
		map.put("CobuyerLastName", creditDecision.getCobuyerLastName());
		map.put("CobuyerApplicationAddressLine", creditDecision.getCobuyerApplicationAddressLine());
		map.put("CobuyerApplicationAddressCity", creditDecision.getCobuyerApplicationAddressCity());
		map.put("CobuyerApplicationAddressState", creditDecision.getCobuyerApplicationAddressState());
		map.put("CobuyerApplicationAddressZipcode", creditDecision.getCobuyerApplicationAddressZipcode());
		map.put("ApplicationStatus", creditDecision.getApplicationStatus());
		map.put("ApplicationNumber", creditDecision.getApplicationNumber());
		map.put("Model", creditDecision.getModel());
		map.put("ModelYear", creditDecision.getModelYear());
		map.put("AmountFinanced", creditDecision.getAmountFinanced());
		map.put("LTV", creditDecision.getLTV());
		map.put("ApplicationType", creditDecision.getApplicationType());
		map.put("ModelDescription", creditDecision.getModelDescription());
		map.put("Make", creditDecision.getMake());
		map.put("SalesClass", creditDecision.getSalesClass());
		map.put("CertifiedPreOwned", creditDecision.isCertifiedPreOwned());
		map.put("DeliveryMileage", creditDecision.getDeliveryMileage());
		map.put("VehicleStock", creditDecision.getVehicleStock());
		map.put("BodyStyle", creditDecision.getBodyStyle());
		map.put("FinanceType", creditDecision.getFinanceType());
		map.put("PaymentAmount", creditDecision.getPaymentAmount());
		map.put("BalanceAmount", creditDecision.getBalanceAmount());
		map.put("ResidualAmount", creditDecision.getResidualAmount());
		map.put("PurchasePrice", creditDecision.getPurchasePrice());
		map.put("Term", creditDecision.getTerm());
		map.put("DownpaymentAmount", creditDecision.getDownpaymentAmount());
		map.put("ManufacturerRebateAmount", creditDecision.getManufacturerRebateAmount());
		map.put("AnnualPercentageRate", creditDecision.getAnnualPercentageRate());
		map.put("NetTradeAmount", creditDecision.getNetTradeAmount());
		map.put("InsuranceTotalExtendedWarrantyAmount", creditDecision.getInsuranceTotalExtendedWarrantyAmount());
		map.put("DisabilityPremiumAmount", creditDecision.getDisabilityPremiumAmount());
		map.put("CreditLifePremiumAmount", creditDecision.getCreditLifePremiumAmount());
		map.put("SecurityDepositAmount", creditDecision.getSecurityDepositAmount());
		map.put("Tier", creditDecision.getTier());
		map.put("Stipulations", creditDecision.getStipulations());

		return map;
	}

	/**
	 * @param ruleExpressionList
	 * @return
	 */
	private List getPercentageEval(List ruleExpressionList) {
		List ruleExpressionCalcPercent = new ArrayList();
		List ruleCalcPercent = new ArrayList();

		for (int i = 0; i < ruleExpressionList.size(); i++) {
			if (ruleExpressionList.get(i).equals("% of")) {
				ruleExpressionCalcPercent.add(ruleExpressionList.get(i));
				int indexofPercentOf = i;
				HashMap<String, Integer> openClosePair = new HashMap<>();
				openClosePair.put("(", 0);
				openClosePair.put(")", 0);

				for (int j = indexofPercentOf + 1; j < ruleExpressionList.size();) {
					if (ruleExpressionList.get(j).equals("(")) {
						openClosePair.put("(", openClosePair.get("(") + 1);
					}

					if (ruleExpressionList.get(j).equals(")")) {
						openClosePair.put(")", openClosePair.get(")") + 1);

					}
					int value = openClosePair.get("(") - openClosePair.get(")");
					if (value != 0) {
						j++;
					}
					if (value == 0) {
						List percentageOfExprn = new ArrayList<>();
						percentageOfExprn.addAll(ruleExpressionList.subList(indexofPercentOf + 2, j));
						ruleExpressionCalcPercent.add(evaluateOfExprn(percentageOfExprn));
						i = j;
						break;
					}

				}
			} else {

				ruleExpressionCalcPercent.add(ruleExpressionList.get(i));

			}
		}

		for (int i = 0; i < ruleExpressionCalcPercent.size(); i++) {
			if (ruleExpressionCalcPercent.get(i).equals("% of")) {

				Double a = calculatePercentage(Double.parseDouble(ruleExpressionCalcPercent.get(i - 1).toString()),
						Double.parseDouble(ruleExpressionCalcPercent.get(i + 1).toString()));

				ruleCalcPercent.add(a.toString());
				i++;
			} else {
				if (i == ruleExpressionCalcPercent.size() - 1) {
					ruleCalcPercent.add(ruleExpressionCalcPercent.get(i));
					break;
				}

				if (!ruleExpressionCalcPercent.get(i + 1).equals("% of")) {
					ruleCalcPercent.add(ruleExpressionCalcPercent.get(i));

				}
			}

		}

		return ruleCalcPercent;
	}

	/**
	 * @param calculationJSON
	 * @param xmlfieldsDTOList
	 * @param xmlFieldValueMap
	 * @param calcList
	 * @param spotValidation
	 * @param creditList
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private String getCalculatedValue(String calculationJSON, List<XMLFieldsDTO> xmlfieldsDTOList,
			Map<String, String> xmlFieldValueMap, List<Calculation> calcList, Boolean spotValidation,
			List<CreditDecision> creditList) throws JsonParseException, JsonMappingException, IOException {
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List ruleExpressionList = new ArrayList();
		ScriptEngineManager mgr = new ScriptEngineManager();

		ScriptEngine engine = mgr.getEngineByName("nashorn");
		String ruleLogic = calculationJSON;
		StringBuilder calculation = new StringBuilder();
		logger.info("Rule for Rule Builder Rule Logic Proccessing...{}", ruleLogic);

		ObjectMapper mapper = new ObjectMapper();

		RegulationRuleLogicExpression[] ruleExpression = mapper.readValue(ruleLogic,
				RegulationRuleLogicExpression[].class);

		for (RegulationRuleLogicExpression element : ruleExpression) {
			Boolean[] regulationRuleQualifier = { false };

			if (element.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
				if (element.getFieldExpressionPrefix().equals("CA")) {
					regulationRuleQualifier[0] = true;
					String field = element.getValue();
					for (int j = 0; j < calcList.size(); j++) {

						if (calcList.get(j).getCalculationName().equals(field)) {
							if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
									|| calcList.get(j).getFinanceType().isEmpty()
									|| calcList.get(j).getFinanceType() == null) {
								if (calcList.get(j).getState().equals(xmlFieldValueMap.get("ContractExecutionState"))
										|| calcList.get(j).getState().isEmpty()
										|| calcList.get(j).getState() == null) {
									if (calcList.get(j).getLender().equals(xmlFieldValueMap.get("LenderPartyId"))
											|| calcList.get(j).getLender().isEmpty()
											|| calcList.get(j).getLender() == null) {
										regulationRuleQualifier[0] = true;
										try {
											String reResult = getCalculatedValue(calcList.get(j).getCalculationJSON(),
													xmlfieldsDTOList, xmlFieldValueMap, calcList, spotValidation,
													creditList);
											if (reResult.equals("Skip Rule")) {
												regulationRuleQualifier[0] = false;
												break;
											}

											ruleExpressionList.add(reResult);

										} catch (IOException e) {
											logger.error(
													"Exception while Rule Builder Rule Logic Expression Proccessing, in Calculation",
													e.getMessage());
										}
									} else {
										regulationRuleQualifier[0] = false;
										break;
									}
								} else {
									regulationRuleQualifier[0] = false;
									break;
								}
							} else {
								regulationRuleQualifier[0] = false;
								break;
							}
						}

					}

				}
				if (element.getFieldExpressionPrefix().equals("CR")) {
					regulationRuleQualifier[0] = true;
					if (spotValidation) {
						regulationRuleQualifier[0] = false;
						return "Skip Rule";
					}
					if (!spotValidation) {
						CreditDecision creditDecision = creditList.get(0);
						String creditfield = element.getValue();
						HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);

						if (map.get(creditfield) == null) {
							regulationRuleQualifier[0] = false;
							return "Skip Rule";
						} else if (map.get(creditfield) != null) {
							ruleExpressionList.add(map.get(creditfield).toString());
						}
					}

				}
				if (element.getFieldExpressionPrefix().equals("CO")) {

					String field = element.getValue();

					for (XMLFieldsDTO xmlField : xmlfieldsDTOList) {

						if (field.equals(xmlField.getFieldName())) {
							logger.info("FieldName {} and FieldValue from XML {}", xmlField.getFieldName(), field);
							regulationRuleQualifier[0] = true;
							if (xmlField.getFieldType().equals("DATETIME")) {
								Date dateFromXML = new Date();
								try {
									dateFromXML = formatter.parse(xmlField.getFieldValue());
								} catch (ParseException e) {
									logger.error(
											"Exception while Rule Builder Rule Logic Expression Proccessing:  Wrong Date Format on XML "
													+ e.getMessage());
									throw new BadRequestException(
											"Exception while Rule Builder Rule Logic Expression Proccessing:  Wrong Date Format on XML "
													+ e.getMessage());
								}

								ruleExpressionList.add("DATETIME");
								ruleExpressionList.add(dateFromXML);

							} else if (xmlField.getFieldType().equals("NUMERIC")
									|| xmlField.getFieldType().equals("TEXT")) {
								ruleExpressionList.add(xmlField.getFieldValue());

							}
							break;

						}

					}

				}
				if (!regulationRuleQualifier[0]) {
					return "Skip Rule";
				}
			}

			if (element.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.OPERATOR)) {
				String op = element.getValue();
				ruleExpressionList.add(op);

			}

			if (element.getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.VALUE)) {
				String value = element.getValue();
				ruleExpressionList.add(value);

			}

		}

		if (ruleExpressionList.contains("DATETIME")) {
			List ruleExpressionDate = new ArrayList();
			for (int i = 0; i < ruleExpressionList.size(); i++) {
				if (ruleExpressionList.get(i).equals("DATETIME")) {
					if (!String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
						if (ruleExpressionList.get(i + 2).equals("=")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException(
										"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.equals(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 3;

						} else if (ruleExpressionList.get(i + 2).equals(">")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException(
										"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.before(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 3;
						} else if (ruleExpressionList.get(i + 2).equals("<")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException(
										"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.after(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 3;
						}
					} else if (String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
						if (ruleExpressionList.get(i + 2).equals("=")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException(
										"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.equals(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 4;

						} else if (ruleExpressionList.get(i + 2).equals(">")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException(
										"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.before(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 4;
						} else if (ruleExpressionList.get(i + 2).equals("<")) {
							Date lhs = new Date();
							Date rhs = new Date();
							try {
								lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
								rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
							} catch (ParseException e) {
								throw new BadRequestException(
										"Rule Builder : Wrong Date Format on Rule " + e.getMessage());
							}
							Boolean dateevaluation = lhs.after(rhs);
							ruleExpressionDate.add(i, dateevaluation);
							i = i + 4;
						}
					}

				} else {
					ruleExpressionDate.add(ruleExpressionList.get(i));
				}
			}
			ruleExpressionList.clear();
			ruleExpressionList.addAll(ruleExpressionDate);

		}

		if (ruleExpressionList.contains("% of")) {
			ruleExpressionList = getPercentageEval(ruleExpressionList);
			/*
			 * List ruleExpressionCalcPercent = new ArrayList(); for (int i = 0;
			 * i < ruleExpressionList.size(); i++) { if
			 * (ruleExpressionList.get(i).equals("% of")) {
			 *
			 * Double a =
			 * calculatePercentage(Double.parseDouble(ruleExpressionList.get(i -
			 * 1).toString()), Double.parseDouble(ruleExpressionList.get(i +
			 * 1).toString()));
			 *
			 * ruleExpressionCalcPercent.set(i - 1, a.toString()); i++; } else {
			 * ruleExpressionCalcPercent.add(ruleExpressionList.get(i)); }
			 *
			 * } ruleExpressionList.clear();
			 * ruleExpressionList.addAll(ruleExpressionCalcPercent);
			 */
		}
		String result = new String();
		String listString = String.join("", ruleExpressionList);
		try {
			result = engine.eval(listString).toString();
		} catch (ScriptException e) {
			logger.info("Error Evaluating Final ExpressionList", e.getMessage());
		}
		return result;
	}

	/**
	 * @param expression
	 * @return
	 * @throws ScriptException
	 */
	private boolean eval(List expression) throws ScriptException {
		String leftString = "";
		String rightString = "";
		String operator = "";

		String leftObj = "";
		String rightObj = "";

		StringBuilder sbLeft = new StringBuilder();
		StringBuilder sbRight = new StringBuilder();

		List<List> leftexpressionlists = new ArrayList();
		List<String> lhs = new ArrayList();
		List<List> rightexpressionlists = new ArrayList();
		List<String> rhs = new ArrayList();

		List<String> relationalOperatorList = new ArrayList();
		int j = 0;

		for (int i = 0; i < expression.size(); i++) {
			if (expression.get(i).equals("=") || expression.get(i).equals("<") || expression.get(i).equals(">")
					|| expression.get(i).equals("<=") || expression.get(i).equals(">=")
					|| expression.get(i).equals("!=")) {
				leftexpressionlists.add(expression.subList(j, i));
				leftexpressionlists.forEach(lhs::addAll);

				rightexpressionlists.add(expression.subList(i + 1, expression.size()));
				rightexpressionlists.forEach(rhs::addAll);

				j = i + 1;
				relationalOperatorList.add((String) expression.get(i));
			}
		}

		if (lhs.contains("=") || lhs.contains(">") || lhs.contains("<") || lhs.contains("<=")
				|| lhs.contains(">=") || lhs.contains("!=")) {

			eval(lhs);
		}

		if (rhs.contains("=") || lhs.contains(">") || rhs.contains("<") || rhs.contains("<=") || rhs.contains(">=")
				|| rhs.contains("!=")) {

			eval(rhs);
		}

		Boolean rhsString = false;
		Boolean lhsObj = false;
		Boolean lhsString = false;
		Boolean rhsObj = false;

		if (lhs.contains("+") || lhs.contains("-") || lhs.contains("*") || lhs.contains("/")) {
			StringBuilder sb = new StringBuilder();

			HashMap<String, Integer> openClosePair = new HashMap<>();
			openClosePair.put("(", 0);
			openClosePair.put(")", 0);
			if (lhs.contains("(")) {
				lhs.forEach(val -> {
					if (openClosePair.containsKey(val)) {
						openClosePair.put(val, openClosePair.get(val) + 1);
					}

					sb.append(val);
				});

				int value = openClosePair.get("(") - openClosePair.get(")");
				if (value > 0) {
					for (int i = 0; i < value; i++) {
						sb.append(")");
					}
				}
			} else if (!lhs.contains("(")) {
				lhs.forEach(val -> {

					sb.append(val);
				});
			}
			ScriptEngineManager mgr = new ScriptEngineManager();
			ScriptEngine engine = mgr.getEngineByName("nashorn");
			//Double val = new BigDecimal(engine.eval(sb.toString()).toString()).doubleValue();
			String val = engine.eval(sb.toString()).toString();
			val = NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val);
			sbLeft.append(val);
			leftObj = sbLeft.toString();
			lhsObj = true;
		} else {

			HashMap<String, Integer> openClosePair = new HashMap<>();
			openClosePair.put("(", 0);
			openClosePair.put(")", 0);

			StringBuilder sb = new StringBuilder();
			if (lhs.contains("(")) {
				lhs.forEach(val -> {
					if (openClosePair.containsKey(val)) {
						openClosePair.put(val, openClosePair.get(val) + 1);
					}

					sb.append(val);
				});

				int value = openClosePair.get("(") - openClosePair.get(")");

				if (value > 0) {
					for (int i = 0; i < value; i++) {
						sb.append(")");
					}
				}

			} else if (!lhs.contains("(")) {
				lhs.forEach(val -> {

					sb.append(val);
				});
			}
			leftString = sb.toString();
			lhsString = true;

		}

		if (rhs.contains("+") || rhs.contains("-") || rhs.contains("*") || rhs.contains("/")) {

			HashMap<String, Integer> openClosePair = new HashMap<>();
			openClosePair.put("(", 0);
			openClosePair.put(")", 0);
			StringBuilder sb = new StringBuilder();
			if (rhs.contains(")")) {
				rhs.forEach(val -> {
					if (openClosePair.containsKey(val)) {
						openClosePair.put(val, openClosePair.get(val) + 1);
					}

					sb.append(val);
				});

				int value = openClosePair.get(")") - openClosePair.get("(");
				if (value > 0) {
					for (int i = 0; i < value; i++) {
						sb.insert(0, "(");
					}
				}
			} else if (!rhs.contains(")")) {
				rhs.forEach(val -> {

					sb.append(val);
				});
			}
			ScriptEngineManager mgr = new ScriptEngineManager();
			ScriptEngine engine = mgr.getEngineByName("nashorn");
			rhsObj = true;
			String val = engine.eval(sb.toString()).toString();
			val = NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val);
			sbRight.append(val);
			rightObj = sbRight.toString();

		} else {

			HashMap<String, Integer> openClosePair = new HashMap<>();
			openClosePair.put("(", 0);
			openClosePair.put(")", 0);
			{
				StringBuilder sb = new StringBuilder();
				if (rhs.contains(")")) {
					rhs.forEach(val -> {
						if (openClosePair.containsKey(val)) {
							openClosePair.put(val, openClosePair.get(val) + 1);
						}

						sb.append(val);
					});

					int value = openClosePair.get(")") - openClosePair.get("(");
					if (value > 0) {
						for (int i = 0; i < value; i++) {
							sb.insert(0, "(");
						}
					}
				} else if (!rhs.contains(")")) {
					rhs.forEach(val -> {

						sb.append(val);
					});
				}
				rightString = sb.toString();
				rhsString = true;
			}
		}

		if (relationalOperatorList.size() == 1) {
			StringBuilder sb = new StringBuilder();
			relationalOperatorList.forEach(val -> {
				if (val.equals("=")) {
					sb.append("=");
				}

				sb.append(val);

			});

			operator = sb.toString();
		}
		boolean val = false;
		if (lhsString && rhsString) {

			val = expressioneval(leftString, rightString, operator);

		}
		if (lhsObj && rhsString) {

			val = expressioneval(leftObj, rightString, operator);
		}
		if (lhsString && rhsObj) {

			val = expressioneval(leftString, rightObj, operator);
		}
		if (lhsObj && rhsObj) {

			val = expressioneval(leftObj, rightObj, operator);
		}

		return val;
	}

	/**
	 * @param lhs
	 * @param rhs
	 * @param relationOperator
	 * @return
	 * @throws ScriptException
	 */
	public boolean expressioneval(String lhs, String rhs, String relationOperator) throws ScriptException {
		StringBuilder sb = new StringBuilder();
		StringBuilder sbfield = new StringBuilder();

		String rhsfield = "";
		String lhsfield = "";

		lhsfield = String.valueOf(lhs);
		rhsfield = String.valueOf(rhs);

		boolean isNumericlhs = lhsfield.chars().allMatch(Character::isDigit);
		boolean isNumericrhs = rhsfield.chars().allMatch(Character::isDigit);

		if (isNumericlhs || isNumericrhs) {

			sb.append(lhsfield);
			sb.append(relationOperator);
			sb.append(rhsfield);

			ScriptEngineManager mgr = new ScriptEngineManager();
			ScriptEngine engine = mgr.getEngineByName("nashorn");

			Object result = engine.eval(sb.toString());
			logger.info("Expression evalualted : {}", sb.toString());
			logger.info("Expression evalualted result: {}", result);
			if (result instanceof Boolean) {
				if (result.equals(true)) {
					return true;
				}
			}

		} else {

			if (relationOperator.equals("==")) {
				if (lhsfield.equals(rhsfield)) {
					return true;
				} else {
					return false;
				}

			}
			if (relationOperator.equals("!=")) {
				if (lhsfield.equals(rhsfield)) {
					return false;
				} else {
					return true;
				}

			}
		}

		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("nashorn");
		sbfield.append(lhsfield);
		sbfield.append(relationOperator);
		sbfield.append(rhsfield);

		Object result = engine.eval(sbfield.toString());
		logger.info("Expression evalualted : {}", sbfield.toString());
		logger.info("Expression evalualted result: {} ", result);
		if (result instanceof Boolean) {
			if (result.equals(true)) {
				return true;
			}
		}

		return false;

	}

	/**
	 * @param xmlfieldsDTOList
	 * @param xmlFieldsList
	 * @param xmlLookUpFieldMap
	 * @param xmlFieldValueMap
	 * @param processAudit
	 * @param calcList
	 * @return
	 * @throws Exception
	 */
	public Optional<RFLRuleResponse> getRuleByRFL(List<XMLFieldsDTO> xmlfieldsDTOList, List<String> xmlFieldsList,
			Map<String, String> xmlLookUpFieldMap, Map<String, String> xmlFieldValueMap, ProcessAudit processAudit,
			List<Calculation> calcList, List<CreditDecision> creditDecisionList) throws Exception {
		logger.info("Entered getRuleByRFL() method of ProcessRuleServiceImpl class.");
		LinkedHashSet<Rule> passedLookupset = new LinkedHashSet<>();
		List<Boolean> boolresultList = new ArrayList<>();
		StringBuilder failureAuditMessage = new StringBuilder();
		HashSet<Rule> passedRuleSet = new HashSet<>();
		StringBuilder passAuditMessage = new StringBuilder();
		HashMap<Rule, String> passRuleMessage = new HashMap<>();
		HashSet<Rule> passeddRuleSet = new HashSet<>();
		HashSet<Rule> failedRuleSet = new HashSet<>();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List<StringentRuleQualification> stringentRuleList = new ArrayList<>();

		LookUpCriteriaPassRules lookUpCriteriaPassRule = new LookUpCriteriaPassRules();


		processAudit.setRflValidationStart(new Timestamp(System.currentTimeMillis()));
		logger.info("RFL Rules Processing ...");
		List<Rule> rflRulelist = ruleDAO.findByRFL();

		if (rflRulelist.isEmpty()) {
			processAudit.setRflValidationResult("");
			processAudit.setRflValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}
		/* Get the rules which pass the Stringent lookup criteria */
		logger.info("Invoking lookupFieldCheck for Stringent filtering of RFL Rules...");
		Optional<LookUpCriteriaPassRules> lookUpCriteriaPassRules = lookupFieldCheck(rflRulelist, xmlLookUpFieldMap);
		if (lookUpCriteriaPassRules.isPresent()) {
			logger.debug("lookupFieldCheck() returned LookUpCriteriaPassRules");
			lookUpCriteriaPassRule = lookUpCriteriaPassRules.get();

		}
		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			logger.debug("lookUpCriteriaPassRule is empty. Exiting getRuleByRFL() method.");
			processAudit.setRflValidationResult("");
			processAudit.setRflValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/*
		 * Look up fields qualified rules are sorted based on the Stringent
		 * Rules hierarchy
		 */
		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() != null) {
			stringentRuleList = lookUpCriteriaPassRule.getStringentQualifyRuleList();
			stringentRuleList = stringentRuleList.stream()
					.sorted((StringentRuleQualification o1, StringentRuleQualification o2) -> {
						int min = Math.min(o1.getStringentRuleHierarchyList().size(),
								o2.getStringentRuleHierarchyList().size());
						for (int i = 0; i < min; i++) {
							int higest = o1.getStringentRuleHierarchyList().get(i)
									.compareTo(o2.getStringentRuleHierarchyList().get(i));
							if (higest != 0) {
								return higest;
							}
						}
						return Integer.compare(o2.getStringentRuleHierarchyList().size(),
								o1.getStringentRuleHierarchyList().size());
					}).collect(Collectors.toList());
			Boolean sameStringentHirearchy = false;

			for (StringentRuleQualification stringentRule : stringentRuleList.subList(1, stringentRuleList.size())) {
				if (stringentRule.getStringentRuleHierarchyList()
						.equals(stringentRuleList.get(0).getStringentRuleHierarchyList())) {
					sameStringentHirearchy = true;
					break;

				}
			}
			/*
			 * If there exists two rules with highest stringent rule priority,
			 * then sort based on the number of lookup fields matched
			 */
			if (sameStringentHirearchy) {

				stringentRuleList.sort((StringentRuleQualification s1,
						StringentRuleQualification s2) -> s2.getTotalLookUpCount() - s1.getTotalLookUpCount());
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getTotalLookUpCount() == stringentRule.getTotalLookUpCount()) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			} else if (!sameStringentHirearchy) {
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getStringentRuleHierarchyList()
							.equals(stringentRule.getStringentRuleHierarchyList())) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			}
		}
		/*
		 * if no stringent rules and only master rule exists, then master rules
		 * are qualified for the Regulation processing
		 */

		if (passedLookupset.isEmpty() && lookUpCriteriaPassRule.getMasterPassedMap() != null) {
			passedLookupset.addAll(lookUpCriteriaPassRule.getMasterPassedMap());
		}

		Boolean spotValidation = null;
		List<CreditDecision> creditList = null;
		Boolean creditDecisionOrSpotValid = validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit,
												creditDecisionList);
		if (creditDecisionOrSpotValid) {
			// Deal is valid, set spotValidation flag and creditList
			spotValidation = isSpotValidation(xmlFieldValueMap, creditDecisionList);
			creditList = getCreditList(xmlFieldValueMap, creditDecisionList);
		}
		else {
			// Deal is invalid
			return Optional.empty();
		}

		/*
		 * String applicationNumber = xmlFieldValueMap.get("ApplicationNumber");
		 *
		 * if (!spotValidation) {
		 *
		 * for (int i = 0; i < creditDecisionList.size(); i++) {
		 *
		 * String conversationId =
		 * creditDecisionList.get(i).getConversationId();
		 *
		 * if (StringUtils.isNotBlank(applicationNumber) &&
		 * applicationNumber.equalsIgnoreCase(conversationId)) {
		 * logger.info("Application Number match found: {}",
		 * creditDecisionList.get(i).getConversationId());
		 * creditList.add(creditDecisionList.get(i)); break; } else {
		 *
		 * if
		 * (xmlFieldValueMap.get("VehicleVIN").equals(creditDecisionList.get(i).
		 * getVIN())) { if
		 * (xmlFieldValueMap.get("LenderPartyId").equals(creditDecisionList.get(
		 * i).getR1lenderId())) {
		 *
		 * if (xmlFieldValueMap.get("ApplicationType").equals("IN")) { if
		 * (xmlFieldValueMap.containsKey("BuyerPersonNameGivenName") &&
		 * xmlFieldValueMap.containsKey("BuyerPersonNameFamilyName") &&
		 * xmlFieldValueMap.containsKey("BuyerPartyId")) { if
		 * (xmlFieldValueMap.get("BuyerPersonNameGivenName")
		 * .equals(creditDecisionList.get(i).getBuyerFirstName())) { if
		 * (xmlFieldValueMap.get("BuyerPersonNameFamilyName")
		 * .equals(creditDecisionList.get(i).getBuyerLastName())) { if
		 * (xmlFieldValueMap.get("BuyerPartyId")
		 * .equals(creditDecisionList.get(i).getBuyerSSN())) {
		 * creditList.add(creditDecisionList.get(i)); } }
		 *
		 * } }
		 *
		 * } if (xmlFieldValueMap.get("ApplicationType").equals("IC") ||
		 * xmlFieldValueMap.get("ApplicationType").equals("BC")) {
		 *
		 * if (xmlFieldValueMap.containsKey("CoAppPersonNameGivenName") &&
		 * xmlFieldValueMap.containsKey("CoAppPersonNameFamilyName") &&
		 * xmlFieldValueMap.containsKey("CoAppPartyId")) { if
		 * (xmlFieldValueMap.get("CoAppPersonNameGivenName")
		 * .equals(creditDecisionList.get(i).getCobuyerFirstName())) { if
		 * (xmlFieldValueMap.get("CoAppPersonNameFamilyName")
		 * .equals(creditDecisionList.get(i).getCobuyerLastName())) { if
		 * (xmlFieldValueMap.get("CoAppPartyId")
		 * .equals(creditDecisionList.get(i).getCoBuyerSSN())) {
		 * creditList.add(creditDecisionList.get(i)); } }
		 *
		 * } } }
		 *
		 * } } } }
		 *
		 * // multiple credit lines error if (creditList.size() > 1) {
		 * processAudit.setRflValidationEnd(new
		 * Timestamp(System.currentTimeMillis())); RFLRuleResponse rflResponse =
		 * new RFLRuleResponse();
		 *
		 * return Optional.of(rflResponse);
		 *
		 * } // no matching credit lines. error if (creditList.isEmpty()) {
		 * String errorMessage = "No Application Number match found!!: " +
		 * applicationNumber; logger.error(errorMessage);
		 * processAudit.setRflValidationEnd(new
		 * Timestamp(System.currentTimeMillis())); RFLRuleResponse rflResponse =
		 * new RFLRuleResponse(); rflResponse.setPassedRFLs(null); //return
		 * Optional.of(rflResponse); throw new
		 * BadRequestException(errorMessage);
		 *
		 * }
		 *
		 * }
		 */

		nextRule: for (Rule rule : passedLookupset) {
			List fieldValueList = new ArrayList();
			List ruleExpressionList = new ArrayList();
			String ruleLogic = rule.getRuleLogic();
			logger.info("Rule for RFL Rule Logic Proccessing...{}", rule);

			ObjectMapper mapper = new ObjectMapper();

			RegulationRuleLogicExpression[] ruleExpression = mapper.readValue(ruleLogic,
					RegulationRuleLogicExpression[].class);

			logger.debug("ruleExpression.length: {}", ruleExpression.length);

			for (int i = 0; i < ruleExpression.length; i++) {

				Boolean[] regulationRuleQualifier = { false };

				logger.debug("ruleExpression type: {}, prefix: {}", ruleExpression[i].getExpressionType(), ruleExpression[i].getFieldExpressionPrefix());

				if (ruleExpression[i].getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {

					if ("CA".equals(ruleExpression[i].getFieldExpressionPrefix())) {
						String result = processCARuleExpressionField4RFL(ruleExpression[i], calcList, xmlFieldValueMap,
								xmlfieldsDTOList, spotValidation, creditList);
						if (StringUtils.isEmpty(result)) {
							regulationRuleQualifier[0] = false;
							continue nextRule;
						} else {
							regulationRuleQualifier[0] = true;
							if (result.equals("Skip Rule")) {
								regulationRuleQualifier[0] = false;
								continue nextRule;
							}
						}

					} else if ("CR".equals(ruleExpression[i].getFieldExpressionPrefix())) {

						if (spotValidation) {
							continue nextRule;
						}

						if (!spotValidation) {
							CreditDecision creditDecision = creditList.get(0);
							String creditfield = ruleExpression[i].getValue();
							HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
							if (map.get(creditfield) != null) {
								ruleExpressionList.add(map.get(creditfield).toString());
							} else if (map.get(creditfield) == null) {
								continue nextRule;
							}
						}
					} else if ("CO".equals(ruleExpression[i].getFieldExpressionPrefix())) {

						logger.info("Processing for field expression prefix: CO starts...");

						boolean result = processCoRuleExpressionField4RFL(ruleExpression[i], xmlfieldsDTOList, ruleExpressionList);

						String field = ruleExpression[i].getValue();

						if (!result) {
							logger.debug("No match found for field: {} in xmlfieldsDTOList", field);
							continue nextRule;
						}
					}

				}

				logger.debug("Checking ExpressionType.OPERATOR");
				if (ruleExpression[i].getExpressionType()
						.equals(RegulationRuleLogicExpression.ExpressionType.OPERATOR)) {
					String op = ruleExpression[i].getValue();
					logger.debug("OPERATOR value: {}", op);
					if (op.equals("IFEXIST")) {
						i++;
						logger.debug("OPERATOR value is IFEXIST. Going for the next ruleExpression");
						logger.debug("ruleExpression type: {}, prefix: {}", ruleExpression[i].getExpressionType(), ruleExpression[i].getFieldExpressionPrefix());
						if (ruleExpression[i].getExpressionType()
								.equals(RegulationRuleLogicExpression.ExpressionType.FIELD)) {
							if ("CO".equals(ruleExpression[i].getFieldExpressionPrefix())) {
								String field = ruleExpression[i].getValue();
								logger.debug("field: {}", field);
								regulationRuleQualifier[0] = true;

								if (xmlFieldValueMap.containsKey(field)) {
									if (!xmlFieldValueMap.get(field).equals("")) {
										ruleExpressionList.add(true);
									} else {
										ruleExpressionList.add(false);

									}

								} else {
									logger.debug("xmlFieldValueMap does not contain field: {}", field);
									ruleExpressionList.add(false);

								}
							}

							if ("CR".equals(ruleExpression[i].getFieldExpressionPrefix())) {
								regulationRuleQualifier[0] = true;
								if (spotValidation) {
									regulationRuleQualifier[0] = false;
									continue nextRule;
								}

								if (!spotValidation) {
									CreditDecision creditDecision = creditList.get(0);
									String creditfield = ruleExpression[i].getValue();
									HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);

									if (map.get(creditfield) != null) {
										ruleExpressionList.add(true);

									} else {
										ruleExpressionList.add(false);

									}

								}
							}

							if ("CA".equals(ruleExpression[i].getFieldExpressionPrefix())) {
								regulationRuleQualifier[0] = true;
								String field = ruleExpression[i].getValue();
								for (int j = 0; j < calcList.size(); j++) {

									if (calcList.get(j).getCalculationName().equals(field)) {
										if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
												|| calcList.get(j).getFinanceType().isEmpty()
												|| calcList.get(j).getFinanceType() == null) {
											if (calcList.get(j).getState()
													.equals(xmlFieldValueMap.get("ContractExecutionState"))
													|| calcList.get(j).getState().isEmpty()
													|| calcList.get(j).getState() == null) {
												if (calcList.get(j).getLender()
														.equals(xmlFieldValueMap.get("LenderPartyId"))
														|| calcList.get(j).getLender().isEmpty()
														|| calcList.get(j).getLender() == null) {
													regulationRuleQualifier[0] = true;
													try {
														String reResult = getCalculatedValue(
																calcList.get(j).getCalculationJSON(), xmlfieldsDTOList,
																xmlFieldValueMap, calcList, spotValidation, creditList);
														if (reResult.equals("Skip Rule")) {
															regulationRuleQualifier[0] = false;
															break;
														}
														ruleExpressionList.add(true);
													} catch (IOException e) {
														logger.error(
																"Exception while RFL Rule Logic Expression Proccessing, in Calculation",
																e.getMessage());
													}
												} else {
													regulationRuleQualifier[0] = false;
													break;
												}
											} else {
												regulationRuleQualifier[0] = false;
												break;
											}
										} else {
											regulationRuleQualifier[0] = false;
											break;
										}
									}

								}

							}

							if (!regulationRuleQualifier[0]) {
								ruleExpressionList.add(false);
							}

						}
					} else {
						ruleExpressionList.add(op);
					}

				}

				if (ruleExpression[i].getExpressionType().equals(RegulationRuleLogicExpression.ExpressionType.VALUE)) {
					String value = ruleExpression[i].getValue();
					ruleExpressionList.add(value);

				}

			} // ruleexpression loop ends here

			/*
			 * to do : write a common function which accepts diff values and do
			 * logic accordingly
			 */

			if (ruleExpressionList.contains("DATETIME")) {
				processRuleExpressionsDateTime4RFL(ruleExpressionList);
			}

			if (ruleExpressionList.contains("% of")) {
				ruleExpressionList = getPercentageEval(ruleExpressionList);
			}

			List<List> ruleLogicExp = new ArrayList<>();
			List<String> logicalOperatorList = new ArrayList<>();

			int j = 0;

			logger.debug("Printing rule expression list for rule: {}, below", rule.getRuleName());
			ruleExpressionList.stream().forEach(rE -> {
				logger.debug(rE.toString());
			});

			if (ruleExpressionList.contains("AND") || ruleExpressionList.contains("OR")) {

				processExpressionAndOr4RFL(logicalOperatorList, ruleExpressionList, ruleLogicExp, boolresultList);

			} else {

				boolean result = false;
				if (ruleExpressionList.get(0) instanceof Boolean) {
					if (ruleExpressionList.get(0).equals(true)) {
						result = true;
					} else if (ruleExpressionList.get(0).equals(false)) {
						result = false;
					}
				} else {
					try {
						result = eval(ruleExpressionList);
					} catch (ScriptException e) {
						logger.error("RFL Rule Logic : Exception while Evaluation Logic " + e.getMessage());
						throw new BadRequestException(
								"RFL Rule Logic : Exception while Evaluation Logic " + e.getMessage());
					}
				}
				if (result) { // make it pass rules here

					passedRuleSet.add(rule);
					passRuleMessage.put(rule, rule.getRuleName());

				}
				if (!result) { // make it fail rules here

				}

			}

			if (!boolresultList.isEmpty() && !logicalOperatorList.isEmpty()) {
				//call script engine to evalute logical operators
				Object result = evaluateLogicalResultUsingScriptEngine(boolresultList, logicalOperatorList);
				if (result instanceof Boolean) {
					if (result.equals(true)) {
						passedRuleSet.add(rule);
						passRuleMessage.put(rule, rule.getRuleName());
					}
					if (result.equals(false)) {
						// No display of failure
					}
				}
			}
		} // end rule loop

		if (passRuleMessage.size() > 0) {

			for (String pass : passRuleMessage.values()) {
				passAuditMessage.append(pass);
				passAuditMessage.append(",");
			}

			logger.debug("Generated RFL: {}", passAuditMessage.toString());
		}
		else
		{
			logger.debug("No RFLs were generated.");
		}
		RFLRuleResponse rflResponse = new RFLRuleResponse();
		rflResponse.setPassedRFLs(passAuditMessage.toString());
		processAudit.setRflValidationEnd(new Timestamp(System.currentTimeMillis()));
		logger.info("Exit getRuleByRFL() method of ProcessRuleServiceImpl class.");
		return Optional.of(rflResponse);

	}

	/**
	 * @param ruleExpressionList
	 */
	private void processRuleExpressionsDateTime4RFL(List ruleExpressionList) throws BadRequestException{

		logger.info("Entered processRuleExpressionsDateTime4RFL() method of ProcessRuleServiceImpl class.");

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List ruleExpressionDate = new ArrayList();
		for (int i = 0; i < ruleExpressionList.size(); i++) {
			if (ruleExpressionList.get(i).equals("DATETIME")) {
				if (!String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
					if (ruleExpressionList.get(i + 2).equals("=")) {
						Date lhs = new Date();
						Date rhs = new Date();
						try {
							lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
							rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
						} catch (ParseException e) {
							throw new BadRequestException(
									" RFL Rule Logic : Wrong Date Format on Rule " + e.getMessage());
						}
						Boolean dateevaluation = lhs.equals(rhs);
						ruleExpressionDate.add(i, dateevaluation);
						i = i + 3;

					} else if (ruleExpressionList.get(i + 2).equals(">")) {
						Date lhs = new Date();
						Date rhs = new Date();
						try {
							lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
							rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
						} catch (ParseException e) {
							throw new BadRequestException(
									" RFL Rule Logic : Wrong Date Format on Rule " + e.getMessage());
						}
						Boolean dateevaluation = lhs.before(rhs);
						ruleExpressionDate.add(i, dateevaluation);
						i = i + 3;
					} else if (ruleExpressionList.get(i + 2).equals("<")) {
						Date lhs = new Date();
						Date rhs = new Date();
						try {
							lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
							rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
						} catch (ParseException e) {
							throw new BadRequestException(
									"RFL Rule Logic  : Wrong Date Format on Rule " + e.getMessage());
						}
						Boolean dateevaluation = lhs.after(rhs);
						ruleExpressionDate.add(i, dateevaluation);
						i = i + 3;
					}
				} else if (String.valueOf(ruleExpressionList.get(i + 3)).equals("DATETIME")) {
					if (ruleExpressionList.get(i + 2).equals("=")) {
						Date lhs = new Date();
						Date rhs = new Date();
						try {
							lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
							rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
						} catch (ParseException e) {
							throw new BadRequestException(
									"RFL Rule Logic  : Wrong Date Format on Rule " + e.getMessage());
						}
						Boolean dateevaluation = lhs.equals(rhs);
						ruleExpressionDate.add(i, dateevaluation);
						i = i + 4;

					} else if (ruleExpressionList.get(i + 2).equals(">")) {
						Date lhs = new Date();
						Date rhs = new Date();
						try {
							lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
							rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
						} catch (ParseException e) {
							throw new BadRequestException(
									"RFL Rule Logic  : Wrong Date Format on Rule " + e.getMessage());
						}
						Boolean dateevaluation = lhs.before(rhs);
						ruleExpressionDate.add(i, dateevaluation);
						i = i + 4;
					} else if (ruleExpressionList.get(i + 2).equals("<")) {
						Date lhs = new Date();
						Date rhs = new Date();
						try {
							lhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 1)));
							rhs = formatter.parse(String.valueOf(ruleExpressionList.get(i + 3)));
						} catch (ParseException e) {
							throw new BadRequestException(
									"RFL Rule Logic  : Wrong Date Format on Rule " + e.getMessage());
						}
						Boolean dateevaluation = lhs.after(rhs);
						ruleExpressionDate.add(i, dateevaluation);
						i = i + 4;
					}
				}

			} else {
				ruleExpressionDate.add(ruleExpressionList.get(i));
			}
		}
		ruleExpressionList.clear();
		ruleExpressionList.addAll(ruleExpressionDate);

	}

	/**
	 * @param boolresultList
	 * @param logicalOperatorList
	 * @return
	 */
	private Object evaluateLogicalResultUsingScriptEngine(List<Boolean> boolresultList,
			List<String> logicalOperatorList) {

		logger.info("Entered evaluateLogicalResultUsingScriptEngine() method of ProcessRuleServiceImpl class.");

		int min = Math.min(boolresultList.size(), logicalOperatorList.size());
		StringBuilder logicalResult = new StringBuilder();
		for (int i = 0; i <= min; i++) {
			if (i < min) {
				logicalResult.append(boolresultList.get(i));
				if (logicalOperatorList.get(i).equals("AND")) {
					logicalResult.append("&&");
				}
				if (logicalOperatorList.get(i).equals("OR")) {
					logicalResult.append("||");
				}

			}
			if (i == min) {
				logicalResult.append(boolresultList.get(i));
			}
		}
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("nashorn");
		Object result = new Object();
		try {
			logger.debug("Expression being evaluated by Script Engine: {}", logicalResult.toString());
			result = engine.eval(logicalResult.toString());
		} catch (ScriptException e) {
			logger.error("RFL Rule: Exception while Evaluation Logic " + e.getMessage());
			throw new BadRequestException("RFL Rule: Exception while Evaluation Logic " + e.getMessage());
		}
		logger.info("Exit evaluateLogicalResultUsingScriptEngine() method of ProcessRuleServiceImpl class.");
		return result;
	}

	/**
	 * @param logicalOperatorList
	 * @param ruleExpressionList
	 * @param ruleLogicExp
	 * @param boolresultList
	 */
	private void processExpressionAndOr4RFL(List<String> logicalOperatorList, List ruleExpressionList, List<List> ruleLogicExp,
			List<Boolean> boolresultList) {

		logger.info("Entered processExpressionAndOr4RFL() method of ProcessRuleServiceImpl class.");

		int j = 0;

		for (int i = 0; i < ruleExpressionList.size(); i++) {
			if (ruleExpressionList.get(i).equals("AND") || ruleExpressionList.get(i).equals("OR")) {
				ruleLogicExp.add(ruleExpressionList.subList(j, i));
				j = i + 1;
				logicalOperatorList.add((String) ruleExpressionList.get(i));
			}
			if (i == ruleExpressionList.size() - 1) {
				if (logicalOperatorList.contains(Constants.OR)) {
					List additionalLogicExp = new ArrayList();
					additionalLogicExp.add(ruleExpressionList.get(0));
					additionalLogicExp.add(ruleExpressionList.get(1));
					additionalLogicExp.add(ruleExpressionList.get(i));
					ruleLogicExp.add(additionalLogicExp);
				} else {
					ruleLogicExp.add(ruleExpressionList.subList(j, i + 1));
				}

			}
		}

		ruleLogicExp.forEach(expression -> {
			// commented phase 1 code for ifexist
			if (expression.contains(true) || expression.contains(false)) {
				if (expression.contains(true)) {
					boolresultList.add(true);
				} else if (expression.contains(false)) {
					boolresultList.add(false);
				}
			}
			else {
				try {
					boolean result = eval(expression);
					boolresultList.add(result);
				} catch (ScriptException e) {
					logger.error("RFL Rule Logic : Exception while Evaluation Logic " + e.getMessage());
					throw new BadRequestException(
							"RFL Rule Logic : Exception while Evaluation Logic " + e.getMessage());
				}
			}
		});

		logger.info("Exit processExpressionAndOr4RFL() method of ProcessRuleServiceImpl class.");

	}

	/**
	 * @param regulationRuleLogicExpression
	 * @param xmlfieldsDTOList
	 * @param ruleExpressionList
	 * @return
	 */
	private boolean processCoRuleExpressionField4RFL(RegulationRuleLogicExpression regulationRuleLogicExpression,
			List<XMLFieldsDTO> xmlfieldsDTOList, List ruleExpressionList) {

		logger.info("Entered processCoRuleExpressionField4RFL() method of ProcessRuleServiceImpl class.");

		String field = regulationRuleLogicExpression.getValue();
		boolean fieldProcessed = false;
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		for (XMLFieldsDTO xmlField : xmlfieldsDTOList) {
			logger.info("FieldName {} and FieldValue from XML {}", xmlField.getFieldName(), field);

			if (field.equals(xmlField.getFieldName())) {

				if (xmlField.getFieldType().equals("DATETIME")) {
					Date dateFromXML = new Date();
					try {
						dateFromXML = formatter.parse(xmlField.getFieldValue());
					} catch (ParseException e) {
						logger.error(
								"Exception while  RFL Rule Logic Expression Proccessing:  Wrong Date Format on XML "
										+ e.getMessage());
						throw new BadRequestException(
								"Exception while  RFL Rule Logic Expression Proccessing:  Wrong Date Format on XML "
										+ e.getMessage());
					}

					ruleExpressionList.add("DATETIME");
					ruleExpressionList.add(dateFromXML);
					fieldProcessed = true;

				} else if (xmlField.getFieldType().equals("NUMERIC")
						|| xmlField.getFieldType().equals("TEXT")) {
					ruleExpressionList.add(xmlField.getFieldValue());
					fieldProcessed = true;

				}
				break;

			}

		}
		logger.info("Exit processCoRuleExpressionField4RFL() method of ProcessRuleServiceImpl class.");
		return fieldProcessed;
	}

	/**
	 * @param regulationRuleLogicExpression
	 * @param calcList
	 * @param xmlFieldValueMap
	 * @param xmlfieldsDTOList
	 * @param spotValidation
	 * @param creditList
	 * @return
	 */
	private String processCARuleExpressionField4RFL(RegulationRuleLogicExpression regulationRuleLogicExpression,
			List<Calculation> calcList, Map<String, String> xmlFieldValueMap, List<XMLFieldsDTO> xmlfieldsDTOList, Boolean spotValidation, List<CreditDecision> creditList) {
		logger.info("Exit processCARuleExpressionField4RFL() method of ProcessRuleServiceImpl class.");
		String field = regulationRuleLogicExpression.getValue();
		String reResult = null;
		for (int j = 0; j < calcList.size(); j++) {

			if (calcList.get(j).getCalculationName().equals(field)) {
				if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
						|| calcList.get(j).getFinanceType().isEmpty()
						|| calcList.get(j).getFinanceType() == null) {
					if (calcList.get(j).getState()
							.equals(xmlFieldValueMap.get("ContractExecutionState"))
							|| calcList.get(j).getState().isEmpty()
							|| calcList.get(j).getState() == null) {
						if (calcList.get(j).getLender().equals(xmlFieldValueMap.get("LenderPartyId"))
								|| calcList.get(j).getLender().isEmpty()
								|| calcList.get(j).getLender() == null) {
							try {
								reResult = getCalculatedValue(
										calcList.get(j).getCalculationJSON(), xmlfieldsDTOList,
										xmlFieldValueMap, calcList, spotValidation, creditList);
								if (reResult.equals("Skip Rule")) {
								}
							} catch (IOException e) {
								logger.error(
										"Exception while RFL Rule Logic Expression Proccessing, in Calculation",
										e.getMessage());
							}
						} else {
							return reResult;
						}
					} else {
						return reResult;
					}
				} else {
					return reResult;
				}
			}

		}
		return null;
	}

	/**
	 * Process Tolerance Rules.
	 *
	 * Multiple rules can be qualified for Tolerance Rules. Qualified rules
	 * are/is checked for the rule logic
	 *
	 * @return if rule logic pass return pass else appropriate fail message
	 */

	public Optional<Integer> getTolerance(List<XMLFieldsDTO> xmlfieldsDTOList, Map<String, String> xmlLookUpFieldMap,
			Map<String, String> xmlFieldValueMap, ProcessAudit processAudit, List<Calculation> calcList, List<CreditDecision> creditDecisionList) {

		logger.info("Enter getTolerance() method of ProcessRuleServiceImpl class.");

		LinkedHashSet<Rule> passedLookupset = new LinkedHashSet<>();

		StringBuilder failureAuditMessage = new StringBuilder();
		StringBuilder passAuditMessage = new StringBuilder();

		StringBuilder failureMsg = new StringBuilder();
		StringBuilder PassMsg = new StringBuilder();


		List<StringentRuleQualification> stringentRuleList = new ArrayList<>();

		LookUpCriteriaPassRules lookUpCriteriaPassRule = new LookUpCriteriaPassRules();

		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("nashorn");

		HashMap<Rule, String> rulepassedmap = new HashMap();
		processAudit.settValidationStart(new Timestamp(System.currentTimeMillis()));
		logger.info("Tolerance Rules Processing ...");
		List<Rule> toleranceRulelist = ruleDAO.findByTolerance();

		HashMap<Rule, String> failedrulemap = new HashMap();

		if (toleranceRulelist == null || toleranceRulelist.isEmpty()) {
			processAudit.settValidationResult(norule);
			processAudit.settValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/* Get the rules which pass the Stringent lookup criteria */
		logger.info("Invoking lookupFieldCheck for Stringent filtering of Tolerance Rules...");
		Optional<LookUpCriteriaPassRules> lookUpCriteriaPassRules = lookupFieldCheck(toleranceRulelist,
				xmlLookUpFieldMap);
		if (lookUpCriteriaPassRules.isPresent()) {
			lookUpCriteriaPassRule = lookUpCriteriaPassRules.get();

		}

		/* No Stringent rule or Master rule return norule */
		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() == null
				&& lookUpCriteriaPassRule.getMasterPassedMap() == null) {
			processAudit.settValidationResult(norule);
			processAudit.settValidationEnd(new Timestamp(System.currentTimeMillis()));
			return Optional.empty();
		}

		/*
		 * Look up fields qualified rules are sorted based on the Stringent
		 * Rules hierarchy
		 */

		if (lookUpCriteriaPassRule.getStringentQualifyRuleList() != null) {
			stringentRuleList = lookUpCriteriaPassRule.getStringentQualifyRuleList();
			stringentRuleList = stringentRuleList.stream()
					.sorted((StringentRuleQualification o1, StringentRuleQualification o2) -> {
						int min = Math.min(o1.getStringentRuleHierarchyList().size(),
								o2.getStringentRuleHierarchyList().size());
						for (int i = 0; i < min; i++) {
							int higest = o1.getStringentRuleHierarchyList().get(i)
									.compareTo(o2.getStringentRuleHierarchyList().get(i));
							if (higest != 0) {
								return higest;
							}
						}
						return Integer.compare(o2.getStringentRuleHierarchyList().size(),
								o1.getStringentRuleHierarchyList().size());
					}).collect(Collectors.toList());
			Boolean sameStringentHirearchy = false;

			/*
			 * If there exists two rules with highest stringent rule priority,
			 * then sort based on the number of lookup fields matched
			 */
			for (StringentRuleQualification stringentRule : stringentRuleList.subList(1, stringentRuleList.size())) {
				if (stringentRule.getStringentRuleHierarchyList()
						.equals(stringentRuleList.get(0).getStringentRuleHierarchyList())) {
					sameStringentHirearchy = true;
					break;

				}
			}

			if (sameStringentHirearchy) {

				stringentRuleList.sort((StringentRuleQualification s1,
						StringentRuleQualification s2) -> s2.getTotalLookUpCount() - s1.getTotalLookUpCount());
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getTotalLookUpCount() == stringentRule.getTotalLookUpCount()) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			} else if (!sameStringentHirearchy) {
				for (StringentRuleQualification stringentRule : stringentRuleList) {
					if (stringentRuleList.get(0).getStringentRuleHierarchyList()
							.equals(stringentRule.getStringentRuleHierarchyList())) {
						passedLookupset.add(stringentRule.getStringentRule());
					}
				}

			}
		}
		/*
		 * if no stringent rules and only master rule exists, then master rules
		 * are qualified for the Tolerance processing
		 */

		if (passedLookupset.isEmpty() && lookUpCriteriaPassRule.getMasterPassedMap() != null) {
			passedLookupset.addAll(lookUpCriteriaPassRule.getMasterPassedMap());
		}

		Boolean spotValidation = null;
		List<CreditDecision> creditList = null;
		Boolean creditDecisionOrSpotValid = validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit,
												creditDecisionList);
		if (creditDecisionOrSpotValid) {
			// Deal is valid, set spotValidation flag and creditList
			spotValidation = isSpotValidation(xmlFieldValueMap, creditDecisionList);
			creditList = getCreditList(xmlFieldValueMap, creditDecisionList);
		}
		else {
			// Deal is invalid
			return Optional.empty();
		}

		/*
		 * String applicationNumber = xmlFieldValueMap.get("ApplicationNumber");
		 *
		 * if (!spotValidation) {
		 *
		 * for (int i = 0; i < creditDecisionList.size(); i++) {
		 *
		 * String conversationId =
		 * creditDecisionList.get(i).getConversationId();
		 *
		 * if (StringUtils.isNotBlank(applicationNumber) &&
		 * applicationNumber.equalsIgnoreCase(conversationId)) {
		 * logger.info("Application Number match found: {}",
		 * creditDecisionList.get(i).getConversationId());
		 * creditList.add(creditDecisionList.get(i)); break; } else {
		 *
		 * if
		 * (xmlFieldValueMap.get("VehicleVIN").equals(creditDecisionList.get(i).
		 * getVIN())) { if
		 * (xmlFieldValueMap.get("LenderPartyId").equals(creditDecisionList.get(
		 * i).getR1lenderId())) {
		 *
		 * if (xmlFieldValueMap.get("ApplicationType").equals("IN")) { if
		 * (xmlFieldValueMap.containsKey("BuyerPersonNameGivenName") &&
		 * xmlFieldValueMap.containsKey("BuyerPersonNameFamilyName") &&
		 * xmlFieldValueMap.containsKey("BuyerPartyId")) { if
		 * (xmlFieldValueMap.get("BuyerPersonNameGivenName")
		 * .equals(creditDecisionList.get(i).getBuyerFirstName())) { if
		 * (xmlFieldValueMap.get("BuyerPersonNameFamilyName")
		 * .equals(creditDecisionList.get(i).getBuyerLastName())) { if
		 * (xmlFieldValueMap.get("BuyerPartyId")
		 * .equals(creditDecisionList.get(i).getBuyerSSN())) {
		 * creditList.add(creditDecisionList.get(i)); } }
		 *
		 * } }
		 *
		 * } if (xmlFieldValueMap.get("ApplicationType").equals("IC") ||
		 * xmlFieldValueMap.get("ApplicationType").equals("BC")) {
		 *
		 * if (xmlFieldValueMap.containsKey("CoAppPersonNameGivenName") &&
		 * xmlFieldValueMap.containsKey("CoAppPersonNameFamilyName") &&
		 * xmlFieldValueMap.containsKey("CoAppPartyId")) { if
		 * (xmlFieldValueMap.get("CoAppPersonNameGivenName")
		 * .equals(creditDecisionList.get(i).getCobuyerFirstName())) { if
		 * (xmlFieldValueMap.get("CoAppPersonNameFamilyName")
		 * .equals(creditDecisionList.get(i).getCobuyerLastName())) { if
		 * (xmlFieldValueMap.get("CoAppPartyId")
		 * .equals(creditDecisionList.get(i).getCoBuyerSSN())) {
		 * creditList.add(creditDecisionList.get(i)); } }
		 *
		 * } } }
		 *
		 * } } } }
		 *
		 * // multiple credit lines error if (creditList.size() > 1) {
		 * failureAuditMessage.append(
		 * "There are multiple decisions found. Please select from the following, input into the Application Number field,"
		 * ); creditList.forEach(credit -> {
		 * failureAuditMessage.append(credit.getApplicationNumber());
		 * failureAuditMessage.append(",");
		 * failureAuditMessage.append(credit.getConversationId());
		 * failureAuditMessage.append(","); });
		 * failureAuditMessage.append("and resubmit validation");
		 * failureAuditMessage.append("  +  ");
		 * processAudit.settValidationResult(passmessage + " || " + failmessage
		 * + " " + failureAuditMessage.toString().substring(0,
		 * failureAuditMessage.toString().length() - 3));
		 * processAudit.settValidationEnd(new
		 * Timestamp(System.currentTimeMillis())); return Optional.empty();
		 *
		 * } // no matching credit lines. error if (creditList.isEmpty()) {
		 * failureAuditMessage.append(
		 * "Credit Application not found. Please input your credit application and re-submit your validation. For SPOT validation, input the customer tier in the Spot Program code."
		 * ); failureAuditMessage.append("  +  ");
		 * processAudit.settValidationResult(passmessage + " || " + failmessage
		 * + " " + failureAuditMessage.toString().substring(0,
		 * failureAuditMessage.toString().length() - 3));
		 * processAudit.settValidationEnd(new
		 * Timestamp(System.currentTimeMillis())); return Optional.empty(); }
		 *
		 * }
		 */

		nextRule: for (Rule rule : passedLookupset) {
			HashMap<String, String> calcValues = new HashMap();
			String ruleLogic = rule.getRuleLogic();
			ToleranceRuleLogic toleranceExpn = new ToleranceRuleLogic();
			logger.info("Rule for Tolerance Rule Logic Proccessing : RuleID: {}, Rule Name: {}", rule.getId(), rule.getRuleName());
			ObjectMapper mapper = new ObjectMapper();

			try {
				toleranceExpn = mapper.readValue(ruleLogic, ToleranceRuleLogic.class);
				logger.info("Rule for Tolerance Rule Logic Expression : {}", toleranceExpn);

			} catch (IOException e) {
				logger.error("Tolerance Rule: Exception while Parsing Logic Expression " + e.getMessage());
				throw new BadRequestException(
						"Tolerance Rule: Exception while Parsing Logic Expression " + e.getMessage());
			}

			Boolean lowExprn = false;
			Boolean baseExprn = false;
			Boolean highExprn = false;
			Boolean ifExprn = false;
			Boolean lowMultipleExprn = false;
			Boolean baseMultipleExprn = false;
			Boolean highMultipleExprn = false;
			List lowToleranceExprnWithValue = new ArrayList();

			List<List> lowToleranceExprns = new ArrayList();
			List<List> lowlogicOperator = new ArrayList();

			HashMap<Integer, List<List>> lowlogicAndRuleSplit = new HashMap<Integer, List<List>>();

			List<List> baseToleranceExprns = new ArrayList();
			List<List> baselogicOperator = new ArrayList();

			HashMap<Integer, List<List>> baselogicAndRuleSplit = new HashMap<Integer, List<List>>();

			List<List> highToleranceExprns = new ArrayList();
			List lowerOfExprn = new ArrayList();
			List<List> highlogicOperator = new ArrayList();

			HashMap<Integer, List<List>> highlogicAndRuleSplit = new HashMap<Integer, List<List>>();
			List higherOfExprn = new ArrayList();
			List ifEvalExprn = new ArrayList();
			// low field value
			if (!toleranceExpn.getLowTolerance().isEmpty()) {
				ToleranceGetValues tolgetVal = new ToleranceGetValues();

				lowExprn = true;
				tolgetVal = getValuesOfExpression(toleranceExpn.getLowTolerance(), new ArrayList(), xmlfieldsDTOList,
						xmlLookUpFieldMap, calcList, spotValidation, creditList);
				lowToleranceExprnWithValue.addAll(tolgetVal.getValuesList());
				calcValues.putAll(tolgetVal.getCalcValues());
				if (lowToleranceExprnWithValue.contains("Skip Rule")) {
					continue nextRule;
				}
				if (lowToleranceExprnWithValue.contains("IFEXIST")) {
					List val = new ArrayList();
					ifExprn = true;
					Map<Integer, List> subLists = new HashMap();
					if (!spotValidation) {
						subLists = evaluateIfExists(lowToleranceExprnWithValue, xmlLookUpFieldMap, calcList,
								xmlfieldsDTOList, xmlLookUpFieldMap, spotValidation, creditList);
					} else if (spotValidation) {
						continue nextRule;
					}

					ifEvalExprn.addAll(subLists.get(0));
					val.addAll(subLists.get(1));
					lowToleranceExprnWithValue.clear();
					lowToleranceExprnWithValue.addAll(val);

				}

				if (lowToleranceExprnWithValue.contains("% of")) {
					lowToleranceExprnWithValue = evaluatePercent(lowToleranceExprnWithValue);
				}

				lowToleranceExprnWithValue = preprocessExpression(lowToleranceExprnWithValue);

				if (lowToleranceExprnWithValue.contains("OR") || lowToleranceExprnWithValue.contains("AND")) {
					lowMultipleExprn = true;
					lowlogicAndRuleSplit = splitExpressionWithORAND(lowToleranceExprnWithValue);
					lowToleranceExprns = lowlogicAndRuleSplit.get(0);
					lowlogicOperator = lowlogicAndRuleSplit.get(1);
				} else {
					lowToleranceExprns.add(lowToleranceExprnWithValue);
				}

			}

			// low operator
			List lowComparsionOperatorWithValue = new ArrayList();
			if (!toleranceExpn.getLowComparsionOperator().isEmpty()) {
				ToleranceGetValues tolgetVal = new ToleranceGetValues();

				tolgetVal = getValuesOfExpression(toleranceExpn.getLowComparsionOperator(), new ArrayList(),
						xmlfieldsDTOList, xmlLookUpFieldMap, calcList, spotValidation, creditList);
				lowComparsionOperatorWithValue.addAll(tolgetVal.getValuesList());
				calcValues.putAll(tolgetVal.getCalcValues());

				if (lowComparsionOperatorWithValue.contains("Skip Rule")) {
					continue nextRule;
				}
				if (lowComparsionOperatorWithValue.contains("% of")) {
					lowComparsionOperatorWithValue = evaluatePercent(lowComparsionOperatorWithValue);
				}

			}

			// base field value
			List fieldExprnWithValue = new ArrayList();
			if (!toleranceExpn.getFieldExpression().isEmpty()) {
				ToleranceGetValues tolgetVal = new ToleranceGetValues();
				baseExprn = true;
				tolgetVal = getValuesOfExpression(toleranceExpn.getFieldExpression(), new ArrayList(), xmlfieldsDTOList,
						xmlLookUpFieldMap, calcList, spotValidation, creditList);
				fieldExprnWithValue.addAll(tolgetVal.getValuesList());
				calcValues.putAll(tolgetVal.getCalcValues());
				if (fieldExprnWithValue.contains("Skip Rule")) {
					continue nextRule;
				}
				if (fieldExprnWithValue.contains("% of")) {
					fieldExprnWithValue = evaluatePercent(fieldExprnWithValue);
				}
				fieldExprnWithValue = preprocessExpression(fieldExprnWithValue);

				if (fieldExprnWithValue.contains("OR") || fieldExprnWithValue.contains("AND")) {
					baseMultipleExprn = true;
					baselogicAndRuleSplit = splitExpressionWithORAND(fieldExprnWithValue);
					baseToleranceExprns = baselogicAndRuleSplit.get(0);
					baselogicOperator = baselogicAndRuleSplit.get(1);
				} else {
					baseToleranceExprns.add(fieldExprnWithValue);
				}

			}

			// high operator
			List highComparsionOperatorWithValue = new ArrayList();
			if (!toleranceExpn.getHighComparsionOperator().isEmpty()) {
				ToleranceGetValues tolgetVal = new ToleranceGetValues();
				tolgetVal = getValuesOfExpression(toleranceExpn.getHighComparsionOperator(), new ArrayList(),
						xmlfieldsDTOList, xmlLookUpFieldMap, calcList, spotValidation, creditList);
				highComparsionOperatorWithValue.addAll(tolgetVal.getValuesList());
				calcValues.putAll(tolgetVal.getCalcValues());
				if (highComparsionOperatorWithValue.contains("Skip Rule")) {
					continue nextRule;
				}
				if (highComparsionOperatorWithValue.contains("% of")) {
					highComparsionOperatorWithValue = evaluatePercent(highComparsionOperatorWithValue);
				}
			}

			// high field value
			List highToleranceExprnWithValue = new ArrayList();
			if (!toleranceExpn.getHighTolerance().isEmpty()) {
				ToleranceGetValues tolgetVal = new ToleranceGetValues();

				highExprn = true;
				tolgetVal = getValuesOfExpression(toleranceExpn.getHighTolerance(), new ArrayList(), xmlfieldsDTOList,
						xmlLookUpFieldMap, calcList, spotValidation, creditList);
				highToleranceExprnWithValue.addAll(tolgetVal.getValuesList());
				calcValues.putAll(tolgetVal.getCalcValues());
				if (highToleranceExprnWithValue.contains("Skip Rule")) {
					continue nextRule;
				}
				if (highToleranceExprnWithValue.contains("% of")) {
					highToleranceExprnWithValue = evaluatePercent(highToleranceExprnWithValue);
				}

				highToleranceExprnWithValue = preprocessExpression(highToleranceExprnWithValue);

				if (highToleranceExprnWithValue.contains("OR") || highToleranceExprnWithValue.contains("AND")) {
					highMultipleExprn = true;
					highlogicAndRuleSplit = splitExpressionWithORAND(highToleranceExprnWithValue);
					highToleranceExprns = highlogicAndRuleSplit.get(0);
					highlogicOperator = highlogicAndRuleSplit.get(1);
				} else {
					highToleranceExprns.add(highToleranceExprnWithValue);
				}

			}
			if (lowExprn && lowComparsionOperatorWithValue.isEmpty()) {
				continue nextRule;

			}
			if (highExprn && highComparsionOperatorWithValue.isEmpty()) {
				continue nextRule;

			}

			List<List<String>> expressionList = new ArrayList();
			List<String> evaluatedExpressionList = new ArrayList();
			String result = "";
			if (lowExprn && baseExprn && !highExprn) {
				for (int i = 0; i < lowToleranceExprns.size(); i++) {
					List<String> seperateExpression = new ArrayList();
					for (int j = 0; j < baseToleranceExprns.size(); j++) {
						StringBuilder expressions = new StringBuilder();
						expressions.append(lowToleranceExprns.get(i).toString());
						expressions.append(lowComparsionOperatorWithValue.get(0).toString());
						expressions.append(baseToleranceExprns.get(j).toString());
						seperateExpression.add(expressions.toString());

					}
					expressionList.add(seperateExpression);

				}
				expressionList = processExpressionList(expressionList, lowlogicOperator, lowMultipleExprn,
						baselogicOperator, baseMultipleExprn);
				evaluatedExpressionList = process(expressionList);
				String listString = String.join("", evaluatedExpressionList);
				try {
					result = engine.eval(listString).toString();
				} catch (ScriptException e) {
					logger.info("Error Evaluating Final ExpressionList", e.getMessage());
				}

			}
			if (!lowExprn && baseExprn && highExprn) {
				for (int i = 0; i < baseToleranceExprns.size(); i++) {
					List<String> seperateExpression = new ArrayList();
					for (int j = 0; j < highToleranceExprns.size(); j++) {
						StringBuilder expressions = new StringBuilder();
						expressions.append(baseToleranceExprns.get(i));
						expressions.append(highComparsionOperatorWithValue.get(0));
						expressions.append(highToleranceExprns.get(j));
						seperateExpression.add(expressions.toString());
					}
					expressionList.add(seperateExpression);
				}
				expressionList = processExpressionList(expressionList, baselogicOperator, baseMultipleExprn,
						highlogicOperator, highMultipleExprn);
				evaluatedExpressionList = process(expressionList);
				String listString = String.join("", evaluatedExpressionList);
				try {
					result = engine.eval(listString).toString();
				} catch (ScriptException e) {
					logger.info("Error Evaluating Final ExpressionList", e.getMessage());
				}

			}

			if (lowExprn && baseExprn && highExprn) {
				StringBuilder finalExpression = new StringBuilder();

				// both low and high expressions
				for (int i = 0; i < lowToleranceExprns.size(); i++) {
					List<String> seperateExpression = new ArrayList();
					for (int j = 0; j < baseToleranceExprns.size(); j++) {
						StringBuilder expressions = new StringBuilder();
						expressions.append(lowToleranceExprns.get(i).toString());
						expressions.append(lowComparsionOperatorWithValue.get(0).toString());
						expressions.append(baseToleranceExprns.get(j).toString());
						seperateExpression.add(expressions.toString());

					}
					expressionList.add(seperateExpression);

				}
				expressionList = processExpressionList(expressionList, lowlogicOperator, lowMultipleExprn,
						baselogicOperator, baseMultipleExprn);
				evaluatedExpressionList = process(expressionList);
				String lString = String.join("", evaluatedExpressionList);
				finalExpression.append(lString);
				expressionList.clear();
				finalExpression.append("&&(");

				for (int i = 0; i < baseToleranceExprns.size(); i++) {
					List<String> seperateExpression = new ArrayList();
					for (int j = 0; j < highToleranceExprns.size(); j++) {
						StringBuilder expressions = new StringBuilder();
						expressions.append(baseToleranceExprns.get(i));
						expressions.append(highComparsionOperatorWithValue.get(0));
						expressions.append(highToleranceExprns.get(j));
						seperateExpression.add(expressions.toString());
					}
					expressionList.add(seperateExpression);
				}
				expressionList = processExpressionList(expressionList, baselogicOperator, baseMultipleExprn,
						highlogicOperator, highMultipleExprn);
				evaluatedExpressionList = process(expressionList);
				String rString = String.join("", evaluatedExpressionList);
				finalExpression.append(rString);
				finalExpression.append(")");
				try {
					result = engine.eval(finalExpression.toString()).toString();
				} catch (ScriptException e) {
					logger.info("Error Evaluating Final ExpressionList", e.getMessage());
				}

			}

			if (ifExprn) {
				StringBuilder sb = new StringBuilder();
				sb.append(ifEvalExprn.get(0).toString());
				if (ifEvalExprn.get(1).toString().equals("OR")) {
					sb.append("||");
				} else if (ifEvalExprn.get(1).toString().equals("AND")) {
					sb.append("&&");
				}
				sb.append(result);
				try {
					result = engine.eval(sb.toString()).toString();
				} catch (ScriptException e) {
					logger.info("Error Evaluating Final ExpressionList", e.getMessage());
				}
			}

			if (result.equals("true")) {

				if (rule.getPassmessage() != null) {
					String passMsg = rule.getPassmessage().getMessage();
					if (rule.getPassRuleValue() != null) {
						String[] passruleValuesArray = rule.getPassRuleValue().split(",");
						Pattern regex = Pattern.compile("\\{(RV.*?)\\}");
						Matcher regexMatcher = regex.matcher(passMsg);
						int i = 0;

						while (regexMatcher.find() && i < passruleValuesArray.length) {
							passMsg = regexMatcher.replaceFirst(passruleValuesArray[i]);
							i++;
							regexMatcher = regex.matcher(passMsg);

						}
					}

					Pattern regexCofield = Pattern.compile("\\{(Contract.*?)\\}");
					Matcher regexMatcherCofield = regexCofield.matcher(passMsg);

					while (regexMatcherCofield.find()) {

						String field = regexMatcherCofield.group(1).toString();
						String segments[] = field.split("Contract.");
						field = segments[segments.length - 1];
						String value = xmlFieldValueMap.get(field);
						passMsg = regexMatcherCofield.replaceFirst(value);
						regexMatcherCofield = regexCofield.matcher(passMsg);

					}
					Pattern regexCafield = Pattern.compile("\\{(Calculation.*?)\\}");
					Matcher regexMatcherCafield = regexCafield.matcher(passMsg);

					while (regexMatcherCafield.find()) {

						String field = regexMatcherCafield.group(1).toString();
						String segments[] = field.split("Calculation.");
						field = segments[segments.length - 1];

						String value = calcValues.get(field);
						passMsg = regexMatcherCafield.replaceFirst(value);
						regexMatcherCafield = regexCafield.matcher(passMsg);

					}
					Pattern regexCrfield = Pattern.compile("\\{(Credit.*?)\\}");
					Matcher regexMatcherCrfield = regexCrfield.matcher(passMsg);

					while (regexMatcherCrfield.find()) {

						String field = regexMatcherCrfield.group(1).toString();
						String segments[] = field.split("Credit.");
						field = segments[segments.length - 1];
						CreditDecision creditDecision = creditList.get(0);
						HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
						if (map.get(field) != null) {
							String value = map.get(field).toString();
							passMsg = regexMatcherCrfield.replaceFirst(value);
							regexMatcherCrfield = regexCrfield.matcher(passMsg);
						}

					}

					rulepassedmap.put(rule, passMsg);

				} else {
					rulepassedmap.put(rule, "NO VAL");

				}

			} else if (result.equals("false")) {
				if (rule.getFailmessage() != null) {
					String failMsg = rule.getFailmessage().getMessage();
					if (rule.getFailRuleValue() != null) {
						String[] failruleValuesArray = rule.getFailRuleValue().split(",");
						Pattern regex = Pattern.compile("\\{(RV.*?)\\}");
						Matcher regexMatcher = regex.matcher(failMsg);
						int i = 0;

						while (regexMatcher.find() && i < failruleValuesArray.length) {
							failMsg = regexMatcher.replaceFirst(failruleValuesArray[i]);
							i++;
							regexMatcher = regex.matcher(failMsg);

						}
					}
					Pattern regexCofield = Pattern.compile("\\{(Contract.*?)\\}");
					Matcher regexMatcherCofield = regexCofield.matcher(failMsg);

					while (regexMatcherCofield.find()) {

						String field = regexMatcherCofield.group(1).toString();
						String segments[] = field.split("Contract.");
						field = segments[segments.length - 1];
						String value = xmlFieldValueMap.get(field);
						failMsg = regexMatcherCofield.replaceFirst(value);
						regexMatcherCofield = regexCofield.matcher(failMsg);

					}
					Pattern regexCafield = Pattern.compile("\\{(Calculation.*?)\\}");
					Matcher regexMatcherCafield = regexCafield.matcher(failMsg);

					while (regexMatcherCafield.find()) {

						String field = regexMatcherCafield.group(1).toString();
						String segments[] = field.split("Calculation.");
						field = segments[segments.length - 1];
						String value = calcValues.get(field);
						failMsg = regexMatcherCafield.replaceFirst(value);
						regexMatcherCafield = regexCafield.matcher(failMsg);

					}
					Pattern regexCrfield = Pattern.compile("\\{(Credit.*?)\\}");
					Matcher regexMatcherCrfield = regexCrfield.matcher(failMsg);

					while (regexMatcherCrfield.find()) {

						String field = regexMatcherCrfield.group(1).toString();
						String segments[] = field.split("Credit.");
						field = segments[segments.length - 1];
						CreditDecision creditDecision = creditList.get(0);
						HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
						if (map.get(field) != null) {
							String value = map.get(field).toString();
							failMsg = regexMatcherCrfield.replaceFirst(value);
							regexMatcherCrfield = regexCrfield.matcher(failMsg);
						}
					}
					failedrulemap.put(rule, failMsg);

				} else {
					failedrulemap.put(rule, "NO VAL");
				}

			}

		}

		if (!failedrulemap.isEmpty()) {

			if (failedrulemap.size() > 1) {
				int failCount = 0;

				for (Entry<Rule, String> rulemsgpair : failedrulemap.entrySet()) {

					RuleAudit ruleAudit = new RuleAudit();
					logger.info("Failed Regulation Rule {}", rulemsgpair.getKey());

					ruleAudit.setRuleExecutionResult(fail);
					ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
					ruleAudit.setXmlId(processAudit.getXmlId());
					ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
					ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
					ruleAudit.setMessageResponse(rulemsgpair.getValue());
					ruleAudit.setRule(rulemsgpair.getKey());
					if (rulemsgpair.getValue().equals("NO VAL")) {
						ruleAuditService.saveRuleAudit(ruleAudit);
						failCount++;
						continue;
					}
					failureAuditMessage.append(rulemsgpair.getValue());
					failureAuditMessage.append("  +  ");
					ruleAuditService.saveRuleAudit(ruleAudit);

				}
				if (failCount == failedrulemap.size()) {
					failureAuditMessage.append("");
					failureAuditMessage.append("  +  ");
				}

			}

			else if (failedrulemap.size() == 1) {
				for (Entry<Rule, String> rulemsgpair : failedrulemap.entrySet()) {
					String val = "";
					RuleAudit ruleAudit = new RuleAudit();
					logger.info("Failed Regulation Rule {}", rulemsgpair.getKey());

					ruleAudit.setRuleExecutionResult(fail);
					ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
					ruleAudit.setXmlId(processAudit.getXmlId());
					ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
					ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
					ruleAudit.setMessageResponse(rulemsgpair.getValue());
					ruleAudit.setRule(rulemsgpair.getKey());
					val = rulemsgpair.getValue();
					if (rulemsgpair.getValue().equals("NO VAL")) {
						val = val.replace("NO VAL", "");
					}
					failureAuditMessage.append(val);
					failureAuditMessage.append("  +  ");

					ruleAuditService.saveRuleAudit(ruleAudit);
				}
			}

		}
		if (!rulepassedmap.isEmpty()) {

			if (rulepassedmap.size() > 1) {
				int passCount = 0;
				for (Entry<Rule, String> rulemsgpair : rulepassedmap.entrySet()) {
					RuleAudit ruleAudit = new RuleAudit();
					logger.info("Passed Regulation Rule {}", rulemsgpair.getKey());
					ruleAudit.setRuleExecutionResult(pass);
					ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
					ruleAudit.setXmlId(processAudit.getXmlId());
					ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
					ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
					ruleAudit.setRule(rulemsgpair.getKey());
					ruleAudit.setMessageResponse(rulemsgpair.getValue());
					if (rulemsgpair.getValue().equals("NO VAL")) {
						ruleAuditService.saveRuleAudit(ruleAudit);
						passCount++;
						continue;
					}
					passAuditMessage.append(rulemsgpair.getValue());
					passAuditMessage.append("  +  ");
					ruleAuditService.saveRuleAudit(ruleAudit);

				}
				if (passCount == rulepassedmap.size()) {
					passAuditMessage.append("");
					passAuditMessage.append("  +  ");
				}
			} else if (rulepassedmap.size() == 1) {
				for (Entry<Rule, String> rulemsgpair : rulepassedmap.entrySet()) {
					String val = "";
					RuleAudit ruleAudit = new RuleAudit();
					logger.info("Passed Regulation Rule {}", rulemsgpair.getKey());
					ruleAudit.setRuleExecutionResult(pass);
					ruleAudit.setRcid(rulemsgpair.getKey().getRuleClassification().getId());
					ruleAudit.setXmlId(processAudit.getXmlId());
					ruleAudit.setLookupCriteria(rulemsgpair.getKey().getLookupCriteria());
					ruleAudit.setRulelogic(rulemsgpair.getKey().getRuleLogic());
					ruleAudit.setRule(rulemsgpair.getKey());
					val = rulemsgpair.getValue();
					if (rulemsgpair.getValue().equals("NO VAL")) {
						val = val.replace("NO VAL", "");
					}
					ruleAudit.setMessageResponse(val);
					passAuditMessage.append(val);
					passAuditMessage.append("  +  ");
					ruleAuditService.saveRuleAudit(ruleAudit);

				}
			}

		}

		processAudit.settValidationEnd(new Timestamp(System.currentTimeMillis()));

		if (rulepassedmap.isEmpty() && !failedrulemap.isEmpty()) {
			processAudit.settValidationResult(passmessage + " " + " || " + failmessage + " "
					+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
		} else if (!rulepassedmap.isEmpty() && !failedrulemap.isEmpty()) {
			if (!passAuditMessage.toString().isEmpty()) {

				processAudit.settValidationResult(passmessage + " "
						+ passAuditMessage.toString().substring(0, passAuditMessage.toString().length() - 3) + " || "
						+ failmessage + " "
						+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
			}
			if (passAuditMessage.toString().isEmpty()) {
				processAudit.settValidationResult(passmessage + " " + " || " + failmessage + " "
						+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
			}
		} else if (failedrulemap.isEmpty() && !rulepassedmap.isEmpty()) {
			if (!passAuditMessage.toString().isEmpty()) {
				processAudit.settValidationResult(passmessage + " "
						+ passAuditMessage.toString().substring(0, passAuditMessage.toString().length() - 3) + auditPass
						+ " || " + failmessage + " ");
			}
			if (passAuditMessage.toString().isEmpty()) {
				processAudit.settValidationResult(passmessage + " " + auditPass + " || " + failmessage + " ");
			}
		}
		if (rulepassedmap.isEmpty() && failedrulemap.isEmpty()) {

			processAudit.settValidationResult(norule);
		}
		logger.info("Tolerance Rules Processing Ends...");
		return Optional.empty();

	}

	private Map<Integer, List> evaluateIfExists(List lowToleranceExprnWithValue, Map<String, String> xmlFieldValueMap,
			List<Calculation> calcList, List<XMLFieldsDTO> xmlfieldsDTOList, Map<String, String> xmlLookUpFieldMap,
			Boolean spotValidation, List<CreditDecision> creditList) {

		List ruleExpressionCalc = new ArrayList();
		List modifiedLowToleranceExprnWithValue = new ArrayList();

		Map<Integer, List> subLists = new HashMap<>();
		Boolean[] regulationRuleQualifier = { false };
		int indexofLowerOf = lowToleranceExprnWithValue.indexOf("IFEXIST");
		// put the source here
		if (lowToleranceExprnWithValue.get(indexofLowerOf + 1).equals("CO")) {
			regulationRuleQualifier[0] = true;
			if (xmlFieldValueMap.containsKey(lowToleranceExprnWithValue.get(indexofLowerOf + 2))) {
				if (!xmlFieldValueMap.get(lowToleranceExprnWithValue.get(indexofLowerOf + 2)).equals("")) {
					ruleExpressionCalc.add("true");
					ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));
				} else {
					ruleExpressionCalc.add("false");
					ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));
				}
			} else {
				ruleExpressionCalc.add("false");
				ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));
			}

			modifiedLowToleranceExprnWithValue = lowToleranceExprnWithValue.subList(indexofLowerOf + 4,
					lowToleranceExprnWithValue.size());
			subLists.put(0, ruleExpressionCalc);
			subLists.put(1, modifiedLowToleranceExprnWithValue);
		}

		if (lowToleranceExprnWithValue.get(indexofLowerOf + 1).equals("CA")) {

			for (int j = 0; j < calcList.size(); j++) {

				if (calcList.get(j).getCalculationName().equals(lowToleranceExprnWithValue.get(indexofLowerOf + 2))) {
					if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
							|| calcList.get(j).getFinanceType().isEmpty()
							|| calcList.get(j).getFinanceType() == null) {
						if (calcList.get(j).getState().equals(xmlFieldValueMap.get("ContractExecutionState"))
								|| calcList.get(j).getState().isEmpty() || calcList.get(j).getState() == null) {
							if (calcList.get(j).getLender().equals(xmlFieldValueMap.get("LenderPartyId"))
									|| calcList.get(j).getLender().isEmpty()
									|| calcList.get(j).getLender() == null) {
								regulationRuleQualifier[0] = true;
								try {
									String reResult = getCalculatedValue(calcList.get(j).getCalculationJSON(),
											xmlfieldsDTOList, xmlFieldValueMap, calcList, spotValidation, creditList);
									if (reResult.equals("Skip Rule")) {
										regulationRuleQualifier[0] = false;
										break;
									}
									ruleExpressionCalc.add("true");
									ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));
								} catch (IOException e) {
									logger.error(
											"Exception while Rule Builder Rule Logic Expression Proccessing, in Calculation",
											e.getMessage());
								}
							} else {
								regulationRuleQualifier[0] = false;
								break;
							}
						} else {
							regulationRuleQualifier[0] = false;
							break;
						}
					} else {
						regulationRuleQualifier[0] = false;
						break;
					}
				}

			}

			if (!regulationRuleQualifier[0]) {
				ruleExpressionCalc.add("false");
				ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));
			}

			modifiedLowToleranceExprnWithValue = lowToleranceExprnWithValue.subList(indexofLowerOf + 4,
					lowToleranceExprnWithValue.size());
			subLists.put(0, ruleExpressionCalc);
			subLists.put(1, modifiedLowToleranceExprnWithValue);
		}
		if (lowToleranceExprnWithValue.get(indexofLowerOf + 1).equals("CR")) {
			if (!spotValidation) {
				CreditDecision creditDecision = creditList.get(0);
				HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
				if (map.get(indexofLowerOf + 2) != null) {
					ruleExpressionCalc.add("true");
					ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));
				} else {
					ruleExpressionCalc.add("false");
					ruleExpressionCalc.add(lowToleranceExprnWithValue.get(indexofLowerOf + 3));

				}
				modifiedLowToleranceExprnWithValue = lowToleranceExprnWithValue.subList(indexofLowerOf + 4,
						lowToleranceExprnWithValue.size());
				subLists.put(0, ruleExpressionCalc);
				subLists.put(1, modifiedLowToleranceExprnWithValue);
			}
		}

		return subLists;
	}

	private List<List<String>> processExpressionList(List<List<String>> expressionList, List lowlogicOperator,
			Boolean lowMultipleExprn, List baselogicOperator, Boolean baseMultipleExprn) {
		List<List<String>> finalexpressionList = new ArrayList();

		if (lowMultipleExprn) {
			for (int i = 0; i < lowlogicOperator.size(); i++) {

				List<String> tempOpeartor = new ArrayList();
				if (lowlogicOperator.get(i).toString().contains("AND")) {
					tempOpeartor.add("&&");

				}
				if (lowlogicOperator.get(i).toString().contains("OR")) {
					tempOpeartor.add("||");

				}

				expressionList.add(i + 1, tempOpeartor);
			}
		}

		if (baseMultipleExprn) {

			for (int i = 0; i < expressionList.size(); i++) {
				List<String> intermediateExpression = new ArrayList();
				List<String> expr = expressionList.get(i);
				if (expr.toString().contains("&&") || expr.toString().contains("||")) {
					finalexpressionList.add(expr);
					continue;
				}
				String[] array = expr.stream().toArray(String[]::new);
				for (int j = 0; j < baselogicOperator.size(); j++) {
					StringBuilder expressions = new StringBuilder();
					expressions.append(array[j].toString());
					if (baselogicOperator.get(j).toString().contains("AND")) {
						expressions.append("&&");
					}
					if (baselogicOperator.get(j).toString().contains("OR")) {
						expressions.append("||");
					}

					if (j == baselogicOperator.size() - 1) {
						expressions.append(array[j + 1].toString());

					}
					intermediateExpression.add(expressions.toString());
					finalexpressionList.add(intermediateExpression);
				}

			}

		}
		if (!baseMultipleExprn && !lowMultipleExprn) {
			finalexpressionList.addAll(expressionList);
		}
		if (!baseMultipleExprn && lowMultipleExprn) {
			finalexpressionList.addAll(expressionList);
		}

		return finalexpressionList;

	}

	private List<String> process(List<List<String>> expressionList) {

		List<String> evaluatedExpressionList = new ArrayList();
		for (List<String> expression : expressionList) {
			for (String ex : expression) {
				ex = ex.replaceAll("[\\[\\](){}]", "");
				ex = ex.replaceAll(",", "");

				evaluatedExpressionList.add(ex);

			}
		}
		return evaluatedExpressionList;
	}

	private List preprocessExpression(List lowToleranceExprnWithValue) {
		List higherOfExprn = new ArrayList();

		List lowerOfExprn = new ArrayList();
		if (lowToleranceExprnWithValue.contains("Higher of")) {

			List<List> higherOfExprnSubList = new ArrayList<>();

			higherOfExprn = gethigherOfExpression(lowToleranceExprnWithValue);

			higherOfExprnSubList = sublistExpression(higherOfExprn);
			double max = 0;
			List higherOfExpnValues = new ArrayList();
			if (higherOfExprnSubList != null) {
				for (int i = 0; i < higherOfExprnSubList.size(); i++) {

					if (higherOfExprnSubList.get(i) != null) {

						if (higherOfExprnSubList.get(i).contains("+") || higherOfExprnSubList.get(i).contains("-")
								|| higherOfExprnSubList.get(i).contains("*")
								|| higherOfExprnSubList.get(i).contains("/")) {
							higherOfExpnValues.add(evaluateOfExprn(higherOfExprnSubList.get(i)));

						} else {

							if (!higherOfExprnSubList.get(i).isEmpty()) {
								String listString = String.join("", higherOfExprnSubList.get(i));
								higherOfExpnValues.add(listString);
							}
						}
					}

				}

				for (int i = 0; i < higherOfExpnValues.size(); i++) {

					max = Math.max(Double.valueOf(higherOfExpnValues.get(i).toString()), max);
				}

			}
			lowToleranceExprnWithValue.clear();
			lowToleranceExprnWithValue.add(max);

		}

		if (lowToleranceExprnWithValue.contains("Lesser of")) {

			List<List> lowerOfExprnSubList = new ArrayList<>();

			lowerOfExprn = getlowerOfExpression(lowToleranceExprnWithValue);

			lowerOfExprnSubList = sublistExpression(lowerOfExprn);
			double min = 0;
			List<String> lowerOfExpnValues = new ArrayList();
			if (lowerOfExprnSubList != null) {
				for (int i = 0; i < lowerOfExprnSubList.size(); i++) {

					if (lowerOfExprnSubList.get(i) != null) {

						if (lowerOfExprnSubList.get(i).contains("+") || lowerOfExprnSubList.get(i).contains("-")
								|| lowerOfExprnSubList.get(i).contains("*")
								|| lowerOfExprnSubList.get(i).contains("/")) {
							lowerOfExpnValues.add(evaluateOfExprn(lowerOfExprnSubList.get(i)));

						} else {

							if (!lowerOfExprnSubList.get(i).isEmpty()) {
								String listString = String.join("", lowerOfExprnSubList.get(i));
								lowerOfExpnValues.add(listString);
							}
						}
					}

				}

				if (Double.parseDouble(lowerOfExpnValues.get(0)) > Double.parseDouble(lowerOfExpnValues.get(1))) {
					min = Double.valueOf(lowerOfExpnValues.get(1));
				} else {
					min = Double.valueOf(lowerOfExpnValues.get(0));
				}
				lowToleranceExprnWithValue.clear();
				lowToleranceExprnWithValue.add(min);

			}
		}
		return lowToleranceExprnWithValue;
	}

	private List<List> sublistExpression(List higherOfExprn) {
		List<List> higherOfExprnSubList = new ArrayList<>();
		int j = 0;
		List<String> higherOfORList = new ArrayList<>();
		for (int i = 0; i < higherOfExprn.size(); i++) {
			if (higherOfExprn.get(i).equals("OR")) {
				higherOfExprnSubList.add(higherOfExprn.subList(j, i));

				j = i + 1;
				higherOfORList.add((String) higherOfExprn.get(i));
			}
			if (i == higherOfExprn.size() - 1) {
				higherOfExprnSubList.add(higherOfExprn.subList(j, i + 1));
			}
		}
		return higherOfExprnSubList;
	}

	private List gethigherOfExpression(List lowToleranceExprnWithValue) {
		List higherOfExprn = new ArrayList<>();
		int indexofHigherOf = lowToleranceExprnWithValue.indexOf("Higher of");
		HashMap<String, Integer> openClosePair = new HashMap<>();
		openClosePair.put("(", 0);
		openClosePair.put(")", 0);

		for (int i = indexofHigherOf + 1; i < lowToleranceExprnWithValue.size();) {
			if (lowToleranceExprnWithValue.get(i).equals("(")) {
				openClosePair.put("(", openClosePair.get("(") + 1);
			}

			if (lowToleranceExprnWithValue.get(i).equals(")")) {
				openClosePair.put(")", openClosePair.get(")") + 1);

			}
			int value = openClosePair.get("(") - openClosePair.get(")");
			if (value != 0) {
				i++;
			}
			if (value == 0) {
				higherOfExprn = lowToleranceExprnWithValue.subList(indexofHigherOf + 2, i);
				i++;
			}

		}

		return higherOfExprn;
	}

	private List getlowerOfExpression(List lowToleranceExprnWithValue) {
		List lowerOfExprn = new ArrayList<>();
		int indexofLowerOf = lowToleranceExprnWithValue.indexOf("Lesser of");
		HashMap<String, Integer> openClosePair = new HashMap<>();
		openClosePair.put("(", 0);
		openClosePair.put(")", 0);

		for (int i = indexofLowerOf + 1; i < lowToleranceExprnWithValue.size();) {
			if (lowToleranceExprnWithValue.get(i).equals("(")) {
				openClosePair.put("(", openClosePair.get("(") + 1);
			}

			if (lowToleranceExprnWithValue.get(i).equals(")")) {
				openClosePair.put(")", openClosePair.get(")") + 1);

			}
			int value = openClosePair.get("(") - openClosePair.get(")");
			if (value != 0) {
				i++;
			}
			if (value == 0) {
				lowerOfExprn = lowToleranceExprnWithValue.subList(indexofLowerOf + 2, i);

			}

		}

		return lowerOfExprn;
	}

	public ToleranceGetValues getValuesOfExpression(List<ToleranceRule> exp, List toleranceruleExpressionList,
			List<XMLFieldsDTO> xmlfieldsDTOList, Map<String, String> xmlFieldValueMap, List<Calculation> calcList,
			Boolean spotValidation, List<CreditDecision> creditList) {
		ToleranceGetValues tolvalues = new ToleranceGetValues();
		HashMap<String, String> calcValues = new HashMap();
		for (int i = 0; i < exp.size(); i++) {

			Boolean[] regulationRuleQualifier = { false };

			if (exp.get(i).getExpressionType().equals(ToleranceRule.ExpressionType.FIELD)) {

				if (exp.get(i).getFieldExpressionPrefix().equals("CO")) {
					String field = exp.get(i).getValue();

					// if values not present in the xml skip it.

					for (XMLFieldsDTO xmlField : xmlfieldsDTOList) {

						if (field.equals(xmlField.getFieldName())) {
							regulationRuleQualifier[0] = true;

							logger.info("FieldName {} and FieldValue from XML {}", xmlField.getFieldName(), field);

							if (xmlField.getFieldType().equals("NUMERIC")
									|| xmlField.getFieldType().equals("TEXT")) {
								toleranceruleExpressionList.add(xmlField.getFieldValue());

							}
							break;

						}

					}
				}
				if (exp.get(i).getFieldExpressionPrefix().equals("CR")) {
					regulationRuleQualifier[0] = true;
					if (spotValidation) {
						regulationRuleQualifier[0] = false;
					}
					if (!spotValidation) {
						CreditDecision creditDecision = creditList.get(0);
						String creditfield = exp.get(i).getValue();
						HashMap<String, Object> map = getCreditDecisionMapping(creditDecision);
						if (map.get(creditfield) != null) {
							toleranceruleExpressionList.add(map.get(creditfield).toString());
						} else if (map.get(creditfield) == null) {
							regulationRuleQualifier[0] = false;
						}
					}

				}
				if (exp.get(i).getFieldExpressionPrefix().equals("CA")) {
					String field = exp.get(i).getValue();
					regulationRuleQualifier[0] = true;
					for (int j = 0; j < calcList.size(); j++) {

						if (calcList.get(j).getCalculationName().equals(field)) {
							if (calcList.get(j).getFinanceType().equals(xmlFieldValueMap.get("FinanceType"))
									|| calcList.get(j).getFinanceType().isEmpty()
									|| calcList.get(j).getFinanceType() == null) {
								if (calcList.get(j).getState().equals(xmlFieldValueMap.get("ContractExecutionState"))
										|| calcList.get(j).getState().isEmpty()
										|| calcList.get(j).getState() == null) {
									if (calcList.get(j).getLender().equals(xmlFieldValueMap.get("LenderPartyId"))
											|| calcList.get(j).getLender().isEmpty()
											|| calcList.get(j).getLender() == null) {
										regulationRuleQualifier[0] = true;
										try {
											String reResult = getCalculatedValue(calcList.get(j).getCalculationJSON(),
													xmlfieldsDTOList, xmlFieldValueMap, calcList, spotValidation,
													creditList);
											if (reResult.equals("Skip Rule")) {
												regulationRuleQualifier[0] = false;
												break;
											}
											toleranceruleExpressionList.add(reResult);
											calcValues.put(calcList.get(j).getCalculationName(), reResult);
										} catch (IOException e) {
											logger.error(
													"Exception while Rule Builder Rule Logic Expression Proccessing, in Calculation",
													e.getMessage());
										}
									} else {
										regulationRuleQualifier[0] = false;
										break;
									}
								} else {
									regulationRuleQualifier[0] = false;
									break;
								}
							} else {
								regulationRuleQualifier[0] = false;
								break;
							}
						}

					}

				}
				if (!regulationRuleQualifier[0]) {
					toleranceruleExpressionList.clear();
					toleranceruleExpressionList.add("Skip Rule");
					tolvalues.setValuesList(toleranceruleExpressionList);
					tolvalues.setCalcValues(calcValues);
					return tolvalues;

				}

			}

			if (exp.get(i).getExpressionType().equals(ToleranceRule.ExpressionType.OPERATOR)) {
				String op = exp.get(i).getValue();

				if (op.equals("IFEXIST")) {
					toleranceruleExpressionList.add(op);
					toleranceruleExpressionList.add(exp.get(i + 1).getFieldExpressionPrefix());
					toleranceruleExpressionList.add(exp.get(i + 1).getValue());
					i++;
					continue;

				}
				toleranceruleExpressionList.add(op);
			}

			if (exp.get(i).getExpressionType().equals(ToleranceRule.ExpressionType.VALUE)) {
				String value = exp.get(i).getValue();
				toleranceruleExpressionList.add(value);

			}

		}
		tolvalues.setValuesList(toleranceruleExpressionList);
		tolvalues.setCalcValues(calcValues);
		return tolvalues;
	}

	public List evaluatePercent(List expressionListwithPercent) {
		if (expressionListwithPercent.contains("% of")) {

			expressionListwithPercent = getPercentageEval(expressionListwithPercent);

		}
		return expressionListwithPercent;
	}

	public String evaluateOfExprn(List higherOfExpression) {

		String val = null;
		if (!higherOfExpression.isEmpty()) {
			String listString = String.join("", higherOfExpression);
			ScriptEngineManager mgr = new ScriptEngineManager();
			ScriptEngine engine = mgr.getEngineByName("nashorn");
			try {
				val = engine.eval(listString.toString()).toString();
				val = NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val);
			} catch (ScriptException e) {
				logger.info("Error Evaluating HigherOFExpression", e.getMessage());
			}
		}

		return val;
	}

	public HashMap<Integer, List<List>> splitExpressionWithORAND(List expressionListwithORAND) {
		List<List> logicalOperatorList = new ArrayList<>();
		int j = 0;

		List<List> fieldExprnSubLists = new ArrayList<>();

		HashMap<Integer, List<List>> expressionSplit = new HashMap<Integer, List<List>>();

		for (int i = 0; i < expressionListwithORAND.size(); i++) {
			if (expressionListwithORAND.get(i).equals("OR") || expressionListwithORAND.get(i).equals("AND")) {
				fieldExprnSubLists.add(expressionListwithORAND.subList(j, i));

				j = i + 1;
				List logicalOperator = new ArrayList<>();
				logicalOperator.add(expressionListwithORAND.get(i));
				logicalOperatorList.add(logicalOperator);
			}
			if (i == expressionListwithORAND.size() - 1) {
				fieldExprnSubLists.add(expressionListwithORAND.subList(j, i + 1));
			}
		}
		expressionSplit.put(0, fieldExprnSubLists);
		expressionSplit.put(1, logicalOperatorList);
		return expressionSplit;
	}

	public int getKeysFromValue(TreeMap<Integer, String> hirearchyMap, String value) {
		int valfromKey = 0;
		for (Integer val : hirearchyMap.keySet()) {
			if (hirearchyMap.get(val).equals(value)) {
				valfromKey = val;
			}
		}
		return valfromKey;
	}

	double calculatePercentage(double obtained, double comparefieldVal) {
		return obtained * comparefieldVal / 100;
	}

	/**
	 * @param rulelist
	 * @param xmlLookUpFieldMap
	 * @return
	 */
	public Optional<LookUpCriteriaPassRules> lookupFieldCheck(List<Rule> rulelist,
			Map<String, String> xmlLookUpFieldMap) {
		final LocalDateTime start = LocalDateTime.now();
		int sizeOfRules = rulelist == null || rulelist.isEmpty() ? 0 : rulelist.size();
		logger.debug("Entered lookupFieldCheck() method of ProcessRuleServiceImpl class. Size of rules: {}", sizeOfRules);

		LookUpCriteriaPassRules lookUpCriteriaPassRules = new LookUpCriteriaPassRules();
		List<StringentRuleQualification> stringentRuleList = new ArrayList<>();

		TreeMap<Integer, String> hirerachyTreeMap = new TreeMap<>();
		hirerachyTreeMap.put(1, "ContractExecutionState");
		hirerachyTreeMap.put(2, "FinanceType");
		hirerachyTreeMap.put(3, "ApplicationType");
		hirerachyTreeMap.put(4, "ProductType");
		hirerachyTreeMap.put(5, "LenderPartyId");

		List<Rule> masterrulelist = new ArrayList<>();

		outerloop: for (Rule rule : rulelist) {
			logger.info("Rules for LookUp Proccessing...{}", rule);

			HashMap<String, String> lookupWithHirearchy = new HashMap<>();
			HashMap<String, String> lookupNoHirearchy = new HashMap<>();
			ObjectMapper mapper = new ObjectMapper();
			LinkedHashMap<String, String> lookupCriteriaMap = new LinkedHashMap<>();

			Boolean stringentRule = false;

			int stringentlookupFieldCount = 0;
			TreeMap<Integer, Boolean> stringentRuleQualifier = new TreeMap<>();
			StringentRuleQualification sRQ = new StringentRuleQualification();
			List<Integer> stringentRuleHierarchyList = new ArrayList<>();

			Boolean ruleQualifier = false;
			int lookupFieldCount = 0;

			String lookupCriteria = rule.getLookupCriteria();

			TypeReference<LinkedHashMap<String, String>> typeRef = new TypeReference<LinkedHashMap<String, String>>() {
			};

			try {
				lookupCriteriaMap = mapper.readValue(lookupCriteria, typeRef);
			} catch (Exception e) {
				logger.error("Exception while parsing lookup fields " + e.getMessage());
				throw new BadRequestException("Exception while parsing lookup fields " + e.getMessage());
			}
			StringBuilder masterRuleString = new StringBuilder();
			masterRuleString
			.append(lookupCriteriaMap.toString().substring(1, lookupCriteriaMap.toString().length() - 1));

			if (masterRuleString.length() == 0) {
				masterrulelist.add(rule);
				continue;
			}

			for (String lookupName : lookupCriteriaMap.keySet()) {

				if (xmlLookUpFieldMap.containsKey(lookupName)) {

					if (hirerachyTreeMap.containsValue(lookupName)) {
						lookupWithHirearchy.put(lookupName, lookupCriteriaMap.get(lookupName));
					} else if (xmlLookUpFieldMap.containsKey(lookupName)
							&& !hirerachyTreeMap.containsValue(lookupName)) {
						lookupNoHirearchy.put(lookupName, lookupCriteriaMap.get(lookupName));
					}
				} else {

					continue outerloop;

				}

			}
			if (!lookupWithHirearchy.isEmpty()) {
				lookupWithHirearchy = lookupWithHirearchy.entrySet().stream()
						.sorted((e1, e2) -> Integer.compare(getKeysFromValue(hirerachyTreeMap, e1.getKey()),
								getKeysFromValue(hirerachyTreeMap, e2.getKey())))
						.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1,
								LinkedHashMap::new));
			}

			for (String lookupName : hirerachyTreeMap.values()) {

				if (lookupWithHirearchy.containsKey(lookupName)) {

					if (xmlLookUpFieldMap.get(lookupName).equals(lookupWithHirearchy.get(lookupName))) {

						stringentRule = true;
						stringentlookupFieldCount++;
						stringentRuleQualifier.put(getKeysFromValue(hirerachyTreeMap, lookupName), true);
						stringentRuleHierarchyList.add(getKeysFromValue(hirerachyTreeMap, lookupName));

					}

					if (!xmlLookUpFieldMap.get(lookupName).equals(lookupWithHirearchy.get(lookupName))) {

						continue outerloop;

					}

				} else {

					if (stringentRuleQualifier.isEmpty()) {
						stringentRule = false;
					} else {
						stringentRule = true;
					}

				}

			}

			sRQ.setStringentRuleLookUpCount(stringentlookupFieldCount);
			sRQ.setStringentRuleHierarchyList(stringentRuleHierarchyList);
			sRQ.setStringentRule(rule);

			for (String lookupName : lookupNoHirearchy.keySet()) {
				if (xmlLookUpFieldMap.containsKey(lookupName)) {

					if (xmlLookUpFieldMap.get(lookupName).equals(lookupNoHirearchy.get(lookupName))) {
						lookupFieldCount++;
						ruleQualifier = true;

					}

					if (!xmlLookUpFieldMap.get(lookupName).equals(lookupNoHirearchy.get(lookupName))) {
						continue outerloop;
					}
				} else {

					continue outerloop;
				}

			}
			sRQ.setTotalLookUpCount(lookupFieldCount);

			if (stringentRule && ruleQualifier) {
				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}

			}
			if (!stringentRule && ruleQualifier) {
				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}
			}

			if (stringentRule && lookupNoHirearchy.isEmpty()) {

				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}

			}
			if (lookupWithHirearchy.isEmpty() && ruleQualifier) {
				if (!stringentRuleList.contains(sRQ)) {

					stringentRuleList.add(sRQ);
				}
			}

		}
		if (stringentRuleList.isEmpty() && !masterrulelist.isEmpty()) {
			logger.info("No Stringent Rules Qualified, Generic Rules Qualified : {}", masterrulelist);
			lookUpCriteriaPassRules.setMasterPassedMap(masterrulelist);
		}
		if (!stringentRuleList.isEmpty()) {
			logger.info("Stringent Rules Qualified : {} ", stringentRuleList);
			lookUpCriteriaPassRules.setStringentQualifuRuleList(stringentRuleList);
		}
		final LocalDateTime end = LocalDateTime.now();
		logger.debug("lookupFieldCheck took {} MILLISECONDS", ChronoUnit.MILLIS.between(start, end));
		return Optional.of(lookUpCriteriaPassRules);
	}
	
	/**
	 * Determine if this deal requires SPOT validation
	 * 
	 * @param xmlFieldValueMap - the map of all incoming XML fields
	 * @param creditDecisionList - the list of CreditDecision found for this deal
	 * @return true if this deal requires SPOT validation, false otherwise
	 */
	public Boolean isSpotValidation(Map<String, String> xmlFieldValueMap, List<CreditDecision> creditDecisionList) {
		logger.debug("Entered isSpotValidation() method of ProcessRuleServiceImpl class.");
		if (xmlFieldValueMap.containsKey(Constants.SPOT_DELIVERY_IND_TAG_NAME)) {
			String spotField = xmlFieldValueMap.get(Constants.SPOT_DELIVERY_IND_TAG_NAME);
			if (spotField == null || spotField.isEmpty()) {
				// SpotDeliveryInd not set
				logger.debug("SpotDeliveryInd not set");
				return false;
			}
			else {
				try {
					int spotInd = Integer.parseInt(spotField);
					if (spotInd == 1) {
						if (creditDecisionList != null && !creditDecisionList.isEmpty()) {
							// Both credit app and spot indicator found
							// Will use credit app and set SpotDeliveryInd to 0
							xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
							logger.debug("Will use credit app and set SpotDeliveryInd to 0");
							return false;
						}
						else {
							// SpotDeliveryInd = 1
							return true;
						}
					}
					else {
						// SpotDeliveryInd = 0
						return false;
					}
				} catch (NumberFormatException nfe) {
					// SpotDeliveryInd was invalid
					logger.debug("SpotDeliveryInd is not a number: " + nfe);
					logger.debug("Setting SpotDeliveryInd to 0");
					xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
					return false;
				}
			}
		}
		else {
			// SpotDeliveryInd not in XML fields
			logger.debug("SpotDeliveryInd not in XML fields");
			return false;
		}
	}
	
	public List<CreditDecision> getCreditList(Map<String, String> xmlFieldValueMap, 
								List<CreditDecision> creditDecisionList) {
		logger.debug("Entered getCreditList() method of ProcessRuleServiceImpl class.");
		List<CreditDecision> creditList = new ArrayList<CreditDecision>();
		if (creditDecisionList != null && !creditDecisionList.isEmpty()) {
			CreditDecision creditDecision = creditDecisionList.get(0);
			String applicationNumber = xmlFieldValueMap.get("ApplicationNumber");
			if (applicationNumber != null && applicationNumber.equals(creditDecision.getApplicationNumber())) {
				logger.debug("ApplicationNumber provided with CV matched the one in the most recent CreditDecision");
				creditList.add(creditDecision);
			}

			//No application number match. Going for Credit Decisions from VIN search.
			if (creditList.isEmpty())
			{
				logger.debug("ApplicationNumber match failed! Working with CreditDecision(s) from VIN search");
				creditList.addAll(creditDecisionList);
			}
		}
		
		return creditList;
	}
	
	public Boolean validateCreditDecisionOrSpot(Map<String, String> xmlFieldValueMap, ProcessAudit processAudit,
					List<CreditDecision> creditDecisionList) {
		logger.debug("Entered validateCreditDecisionOrSpot() method of ProcessRuleServiceImpl class.");
		Boolean spotValidation = isSpotValidation(xmlFieldValueMap, creditDecisionList);
		logger.debug("isSpotValidation result: " + spotValidation);
		
		StringBuilder failureAuditMessage = new StringBuilder();

		if (!spotValidation) {
			logger.debug("Entered Credit Decision Validation Block");
			List<CreditDecision> creditList = getCreditList(xmlFieldValueMap, creditDecisionList);

			// multiple credit lines error
			if (creditList.size() > 1) {
				failureAuditMessage.append(
						"There are multiple decisions found. Please select from the following, input into the Application Number field,");
				creditList.forEach(credit -> {
					failureAuditMessage.append(credit.getApplicationNumber());
					failureAuditMessage.append(",");
					failureAuditMessage.append(credit.getConversationId());
					failureAuditMessage.append(",");
				});
				failureAuditMessage.append("and resubmit validation");
				failureAuditMessage.append("  +  ");
				processAudit.setrValidationResult(passmessage + " || " + failmessage + " "
						+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
				processAudit.setrValidationEnd(new Timestamp(System.currentTimeMillis()));
				// Credit Decision Validation failed
				return false;

			}
			// no matching credit lines. error
			if (creditList.isEmpty()) {
				String applicationNumber = xmlFieldValueMap.get("ApplicationNumber");
				logger.debug("No Application Number match found!!: {}", applicationNumber);
				failureAuditMessage.append(
						"Credit Application not found. Please input your credit application and re-submit your validation. For SPOT validation, input the customer tier in the Spot Program code.");
				failureAuditMessage.append("  +  ");
				processAudit.setrValidationResult(passmessage + " || " + failmessage + " "
						+ failureAuditMessage.toString().substring(0, failureAuditMessage.toString().length() - 3));
				processAudit.setrValidationEnd(new Timestamp(System.currentTimeMillis()));
				// Credit Decision Validation failed
				return false;

			}

		}
		// Spot deal or Credit Decision Validation passed
		return true;
	}
}
