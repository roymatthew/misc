package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.exchange.re.DTO.RuleAuditDTO;
import com.ode.exchange.re.DTO.RuleDTO;
import com.ode.exchange.re.entity.RuleAudit;
import com.ode.exchange.re.exceptions.BadRequestException;
import com.ode.exchange.re.repository.IRuleAuditDAO;



/**
 * This Service Implementation Class for RuleAuditServiceImpl.
 * @author 
 * 
 */

@Service
@Transactional
public class RuleAuditServiceImpl {

	
	public static final Logger logger = LoggerFactory.getLogger(RuleAuditServiceImpl.class);

	@Autowired
	IRuleAuditDAO ruleAuditDAO;
	
	  @Autowired
	    private ModelMapper modelMapper;
	  

	public RuleAudit saveRuleAudit(RuleAudit ruleAudit) {
	
		try{
			ruleAudit =	 ruleAuditDAO.save(ruleAudit);
		}
		catch(Exception e){
			throw new BadRequestException(e.getMessage());			
		}
		
		return ruleAudit;
	}

	public List<RuleAuditDTO> getRuleAuditAll() {
		List<RuleAuditDTO> ruleAuditDTOList = new ArrayList<>();
		List<RuleAudit> ruleAuditList = (List<RuleAudit>) ruleAuditDAO.findAll();
		if (ruleAuditList != null) {
			
			for (int i = 0; i < ruleAuditList.size(); i++) {
				RuleDTO ruleDTO = modelMapper.map(ruleAuditList.get(i).getRule(), RuleDTO.class);
				RuleAuditDTO ruleAuditDTO = modelMapper.map(ruleAuditList.get(i), RuleAuditDTO.class);
				ruleAuditDTO.setRuledto(ruleDTO);
				ruleAuditDTOList.add(ruleAuditDTO);
			}
		}
		return ruleAuditDTOList;
	}
}




