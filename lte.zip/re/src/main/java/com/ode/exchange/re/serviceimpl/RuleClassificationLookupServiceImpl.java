package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.ode.exchange.re.DTO.FieldDTO;
import com.ode.exchange.re.DTO.FieldDropDownNameDTO;
import com.ode.exchange.re.DTO.FieldNameDTO;

import com.ode.exchange.re.DTO.RuleClassificationLookupDTO;

import com.ode.exchange.re.entity.RuleClassification;

import com.ode.exchange.re.repository.IFieldNameDAO;

@Service
@Transactional
public class RuleClassificationLookupServiceImpl {

	public static final Logger logger = LoggerFactory.getLogger(RuleClassificationLookupServiceImpl.class);

	@Autowired
	private FieldNameServiceImpl fieldNameService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	IFieldNameDAO fieldNameDAO;
	
	/**
	 * // Get All Lookups with Names with associated RuleClassification id
	 *
	 * @param fieldIDList - FieldId
	 * @return rclDTO - Lookups with Names with associated with RuleClassification
	 */

	public RuleClassificationLookupDTO findFieldDropDownByRuleClassificationId(List<Integer> fieldIDList, RuleClassification rc) {
		RuleClassificationLookupDTO rclDTO = modelMapper.map(rc, RuleClassificationLookupDTO.class);

		List<FieldDropDownNameDTO> fieldDropDownNameList = new ArrayList<>();

		fieldIDList.forEach(fieldID -> {
			FieldDropDownNameDTO fieldDropDownName = new FieldDropDownNameDTO();
			if (fieldNameDAO.findById(fieldID) != null) {
				FieldDTO fieldDTOObj = fieldNameService.getFieldById(fieldID);
				fieldDropDownName.setFieldDTO(fieldDTOObj);
				FieldNameDTO fieldDropdownDTOObj = fieldNameService.findFieldDropDownById(fieldID);
				fieldDropDownName.setFieldNameDTO(fieldDropdownDTOObj);
			} else {

				FieldDTO fieldDTOObj = fieldNameService.getFieldById(fieldID);
				fieldDropDownName.setFieldDTO(fieldDTOObj);
			}
			fieldDropDownNameList.add(fieldDropDownName);

		});
		rclDTO.setFieldDropDownNameDTO(fieldDropDownNameList);
		return rclDTO;
	}

	/**
	 * // Convert RuleClassification to RuleClassificationLookupDTO
	 *
	 * @param rc - RuleClassification 
	 * @return RuleClassificationLookupDTO - Lookups with Names with associated with
	 *         the RuleClassification
	 */


public RuleClassificationLookupDTO findRuleClassification(RuleClassification rc) {
	return modelMapper.map(rc, RuleClassificationLookupDTO.class);
	
	
}
}
