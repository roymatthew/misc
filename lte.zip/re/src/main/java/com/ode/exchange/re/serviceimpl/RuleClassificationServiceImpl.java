package com.ode.exchange.re.serviceimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IRuleClassificationDAO;

/**
 * This Service Implementation Class for RuleClassificationServiceImpl.
 * @author 
 * 
 */

@Service
@Transactional
public class RuleClassificationServiceImpl {

	public static final Logger logger =  LoggerFactory.getLogger(RuleClassificationServiceImpl.class);

	@Autowired
	IRuleClassificationDAO ruleClassificationDAO;

	
	
	/**
	 * // Fetch all RuleClassifications from DB
	 * 
	 * @return lists all RuleClassifications
	 */
	
	public List<RuleClassification> getRuleClassificationAll() {
		return  (List<RuleClassification>) ruleClassificationDAO.findAll();
		

	}

	
	/**
	 * Fetch RuleClassifications from DB by rcID
	 *
	 * @param rcID - RuleClassification id
	 * @return RuleClassification associated with the rcID
	 */
	
	public RuleClassification findRuleClassificationById(int rcID) {
		RuleClassification rc = ruleClassificationDAO.findById(rcID);
		if(rc == null)
		{
			throw new NotFoundException("RuleClassification does not exist");
		}
		return rc;

	}

	
	
	/**
	 * // Create RuleClassification 
	 * 
	 * @param rc  - RuleClassification to be created	 
	 * @return RuleClassificationDTO - created RuleClassification
	 */
	
	public RuleClassification createRuleclassification(RuleClassification rc) {
		RuleClassification rcEntity = rc;
		if (rcEntity != null) {
			rc = ruleClassificationDAO.save(rcEntity);
		}
		return rc;
	}

	
	/**
	 * // Update RuleClassification By id
	 * 
	 * 
	 * @param rc - RuleClassification to be updated 
	 * @param rcID  - RuleClassification id
	 * @return RuleClassificationDTO - RuleClassification updated
	 */
	
	public RuleClassification updateById(int rcID, RuleClassification rc) {
		RuleClassification rcEntity = ruleClassificationDAO.findById(rcID);
		RuleClassification ruleclassificationEntity = new RuleClassification();
		if (rcEntity == null) {

			throw new NotFoundException("RuleClassification does not exist");
		} else {
			//rcEntity.setComputeRule(rc.isComputeRule()); // Removed in Phase 2  
			//rcEntity.setFixedFieldValues(rc.isFixedFieldValues());
			rcEntity.setLookupFieldsID(rc.getLookupFieldsID());
			//rcEntity.setRequiredFields((rc.isRequiredFields()));
			rcEntity.setRemarks(rc.getRemarks());
		//	rcEntity.setStatus(rc.isStatus());
			rcEntity.setReasonCodeDivision(rc.getReasonCodeDivision());
			rcEntity.setReasonCodeHigh(rc.getReasonCodeHigh());
			rcEntity.setReasonCodeLow(rc.getReasonCodeLow());
			rcEntity.setUpdatedDate(rc.getUpdatedDate());
			rcEntity.setUpdatedBy(rc.getUpdatedBy());
			ruleclassificationEntity = ruleClassificationDAO.save(rcEntity);

		}

		return ruleclassificationEntity;

	}
}
