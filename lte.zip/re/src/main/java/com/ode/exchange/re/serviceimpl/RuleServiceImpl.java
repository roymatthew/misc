package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;

import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.DTO.PassFailMessageDTO;
import com.ode.exchange.re.DTO.RuleClassificationDTO;
import com.ode.exchange.re.DTO.RuleDTO;
import com.ode.exchange.re.DTO.RuleSubtypeDTO;
import com.ode.exchange.re.DTO.RuleTypeDTO;
import com.ode.exchange.re.entity.Message;
import com.ode.exchange.re.entity.Rule;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.entity.RuleSubtype;
import com.ode.exchange.re.entity.RuleType;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IMessageDAO;
import com.ode.exchange.re.repository.IProcessAuditDAO;
import com.ode.exchange.re.repository.IRuleClassificationDAO;
import com.ode.exchange.re.repository.IRuleDAO;
import com.ode.exchange.re.repository.IRuleSubtypeDAO;
import com.ode.exchange.re.repository.IRuleTypeDAO;
import com.ode.exchange.re.repository.IUserroleDAO;

/**
 * This Service Implementation Class for RuleServiceImpl.
 * 
 * @author
 * 
 */
@Service
@Transactional
public class RuleServiceImpl {
	public static final Logger logger = LoggerFactory.getLogger(RuleServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	IRuleDAO ruleDAO;

	@Autowired
	IRuleSubtypeDAO ruleSubtypeDAO;

	@Autowired
	IRuleTypeDAO ruleTypeDAO;

	@Autowired
	IMessageDAO messageDAO;

	@Autowired
	IProcessAuditDAO processAuditDAO;

	@Autowired
	IRuleClassificationDAO ruleClassificationDAO;

	/**
	 * // Get All Rules
	 * 
	 * @return lists all Rules
	 */

	public List<RuleDTO> getRuleAll() {

		List<Rule> ruleList = ruleDAO.findAll();
		List<RuleDTO> ruleDTOList = new ArrayList<>();
		for (int i = 0; i < ruleList.size(); i++) {
			RuleTypeDTO ruleTypeDTO = new RuleTypeDTO();
			RuleSubtypeDTO ruleSubtypeDTO = new RuleSubtypeDTO();
			PassFailMessageDTO passMessageDTO = new PassFailMessageDTO();
			PassFailMessageDTO failMessageDTO = new PassFailMessageDTO();

			RuleDTO ruleDTO = modelMapper.map(ruleList.get(i), RuleDTO.class);
			RuleClassificationDTO rcDTO = modelMapper.map(ruleList.get(i).getRuleClassification(),
					RuleClassificationDTO.class);
			if (ruleList.get(i).getRuleType() != null) {

				ruleTypeDTO = modelMapper.map(ruleList.get(i).getRuleType(), RuleTypeDTO.class);
				ruleDTO.setRuleTypeDTO(ruleTypeDTO);
			} else {
				ruleDTO.setRuleTypeDTO(null);
			}

			if (ruleList.get(i).getRuleSubtype() != null) {
				ruleSubtypeDTO = modelMapper.map(ruleList.get(i).getRuleSubtype(), RuleSubtypeDTO.class);
				ruleDTO.setRuleSubtypeDTO(ruleSubtypeDTO);
			} else

			{
				ruleDTO.setRuleSubtypeDTO(null);
			}

			if (ruleList.get(i).getPassmessage() != null) {
				passMessageDTO = modelMapper.map(ruleList.get(i).getPassmessage(), PassFailMessageDTO.class);
				ruleDTO.setPassmessageDTO(passMessageDTO);
			} else

			{
				ruleDTO.setPassmessageDTO(null);
			}

			if (ruleList.get(i).getFailmessage() != null) {
				failMessageDTO = modelMapper.map(ruleList.get(i).getFailmessage(), PassFailMessageDTO.class);
				ruleDTO.setFailmessageDTO(failMessageDTO);
			} else

			{
				ruleDTO.setFailmessageDTO(null);
			}

			ruleDTO.setRuleClassificationDTO(rcDTO);
			ruleDTOList.add(ruleDTO);

		}
		return ruleDTOList;

	}

	/**
	 * Get Rule By id
	 *
	 * @param ruleid - Rule id
	 * @return Rule associated with the ruleid
	 */

	public RuleDTO getRuleById(int ruleid) {
		Rule rule = ruleDAO.findById(ruleid);
		if (rule == null) {
			throw new NotFoundException("rule does not exist");
		}

		RuleTypeDTO ruleTypeDTO = new RuleTypeDTO();
		RuleSubtypeDTO ruleSubtypeDTO = new RuleSubtypeDTO();
		RuleDTO ruleDTO = modelMapper.map(rule, RuleDTO.class);
		PassFailMessageDTO passMessageDTO = new PassFailMessageDTO();
		PassFailMessageDTO failMessageDTO = new PassFailMessageDTO();

		RuleClassificationDTO rcDTO = modelMapper.map(rule.getRuleClassification(), RuleClassificationDTO.class);
		if (rule.getRuleType() != null) {
			ruleTypeDTO = modelMapper.map(rule.getRuleType(), RuleTypeDTO.class);
			ruleDTO.setRuleTypeDTO(ruleTypeDTO);
		} else {
			ruleDTO.setRuleTypeDTO(null);
		}

		if (rule.getRuleSubtype() != null) {
			ruleSubtypeDTO = modelMapper.map(rule.getRuleSubtype(), RuleSubtypeDTO.class);
			ruleDTO.setRuleSubtypeDTO(ruleSubtypeDTO);
		} else {
			ruleDTO.setRuleSubtypeDTO(null);
		}

		if (rule.getPassmessage() != null) {
			passMessageDTO = modelMapper.map(rule.getPassmessage(), PassFailMessageDTO.class);
			ruleDTO.setPassmessageDTO(passMessageDTO);
		} else

		{
			ruleDTO.setPassmessageDTO(null);
		}

		if (rule.getFailmessage() != null) {
			failMessageDTO = modelMapper.map(rule.getFailmessage(), PassFailMessageDTO.class);
			ruleDTO.setFailmessageDTO(failMessageDTO);
		} else

		{
			ruleDTO.setFailmessageDTO(null);
		}

		ruleDTO.setRuleClassificationDTO(rcDTO);

		return ruleDTO;
	}

	public List<RuleDTO> getRuleByRCId(int rcID) {
		List<Rule> ruleList = ruleDAO.findByRCId(rcID);

		List<RuleDTO> ruleDTOList = new ArrayList<>();
		for (int i = 0; i < ruleList.size(); i++) {
			RuleTypeDTO ruleTypeDTO = new RuleTypeDTO();
			RuleSubtypeDTO ruleSubtypeDTO = new RuleSubtypeDTO();
			PassFailMessageDTO passMessageDTO = new PassFailMessageDTO();
			PassFailMessageDTO failMessageDTO = new PassFailMessageDTO();

			RuleDTO ruleDTO = modelMapper.map(ruleList.get(i), RuleDTO.class);

			RuleClassificationDTO rcDTO = modelMapper.map(ruleList.get(i).getRuleClassification(),
					RuleClassificationDTO.class);
			if (ruleList.get(i).getRuleType() != null) {

				ruleTypeDTO = modelMapper.map(ruleList.get(i).getRuleType(), RuleTypeDTO.class);
				ruleDTO.setRuleTypeDTO(ruleTypeDTO);
			} else {
				ruleDTO.setRuleTypeDTO(null);
			}

			if (ruleList.get(i).getRuleSubtype() != null) {
				ruleSubtypeDTO = modelMapper.map(ruleList.get(i).getRuleSubtype(), RuleSubtypeDTO.class);
				ruleDTO.setRuleSubtypeDTO(ruleSubtypeDTO);
			} else

			{
				ruleDTO.setRuleSubtypeDTO(null);
			}

			if (ruleList.get(i).getPassmessage() != null) {
				passMessageDTO = modelMapper.map(ruleList.get(i).getPassmessage(), PassFailMessageDTO.class);
				ruleDTO.setPassmessageDTO(passMessageDTO);
			} else

			{
				ruleDTO.setPassmessageDTO(null);
			}

			if (ruleList.get(i).getFailmessage() != null) {
				failMessageDTO = modelMapper.map(ruleList.get(i).getFailmessage(), PassFailMessageDTO.class);
				ruleDTO.setFailmessageDTO(failMessageDTO);
			} else

			{
				ruleDTO.setFailmessageDTO(null);
			}

			ruleDTO.setRuleClassificationDTO(rcDTO);
			ruleDTOList.add(ruleDTO);

		}
		return ruleDTOList;
	}

	/**
	 * // Create Rule
	 * 
	 * 
	 * @param ruleDTO - Rule to be created
	 * @return ruleDTO - created Rule
	 */

	public RuleDTO createRule(RuleDTO ruleDTO) {
		Rule rule = null;
		if (ruleDTO != null) {
			RuleTypeDTO ruleTypeDTO = new RuleTypeDTO();
			RuleType ruleType = new RuleType();
			Message passMesssage = new Message();
			Message failMesssage = new Message();

			PassFailMessageDTO passMessageDTO = new PassFailMessageDTO();
			PassFailMessageDTO failMessageDTO = new PassFailMessageDTO();

			RuleSubtypeDTO ruleSubtypeDTO = new RuleSubtypeDTO();
			RuleSubtype ruleSubType = new RuleSubtype();

			rule = modelMapper.map(ruleDTO, Rule.class);
			RuleClassification ruleClassification = ruleClassificationDAO
					.findById(ruleDTO.getRuleClassificationDTO().getId());

			if (ruleDTO.getRuleTypeDTO() != null) {
				ruleType = ruleTypeDAO.findById(ruleDTO.getRuleTypeDTO().getId());
				rule.setRuleType(ruleType);
			} else {
				rule.setRuleType(null);
			}

			if (ruleDTO.getRuleSubtypeDTO() != null) {
				ruleSubType = ruleSubtypeDAO.findById(ruleDTO.getRuleSubtypeDTO().getId());
				rule.setRuleSubtype(ruleSubType);
			} else {
				rule.setRuleSubtype(null);
			}

			if (ruleDTO.getPassmessageDTO() != null) {
				passMesssage = messageDAO.findById(ruleDTO.getPassmessageDTO().getId());
				rule.setPassmessage(passMesssage);
			} else {
				rule.setPassmessage(null);
			}

			if (ruleDTO.getFailmessageDTO() != null) {
				failMesssage = messageDAO.findById(ruleDTO.getFailmessageDTO().getId());
				rule.setFailmessage(failMesssage);
			} else {
				rule.setFailmessage(null);
			}

			rule.setRuleClassification(ruleClassification);

			rule = ruleDAO.save(rule);
			
			ruleDTO = modelMapper.map(rule, RuleDTO.class);

			RuleClassificationDTO rcDTO = modelMapper.map(rule.getRuleClassification(), RuleClassificationDTO.class);
			if (rule.getRuleType() != null) {
				ruleTypeDTO = modelMapper.map(rule.getRuleType(), RuleTypeDTO.class);
				ruleDTO.setRuleTypeDTO(ruleTypeDTO);
			} else {
				ruleDTO.setRuleTypeDTO(null);
			}

			if (rule.getRuleSubtype() != null) {
				ruleSubtypeDTO = modelMapper.map(rule.getRuleSubtype(), RuleSubtypeDTO.class);
				ruleDTO.setRuleSubtypeDTO(ruleSubtypeDTO);
			} else {
				ruleDTO.setRuleTypeDTO(null);
			}

			if (rule.getPassmessage() != null) {
				passMessageDTO = modelMapper.map(rule.getPassmessage(), PassFailMessageDTO.class);
				ruleDTO.setPassmessageDTO(passMessageDTO);
			} else

			{
				ruleDTO.setPassmessageDTO(null);
			}

			if (rule.getFailmessage() != null) {
				failMessageDTO = modelMapper.map(rule.getFailmessage(), PassFailMessageDTO.class);
				ruleDTO.setFailmessageDTO(failMessageDTO);
			} else

			{
				ruleDTO.setFailmessageDTO(null);
			}

			ruleDTO.setRuleClassificationDTO(rcDTO);

		}

		return ruleDTO;
	}

	/**
	 * // Update Rule By id
	 * 
	 * 
	 * @param ruleDTO - Rule to be updated
	 * @param ruleid  - message id
	 * @return ruleDTO - Rule updated
	 */

	public Rule updateById(int ruleid, RuleDTO ruleDTO) {

		Rule rule = ruleDAO.findById(ruleid);
		RuleType ruleType = new RuleType();
		RuleSubtype ruleSubType = new RuleSubtype();
		Message passMesssage = new Message();
		Message failMesssage = new Message();
		if (rule == null) {
			throw new NotFoundException("rule does not exist");
		}

		rule.setStatus(ruleDTO.getStatus());
		rule.setRemarks(ruleDTO.getRemarks());
		rule.setExpirationDate(ruleDTO.getExpirationDate());
		rule.setEffectiveDate(ruleDTO.getEffectiveDate());
		rule.setRuleLogic(ruleDTO.getRuleLogic());
		/*rule.setFixedFieldValues(ruleDTO.getFixedFieldValues());
		rule.setRequiredFields(ruleDTO.getRequiredFields());*/
		rule.setLookupCriteria(ruleDTO.getLookupCriteria());
		rule.setRuleName(ruleDTO.getRuleName());
		rule.setFailRuleValue(ruleDTO.getFailRuleValue());
		rule.setPassRuleValue(ruleDTO.getPassRuleValue());
		RuleClassification ruleClassification = ruleClassificationDAO
				.findById(ruleDTO.getRuleClassificationDTO().getId());

		if (ruleDTO.getRuleTypeDTO() != null) {
			ruleType = ruleTypeDAO.findById(ruleDTO.getRuleTypeDTO().getId());
			rule.setRuleType(ruleType);
		} else {
			rule.setRuleType(null);
		}

		if (ruleDTO.getRuleSubtypeDTO() != null) {
			ruleSubType = ruleSubtypeDAO.findById(ruleDTO.getRuleSubtypeDTO().getId());
			rule.setRuleSubtype(ruleSubType);
		} else {
			rule.setRuleSubtype(null);
		}

		if (ruleDTO.getPassmessageDTO() != null) {
			passMesssage = messageDAO.findById(ruleDTO.getPassmessageDTO().getId());
			rule.setPassmessage(passMesssage);
		} else {
			rule.setPassmessage(null);
		}

		if (ruleDTO.getFailmessageDTO() != null) {
			failMesssage = messageDAO.findById(ruleDTO.getFailmessageDTO().getId());
			rule.setFailmessage(failMesssage);
		} else {
			rule.setFailmessage(null);
		}

		rule.setRuleClassification(ruleClassification);

		rule = ruleDAO.save(rule);

		return rule;
	}

	public List<RuleDTO> getActiveRulesByMessageId(String rcName, int messageId) {
		List<Rule> rulebyRuleClassificationList = new ArrayList();
		List<Rule> activeRuleList = new ArrayList();
		List<RuleDTO> ruleDTOList = new ArrayList<>();
		List<Rule> ruleList = ruleDAO.findAll();

		 ruleList.forEach(rule->{
			 if(rule.getRuleClassification().getRcName().equals(rcName) && rule.getStatus()=='A')
			 {
				 rulebyRuleClassificationList.add(rule);
			 }
			 
		 });
		
		
		
		 rulebyRuleClassificationList.forEach(rule ->{			

			if(rule.getPassmessage()!=null) { 
			if(rule.getPassmessage().getId()== messageId )
			{
				activeRuleList.add(rule);
			}
			}
			if(rule.getFailmessage()!=null) { 
				if(rule.getFailmessage().getId()== messageId )
				{
					activeRuleList.add(rule);
				}
				}
			
			
			
		});
		
		activeRuleList.forEach(rule->{
			
			RuleTypeDTO ruleTypeDTO = new RuleTypeDTO();
			RuleSubtypeDTO ruleSubtypeDTO = new RuleSubtypeDTO();
			PassFailMessageDTO passMessageDTO = new PassFailMessageDTO();
			PassFailMessageDTO failMessageDTO = new PassFailMessageDTO();

			RuleDTO ruleDTO = modelMapper.map(rule, RuleDTO.class);
			RuleClassificationDTO rcDTO = modelMapper.map(rule.getRuleClassification(),
					RuleClassificationDTO.class);
			if (rule.getRuleType() != null) {

				ruleTypeDTO = modelMapper.map(rule.getRuleType(), RuleTypeDTO.class);
				ruleDTO.setRuleTypeDTO(ruleTypeDTO);
			} else {
				ruleDTO.setRuleTypeDTO(null);
			}

			if (rule.getRuleSubtype() != null) {
				ruleSubtypeDTO = modelMapper.map(rule.getRuleSubtype(), RuleSubtypeDTO.class);
				ruleDTO.setRuleSubtypeDTO(ruleSubtypeDTO);
			} else

			{
				ruleDTO.setRuleSubtypeDTO(null);
			}

			if (rule.getPassmessage() != null) {
				passMessageDTO = modelMapper.map(rule.getPassmessage(), PassFailMessageDTO.class);
				ruleDTO.setPassmessageDTO(passMessageDTO);
			} else

			{
				ruleDTO.setPassmessageDTO(null);
			}

			if (rule.getFailmessage() != null) {
				failMessageDTO = modelMapper.map(rule.getFailmessage(), PassFailMessageDTO.class);
				ruleDTO.setFailmessageDTO(failMessageDTO);
			} else

			{
				ruleDTO.setFailmessageDTO(null);
			}

			ruleDTO.setRuleClassificationDTO(rcDTO);
			ruleDTOList.add(ruleDTO);
			
		});
		
		
		return ruleDTOList;
	}

}
