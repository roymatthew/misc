package com.ode.exchange.re.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.DTO.RuleSubtypeDTO;
import com.ode.exchange.re.DTO.RuleTypeDTO;
import com.ode.exchange.re.entity.RuleSubtype;
import com.ode.exchange.re.entity.RuleType;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IRuleSubtypeDAO;
import com.ode.exchange.re.repository.IRuleTypeDAO;

@Service
@Transactional
public class RuleSubtypeServiceImpl {
	public static final Logger logger = LoggerFactory.getLogger(RuleSubtypeServiceImpl.class);

	@Autowired
	IRuleSubtypeDAO ruleSubtypeDAO;

	@Autowired
	IRuleTypeDAO ruleTypeDAO;
	
	@Autowired
    private ModelMapper modelMapper;

	public List<RuleSubtypeDTO> getRuleSubtypeAll() {

		List<RuleSubtypeDTO> ruleSubtypeList = new ArrayList<>();
		List<RuleSubtype> ruleSubtypeEntityList = ruleSubtypeDAO.findAll();
		if (ruleSubtypeEntityList != null) {
			java.lang.reflect.Type targetListType = new TypeToken<List<RuleSubtypeDTO>>() {
			}.getType();
			ruleSubtypeList = modelMapper.map(ruleSubtypeEntityList, targetListType);
			for (int i = 0; i < ruleSubtypeEntityList.size(); i++) {
				RuleTypeDTO ruleTypeDTO = modelMapper.map(ruleSubtypeEntityList.get(i).getRuleType(), RuleTypeDTO.class);
				RuleSubtypeDTO ruleSubtypeDTO = modelMapper.map(ruleSubtypeEntityList.get(i), RuleSubtypeDTO.class);
				ruleSubtypeDTO.setRuleType(ruleTypeDTO);
			}
		}

		return ruleSubtypeList;

	}
	
	public RuleSubtypeDTO findById(int ruleTypeID) {
		RuleSubtypeDTO ruleSubtypeDTOObj = new RuleSubtypeDTO();		
		RuleSubtype ruleSubtypeEntity = ruleSubtypeDAO.findById(ruleTypeID);		
		if (ruleSubtypeEntity == null) {
			throw new NotFoundException("RuleSubtype does not exist");
		}
			RuleTypeDTO ruleTypeDTO = modelMapper.map(ruleSubtypeEntity.getRuleType(), RuleTypeDTO.class);
			ruleSubtypeDTOObj = modelMapper.map(ruleSubtypeEntity, RuleSubtypeDTO.class);
			ruleSubtypeDTOObj.setRuleType(ruleTypeDTO);
			
		
		

		return ruleSubtypeDTOObj;
	}
	
	

	public List<RuleSubtypeDTO>  findRuleSubtypeByRuleType(String ruleType) {
		List<RuleSubtypeDTO> ruleSubtypeList = new ArrayList<>();
		List<RuleSubtype> ruleSubtypeEntityList = ruleSubtypeDAO.findRuleSubtypeByRuleType(ruleType);		
		if (ruleSubtypeEntityList != null) {
			java.lang.reflect.Type targetListType = new TypeToken<List<RuleSubtypeDTO>>() {
			}.getType();
			ruleSubtypeList = modelMapper.map(ruleSubtypeEntityList, targetListType);
			for (int i = 0; i < ruleSubtypeEntityList.size(); i++) {
				RuleTypeDTO ruleTypeDTO = modelMapper.map(ruleSubtypeEntityList.get(i).getRuleType(), RuleTypeDTO.class);
				RuleSubtypeDTO ruleSubtypeDTO = modelMapper.map(ruleSubtypeEntityList.get(i), RuleSubtypeDTO.class);
				ruleSubtypeDTO.setRuleType(ruleTypeDTO);
			}
		}

		return ruleSubtypeList;
	}

	
	public RuleSubtypeDTO createRuleSubtype(RuleSubtypeDTO ruleSubtypeDTO)  {		

		if (ruleSubtypeDTO != null) {
			RuleSubtype ruleSubtype = modelMapper.map(ruleSubtypeDTO, RuleSubtype.class);
			RuleType ruleType = ruleTypeDAO.findById(ruleSubtypeDTO.getRuleType().getId());
			if (ruleType == null) {

				throw new NotFoundException("RuleType does not exist");
			} else {
				ruleSubtype.setRuleType(ruleType);
				ruleSubtype = ruleSubtypeDAO.save(ruleSubtype);
				if (ruleSubtype != null) {
					RuleTypeDTO ruleTypeDTO = modelMapper.map(ruleSubtype.getRuleType(), RuleTypeDTO.class);
					ruleSubtypeDTO = modelMapper.map(ruleSubtype, RuleSubtypeDTO.class);
					ruleSubtypeDTO.setRuleType(ruleTypeDTO);
				}

			}
		}
		return ruleSubtypeDTO;
	}
	
	
	public RuleSubtypeDTO updateById(int ruleSubTypeID, RuleSubtypeDTO ruleSubtypeDTO)  {	
		RuleSubtype ruleSubtypeEntity;
		if (ruleSubtypeDTO != null) {
			ruleSubtypeEntity = ruleSubtypeDAO.findById(ruleSubTypeID);
			if(ruleSubtypeEntity == null)
			{
				throw new NotFoundException("RuleSubType does not exist");
			}
			ruleSubtypeEntity.setStatus(ruleSubtypeDTO.isStatus());
			ruleSubtypeEntity.setRemarks(ruleSubtypeDTO.getRemarks());
			RuleType ruleType = ruleTypeDAO.findById(ruleSubtypeDTO.getRuleType().getId());
			if(ruleType == null)
			{

				throw new NotFoundException("RuleType does not exist");
			}
			ruleSubtypeEntity.setRuleType(ruleType);
			ruleSubtypeEntity = ruleSubtypeDAO.save(ruleSubtypeEntity);
			if (ruleSubtypeEntity != null) {
				RuleTypeDTO ruleTypeDTO = modelMapper.map(ruleSubtypeEntity.getRuleType(), RuleTypeDTO.class);
				ruleSubtypeDTO = modelMapper.map(ruleSubtypeEntity, RuleSubtypeDTO.class);
				ruleSubtypeDTO.setRuleType(ruleTypeDTO);
			}
		}

		return ruleSubtypeDTO;
	}


}