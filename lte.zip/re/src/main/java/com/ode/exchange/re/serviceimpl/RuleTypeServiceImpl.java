package com.ode.exchange.re.serviceimpl;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.entity.RuleType;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IRuleTypeDAO;
/**
 * This Service Implementation Class for RuleTypeServiceImpl.
 * @author 
 * 
 */

@Service
@Transactional
public class RuleTypeServiceImpl {


	@Autowired
	IRuleTypeDAO ruleTypeDAO;	

	/**
	 * 
	// Fetch all RuleType from DB
	 * 
	 * @return lists all Ruletypes
	 */
 
	
	public List<RuleType> getRuleTypeAll() {
		return  ruleTypeDAO.findAll();	
		
	}

	
	
	/**
	// Fetch  RuleType from DB based on ruleTypeID
	 *
	 * @param ruleTypeID - message id
	 * @return RuleType associated with the ruleTypeID
	 */
	
	public RuleType findRuleTypeById(int ruleTypeID) {
		RuleType ruleTypeEntity = ruleTypeDAO.findById(ruleTypeID);
		if(ruleTypeEntity == null)
		{
			throw new NotFoundException("RuleType does not exist");
		}
		return ruleTypeEntity;
	}

	
	/**
	 * // Create Ruletype
	 * 
	 * 
	 * @param ruleType  - RuleType to be created	 
	 * @return RuleTypeDTO - RuleType Message
	 */

	public RuleType createRuleType(RuleType ruleType) {	
		if(ruleType!= null) {
			ruleType = ruleTypeDAO.save(ruleType);
		}
		return  ruleType;
	}

	/**
	 *Update Ruletype By id
	 * 
	 * 
	 * @param ruleType - Ruletype to be updated 
	 * @param ruleTypeID  - Ruletype id
	 * @return RuleTypeDTO - Ruletype updated
	 */
	
	public RuleType updateRuleTypeById(int ruleTypeID, RuleType ruleType) {
		RuleType ruleTypeEntity = ruleTypeDAO.findById(ruleTypeID);
		if(ruleTypeEntity == null)
		{
			throw new NotFoundException("RuleType does not exist");
		}					
			ruleTypeEntity.setRemarks(ruleType.getRemarks());
			ruleTypeEntity.setStatus(ruleType.isStatus());			
			ruleTypeDAO.save(ruleTypeEntity);
		
		return ruleTypeEntity;
	}



}
