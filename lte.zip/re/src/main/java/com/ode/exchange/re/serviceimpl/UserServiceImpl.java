package com.ode.exchange.re.serviceimpl;

import java.util.Base64;
import java.util.HashSet;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ode.exchange.re.entity.AppUser;
import com.ode.exchange.re.entity.UserRole;
import com.ode.exchange.re.exceptions.NotFoundException;
import com.ode.exchange.re.repository.IUserDAO;
import com.ode.exchange.re.repository.IUserroleDAO;
import com.ode.exchange.re.service.UserService;



@Service(value = "userService")
@Transactional
public class UserServiceImpl  implements UserService {			

	
	
	@Autowired
	IUserDAO userDAO;

	@Autowired
	IUserroleDAO iUserroleDAO;
	
	/*@Autowired
	UserServiceImpl userService;*/

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	@Value("${ode.secret.encoding.key}")
	private String secret;
	
	
	/**
	 * //Fetch all the Users from DB
	 * 
	 * @return lists all Users
	 */	
	
	@Override
	public Iterable<AppUser> getUserAll() {
		return userDAO.findAll();

	}

	
	
	/**
	 * //Fetch User from DB based on userID
	 *
	 * @param userID - User id
	 * @return AppUser -  User associated with the userID
	 */

	@Override
	public AppUser findById(int userID) {
		AppUser appUser = userDAO.findById(userID);
		
		if (appUser == null) {
			throw new NotFoundException("User does not exist");
		}
		
		return appUser;
	}

	/**
	 * Create  User
	 * 
	 * 
	 * @param userDTO  - User to be created	 
	 * @return AppUser - User created
	 */
	
	@Override
	public AppUser save(AppUser appuser)  {
		if(appuser.getId()==0) {
		if(appuser.getPassword()!=null){
			Base64.Decoder decoder = Base64.getDecoder();
			byte[] decodedByteArray = decoder.decode(appuser.getPassword());
			String decodedString = new String(decodedByteArray);	
			String pass =  decodedString.replaceFirst(secret, "");		
			appuser.setPassword(bcryptEncoder.encode(pass));			
			
		}
		}
			UserRole role = iUserroleDAO.findById(appuser.getUserroleid());
		if(role == null){
			throw new NotFoundException("Userrole does not exist");
		}
		
		appuser.setUserRoles(role);
		return userDAO.save(appuser);
	}

	
	/**
	 * //Fetch User from DB based on username
	 * 
	 * 
	 * @param username - Username
	 * @return AppUser - User associated with the Username
	 */
	
	@Override
	public AppUser findByUser(String username) {
		return userDAO.findByUserName(username);
	}

	
	/**
	 * // Grant Authority to Userroles
	 * 
	 * 
	 * @param appuser - User
	 * @return set of authorities
	 */
	
	public Set<SimpleGrantedAuthority> getAuthority(AppUser appuser) {
		Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		UserRole roleEntity = appuser.getUserRoles();
		authorities.add(new SimpleGrantedAuthority("ROLE_" + roleEntity.getUserrolename()));
		return authorities;

	}

	

	
	/**
	 * //  UserName Password Validation and Fetch UserDetails  
	 * 
	 * 
	 * @param appuser - User
	 * @return authority with name and password
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		AppUser user = new AppUser();
		if (username != null) {
			user = userDAO.findByUserName(username);
			if (user == null) {
				throw new UsernameNotFoundException("Invalid username or password.");
			}
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),getAuthority(user));
	}
	
}
