package com.ode.exchange.re.serviceimpl;



import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ode.exchange.re.entity.UserRole;
import com.ode.exchange.re.repository.IUserroleDAO;
/**
 * This Service Implementation Class for FunctionalityServiceImpl.
 * @author 
 * 
 */

@Service
@Transactional
public class UserroleServiceImpl {

	@Autowired
	IUserroleDAO userroleDAO;

	
	/**
	 * //Fetch all Roles from DB
	 * 
	 * @return lists all Roles
	 */
	public Iterable<UserRole> getRolesAll() {

		return userroleDAO.findAll();

	}

	
	/**
	 * //Fetch Role by roleID
	 *
	 * @param roleID - Role id
	 * @return UserRole - Role associated with the roleID
	 */
	
	public UserRole findById(int roleID) {

		return userroleDAO.findById(roleID);

	}
	
	
	/**
	 * //Save Role
	 * 
	 * 
	 * @param rolesDTO - Role to be created
	 * @return UserRole - Role created
	 */

	public UserRole saveRole(UserRole roles) {		
		return userroleDAO.save(roles);

	}
	
	/**
	 * // Update Role By id
	 * 
	 * 
	 * @param userRole - Role to be updated
	 * @param roleID   - Role id
	 * @return userRoleEntity - Role updated
	 */

	public UserRole updateUserrole(int roleID, UserRole userRole) {
		UserRole userRoleEntity = userroleDAO.findById(roleID);		
		userRoleEntity.setRemarks(userRole.getRemarks());
		userRoleEntity.setStatus(userRole.isStatus());		
		return userRoleEntity;
	}


}


