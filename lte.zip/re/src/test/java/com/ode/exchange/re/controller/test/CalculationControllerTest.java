package com.ode.exchange.re.controller.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.exchange.re.entity.Calculation;
import com.ode.exchange.re.entity.Login;

@SpringBootTest

@RunWith(SpringRunner.class) 
@AutoConfigureMockMvc
public class CalculationControllerTest {
	//public static final Logger logger = LoggerFactory.getLogger(CalculationControllerTest.class);

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper objMapper;

	List<String> token = new ArrayList<String>();

	
	@Ignore
	@Test
	public void givenNoToken_Unauthorized() throws Exception { //
		 
		mockMvc.perform(MockMvcRequestBuilders.get("/calculations")).andExpect(status().isUnauthorized());
		
	//	MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/calculations");
	

	}

	public String getTokenFromLogin(String name, String pass) throws Exception {
		Login login = new Login();
		login.setPassword(pass);
		login.setUserName(name);

		ResultActions mvcResult = mockMvc
				.perform(MockMvcRequestBuilders.post("/login").contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON).content(objMapper.writeValueAsString(login)))
				.andExpect(status().isOk());
		token = mvcResult.andReturn().getResponse().getHeaders("token");	
		return token.get(0).toString();

	}

	@Ignore
	@Test
	public void getAllCalculationsAPI() throws Exception {
		String tok = getTokenFromLogin("john", "U2VjcmV0LWRvZQ==");
		ResultActions mvcResult = mockMvc.perform(
				MockMvcRequestBuilders.get("/calculations").header("token", tok).accept(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(status().isOk());

		int status = mvcResult.andReturn().getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.andReturn().getResponse().getContentAsString();
		Calculation[] calculationlist = objMapper.readValue(content, Calculation[].class);
		assertTrue(calculationlist.length > 0);
	}

	@Ignore
	@Test
	public void createCalculation() throws Exception {

		Calculation calculation = new Calculation();
		calculation.setFinanceType("L");
		calculation.setCalculationJSON("calculationJSONTest");
		calculation.setCalculationName("calculationJSONTest");
		calculation.setRemarks("calculationJSONTest");
		//calculation.setStatus(true);
		calculation.setUpdatedBy(25);
		calculation.setCreatedBy(25);

		String tok = getTokenFromLogin("john", "U2VjcmV0LWRvZQ==");
		ResultActions mvcResult = mockMvc
				.perform(MockMvcRequestBuilders.post("/calculations").header("token", tok)
						.contentType(MediaType.APPLICATION_JSON).content(objMapper.writeValueAsString(calculation)))
				.andExpect(status().isCreated());

		int status = mvcResult.andReturn().getResponse().getStatus();
		assertEquals(201, status);

	}

}
