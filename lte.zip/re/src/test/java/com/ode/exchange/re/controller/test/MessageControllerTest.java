package com.ode.exchange.re.controller.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.exchange.re.entity.FunctionalityUserRoleMapping;
import com.ode.exchange.re.entity.Login;
import com.ode.exchange.re.entity.Message;


@SpringBootTest
@RunWith(SpringRunner.class) 
@AutoConfigureMockMvc
public class MessageControllerTest {

	

	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper objMapper;

	List<String> token = new ArrayList<String>();
	
	@Ignore
	@Test
	public void givenNoToken_Unauthorized() throws Exception { //
		 
		mockMvc.perform(MockMvcRequestBuilders.get("/messages")).andExpect(status().isUnauthorized());
		
	//	MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/calculations");
	

	}
	
	public String getTokenFromLogin(String name, String pass) throws Exception {
		Login login = new Login();
		login.setPassword(pass);
		login.setUserName(name);

		ResultActions mvcResult = mockMvc
				.perform(MockMvcRequestBuilders.post("/login").contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON).content(objMapper.writeValueAsString(login)))
				.andExpect(status().isOk());
		token = mvcResult.andReturn().getResponse().getHeaders("token");	
		return token.get(0).toString();

	}
	
	@Ignore
	@Test
	public void getAllRuleClassificationsAPI() throws Exception {
		String tok = getTokenFromLogin("john", "U2VjcmV0LWRvZQ==");
		ResultActions mvcResult = mockMvc.perform(
				MockMvcRequestBuilders.get("/messages").header("token", tok).accept(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(status().isOk());

		int status = mvcResult.andReturn().getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.andReturn().getResponse().getContentAsString();
		Message[] messagelist = objMapper.readValue(content, Message[].class);
		assertTrue(messagelist.length > 0);
	}
	
}
