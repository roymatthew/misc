package com.ode.exchange.re.etlutils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * @author rmathew
 *
 */
public class NumberFormatUtilsTest {

	@Test
	public void test() {
		
		String val = "35635.5245535435";
		assertEquals("35635.52", NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val));
		
		val = "35635.5265535435";
		assertEquals("35635.53", NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val));
		
		val = "35635.52";
		assertEquals("35635.52", NumberFormatUtils.getAmountRoundedToTwoDecimalPlacesAsString(val));
	}

}
