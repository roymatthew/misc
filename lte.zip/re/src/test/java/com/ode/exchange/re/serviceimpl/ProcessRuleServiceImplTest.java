/**
 *
 */
package com.ode.exchange.re.serviceimpl;

import com.ode.exchange.re.entity.CreditDecision;
import com.ode.exchange.re.entity.ProcessAudit;
import com.ode.exchange.re.entity.Rule;
import com.ode.exchange.re.entity.RuleClassification;
import com.ode.exchange.re.etlconstants.Constants;
import com.ode.exchange.re.repository.IRuleDAO;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for ProcessRuleServiceImpl
 *
 * @see com.ode.exchange.re.serviceimpl.ProcessRuleServiceImpl
 * @author rmathew
 */
public class ProcessRuleServiceImplTest {

	@InjectMocks
	private	ProcessRuleServiceImpl underTest = new ProcessRuleServiceImpl();
	@Mock
	private IRuleDAO ruleDAO;
	@Mock
	private CreditDecisionServiceImpl creditDecisionService = new CreditDecisionServiceImpl();




	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
		Mockito.doReturn(getMockCreditDecisions()).when(creditDecisionService).getCreditDecisionAll();
		Mockito.doReturn(getMockRFLRules()).when(ruleDAO).findByRFL();
	}


	private List<Rule> getMockRFLRules() {
		List<Rule> listOfRflRules = new ArrayList<>();

		Rule contract = new Rule();
		contract.setId(43);
		contract.setRuleName("Contract");
		contract.setLookupCriteria("{\"FinanceType\":\"R\"}");
		contract.setRuleLogic("[{\"expressionType\":\"OPERATOR\",\"value\":\"IFEXIST\"},{\"expressionType\":\"FIELD\",\"value\":\"AmountFinanced\",\"fieldExpressionPrefix\":\"CO\"}]");
		contract.setRemarks("Retail Installment Contract must exist as RFL for all Retail deals");
		contract.setStatus('A');
		contract.setCreatedDate(new Date(System.currentTimeMillis()));
		contract.setCreatedBy(25);

		RuleClassification rCContract = new RuleClassification();
		rCContract.setId(66);
		rCContract.setRcName("Required Form List");
		rCContract.setRemarks("This is Lookup Configuration for Required Form List Classification");
		contract.setRuleClassification(rCContract);
		listOfRflRules.add(contract);

		Rule invoice = new Rule();
		invoice.setId(35);
		invoice.setRuleName("Invoice");
		invoice.setLookupCriteria("{\"FinanceType\":\"R\"}");
		invoice.setRuleLogic("[{\"expressionType\":\"FIELD\",\"value\":\"VehicleSaleClass\",\"fieldExpressionPrefix\":\"CO\"},{\"expressionType\":\"OPERATOR\",\"value\":\"=\"},{\"expressionType\":\"VALUE\",\"value\":\"New\"}]");
		invoice.setRemarks("Some text about invoice");
		invoice.setStatus('A');
		invoice.setCreatedDate(new Date(System.currentTimeMillis()));
		invoice.setCreatedBy(25);

		RuleClassification rCInvoice = new RuleClassification();
		rCInvoice.setId(66);
		rCInvoice.setRcName("Required Form List");
		rCInvoice.setRemarks("This is Lookup Configuration for Required Form List Classification");
		invoice.setRuleClassification(rCInvoice);
		listOfRflRules.add(invoice);



		return listOfRflRules;
	}


	private List<CreditDecision> getMockCreditDecisions() {
		List<CreditDecision> listOfCDs = new ArrayList<>();
		CreditDecision cd = new CreditDecision();
		cd.setApplicationNumber("100abcd");
		cd.setConversationId("100abcd");
		listOfCDs.add(cd);
		return listOfCDs;
	}


	/**
	 * Parasoft Jtest UTA: Test for getRuleByRFL(List)
	 *
	 * @see com.ode.exchange.re.serviceimpl.ProcessRuleServiceImpl#getRuleByRFL(List)
	 * @author rmathew
	 */
	// @Test
	// public void testGetRuleByRFL() throws Throwable {
	// // Given
	//
	//
	// // When
	// List<XMLFieldsDTO> xmlfieldsDTOList = new ArrayList<XMLFieldsDTO>(); //
	// UTA: default value
	// List<String> xmlFieldsList = new ArrayList<String>(); // UTA: default
	// value
	// //xmlFieldsList.add("AmountFinanced");
	// //xmlFieldsList.add("VehicleSaleClass");
	//
	// /*XMLFieldsDTO xMLFieldsDTO = new XMLFieldsDTO();
	// xMLFieldsDTO.setFieldName("AmountFinanced");
	// xMLFieldsDTO.setFieldType("FIELD");
	// xMLFieldsDTO.setFieldValue("AmountFinanced");
	// xmlfieldsDTOList.add(xMLFieldsDTO);*/
	//
	// XMLFieldsDTO xMLFieldsDTO = new XMLFieldsDTO();
	// xMLFieldsDTO.setFieldName("VehicleSaleClass");
	// xMLFieldsDTO.setFieldType("TEXT");
	// xMLFieldsDTO.setFieldValue("New");
	// xmlfieldsDTOList.add(xMLFieldsDTO);
	//
	//
	// Map<String, String> xmlLookUpFieldMap = new HashMap<String, String>(); //
	// UTA: default value
	// xmlLookUpFieldMap.put("FinanceType", "R");
	// //xmlLookUpFieldMap.put("VehicleSaleClass", "New");
	// Map<String, String> xmlFieldValueMap = new HashMap<String, String>(); //
	// UTA: default value
	// xmlFieldValueMap.put("ApplicationNumber","100abcd");
	// xmlFieldValueMap.put("AmountFinanced", "1000");
	// xmlFieldValueMap.put("VehicleSaleClass", "New");
	// ProcessAudit processAudit = getMockProcessAudit(); // UTA: default value
	// List<Calculation> calcList = new ArrayList<Calculation>(); // UTA:
	// default value
	// Optional<RFLRuleResponse> result =
	// underTest.getRuleByRFL(xmlfieldsDTOList, xmlFieldsList,
	// xmlLookUpFieldMap,
	// xmlFieldValueMap, processAudit, calcList);
	//
	// // Then
	// assertNotNull(result);
	// assertTrue(result.isPresent());
	// RFLRuleResponse rFLRuleResponse = result.get();
	// assertNotNull(rFLRuleResponse);
	// assertNotNull(rFLRuleResponse.getPassedRFLs());
	// }


	private ProcessAudit getMockProcessAudit() {
		ProcessAudit processAudit = new ProcessAudit();
		return processAudit;
	}
	
	@Test
	public void testIsSpotValidationTrue() {
		// Given SpotDeliveryInd is 1 and no credit app
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "1");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		// When evaluating if SPOT validation is required
		Boolean result = underTest.isSpotValidation(xmlFieldValueMap, creditDecisionList);
		// Then true should be returned
		assertTrue("isSpotValidation did not return true when SpotDeliveryInd is 1 and no credit app", result);
	}
	
	@Test
	public void testIsSpotValidationFalse() {
		// Given SpotDeliveryInd is 0 and one credit app
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision = new CreditDecision();
		creditDecisionList.add(creditDecision);
		// When evaluating if SPOT validation is required
		Boolean result = underTest.isSpotValidation(xmlFieldValueMap, creditDecisionList);
		// Then false should be returned
		assertTrue("isSpotValidation did not return false when SpotDeliveryInd is 0 and one credit app", !result);
	}
	
	@Test
	public void testIsSpotValidationNoSpotDeliveryInd() {
		// Given SpotDeliveryInd is not present and one credit app
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put("foo", "bar");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision = new CreditDecision();
		creditDecisionList.add(creditDecision);
		// When evaluating if SPOT validation is required
		Boolean result = underTest.isSpotValidation(xmlFieldValueMap, creditDecisionList);
		// Then false should be returned
		assertTrue("isSpotValidation did not return false when SpotDeliveryInd is not present and one credit app", !result);
	}
	
	@Test
	public void testIsSpotValidationCreditAppAndSpotDeliveryInd() {
		// Given SpotDeliveryInd is 1 and one credit app
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "1");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision = new CreditDecision();
		creditDecisionList.add(creditDecision);
		// When evaluating if SPOT validation is required
		Boolean result = underTest.isSpotValidation(xmlFieldValueMap, creditDecisionList);
		Boolean isSpotDeliveryInd0 = xmlFieldValueMap.get(Constants.SPOT_DELIVERY_IND_TAG_NAME).contentEquals("0");
		// Then false should be returned and SpotDeliveryInd should be set to 0
		assertTrue("isSpotValidation did not return false when SpotDeliveryInd is 1 and one credit app", !result);
		assertTrue("isSpotValidation did not set SpotDeliveryInd to 0 when SpotDeliveryInd is 1 and one credit app", isSpotDeliveryInd0);
	}
	
	@Test
	public void testGetCreditListApplicationNumberMatch() {
		// Given ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 123 and 
		// the second CreditDecision has ApplicationNumber 456
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("123");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("456");
		creditDecisionList.add(creditDecision2);
		// When getting the credit list
		List<CreditDecision> creditList = underTest.getCreditList(xmlFieldValueMap, creditDecisionList);
		Boolean isListOfOneCreditDecision = creditList.size() == 1;
		Boolean isApplicationNumber123 = creditList.get(0).getApplicationNumber().contentEquals("123");
		// Then a list with only the first CreditDecision should be returned
		assertTrue("getCreditList did not return only one CreditDecision", isListOfOneCreditDecision);
		assertTrue("getCreditList did not return the correct CreditDecision", isApplicationNumber123);
	}
	
	@Test
	public void testGetCreditListApplicationNumberMatchNotFirst() {
		// Given ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 456 and 
		// the second CreditDecision has ApplicationNumber 123
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("456");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("123");
		creditDecisionList.add(creditDecision2);
		// When getting the credit list
		List<CreditDecision> creditList = underTest.getCreditList(xmlFieldValueMap, creditDecisionList);
		// Then a list with both CreditDecision should be returned
		assertTrue("getCreditList did not return both CreditDecision", creditList.size() == 2);
	}
	
	@Test
	public void testGetCreditListApplicationNumberNoMatch() {
		// Given ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 456 and 
		// the second CreditDecision has ApplicationNumber 789
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("456");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("789");
		creditDecisionList.add(creditDecision2);
		// When getting the credit list
		List<CreditDecision> creditList = underTest.getCreditList(xmlFieldValueMap, creditDecisionList);
		// Then a list with both CreditDecision should be returned
		assertTrue("getCreditList did not return both CreditDecision", creditList.size() == 2);
	}
	
	@Test
	public void testGetCreditListNoApplicationNumber() {
		// Given ApplicationNumber is not set 
		// the first CreditDecision has ApplicationNumber 456 and 
		// the second CreditDecision has ApplicationNumber 789
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put("foo", "bar");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("456");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("789");
		creditDecisionList.add(creditDecision2);
		// When getting the credit list
		List<CreditDecision> creditList = underTest.getCreditList(xmlFieldValueMap, creditDecisionList);
		// Then a list with both CreditDecision should be returned
		assertTrue("getCreditList did not return both CreditDecision", creditList.size() == 2);
	}
	
	@Test
	public void testGetCreditListNoCreditDecision() {
		// Given ApplicationNumber is 123 and 
		// there are no CreditDecision
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = null;
		// When getting the credit list
		List<CreditDecision> creditList = underTest.getCreditList(xmlFieldValueMap, creditDecisionList);
		// Then an empty list should be returned
		assertTrue("getCreditList did not return an empty list", creditList.isEmpty());
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenSpotTrue() {
		// Given a Spot deal (SpotDeliveryInd is 1 and no credit app)
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "1");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then true should be returned
		assertTrue("validateCreditDecisionOrSpot did not return true for a Spot deal", result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenCreditDecisionMatch() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 123 and 
		// the second CreditDecision has ApplicationNumber 456
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("123");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("456");
		creditDecisionList.add(creditDecision2);
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then true should be returned
		assertTrue("validateCreditDecisionOrSpot did not return true for a deal with a matching CreditDecision", result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenCreditDecisionMatchAndSpot() {
		// Given SpotDeliveryInd is 1 and 
		// ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 123 and 
		// the second CreditDecision has ApplicationNumber 456
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "1");
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("123");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("456");
		creditDecisionList.add(creditDecision2);
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		Boolean isSpotDeliveryInd0 = xmlFieldValueMap.get(Constants.SPOT_DELIVERY_IND_TAG_NAME).contentEquals("0");
		// Then true should be returned and SpotDeliveryInd should be set to 0
		assertTrue("validateCreditDecisionOrSpot did not return true for a deal with a matching CreditDecision", result);
		assertTrue("validateCreditDecisionOrSpot did not set SpotDeliveryInd to 0", isSpotDeliveryInd0);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenCreditDecisionMatchNotFirst() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 456 and 
		// the second CreditDecision has ApplicationNumber 123
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("456");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("123");
		creditDecisionList.add(creditDecision2);
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then false should be returned
		assertTrue("validateCreditDecisionOrSpot did not return false for a deal with the matching CreditDecision not most recent", !result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenCreditDecisionNoMatch() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is 123 and 
		// the first CreditDecision has ApplicationNumber 456 and 
		// the second CreditDecision has ApplicationNumber 789
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("456");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("789");
		creditDecisionList.add(creditDecision2);
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then false should be returned
		assertTrue("validateCreditDecisionOrSpot did not return false for a deal with no matching CreditDecision", !result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenNoCreditDecision() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is 123 and 
		// there is no CreditDecision
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("ApplicationNumber", "123");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then false should be returned
		assertTrue("validateCreditDecisionOrSpot did not return false for a deal with no CreditDecision", !result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenNoApplicationNumberAndOneCreditDecision() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is not set and 
		// there is one CreditDecision with ApplicationNumber 123
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("foo", "bar");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("123");
		creditDecisionList.add(creditDecision1);
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then true should be returned
		assertTrue("validateCreditDecisionOrSpot did not return true for a deal with no ApplicationNumber and one CreditDecision", result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenNoApplicationNumberAndNoCreditDecision() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is not set and 
		// there is no CreditDecision
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("foo", "bar");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then false should be returned
		assertTrue("validateCreditDecisionOrSpot did not return false for a deal with no ApplicationNumber and no CreditDecision", !result);
	}
	
	@Test
	public void testValidateCreditDecisionOrSpotWhenNoApplicationNumberAndMultipleCreditDecision() {
		// Given SpotDeliveryInd is 0 and 
		// ApplicationNumber is not set and 
		// there is a CreditDecision with ApplicationNumber 123 and 
		// there is a CreditDecision with ApplicationNumber 456
		Map<String, String> xmlFieldValueMap = new HashMap<>();
		xmlFieldValueMap.put(Constants.SPOT_DELIVERY_IND_TAG_NAME, "0");
		xmlFieldValueMap.put("foo", "bar");
		List<CreditDecision> creditDecisionList = new ArrayList<>();
		CreditDecision creditDecision1 = new CreditDecision();
		creditDecision1.setApplicationNumber("123");
		creditDecisionList.add(creditDecision1);
		CreditDecision creditDecision2 = new CreditDecision();
		creditDecision2.setApplicationNumber("456");
		creditDecisionList.add(creditDecision2);
		ProcessAudit processAudit = new ProcessAudit();
		// When validating CreditDecision or Spot
		Boolean result = underTest.validateCreditDecisionOrSpot(xmlFieldValueMap, processAudit, creditDecisionList);
		// Then false should be returned
		assertTrue("validateCreditDecisionOrSpot did not return false for a deal with no ApplicationNumber and multiple CreditDecision", !result);
	}
}