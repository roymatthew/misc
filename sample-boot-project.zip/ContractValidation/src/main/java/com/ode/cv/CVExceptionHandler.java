/**
 * 
 */
package com.ode.cv;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author rmathew
 *
 */
@RestControllerAdvice
public class CVExceptionHandler {
    
    /**
     * Instance of org.apache.logging.log4j.Logger.
     */
    private static final Logger logger = LogManager.getLogger(CVExceptionHandler.class);
    
    /**
     * @param 
     * @return
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler({ Exception.class })
    public @ResponseBody String handleException(final Exception ex) {
        logger.debug("Entered handleException()", ex);
        // return new ResponseEntity<Object>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        String responseMessage = ex.getMessage();
        return responseMessage;
    }

}
