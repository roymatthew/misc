package com.ode.cv.bo;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.persistence.service.DcFormRepoService;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DeDmsVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public abstract class AbstractDmsBO implements IDmsBO {
	
	private static final Logger logger = LogManager.getLogger(AbstractDmsBO.class);

    /**
     * Enum that holds the Id and Name of the real world DMS.
     */
    protected DeDmsVO deDms = null;

    /**
     * Getter for DMS.
     *
     * @return
     */
    public DeDmsVO getDeDms() {
        return deDms;
    }

    /**
     * Setter for DMS.
     *
     * @param dms
     */
    public void setDeDms(final DeDmsVO dms) {
        this.deDms = deDms;
    }
    
    @Override
	@Transactional(value = "transactionManager")
	public void saveRFL(List<DcFormVO> listOfForms, final DcFormRepoService dcFormRepoService,
			final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered saveRFL method of AbstractDmsBO class");

		if (null != listOfForms && !listOfForms.isEmpty()) {
			logger.debug("There are {} RFL forms to save to DB.", listOfForms.size());
			listOfForms.stream().forEach(form -> {
				form.setDeDealId(cvTransmitVO.getDealVO().getDeDealId());
				DcFormVO dcFormVO = dcFormRepoService.saveDcForm(form);
				logger.debug("Saved DcFormVO with primary key: {}", dcFormVO.getDcFormId());
			});
		}
	}

}
