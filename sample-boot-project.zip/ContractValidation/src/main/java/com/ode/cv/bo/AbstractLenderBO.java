package com.ode.cv.bo;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author rmathew
 *
 */
public abstract class AbstractLenderBO implements ILenderBO {

    private static final Logger logger = LogManager.getLogger(AbstractLenderBO.class);

    protected String lenderId;
    protected String partyId;
    
    public String getLenderId() {
		return lenderId;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	/* (non-Javadoc)
     * @see com.ode.cv.bo.ILenderBO#isEcoutChangesRequired()
     */
    public Boolean isEcoutChangesRequired()
    {
    	return Boolean.FALSE;
    }

}
