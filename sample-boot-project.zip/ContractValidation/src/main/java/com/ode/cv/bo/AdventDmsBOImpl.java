package com.ode.cv.bo;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.persistence.vo.DeDmsVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author rmathew
 *
 */
public class AdventDmsBOImpl extends AbstractDmsBO {
	
    private static final Logger logger = LogManager.getLogger(AdventDmsBOImpl.class);

	public AdventDmsBOImpl() {
	}

	public AdventDmsBOImpl(final DeDmsVO deDmsVO) {
		super();
		super.deDms = deDmsVO;
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public String getDmsId() {
        return super.deDms.getDmsId();
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public Boolean isRFLRequiredWithACCR() {
		logger.debug("Entered isRFLRequiredWithACCR method of AdventDmsBOImpl class");
		return Boolean.FALSE;
	}

    /**
     * {@inheritDoc}
     */
	@Override
	public Boolean isStaticRFLRequiredWithACCR(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered isStaticRFLRequiredWithACCR method of AdventDmsBOImpl class");
		return Boolean.FALSE;
	}

}
