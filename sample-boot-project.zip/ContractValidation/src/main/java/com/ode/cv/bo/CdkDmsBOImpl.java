package com.ode.cv.bo;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.persistence.service.DcFormRepoService;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DeDmsVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public class CdkDmsBOImpl extends AbstractDmsBO {

	private static final Logger logger = LogManager.getLogger(CdkDmsBOImpl.class);

	@Override
	public String toString() {
		return "CdkBO [deDms=" + deDms + "]";
	}

	/**
	 * Constructor.
	 */
	public CdkDmsBOImpl() {
		super();
	}

	/**
	 * Constructor.
	 */
	public CdkDmsBOImpl(final DeDmsVO deDmsVO) {
		super();
		super.deDms = deDmsVO;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getDmsId() {
		return super.deDms.getDmsId();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Boolean isRFLRequiredWithACCR() {
		logger.debug("Entered isRFLRequiredWithACCR method of CdkDmsBOImpl class");
		return Boolean.TRUE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@Transactional(value = "transactionManager")
	public void saveRFL(List<DcFormVO> listOfForms, final DcFormRepoService dcFormRepoService,
			final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered saveRFL method of CdkDmsBOImpl class");

		if (null != listOfForms && !listOfForms.isEmpty()) {
			logger.debug("There are {} RFL forms to save to DB.", listOfForms.size());
			listOfForms.stream().forEach(form -> {
				form.setDeDealId(cvTransmitVO.getDealVO().getDeDealId());
				DcFormVO dcFormVO = dcFormRepoService.saveDcForm(form);
				logger.debug("Saved DcFormVO with primary key: {}", dcFormVO.getDcFormId());
			});
		}

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Boolean isStaticRFLRequiredWithACCR(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered isStaticRFLRequiredWithACCR method of CdkDmsBOImpl class. {}",
				cvTransmitVO.isStaticRFLEnabled());
		return cvTransmitVO.isStaticRFLEnabled();
	}

}
