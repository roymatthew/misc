/**
 * 
 */
package com.ode.cv.bo;

import java.util.Map;

import org.w3c.dom.Document;

import com.ode.cv.vo.CreditContractVO;

/**
 * @author rmathew
 *
 */
public class GenericLenderBO extends AbstractLenderBO {

	@Override
	public Document makeChangesToEcout(final CreditContractVO creditContractVO, final Document document, Map<String, String> webSvcFeatures) {
		return document;
	}

}
