package com.ode.cv.bo;

import java.util.List;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.persistence.service.DcFormRepoService;
import com.ode.persistence.vo.DcFormVO;

/**
 * @author rmathew
 *
 */
public interface IDmsBO {
	
	String getDmsId();

	/**
	 * @return
	 */
	Boolean isRFLRequiredWithACCR();
	
	/**
	 * @return
	 */
	Boolean isStaticRFLRequiredWithACCR(final CVTransmitVO cvTransmitVO);
	
	/**
	 * @param listOfForms
	 * @param cvTransmitVO 
	 */
	void saveRFL(final List<DcFormVO> listOfForms, final DcFormRepoService dcFormRepoService, final CVTransmitVO cvTransmitVO);

}
