/**
 * 
 */
package com.ode.cv.bo;

import java.util.Map;

import org.w3c.dom.Document;

import com.ode.cv.vo.CreditContractVO;

/**
 * @author rmathew
 *
 */
public interface ILenderBO {
	
	/**
	 * @param creditContractVO
	 * @param inEcout
	 * @return
	 */
	Document makeChangesToEcout(final CreditContractVO creditContractVO, final Document document, Map<String, String> webSvcFeatures);
	
	/**
	 * @return
	 */
	Boolean isEcoutChangesRequired();

}
