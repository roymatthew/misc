package com.ode.cv.bo;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.persistence.service.DcFormRepoService;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DeDmsVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public class ReynoldsDmsBOImpl extends AbstractDmsBO {

	private static final Logger logger = LogManager.getLogger(ReynoldsDmsBOImpl.class);

	/**
	 * Constructor.
	 */
	public ReynoldsDmsBOImpl() {
		super();
	}

	/**
	 * Constructor.
	 */
	public ReynoldsDmsBOImpl(final DeDmsVO deDmsVO) {
		super();
		super.deDms = deDmsVO;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getDmsId() {
		return super.deDms.getDmsId();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Boolean isRFLRequiredWithACCR() {
		logger.debug("Entered isRFLRequiredWithACCR method of ReynoldsDmsBOImpl class");
		return Boolean.FALSE;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@Transactional(value = "transactionManager")
	public void saveRFL(List<DcFormVO> listOfForms, final DcFormRepoService dcFormRepoService,
			final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered saveRFL method of ReynoldsDmsBOImpl class");
		if (null != listOfForms && !listOfForms.isEmpty()) {
			logger.debug("There are {} RFL forms to save to DB.", listOfForms.size());
			listOfForms.stream().forEach(form -> {
				form.setDeDealId(cvTransmitVO.getDealVO().getDeDealId());
				DcFormVO dcFormVO = dcFormRepoService.saveDcForm(form);
				logger.debug("Saved DcFormVO with primary key: {}", dcFormVO.getDcFormId());
			});
		}

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Boolean isStaticRFLRequiredWithACCR(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered isStaticRFLRequiredWithACCR method of ReynoldsDmsBOImpl class. {}",
				cvTransmitVO.isStaticRFLEnabled());
		return cvTransmitVO.isStaticRFLEnabled();
	}

}