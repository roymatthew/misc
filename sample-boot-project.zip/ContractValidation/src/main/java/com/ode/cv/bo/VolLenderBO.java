/**
 * 
 */
package com.ode.cv.bo;

import java.time.Instant;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ode.cv.util.Constants;
import com.ode.cv.vo.CreditContractVO;

/**
 * @author rmathew
 *
 */
public class VolLenderBO extends AbstractLenderBO {

	private static final Logger logger = LogManager.getLogger(VolLenderBO.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ode.cv.bo.AbstractLenderBO#isEcoutChangesRequired()
	 */
	public Boolean isEcoutChangesRequired() {
		return Boolean.TRUE;
	}

	@Override
	public Document makeChangesToEcout(final CreditContractVO creditContractVO, final Document document,
			final Map<String, String> webSvcFeatures) {

		logger.debug("Entered makeChangesToEcout() method of VolLenderBO class");
		
		if (null == webSvcFeatures || webSvcFeatures.isEmpty())
		{
			logger.error("Could not find feature configurations for VOL! Please check DB configuration.");
			logger.debug("Returning document as is.");
			return document;
		}

		final NodeList soapHeaderNodeList = document.getElementsByTagName("soap:Header");
		if (null != soapHeaderNodeList && soapHeaderNodeList.getLength() > 0) {
			Node soapHeaderNode = soapHeaderNodeList.item(0);
			Element fASServiceControlElement = document.createElement(Constants.SOAP_HEADER_FA_SVC_CNTRL);
			fASServiceControlElement.setAttribute(Constants.NS_PREFIX_XMLNS_H_NAME, Constants.NS_XMLNS_H_VALUE);
			fASServiceControlElement.setAttribute(Constants.NS_PREFIX_XMLNS_NAME, Constants.NS_XMLNS_H_VALUE);
			fASServiceControlElement.setAttribute(Constants.NS_PREFIX_XMLNS_XSD_NAME, Constants.NS_XMLNS_XSD_VALUE);
			fASServiceControlElement.setAttribute(Constants.NS_PREFIX_XMLNS_XSI_NAME, Constants.NS_XMLNS_XSI_VALUE);
			Element languageCodeElement = document.createElement(Constants.SOAP_HEADER_MSG_LANG_CODE);
			languageCodeElement.setTextContent(webSvcFeatures.get(Constants.SOAP_HEADER_MSG_LANG_CODE));
			Element senderIdElement = document.createElement(Constants.SOAP_HEADER_SENDER_ID);
			senderIdElement.setTextContent(webSvcFeatures.get(Constants.SOAP_HEADER_SENDER_ID));
			Element timeStampElement = document.createElement(Constants.SOAP_HEADER_SENT_TS);
/*			String createdTs =  null;
			try {
				createdTs = XPathAPI.eval(document, "//payload/content/ProcessCreditContract/ApplicationArea/CreationDateTime").toString();
			} catch (final TransformerException e) {
				createdTs = Instant.now().toString();
			}*/
			timeStampElement.setTextContent(Instant.now().toString());
			Element targetIDElement = document.createElement(Constants.SOAP_HEADER_TARGET_ID);
			targetIDElement.setTextContent(webSvcFeatures.get(Constants.SOAP_HEADER_TARGET_ID));
			Element correlationID = document.createElement(Constants.SOAP_HEADER_CORRELATION_ID);
			correlationID.setTextContent(creditContractVO.getDocumentId());
			Element messageType = document.createElement(Constants.SOAP_HEADER_MESSAGE_TYPE);
			messageType.setTextContent(webSvcFeatures.get(Constants.SOAP_HEADER_MESSAGE_TYPE));

			fASServiceControlElement.appendChild(languageCodeElement);
			fASServiceControlElement.appendChild(senderIdElement);
			fASServiceControlElement.appendChild(timeStampElement);
			fASServiceControlElement.appendChild(targetIDElement);
			fASServiceControlElement.appendChild(correlationID);
			fASServiceControlElement.appendChild(messageType);

			if (soapHeaderNode instanceof Element) {
				Element soapHeaderElement = (Element) soapHeaderNode;
				soapHeaderElement.appendChild(fASServiceControlElement);
				soapHeaderElement.removeChild(document.getElementsByTagName(Constants.TAG_NAME_PAYLOAD_MANIFEST).item(0));
			}

		}
		return restructureSoapBody(document, webSvcFeatures);
	}

	/**
	 * @param document
	 * @return
	 */
	private Document restructureSoapBody(final Document document, final Map<String, String> webSvcFeatures) {
		logger.debug("Entered restructureSoapBody() method of VolLenderBO class");
		final NodeList soapBodyNodeList = document.getElementsByTagName(Constants.TAG_NAME_SOAP_BODY);
		if (null != soapBodyNodeList && soapBodyNodeList.getLength() > 0) {
			Node soapBodyNode = soapBodyNodeList.item(0);
			if (soapBodyNode instanceof Element) {
				Element soapBodyElement = (Element) soapBodyNode;
				Element putRequestElement = document.createElement(Constants.TAG_NAME_PUT_REQUEST);
				putRequestElement.setAttribute(Constants.NS_PREFIX_XMLNS_NAME, webSvcFeatures.get(Constants.PUT_REQUEST_XMLNS));
				Element messageElement = document.createElement("message");
				putRequestElement.appendChild(messageElement);
				final NodeList pccNodeList = document.getElementsByTagName(Constants.TAG_NAME_PCC);
				if (null != pccNodeList && pccNodeList.getLength() > 0) {
					Node pccNode = pccNodeList.item(0);
					if (pccNode instanceof Element) {
						Element pccElement = (Element) pccNode;
						messageElement.appendChild(pccElement);
					}
				}
				soapBodyElement.appendChild(putRequestElement);
				soapBodyElement.removeChild(document.getElementsByTagName(Constants.TAG_NAME_PROCESS_MESSAGE).item(0));
			}
		}

		return document;
	}

}
