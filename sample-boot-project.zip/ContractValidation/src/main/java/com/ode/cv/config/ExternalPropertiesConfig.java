package com.ode.cv.config;

import java.net.MalformedURLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

@Configuration
public class ExternalPropertiesConfig {

	@Bean
	public static PropertySourcesPlaceholderConfigurer properties() throws MalformedURLException {
		PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
		/*
		 * Resource[] resources = new ClassPathResource[ ] { new ClassPathResource(
		 * "../data/ode/lp/config/xpathprops.properties" ) };
		 */
		/*
		 * Resource[] resources = new UrlResource[] {new
		 * UrlResource("/data/ode/lp/config/xpathprops.properties")};
		 */
		Resource[] resources = new FileSystemResource[] {
				new FileSystemResource("/data/ode/cv/config/xpathprops.properties"),
				new FileSystemResource("/data/ode/cv/config/cv.properties") };
		pspc.setLocations(resources);
		pspc.setIgnoreUnresolvablePlaceholders(true);
		return pspc;
	}
}
