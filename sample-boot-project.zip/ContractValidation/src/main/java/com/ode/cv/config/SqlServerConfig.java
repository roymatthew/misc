/**
 * 
 */
package com.ode.cv.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author rmathew
 *
 */
@Configuration
@Profile("local")
@EnableJpaRepositories(
		  basePackages = "com.ode.cv.persistence",
		  entityManagerFactoryRef = "sqlServerEntityManagerFactory",
		  transactionManagerRef = "sqlServerTransactionManager")
@EntityScan("com.ode.cv.persistence.*")
@ComponentScan({ "com.ode.cv.persistence.*" })
@EnableTransactionManagement
public class SqlServerConfig {
	
	@Bean(name="sqlServerDataSource")
    @ConfigurationProperties(prefix="spring.sqlserver-datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}
	
    @Bean(name="sqlServerJdbcTemplate")
    public JdbcTemplate jdbcTemplate(DataSource dataSource)
    {
        return new JdbcTemplate(dataSource);
    }


	@Bean(name="sqlServerEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dataSource());
		em.setPackagesToScan(new String[] { "com.ode.cv.persistence" });

		JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		em.setJpaProperties(hibernateProperties());
		em.setPersistenceUnitName("sqlServerPersistence");

		return em;
	}

	@Bean(name="sqlServerTransactionManager")
	public PlatformTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return transactionManager;
	}

	private final Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.SQLServer2012Dialect");
		hibernateProperties.setProperty("format_sql", "true");

		return hibernateProperties;
	}

}
