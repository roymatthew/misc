/**
 * 
 */
package com.ode.cv.context;

import java.io.Serializable;

/**
 * @author snimma
 *
 */
public class AppIn implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String specialPrograms = null;

	public String getSpecialPrograms() {
		return specialPrograms;
	}

	public void setSpecialPrograms(String specialPrograms) {
		this.specialPrograms = specialPrograms;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AppIn [specialPrograms=");
		builder.append(specialPrograms);
		builder.append("]");
		return builder.toString();
	}

}
