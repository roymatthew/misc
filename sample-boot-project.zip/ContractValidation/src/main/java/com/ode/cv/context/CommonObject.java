/**
 * 
 */
package com.ode.cv.context;

import java.io.Serializable;

/**
 * @author snimma
 *
 */
public class CommonObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String vehicleMake = null;
	private String transactionId = null;
	private Object bodId = null;
	private String vehicleModel = null;
	private String saleClass = null;
	private String customerName = null;
	private String customerAddress = null;
	private String coApplicantName = null;
	private String coApplicantAddress = null;
	private String businessName = null;
	private String businessAddress = null;
	private String financeType = null;
	private String applicationType = null;
	private String term = null;
	private String dealerName = null;
	private String dealerAddress = null;
	private String dealerState = null;
	private String dealerCity = null;
	private String dealerZip = null;

	public String getVehicleMake() {
		return vehicleMake;
	}

	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Object getBodId() {
		return bodId;
	}

	public void setBodId(Object bodId) {
		this.bodId = bodId;
	}

	public String getVehicleModel() {
		return vehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}

	public String getSaleClass() {
		return saleClass;
	}

	public void setSaleClass(String saleClass) {
		this.saleClass = saleClass;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCoApplicantName() {
		return coApplicantName;
	}

	public void setCoApplicantName(String coApplicantName) {
		this.coApplicantName = coApplicantName;
	}

	public String getCoApplicantAddress() {
		return coApplicantAddress;
	}

	public void setCoApplicantAddress(String coApplicantAddress) {
		this.coApplicantAddress = coApplicantAddress;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getBusinessAddress() {
		return businessAddress;
	}

	public void setBusinessAddress(String businessAddress) {
		this.businessAddress = businessAddress;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getDealerAddress() {
		return dealerAddress;
	}

	public void setDealerAddress(String dealerAddress) {
		this.dealerAddress = dealerAddress;
	}

	public String getDealerState() {
		return dealerState;
	}

	public void setDealerState(String dealerState) {
		this.dealerState = dealerState;
	}

	public String getDealerCity() {
		return dealerCity;
	}

	public void setDealerCity(String dealerCity) {
		this.dealerCity = dealerCity;
	}

	public String getDealerZip() {
		return dealerZip;
	}

	public void setDealerZip(String dealerZip) {
		this.dealerZip = dealerZip;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CommonObject [vehicleMake=");
		builder.append(vehicleMake);
		builder.append(", transactionId=");
		builder.append(transactionId);
		builder.append(", bodId=");
		builder.append(bodId);
		builder.append(", vehicleModel=");
		builder.append(vehicleModel);
		builder.append(", saleClass=");
		builder.append(saleClass);
		builder.append(", customerName=");
		builder.append(customerName);
		builder.append(", customerAddress=");
		builder.append(customerAddress);
		builder.append(", coApplicantName=");
		builder.append(coApplicantName);
		builder.append(", coApplicantAddress=");
		builder.append(coApplicantAddress);
		builder.append(", businessName=");
		builder.append(businessName);
		builder.append(", businessAddress=");
		builder.append(businessAddress);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", applicationType=");
		builder.append(applicationType);
		builder.append(", term=");
		builder.append(term);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", dealerAddress=");
		builder.append(dealerAddress);
		builder.append(", dealerState=");
		builder.append(dealerState);
		builder.append(", dealerCity=");
		builder.append(dealerCity);
		builder.append(", dealerZip=");
		builder.append(dealerZip);
		builder.append("]");
		return builder.toString();
	}

}
