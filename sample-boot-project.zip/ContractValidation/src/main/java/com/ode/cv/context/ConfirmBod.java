/**
 * 
 */
package com.ode.cv.context;

import java.io.Serializable;

/**
 * @author snimma
 *
 */
public class ConfirmBod implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String statusCode = null;
	private String messageDescription = null;
	private String sourceConfBod = null;
	private String nounFailure = null;
	private String bodFailure = null;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessageDescription() {
		return messageDescription;
	}

	public void setMessageDescription(String messageDescription) {
		this.messageDescription = messageDescription;
	}

	public String getSourceConfBod() {
		return sourceConfBod;
	}

	public void setSourceConfBod(String sourceConfBod) {
		this.sourceConfBod = sourceConfBod;
	}

	public String getNounFailure() {
		return nounFailure;
	}

	public void setNounFailure(String nounFailure) {
		this.nounFailure = nounFailure;
	}

	public String getBodFailure() {
		return bodFailure;
	}

	public void setBodFailure(String bodFailure) {
		this.bodFailure = bodFailure;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConfirmBod [statusCode=");
		builder.append(statusCode);
		builder.append(", messageDescription=");
		builder.append(messageDescription);
		builder.append(", sourceConfBod=");
		builder.append(sourceConfBod);
		builder.append(", nounFailure=");
		builder.append(nounFailure);
		builder.append(", bodFailure=");
		builder.append(bodFailure);
		builder.append("]");
		return builder.toString();
	}

}
