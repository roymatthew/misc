package com.ode.cv.context;

import java.io.Serializable;

public class ContractValidationContext implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CommonObject commonObject = new CommonObject();

	private ConfirmBod confirmBod = new ConfirmBod();

	private EcIn ecIn = new EcIn();

	public CommonObject getCommonObject() {
		return commonObject;
	}

	public void setCommonObject(CommonObject commonObject) {
		this.commonObject = commonObject;
	}

	public ConfirmBod getConfirmBod() {
		return confirmBod;
	}

	public void setConfirmBod(ConfirmBod confirmBod) {
		this.confirmBod = confirmBod;
	}

	public EcIn getEcIn() {
		return ecIn;
	}

	public void setEcIn(EcIn ecIn) {
		this.ecIn = ecIn;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ContractValidationContext [commonObject=");
		builder.append(commonObject);
		builder.append(", confirmBod=");
		builder.append(confirmBod);
		builder.append(", ecIn=");
		builder.append(ecIn);
		builder.append("]");
		return builder.toString();
	}

}
