/**
 * 
 */
package com.ode.cv.context;

import java.io.Serializable;

/**
 * @author snimma
 *
 */
public class CreditApplicationContext implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CommonObject commonObject = new CommonObject();

	private ConfirmBod confirmBod = new ConfirmBod();

	private AppIn appIn = new AppIn();

	public CommonObject getCommonObject() {
		return commonObject;
	}

	public void setCommonObject(CommonObject commonObject) {
		this.commonObject = commonObject;
	}

	public ConfirmBod getConfirmBod() {
		return confirmBod;
	}

	public void setConfirmBod(ConfirmBod confirmBod) {
		this.confirmBod = confirmBod;
	}

	public AppIn getAppIn() {
		return appIn;
	}

	public void setAppIn(AppIn appIn) {
		this.appIn = appIn;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CreditApplicationContext [commonObject=");
		builder.append(commonObject);
		builder.append(", confirmBod=");
		builder.append(confirmBod);
		builder.append(", appIn=");
		builder.append(appIn);
		builder.append("]");
		return builder.toString();
	}

}
