package com.ode.cv.context;

import java.io.Serializable;

public class EcIn implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String productType = null;
	private String contractFormNumber = null;
	private String contractExecState = null;
	private String contractFormRevisionDate = null;

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;

	}

	public String getContractFormNumber() {
		return contractFormNumber;
	}

	public void setContractFormNumber(String contractFormNumber) {
		this.contractFormNumber = contractFormNumber;

	}

	public String getContractExecState() {
		return contractExecState;
	}

	public void setContractExecState(String contractExecState) {
		this.contractExecState = contractExecState;

	}

	public String getContractFormRevisionDate() {
		return contractFormRevisionDate;
	}

	public void setContractFormRevisionDate(String contractFormRevisionDate) {
		this.contractFormRevisionDate = contractFormRevisionDate;

	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EcIn [productType=");
		builder.append(productType);
		builder.append(", contractFormNumber=");
		builder.append(contractFormNumber);
		builder.append(", contractExecState=");
		builder.append(contractExecState);
		builder.append(", contractFormRevisionDate=");
		builder.append(contractFormRevisionDate);
		builder.append("]");
		return builder.toString();
	}

}
