package com.ode.cv.context;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import com.ode.cv.util.ApplpTransformer;
import com.ode.cv.vo.CreditContractVO;

/**
 * @author snimma
 *
 */
@Component
public class GenericCommonObjectBuilder extends ApplpTransformer implements ICommonObjectBuilder {

	private static final Logger log = LogManager.getLogger(GenericCommonObjectBuilder.class);

	/**
	 * {@inheritDoc} 
	 * @throws Exception
	 */
	public void buildCommonObject(final CreditContractVO creditContractVO, final Document document) throws Exception {
		
		log.debug("Entered buildCommonObject() of GenericCommonObjectBuilder class");
	
		creditContractVO.getEcContext().getCommonObject()
				.setDealerName(XPathAPI.eval(document, getXPath_GenericCreditContract_DealerName()).toString());
		creditContractVO.getEcContext().getCommonObject()
				.setDealerAddress(XPathAPI.eval(document, getXPath_GenericCreditContract_DealerAddress()).toString());
		creditContractVO.getEcContext().getCommonObject()
				.setDealerCity(XPathAPI.eval(document, getXPath_GenericCreditContract_DealerCity()).toString());
		creditContractVO.getEcContext().getCommonObject()
				.setDealerState(XPathAPI.eval(document, getXPath_GenericCreditContract_DealerState()).toString());
		creditContractVO.getEcContext().getCommonObject()
				.setDealerZip(XPathAPI.eval(document, getXPath_GenericCreditContract_DealerZip()).toString());
		creditContractVO.getEcContext().getEcIn()
				.setProductType(XPathAPI.eval(document, getXPath_GenericCreditContract_ProductType()).toString());
		creditContractVO.getEcContext().getEcIn().setContractFormNumber(
				XPathAPI.eval(document, getXPath_GenericCreditContract_ContractFormNumber()).toString());
		creditContractVO.getEcContext().getEcIn().setContractExecState(
				XPathAPI.eval(document, getXPath_GenericCreditContract_ContractExecState()).toString());
	}

}