package com.ode.cv.context;

import com.ode.cv.vo.CreditContractVO;
import org.w3c.dom.Document;

public interface ICommonObjectBuilder {
	
	/**
	 * @param creditContractVO
	 * @param document
	 * @throws Exception
	 */
	public void buildCommonObject(final CreditContractVO creditContractVO, final Document document) throws Exception;
}

