package com.ode.cv.context;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import com.ode.cv.util.ApplpTransformer;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.context.ICommonObjectBuilder;


/**
 * @author rmathew
 *
 */
@Component
public class StarCommonObjectBuilder extends ApplpTransformer implements
		ICommonObjectBuilder {
	
	private static final Logger log = LogManager.getLogger(StarCommonObjectBuilder.class);

	/**
	 * {@inheritDoc} 
	 * @throws Exception
	 */
	public void buildCommonObject(final CreditContractVO creditContractVO,
			Document document) throws Exception {

		log.debug("Entered buildCommonObject() of StarCommonObjectBuilder class");
		creditContractVO.getEcContext().getCommonObject().setDealerName(
				XPathAPI.eval(document, getDealerName()).toString());
		creditContractVO.getEcContext().getCommonObject().setDealerAddress(
				XPathAPI.eval(document, getDealerAddress()).toString());
		creditContractVO.getEcContext().getCommonObject().setDealerCity(
				XPathAPI.eval(document, getDealerCity()).toString());
		creditContractVO.getEcContext().getCommonObject().setDealerState(
				XPathAPI.eval(document, getDealerState()).toString());
		creditContractVO.getEcContext().getCommonObject().setDealerZip(
				XPathAPI.eval(document, getDealerZip()).toString());
		creditContractVO.getEcContext().getEcIn().setProductType(
				XPathAPI.eval(document, getProductType()).toString());
		creditContractVO.getEcContext().getEcIn().setContractFormNumber(
				XPathAPI.eval(document, getContractFormNumber())
						.toString());
		creditContractVO.getEcContext().getEcIn().setContractFormRevisionDate(
				XPathAPI.eval(document, getContractFormRevisionDate())
						.toString());
		creditContractVO.getEcContext().getEcIn().setContractExecState(
				XPathAPI.eval(document, getContractExecState())
						.toString());
	}

}
