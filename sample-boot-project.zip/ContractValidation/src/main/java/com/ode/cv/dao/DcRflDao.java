package com.ode.cv.dao;

import java.sql.Timestamp;

import com.ode.cv.vo.CVTransmitVO;

/**
 * @author rmathew
 *
 */
public interface DcRflDao {
	
	String ADD_DC_RFL_SQL = "INSERT INTO CRGATE.DC_RFL (DEAL_ID, SEQUENCE_ID, INBOUND_XML, BOD_ID, CREATOR_NAME_CODE, DESTINATION_NAME_CODE, "
			+ "LENDER_DEALER_ID, DMS_DEAL_ID, DEAL_STATUS, DEAL_COMMENT, CREATED_BY, CREATED_TS, MODIFIED_BY, MODIFIED_TS) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
	
	String FETCH_DC_RFL_SQL = "SELECT DEAL_ID FROM CRGATE.DC_RFL WHERE DEAL_ID = ? AND SEQUENCE_ID = ?";
	
	Boolean addDcRfl(final CVTransmitVO cvTransmitVO, final String rflSequenceId, final Timestamp currentTs);
}
