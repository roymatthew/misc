/**
 * 
 */
package com.ode.cv.dao;

import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ode.cv.util.Constants;
import com.ode.cv.vo.CVTransmitVO;

/**
 * @author rmathew
 *
 */
@Repository
public class DcRflDaoImpl implements DcRflDao {
	
	private static final Logger log = LogManager.getLogger(DcRflDaoImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	@Transactional(value = "transactionManager")
	public Boolean addDcRfl(final CVTransmitVO cvTransmitVO, final String rflSequenceId, final Timestamp currentTs) {
		
		log.debug("Entered addDcRfl() method of DcRflDaoImpl class");
		
		Object[] args = {cvTransmitVO.getDealVO().getDeDealId(), rflSequenceId};
		int[] argTypes = {Types.VARCHAR, Types.VARCHAR };
		
		String dealId = null;
		
		try {
			dealId = jdbcTemplate.queryForObject(FETCH_DC_RFL_SQL, args, argTypes, String.class);
		} catch (DataAccessException e) {
			log.debug("No DC_RFL record found with deDealId: {} and rflSequenceId: {}",
					cvTransmitVO.getDealVO().getDeDealId(), rflSequenceId);
		}
		
		if (StringUtils.isBlank(dealId)) {
			
			log.debug("About to insert new DC_RFL record with deDealId: {} and rflSequenceId: {}",
					cvTransmitVO.getDealVO().getDeDealId(), rflSequenceId);

			return jdbcTemplate.execute(ADD_DC_RFL_SQL, new PreparedStatementCallback<Boolean>() {
				@Override
				public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {

					ps.setString(1, cvTransmitVO.getDealVO().getDeDealId());
					ps.setString(2, rflSequenceId);
					ps.setLong(3, Long.valueOf(0));
					ps.setString(4, cvTransmitVO.getAccrContext().getBodId());
					ps.setString(5, Constants.APP_CV_CODE);
					ps.setString(6, cvTransmitVO.getAccrContext().getDestinationCode());
					ps.setString(7, cvTransmitVO.getDealerInfoVO().getDealerPartyId());
					ps.setString(8, cvTransmitVO.getAccrContext().getAdpDealNo());
					ps.setString(9, cvTransmitVO.getAccrContext().getFundingStatus());
					ps.setString(10, cvTransmitVO.getAccrContext().getFunderComments());
					ps.setString(11, Constants.APP_CV_CODE);
					ps.setTimestamp(12, currentTs);
					ps.setString(13, Constants.APP_CV_CODE);
					ps.setTimestamp(14, currentTs);
					return ps.execute();

				}
			});
		}
		return Boolean.TRUE;
 
	}

}
