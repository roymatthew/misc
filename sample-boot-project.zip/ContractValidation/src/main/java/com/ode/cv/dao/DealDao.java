/**
 * 
 */
package com.ode.cv.dao;

/**
 * @author rmathew
 *
 */
public interface DealDao {
	
	/**
	 * @return
	 */
	Integer getNextNumericValueForPrimaryKey();

}
