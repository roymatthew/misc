/**
 * 
 */
package com.ode.cv.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author rmathew
 *
 */
@Repository
public class DealDaoImpl implements DealDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String NEXT_VAL_SQL = "SELECT NEXT VALUE FOR crgate.DE_DEAL_ID_SEQ";
	
	public Integer getNextNumericValueForPrimaryKey()
	{
		Integer nextValue = jdbcTemplate.queryForObject(NEXT_VAL_SQL, Integer.class);
		return nextValue;
	}

}
