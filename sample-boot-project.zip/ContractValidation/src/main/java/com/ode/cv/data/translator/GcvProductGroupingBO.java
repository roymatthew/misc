package com.ode.cv.data.translator;

public class GcvProductGroupingBO {
	private long gcvProductGroupingId;
	private String description;
	private String amount;
	private String indicator;
	private String rate;
	private String limit;
	private String term;
	private String defaultProduct;
	private String defaultType;

	public long getGcvProductGroupingId() {
		return gcvProductGroupingId;
	}

	public void setGcvProductGroupingId(long gcvProductGroupingId) {
		this.gcvProductGroupingId = gcvProductGroupingId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getDefaultProduct() {
		return defaultProduct;
	}

	public void setDefaultProduct(String defaultProduct) {
		this.defaultProduct = defaultProduct;
	}

	public String getDefaultType() {
		return defaultType;
	}

	public void setDefault_type(String defaultType) {
		this.defaultType = defaultType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GcvProductGroupingBO [gcvProductGroupingId=");
		builder.append(gcvProductGroupingId);
		builder.append(", description=");
		builder.append(description);
		builder.append(", amount=");
		builder.append(amount);
		builder.append(", indicator=");
		builder.append(indicator);
		builder.append(", rate=");
		builder.append(rate);
		builder.append(", limit=");
		builder.append(limit);
		builder.append(", term=");
		builder.append(term);
		builder.append(", defaultProduct=");
		builder.append(defaultProduct);
		builder.append(", defaultType=");
		builder.append(defaultType);
		builder.append("]");
		return builder.toString();
	}
}