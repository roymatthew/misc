package com.ode.cv.data.translator;

public class GcvProductTranslationBO {
	private String incomingDescription;
	private String dealerId;
	private String product;
	private String type;

	public String getIncomingDescription() {
		return incomingDescription;
	}

	public void setIncomingDescription(String incomingDescription) {
		this.incomingDescription = incomingDescription;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GcvProductTranslationBO [incomingDescription=");
		builder.append(incomingDescription);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append(", product=");
		builder.append(product);
		builder.append(", type=");
		builder.append(type);
		builder.append("]");
		return builder.toString();
	}

}
