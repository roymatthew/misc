package com.ode.cv.data.translator;

import com.ode.cv.normalizer.util.NormalizerUtil;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.service.GcvProductGroupingRepoServiceImpl;
import com.ode.persistence.service.GcvProductTranslationRepoServiceImpl;
import com.ode.persistence.vo.GcvProductGroupingVO;
import com.ode.persistence.vo.GcvProductTranslationVO;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * @author rmathew
 *
 */
@Component
public class GcvToStarProductTranslator {
	private static final Logger logger = LogManager.getLogger(GcvToStarProductTranslator.class);
	@Value("${capIndicators}")
	private String capIndicators;
	@Value("${upfIndicators}")
	private String upfIndicators;
	@Value("${monthlyIndicators}")
	private String monthlyIndicators;
	private Map<String, String> capIndicatorMap;
	private List<String> monthlyIndicatorList;
	private DecimalFormat df = new DecimalFormat("0.00");

	@Autowired
	GcvProductGroupingRepoServiceImpl gcvProductGroupingRepoServiceImpl;

	@Autowired
	GcvProductTranslationRepoServiceImpl gcvProductTranslationRepoServiceImpl;

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;

	/**
	 * @param creditContractVO
	 * @param requestXml
	 * @param lenderRequestXml
	 * @param dealerId
	 * @param financeType
	 * @return
	 * @throws Exception
	 */
	public String translateGcvToStarProducts(final CreditContractVO creditContractVO, final String requestXml,
			String lenderRequestXml) throws Exception {
		logger.debug(
				"Entered translateGcvToStarProducts() method of GcvToStarProductTranslator class. DealerId: {}, FinanceType: {}",
				creditContractVO.getDealerInfo().getDealerId(), creditContractVO.getFinanceType());
		Document requestXmlDoc = cvRequestXmlParser.getDocument(requestXml);
		Map<String, String> nvps = getNvpValues(requestXmlDoc);
		List<Product> products = groupNvpsIntoProducts(nvps, creditContractVO.getFinanceType());
		List<GcvProductTranslationVO> productTranslations = gcvProductTranslationRepoServiceImpl
				.getUniqueTranslationsByDealerId(creditContractVO.getDealerInfo().getDealerId());
		Map<String, GcvProductTranslationVO> mapOfDealerProductTranslations = createMapFromListOfTranslations(
				productTranslations);
		//logger.debug("uniqueTranslations:{}", productTranslations.toString());
		// Map<String, Product> mapOfDealerProducts = null;
		List<Product> listOfOptionProducts = createProductsFromOptions(requestXmlDoc, mapOfDealerProductTranslations,
				creditContractVO.getDealerInfo().getDealerId(), creditContractVO.getContractExecutionState(),
				creditContractVO.getFinanceType());
		products.addAll(listOfOptionProducts);
		products = removeNonZeroProducts(products);
		products = translateProducts(products, productTranslations);
		if (Constants.STAR_FINANCE_TYPE_LEASE.equalsIgnoreCase(creditContractVO.getFinanceType())) {
			// roll up monthly taxes
			Document document = getDocument(lenderRequestXml);
			String productType = document.getElementsByTagName("ProductType").item(0).getTextContent();
			String termString = document.getElementsByTagName("ContractTerm").item(0).getTextContent();
			BigDecimal term = null;
			try {
				term = new BigDecimal(termString);
			} catch (NumberFormatException e) {
				logger.error("could not convert term to a number:" + termString, e);
			}
			products = rollupMonthlyTaxes(products, productType, term);
		}
		products = translateProductsCapInd(products);
		String translatedLenderRequestXml = insertProducts(creditContractVO, lenderRequestXml, products);

		return translatedLenderRequestXml;
	}

	/**
	 * @param requestXmlDoc
	 * @param mapOfTranslations
	 * @return
	 * @throws XPathExpressionException
	 */
	private List<Product> createProductsFromOptions(final Document requestXmlDoc,
			final Map<String, GcvProductTranslationVO> mapOfTranslations, String dealerId, String state,
			String financeType) throws XPathExpressionException {
		logger.debug("Entered createProductsFromOptions() method of GcvToStarProductTranslator class.");
		Map<String, Product> mapOfProducts = new HashMap<>();
		List<Product> listOfProducts = new ArrayList();
		// get dmsData Options
		NodeList optionsNodeList = NormalizerUtil.getNodeListFromXML(requestXmlDoc,
				"/payload/content/GenericCreditContract/contractInfo/dmsData/Option");
		int countOfOptions = 0;
		if (null != optionsNodeList) {
			countOfOptions = optionsNodeList.getLength();
		}
		logger.debug("countOfOptions: {}", countOfOptions);
		String incomingDescription = null;
		String optionDisclosure = null;
		String optionFlag = null;
		Double amount = 0.00;
		Double msrp = 0.00;
		Double cost = 0.00;
		if (countOfOptions > 0) {
			for (int i = 0; i < countOfOptions; i++) {
				incomingDescription = "";
				optionDisclosure = "";
				optionFlag = "";
				amount = 0.00;
				msrp = 0.00;
				Node optionNode = optionsNodeList.item(i);
				if (optionNode instanceof Element) {
					Product product = new Product();
					product.setIndicator("1");
					NodeList childNodes = optionNode.getChildNodes();
					int countOfChildNodes = childNodes.getLength();
					for (int j = 0; j < countOfChildNodes; j++) {
						Node childNode = childNodes.item(j);
						if (null != childNode) {

							String nodeName = childNode.getNodeName();
							String textContent = childNode.getTextContent();

							if ("OptionName".equalsIgnoreCase(nodeName)) {
								product.setDescription(textContent);
								incomingDescription = textContent;
							} else if ("OptionDisclosure".equals(nodeName) && textContent.length() > 0) {
								logger.debug("Entering OptionDisclosure block (populated Disclosure)");
								optionDisclosure = textContent;
							} else if ("OptionDisclosure".equals(nodeName) && textContent.length() < 1) {
								logger.debug("Entering OptionDisclosure block (Blank Disclosure)");
								product.setType("Other");
								optionDisclosure = "";
							} else if ("OptionPrice".equals(nodeName)) {
								product.setAmount(textContent);
								amount = Double.parseDouble(textContent);
							} else if ("OptionCost".equals(nodeName)) {
								cost = Double.parseDouble(textContent);
							} else if ("OptionFlag".equals(nodeName)) {
								optionFlag = textContent;
							} else if ("OptionMSRP".equals(textContent)) {
								msrp = Double.parseDouble(textContent);
							}

						}
					}
					
					logger.debug("optionDisclosure: {}, OptionFlag: {}, amount: {}", optionDisclosure, optionFlag, amount);

					List<GcvProductTranslationVO> optionTranslationSet = null;
					GcvProductTranslationVO optionTranslations = null;
					if ("H".equalsIgnoreCase(optionFlag) && "L".equalsIgnoreCase(financeType) && msrp > 0) {
						logger.debug("Option has financetype of L and flag of H, It will not be translated:{}",
								product);						
					} else {
						try {
							optionTranslationSet = gcvProductTranslationRepoServiceImpl.getGcvTranslations(dealerId,
									state, financeType, incomingDescription);
							if (optionTranslationSet.size() > 0) {
								optionTranslations = optionTranslationSet.get(0);
								logger.debug("all the option translations(optionName):{}", optionTranslations);
							} else {
								if (StringUtils.isNotBlank(optionDisclosure)) {
									logger.debug("option Disclosure not blank:{}", optionDisclosure);
									optionTranslationSet = gcvProductTranslationRepoServiceImpl
											.findGcvTranslationsOptionDisclosure(dealerId,
													state, financeType, optionDisclosure);
									if (optionTranslationSet.size() > 0) {
										optionTranslations = optionTranslationSet.get(0);
										logger.debug("all the option translations(optionDisclosure):{}",
												optionTranslations);
									} else {
										logger.debug(
												"Default product and type set because optionDisclosure translation was not found");
										optionTranslations = new GcvProductTranslationVO();
										optionTranslations.setProduct("DealerProducts");
										optionTranslations.setType("Other");
										product.setType("Other");
										product.setDefault_type("Other");

									}
								} else {
									logger.debug("Default product and type set");
									optionTranslations = new GcvProductTranslationVO();
									optionTranslations.setProduct("DealerProducts");
									optionTranslations.setType("Other");
									product.setType("Other");
									product.setDefault_type("Other");
								}

							}

						} catch (Exception e) {
							logger.error("error retrieving option translations from db", e);

						}
						if (null != optionTranslations) {
							product.setProductType(optionTranslations.getProduct());
							product.setType(optionTranslations.getType());
							product.setPaidTo(optionTranslations.getPaidTo());
							
							if ("H".equalsIgnoreCase(optionFlag) && "R".equalsIgnoreCase(financeType)
									&& (Constants.GCV_OPTION_DISCLOSURE_OTHER.equals(optionDisclosure) || StringUtils.isBlank(optionDisclosure))) {
								logger.debug("Option has financetype of R and flag of H");								
								product.setProductType(Constants.GCV_CASH_PRICE_INCLUSION_TAG_NAME);
								product.setType(Constants.GCV_CASH_PRICE_INCLUSION_TYPE_TOTAL);
								product.setDefault_type(Constants.GCV_CASH_PRICE_INCLUSION_TYPE_TOTAL);
							}

							listOfProducts.add(product);

							logger.debug("Added product: {} to ListOfProducts for Options", product);
						}

					}
				}
				logger.debug("Incoming Description: {}, Option Disclosure: {}", incomingDescription, optionDisclosure);
			}
		}
		return listOfProducts;
	}

	/**
	 * @param productTranslations
	 * @return
	 */
	private Map<String, GcvProductTranslationVO> createMapFromListOfTranslations(
			List<GcvProductTranslationVO> productTranslations) {
		logger.debug("Entered createMapFromListOfTranslations() method of GcvToStarProductTranslator class.");
		Map<String, GcvProductTranslationVO> map = new HashMap<>();
		String key = "";
		for (GcvProductTranslationVO translation : productTranslations) {
			if ("DealerProducts".equals(translation.getProduct())) {
				key = translation.getIncomingDescription() + Constants.PIPE + translation.getProduct() + Constants.PIPE
						+ translation.getType();
				map.put(key, translation);
				logger.debug("Added translation to DealerProducts translation map. Key: {}", key);
			}

		}
		return map;
	}

	/**
	 * @param requestXml
	 * @return
	 */
	private Map<String, String> getNvpValues(final Document requestXmlDoc) {
		logger.debug("Entered getNvpValues() method of GcvToStarProductTranslator class.");
		Map<String, String> nvps = new HashMap<String, String>();
		try {

			// get adpCreditData nvp values
			NodeList adpCreditData = NormalizerUtil.getNodeListFromXML(requestXmlDoc,
					"/payload/content/GenericCreditContract/contractInfo/adpCreditData/nvp");
			Map<String, String> adpCreditDataNvps = extractNvpsIntoMap(adpCreditData);
			nvps.putAll(adpCreditDataNvps);

			// get dmsData nvp values
			NodeList dmsData = NormalizerUtil.getNodeListFromXML(requestXmlDoc,
					"/payload/content/GenericCreditContract/contractInfo/dmsData/nvp");
			Map<String, String> dmsDataNvps = extractNvpsIntoMap(dmsData);
			nvps.putAll(dmsDataNvps);

		} catch (Exception e) {
			logger.error("error", e);
		}
		return nvps;
	}

	/**
	 * @param nvps
	 * @param financeType
	 * @return
	 */
	private List<Product> groupNvpsIntoProducts(final Map<String, String> nvps, final String financeType) {
		logger.debug("Entered groupNvpsIntoProducts() method of GcvToStarProductTranslator class.");
		List<Product> products = new ArrayList<Product>();
		List<GcvProductGroupingVO> productGroupingsList = gcvProductGroupingRepoServiceImpl
				.getByFinanceType(financeType);
		for (GcvProductGroupingVO grouping : productGroupingsList) {
			if (nvps.containsKey(grouping.getAmount())) {
				Product product = new Product();
				product.setAmount(nvps.get(grouping.getAmount()));
				product.setDescription(nvps.get(grouping.getDescription()));
				if (null != grouping.getIndicator()) {
					if (grouping.getIndicator().equals("1")) {
						product.setIndicator("1");
					} else if (grouping.getIndicator().equals("0")) {
						product.setIndicator("0");
					} else {
						String indicator = nvps.get(grouping.getIndicator());
						product.setIndicator(indicator);
					}

				}
				product.setRate(nvps.get(grouping.getRate()));
				product.setLimit(nvps.get(grouping.getLimit()));
				product.setTerm(nvps.get(grouping.getTerm()));
				product.setDefault_product(grouping.getDefaultProduct());
				product.setDefault_type(grouping.getDefaultType());
				products.add(product);
				logger.debug(product);
			}
		}
		return products;
	}

	/**
	 * @param products
	 * @return
	 */
	private List<Product> removeNonZeroProducts(final List<Product> products) {
		logger.debug("Entered removeNonZeroProducts() method of GcvToStarProductTranslator class.");
		List<Product> positiveProducts = new ArrayList<Product>();
		if (null != products && !products.isEmpty()) {
			for (Product product : products) {
				String amountString = product.getAmount();
				BigDecimal amount = BigDecimal.ZERO;
				try {
					amount = new BigDecimal(amountString);
				} catch (Exception e) {
				}
				;
				if (amount.compareTo(BigDecimal.ZERO) <= 0) { // is amount <= zero?
					logger.debug("product amount is not greater than zero. Product will not be translated {}", product);
				} else {
					positiveProducts.add(product);
				}
			}
		}
		return positiveProducts;
	}

	/**
	 * @param products
	 * @param productTranslations
	 * @return
	 */
	private List<Product> translateProducts(final List<Product> products,
			final List<GcvProductTranslationVO> productTranslations) {
		logger.debug("Entered translateProducts() method of GcvToStarProductTranslator class.");
		if (null != productTranslations && !productTranslations.isEmpty() && null != products && !products.isEmpty()) {
			for (Product product : products) {
				
				if (Constants.GCV_CASH_PRICE_INCLUSION_TAG_NAME.equals(product.getProductType()))
				{
					logger.debug("Skipping translation for product: {}, having amount: {}", product.getProductType(), product.getAmount());
					continue;
				}
				boolean translationExists = false;

				for (GcvProductTranslationVO translation : productTranslations) {
					if (null != translation.getIncomingDescription() && null != translation.getProduct()
							&& null != translation.getType()) {
						if (null != product.getDescription()
								&& product.getDescription().equalsIgnoreCase(translation.getIncomingDescription())) {
							product.setProductType(translation.getProduct());
							product.setType(translation.getType());
							product.setPaidTo(translation.getPaidTo());
							translationExists = true;
							break;
						}
					}
				}

				if (!translationExists && null != product.getDefaultProduct() && null != product.getDefault_type()) {
					logger.warn("no translation match found, applying default translation on product:{}", product);
					product.setProductType(product.getDefaultProduct());
					product.setType(product.getDefault_type());
				} else if (!translationExists) {
					logger.error("No translation or default exists for product:{}", product);
				}
			}
		}
		return products;
	}

	/**
	 * @param xml
	 * @return
	 */
	private Document getDocument(final String xml) {
		logger.debug("Entered getDocument() method of GcvToStarProductTranslator class.");
		Document document = null;
		try {
			DocumentBuilder docBuilder;
			docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(xml));
			document = docBuilder.parse(is);
		} catch (ParserConfigurationException e) {
			logger.error("could not create doucment builder", e);
		} catch (SAXException e) {
			logger.error("could not parse ECOUT", e);
		} catch (IOException e) {
			logger.error("could not parse ECOUT", e);
		}
		return document;
	}

	public List<Product> rollupMonthlyTaxes(final List<Product> productsBeforeRollup, final String productType,
			final BigDecimal term) {
		logger.debug(
				"Entered rollupMonthlyTaxes() method of GcvToStarProductTranslator class. productType: {}, term: {}",
				productType, term);
		BigDecimal totalMonthlyUseTax = BigDecimal.ZERO;
		BigDecimal totalMonthlyUseTaxRate = BigDecimal.ZERO;

		List<Product> products = new ArrayList<Product>();
		if (null != productsBeforeRollup && !productsBeforeRollup.isEmpty()) {
			for (Product product : productsBeforeRollup) {
				if (null != product.getProductType() && product.getProductType().equals(Constants.STAR_TAG_TAX)
						&& null != product.getIndicator() && isMonthlyCapInd(product.getIndicator())) {
					logger.debug("rolling up monthly tax:{}", product);
					String amountString = product.getAmount();
					BigDecimal amount = BigDecimal.ZERO;
					try {
						amount = new BigDecimal(amountString);
					} catch (NumberFormatException e) {
						logger.warn("could not parse amount:" + amountString + " from product:" + product, e);
					}
					totalMonthlyUseTax = totalMonthlyUseTax.add(amount);
					String taxRateString = product.getRate();
					BigDecimal taxRate = BigDecimal.ZERO;
					try {
						taxRate = new BigDecimal(taxRateString);
					} catch (NumberFormatException e) {
						logger.warn("could not parse rate:" + taxRateString + " from product:" + product, e);
					}
					totalMonthlyUseTaxRate = totalMonthlyUseTaxRate.add(taxRate);
				} else {
					products.add(product);
				}
			}
		}

		// generate Monthly Tax
		Product product = new Product();
		product.setProductType(Constants.STAR_TAG_TAX);
		product.setType(Constants.STAR_TAX_TYPE_MONTHLY_USE);
		product.setDescription("Monthly Tax");
		product.setIndicator(Constants.STAR_CAP_IND_CAP);
		product.setAmount(totalMonthlyUseTax.toString());
		product.setRate(totalMonthlyUseTaxRate.toString());
		products.add(product);

		// generate Total Monthly Tax
		product = new Product();
		product.setProductType(Constants.STAR_TAG_TAX);
		product.setType(Constants.STAR_TAX_TYPE_TOTAL_MONTHLY_USE);
		product.setDescription("Total Monthly Tax");
		product.setIndicator(Constants.STAR_CAP_IND_CAP);
		product.setRate(totalMonthlyUseTaxRate.toString());
		if (null != productType && productType.equals(Constants.STAR_PRODUCT_TYPE_ONE_PAY) && null != term) {
			product.setAmount(totalMonthlyUseTax.multiply(term).setScale(2, RoundingMode.HALF_UP).toString());
		} else {
			product.setAmount(totalMonthlyUseTax.toString());
		}
		products.add(product);

		return products;
	}

	private List<Product> translateProductsCapInd(final List<Product> products) {
		logger.debug("Entered translateProductsCapInd()");
		if (null != products) {
			for (Product product : products) {
				String capInd = translateCapInd(product.getIndicator());
				product.setIndicator(capInd);
			}
		}
		return products;
	}

	/**
	 * @param creditContractVO
	 * @param lenderRequestXml
	 * @param products
	 * @param mapOfDealerProducts
	 * @return
	 */
	private String insertProducts(final CreditContractVO creditContractVO, final String lenderRequestXml,
			final List<Product> products) {
		logger.debug("Entered insertProducts() method of GcvToStarProductTranslator class.");
		logger.debug("Size of products starting insertProducts: {}", products.size());
		String translatedLenderRequestXml = "";
		NodeList dealerProductsNodes = null;
		try {
			DocumentBuilder docBuilder;
			InputSource inputSource = new InputSource(new StringReader(lenderRequestXml));
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			docBuilder = factory.newDocumentBuilder();
			Document lenderRequestXmlDoc = docBuilder.parse(inputSource);
			NodeList pccNodes = lenderRequestXmlDoc.getElementsByTagName("ProcessCreditContract");
			String namespace = "";
			if (pccNodes.getLength() > 0) {
				Node pcc = pccNodes.item(0);
				namespace = pcc.getNamespaceURI();
			} else {
				logger.warn("could not find ProcessCreditContract node, namespace for new elements will not be set.");
			}

			// find product placeholders
			NodeList taxNodes = lenderRequestXmlDoc.getElementsByTagName("Tax");
			Node taxPlaceholder = null;
			if (null != taxNodes && taxNodes.getLength() > 0) {
				taxPlaceholder = taxNodes.item(taxNodes.getLength() - 1);
			} else {
				logger.warn("no placeholder tax was found - no taxes will be added.");
			}
			NodeList feeNodes = lenderRequestXmlDoc.getElementsByTagName("Fee");
			Node feePlaceholder = null;
			if (null != feeNodes && feeNodes.getLength() > 0) {
				feePlaceholder = feeNodes.item(feeNodes.getLength() - 1);
			} else {
				logger.warn("no placeholder fee was found - no fees will be added.");
			}
			dealerProductsNodes = lenderRequestXmlDoc.getElementsByTagName("DealerProducts");
			Node dealerProductsPlaceholder = null;
			if (null != dealerProductsNodes && dealerProductsNodes.getLength() > 0) {
				dealerProductsPlaceholder = dealerProductsNodes.item(dealerProductsNodes.getLength() - 1);
			} else {
				logger.warn("no placeholder dealer product was found - no dealer products will be added.");
			}
			NodeList insuranceNodes = lenderRequestXmlDoc.getElementsByTagName("Insurance");
			Node insurancePlaceholder = null;
			if (null != insuranceNodes && insuranceNodes.getLength() > 0) {
				insurancePlaceholder = insuranceNodes.item(insuranceNodes.getLength() - 1);
			} else {
				logger.warn("no placeholder insurance was found - no insurances will be added.");
			}
			NodeList serviceContractNodes = lenderRequestXmlDoc.getElementsByTagName("ServiceContract");
			Node serviceContractPlaceholder = null;
			if (null != serviceContractNodes && serviceContractNodes.getLength() > 0) {
				serviceContractPlaceholder = serviceContractNodes.item(serviceContractNodes.getLength() - 1);
			} else {
				logger.warn("no placeholder service contract was found - no service contracts will be added.");
			}

			NodeList otherChargesNodes = lenderRequestXmlDoc.getElementsByTagName("OtherCharges");
			Node otherChargesPlaceholder = null;
			if (null != otherChargesNodes && otherChargesNodes.getLength() > 0) {
				otherChargesPlaceholder = otherChargesNodes.item(otherChargesNodes.getLength() - 1);
			} else {
				logger.warn("no placeholder other charges was found - no other charges will be added.");
			}

			for (Product product : products) {
				logger.debug("Product: {}", product);
				if (null == product.getProductType()) {
					logger.error("no translation found for product:{}", product);
				} else if (product.getProductType().equals(Constants.STAR_TAG_TAX)) {
					if (null != taxPlaceholder) {
						Node tax = createTaxNode(lenderRequestXmlDoc, namespace, product);
						taxPlaceholder.getParentNode().insertBefore(tax, taxPlaceholder);
					}
				} else if (product.getProductType().equals(Constants.STAR_TAG_FEE)) {
					if (null != feePlaceholder) {
						Node fee = createFeeNode(creditContractVO, lenderRequestXmlDoc, namespace, product);
						feePlaceholder.getParentNode().insertBefore(fee, feePlaceholder);
					}
				} else if (product.getProductType().equals(Constants.STAR_TAG_INSURANCE)) {
					if (null != insurancePlaceholder) {
						Node insurance = createInsuranceNode(lenderRequestXmlDoc, namespace, product);
						insurancePlaceholder.getParentNode().insertBefore(insurance, insurancePlaceholder);
					}
				} else if (product.getProductType().equals(Constants.STAR_TAG_SERVICE_CONTRACT)) {
					if (null != serviceContractPlaceholder) {
						Node serviceContract = createServiceContractNode(lenderRequestXmlDoc, namespace, product);
						serviceContractPlaceholder.getParentNode().insertBefore(serviceContract,
								serviceContractPlaceholder);
					}
				} else if (product.getProductType().equals(Constants.STAR_TAG_DEALER_PRODUCTS)) {
					if (null != dealerProductsPlaceholder) {
						Node dealerProducts = createDealerProductsNode(lenderRequestXmlDoc, namespace, product);
						dealerProductsPlaceholder.getParentNode().insertBefore(dealerProducts,
								dealerProductsPlaceholder);
					}
				} else if (product.getProductType().equals(Constants.STAR_TAG_OTHER_CHARGES)) {
					if (null != otherChargesPlaceholder) {
						Node otherCharges = createOtherChargesNode(lenderRequestXmlDoc, namespace, product);
						otherChargesPlaceholder.getParentNode().insertBefore(otherCharges, otherChargesPlaceholder);
					}
				} else {
					logger.error(
							"product will not be inserted because of an invalid product:{}. Should be Tax, Fee, DealerProducts, ServiceContract or Insurance.",
							product.getProductType());
				}
			}
			
			/* CashPriceInclusion processing */
			Node cashPriceInclusionPlaceholder = null;
			NodeList dealerRecourseNodeList = lenderRequestXmlDoc.getElementsByTagName("DealerRecourse");
			if (null != dealerRecourseNodeList) {
				cashPriceInclusionPlaceholder = dealerRecourseNodeList.item(0);
			}
			logger.debug("Start processing CashPriceInclusion elements");
			for (Product product : products) {
				if (null == product.getProductType()) {
					continue;
				}
				if (product.getProductType().equals(Constants.GCV_CASH_PRICE_INCLUSION_TAG_NAME)) {
					logger.debug("Processing CashPriceInclusion element");
					Node cashPriceInclusion = createCashPriceInclusionNode(lenderRequestXmlDoc, namespace, product);
					if (null != cashPriceInclusionPlaceholder) {
						cashPriceInclusionPlaceholder.getParentNode().insertBefore(cashPriceInclusion,
								cashPriceInclusionPlaceholder);
					}
					else
					{
						Node financeNode = lenderRequestXmlDoc.getElementsByTagName("Finance").item(0);
						financeNode.appendChild(cashPriceInclusion);
					}
				}
			}

			// if (null != dealerProductsPlaceholder &&
			// dealerProductsNodes.getLength() > 0) {
			// logger.debug("Begin translation for dealer product. No. of dealer
			// products to translate: {}",
			// dealerProductsNodes.getLength());
			// int countOfDealerProductNodes = dealerProductsNodes.getLength();
			// for (int i = 0; i < countOfDealerProductNodes; i++) {
			// Node inDealerProduct = dealerProductsNodes.item(i);
			// if (inDealerProduct instanceof Element) {
			// updateDealerProductPaidTo(namespace, inDealerProduct,
			// mapOfDealerProducts, lenderRequestXmlDoc);
			// }
			// }
			//
			// }

			// remove placeholders
			if (null != taxPlaceholder) {
				logger.debug("removing tax placeholder");
				taxPlaceholder.getParentNode().removeChild(taxPlaceholder);
			}
			if (null != feePlaceholder) {
				feePlaceholder.getParentNode().removeChild(feePlaceholder);
			}
			if (null != dealerProductsPlaceholder) {
				dealerProductsPlaceholder.getParentNode().removeChild(dealerProductsPlaceholder);
			}
			if (null != insurancePlaceholder && insuranceNodes.getLength() > 1) {
				insurancePlaceholder.getParentNode().removeChild(insurancePlaceholder);
			}
			if (null != serviceContractPlaceholder) {
				serviceContractPlaceholder.getParentNode().removeChild(serviceContractPlaceholder);
			}
			if (null != otherChargesPlaceholder) {
				otherChargesPlaceholder.getParentNode().removeChild(otherChargesPlaceholder);
			}

			// convert doc to string
			translatedLenderRequestXml = NormalizerUtil.getStringFromDocument(lenderRequestXmlDoc);
		} catch (final Exception e) {
			logger.error("Exception caught within insertProducts() method of GcvToStarProductTranslator class", e);
		}
		logger.debug("Exit insertProducts() method");
		return translatedLenderRequestXml;
	}

	/**
	 * @param lenderRequestXmlDoc
	 * @param namespace
	 * @param product
	 * @return
	 */
	private Node createOtherChargesNode(Document lenderRequestXmlDoc, String namespace, Product product) {
		logger.debug(
				"Entered createOtherChargesNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);
		Node otherCharges = lenderRequestXmlDoc.createElementNS(namespace, "OtherCharges");

		if (null != product.getDescription()) {
			Node otherChargesPaidFor = lenderRequestXmlDoc.createElementNS(namespace, "OtherChargesPaidFor");
			otherChargesPaidFor.setTextContent(product.getDescription());
			otherCharges.appendChild(otherChargesPaidFor);
		}

		if (StringUtils.isNotBlank(product.getPaidTo())) {
			Node otherChargesPaidTo = lenderRequestXmlDoc.createElementNS(namespace, "OtherChargesPaidTo");
			otherChargesPaidTo.setTextContent(product.getPaidTo());
			otherCharges.appendChild(otherChargesPaidTo);
		}

		if (null != product.getAmount()) {
			Node otherChargesAmount = lenderRequestXmlDoc.createElementNS(namespace, "OtherChargesAmount");
			otherChargesAmount.setTextContent(df.format(new BigDecimal(product.getAmount())));
			((Element) otherChargesAmount).setAttribute("currency", "USD");
			otherCharges.appendChild(otherChargesAmount);
		}

		if (null != product.getIndicator()) {
			Node otherChargesCapitalizedInd = lenderRequestXmlDoc.createElementNS(namespace,
					"OtherChargesCapitalizedInd");
			otherChargesCapitalizedInd.setTextContent(product.getIndicator());
			otherCharges.appendChild(otherChargesCapitalizedInd);
		}

		return otherCharges;
	}

	/**
	 * @param lenderRequestXmlDoc
	 * @param namespace
	 * @param product
	 * @return
	 */
	private Node createTaxNode(final Document lenderRequestXmlDoc, final String namespace, final Product product) {
		logger.debug("Entered createTaxNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);
		Node tax = lenderRequestXmlDoc.createElementNS(namespace, "Tax");

		if (null != product.getType()) {
			Node taxType = lenderRequestXmlDoc.createElementNS(namespace, "TaxType");
			taxType.setTextContent(product.getType());
			tax.appendChild(taxType);
		}

		if (null != product.getDescription()) {
			Node taxDescription = lenderRequestXmlDoc.createElementNS(namespace, "TaxDescription");
			taxDescription.setTextContent(product.getDescription());
			tax.appendChild(taxDescription);
		}

		if (null != product.getAmount()) {
			Node taxAmount = lenderRequestXmlDoc.createElementNS(namespace, "TaxAmount");
			taxAmount.setTextContent(df.format(new BigDecimal(product.getAmount())));
			((Element) taxAmount).setAttribute("currency", "USD");
			tax.appendChild(taxAmount);
		}

		if (null != product.getRate()) {
			Node taxRate = lenderRequestXmlDoc.createElementNS(namespace, "TaxRate");
			taxRate.setTextContent(product.getRate());
			tax.appendChild(taxRate);
		}

		if (null != product.getIndicator()) {
			Node capitalizedTaxInd = lenderRequestXmlDoc.createElementNS(namespace, "CapitalizedTaxInd");
			capitalizedTaxInd.setTextContent(product.getIndicator());
			tax.appendChild(capitalizedTaxInd);
		}

		if (StringUtils.isNotBlank(product.getPaidTo())) {
			Node taxPaidTo = lenderRequestXmlDoc.createElementNS(namespace, "TaxPaidTo");
			taxPaidTo.setTextContent(product.getPaidTo());
			tax.appendChild(taxPaidTo);
		}
		return tax;
	}

	private Node createDealerProductsNode(final Document lenderRequestXmlDoc, final String namespace,
			final Product product) {
		logger.debug(
				"Entered createDealerProductsNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);
		Node dealerProducts = lenderRequestXmlDoc.createElementNS(namespace, "DealerProducts");

		if (null != product.getType()) {
			Node DealerProductsType = lenderRequestXmlDoc.createElementNS(namespace, "DealerProductsType");
			DealerProductsType.setTextContent(product.getType());
			dealerProducts.appendChild(DealerProductsType);
		}

		if (null != product.getAmount()) {
			Node DealerProductsAmount = lenderRequestXmlDoc.createElementNS(namespace, "DealerProductsAmount");
			DealerProductsAmount.setTextContent(df.format(new BigDecimal(product.getAmount())));
			((Element) DealerProductsAmount).setAttribute("currency", "USD");
			dealerProducts.appendChild(DealerProductsAmount);
		}

		if (null != product.getDescription()) {
			Node DealerProductsPaidFor = lenderRequestXmlDoc.createElementNS(namespace, "DealerProductsPaidFor");
			DealerProductsPaidFor.setTextContent(product.getDescription());
			dealerProducts.appendChild(DealerProductsPaidFor);

			Node DealerProductsPaidTo = lenderRequestXmlDoc.createElementNS(namespace, "DealerProductsPaidTo");
			if (StringUtils.isBlank(product.getPaidTo())) {
				product.setPaidTo("Not Provided");
			}
			DealerProductsPaidTo.setTextContent(product.getPaidTo());
			dealerProducts.appendChild(DealerProductsPaidTo);
		}

		if (null != product.getIndicator()) {
			Node DealerProductsCapitalizedInd = lenderRequestXmlDoc.createElementNS(namespace,
					"DealerProductsCapitalizedInd");
			DealerProductsCapitalizedInd.setTextContent(product.getIndicator());
			dealerProducts.appendChild(DealerProductsCapitalizedInd);
		}

		return dealerProducts;
	}
	
	/**
	 * @param lenderRequestXmlDoc
	 * @param namespace
	 * @param product
	 * @return
	 */
	private Node createCashPriceInclusionNode(final Document lenderRequestXmlDoc, final String namespace,
			final Product product) {
		logger.debug(
				"Entered createCashPriceInclusionNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);
		Node cashPriceInclusion = lenderRequestXmlDoc.createElementNS(namespace, Constants.GCV_CASH_PRICE_INCLUSION_TAG_NAME);

		if (null != product.getType()) {
			Node type = lenderRequestXmlDoc.createElementNS(namespace, "CashPriceInclusionType");
			type.setTextContent(product.getType());
			cashPriceInclusion.appendChild(type);
		}

		if (null != product.getAmount()) {
			Node amount = lenderRequestXmlDoc.createElementNS(namespace, "CashPriceInclusionAmount");
			amount.setTextContent(df.format(new BigDecimal(product.getAmount())));
			((Element) amount).setAttribute("currency", "USD");
			cashPriceInclusion.appendChild(amount);
		}

		if (null != product.getDescription()) {
			Node description = lenderRequestXmlDoc.createElementNS(namespace, "CashPriceInclusionDesc");
			description.setTextContent(product.getDescription());
			cashPriceInclusion.appendChild(description);
		}

		return cashPriceInclusion;
	}

	/**
	 * @param creditContractVO
	 * @param lenderRequestXmlDoc
	 * @param namespace
	 * @param product
	 * @return
	 */
	private Node createFeeNode(final CreditContractVO creditContractVO, final Document lenderRequestXmlDoc,
			final String namespace, final Product product) {
		logger.debug("Entered createFeeNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);

		Node fee = null;

		try {
			fee = lenderRequestXmlDoc.createElementNS(namespace, "Fee");

			if (null != product.getType()) {
				Node feeType = lenderRequestXmlDoc.createElementNS(namespace, "FeeType");
				feeType.setTextContent(product.getType());
				fee.appendChild(feeType);
			}

			if (null != product.getDescription()) {
				Node feeDescription = lenderRequestXmlDoc.createElementNS(namespace, "FeeDescription");
				feeDescription.setTextContent(product.getDescription());
				fee.appendChild(feeDescription);
			}

			if (null != product.getAmount()) {
				Node feeAmount = lenderRequestXmlDoc.createElementNS(namespace, "FeeAmount");

				if (null != feeAmount) {
					feeAmount.setTextContent(df.format(new BigDecimal(product.getAmount())));
					Element feeAmountElement = (Element) feeAmount;
					feeAmountElement.setAttribute("currency", "USD");
				}

				fee.appendChild(feeAmount);
			}

			if (product.getType().equalsIgnoreCase("DocumentationFee")
					&& creditContractVO.getFinanceType().equalsIgnoreCase(Constants.STAR_FINANCE_TYPE_RETAIL)) {
				Node feePaidTo = lenderRequestXmlDoc.createElementNS(namespace, "FeePaidTo");
				feePaidTo.setTextContent(creditContractVO.getDealerInfo().getDealerName());
				fee.appendChild(feePaidTo);
			} else if (StringUtils.isNotBlank(product.getPaidTo())) {
				Node feePaidTo = lenderRequestXmlDoc.createElementNS(namespace, "FeePaidTo");
				feePaidTo.setTextContent(product.getPaidTo());
				fee.appendChild(feePaidTo);
			}

			if (null != product.getIndicator()) {
				Node capitalizedFeeInd = lenderRequestXmlDoc.createElementNS(namespace, "CapitalizedFeeInd");
				capitalizedFeeInd.setTextContent(product.getIndicator());
				fee.appendChild(capitalizedFeeInd);
			}
		} catch (Exception e) {
			logger.error(e);
		}
		return fee;
	}

	/**
	 * @param lenderRequestXmlDoc
	 * @param namespace
	 * @param product
	 * @return
	 */
	private Node createInsuranceNode(Document lenderRequestXmlDoc, String namespace, Product product) {
		logger.debug(
				"Entered createInsuranceNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);
		Node insurance = lenderRequestXmlDoc.createElementNS(namespace, "Insurance");

		if (null != product.getType()) {
			Node insuranceType = lenderRequestXmlDoc.createElementNS(namespace, "InsuranceType");
			insuranceType.setTextContent(product.getType());
			insurance.appendChild(insuranceType);
		}

		Node insuranceCompanyName = lenderRequestXmlDoc.createElementNS(namespace, "InsuranceCompanyName");
		if (StringUtils.isNotBlank(product.getPaidTo())) {
			insuranceCompanyName.setTextContent(product.getPaidTo());
			insurance.appendChild(insuranceCompanyName);
		} else if (null != product.getDescription()) {
			insuranceCompanyName.setTextContent(product.getDescription());
			insurance.appendChild(insuranceCompanyName);
		}

		if (null != product.getTerm()) {
			Node term = lenderRequestXmlDoc.createElementNS(namespace, "Term");
			term.setTextContent(product.getTerm());
			insurance.appendChild(term);
		}

		if (null != product.getAmount()) {
			Node premium = lenderRequestXmlDoc.createElementNS(namespace, "Premium");
			premium.setTextContent(df.format(new BigDecimal(product.getAmount())));
			((Element) premium).setAttribute("currency", "USD");
			insurance.appendChild(premium);
		}

		if (null != product.getIndicator()) {
			Node financedInd = lenderRequestXmlDoc.createElementNS(namespace, "FinancedInd");
			financedInd.setTextContent(product.getIndicator());
			insurance.appendChild(financedInd);
		}
		return insurance;
	}

	/**
	 * @param lenderRequestXmlDoc
	 * @param namespace
	 * @param product
	 * @return
	 */
	private Node createServiceContractNode(Document lenderRequestXmlDoc, String namespace, Product product) {
		logger.debug(
				"Entered createServiceContractNode() method of GcvToStarProductTranslator class. namespace: {}, product: {}",
				namespace, product);
		Node serviceContract = lenderRequestXmlDoc.createElementNS(namespace, "ServiceContract");

		Node contractCompanyName = lenderRequestXmlDoc.createElementNS(namespace, "ContractCompanyName");
		if (StringUtils.isNotBlank(product.getPaidTo())) {
			contractCompanyName.setTextContent(product.getPaidTo());
			serviceContract.appendChild(contractCompanyName);
		} else if (null != product.getDescription()) {
			contractCompanyName.setTextContent(product.getDescription());
			serviceContract.appendChild(contractCompanyName);
		}

		if (null != product.getType()) {
			Node contractType = lenderRequestXmlDoc.createElementNS(namespace, "ContractType");
			contractType.setTextContent(product.getType());
			serviceContract.appendChild(contractType);
		}

		if (null != product.getLimit()) {
			Node contractTermMileage = lenderRequestXmlDoc.createElementNS(namespace, "ContractTermMileage");
			contractTermMileage.setTextContent(product.getLimit());
			((Element) contractTermMileage).setAttribute("uom", "M");
			serviceContract.appendChild(contractTermMileage);
		}

		if (null != product.getTerm()) {
			Node term = lenderRequestXmlDoc.createElementNS(namespace, "Term");
			term.setTextContent(product.getTerm());
			((Element) term).setAttribute("length", "Months");
			serviceContract.appendChild(term);
		}

		if (null != product.getAmount()) {
			Node customerSalePrice = lenderRequestXmlDoc.createElementNS(namespace, "CustomerSalePrice");
			customerSalePrice.setTextContent(df.format(new BigDecimal(product.getAmount())));
			((Element) customerSalePrice).setAttribute("currency", "USD");
			serviceContract.appendChild(customerSalePrice);
		}

		if (null != product.getIndicator()) {
			Node financedInd = lenderRequestXmlDoc.createElementNS(namespace, "FinancedInd");
			financedInd.setTextContent(product.getIndicator());
			serviceContract.appendChild(financedInd);
		}

		if (null != product.getDescription()) {
			Node contractDescription = lenderRequestXmlDoc.createElementNS(namespace, "ServiceContractDescription");
			contractDescription.setTextContent(product.getDescription());
			serviceContract.appendChild(contractDescription);
		}

		return serviceContract;
	}

	/**
	 * @param nvpNodes
	 * @return
	 */
	private Map<String, String> extractNvpsIntoMap(final NodeList nvpNodes) {
		logger.debug("Entered extractNvpsIntoMap() method of GcvToStarProductTranslator class.");
		Map<String, String> nvps = new HashMap<String, String>();
		for (int i = 0; i < nvpNodes.getLength(); i++) {
			String name = "";
			String value = "";
			for (int j = 0; j < nvpNodes.item(i).getChildNodes().getLength(); j++) {
				Node node = nvpNodes.item(i).getChildNodes().item(j);
				if (null != node) {
					String nodeName = node.getNodeName();
					String textContent = node.getTextContent();
					if (nodeName.equalsIgnoreCase("name")) {
						name = textContent;
					}
					if (nodeName.equalsIgnoreCase("value")) {
						value = textContent;
					}
				}
			}
			nvps.put(name, value);
		}
		return nvps;
	}

	private String translateCapInd(final String indicator) {
		logger.debug("Entered translateCapInd() method of GcvToStarProductTranslator class. indicator: {}", indicator);
		if (null == capIndicatorMap) {
			capIndicatorMap = new HashMap<String, String>();
			for (String capInd : Arrays.asList(capIndicators.split(","))) {
				capIndicatorMap.put(capInd, "1");
			}
			for (String upfInd : Arrays.asList(upfIndicators.split(","))) {
				capIndicatorMap.put(upfInd, "0");
			}
		}
		return capIndicatorMap.get(indicator);
	}

	private boolean isMonthlyCapInd(final String indicator) {
		logger.debug("Entered isMonthlyCapInd() method of GcvToStarProductTranslator class. indicator: {}", indicator);
		if (null == monthlyIndicatorList) {
			monthlyIndicatorList = new ArrayList<String>();
			for (String capInd : Arrays.asList(monthlyIndicators.split(","))) {
				monthlyIndicatorList.add(capInd);
			}
		}
		return monthlyIndicatorList.contains(indicator);
	}

	public String getCapIndicators() {
		return capIndicators;
	}

	public void setCapIndicators(String capIndicators) {
		this.capIndicators = capIndicators;
	}

	public String getUpfIndicators() {
		return upfIndicators;
	}

	public void setUpfIndicators(String upfIndicators) {
		this.upfIndicators = upfIndicators;
	}

	public String getMonthlyIndicators() {
		return monthlyIndicators;
	}

	public void setMonthlyIndicators(String monthlyIndicators) {
		this.monthlyIndicators = monthlyIndicators;
	}
}
