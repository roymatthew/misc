package com.ode.cv.data.translator;

public class Product {
	private String productType;
	private String type;
	private String description;
	private String amount;
	private String indicator;
	private String rate;
	private String limit;
	private String term;
	private String defaultProduct;
	private String defaultType;
	private String paidTo;

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getDefaultProduct() {
		return defaultProduct;
	}

	public void setDefault_product(String defaultProduct) {
		this.defaultProduct = defaultProduct;
	}

	public String getDefault_type() {
		return defaultType;
	}

	public void setDefault_type(String defaultType) {
		this.defaultType = defaultType;
	}
	
	public String getPaidTo() {
		return paidTo;
	}

	public void setPaidTo(String paidTo) {
		this.paidTo = paidTo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Product [productType=");
		builder.append(productType);
		builder.append(", type=");
		builder.append(type);
		builder.append(", description=");
		builder.append(description);
		builder.append(", amount=");
		builder.append(amount);
		builder.append(", indicator=");
		builder.append(indicator);
		builder.append(", rate=");
		builder.append(rate);
		builder.append(", limit=");
		builder.append(limit);
		builder.append(", term=");
		builder.append(term);
		builder.append(", defaultProduct=");
		builder.append(defaultProduct);
		builder.append(", defaultType=");
		builder.append(defaultType);
		builder.append(", paidTo=");
		builder.append(paidTo);
		builder.append("]");
		return builder.toString();
	}
}