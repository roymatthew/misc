package com.ode.cv.entity;

import java.math.BigInteger;

public class DigitalDealJacket {
	
	private String messageType;
    private BigInteger key;
    
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public BigInteger getKey() {
		return key;
	}
	public void setKey(BigInteger key) {
		this.key = key;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DigitalDealJacket [messageType=");
		builder.append(messageType);
		builder.append(", key=");
		builder.append(key);
		builder.append("]");
		return builder.toString();
	}
    
}
