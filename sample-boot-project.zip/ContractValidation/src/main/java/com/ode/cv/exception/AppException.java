/*
 * Created on Mar 31, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.exception;

/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/**
 * This class implements an exception which can wrapped a lower-level exception.
 *  
 */
public class AppException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected Throwable cause;
	protected String Context;
	protected String Pgm;
	protected String traceMsg ="N/A"; // default value
	public AppException() {
		super("Error occurred in application.");
	}

	public AppException(String message,String context,String pgm) {
		super(message);
		Context = context;
		Pgm = pgm;
	}

	public AppException (Throwable t,String context,String pgm){
		super(t.getMessage());
		this.cause=t;
		Context = context;
		Pgm = pgm;
	}
	public AppException(String message, Throwable t,String context,String pgm) {
		super(message);
		this.cause = t;
		Context = context;
		Pgm = pgm;
	}
	
	public AppException(String message, Throwable t,String context,String pgm,String trace) {
		super(message);
		this.cause = t;
		Context = context;
		Pgm = pgm;
		traceMsg = trace;
	}
	
	public Throwable initCause(Throwable t,String context,String pgm) {
		this.cause = t;
		Context = context;
		Pgm = pgm;
		return cause;
	}
	public String toString() {
		return super.getMessage();
	}
	public Throwable getCause() {
		return cause;
	}
	public String getContext(){
		return Context;
	}
	
	public String getPgm(){
		return Pgm;
	}

	public String getTraceMsg(){
		return traceMsg;
	}
}
