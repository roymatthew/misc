/**
 * 
 */
package com.ode.cv.exception;

/**
 * @author rmathew
 *
 */
public class CVFromDocumentException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6688485697759441090L;

	public CVFromDocumentException() {
	}

	/**
	 * @param message
	 */
	public CVFromDocumentException(final String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public CVFromDocumentException(final Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CVFromDocumentException(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public CVFromDocumentException(final String message, final Throwable cause, final boolean enableSuppression, final boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
