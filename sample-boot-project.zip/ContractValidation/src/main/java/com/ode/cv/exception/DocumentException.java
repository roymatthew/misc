/**
 * 
 */
package com.ode.cv.exception;

/**
 * @author rmathew
 *
 */
public class DocumentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6277586602730081890L;
	
	public DocumentException() {
	}

	/**
	 * @param message
	 */
	public DocumentException(final String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public DocumentException(final Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DocumentException(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public DocumentException(final String message, final Throwable cause, final boolean enableSuppression, final boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
