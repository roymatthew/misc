package com.ode.cv.exception;

/**
 * @author rmathew
 *
 */
public class InvalidDmsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1846758352042540119L;

	/**
	 * Default Constructor
	 */
	public InvalidDmsException() {
	}

	/**
	 * @param arg0
	 */
	public InvalidDmsException(final String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public InvalidDmsException(final Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public InvalidDmsException(final String arg0, final Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 */
	public InvalidDmsException(final String arg0, final Throwable arg1, final boolean arg2, final boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

}
