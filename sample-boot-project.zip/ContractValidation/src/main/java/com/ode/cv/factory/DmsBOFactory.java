package com.ode.cv.factory;

import com.ode.cv.bo.*;
import com.ode.cv.exception.InvalidDmsException;
import com.ode.persistence.service.DeDmsRepoService;
import com.ode.persistence.vo.DeDmsVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DmsBOFactory {

    @Autowired
    public DeDmsRepoService deDmsRepoService;

    private static final Logger logger = LogManager.getLogger(DmsBOFactory.class);

    /**
     * Returns an instance of DMSBO that corresponds to the given dmsId.
     *
     * @param dmsId String
     * @return dms DmsBO
     */
    public IDmsBO createDMS(final String dmsId) throws Exception {
        logger.debug("Enter createDMS method of DmsBOFactory class. dmsId: {}", dmsId);
        DeDmsVO deDmsVO = deDmsRepoService.findById(dmsId);

        if (null == deDmsVO) {
            throw new InvalidDmsException("Could not create a DMS with dmsId: " + dmsId);
        }

        IDmsBO dms = null;
        switch (deDmsVO.getDmsId()) {
            case "AD":
                dms = new CdkDmsBOImpl(deDmsVO);
                break;
            case "AR":
            	dms = new AdventDmsBOImpl(deDmsVO);
            	break;
            case "RR":
                dms = new ReynoldsDmsBOImpl(deDmsVO);
                break;
            default:
                dms = new GenericDmsBOImpl(deDmsVO);
                break;
        }

        logger.debug("Created a DMS with dmsID: " + dms.getDmsId());
        return dms;
    }
}
