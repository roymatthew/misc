/**
 * 
 */
package com.ode.cv.factory;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.cv.util.Constants;
import com.ode.cv.util.MessageProcessingUtil;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.cv.vo.AccrVO;
import com.ode.dlr.util.AppMessage;
import com.ode.dlr.util.EncryptionException;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.vo.AuditJournalVO;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public class JournalFactory {

	private static final Logger logger = LogManager.getLogger(JournalFactory.class);

	private JournalFactory() {
		super();
	}

	public static JournalObjectVO createJournalObject(final String transType, final AppMessage appMessage,
			final String xmlString) {
		JournalObjectVO journalObject = new JournalObjectVO();
		journalObject.setTransType(transType);
		journalObject.setTimestamp((new java.sql.Timestamp(new Date().getTime())));
		journalObject.setXmlData(xmlString);
		journalObject.setAppMsg(appMessage);
		return journalObject;
	}

	/**
	 * @param journalObject
	 * @param contractValidation
	 * @return
	 * @throws EncryptionException
	 */
	public static CreditJournalVO createCreditJournal(final JournalObjectVO journalObject,
			final CreditContractVO creditContractVO) throws EncryptionException {

		logger.debug(
				"Enter createCreditJournal() method of JournalFactory. Transtype: " + journalObject.getTransType());

		CreditJournalVO creditJournalVO = new CreditJournalVO();
		String crDataXml = journalObject.getXmlData();
		String keyId = "";
		List<String> encryptedItems = EncryptionUtils.encryptText(crDataXml);
		keyId = encryptedItems.get(0);
		String encryptedXML = encryptedItems.get(1);
		String auditData = journalObject.getAppMessage().getMessageID() + " - "
				+ journalObject.getAppMessage().getMessage();
		if (auditData.length() > 200) {
			auditData = auditData.substring(0, 199);
		}

		String transType = journalObject.getTransType();
		String transactionId = creditContractVO.getRoKey() != null ? creditContractVO.getRoKey()
				: creditContractVO.getDocumentId() == null ? "" : creditContractVO.getDocumentId();
		String userId = creditContractVO.getUserId() != null ? creditContractVO.getUserId() : "";
		String deliverySource = creditContractVO.getDeliverySource() == null ? ""
				: creditContractVO.getDeliverySource();
		String applicationSource = creditContractVO.getApplicationSource().length() > 2
				? creditContractVO.getApplicationSource().substring(0, 2)
				: creditContractVO.getApplicationSource();
		String financeType = creditContractVO.getFinanceType() == null ? "" : creditContractVO.getFinanceType();
		String appDealNumber = creditContractVO.getAdpDealNo() == null ? "" : creditContractVO.getAdpDealNo();
		String dmsId = creditContractVO.getDealerInfo().getDspId() == null ? ""
				: creditContractVO.getDealerInfo().getDspId();

		if (creditContractVO.getTransType() != null) {
			if (creditContractVO.getTransType().equals(Constants.TRANS_TYPE_ID_IN)
					&& transType.equals(Constants.TRANS_TYPE_APP_OUT)) {
				transType = Constants.TRANS_TYPE_ID_OUT;
			}
			if (creditContractVO.getTransType().equals(Constants.TRANS_TYPE_ID_IN)
					&& transType.equals(Constants.TRANS_TYPE_APP_CONF_IN)) {
				transType = Constants.TRANS_TYPE_ID_CONF_IN;
			}
			if (creditContractVO.getTransType().equals(Constants.TRANS_TYPE_ID_IN)
					&& transType.equals(Constants.TRANS_TYPE_APP_CONF_OUT)) {
				transType = Constants.TRANS_TYPE_ID_CONF_OUT;
			}
		}

		String sequenceNo = creditContractVO.getAccr().getContractApplicationNumber() == null
				|| (!(Constants.ecoutUpdate.equalsIgnoreCase(creditContractVO.getTaskName())))
				|| ((Constants.ecoutUpdate.equalsIgnoreCase(creditContractVO.getTaskName()))
						&& (!(transType.equalsIgnoreCase(Constants.TRANS_TYPE_EC_ACK_IN)))) ? ""
								: creditContractVO.getAccr().getContractApplicationNumber();

		if (MessageProcessingUtil.containsValue(creditContractVO.getMessageProcessing(), "lenderSpecificACCRv1")
				&& transType.equalsIgnoreCase(Constants.TRANS_TYPE_EC_ACK_IN)) {
			// MB/CUDC sequence number is sent in the DocumentId
			sequenceNo = creditContractVO.getAccr().getSequenceNumber();
		}

		creditJournalVO.setSystemId(creditContractVO.getDealerInfo().getSystemId());
		creditJournalVO.setDealerId(creditContractVO.getDealerInfo().getDealerId());
		creditJournalVO.setPartnerId(creditContractVO.getPartnerInfo().getLenderId());
		creditJournalVO.setTransDateTime(journalObject.getTimestamp());
		creditJournalVO.setTransType(transType);
		// TODO set transflag dynamically
		creditJournalVO.setTransFlag("N");
		creditJournalVO.setPartnerDealNo(
				creditContractVO.getPartnerDealNumber() == null ? "" : creditContractVO.getPartnerDealNumber());
		creditJournalVO.setCrDataXml(encryptedXML);
		creditJournalVO.setAccountId(creditContractVO.getPartnerInfo().getLenderAccountId());
		creditJournalVO.setTransactionId(transactionId);
		creditJournalVO.setUserId(userId);
		// delivery source
		creditJournalVO.setDeliverySource(deliverySource);
		// application source
		creditJournalVO.setApplicationSource(applicationSource);
		// creditJournalVO.setApplType(creditContractVO.getContractValidation().getApplicationType());
		creditJournalVO.setApplType(financeType);
		// finance type
		creditJournalVO.setFinanceInstitution(financeType);
		// adp deal no
		creditJournalVO.setAdpDealNo(appDealNumber);
		// dspid
		creditJournalVO.setDspId(creditContractVO.getDealerInfo().getDspId());
		// sequence no
		creditJournalVO.setSequenceNo(sequenceNo);
		// dealid
		creditJournalVO.setDealId(creditContractVO.getContractValidation().getDealId());
		// sequence id
		creditJournalVO.setSequenceId(creditContractVO.getContractValidation().getSequenceId());
		//
		creditJournalVO.setAuditData(auditData);
		// keyid
		creditJournalVO.setEncryptionKeyId(keyId);
		
		logger.debug("CreditJournalVO Created: {}", creditJournalVO);

		return creditJournalVO;

	}
	
	/**
	 * @param journalObject
	 * @param contractValidation
	 * @return
	 * @throws EncryptionException
	 */
	public static CreditJournalVO createCreditJournal(final JournalObjectVO journalObject,
			final DeDealVO deDealVO, CreditJournalVO cjVO, AccrVO accrVO ) throws EncryptionException {

		logger.debug(
				"Enter createCreditJournal() method of JournalFactory. Transtype: " + journalObject.getTransType());

		CreditJournalVO creditJournalVO = new CreditJournalVO();
		String crDataXml = journalObject.getXmlData();
		String keyId = "";
		List<String> encryptedItems = EncryptionUtils.encryptText(crDataXml);
		keyId = encryptedItems.get(0);
		String encryptedXML = encryptedItems.get(1);
		String auditData = journalObject.getAppMessage().getMessageID() + " - "
				+ journalObject.getAppMessage().getMessage();
		if (auditData.length() > 200) {
			auditData = auditData.substring(0, 199);
		}

		String transType = journalObject.getTransType();
		String transactionId = cjVO.getTransactionId();
		String userId = cjVO.getUserId();
		String deliverySource = "RO";
		String applicationSource = cjVO.getApplicationSource();
		String financeType = deDealVO.getFinanceType();
		String appDealNumber = cjVO.getAdpDealNo();
		creditJournalVO.setSystemId(cjVO.getSystemId());
		creditJournalVO.setDealerId(cjVO.getDealerId());
		creditJournalVO.setPartnerId(accrVO.getLenderId());
		creditJournalVO.setTransDateTime(journalObject.getTimestamp());
		creditJournalVO.setTransType(transType);
		creditJournalVO.setTransFlag("N");
		creditJournalVO.setPartnerDealNo("");
		creditJournalVO.setCrDataXml(encryptedXML);
		creditJournalVO.setAccountId(deDealVO.getLenderDealerId());
		creditJournalVO.setTransactionId(transactionId);
		creditJournalVO.setUserId(userId);
		creditJournalVO.setDeliverySource(deliverySource);
		creditJournalVO.setApplicationSource(applicationSource);
		creditJournalVO.setApplType(financeType);
		creditJournalVO.setFinanceInstitution(financeType);
		creditJournalVO.setAdpDealNo(appDealNumber);
		creditJournalVO.setDspId(deDealVO.getDmsId());
		creditJournalVO.setSequenceNo("");
		creditJournalVO.setDealId(deDealVO.getDeDealId());
		creditJournalVO.setSequenceId(deDealVO.getCvSequenceId());
		creditJournalVO.setAuditData(auditData);
		creditJournalVO.setEncryptionKeyId(keyId);

		return creditJournalVO;

	}

	/**
	 * @param journalObject
	 * @param creditContractVO
	 * @return
	 */
	public static AuditJournalVO createAuditJournal(final JournalObjectVO journalObject,
			final CreditContractVO creditContractVO) {


		AuditJournalVO auditJournalVO = new AuditJournalVO();
		String auditData = journalObject.getAppMessage().getMessageID() + " - "
				+ journalObject.getAppMessage().getMessage();
		auditData = auditData.length() > 200 ? auditData.substring(0, 199) : auditData;
		String lenderAccountId = StringUtils.isNotEmpty(creditContractVO.getPartnerInfo().getLenderAccountId())
				? creditContractVO.getPartnerInfo().getLenderAccountId()
				: "NULL";
		String deliverySource = creditContractVO.getDeliverySource() == null ? ""
				: creditContractVO.getDeliverySource();
		String applicationSource = creditContractVO.getApplicationSource().length() > 2
				? creditContractVO.getApplicationSource().substring(0, 2)
				: creditContractVO.getApplicationSource();
		String dspId = creditContractVO.getDealerInfo().getDspId().length() > 2
				? creditContractVO.getDealerInfo().getDspId().substring(0, 2)
				: creditContractVO.getDealerInfo().getDspId();
		auditJournalVO.setAuditData(auditData);
		auditJournalVO.setTransType(journalObject.getTransType());
		auditJournalVO.setSystemId(creditContractVO.getDealerInfo().getSystemId());
		auditJournalVO.setDealerId(creditContractVO.getDealerInfo().getDealerId());
		auditJournalVO.setPartnerId(creditContractVO.getPartnerInfo().getLenderId());
		auditJournalVO.setTransDateTime(journalObject.getTimestamp());
		auditJournalVO.setAccountId(lenderAccountId);
		auditJournalVO.setDeliverySource(deliverySource);
		auditJournalVO.setApplicationSource(applicationSource);
		auditJournalVO.setDspId(dspId);
		auditJournalVO.setDeDealId(creditContractVO.getDeal().getDeDealId());

		return auditJournalVO;
	}

	/**
	 * @param creditJournalVO
	 * @return
	 */
	public static AuditJournalVO createAuditJournal(final CreditJournalVO creditJournalVO) {

		AuditJournalVO auditJournalVO = new AuditJournalVO();
		auditJournalVO.setAuditData(creditJournalVO.getAuditData());
		auditJournalVO.setTransType(creditJournalVO.getTransType());
		auditJournalVO.setSystemId(creditJournalVO.getSystemId());
		auditJournalVO.setDealerId(creditJournalVO.getDealerId());
		auditJournalVO.setPartnerId(creditJournalVO.getPartnerId());
		auditJournalVO.setTransDateTime(creditJournalVO.getTransDateTime());
		auditJournalVO.setAccountId("NULL");
		auditJournalVO.setDeliverySource(creditJournalVO.getDeliverySource());
		auditJournalVO.setApplicationSource(creditJournalVO.getApplicationSource());
		auditJournalVO.setDspId(creditJournalVO.getDspId());

		return auditJournalVO;
	}

}
