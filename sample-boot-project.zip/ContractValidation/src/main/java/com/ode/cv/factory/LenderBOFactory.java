/**
 * 
 */
package com.ode.cv.factory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.ode.cv.bo.GenericLenderBO;
import com.ode.cv.bo.ILenderBO;
import com.ode.cv.bo.VolLenderBO;
import com.ode.cv.util.Constants;

/**
 * @author rmathew
 *
 */
@Component
public class LenderBOFactory {
	
    private static final Logger logger = LogManager.getLogger(LenderBOFactory.class);
    
    public ILenderBO createLenderBO(final String lenderId)
    {
    	ILenderBO lenderBO = null;
    	if (Constants.LENDER_VOL.equals(lenderId))
    	{
    		lenderBO = new VolLenderBO();
    	}
    	else
    	{
    		lenderBO = new GenericLenderBO();
    	}
		return lenderBO;
    	
    }

}
