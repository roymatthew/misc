/**
 * 
 */
package com.ode.cv.factory;

import java.sql.Timestamp;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.cv.util.Constants;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.ContractPackageVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import com.ode.cv.vo.DealerInfoVO;
import com.ode.cv.vo.PartnerInfoVO;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.FormsVO;

/**
 * @author rmathew
 *
 */
public class VOFactory {

	private static final Logger logger = LogManager.getLogger(VOFactory.class);

	/**
	 * Private Constructor.
	 */
	private VOFactory() {
	}

	/**
	 * @param deal
	 * @return
	 */
	public static DeContractValidationBo createNewContractVal(final DeDealVO deal) {

		logger.debug("Entered createNewContractVal() method of VOFactory class");
		DeContractValidationBo contractVal = new DeContractValidationBo();
		String sequenceId = "";
		if (null != deal) {
			contractVal.setDealId(deal.getDeDealId());
			sequenceId = deal.getCvSequenceId();
		}
		if (StringUtils.isEmpty(sequenceId)) {
			sequenceId = "CV00";
		}
		sequenceId = "CV" + incrementSequenceId(sequenceId);
		contractVal.setSequenceId(sequenceId);
		contractVal.setAutoFundingIndicator("0");

		return contractVal;
	}

	/**
	 * @param deContractValidationBo
	 * @param deDealVO
	 */
	public static void updateCVSequenceId(final DeContractValidationBo deContractValidationBo,
			final DeDealVO deDealVO) {

		logger.debug("Entered updateCVSequenceId() method of VOFactory class");
		String sequenceId = (null == deDealVO) ? "" : deDealVO.getCvSequenceId();
		if (StringUtils.isEmpty(sequenceId)) {
			sequenceId = "CV00";
		}
		sequenceId = "CV" + incrementSequenceId(sequenceId);
		deContractValidationBo.setSequenceId(sequenceId);
		deContractValidationBo.setAutoFundingIndicator("0");
	}

	/**
	 * @param sequenceId
	 * @return
	 */
	private static String incrementSequenceId(final String sequenceId) {

		logger.debug("Entered incrementSequenceId()");
		String newSequenceId = "";
		int sequenceIdInt = 1;
		if (null == sequenceId || sequenceId.length() <= 2) {
			logger.warn("sequence id null or not long enough:{}, defaulting to 1", sequenceId);
			newSequenceId = "01";
			return newSequenceId;
		}
		try {
			sequenceIdInt = Integer.parseInt(sequenceId.substring(2));
			sequenceIdInt += 1;
		} catch (NumberFormatException e) {
			logger.warn("could not parse sequence id:{}, defaulting to 1", sequenceId.substring(2));
		}
		if (sequenceIdInt >= 100) {
			logger.warn("sequence id overflow - restarting at 1");
			newSequenceId = "01";
		} else if (sequenceIdInt >= 10) {
			newSequenceId = Integer.toString(sequenceIdInt);
		} else {
			newSequenceId = "0" + Integer.toString(sequenceIdInt);
		}
		return newSequenceId;
	}

	/**
	 * @param creditContractVO
	 * @param transType
	 * @param integerPK
	 * @return
	 */
	public static DeDealBo createNewDealBo(final CreditContractVO creditContractVO, final String transType,
			final Integer integerPK) {

		logger.debug("Entered createNewDealBo() method of VOFactory class");
		DeDealBo deal = new DeDealBo();
		deal.setDeDealId(getNewDealId(integerPK));
		deal.setFinanceType(getFinanceTypeFromECIN(creditContractVO, transType));
		deal.setDmsId(creditContractVO.getDealerInfo().getDspId());
		return deal;
	}

	/**
	 * @param dealVO
	 * @param dealFromDocument
	 */
	public static void updateDealWithDealFromDocument(final DeDealVO dealVO, final DeDealBo dealFromDocument) {
		logger.debug("Entered updateDealWithDealFromDocument() method of VOFactory class");

		if (dealFromDocument.getDeDealId() != null && !dealFromDocument.getDeDealId().isEmpty()) {
			dealVO.setDeDealId(dealFromDocument.getDeDealId());
		}
		if (dealFromDocument.getLenderDealerId() != null && !dealFromDocument.getLenderDealerId().isEmpty()) {
			dealVO.setLenderDealerId(dealFromDocument.getLenderDealerId());
		}
		if (dealFromDocument.getDmsDealerId() != null && !dealFromDocument.getDmsDealerId().isEmpty()) {
			dealVO.setDmsDealerId(dealFromDocument.getDmsDealerId());
		}
		if (dealFromDocument.getDmsDealNum() != null && !dealFromDocument.getDmsDealNum().isEmpty()) {
			dealVO.setDmsDealNum(dealFromDocument.getDmsDealNum());
		}
		if (dealFromDocument.getVaultDocId() != null && !dealFromDocument.getVaultDocId().isEmpty()) {
			dealVO.setVaultDocId(dealFromDocument.getVaultDocId());
		}
		if (dealFromDocument.getLenderId() != null && !dealFromDocument.getLenderId().isEmpty()) {
			dealVO.setLenderId(dealFromDocument.getLenderId());
		}
		if (dealFromDocument.getDmsId() != null && !dealFromDocument.getDmsId().isEmpty()) {
			dealVO.setDmsId(dealFromDocument.getDmsId());
		}
		if (dealFromDocument.getFinanceType() != null && !dealFromDocument.getFinanceType().isEmpty()) {
			dealVO.setFinanceType(dealFromDocument.getFinanceType());
		}
		if (dealFromDocument.getDealExecutionState() != null && !dealFromDocument.getDealExecutionState().isEmpty()) {
			dealVO.setDealExecutionState(dealFromDocument.getDealExecutionState());
		}
		if (dealFromDocument.getVin() != null && !dealFromDocument.getVin().isEmpty()) {
			dealVO.setVin(dealFromDocument.getVin());
		}
		if (dealFromDocument.getBuyerFirstName() != null && !dealFromDocument.getBuyerFirstName().isEmpty()) {
			dealVO.setBuyerFirstName(dealFromDocument.getBuyerFirstName());
		}
		if (dealFromDocument.getBuyerLastName() != null && !dealFromDocument.getBuyerLastName().isEmpty()) {
			dealVO.setBuyerLastName(dealFromDocument.getBuyerLastName());
		}
		if (dealFromDocument.getCaSequenceId() != null && !dealFromDocument.getCaSequenceId().isEmpty()) {
			dealVO.setCaSequenceId(dealFromDocument.getCaSequenceId());
		}
		if (dealFromDocument.getCaApplicationNum() != null && !dealFromDocument.getCaApplicationNum().isEmpty()) {
			dealVO.setCaApplicationNum(dealFromDocument.getCaApplicationNum());
		}
		if (dealFromDocument.getApplicationType() != null && !dealFromDocument.getApplicationType().isEmpty()) {
			dealVO.setApplicationType(dealFromDocument.getApplicationType());
		}
		if (dealFromDocument.getCaStatus() != null && !dealFromDocument.getCaStatus().isEmpty()) {
			dealVO.setCaStatus(dealFromDocument.getCaStatus());
		}
		if (dealFromDocument.getCvSequenceId() != null && !dealFromDocument.getCvSequenceId().isEmpty()) {
			dealVO.setCvSequenceId(dealFromDocument.getCvSequenceId());
		}
		if (dealFromDocument.getCvStatus() != null && !dealFromDocument.getCvStatus().isEmpty()) {
			dealVO.setCvStatus(dealFromDocument.getCvStatus());
		}
		if (dealFromDocument.getCvStatusTs() != null) {
			Timestamp ts = new Timestamp(dealFromDocument.getCvStatusTs().getTime());
			dealVO.setCvStatusTs(ts);
		}
		if (dealFromDocument.getCvSubmittedTs() != null) {
			Timestamp ts = new Timestamp(dealFromDocument.getCvSubmittedTs().getTime());
			dealVO.setCvSubmittedTs(ts);
		}
		if (dealFromDocument.getLenderSeqNum() != null && !dealFromDocument.getLenderSeqNum().isEmpty()) {
			dealVO.setLenderSeqNum(dealFromDocument.getLenderSeqNum());
		}
		if (dealFromDocument.getAccountNum() != null && !dealFromDocument.getAccountNum().isEmpty()) {
			dealVO.setAccountNum(dealFromDocument.getAccountNum());
		}
		if (dealFromDocument.getFundingStatus() != null && !dealFromDocument.getFundingStatus().isEmpty()) {
			dealVO.setFundingStatus(dealFromDocument.getFundingStatus());
		}
		if (dealFromDocument.getFundingStatusTs() != null) {
			Timestamp ts = new Timestamp(dealFromDocument.getFundingStatusTs().getTime());
			dealVO.setFundingStatusTs(ts);
		}
		if (dealFromDocument.getDistributionTs() != null) {
			Timestamp ts = new Timestamp(dealFromDocument.getDistributionTs().getTime());
			dealVO.setDistributionTs(ts);
		}
		if (dealFromDocument.geteConStatus() != null && !dealFromDocument.geteConStatus().isEmpty()) {
			dealVO.setEconStatus(dealFromDocument.geteConStatus());
		}
		if (dealFromDocument.geteConStatusTs() != null) {
			Timestamp ts = new Timestamp(dealFromDocument.geteConStatusTs().getTime());
			dealVO.setEconStatusTs(ts);
		}
		if (dealFromDocument.geteConSubmittedTs() != null) {
			Timestamp ts = new Timestamp(dealFromDocument.geteConSubmittedTs().getTime());
			dealVO.setEconSubmittedTs(ts);
		}
		if (dealFromDocument.getContractDate() != null) {
			dealVO.setContractDate(dealFromDocument.getContractDate());
		}
		if (dealFromDocument.getSpotFlag() != null) {
			dealVO.setSpotFlag(dealFromDocument.getSpotFlag());
		}
		if (dealFromDocument.getTerm() != null) {
			dealVO.setTerm(dealFromDocument.getTerm());
		}
		if (dealFromDocument.getLoanAmount() != null) {
			dealVO.setLoanAmount(dealFromDocument.getLoanAmount());
		}
		if (dealFromDocument.getProductType() != null) {
			dealVO.setProductType(dealFromDocument.getProductType());
		}
		if (dealFromDocument.getVehicleCondition() != null) {
			dealVO.setVehicleCondition(dealFromDocument.getVehicleCondition());
		}

	}

	/**
	 * @param context
	 * @param transType
	 * @return
	 */
	public static String getFinanceTypeFromECIN(final CreditContractVO context, final String transType) {
		String deDealFinanceType = context.getFinanceType();
		if (Constants.TRANS_TYPE_EC_IN.equals(transType)
				|| Constants.TRANS_TYPE_EC_IN_WITH_ATTACHMENT.equals(transType)) {
			if ("F".equals(deDealFinanceType)) {
				deDealFinanceType = "R";
			}
		}
		return deDealFinanceType;
	}

	/**
	 * @param integerValue
	 * @return
	 */
	private static String getNewDealId(final Integer integerValue) {
		logger.debug("Enter getNewDealId() method of VOFactory class");
		int dealIdInt = integerValue.intValue();
		String dealId = "000000000000";
		String unpaddedDealId = Integer.toString(dealIdInt);
		dealId = dealId.substring(0, 12 - unpaddedDealId.length()) + unpaddedDealId;
		return dealId;
	}

	/**
	 * @param contractValidationToPersist
	 * @param deContractValidationBo
	 */
	public static void updateContractValidationFromDocument(final DeContractValidationVO contractValidationToPersist,
			final DeContractValidationBo from) {
		logger.debug("Entered updateContractValidationFromDocument() method of VOFactory class");
		if (from.getDealId() != null && !from.getDealId().isEmpty()) {
			contractValidationToPersist.setDealId(from.getDealId());
		}
		/*
		 * if(from.getLenderId() != null && !from.getLenderId().isEmpty()){
		 * contractValidationToPersist.setLenderId(from.getLenderId()); }
		 */
		if (from.getDmsId() != null && !from.getDmsId().isEmpty()) {
			contractValidationToPersist.setDmsDealNum(from.getDmsId());
		}
		if (from.getSequenceId() != null && !from.getSequenceId().isEmpty()) {
			contractValidationToPersist.setSequenceId(from.getSequenceId());
		}
		if (from.getStatus() != null && !from.getStatus().isEmpty()) {

			String status = null;

			if (from.getStatus().length() > 10) {
				status = from.getStatus().substring(0, 10);
			} else {
				status = from.getStatus();
			}
			contractValidationToPersist.setStatus(status);
		}
		if (from.getStatusTs() != null) {
			Timestamp tS = new Timestamp(from.getStatusTs().getTime());
			contractValidationToPersist.setStatusTs(tS);
		}
		if (from.getSubmittedTs() != null) {
			Timestamp tS = new Timestamp(from.getSubmittedTs().getTime());
			contractValidationToPersist.setSubmittedTs(tS);
		}
		if (from.getDmsDealNum() != null && !from.getDmsDealNum().isEmpty()) {
			contractValidationToPersist.setDmsDealNum(from.getDmsDealNum());
		}
		if (from.getLenderSeqNum() != null && !from.getLenderSeqNum().isEmpty()) {
			contractValidationToPersist.setLenderSeqNum(from.getLenderSeqNum());
		}
		if (from.getAccountNum() != null && !from.getAccountNum().isEmpty()) {
			contractValidationToPersist.setAccountNum(from.getAccountNum());
		}
		if (from.getApplicationType() != null && !from.getApplicationType().isEmpty()) {
			contractValidationToPersist.setApplicationType(from.getApplicationType());
		}
		if (from.getDealerId() != null && !from.getDealerId().isEmpty()) {
			contractValidationToPersist.setDealerId(from.getDealerId());
		}
		if (from.getVin() != null && !from.getVin().isEmpty()) {
			contractValidationToPersist.setVin(from.getVin());
		}
		if (from.getBuyerFirstName() != null && !from.getBuyerFirstName().isEmpty()) {
			contractValidationToPersist.setBuyerFirstName(from.getBuyerFirstName());
		}
		if (from.getBuyerLastName() != null && !from.getBuyerLastName().isEmpty()) {
			contractValidationToPersist.setBuyerLastName(from.getBuyerLastName());
		}
		if (from.getBuyerLastName() != null && !from.getBuyerLastName().isEmpty()) {
			contractValidationToPersist.setBuyerLastName(from.getBuyerLastName());
		}
		if (from.getVaultDocId() != null && !from.getVaultDocId().isEmpty()) {
			contractValidationToPersist.setVaultDocId(from.getVaultDocId());
		}
		if (from.getFromPf() != null && !from.getFromPf().isEmpty()) {
			contractValidationToPersist.setFromPf(from.getFromPf());
		}
		if (from.getApplicationType() != null && !from.getApplicationType().isEmpty()) {
			contractValidationToPersist.setApplicationType(from.getApplicationType());
		}

	}

	/**
	 * @param creditContractVO
	 * @return
	 */
	public static CVTransmitVO createCVTransmitVO(final CreditContractVO creditContractVO) {
		logger.debug("Entered createTransmitVO() method of VOFactory class");
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		cvTransmitVO.setPartnerInfoVO(creditContractVO.getPartnerInfo());
		cvTransmitVO.setLenderRequestXml(creditContractVO.getLenderRequestXml());
		cvTransmitVO.setDestinationProductId(Constants.CV_DESTINATION_PRODUCT_ID);
		return cvTransmitVO;
	}

	/**
	 * @param creditContractVO
	 * @param formsVO 
	 * @return
	 */
	public static ContractPackageVO createContractPackageVO(final CreditContractVO creditContractVO) {
		logger.debug("Entered createContractPackageVO() method of VOFactory class");
		ContractPackageVO contractPackage = new ContractPackageVO();
		contractPackage.setContractId(creditContractVO.getContractValidation().getContractId());
		contractPackage.setContractType(StringUtils.isBlank(creditContractVO.getContractType()) ? "LAW" : creditContractVO.getContractType());
		if (null != creditContractVO.getDealerInfo().getPartnerId()) {
			logger.debug("creditContractVO.getDealerInfo().getPartnerId(): {}",
					creditContractVO.getDealerInfo().getPartnerId());
			contractPackage.setPartnerFSID(creditContractVO.getDealerInfo().getPartnerId());
		} else {
			logger.debug("creditContractVO.getPartnerInfo().getLenderId(): {}",
					creditContractVO.getPartnerInfo().getLenderId());
			contractPackage.setPartnerFSID(creditContractVO.getPartnerInfo().getLenderId());
		}
		if (null != creditContractVO.getConversationId()) {
			String conversationId = creditContractVO.getConversationId().length() > 20
					? creditContractVO.getConversationId().substring(0, 20)
					: creditContractVO.getConversationId();
			contractPackage.setConversationId(conversationId);
		}

		return contractPackage;
	}

	/**
	 * @param creditJournalVO
	 * @return
	 */
	public static CreditContractVO createCreditContractFromExistingCreditJournal(
			final CreditJournalVO creditJournalVO) {
		logger.debug("Entered createCreditContractFromExistingCreditJournal method of VOFactory class");
		CreditContractVO creditContractVO = new CreditContractVO();
		creditContractVO.setPartnerInfo(new PartnerInfoVO());
		creditContractVO.setDealerInfo(new DealerInfoVO());
		creditContractVO.setApplicationSource(creditJournalVO.getApplicationSource());
		creditContractVO.setAdpDealNo(creditJournalVO.getAdpDealNo());
		creditContractVO.getDealerInfo().setDealerId(creditJournalVO.getDealerId());
		return creditContractVO;
	}
	
	/**
	 * @param creditContractVO
	 * @return
	 */
	public static AccrVO createAccrVOFromCreditContract(final CreditContractVO creditContractVO)
	{
		logger.debug("Entered createAccrFromCreditContract method of VOFactory class");
		AccrVO accrVO = new AccrVO();
		accrVO.setDealerNumber(creditContractVO.getDealerInfo().getDealerId());
		accrVO.setStoreNumber(creditContractVO.getDealerInfo().getStoreNumber());
		accrVO.setReferenceId(creditContractVO.getAdpDealNo());
		accrVO.setAuthorizationId(creditContractVO.getUserId());
		accrVO.setContractFormNumber(creditContractVO.getContractFormNumber());
		accrVO.setDestinationCode(creditContractVO.getDestinationNameCode());
		//accrVO.setDocumentVersionNumber(creditContractVO.getdoc);
		//accrVO.setFinanceCompanyName(creditContractVO.getPartnerInfo().getle);
		accrVO.setDealerName(creditContractVO.getDealerName());
		//accrVO.setApplicationType(applicationType);
		//accrVO.setfinanceType
		//accrVO.setPaymentAmount(creditContractVO);
		//accrVO.setNetAnnualPercentageRate(netAnnualPercentageRate);
		accrVO.setBodId(creditContractVO.getDocumentId());
		return accrVO;
	}

}
