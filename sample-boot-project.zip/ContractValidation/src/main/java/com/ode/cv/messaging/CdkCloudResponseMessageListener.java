package com.ode.cv.messaging;

import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.ode.cv.service.ICdkCloudService;

public class CdkCloudResponseMessageListener implements MessageListener {

	private static final Logger log = LogManager.getLogger(CdkCloudResponseMessageListener.class);
	
	@Autowired
	private ICdkCloudService cdkCloudService;
	
	@Override
	public void onMessage(final Message message) {
		ThreadContext.put("uuid", UUID.randomUUID().toString());
		log.debug("Entered onMessage() of CdkCloudResponseMessageListener class. Message: {} ", message);
	
		final TextMessage textMessage = (TextMessage) message;
		String jsonString = null;
		try {
			jsonString = textMessage.getText();
			if (jsonString != null && log.isDebugEnabled()) {
				log.debug("Received message in listener: {}", jsonString);
			}
			textMessage.acknowledge();

		} catch (JMSException e) {
			log.error(e);
		}
		
		cdkCloudService.processCdkCloudJsonResponse(jsonString);
	}
}