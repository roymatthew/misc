package com.ode.cv.messaging;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component
public class CdkCloudResponseMessageProducer {
	
	private static final Logger log = LogManager.getLogger(CdkCloudResponseMessageProducer.class);

	@Autowired
	@Qualifier("cdkCloudResponseJmsTemplate")
	private JmsTemplate jmsTemplate;
	
	public void sendMessage(final String message) throws JMSException {
		log.debug("Enter sendMessage");

		try {
			jmsTemplate.send(new MessageCreator() {

				@Override
				public Message createMessage(Session session) throws JMSException {
					return session.createTextMessage(message);
				}
			});

			log.debug("Message written to CDK.CLOUD.RESP.QUEUE");

		} catch (final JmsException e) {
			log.error(e);
		}
	}
}
