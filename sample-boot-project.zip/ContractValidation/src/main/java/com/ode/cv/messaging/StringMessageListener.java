package com.ode.cv.messaging;

import javax.jms.Message;
import javax.jms.MessageListener;

public class StringMessageListener implements MessageListener {

	@Override
	public void onMessage(final Message message) {
		
		System.out.println("Received Message: " + message);

	}

}
