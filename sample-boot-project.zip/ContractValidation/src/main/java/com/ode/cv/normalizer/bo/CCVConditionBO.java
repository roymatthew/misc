package com.ode.cv.normalizer.bo;

public class CCVConditionBO {

	private int conditionId;
	private CCVXPathBO xpath;
	private String operation;
	private String value;
	
	public int getConditionId() {
		return conditionId;
	}
	
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	
	public CCVXPathBO getXpath() {
		return xpath;
	}
	
	public void setXpath(CCVXPathBO xpath) {
		this.xpath = xpath;
	}
	
	public String getOperation() {
		return operation;
	}
	
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CCVConditionBO [conditionId=");
		builder.append(conditionId);
		builder.append(", xpath=");
		builder.append(xpath);
		builder.append(", operation=");
		builder.append(operation);
		builder.append(", value=");
		builder.append(value);
		builder.append("]");
		return builder.toString();
	}
}