package com.ode.cv.normalizer.bo;

public class CCVDataExceptionBO {

	private CCVXPathBO xpath;
	private String child;
	private String childValue;
	
	public CCVXPathBO getXpath() {
		return xpath;
	}
	
	public void setXpath(CCVXPathBO xpath) {
		this.xpath = xpath;
	}
	
	public String getChild() {
		return child;
	}
	
	public void setChild(String child) {
		this.child = child;
	}
	
	public String getChildValue() {
		return childValue;
	}
	
	public void setChildValue(String childValue) {
		this.childValue = childValue;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CCVDataExceptionBO [xpath=");
		builder.append(xpath);
		builder.append(", child=");
		builder.append(child);
		builder.append(", childValue=");
		builder.append(childValue);
		builder.append("]");
		return builder.toString();
	}
}