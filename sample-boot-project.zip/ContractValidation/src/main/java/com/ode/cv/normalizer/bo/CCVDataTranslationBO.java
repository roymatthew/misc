package com.ode.cv.normalizer.bo;

import java.util.List;

public class CCVDataTranslationBO {

	private int translationId;
	private int conditionSet;
	private List<CCVConditionBO> conditions;
	private CCVXPathBO xpath;
	private CCVXPathBO translateToElement;
	private String translateToValue;
	private int order;
	
	public int getTranslationId() {
		return translationId;
	}
	
	public void setTranslationId(int translationId) {
		this.translationId = translationId;
	}
	
	public int getConditionSet() {
		return conditionSet;
	}
	
	public void setConditionSet(int conditionSet) {
		this.conditionSet = conditionSet;
	}
	
	public List<CCVConditionBO> getConditions() {
		return conditions;
	}
	
	public void setConditions(List<CCVConditionBO> conditions) {
		this.conditions = conditions;
	}
	
	public CCVXPathBO getXpath() {
		return xpath;
	}
	
	public void setXpath(CCVXPathBO xpath) {
		this.xpath = xpath;
	}
	
	public CCVXPathBO getTranslateToElement() {
		return translateToElement;
	}
	
	public void setTranslateToElement(CCVXPathBO translateToElement) {
		this.translateToElement = translateToElement;
	}
	
	public String getTranslateToValue() {
		return translateToValue;
	}
	
	public void setTranslateToValue(String translateToValue) {
		this.translateToValue = translateToValue;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CCVDataTranslationBO [translationId=");
		builder.append(translationId);
		builder.append(", conditions=");
		builder.append(conditions);
		builder.append(", xpath=");
		builder.append(xpath);
		builder.append(", translateToElement=");
		builder.append(translateToElement);
		builder.append(", translateToValue=");
		builder.append(translateToValue);
		builder.append(", order=");
		builder.append(order);
		builder.append("]");
		return builder.toString();
	}
}