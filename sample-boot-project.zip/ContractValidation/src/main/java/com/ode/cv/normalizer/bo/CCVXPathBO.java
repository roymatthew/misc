package com.ode.cv.normalizer.bo;

import java.util.List;

public class CCVXPathBO {

	private int xpathId;
	private String xpathKey;
	private String xpath;
	private String parentXpath;
	
	public int getXpathId() {
		return xpathId;
	}
	
	public void setXpathId(int xpathId) {
		this.xpathId = xpathId;
	}
	
	public String getXpathKey() {
		return xpathKey;
	}
	
	public void setXpathKey(String xpathKey) {
		this.xpathKey = xpathKey;
	}
	
	public String getXpath() {
		return xpath;
	}

	public void setXpath(String xpath) {
		this.xpath = xpath;
	}

	public String getParentXpath() {
		return parentXpath;
	}
	
	public void setParentXpath(String parentXpath) {
		this.parentXpath = parentXpath;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CCVXPathBO [xpathId=");
		builder.append(xpathId);
		builder.append(", xpathKey=");
		builder.append(xpathKey);
		builder.append(", xpath=");
		builder.append(xpath);
		builder.append(", parentXpath=");
		builder.append(parentXpath);
		builder.append("]");
		return builder.toString();
	}

}