package com.ode.cv.normalizer.bo;

import java.util.Date;

public class DCFormBO implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	private Long dcDigitalDealId;
	private String formId;
	private String formName;
	private String formComment = "";
	private Date lenderReceivedDate;
	private Date transferredDate;
	private Date createdTs;
	private String createdBy;
	private Date modifiedTs;
	private String modifiedBy;
	private String deDealId;
	private String formStatus;
	private String productDescription;
	private String productFormName;
	private Date productFormVersionDate;
	private String rflSequenceId;
	private Integer dcDocumentId; 
	private String requiredFormFlag;
	private String lenderSeqNum;
	
	public Long getDcDigitalDealId() {
		return dcDigitalDealId;
	}
	public void setDcDigitalDealId(Long dcDigitalDealId) {
		this.dcDigitalDealId = dcDigitalDealId;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFormComment() {
		return formComment;
	}
	public void setFormComment(String formComment) {
		this.formComment = formComment;
	}
	public Date getLenderReceivedDate() {
		return lenderReceivedDate;
	}
	public void setLenderReceivedDate(Date lenderReceivedDate) {
		this.lenderReceivedDate = lenderReceivedDate;
	}
	public Date getTransferredDate() {
		return transferredDate;
	}
	public void setTransferredDate(Date transferredDate) {
		this.transferredDate = transferredDate;
	}
	public Date getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Date modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}
	public String getFormStatus() {
		return formStatus;
	}
	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductFormName() {
		return productFormName;
	}
	public void setProductFormName(String productFormName) {
		this.productFormName = productFormName;
	}
	public Date getProductFormVersionDate() {
		return productFormVersionDate;
	}
	public void setProductFormVersionDate(Date productFormVersionDate) {
		this.productFormVersionDate = productFormVersionDate;
	}
	public String getRflSequenceId() {
		return rflSequenceId;
	}
	public void setRflSequenceId(String rflSequenceId) {
		this.rflSequenceId = rflSequenceId;
	}
	public Integer getDcDocumentId() {
		return dcDocumentId;
	}
	public void setDcDocumentId(Integer dcDocumentId) {
		this.dcDocumentId = dcDocumentId;
	}
	public String getRequiredFormFlag() {
		return requiredFormFlag;
	}
	public void setRequiredFormFlag(String requiredFormFlag) {
		this.requiredFormFlag = requiredFormFlag;
	}
	public String getLenderSeqNum() {
		return lenderSeqNum;
	}
	public void setLenderSeqNum(String lenderSeqNum) {
		this.lenderSeqNum = lenderSeqNum;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DCFormBO [dcDigitalDealId=");
		builder.append(dcDigitalDealId);
		builder.append(", formId=");
		builder.append(formId);
		builder.append(", formName=");
		builder.append(formName);
		builder.append(", formComment=");
		builder.append(formComment);
		builder.append(", lenderReceivedDate=");
		builder.append(lenderReceivedDate);
		builder.append(", transferredDate=");
		builder.append(transferredDate);
		builder.append(", createdTs=");
		builder.append(createdTs);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", modifiedTs=");
		builder.append(modifiedTs);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", deDealId=");
		builder.append(deDealId);
		builder.append(", formStatus=");
		builder.append(formStatus);
		builder.append(", productDescription=");
		builder.append(productDescription);
		builder.append(", productFormName=");
		builder.append(productFormName);
		builder.append(", productFormVersionDate=");
		builder.append(productFormVersionDate);
		builder.append(", rflSequenceId=");
		builder.append(rflSequenceId);
		builder.append(", dcDocumentId=");
		builder.append(dcDocumentId);
		builder.append(", requiredFormFlag=");
		builder.append(requiredFormFlag);
		builder.append(", lenderSeqNum=");
		builder.append(lenderSeqNum);
		builder.append("]");
		return builder.toString();
	}
}
