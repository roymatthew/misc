package com.ode.cv.normalizer.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.cv.normalizer.bo.CCVConditionBO;
import com.ode.cv.normalizer.bo.CCVDataExceptionBO;
import com.ode.cv.normalizer.bo.CCVDataTranslationBO;
import com.ode.cv.normalizer.bo.CCVXPathBO;
import com.ode.cv.vo.CcvInputVO;
import com.ode.persistence.vo.CcvConditionSetVO;
import com.ode.persistence.vo.CcvConditionVO;
import com.ode.persistence.vo.CcvDataExceptionVO;
import com.ode.persistence.vo.CcvDataTranslationVO;
import com.ode.persistence.vo.CcvXpathVO;

public class DataTranslationMapper {

	private static final Logger logger = LogManager.getLogger(DataTranslationMapper.class);

	public static List<CCVDataTranslationBO> mapDataTranslations(final CcvInputVO ccvInputVO) {
		logger.debug("Entered mapDataTranslations() ");

		// DB Lists
		List<CcvDataTranslationVO> dataTranslationsDB = ccvInputVO.getListOfDataTranslations();
		List<CcvConditionVO> conditionsDB = ccvInputVO.getListOfCcvConditions();
		List<CcvConditionSetVO> conditionSetsDB = ccvInputVO.getListOfCcvConditionSets();
		List<CcvXpathVO> xPathsDB = ccvInputVO.getListOfCcvXpaths();

		// BO Lists
		List<CCVDataTranslationBO> dataTranslations = new ArrayList<CCVDataTranslationBO>();
		List<CCVConditionBO> conditions = new ArrayList<CCVConditionBO>();
		List<CCVXPathBO> xPaths = mapXPaths(xPathsDB);

		for (CcvConditionVO conditionDB : conditionsDB) {
			CCVConditionBO condition = new CCVConditionBO();

			condition.setConditionId(conditionDB.getConditionId());
			condition.setXpath(NormalizerUtil.getXPathByKey(xPaths, conditionDB.getXpathKey()));
			condition.setOperation(conditionDB.getOperation());
			condition.setValue(conditionDB.getValue());
			conditions.add(condition);
		}

		for (CcvDataTranslationVO dataTranslationDB : dataTranslationsDB) {
			CCVDataTranslationBO dataTranslation = new CCVDataTranslationBO();

			dataTranslation.setTranslationId(dataTranslationDB.getTranslationId());
			dataTranslation.setConditionSet(dataTranslationDB.getConditionSet());
			dataTranslation.setConditions(
					NormalizerUtil.getConditionsById(dataTranslationDB.getConditionSet(), conditionSetsDB, conditions));
			dataTranslation.setXpath(NormalizerUtil.getXPathByKey(xPaths, dataTranslationDB.getXpathKey()));
			dataTranslation.setTranslateToElement(
					NormalizerUtil.getXPathByKey(xPaths, dataTranslationDB.getTranslateToElement()));
			dataTranslation.setTranslateToValue(dataTranslationDB.getTranslateToValue());
			dataTranslation.setOrder(dataTranslationDB.getOrder());
			dataTranslations.add(dataTranslation);
		}

		return dataTranslations;
	}

	public static List<CCVDataExceptionBO> mapDataExceptions(final CcvInputVO ccvInputVO) {
		logger.debug("Entered mapDataExceptions() ");
		// DB Lists
		List<CcvXpathVO> xPathsDB = ccvInputVO.getListOfCcvXpaths();
		List<CcvDataExceptionVO> dataExceptionsDB = ccvInputVO.getListOfDataExceptions();

		// BO Lists
		List<CCVXPathBO> xPaths = mapXPaths(xPathsDB);
		List<CCVDataExceptionBO> dataExceptions = new ArrayList<CCVDataExceptionBO>();

		for (CcvDataExceptionVO dataExceptionDB : dataExceptionsDB) {
			CCVDataExceptionBO dataException = new CCVDataExceptionBO();

			dataException.setXpath(NormalizerUtil.getXPathById(xPaths, dataExceptionDB.getXpathId()));
			dataException.setChild(dataExceptionDB.getChild());
			dataException.setChildValue(dataExceptionDB.getChildValue());
			dataExceptions.add(dataException);
		}

		return dataExceptions;
	}

	public static List<CCVXPathBO> mapXPaths(List<CcvXpathVO> xPathsDB) {
		logger.debug("Entered mapXPaths() ");
		List<CCVXPathBO> xPaths = new ArrayList<CCVXPathBO>();

		for (CcvXpathVO xPathDB : xPathsDB) {
			CCVXPathBO xPath = new CCVXPathBO();

			xPath.setXpathId(xPathDB.getXpathId());
			xPath.setXpathKey(xPathDB.getXpathKey());
			xPath.setXpath(xPathDB.getXpath());
			xPath.setParentXpath(NormalizerUtil.getParentXPath(xPathsDB, xPathDB.getParentXpath()));
			xPaths.add(xPath);
		}

		return xPaths;
	}
}