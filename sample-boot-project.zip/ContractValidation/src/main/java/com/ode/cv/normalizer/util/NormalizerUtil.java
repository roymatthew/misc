package com.ode.cv.normalizer.util;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.microsoft.sqlserver.jdbc.StringUtils;
import com.ode.cv.normalizer.bo.CCVConditionBO;
import com.ode.cv.normalizer.bo.CCVDataExceptionBO;
import com.ode.cv.normalizer.bo.CCVDataTranslationBO;
import com.ode.cv.normalizer.bo.CCVXPathBO;
import com.ode.cv.util.Constants;
import com.ode.cv.vo.CcvInputVO;
import com.ode.persistence.vo.CcvConditionSetVO;
import com.ode.persistence.vo.CcvConditionVO;
import com.ode.persistence.vo.CcvDataTranslationVO;
import com.ode.persistence.vo.CcvXpathVO;

public class NormalizerUtil {

	private static final Logger logger = LogManager.getLogger(NormalizerUtil.class);

	public static List<Integer> getDistinctConditionIdsForSQL(final CcvInputVO ccvInputVO) {
		logger.debug("Entered getDistinctConditionIdsForSQL() method of NormalizerUtil class");
		List<Integer> conditionIds = new ArrayList<Integer>();
		List<CcvConditionSetVO> listOfConditionSetVOs = ccvInputVO.getListOfCcvConditionSets();

		for (CcvConditionSetVO conditionSet : listOfConditionSetVOs) {
			int conditionId = conditionSet.getConditionId();
			if (!conditionIds.contains(conditionId)) {
				conditionIds.add(conditionId);
			}
		}

		return conditionIds;
	}

	/**
	 * @param ccvInputVO
	 * @return
	 */
	public static List<String> getDistinctXPathKeysForSQL(final CcvInputVO ccvInputVO) {
		logger.debug("Entered getDistinctXPathKeysForSQL() method of NormalizerUtil class");
		List<String> xpathKeys = new ArrayList<String>();
		List<CcvDataTranslationVO> listOfDataTranslations = ccvInputVO.getListOfDataTranslations();
		List<CcvConditionVO> listOfConditions = ccvInputVO.getListOfCcvConditions();

		for (CcvDataTranslationVO dataTranslation : listOfDataTranslations) {
			String xpathKey = dataTranslation.getXpathKey();
			String transToElement = dataTranslation.getTranslateToElement();

			if (!xpathKeys.contains(xpathKey)) {
				xpathKeys.add(xpathKey);
			}

			if (!xpathKeys.contains(transToElement)) {
				xpathKeys.add(transToElement);
			}
		}

		for (CcvConditionVO condition : listOfConditions) {
			String xpathKey = condition.getXpathKey();
			if (!xpathKeys.contains(xpathKey)) {
				xpathKeys.add(xpathKey);
			}
		}

		return xpathKeys;
	}

	/**
	 * @param xpaths
	 * @param parentXpathId
	 * @return
	 */
	public static String getParentXPath(final List<CcvXpathVO> xpaths, final Integer parentXpathId) {
		// logger.debug("Entered getParentXPath() "); //this is called too many times
		// per request and fills up the logs
		if (null == parentXpathId) {
			return null;
		}

		for (CcvXpathVO xpath : xpaths) {
			if (parentXpathId == xpath.getXpathId()) {
				return xpath.getXpath();
			}
		}

		return null;
	}

	/**
	 * @param xpaths
	 * @param xpathKey
	 * @return
	 */
	public static CCVXPathBO getXPathByKey(final List<CCVXPathBO> xpaths, final String xpathKey) {
		// logger.debug("Entered getXPathByKey() "); //this is called too many times per
		// request and fills up the logs
		for (CCVXPathBO xpath : xpaths) {
			if (xpath.getXpathKey().equalsIgnoreCase(xpathKey)) {
				return xpath;
			}
		}

		return new CCVXPathBO();
	}

	/**
	 * @param xPaths
	 * @param xpathId
	 * @return
	 */
	public static CCVXPathBO getXPathById(final List<CCVXPathBO> xPaths, final int xpathId) {
		logger.debug("Entered getXPathById() method of NormalizerUtil class");
		for (CCVXPathBO xpath : xPaths) {
			if (xpath.getXpathId() == xpathId) {
				return xpath;
			}
		}

		return new CCVXPathBO();
	}

	/**
	 * @param conditionSet
	 * @param listOfConditionSetVOs
	 * @param conditions
	 * @return
	 */
	public static List<CCVConditionBO> getConditionsById(final int conditionSet,
			final List<CcvConditionSetVO> listOfConditionSetVOs, final List<CCVConditionBO> conditions) {
		// logger.debug("Entered getConditionsById() "); //this is called too many times
		// per request and fills up the logs
		List<CCVConditionBO> conditionsInSet = new ArrayList<CCVConditionBO>();

		for (CcvConditionSetVO conditionSetVO : listOfConditionSetVOs) {
			if (conditionSet == conditionSetVO.getConditionSet()) {
				for (CCVConditionBO condition : conditions) {
					if (condition.getConditionId() == conditionSetVO.getConditionId()) {
						conditionsInSet.add(condition);
					}
				}
			}
		}

		return conditionsInSet;
	}

	/**
	 * @param dataTranslations
	 * @return
	 */
	public static List<CCVXPathBO> getXPathsToTranslate(final List<CCVDataTranslationBO> dataTranslations) {
		logger.debug("Entered getXPathsToTranslate() method of NormalizerUtil class");
		List<CCVXPathBO> xpathsToTranslate = new ArrayList<CCVXPathBO>();

		for (CCVDataTranslationBO dataTranslation : dataTranslations) {
			CCVXPathBO xpathToTranslate = dataTranslation.getXpath();
			if (!xpathsToTranslate.contains(xpathToTranslate)) {
				xpathsToTranslate.add(xpathToTranslate);
			}
		}

		return xpathsToTranslate;
	}

	/**
	 * @param dataTranslations
	 * @param xPath
	 * @return
	 */
	public static List<CCVDataTranslationBO> getDataTranslationsForXPath(final List<CCVDataTranslationBO> dataTranslations,
			final CCVXPathBO xPath) {
		logger.debug("Entered getDataTranslationsForXPath() method of NormalizerUtil class {}", xPath);
		List<CCVDataTranslationBO> dataTranslationsForXPath = new ArrayList<CCVDataTranslationBO>();

		for (CCVDataTranslationBO dataTranslation : dataTranslations) {
			if (dataTranslation.getXpath().getXpathId() == xPath.getXpathId()) {
				dataTranslationsForXPath.add(dataTranslation);
			}
		}

		return dataTranslationsForXPath;
	}

	/**
	 * @param dataExceptions
	 * @param xPath
	 * @return
	 */
	public static List<CCVDataExceptionBO> getDataExceptionsForXPath(final List<CCVDataExceptionBO> dataExceptions,
			final CCVXPathBO xPath) {
		logger.debug("Entered getDataExceptionsForXPath() method of NormalizerUtil class {}", xPath);
		if (null == dataExceptions || dataExceptions.isEmpty()) {
			return new ArrayList<CCVDataExceptionBO>();
		}

		List<CCVDataExceptionBO> dataExceptionsForXPath = new ArrayList<CCVDataExceptionBO>();

		for (CCVDataExceptionBO dataException : dataExceptions) {
			if (dataException.getXpath().getXpathId() == xPath.getXpathId()) {
				dataExceptionsForXPath.add(dataException);
			}
		}

		return dataExceptionsForXPath;
	}

	/**
	 * @param condition
	 * @param ecinValueIn
	 * @return
	 */
	public static boolean evaluateCondition(final CCVConditionBO condition, final String ecinValueIn) {
		logger.debug("Entered evaluateCondition() method of NormalizerUtil class {}, {} ", condition, ecinValueIn);
		String ecinValue = StringUtils.isEmpty(ecinValueIn) ? ecinValueIn : ecinValueIn.toLowerCase();
		String conditionValue = condition.getValue().toLowerCase();

		if (condition.getOperation().equalsIgnoreCase(Constants.CONTAINS_CONDITION)) {
			if (ecinValue.contains(conditionValue)) {
				return true;
			} else {
				return false;
			}
		} else if (condition.getOperation().equalsIgnoreCase(Constants.NOT_CONTAINS_CONDITIONS)) {
			if (!ecinValue.contains(conditionValue)) {
				return true;
			} else {
				return false;
			}
		} else if (condition.getOperation().equalsIgnoreCase(Constants.STARTS_WITH_CONDITION)) {
			if (ecinValue.startsWith(conditionValue)) {
				return true;
			} else {
				return false;
			}
		} else if (condition.getOperation().equalsIgnoreCase(Constants.NOT_STARTS_WITH_CONDITION)) {
			if (!ecinValue.startsWith(conditionValue)) {
				return true;
			} else {
				return false;
			}
		} else if (condition.getOperation().equalsIgnoreCase(Constants.EQUALS_CONDITION)) {
			if (ecinValue.equalsIgnoreCase(conditionValue)) {
				return true;
			} else {
				return false;
			}
		} else if (condition.getOperation().equalsIgnoreCase(Constants.NOT_EQUALS_CONDITION)) {
			if (!ecinValue.equalsIgnoreCase(conditionValue)) {
				return true;
			} else {
				return false;
			}
		}

		logger.error(
				"The specified operation {} for conditionId {} is not valid.  Change this condition in the database with a valid one.",
				condition.getOperation(), condition.getConditionId());
		return false;
	}

	/**
	 * @param inputXml
	 * @param xpathOfInnerXML
	 * @return
	 * @throws Exception
	 */
	public static String getXMLFromXPath(final String inputXml, final String xpathOfInnerXML) throws Exception {
		logger.debug("Entered getXMLFromXPath() method of NormalizerUtil class");
		DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document outerXML = docBuilder.parse(new InputSource(new StringReader(inputXml)));
		outerXML.getDocumentElement().normalize();
		Document innerXML = getInnerXMLDocument(xpathOfInnerXML, outerXML);
		String innerXMLString = NormalizerUtil.getStringFromDocument(innerXML);
		innerXMLString = removeXmlDeclaration(
				innerXMLString.replace("\r", "").replace("\n", "").replace("\t", "").trim());
		return innerXMLString;
	}

	/**
	 * @param xpathOfInnerXML
	 * @param outerXML
	 * @return
	 * @throws ParserConfigurationException
	 * @throws XPathExpressionException
	 */
	public static Document getInnerXMLDocument(final String xpathOfInnerXML, final Document outerXML)
			throws ParserConfigurationException, XPathExpressionException {
		logger.debug("Entered getInnerXMLDocument() method of NormalizerUtil class");
		Document innerXML = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		NodeList childNodesOfOuterXML = NormalizerUtil.getNodeListFromXML(outerXML, xpathOfInnerXML);
		if (null != innerXML && null != childNodesOfOuterXML && childNodesOfOuterXML.getLength() > 0) {
			innerXML.appendChild(innerXML.importNode(childNodesOfOuterXML.item(0), true));
		}
		return innerXML;
	}

	/**
	 * @param xml
	 * @return
	 */
	public static String removeXmlDeclaration(String xml) {
		logger.debug("Entered removeXmlDeclaration() method of NormalizerUtil class");
		if (null != xml) {
			xml = xml.trim();
			if (xml.startsWith("<?xml")) {
				int location = xml.indexOf("?>");
				return xml.substring(location + 2);
			}
		}
		return xml;
	}

	/**
	 * @param doc
	 * @param xPath
	 * @return
	 * @throws XPathExpressionException
	 */
	public static NodeList getNodeListFromXML(final Document doc, final String xPath) throws XPathExpressionException {
		logger.debug("Entered getNodeListFromXML() method of NormalizerUtil class {}", xPath);
		XPathFactory factory = XPathFactory.newInstance();
		XPath xPathObj = factory.newXPath();
		XPathExpression expr = xPathObj.compile("/" + xPath);
		return (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
	}

	/**
	 * @param childNodes
	 * @param dataExceptions
	 * @return
	 */
	public static boolean isNodeListExempt(final NodeList childNodes, final List<CCVDataExceptionBO> dataExceptions) {
		logger.debug("Entered isNodeListExempt()  method of NormalizerUtil class {}", childNodes);
		if (null != dataExceptions && !dataExceptions.isEmpty()) {
			// Loop over child nodes
			for (int i = 0; i < childNodes.getLength(); i++) {
				// Assign the node an object
				Node childNode = childNodes.item(i);

				if (isValidNode(childNode)) {
					String nodeName = childNode.getNodeName();
					String nodeValue = childNode.getTextContent();

					// Loop over exceptions
					for (CCVDataExceptionBO dataException : dataExceptions) {
						String exemptNode = dataException.getChild();
						String exemptNodeValue = dataException.getChildValue();

						// If a match is found, the child nodeList is send as received (don't translate)
						if (nodeName.equalsIgnoreCase(exemptNode) && nodeValue.equalsIgnoreCase(exemptNodeValue)) {
							return true;
						}
					}
				}
			}
		}

		return false;
	}

	/**
	 * @param doc
	 * @return
	 */
	public static String getStringFromDocument(Document doc) {
		logger.debug("Entered getStringFromDocument() method of NormalizerUtil class");
		try {
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
					org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
			Transformer transformer = tf.newTransformer();
			try {
				transformer.setOutputProperty(OutputKeys.ENCODING, doc.getXmlEncoding());
			} catch (Exception e) {
				logger.debug("Error setting XML encoding type.");
			}
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (TransformerException ex) {
			logger.error("Exception in FrontEndPCCXmlParserImpl.getStringFromDocument()", ex);
			return null;
		}
	}

	/**
	 * @param dataTranslationsDB
	 * @return
	 */
	public static boolean isValidTranslationData(List<CcvDataTranslationVO> dataTranslationsDB) {
		logger.debug("Entered isValidTranslationData() method of NormalizerUtil class");
		if (null != dataTranslationsDB && !dataTranslationsDB.isEmpty()) {
			return true;
		}

		return false;
	}

	/**
	 * @param nodes
	 * @return
	 */
	public static boolean isValidNodeList(NodeList nodes) {
		logger.debug("Entered isValidNodeList() method of NormalizerUtil class");
		if (null != nodes && nodes.getLength() > 0) {
			return true;
		}

		return false;
	}

	/**
	 * @param node
	 * @return
	 */
	public static boolean isValidNode(Node node) {
		logger.debug("Entered isValidNode() method of NormalizerUtil class");
		if (null != node && node.getNodeType() == Node.ELEMENT_NODE) {
			return true;
		}

		return false;
	}

	/**
	 * @param condition
	 * @return
	 */
	public static boolean isRepeatableElement(final CCVConditionBO condition) {
		logger.debug("Entered isRepeatableElement() method of NormalizerUtil class");
		if (null != condition && null != condition.getXpath().getParentXpath()) {
			return true;
		}

		return false;
	}
}