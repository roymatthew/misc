package com.ode.cv.normalizer.util;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.ode.cv.normalizer.bo.CCVConditionBO;
import com.ode.cv.normalizer.bo.CCVDataExceptionBO;
import com.ode.cv.normalizer.bo.CCVDataTranslationBO;
import com.ode.cv.normalizer.bo.CCVXPathBO;
import com.ode.cv.vo.CcvInputVO;

@Component
public class XmlNormalizer {

	private static final Logger logger = LogManager.getLogger(XmlNormalizer.class);
	private HashMap<CCVXPathBO, String> nodeCache = new HashMap<CCVXPathBO, String>();
	private HashMap<String, String> childLogger = new HashMap<String, String>();
	private Document ecinDoc;

	/**
	 * @param ecinXML
	 * @param ccvInputVO
	 * @return
	 */
	public String normalizeEcin(final String ecinXML, final CcvInputVO ccvInputVO) {
		logger.debug("Entered normalizeEcin() method of XmlNormalizer class. CcvInputVO: {}", ccvInputVO);
		nodeCache.clear();
		childLogger.clear();
		if (NormalizerUtil.isValidTranslationData(ccvInputVO.getListOfDataTranslations())) {
			logger.debug("Translations found, begin processing.");
			List<CCVDataTranslationBO> dataTranslations = DataTranslationMapper.mapDataTranslations(ccvInputVO);
			List<CCVDataExceptionBO> dataExceptions = DataTranslationMapper.mapDataExceptions(ccvInputVO);
			List<CCVXPathBO> xPathsToTranslate = NormalizerUtil.getXPathsToTranslate(dataTranslations);
			String normaizedEcin = null;

			try {
				DocumentBuilder docBuilder;
				InputSource inputSource = new InputSource(new StringReader(ecinXML));
				docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				ecinDoc = docBuilder.parse(inputSource);

				for (CCVXPathBO xPathToTranslate : xPathsToTranslate) // Loop through the xpath mappings from the
																		// XPathMap table
				{
					processXPath(xPathToTranslate, dataTranslations, dataExceptions);
				}
				normaizedEcin = NormalizerUtil.getStringFromDocument(ecinDoc);
				ccvInputVO.setEcTransXML(normaizedEcin);
				logger.debug("Translation processing complete.");
				return normaizedEcin;
			} catch (Throwable e) {
				logger.error("error generating ECTRANS", e);
			}
		}

		return ecinXML;
	}

	/**
	 * @param xPathToTranslate
	 * @param dataTranslations
	 * @param dataExceptions
	 * @throws Exception
	 */
	private void processXPath(final CCVXPathBO xPathToTranslate, final List<CCVDataTranslationBO> dataTranslations,
			final List<CCVDataExceptionBO> dataExceptions) throws Exception {
		logger.debug("Entered processXPath() method of XmlNormalizer class, {}", xPathToTranslate);
		String xPathValue = xPathToTranslate.getXpath();

		// Grab the nodes from the XML with the current tag (ServiceContract, Insurance,
		// etc...)
		NodeList parentNodes = NormalizerUtil.getNodeListFromXML(ecinDoc, xPathValue);

		List<CCVDataTranslationBO> dataTranslationsForXPath = NormalizerUtil
				.getDataTranslationsForXPath(dataTranslations, xPathToTranslate);
		List<CCVDataExceptionBO> dataExceptionsForXPath = NormalizerUtil.getDataExceptionsForXPath(dataExceptions,
				xPathToTranslate);

		if (NormalizerUtil.isValidNodeList(parentNodes)) {
			for (int i = 0; i < parentNodes.getLength(); i++) // Looping over parent nodes (ServiceContract, Insurance,
																// etc...)
			{
				// Separate the parent node from the list.
				// Don't use NodeList childNodes = parentNodes.item(i).getChildNodes();
				Node parentNode = parentNodes.item(i);
				processParentNode(parentNode, dataTranslationsForXPath, dataExceptionsForXPath);
			}
		}
		logger.debug("Exit processXpath() method " + xPathValue);
	}

	/**
	 * @param parentNode
	 * @param dataTranslationsForXPath
	 * @param dataExceptionsForXPath
	 * @throws Exception
	 */
	private void processParentNode(final Node parentNode, final List<CCVDataTranslationBO> dataTranslationsForXPath,
			final List<CCVDataExceptionBO> dataExceptionsForXPath) throws Exception {
		logger.debug("Entered processParentNode() method of XmlNormalizer class. {}", parentNode);
		// Grab the child nodes from the parent (InsuranceType, InsuranceName, etc...)
		NodeList childNodes = parentNode.getChildNodes();
		CCVDataTranslationBO translation = null;

		// Null check and exception check child nodes
		if (NormalizerUtil.isValidNodeList(childNodes)
				&& !NormalizerUtil.isNodeListExempt(childNodes, dataExceptionsForXPath)) {
			// Loop through the child nodes for any applicable translations.
			translation = getTranslation(childNodes, dataTranslationsForXPath);
		}

		if (null != translation) // If a translation for a value exists, apply it
		{
			boolean targetElementExists = applyTranslation(childNodes, translation);

			if (targetElementExists) {
				logger.debug("Translation executed: translationId = {}, node = {}, value = {}.",
						translation.getTranslationId(), translation.getTranslateToElement().getXpathKey(),
						translation.getTranslateToValue());
			} else {
				logger.warn(
						"Unable to apply Translation - target element doesn't exist: translationId = {}, node = {}, value = ",
						translation.getTranslationId(), translation.getTranslateToElement().getXpathKey(),
						translation.getTranslateToValue());
			}
		}

	}

	/**
	 * @param childNodes
	 * @param translation
	 * @return
	 */
	private boolean applyTranslation(final NodeList childNodes, final CCVDataTranslationBO translation) {
		logger.debug("Entered applyTranslation() method of XmlNormalizer class. {}", translation);
		for (int j = 0; j < childNodes.getLength(); j++) {
			Node outNode = childNodes.item(j);
			if (NormalizerUtil.isValidNode(outNode)) {
				String outNodeName = outNode.getNodeName().toString();
				// Find the output node in the list of child nodes
				// When we have a match, save the translateTo value to the node
				if (outNodeName.equalsIgnoreCase(translation.getTranslateToElement().getXpathKey())) {
					outNode.setTextContent(translation.getTranslateToValue());
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Returns a Translation object that contains the destination node and the data
	 * for it. Searches any child nodes for data that needs to be translated.
	 * 
	 * @param childNodes
	 * @param dataTranslations
	 * @return translation
	 */
	private CCVDataTranslationBO getTranslation(final NodeList childNodes, final List<CCVDataTranslationBO> dataTranslations)
			throws Exception {
		logger.debug("Entered getTranslation() method of XmlNormalizer class.");
		// Since the dataTranslations list is ordered, we loop through it first.
		// For each ordered translation item, we loop through every child node.
		// The first match made will always be the highest priority translation, so we
		// need not make a direct comparison on the order.
		// ChildNodes = InsuranceType, InsuranceName, etc....
		for (CCVDataTranslationBO dataTranslation : dataTranslations) {
			if (evaluateConditions(dataTranslation, childNodes)) // Check to see if the translation has passed.
			{
				// If the translation hasn't been disqualified, it's sent off to be applied to
				// the node.
				logger.debug("Data translation found: TranslationId={}, ConditionSet={}",
						dataTranslation.getTranslationId(), dataTranslation.getConditionSet());
				logger.debug("XML Data used for Condition matching: {}", childLogger.toString());
				logger.debug("Conditions: {}", dataTranslation.getConditions().toString());

				return dataTranslation;
			}
		}

		return null;
	}

	/**
	 * @param dataTranslation
	 * @param childNodes
	 * @return
	 * @throws Exception
	 */
	private boolean evaluateConditions(CCVDataTranslationBO dataTranslation, NodeList childNodes) throws Exception {
		logger.debug("Entered evaluateConditions() method of XmlNormalizer class. {}, {}", dataTranslation, childNodes);
		for (CCVConditionBO condition : dataTranslation.getConditions()) // Loop through conditions
		{
			// REPEATABLE ELEMENT (DealerProductsPaidFor, DealerProductsType, etc...)
			// The node is inside the list of childNodes
			if (NormalizerUtil.isRepeatableElement(condition)) {
				if (!evaluateRepeatableElement(condition, childNodes)) {
					return false;
				}
			}
			// NON-REPEATABLE ELEMENT (ContractExecutionState, FinanceType, etc...)
			else // The parent XPath is null, we need to do a lookup outside the parentNode for
					// the node
			{
				if (!evaluateNonRepeatableElement(condition)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * @param condition
	 * @return
	 * @throws Exception
	 */
	private boolean evaluateNonRepeatableElement(final CCVConditionBO condition) throws Exception {
		logger.debug("Entered evaluateNonRepeatableElement() method of XmlNormalizer class. {}", condition);
		String xmlValue = "";
		if (nodeCache.containsKey(condition.getXpath())) // Check the cache for the xpath first
		{
			xmlValue = nodeCache.get(condition.getXpath()); // If found, grab the value from cache
		} else // If not in cache, evaluate ecin for node
		{
			String xPath = condition.getXpath().getXpath() + "/" + condition.getXpath().getXpathKey();
			NodeList nodes = NormalizerUtil.getNodeListFromXML(ecinDoc, xPath);
			if (NormalizerUtil.isValidNodeList(nodes)) {
				for (int i = 0; i < nodes.getLength(); i++) {
					Node node = nodes.item(i);
					if (NormalizerUtil.isValidNode(node)
							&& node.getNodeName().equalsIgnoreCase(condition.getXpath().getXpathKey())) {
						xmlValue = node.getTextContent();
						logger.debug("Adding XPath:Value to cache: {}, {}", condition.getXpath(), xmlValue);
						nodeCache.put(condition.getXpath(), xmlValue); // Add the xpath - value combination to cache
						break;
					}
				}
			}
		}

		if (!evaluateCondition(condition, xmlValue)) {
			return false;
		}

		return true;
	}

	/**
	 * @param condition
	 * @param childNodes
	 * @return
	 */
	private boolean evaluateRepeatableElement(final CCVConditionBO condition, final NodeList childNodes) {
		logger.debug("Entered evaluateRepeatableElement() method of XmlNormalizer class. {}, {}", condition, childNodes);

		boolean nodeExistsInXML = false;
		for (int i = 0; i < childNodes.getLength(); i++) // Loop over child nodes
		{
			Node inNode = childNodes.item(i); // Assign the node an object
			if (NormalizerUtil.isValidNode(inNode)) {
				String nodeName = inNode.getNodeName(); // Get the node name from the node object
				if (condition.getXpath().getXpathKey().equalsIgnoreCase(nodeName)) // If there's a match on the node
																					// name in the condition
				{
					nodeExistsInXML = true;
					String nodeValue = inNode.getTextContent();

					if (!evaluateCondition(condition, nodeValue)) {
						return false;
					}
				}
			}
		}

		if (!nodeExistsInXML) {
			logger.debug("Expected node {} not found in XML", condition.getXpath().getXpathKey());
			return false;
		}

		return true;
	}

	/**
	 * @param condition
	 * @param value
	 * @return
	 */
	private boolean evaluateCondition(final CCVConditionBO condition, final String value) {
		logger.debug("Entered evaluateCondition() method of XmlNormalizer class. {}, {}", condition, value);
		if (!NormalizerUtil.evaluateCondition(condition, value)) {
			childLogger = new HashMap<String, String>();
			return false;
		}
		childLogger.put(condition.getXpath().getXpathKey(), value);
		return true;
	}
}