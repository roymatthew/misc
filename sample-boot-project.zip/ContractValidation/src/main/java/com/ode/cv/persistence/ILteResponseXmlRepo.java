/**
 * 
 */
package com.ode.cv.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author rmathew
 *
 */
public interface ILteResponseXmlRepo extends JpaRepository<LteResponseXml, Integer> {

}
