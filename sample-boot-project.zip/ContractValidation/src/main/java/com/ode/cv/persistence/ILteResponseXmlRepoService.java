/**
 * 
 */
package com.ode.cv.persistence;

import com.ode.cv.vo.LteResponseXmlVO;

/**
 * @author rmathew
 *
 */
public interface ILteResponseXmlRepoService {
	
	LteResponseXmlVO getByXmlId(final Integer xmlId);

}
