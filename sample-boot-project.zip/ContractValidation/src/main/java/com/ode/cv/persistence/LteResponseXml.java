package com.ode.cv.persistence;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rmathew
 *
 */
@Entity
@Table(name = "[ResponseXML]")
public class LteResponseXml implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3018097777520450289L;
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "XMLID")
	private Integer xmlId;
	@Column(name = "LTE_OUTPUT")
	private String lteOutputXml;
	@Column(name = "ACCR_XML")
	private String accrXml;
	@Column(name = "CreatedDate")
	private Timestamp createdDate;
	public Integer getXmlId() {
		return xmlId;
	}
	public void setXmlId(Integer xmlId) {
		this.xmlId = xmlId;
	}
	public String getLteOutputXml() {
		return lteOutputXml;
	}
	public void setLteOutputXml(String xmlData) {
		this.lteOutputXml = xmlData;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getAccrXml() {
		return accrXml;
	}
	public void setAccrXml(String accrXml) {
		this.accrXml = accrXml;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accrXml == null) ? 0 : accrXml.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((lteOutputXml == null) ? 0 : lteOutputXml.hashCode());
		result = prime * result + ((xmlId == null) ? 0 : xmlId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LteResponseXml other = (LteResponseXml) obj;
		if (accrXml == null) {
			if (other.accrXml != null)
				return false;
		} else if (!accrXml.equals(other.accrXml))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (lteOutputXml == null) {
			if (other.lteOutputXml != null)
				return false;
		} else if (!lteOutputXml.equals(other.lteOutputXml))
			return false;
		if (xmlId == null) {
			if (other.xmlId != null)
				return false;
		} else if (!xmlId.equals(other.xmlId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "LteResponseXml [xmlId=" + xmlId + ", lteOutputXml=" + lteOutputXml + ", accrXml=" + accrXml
				+ ", createdDate=" + createdDate + "]";
	}
	
	
	
	

}
