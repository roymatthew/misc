/**
 * 
 */
package com.ode.cv.persistence;

import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.cv.service.RouteOneServiceImpl;
import com.ode.cv.vo.LteResponseXmlVO;

/**
 * @author rmathew
 *
 */
@Service
public class LteResponseXmlRepoServiceImpl implements ILteResponseXmlRepoService {
	
	private static final Logger logger = LogManager.getLogger(RouteOneServiceImpl.class);
	
	@Autowired
	private ILteResponseXmlRepo iLteResponseXmlRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public LteResponseXmlVO getByXmlId(final Integer xmlId) {
		logger.debug("Entered getByXmlId in LteResponseXmlRepoServiceImpl : " + xmlId);
		
		Optional<LteResponseXml> lteResponseXml = iLteResponseXmlRepo.findById(xmlId);
		if (lteResponseXml.isPresent())
		{
			return modelMapper.map(lteResponseXml.get(), LteResponseXmlVO.class);
		}
		return null;
	}

}
