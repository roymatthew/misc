package com.ode.cv.rest.api;

import com.ode.cv.service.IAccrService;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.vo.AccrVO;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Profile({"dev", "qa", "stage", "prod"})
@RestController
public class ContractValidationResponseController {

	private static final Logger logger = LogManager.getLogger(ContractValidationResponseController.class);

	@Autowired
	private IAccrService accrService;

	@Autowired
	private PCCXmlParser pccXmlParser;

	@Autowired
	private CVResponseXMLParser cvResponseXmlParser;

	/**
	 * @param requestXML
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/processResponse", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> processCVResponse(@RequestBody String requestXML) throws Exception {
		ThreadContext.put("uuid", UUID.randomUUID().toString());
		logger.debug("Entered processCVResponse() method of ContractValidationResponseController class");
		logger.debug("processCVResponse requestXML: {}", requestXML.replaceAll("[\r\n]+", " "));

		long startTime = System.nanoTime();
		AccrVO accrVO = new AccrVO();
		String requestWithoutSchemaPrefix = cvResponseXmlParser.removeSchemaPrefixIfAny(requestXML);
		String senderNameCode = pccXmlParser.getSenderNameCode(requestWithoutSchemaPrefix);
		accrVO.setSenderNameCode(senderNameCode);
		logger.debug("senderNameCode accrVO: {}", senderNameCode);

		try {
			accrVO.setAccrRequestXml(requestXML);
			if (Constants.DESTINATION_CODE_ROUTE_ONE.equalsIgnoreCase(senderNameCode)) {
				logger.debug("Processing ACCR from RouteONE");
				accrVO = accrService.processAccrFromRouteOne(accrVO);
			} else {
				logger.debug("Processing Response from Lender");
				accrVO = accrService.processAsyncResponseFromLender(requestXML);
			}

			logger.debug("Response from service: {}", accrVO.getResponseMessage());
			long endTime = System.nanoTime();
			logger.debug("processCVResponse Execution time: " + (endTime - startTime) / 1000000 + " ms");
		} catch (final Exception e) {
			logger.debug("Exception processing CV Response from Lender.", e);
			throw e;
		} finally {
			ThreadContext.clearAll();
		}
		return new ResponseEntity<String>(accrVO.getResponseMessage(), HttpStatus.OK);
	}
}
