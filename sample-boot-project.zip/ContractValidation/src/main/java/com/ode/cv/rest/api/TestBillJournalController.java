package com.ode.cv.rest.api;

import java.math.BigInteger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ode.persistence.entity.BillJournal;
import com.ode.persistence.service.BillJournalRepoService;
import com.ode.persistence.service.DeContractValidationRepoService;
import com.ode.persistence.vo.BillJournalVO;
import com.ode.persistence.vo.DeContractValidationVO;


/**
 * @author rmathew
 * ***********This class is written for testing purposes only**************
 *
 */
@Controller
public class TestBillJournalController {
	
	private static final Logger log = LogManager.getLogger(TestBillJournalController.class);
	
	@Value("${spring.profiles.active}")
	private String activeProfle;
	@Value("${destination.queue.jndi-name}")
	private String activeMqJndiName;
	@Value("${destination.queue.name}")
	private String activeMqQName;
	@Value("${spring.datasource.password}")
	private String dbPassword;
	

	@Autowired
	private BillJournalRepoService billJournalRepositoryService;
	
	@Autowired
	private DeContractValidationRepoService deContractValidationRepoService;
	
	@GetMapping(value="/billjournal/billid/{billId}")
	@ResponseBody
	public ResponseEntity<BillJournalVO> getBillJournal(@PathVariable final BigInteger billId) throws Exception
	{
		log.debug("Enter getBillJournal");
		log.debug("Current Spring active profile:" + activeProfle);
		BillJournalVO billJournalVO =  billJournalRepositoryService.getByBillId(billId);
		return new ResponseEntity<BillJournalVO>(billJournalVO, HttpStatus.OK);
		
	}
	
	@GetMapping(value="/cv/dealId/{dealId}/sequenceId/{sequenceId}")
	@ResponseBody
	public ResponseEntity<DeContractValidationVO> getDeContractValidation(@PathVariable final String dealId, @PathVariable final String sequenceId) throws Exception
	{
		log.debug("Enter getDeContractValidation method of TestBillJournalController class");
		log.debug("Current Spring active profile:" + activeProfle);
		DeContractValidationVO  deContractValidationVO =  deContractValidationRepoService.selectDeContractValidation(dealId, sequenceId);
		return new ResponseEntity<DeContractValidationVO>(deContractValidationVO, HttpStatus.OK);
		
	}

}
