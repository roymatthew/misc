package com.ode.cv.rest.api;

import javax.jms.JMSException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ode.cv.messaging.CVMessageProducer;
import com.ode.cv.messaging.CdkCloudResponseMessageProducer;
import com.ode.cv.service.ICdkCloudService;

@RestController
@Profile({"dev", "qa", "stage", "prod"})
public class TestJmsController {
	
	private static final Logger log = LogManager.getLogger(TestJmsController.class);
	
	@Autowired
	private CVMessageProducer messageProducer;
	
	@Autowired
	private CdkCloudResponseMessageProducer cdkCloudResponseMessageProducer;
	
	@Autowired
	private ICdkCloudService cdkCloudService;
	
	@PutMapping(value = "/add/message")
	public void writeMessageToQueue(@RequestBody final String message) throws JMSException
	{
		log.debug("Enter writeMessageToQueue");
		messageProducer.sendMessage(message);
	}
	
	@PutMapping(value = "/add/respQMessage")
	public void writeMessageToRespQueue(@RequestBody final String message) throws JMSException
	{
		log.debug("Enter writeMessageToRespQueue");
		cdkCloudResponseMessageProducer.sendMessage(message);
	}
	
	@PutMapping(value = "/add/processRespQ")
	public void processRespQ(@RequestBody final String message)
	{
		log.debug("Enter processRespQ");
		cdkCloudService.processCdkCloudJsonResponse(message);
	}
}
