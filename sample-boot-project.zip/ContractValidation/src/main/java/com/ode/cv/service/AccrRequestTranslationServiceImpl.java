package com.ode.cv.service;

import com.ode.cv.util.ApplpTransformer;
import com.ode.cv.util.Constants;
import com.ode.cv.util.LpTransformerTemplateFactory;
import com.ode.cv.util.RFLUtil;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import javax.xml.transform.Transformer;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import com.ode.persistence.entity.DeDmsDestination;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Service
public class AccrRequestTranslationServiceImpl extends ApplpTransformer
implements IAccrRequestTranslationService, Constants {

	private static final Logger logger = LogManager.getLogger(AccrRequestTranslationServiceImpl.class);

	private final static String XML_START = "<data>";
	private final static String XML_END = "</data>";

	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;

	@Autowired
	private RFLUtil rflUtil;

	@Autowired
	CVTransmitClient cvTransmitClient;

	@Autowired
	private LpTransformerTemplateFactory appXSLFactory;

	@Override
	public void createDMSOut(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO,
			final String stylesheetId) throws Exception {

		final LocalDateTime start = LocalDateTime.now();
		logger.debug("Entered createDMSOut() method of AccrRequestTranslationServiceImpl class");

		if (null != cvTransmitVO.getAccrResponseXml()) {
			logger.debug("cvTransmitVO.getAccrResponseXml() before getting xpath clob: {}",
					cvTransmitVO.getAccrResponseXml());
			getXpathValuefromCLOB(creditContractVO, cvTransmitVO);
		}

		// process RFL and vault accept/reject
		if (creditContractVO.getAccr().getValidationResults() != null
				&& (creditContractVO.getAccr().getValidationResults().equals(Constants.VALID)
						|| creditContractVO.getAccr().getValidationResults().equals(Constants.PASSED))
				&& (productConfigurationLookupService.isRFLFeatureEnabled()
						|| Constants.ADVENT_DMS_ID.equals(cvTransmitVO.getDealerInfoVO().getDspId()))) {

			rflUtil.processRflInAccr(cvTransmitVO, creditContractVO);
		}

		logger.debug("Trying to obtain transformer to generate ECACKOUT to DMS");

		final Transformer pccrTransformer = getTransformer(stylesheetId);

		if (null != pccrTransformer) {
			logger.debug("Transformer for ACCR/ConfirmBOD translation to ECACKOUT is ready");
		}
		pccrTransformer.clearParameters();

		// When DMS=='AD', add these parameters to stylesheet: username, password, locationId, serviceId
		String locationId = "";
		String serviceId = "";
		if (Constants.CDK_DMS_ID.equalsIgnoreCase(cvTransmitVO.getDealVO().getDmsId())) {
			DeDmsDestination deDmsDestination = productConfigurationLookupService.getDeDmsDestination(
					Constants.CDK_DMS_ID, Constants.APPLICATION_CV, Constants.PRODUCT_CV);
			locationId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
					Constants.CDK_DMS_ID, Constants.ACCR, Constants.LOCATION_ID);
			serviceId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
					Constants.CDK_DMS_ID, Constants.ACCR, Constants.SERVICE_ID);

			pccrTransformer.setParameter("username", null == deDmsDestination || null == deDmsDestination.getWsUsername() ?
					"" : deDmsDestination.getWsUsername());
			pccrTransformer.setParameter("password", null == deDmsDestination || null == deDmsDestination.getWsPassword() ?
					"" : deDmsDestination.getWsPassword());
			pccrTransformer.setParameter("locationId", null == locationId ? "" : locationId);
			pccrTransformer.setParameter("serviceId", null == serviceId ? "" : serviceId);
		}

		pccrTransformer.setParameter("dealerId", creditContractVO.getDealerInfo().getDealerId() == null ? ""
				: creditContractVO.getDealerInfo().getDealerId());
		pccrTransformer.setParameter("lenderId", creditContractVO.getPartnerInfo().getLenderId() == null ? ""
				: creditContractVO.getPartnerInfo().getLenderId());
		pccrTransformer.setParameter("systemId", creditContractVO.getDealerInfo().getSystemId() == null ? ""
				: creditContractVO.getDealerInfo().getSystemId());
		pccrTransformer.setParameter("dmsDealNumber", creditContractVO.getAdpDealNo());

		pccrTransformer.setParameter("dealerPartyId", creditContractVO.getDealerInfo().getDealerPartyId() == null ? ""
				: creditContractVO.getDealerInfo().getDealerPartyId());

		if (creditContractVO.getPartnerInfo().getLenderAccountId() != null) {
			pccrTransformer.setParameter("accountId", creditContractVO.getPartnerInfo().getLenderAccountId());
		} else {
			pccrTransformer.setParameter("accountId", " ");
		}

		String dealerNumber = "";
		String storeNumber = "";
		String senderNameCode = "";
		String referenceId = "";
		String authorizationId = "";
		String contractId = "";
		String contractFormNumber = "";
		String destinationCode = "";
		String documentVersionNumber = "";
		String financeCompanyName = "";
		String dealerName = "";
		String applicationType = "";
		String financeType = "";
		String paymentAmount = "";
		String netAnnualPercentageRate = "";
		String bodId = "";

		if (null != creditContractVO.getAccr()) {
			dealerNumber = StringUtils.isBlank(creditContractVO.getAccr().getDealerNumber()) ? ""
					: creditContractVO.getAccr().getDealerNumber();
			storeNumber = StringUtils.isBlank(creditContractVO.getAccr().getStoreNumber()) ? ""
					: creditContractVO.getAccr().getStoreNumber();
			senderNameCode = StringUtils.isBlank(creditContractVO.getAccr().getSenderNameCode()) ? ""
					: creditContractVO.getAccr().getSenderNameCode();
			referenceId = StringUtils.isBlank(creditContractVO.getAccr().getReferenceId()) ? ""
					: creditContractVO.getAccr().getReferenceId();
			authorizationId = StringUtils.isBlank(creditContractVO.getAccr().getAuthorizationId()) ? ""
					: creditContractVO.getAccr().getAuthorizationId();
			contractId = StringUtils.isBlank(creditContractVO.getAccr().getContractId()) ? ""
					: creditContractVO.getAccr().getContractId();
			if (StringUtils.isBlank(contractId))
			{
				contractId = StringUtils.isBlank(creditContractVO.getAccr().getBodId()) ? ""
						: creditContractVO.getAccr().getBodId();
			}
			contractFormNumber = StringUtils.isBlank(creditContractVO.getAccr().getContractFormNumber()) ? ""
					: creditContractVO.getAccr().getContractFormNumber();
			destinationCode = StringUtils.isBlank(creditContractVO.getAccr().getDestinationCode()) ? ""
					: creditContractVO.getAccr().getDestinationCode();
			documentVersionNumber = StringUtils.isBlank(creditContractVO.getAccr().getDocumentVersionNumber()) ? ""
					: creditContractVO.getAccr().getDocumentVersionNumber();
			financeCompanyName = StringUtils.isBlank(creditContractVO.getAccr().getFinanceCompanyName()) ? ""
					: creditContractVO.getAccr().getFinanceCompanyName();
			dealerName = StringUtils.isBlank(creditContractVO.getAccr().getDealerName()) ? ""
					: creditContractVO.getAccr().getDealerName();
			applicationType = StringUtils.isBlank(creditContractVO.getAccr().getApplicationType()) ? ""
					: creditContractVO.getAccr().getApplicationType();
			financeType = StringUtils.isBlank(creditContractVO.getAccr().getFinanceType()) ? ""
					: creditContractVO.getAccr().getFinanceType();
			paymentAmount = StringUtils.isBlank(creditContractVO.getAccr().getPaymentAmount()) ? ""
					: creditContractVO.getAccr().getPaymentAmount();
			netAnnualPercentageRate = StringUtils.isBlank(creditContractVO.getAccr().getNetAnnualPercentageRate()) ? ""
					: creditContractVO.getAccr().getNetAnnualPercentageRate();
			bodId = StringUtils.isBlank(creditContractVO.getAccr().getBodId()) ? ""
					: creditContractVO.getAccr().getBodId();
		}

		pccrTransformer.setParameter("dealerNumber", dealerNumber);
		pccrTransformer.setParameter("storeNumber", storeNumber);
		pccrTransformer.setParameter("senderNameCode", senderNameCode);
		pccrTransformer.setParameter("referenceId", referenceId);
		pccrTransformer.setParameter("authorizationId", authorizationId);
		pccrTransformer.setParameter("contractId", contractId);
		pccrTransformer.setParameter("contractFormNumber", contractFormNumber);
		pccrTransformer.setParameter("destinationCode", destinationCode);
		pccrTransformer.setParameter("documentVersionNumber", documentVersionNumber);
		pccrTransformer.setParameter("financeCompanyName", financeCompanyName);
		pccrTransformer.setParameter("dealerName", dealerName);
		pccrTransformer.setParameter("applicationType", applicationType);
		pccrTransformer.setParameter("financeType", financeType);
		pccrTransformer.setParameter("paymentAmount", paymentAmount);
		pccrTransformer.setParameter("netAnnualPercentageRate", netAnnualPercentageRate);
		pccrTransformer.setParameter("bodId", bodId);
		// use bodId for documentId
		pccrTransformer.setParameter("documentId", bodId);
		logger.debug(
				"From createDMSOut() method. dealerNumber: {}, storeNumber: {}, referenceId: {}, authorizationId: {}, contractId: {}, contractFormNumber: {}, "
						+ "destinationCode: {}, documentVersionNumber: {}, financeCompanyName: {}, dealerName: {}, applicationType: {}, financeType: {}, " 
						+ "paymentAmount: {}, netAnnualPercentageRate: {}, locationId: {}, serviceId: {}",
						dealerNumber, storeNumber, referenceId, authorizationId, contractId, contractFormNumber,
						destinationCode, documentVersionNumber, financeCompanyName, dealerName, applicationType, financeType,
						paymentAmount, netAnnualPercentageRate, locationId, serviceId);

		if (creditContractVO.getAppMsg() != null) {
			pccrTransformer.setParameter("errorCode", creditContractVO.getAppMsg().getMessageID());
			pccrTransformer.setParameter("errorMessage",
					creditContractVO.getAppMsg().getMessage() != null ? creditContractVO.getAppMsg().getMessage()
							: "Message sent to Lender");
		} else {
			pccrTransformer.setParameter("errorCode", "Unknown");
			pccrTransformer.setParameter("errorMessage", "Unknown");
		}

		if (creditContractVO.isValidationError()) {
			pccrTransformer.setParameter("validationMessage", creditContractVO.getValMessageDesc());
			pccrTransformer.setParameter("validationMessageCode", creditContractVO.getValMessageCode());
		}

		pccrTransformer.setParameter("dateTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date()));

		StringWriter strWriter = new StringWriter();
		StreamResult streamResult = new StreamResult(strWriter);
		pccrTransformer.transform(new StreamSource(new ByteArrayInputStream(getXmlData(cvTransmitVO).getBytes())),
				streamResult);

		String dmsOutXml = strWriter.toString();

		if (null != dmsOutXml) {
			logger.debug("ACCR/ConfirmBOD Traslation completed. dmsOutXml ==> " + dmsOutXml);
		}
		cvTransmitVO.setAccroutXml(dmsOutXml);
		creditContractVO.setAccroutXml(dmsOutXml);

		final LocalDateTime end = LocalDateTime.now();
		logger.debug("ACCR translation took " + ChronoUnit.MILLIS.between(start, end) + " milliseconds");

	}

	/**
	 * @param stylesheetKey
	 * @return
	 * @throws Exception
	 */
	protected Transformer getTransformer(String stylesheetKey) throws Exception {
		logger.debug("Entered getTransformer of ApplpTransformer class. stylesheetKey: " + stylesheetKey);
		return appXSLFactory.getTransformer(stylesheetKey);
	}

	/**
	 * @param creditContractVO
	 * @throws Exception
	 */
	private void getXpathValuefromCLOB(final CreditContractVO creditContractVO, final CVTransmitVO cvTransmitVO)
			throws Exception {

		logger.debug("Entered getXpathValuefromCLOB() method of AccrRequestTranslationServiceImpl class");
		Document document = getDocument(cvTransmitVO.getAccrResponseXml());
		String xpathPrefix = constantXpath;
		String xPathValidationDescription = "";

		if (productConfigurationLookupService.cvMessageProcessingContainsValue("rules")) {
			xpathPrefix = constantXpath_rules;
		}
		if (XPathAPI.selectSingleNode(document, getXPath_ContractApplicationNumber()) == null) {

			logger.debug("Contract Application Number is null in ACCR.");
			creditContractVO.getAccr().setContractApplicationNumber(
					XPathAPI.eval(document, xpathPrefix + getXPath_ContractApplicationNumber()).toString());
			creditContractVO.getAccr()
			.setFunderComments(XPathAPI.eval(document, xpathPrefix + getXPath_FunderComments()).toString());
			creditContractVO.getAccr()
			.setFundingStatus(XPathAPI.eval(document, xpathPrefix + getXPath_FundingStatus()).toString());
			creditContractVO.getAccr()
			.setSequenceNumber(XPathAPI.eval(document, xpathPrefix + getXPath_DocumentId()).toString());

			NodeList nodeList = XPathAPI.selectNodeList(document, xpathPrefix + getXPath_ValidationDescription());
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if (node.hasChildNodes()) {
					creditContractVO.getAccr()
					.setValidationDescription(creditContractVO.getAccr().getValidationDescription() == null
					? node.getFirstChild().getNodeValue().trim()
							: node.getFirstChild().getNodeValue() + " :: "
							+ creditContractVO.getAccr().getValidationDescription().trim());
				}
			}

			xPathValidationDescription = XPathAPI.eval(document, xpathPrefix + getXPath_ValidationDescription())
					.toString();

		} else {
			creditContractVO.getAccr().setContractApplicationNumber(
					XPathAPI.eval(document, getXPath_ContractApplicationNumber()).toString());
			creditContractVO.getAccr().setFunderComments(XPathAPI.eval(document, getXPath_FunderComments()).toString());
			creditContractVO.getAccr().setSequenceNumber(XPathAPI.eval(document, getXPath_DocumentId()).toString());
			xPathValidationDescription = XPathAPI.eval(document, getXPath_ValidationDescription()).toString();
		}

		if (StringUtils.isNotBlank(xPathValidationDescription)
				&& StringUtils.isBlank(creditContractVO.getAccr().getValidationResults())) {
			creditContractVO.getAccr().setValidationResults(xPathValidationDescription);
		}

		logger.debug("Validation Results from ACCR: {}", creditContractVO.getAccr().getValidationResults());
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private String getXmlData(final CVTransmitVO cvTransmitVO) {

		logger.debug("Entered getXmlData() method of AccrRequestTranslationServiceImpl class");
		String tempXmlData;

		String requestXml = cvTransmitVO.getAccrResponseXml().trim();
		requestXml = requestXml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
		tempXmlData = XML_START;


		// If request is not VOL, remove incoming RFL messages
		if (!requestXml.contains("<SenderNameCode>OD</SenderNameCode>")) {
			requestXml = requestXml.replaceAll("<ValidationMessage>((?!<ValidationMessage).)*<ReferenceName>RFL<\\/ReferenceName>((?!<ValidationMessage).)*<\\/ValidationMessage>", "");
		}


		if (requestXml != null) {
			int start = 0;
			int end = 0;

			// for rules engine response only
			if (requestXml.indexOf("<ns3:AcknowledgeCreditContractResponse") > 0) {
				requestXml = requestXml.replaceAll("<ns3:", "<");
				requestXml = requestXml.replaceAll("</ns3:", "</");
			}

			if (requestXml.indexOf("<AcknowledgeCreditContractResponse") >= 0) {
				start = requestXml.indexOf("<AcknowledgeCreditContractResponse");
				end = requestXml.indexOf("</AcknowledgeCreditContractResponse>") + 36;
			} else if (requestXml.indexOf("<CreditContractResponse") > 0) {
				start = requestXml.indexOf("<CreditContractResponse");
				end = requestXml.indexOf("</CreditContractResponse>") + 25;
			} else if (requestXml.indexOf("<ProcessBDKTransResponse") > 0) {
				start = requestXml.indexOf("<ProcessBDKTransResponse");
				end = requestXml.indexOf("</ProcessBDKTransResponse>") + 26;
			}

			if (start == end) {
				tempXmlData += requestXml;
			} else {
				tempXmlData += requestXml.substring(start, end);
			}

			if (null != cvTransmitVO.getAccrContext() && null != cvTransmitVO.getAccrContext().getFormList()
					&& cvTransmitVO.getAccrContext().getFormList().size() > 0) {
				String formListXml = rflUtil
						.createRFLXmlFromLenderFormsList(cvTransmitVO.getAccrContext().getFormList());
				tempXmlData += formListXml;


			}
		}

		tempXmlData += XML_END;
		tempXmlData = tempXmlData.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
		return tempXmlData;
	}
}
