package com.ode.cv.service;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.persistence.ILteResponseXmlRepoService;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.cv.vo.LteResponseXmlVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.CreditJournalRepoService;
import com.ode.persistence.service.DeContractValidationRepoService;
import com.ode.persistence.service.DeDealRepoService;
import com.ode.persistence.service.DeLenderFeatureRepoService;
import com.ode.persistence.service.DealerPpNvpRepoService;
import com.ode.persistence.service.DealerRepoService;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.DeLenderFeatureVO;
import com.ode.persistence.vo.DeLenderVO;
import com.ode.persistence.vo.DealerPpNvpVO;
import com.ode.persistence.vo.DealerVO;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @author rmathew
 *
 */
@Service
public class AccrServiceImpl implements IAccrService {

	private static final Logger logger = LogManager.getLogger(AccrServiceImpl.class);

	@Autowired
	private IAccrRequestTranslationService accrRequestTranslationService;

	@Autowired
	private CVTransmitClient cvTransmitClient;

	@Autowired
	private ApplpEventHandler applpEventHandler;

	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;

	@Autowired
	private IRouteOneService routeOneService;

	@Autowired
	private ILenderService lenderService;

	@Autowired
	private DeDealRepoService deDealRepoService;

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private CVResponseXMLParser cvResponseXmlParser;

	@Autowired
	private PCCXmlParser pccXmlParser;

	@Autowired
	private ILteResponseXmlRepoService lteResponseXmlRepoService;

	@Autowired
	private IGenerateEformService generateEformService;

	@Autowired
	private ILenderLookupService lenderLookupService;

	@Autowired
	private DealerRepoService dealerRepoService;

	@Autowired
	private DeContractValidationRepoService deContractValidationRepoService;

	@Autowired
	private CreditJournalRepoService creditJournalRepoService;

	@Autowired
	private DeLenderFeatureRepoService deLenderFeatureRepoService;

	@Autowired
	private DealerPpNvpRepoService dealerPpNvpRepoService;

	@Autowired
	private IRflProcessingService rflProcessingService;

	@Autowired
	private ICommonService commonService;

	@Autowired
	private ICdkCloudService cdkCloudService;

	@Autowired
	private ModelMapper modelMapper;
	/**
	 * {@inheritDoc}
	 *
	 * @throws Exception
	 */
	@Override
	public void processAccrFromLTE(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO,
								   final Boolean isStandard) throws Exception {

		logger.debug("Enter processAccrFromLTE() method of AccrServiceImpl class");
		logger.debug(creditContractVO.getDealerInfo());
		logger.debug(creditContractVO.getPartnerInfo());

		// success validation from Rules Engine
		if (HttpStatus.SC_OK == cvTransmitVO.getAccrResponseMessage().getStatusCode()) {
			if (cvTransmitVO.getAccrResponseXml().contains(Constants.CONFIRM_BOD)) {

				logger.debug("$$$$$$ Post CV request to RouteOne starts from here $$$$$$$$$");
				// save ConfirmBOD to CJ to be used when we receive Async ACCR from RouteOne
				AppMessage lteCBODAppMsg = applpEventHandler.handleEvents("Success");
				JournalObjectVO lteCBODJournalObject = JournalFactory.createJournalObject(
						Constants.TRANS_TYPE_LTE_CONFIRM_BOD, lteCBODAppMsg, cvTransmitVO.getAccrResponseXml());
				cvJournalService.addJournal(creditContractVO, lteCBODJournalObject);
				// parse ConfirmBOD and get responseXmlId
				int responseXmlId = pccXmlParser.getResponseXmlId(cvTransmitVO.getAccrResponseXml());
				logger.debug("XmlId returned from LTE: " + responseXmlId);
				String conversationId = pccXmlParser.getRouteOneConversationId(cvTransmitVO.getAccrResponseXml());
				creditContractVO.setConversationId(conversationId);
				// use responseXmlId to fetch translated xml from sqlserver
				LteResponseXmlVO lteResponseXmlVO = lteResponseXmlRepoService.getByXmlId(responseXmlId);
				if (null != lteResponseXmlVO) {
					routeCV(cvTransmitVO, creditContractVO, lteResponseXmlVO, isStandard);
				} else {
					logger.error("Could not find LTE translated xml in database.");
					processNegativeConfirmBOD(cvTransmitVO, creditContractVO);
				}

			} else if (cvTransmitVO.getAccrResponseXml().contains("AcknowledgeCreditContractResponse")) {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document doc = docBuilder.parse(new InputSource(new StringReader(cvTransmitVO.getAccrResponseXml())));
				doc.getDocumentElement().normalize();
				String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
						creditContractVO.getDealerInfo().getDspId(), Constants.ACCR, Constants.STYLESHEET);

				// Failed validation from Rules Engine
				if (null != doc.getElementsByTagName("ns3:AcknowledgeCreditContractResponse")
						&& doc.getElementsByTagName("ns3:AcknowledgeCreditContractResponse").getLength() > 0) {

					// Journal ACKIN from RE
					AppMessage ecAckInAppMsg = applpEventHandler.handleEvents("AppRulesValidationException");
					JournalObjectVO ecAckInJournalObject = JournalFactory.createJournalObject(
							Constants.TRANS_TYPE_EC_ACK_IN, ecAckInAppMsg, cvTransmitVO.getAccrResponseXml());
					creditContractVO.addToListOfJournalObjects(ecAckInJournalObject);
					cvTransmitVO.setAccrContext(creditContractVO.getAccr());
					cvResponseXmlParser.populateDestinationInfoFromEcout(cvTransmitVO);
					cvResponseXmlParser.populateDestinationInfoFromEcin(creditContractVO, cvTransmitVO);
					accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
					// call cvTransmitClient to send Output to DMS
					cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, creditContractVO.getDealerInfo().getDspId());

					// Journal ACKOUT to DMS
					AppMessage ackOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
					JournalObjectVO ackOutJournalObject = JournalFactory.createJournalObject(
							Constants.TRANS_TYPE_EC_ACK_OUT, ackOutAppMsg, cvTransmitVO.getAccroutXml());
					creditContractVO.addToListOfJournalObjects(ackOutJournalObject);

					// Journal ECACKCONFIN from DMS
					AppMessage ecAckConfinAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
					JournalObjectVO ecAckConfInJournalObject = JournalFactory.createJournalObject(
							Constants.TRANS_TYPE_EC_ACK_CONF_IN, ecAckConfinAppMsg, cvTransmitVO.getResponseXml());
					creditContractVO.addToListOfJournalObjects(ecAckConfInJournalObject);
					// set CV Status to Failed since we only get Failed ACCR from ODE RulesEngine
					// for R1
					creditContractVO.getContractValidation().setStatus(Constants.FAILED);
					creditContractVO.getContractValidation()
					.setStatusTs(new java.sql.Timestamp(new Date().getTime()));
					creditContractVO.getDeal().setCvStatus(Constants.FAILED);
					creditContractVO.getDeal().setCvStatusTs(new java.sql.Timestamp(new Date().getTime()));
				} else {
					logger.error("Status Code 200, but received Exception From Rules Engine");
					processNegativeConfirmBOD(cvTransmitVO, creditContractVO);
				}

			}

		} else {
			logger.error("Received Exception From Rules Engine");
			processNegativeConfirmBOD(cvTransmitVO, creditContractVO);
		}
	}

	/**
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @param lteResponseXmlVO
	 * @throws Exception
	 */
	protected void routeCV(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO,
			LteResponseXmlVO lteResponseXmlVO, Boolean isStandard) throws Exception {
		String destinationNameCode = pccXmlParser
				.getDestinationNameCode(lteResponseXmlVO.getLteOutputXml());
		logger.debug("destinationNameCode: {}", destinationNameCode);
		if (Constants.DESTINATION_CODE_ROUTE_ONE.equals(destinationNameCode)) {
			processRouteOneCV(cvTransmitVO, creditContractVO, lteResponseXmlVO.getLteOutputXml());
		} else {
			processLenderSpecificCV(cvTransmitVO, creditContractVO, lteResponseXmlVO.getLteOutputXml(), isStandard);
		}
	}

	/**
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @param lteOutputXml
	 * @throws Exception
	 */
	private void processRouteOneCV(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO, String lteOutputXml) throws Exception {
		logger.debug("Enter processRouteOneCV() method of AccrServiceImpl class");
		ECConfinVO ecConfinVO = routeOneService.prepareAndPostCVToRouteOne(creditContractVO, lteOutputXml, cvTransmitVO.isCdkCloudEnabled());
		cvTransmitVO.setEcConfinVO(ecConfinVO);
	}

	/**
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @param lteOutputXml
	 * @throws Exception
	 */
	private void processLenderSpecificCV(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO,
			String lteOutputXml, Boolean isStandard) throws Exception {
		logger.debug("Enter processLenderSpecificCV() method of AccrServiceImpl class");
		ECConfinVO ecConfinVO = lenderService.prepareAndPostCVToLender(cvTransmitVO, creditContractVO, lteOutputXml, isStandard);
		cvTransmitVO.setEcConfinVO(ecConfinVO);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @throws Exception
	 */
	@Override
	public AccrVO processAccrFromRouteOne(final AccrVO accrVOFromRequest) throws Exception {

		logger.debug("Enter processAccrFromRouteOne() method of AccrServiceImpl class. ACCR Received from R1: {}",
				accrVOFromRequest.getAccrRequestXml());

		AccrVO accrVO = cvResponseXmlParser.populateAccrDetailsFromInput(accrVOFromRequest);
		DeDealVO dealVO = null;
		CreditJournalVO creditJournalVO = null;

		// process dealer validation

		if (!StringUtils.isEmpty(accrVO.getDealerId()) && !StringUtils.isEmpty(accrVO.getAdpDealNo())) {
			logger.debug("Looking up deal by DmsDealId: {}, and dealerid: {}", accrVO.getAdpDealNo(),
					accrVO.getDealerId());
			dealVO = deDealRepoService.findDeDealByDmsDealId(accrVO.getAdpDealNo(), accrVO.getDealerId(),
					accrVO.getLenderId());
			logger.debug("Found deal by DmsDealId and dealerid");
		} else {
			// fetch CJ record using BODId and PartyId
			logger.debug("Fetching deal information using BodId: {} and partyId: {}", accrVO.getBodId(),
					accrVO.getLenderId());
			try {
				creditJournalVO = creditJournalRepoService.getMostRecentRecordByPartnerIdAndTransactionId(
						accrVO.getLenderId(), accrVO.getBodId(), Constants.TRANS_TYPE_CV_EC_OUT);
				if (null != creditJournalVO) {
					logger.debug("Found credit journal by BodId");
				}
				dealVO = deDealRepoService.findDeDealByDmsDealId(creditJournalVO.getAdpDealNo(),
						creditJournalVO.getDealerId(), accrVO.getLenderId());
				logger.debug("Found deal by BodId: {}", dealVO);
			} catch (final Exception e) {
				logger.debug("Exception caught when ", e);
			}

		}

		if (null == dealVO) {
			// unable to find deal send error back to R1
			logger.debug("Could not find deal!");
			accrVO.setResponseMessage(Constants.RESPONSE_MESSAGE_DEAL_NOT_FOUND);
			return accrVO;
		}

		DeLenderVO deLenderVO = lenderLookupService.lookupLenderById(accrVO.getLenderId());

		boolean isCdkCloudEnabled = false;
		try {
			isCdkCloudEnabled = commonService.isCdkCloudEnabled(dealVO.getLenderId(), dealVO.getDmsDealerId(), dealVO.getDmsId());
			logger.debug("isCdkCloudEnabled? {}", isCdkCloudEnabled);
		} catch(Exception e) {
			logger.debug("Unable to determine if lender/dealer/dms is cdkCloud enabled");
		}

		// process Generate Eform Flag
		String generateEFormFlag = null;
		if (null != deLenderVO) {

			if (isCdkCloudEnabled)
			{
				logger.debug("Lender: {} is CdkCloudEnabled. Skipping check for generateEFormFlag", accrVO.getLenderId());
			}
			else
			{
				logger.debug("Lender: {} is **NOT** CdkCloudEnabled. Checking for generateEFormFlag", accrVO.getLenderId());
				generateEFormFlag = deLenderVO.getLenderEformFlag();
				logger.debug("Value of generateEFormFlag: {}", generateEFormFlag);
				//GenerateEForms is CDK ONLY
				if ("Y".equalsIgnoreCase(generateEFormFlag) && Constants.CDK_DSP_IDS.contains(dealVO.getDmsId())) {
					// 3 pieces of xml that should be dropped in generate eforms queue
					// 1. ECIN
					// 2. ECOUT
					// 3. EC_ACK_IN - accrVO.getAccrRequestXml()
					generateEformService.generateEForm(accrVO.getAccrRequestXml(), dealVO);
				}
			}

		} else {
			accrVO.setResponseMessage(Constants.RESPONSE_MESSAGE_LENDER_NOT_FOUND);
			return accrVO;
		}

		productConfigurationLookupService.loadConfigurations(deLenderVO.getLenderId());
		DealerVO deDealer = null;
		String dealerId = accrVO.getDealerId();
		if (StringUtils.isBlank(dealerId)) {
			dealerId = dealVO.getDmsDealerId();
		}
		deDealer = dealerRepoService.getByDealerId(dealerId);
		DealerPpNvpVO dealerPpNvpVO = new DealerPpNvpVO();
		dealerPpNvpVO.setDealerId(dealerId);
		dealerPpNvpVO.setPartnerId(deLenderVO.getLenderId());
		dealerPpNvpVO.setProductId("CV");
		dealerPpNvpVO.setParmName("ACCOUNTID1");
		String dealerPartyId = dealerPpNvpRepoService.getParmValueByParmNameLenderDealerAndProduct(dealerPpNvpVO);
		logger.debug("dealerPartyId: {}", dealerPartyId);
		// get DE_CONTRACT_VALIDATION
		DeContractValidationVO deContractValidationVO = null;
		try {
			deContractValidationVO = deContractValidationRepoService.selectDeContractValidation(dealVO.getDeDealId(),
					creditJournalVO.getSequenceId());
		} catch (final Exception e) {
			logger.error("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}", dealVO.getDeDealId(),
					creditJournalVO.getSequenceId(), e.getMessage());
		}
		if (null != deContractValidationVO) {
			deContractValidationVO.setStatus(accrVO.getValidationResults());
			deContractValidationVO.setStatusTs(new java.sql.Timestamp(new Date().getTime()));
		} else {
			logger.debug("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}", dealVO.getDeDealId(),
					creditJournalVO.getSequenceId());
		}
		// CreditContractVO creditContractVO = new CreditContractVO();
		CreditContractVO creditContractVO = VOFactory.createCreditContractFromExistingCreditJournal(creditJournalVO);
		if (null != deDealer) {
			creditContractVO.getDealerInfo().setDealerId(deDealer.getDealerId());
			creditContractVO.getDealerInfo().setSystemId(deDealer.getSystemId());
			creditContractVO.getDealerInfo()
			.setStoreNumber(deDealer.getStoreId() == null ? deDealer.getDealerId() : deDealer.getStoreId());
			creditContractVO.getDealerInfo().setDealerPartyId(dealerPartyId);
			creditContractVO.getDealerInfo().setDspId(deDealer.getDspId());
		}
		creditContractVO.getPartnerInfo().setLenderId(deLenderVO.getLenderId());
		// creditContractVO.setFiConfig(financeInstitutionConfig.getFinanceInstitution(deLenderVO.getLenderId()));
		creditContractVO.setAccr(accrVO);
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		cvTransmitVO.setPartnerInfoVO(creditContractVO.getPartnerInfo());
		cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
		cvTransmitVO.setAccrContext(accrVO);
		cvTransmitVO.setAccrResponseXml(accrVO.getAccrRequestXml());

		dealVO.setCvStatus(accrVO.getValidationResults());
		dealVO.setCvStatusTs(new java.sql.Timestamp(new Date().getTime()));

		cvTransmitVO.setDealVO(dealVO);

		// Enter ECACKIN in CJ
		List<CreditJournalVO> listOfCreditJournals = new ArrayList<>();
		AppMessage ecAckInAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
		JournalObjectVO journalObjectVO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_IN,
				ecAckInAppMsg, accrVO.getAccrRequestXml());


		CreditJournalVO ecAckInJournalObject = JournalFactory.createCreditJournal(journalObjectVO, dealVO,
				creditJournalVO, accrVO);
		listOfCreditJournals.add(ecAckInJournalObject);

		DeLenderFeatureVO srflLenderFeature = deLenderFeatureRepoService
				.getLenderFeatureByLenderIdAndFeatureId(deLenderVO.getLenderId(), Constants.STATIC_RFL_FLAG);
		if (null != srflLenderFeature) {
			logger.debug("Found DeLenderFeatureVO with featureId {}", Constants.STATIC_RFL_FLAG);
			cvTransmitVO.setStaticRFLEnabled(true);
		}

		try {
			String ecout2Xml = null;
			String ecinXml = null;

			// extract dealer and store number from ECOUT2
			try {
				ecout2Xml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
						Constants.TRANS_TYPE_EC_OUT2);
				cvResponseXmlParser.populateAccrDetailsFromEcout2(ecout2Xml, accrVO);
			} catch (final Exception e) {
				logger.debug("Exception caught when fetching ecout2Xml", e);
			}

			// extract finance type, application type and DestinationNameCode from ECIN
			String dspId = "";
			if (null != creditContractVO.getDealerInfo() && StringUtils.isNotBlank(creditContractVO.getDealerInfo().getDspId()))
			{
				dspId = creditContractVO.getDealerInfo().getDspId();
			}
			try {
				try {
					ecinXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
							Constants.TRANS_TYPE_CV_EC_IN);
				} catch (final Exception e) {
					logger.debug("Exception caught when fetching ecinXml from {}, attempting to fetch from {}.",
							Constants.TRANS_TYPE_CV_EC_IN, Constants.TRANS_TYPE_EC_IN, e);
				}
				if (null == ecinXml) {
					ecinXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
							Constants.TRANS_TYPE_EC_IN);
				}
				cvResponseXmlParser.populateAccrDetailsFromEcin(ecinXml, accrVO,dspId);
			} catch (final Exception e) {
				logger.debug("Exception caught when fetching ecinXml", e);
			}

			rflProcessingService.processRfl(cvTransmitVO, accrVO);

			String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
					deDealer.getDspId(), Constants.ACCR, Constants.STYLESHEET);
			creditContractVO.setFinanceType(accrVO.getFinanceType());
			accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
			// call cvTransmitClient to send ECACKOUT to DMS
			cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, deDealer.getDspId());

			// Journal ACKOUT to DMS
			AppMessage ackOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
			journalObjectVO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_OUT, ackOutAppMsg,
					cvTransmitVO.getAccroutXml());
			CreditJournalVO ackOutJournalObject = JournalFactory.createCreditJournal(journalObjectVO, dealVO,
					creditJournalVO, accrVO);
			listOfCreditJournals.add(ackOutJournalObject);

			// Journal ECACKCONFIN from DMS
			AppMessage ecAckConfinAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
			journalObjectVO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_CONF_IN, ecAckConfinAppMsg,
					cvTransmitVO.getResponseXml());
			CreditJournalVO ecAckConfInJournalObject = JournalFactory.createCreditJournal(journalObjectVO, dealVO,
					creditJournalVO, accrVO);

			listOfCreditJournals.add(ecAckConfInJournalObject);
		} catch (final Exception e) {
			// Generate Negative Confirm BOD and send to DMS
			logger.error("Exception caught during RouteOne ACCR processing, triggering negative confirmBOD.", e);
			processNegativeConfirmBOD(cvTransmitVO, creditContractVO);
		}

		if (isCdkCloudEnabled) {
			String queueMessage = cdkCloudService.notifyCDKCloudService(dealVO);
			if(queueMessage != null) {
				// Journal CV-CLOUDQOUT from CV to CDKCloudService
				AppMessage cvCloudQOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
				journalObjectVO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_CV_CLOUDQOUT, cvCloudQOutAppMsg, queueMessage);
				CreditJournalVO cvCloudQOutJournalObject = JournalFactory.createCreditJournal(journalObjectVO, dealVO,
						creditJournalVO, accrVO);
				listOfCreditJournals.add(cvCloudQOutJournalObject);
			}
		}

		Boolean journalsInserted = cvJournalService.addListOfJournals(listOfCreditJournals);
		if (journalsInserted.booleanValue()) {
			accrVO.setResponseMessage(Constants.OPERATION_SUCCESS_MESSSAGE);
		}

		// Update Deal Status
		deDealRepoService.saveOrUpdate(dealVO);
		deContractValidationRepoService.saveOrUpdate(deContractValidationVO);

		return accrVO;
	}

	@Override
	public AccrVO processAsyncResponseFromLender(final String lenderResponseXml) throws Exception {
		logger.debug("Enter processAsyncResponseFromLender() method of AccrServiceImpl class. Response Received from Lender: {}",
				lenderResponseXml);
		if (StringUtils.isNotEmpty(lenderResponseXml)) {
			if (lenderResponseXml.contains(Constants.LENDER_RESPONSE_ACCR)) {
				logger.debug("Processing AcknowledgeCreditContractResponse from Lender");
				AccrVO accrVOFromRequest = new AccrVO();
				accrVOFromRequest.setAccrRequestXml(lenderResponseXml);
				return processAsyncAccrFromLender(accrVOFromRequest);
			} else if (lenderResponseXml.contains(Constants.CONFIRM_BOD)) {
				logger.debug("Processing ConfirmBOD from Lender");
				return processAsyncConfirmBodFromLender(lenderResponseXml);
			} else {
				logger.debug("Response from Lender was not empty but not an Accr or ConfirmBod");
			}
		} else {
			logger.debug("Response from Lender was empty");
		}
		return null;
	}

	private AccrVO processAsyncConfirmBodFromLender(String lenderResponseXml) throws Exception {
		logger.debug("Enter processAsyncConfirmBodFromLender() method of AccrServiceImpl class. ConfirmBod Received from Lender: {}",lenderResponseXml);

		AccrVO accrVO = cvResponseXmlParser.populateConfirmBodDetailsFromInput(lenderResponseXml);
		DeDealVO dealVO = null;
		CreditJournalVO creditJournalVO = null;
		logger.debug("Fetching deal information using BodId: {} and partyId: {}", accrVO.getBodId(),
				accrVO.getLenderId());
		try {
			creditJournalVO = creditJournalRepoService.getMostRecentRecordByPartnerIdAndTransactionId(
					accrVO.getLenderId(), accrVO.getBodId(), Constants.TRANS_TYPE_CV_EC_OUT);
			if (null != creditJournalVO) {
				logger.debug("Found credit journal by BodId");
			}
			dealVO = deDealRepoService.findDeDealByDmsDealId(creditJournalVO.getAdpDealNo(),
					creditJournalVO.getDealerId(), accrVO.getLenderId());
			logger.debug("Found deal by BodId");
		} catch (final Exception e) {
			logger.debug("Exception caught trying to find deal, ", e);
		}

		if (null == dealVO) {
			// unable to find deal send error back to R1
			logger.debug("Could not find deal!");
			accrVO.setResponseMessage(Constants.RESPONSE_MESSAGE_DEAL_NOT_FOUND);
			return accrVO;
		}

		DeLenderVO deLenderVO = lenderLookupService.lookupLenderById(accrVO.getLenderId());
		productConfigurationLookupService.loadConfigurations(deLenderVO.getLenderId());
		DealerVO deDealer = null;
		String dealerId =  dealVO.getDmsDealerId();
		logger.debug("ConfirmBOD DMS DealerID: {}", dealerId);

		deDealer = dealerRepoService.getByDealerId(dealerId);
		DealerPpNvpVO dealerPpNvpVO = new DealerPpNvpVO();
		dealerPpNvpVO.setDealerId(dealerId);
		dealerPpNvpVO.setPartnerId(deLenderVO.getLenderId());
		dealerPpNvpVO.setProductId("CV");
		dealerPpNvpVO.setParmName("ACCOUNTID1");
		String dealerPartyId = dealerPpNvpRepoService.getParmValueByParmNameLenderDealerAndProduct(dealerPpNvpVO);

		DeContractValidationVO deContractValidationVO = null;
		try {
			deContractValidationVO = deContractValidationRepoService.selectDeContractValidation(dealVO.getDeDealId(),
					creditJournalVO.getSequenceId());
		} catch (final Exception e) {
			logger.error("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}", dealVO.getDeDealId(),
					creditJournalVO.getSequenceId(), e.getMessage());
		}
		if (null != deContractValidationVO) {
			deContractValidationVO.setStatus(accrVO.getValidationResults());
			deContractValidationVO.setStatusTs(new java.sql.Timestamp(new Date().getTime()));
		} else {
			logger.debug("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}", dealVO.getDeDealId(),
					creditJournalVO.getSequenceId());
		}
		DeContractValidationBo deContractValidationBo = modelMapper.map(deContractValidationVO, DeContractValidationBo.class);

		CreditContractVO creditContractVO = VOFactory.createCreditContractFromExistingCreditJournal(creditJournalVO);
		creditContractVO.setContractValidation(deContractValidationBo);
		if (null != deDealer) {
			creditContractVO.getDealerInfo().setDealerId(deDealer.getDealerId());
			creditContractVO.getDealerInfo().setSystemId(deDealer.getSystemId());
			creditContractVO.getDealerInfo()
			.setStoreNumber(deDealer.getStoreId() == null ? deDealer.getDealerId() : deDealer.getStoreId());
			creditContractVO.getDealerInfo().setDealerPartyId(dealerPartyId);
			creditContractVO.getDealerInfo().setDspId(deDealer.getDspId());
		}
		creditContractVO.getPartnerInfo().setLenderId(deLenderVO.getLenderId());

		AppMessage appMessage = applpEventHandler.handleEvents(Constants.Event_Partner_Validation_Exception);
		appMessage.setMessage(accrVO.getValidationResults());
		creditContractVO.setAppMsg(appMessage);

		JournalObjectVO ecconfinJO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_IN , appMessage,
				lenderResponseXml);
		cvJournalService.addJournal(creditContractVO, ecconfinJO);

		String ecout2Xml = null;
		String ecinXml = null;

		// extract dealer and store number from ECOUT2
		try {
			ecout2Xml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
					Constants.TRANS_TYPE_EC_OUT2);
			cvResponseXmlParser.populateAccrDetailsFromEcout2(ecout2Xml, accrVO);
		} catch (final Exception e) {
			logger.debug("Exception caught when fetching ecout2Xml", e);
		}

		// extract finance type, application type and DestinationNameCode from ECIN
		String dspId = "";
		if (null != creditContractVO.getDealerInfo() && StringUtils.isNotBlank(creditContractVO.getDealerInfo().getDspId()))
		{
			dspId = creditContractVO.getDealerInfo().getDspId();
		}
		logger.debug("ConfirmBOD DSP: {}", dspId);
		try {
			try {
				ecinXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
						Constants.TRANS_TYPE_CV_EC_IN);
			} catch (final Exception e) {
				logger.debug("Exception caught when fetching ecinXml from {}, attempting to fetch from {}.",
						Constants.TRANS_TYPE_CV_EC_IN, Constants.TRANS_TYPE_EC_IN, e);
			}
			if (null == ecinXml) {
				ecinXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
						Constants.TRANS_TYPE_EC_IN);
			}
			cvResponseXmlParser.populateAccrDetailsFromEcin(ecinXml, accrVO,dspId);
		} catch (final Exception e) {
			logger.debug("Exception caught when fetching ecinXml", e);
		}

		creditContractVO.setAccr(accrVO);

		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		cvTransmitVO.setPartnerInfoVO(creditContractVO.getPartnerInfo());
		cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
		cvTransmitVO.setAccrContext(accrVO);
		String cvEcoutXml = "";
		try {
			cvEcoutXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
					Constants.TRANS_TYPE_CV_EC_OUT);
		} catch (Exception e) {
			logger.debug("Exception caught when fetching cvEcoutXml", e);
		}
		cvTransmitVO.setAccrResponseXml(cvEcoutXml);
		cvTransmitVO.setDealVO(dealVO);

		String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
				creditContractVO.getDealerInfo().getDspId(), Constants.CONFIRMBOD, Constants.STYLESHEET);
		/*generate DMS Out XML applying confirmBod stylesheet*/
		accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
		/*Send DMS Out XML*/
		cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, deDealer.getDspId());

		JournalObjectVO ecconfoutJO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_OUT , appMessage,
				cvTransmitVO.getAccroutXml());
		cvJournalService.addJournal(creditContractVO, ecconfoutJO);

		dealVO.setCvStatus(Constants.FAILED);
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		dealVO.setCvStatusTs(currentTime);
		dealVO.setModifiedTs(currentTime);
		dealVO.setLastModifiedTs(currentTime);
		dealVO.setModifiedBy(Constants.APP_CV_CODE);
		deDealRepoService.saveOrUpdate(dealVO);
		deContractValidationRepoService.saveOrUpdate(deContractValidationVO);
		return accrVO;
	}

	private AccrVO processAsyncAccrFromLender(final AccrVO accrVOFromRequest) throws Exception {
		logger.debug("Enter processAsyncAccrFromLender() method of AccrServiceImpl class. ACCR Received from Lender: {}",

				accrVOFromRequest.getAccrRequestXml());

		AccrVO accrVO = cvResponseXmlParser.populateAccrDetailsFromInput(accrVOFromRequest);
		DeDealVO dealVO = null;
		CreditJournalVO creditJournalVO = null;
		if (!StringUtils.isEmpty(accrVO.getDealerId()) && !StringUtils.isEmpty(accrVO.getAdpDealNo())) {
			logger.debug("Looking up deal by DmsDealId: {}, and dealerid: {}", accrVO.getAdpDealNo(),
					accrVO.getDealerId());
			dealVO = deDealRepoService.findDeDealByDmsDealId(accrVO.getAdpDealNo(), accrVO.getDealerId(),
					accrVO.getLenderId());
			logger.debug("Found deal by DmsDealId and dealerid");
		} else {
			logger.debug("Fetching deal information using BodId: {} and partyId: {}", accrVO.getBodId(),
					accrVO.getLenderId());
			try {
				creditJournalVO = creditJournalRepoService.getMostRecentRecordByPartnerIdAndTransactionId(
						accrVO.getLenderId(), accrVO.getBodId(), Constants.TRANS_TYPE_CV_EC_OUT);
				if (null != creditJournalVO) {
					logger.debug("Found credit journal by BodId");
				}
				dealVO = deDealRepoService.findDeDealByDmsDealId(creditJournalVO.getAdpDealNo(),
						creditJournalVO.getDealerId(), accrVO.getLenderId());
				logger.debug("Found deal by BodId");
			} catch (final Exception e) {
				logger.debug("Exception caught trying to find deal, ", e);
			}
		}

		if (null == dealVO) {
			// unable to find deal send error back to R1
			logger.debug("Could not find deal!");
			accrVO.setResponseMessage(Constants.RESPONSE_MESSAGE_DEAL_NOT_FOUND);
			return accrVO;
		}

		DeLenderVO deLenderVO = lenderLookupService.lookupLenderById(accrVO.getLenderId());

		boolean isCdkCloudEnabled = false;
		try {
			isCdkCloudEnabled = commonService.isCdkCloudEnabled(dealVO.getLenderId(), dealVO.getDmsDealerId(), dealVO.getDmsId());
			logger.debug("isCdkCloudEnabled? {}", isCdkCloudEnabled);
		} catch(Exception e) {
			logger.debug("Unable to determine if lender/dealer/dms is cdkCloud enabled");
		}
		
		String generateEFormFlag = null;
		if (null != deLenderVO) {
			generateEFormFlag = deLenderVO.getLenderEformFlag();
			logger.debug("Value of generateEFormFlag: {}", generateEFormFlag);
			if ("Y".equalsIgnoreCase(generateEFormFlag)) {
				generateEformService.generateEForm(accrVO.getAccrRequestXml(), dealVO);
			}
		} else {
			accrVO.setResponseMessage(Constants.RESPONSE_MESSAGE_LENDER_NOT_FOUND);
			return accrVO;
		}

		productConfigurationLookupService.loadConfigurations(deLenderVO.getLenderId());
		DealerVO deDealer = null;
		String dealerId = accrVO.getDealerId();
		if (StringUtils.isBlank(dealerId)) {
			dealerId = dealVO.getDmsDealerId();
		}

		deDealer = dealerRepoService.getByDealerId(dealerId);
		DealerPpNvpVO dealerPpNvpVO = new DealerPpNvpVO();
		dealerPpNvpVO.setDealerId(dealerId);
		dealerPpNvpVO.setPartnerId(deLenderVO.getLenderId());
		dealerPpNvpVO.setProductId("CV");
		dealerPpNvpVO.setParmName("ACCOUNTID1");
		String dealerPartyId = dealerPpNvpRepoService.getParmValueByParmNameLenderDealerAndProduct(dealerPpNvpVO);

		logger.debug("dealerPartyId: {}", dealerPartyId);
		// get DE_CONTRACT_VALIDATION
		DeContractValidationVO deContractValidationVO = null;
		try {
			deContractValidationVO = deContractValidationRepoService.selectDeContractValidation(dealVO.getDeDealId(),
					creditJournalVO.getSequenceId());
		} catch (final Exception e) {
			logger.error("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}", dealVO.getDeDealId(),
					creditJournalVO.getSequenceId(), e.getMessage());
		}
		if (null != deContractValidationVO) {
			deContractValidationVO.setStatus(accrVO.getValidationResults());
			deContractValidationVO.setStatusTs(new java.sql.Timestamp(new Date().getTime()));
		} else {
			logger.debug("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}", dealVO.getDeDealId(),
					creditJournalVO.getSequenceId());
		}

		CreditContractVO creditContractVO = VOFactory.createCreditContractFromExistingCreditJournal(creditJournalVO);
		if (null != deDealer) {
			creditContractVO.getDealerInfo().setDealerId(deDealer.getDealerId());
			creditContractVO.getDealerInfo().setSystemId(deDealer.getSystemId());
			creditContractVO.getDealerInfo()
			.setStoreNumber(deDealer.getStoreId() == null ? deDealer.getDealerId() : deDealer.getStoreId());
			creditContractVO.getDealerInfo().setDealerPartyId(dealerPartyId);
			creditContractVO.getDealerInfo().setDspId(deDealer.getDspId());
		}
		creditContractVO.getPartnerInfo().setLenderId(deLenderVO.getLenderId());
		creditContractVO.setAccr(accrVO);
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		cvTransmitVO.setPartnerInfoVO(creditContractVO.getPartnerInfo());
		cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
		cvTransmitVO.setAccrContext(accrVO);
		cvTransmitVO.setAccrResponseXml(accrVO.getAccrRequestXml());
		dealVO.setCvStatus(accrVO.getValidationResults());
		dealVO.setCvStatusTs(new java.sql.Timestamp(new Date().getTime()));

		cvTransmitVO.setDealVO(dealVO);
		List<CreditJournalVO> listOfCreditJournals = new ArrayList<>();
		AppMessage ecAckInAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
		JournalObjectVO ecAckInJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_IN,
				ecAckInAppMsg, accrVO.getAccrRequestXml());


		CreditJournalVO ecAckInCreditJournalVo = JournalFactory.createCreditJournal(ecAckInJournalObject, dealVO,
				creditJournalVO, accrVO);
		listOfCreditJournals.add(ecAckInCreditJournalVo);

		DeLenderFeatureVO srflLenderFeature = deLenderFeatureRepoService
				.getLenderFeatureByLenderIdAndFeatureId(deLenderVO.getLenderId(), Constants.STATIC_RFL_FLAG);
		if (null != srflLenderFeature) {
			logger.debug("Found DeLenderFeatureVO with featureId {}", Constants.STATIC_RFL_FLAG);
			cvTransmitVO.setStaticRFLEnabled(true);
		}

		try {
			String ecout2Xml = null;
			String ecinXml = null;

			// extract dealer and store number from ECOUT2
			try {
				ecout2Xml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
						Constants.TRANS_TYPE_EC_OUT2);
				cvResponseXmlParser.populateAccrDetailsFromEcout2(ecout2Xml, accrVO);
			} catch (final Exception e) {
				logger.debug("Exception caught when fetching ecout2Xml", e);
			}

			logger.debug("AccrVO requestXMl before processRFL: {}", accrVO.getAccrRequestXml());
			logger.debug("cvTransmitVO accrresponsexml before processRFL: {}", cvTransmitVO.getAccrResponseXml());
			rflProcessingService.processRfl(cvTransmitVO, accrVO);

			// extract finance type, application type and DestinationNameCode from ECIN
			String dspId = "";
			if (null != creditContractVO.getDealerInfo() && StringUtils.isNotBlank(creditContractVO.getDealerInfo().getDspId())) {
				dspId = creditContractVO.getDealerInfo().getDspId();
			}
			try {
				try {
					ecinXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
							Constants.TRANS_TYPE_CV_EC_IN);
				} catch (final Exception e) {
					logger.debug("Exception caught when fetching ecinXml from {}, attempting to fetch from {}.",
							Constants.TRANS_TYPE_CV_EC_IN, Constants.TRANS_TYPE_EC_IN, e);
				}
				if (null == ecinXml) {
					ecinXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
							Constants.TRANS_TYPE_EC_IN);
				}
				cvResponseXmlParser.populateAccrDetailsFromEcin(ecinXml, accrVO, dspId);
			} catch (final Exception e) {
				logger.debug("Exception caught when fetching ecinXml", e);
			}
			String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
					deDealer.getDspId(), Constants.ACCR, Constants.STYLESHEET);
			accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
			creditContractVO.setFinanceType(accrVO.getFinanceType());
			cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, deDealer.getDspId());
			AppMessage ackOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
			JournalObjectVO ecAckOutJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_OUT, ackOutAppMsg,
					cvTransmitVO.getAccroutXml());
			CreditJournalVO ecAckOutCreditJournalVo = JournalFactory.createCreditJournal(ecAckOutJournalObject, dealVO,
					creditJournalVO, accrVO);
			listOfCreditJournals.add(ecAckOutCreditJournalVo);

			// Journal ECACKCONFIN from DMS
			AppMessage ecAckConfinAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
			JournalObjectVO ecAckConfInJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_CONF_IN, ecAckConfinAppMsg,
					cvTransmitVO.getResponseXml());
			CreditJournalVO ecAckConfInCreditJournalVo = JournalFactory.createCreditJournal(ecAckConfInJournalObject, dealVO,
					creditJournalVO, accrVO);
			listOfCreditJournals.add(ecAckConfInCreditJournalVo);
		} catch (final Exception e) {
			// Generate Negative Confirm BOD and send to DMS
			logger.error("Exception caught during ACCR processing, triggering negative confirmBOD.", e);
			processNegativeConfirmBOD(cvTransmitVO, creditContractVO);
		}

		if (isCdkCloudEnabled) {
			String queueMessage = cdkCloudService.notifyCDKCloudService(dealVO);
			if(queueMessage != null) {
				// Journal CV-CLOUDQOUT from CV to CDKCloudService
				AppMessage cvCloudQOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
				JournalObjectVO journalObjectVO = JournalFactory.createJournalObject(Constants.TRANS_TYPE_CV_CLOUDQOUT, cvCloudQOutAppMsg, queueMessage);
				CreditJournalVO cvCloudQOutJournalObject = JournalFactory.createCreditJournal(journalObjectVO, dealVO,
						creditJournalVO, accrVO);
				listOfCreditJournals.add(cvCloudQOutJournalObject);
			}
		}

		Boolean journalsInserted = cvJournalService.addListOfJournals(listOfCreditJournals);
		if (journalsInserted.booleanValue()) {
			accrVO.setResponseMessage(Constants.OPERATION_SUCCESS_MESSSAGE);
		}

		dealVO.setCvStatus(creditContractVO.getAccr().getValidationResults());
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		dealVO.setCvStatusTs(currentTime);
		dealVO.setModifiedTs(currentTime);
		dealVO.setLastModifiedTs(currentTime);
		dealVO.setModifiedBy(Constants.APP_CV_CODE);

		deDealRepoService.saveOrUpdate(dealVO);
		deContractValidationRepoService.saveOrUpdate(deContractValidationVO);

		return accrVO;
	}

	/**
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @throws Exception
	 */
	private void processNegativeConfirmBOD(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO)
			throws Exception {

		logger.debug("Enter processNegativeConfirmBOD() method of AccrServiceImpl class");
		String negativeConfirmBODXml = creditContractVO.getLenderRequestXml();
		cvTransmitVO.setAccrResponseXml(negativeConfirmBODXml);
		if (creditContractVO.getAccr() == null) {
			AccrVO accrVO = new AccrVO();
			accrVO.setBodId(creditContractVO.getDocumentId());
			creditContractVO.setAccr(accrVO);
		} else {
			creditContractVO.getAccr().setBodId(creditContractVO.getDocumentId());
		}
		AppMessage ecConfInAppMsg = applpEventHandler.handleEvents("AppRulesValidationException");
		creditContractVO.setAppMsg(ecConfInAppMsg);
		JournalObjectVO ecConfInJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_IN,
				ecConfInAppMsg, negativeConfirmBODXml);
		cvJournalService.addJournal(creditContractVO, ecConfInJournalObject);

		// Journal CONFOUT to DMS
		String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
				creditContractVO.getDealerInfo().getDspId(), Constants.CONFIRMBOD, Constants.STYLESHEET);
		AppMessage ecConfOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
		accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
		JournalObjectVO ecConfOutJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_OUT,
				ecConfOutAppMsg, cvTransmitVO.getAccroutXml());
		creditContractVO.addToListOfJournalObjects(ecConfOutJournalObject);
		// call cvTransmitClient to send Output to DMS
		cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, creditContractVO.getDealerInfo().getDspId());

	}
}