/**
 * 
 */
package com.ode.cv.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.cv.normalizer.bo.CCVConditionBO;
import com.ode.cv.normalizer.bo.CCVXPathBO;
import com.ode.cv.util.CVDataTranslationUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CcvInputVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.service.ApplicationPropertiesRepoService;
import com.ode.persistence.service.CcvConditionRepoService;
import com.ode.persistence.service.CcvConditionSetRepoService;
import com.ode.persistence.service.CcvDataExceptionRepoService;
import com.ode.persistence.service.CcvDataTranslationRepoService;
import com.ode.persistence.service.CcvXpathRepoService;
import com.ode.persistence.service.FormsRepoService;
import com.ode.persistence.vo.ApplicationPropertiesVO;
import com.ode.persistence.vo.CcvConditionSetVO;
import com.ode.persistence.vo.CcvConditionVO;
import com.ode.persistence.vo.CcvDataExceptionVO;
import com.ode.persistence.vo.CcvDataTranslationVO;
import com.ode.persistence.vo.CcvXpathVO;
import com.ode.persistence.vo.FormsVO;

/**
 * @author rmathew
 */
@Service
public class CVDataTranslationServiceImpl implements ICVDataTranslationService {

	private static final Logger logger = LogManager.getLogger(CVDataTranslationServiceImpl.class);

	@Autowired
	private CcvDataTranslationRepoService ccvDataTranslationRepoService;

	@Autowired
	private CcvDataExceptionRepoService ccvDataExceptionRepoService;

	@Autowired
	private CcvConditionSetRepoService ccvConditionSetRepoService;

	@Autowired
	private CcvConditionRepoService ccvConditionRepoService;

	@Autowired
	private CcvXpathRepoService ccvXpathRepoService;

	@Autowired
	private FormsRepoService formRepoService;

	@Autowired
	private CVDataTranslationUtil cvDataTranslationUtil;

	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;

	@Autowired
	private ApplicationPropertiesRepoService applicationPropertiesRepoService;
	
	@Autowired
	private CVTransmitClient transmitClient;

	/**
	 * {@inheritDoc}
	 * 
	 * @throws Exception
	 */
	@Override
	public void translateData(final CreditContractVO creditContractVO) throws Exception {

		logger.debug("Entered translateData() method of CVDataTranslationServiceImpl class for lenderId: {}",
				creditContractVO.getPartnerInfo().getLenderId());

		if (cvDataTranslationUtil.isContractFormTranslationRequired(creditContractVO)) {

			logger.debug(
					"Trying to fetch FormsVO with params formNumber: {}, ContractFormRevisionDate: {}, lenderId: {}",
					creditContractVO.getContractFormNumber(), creditContractVO.getContractFormRevisionDate(),
					creditContractVO.getPartnerInfo().getLenderId());

			FormsVO formsVO = null;

			if (productConfigurationLookupService.cvMessageProcessingContainsValue("formTranslation")) {
				formsVO = formRepoService.getFormByFormRevisionDateAndLenderCode(
						creditContractVO.getContractFormNumber(), creditContractVO.getContractFormRevisionDate(),
						creditContractVO.getPartnerInfo().getLenderId());

			}

			else if (null != creditContractVO.getContractExecutionState()) {
				formsVO = formRepoService.getFormTranslationWithState(creditContractVO.getContractFormNumber(),
						creditContractVO.getContractFormRevisionDate(), creditContractVO.getPartnerInfo().getLenderId(),
						creditContractVO.getContractExecutionState());

			}

			if (null == formsVO) {
				// creditContractVO.setContractFormNumber(formsVO.getFormNumber());
				// creditContractVO.setContractFormRevisionDate(formsVO.getRevDate());
				logger.debug("Failed fetching FormsVO from DB");
			} else {
				logger.debug("ContractType: {}", formsVO.getContractType());
				creditContractVO.setContractType(formsVO.getContractType());
			}

		}

		creditContractVO.setStateGroup(cvDataTranslationUtil.selectStateGroup(creditContractVO));

		CcvInputVO ccvInputVO = new CcvInputVO();
		CCVConditionBO ccvCoditionBO = new CCVConditionBO();
		CCVXPathBO ccvXpathBO = new CCVXPathBO();
		List<CcvDataTranslationVO> listOfDataTranslations = ccvDataTranslationRepoService.getByLenderIdAndDspId(
				creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDspId());
		List<CcvDataExceptionVO> listOfDataExceptions = ccvDataExceptionRepoService.getByLenderIdAndDspId(
				creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDspId());
		List<CcvConditionSetVO> listOfConditionSetVO = ccvConditionSetRepoService.getByLenderIdAndDspId(
				creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDspId());
		List<CcvConditionVO> listOfConditions = new ArrayList<>();
		CcvConditionVO ccvCondition = ccvConditionRepoService.getCcvConditionById(ccvCoditionBO.getConditionId());
		listOfConditions.add(ccvCondition);
		List<String> xpathArgs = new ArrayList<>();
		xpathArgs.add(ccvXpathBO.getXpath());
		List<CcvXpathVO> listOfXpaths = ccvXpathRepoService.getXpathsByXpathKeys(xpathArgs);

		if (null == listOfDataTranslations || !listOfDataTranslations.isEmpty()) {
			logger.debug("No datatranslation data found for lenderId: {}",
					creditContractVO.getPartnerInfo().getLenderId());
		} else {
			logger.debug("Number of datatranslation found for lenderId: {} is {}",
					creditContractVO.getPartnerInfo().getLenderId(), listOfDataTranslations.size());

		}

		if (null == listOfXpaths || listOfXpaths.isEmpty()) {
			logger.debug("No listOfXpaths data found for lenderId: {}",
					creditContractVO.getPartnerInfo().getLenderId());
		} else {
			logger.debug("Number of listOfXpaths found for lenderId: {} is {}",
					creditContractVO.getPartnerInfo().getLenderId(), listOfXpaths.size());

		}

		ccvInputVO.setListOfDataTranslations(listOfDataTranslations);
		ccvInputVO.setListOfDataExceptions(listOfDataExceptions);
		ccvInputVO.setListOfCcvConditionSets(listOfConditionSetVO);
		ccvInputVO.setListOfCcvConditions(listOfConditions);
		ccvInputVO.setListOfCcvXpaths(listOfXpaths);
		creditContractVO.setCcvInputVO(ccvInputVO);

		// this is for routing CV to R1 or other lender or DMS (VCF after passed RE
		// validation, until Volvo rules are migrated to LTE)
		logger.debug("LenderId to set as DestinationNameCode: {}", creditContractVO.getPartnerInfo().getLenderId());
		creditContractVO.setDestinationNameCode(creditContractVO.getPartnerInfo().getLenderId());
		Boolean routeOneFlag = transmitClient.getRouteOneFlag(creditContractVO.getDealerInfo().getDealerId(),
				creditContractVO.getPartnerInfo().getLenderId(), Constants.APP_CV_CODE);
		if (routeOneFlag) {
			creditContractVO.setDestinationNameCode(Constants.DESTINATION_CODE_ROUTE_ONE);
		}
		ApplicationPropertiesVO applicationPropertiesVO = applicationPropertiesRepoService
				.getByApplicationNameAndPropertyName(Constants.APP_CV_CODE, Constants.RE_LENDERS);
		if (null != applicationPropertiesVO && StringUtils.isNotBlank(applicationPropertiesVO.getPropertyValue())) {
			logger.debug("Found ApplicationPropertiesVO for {}. Property Value: {}", Constants.RE_LENDERS,
					applicationPropertiesVO.getPropertyValue());
			StringTokenizer sT = new StringTokenizer(applicationPropertiesVO.getPropertyValue(), Constants.PIPE);
			List<String> listOfRELenders = new ArrayList<>();
			while (sT.hasMoreTokens()) {
				listOfRELenders.add(sT.nextToken());
			}
			logger.debug("listOfRELenders: {}", listOfRELenders);
			if (listOfRELenders.contains(creditContractVO.getPartnerInfo().getLenderId())) {
				creditContractVO.setOldREValidationRequired(Boolean.TRUE);
			}

		} else {
			logger.debug("Could not find ApplicationPropertiesVO for {}", Constants.RE_LENDERS);
		}

	}
}
