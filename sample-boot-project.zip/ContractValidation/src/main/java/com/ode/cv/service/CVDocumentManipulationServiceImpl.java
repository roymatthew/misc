package com.ode.cv.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.ode.commons.util.vo.CommonsUtilNvpVO;
import com.ode.cv.bo.ILenderBO;
import com.ode.cv.factory.LenderBOFactory;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.DeCdkCloudCvXrefVO;
import com.ode.persistence.vo.FeatureConfigurationVO;

@Service
public class CVDocumentManipulationServiceImpl implements ICVDocumentManipulationService {

	private static final Logger logger = LogManager.getLogger(CVDocumentManipulationServiceImpl.class);

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;

	@Autowired
	private PCCXmlParser pccXmlParser;
	
	@Autowired
	private LenderBOFactory lenderBOFactory;
	
	@Autowired
	private IProductConfigurationLookupService iProductConfigurationLookupService;

	@Override
	public Document manipulateCVDocument(final CreditContractVO creditContractVO, final String xml) throws Exception {

		String dmsDealNum = "";
		if (null != creditContractVO && null != creditContractVO.getDeal()) {
			dmsDealNum = creditContractVO.getDeal().getDmsDealNum();
		}
		logger.debug("Entered manipulateCVDocument() of CVDocumentManipulationServiceImpl class. DealId: {}",
				dmsDealNum);

		Document document = cvRequestXmlParser.getDocument(xml);

		String destinationNameCode = pccXmlParser.getDestinationNameCode(xml);
		logger.debug("destinationNameCode: {}", destinationNameCode);

		if (Constants.DESTINATION_CODE_ROUTE_ONE.equals(destinationNameCode)) {
			Document newDocument = CVUtil.removeTradeInsFromCVDocument(document, creditContractVO);
			newDocument = CVUtil.addApplicantPartyIDs(newDocument, creditContractVO);
			CVUtil.addDealerPartyId(newDocument, creditContractVO);
			return newDocument;
		}
		return document;
	}

	@Override
	public String updateSubTotals(final String crDataXml, final Map<String, String> subTotalsMap,
			final List<DeCdkCloudCvXrefVO> listOfXrefsForSubTotal) throws Exception {
		logger.debug("Entered updateSubTotals() of CVDocumentManipulationServiceImpl class");
		String ecout3 = "";
		XPath xpath = XPathFactory.newInstance().newXPath();
		try {
			Document document = cvRequestXmlParser.getDocument(crDataXml);
			listOfXrefsForSubTotal.stream().forEach(xref -> {

				XPathExpression expr;

				try {
					expr = xpath.compile(xref.getXpath());
					Node node = (Node) expr.evaluate(document, XPathConstants.NODE);
					if (null != node) {
						String newSubTotal = subTotalsMap.get(xref.getJsonSourceField());
						if (StringUtils.isNotBlank(newSubTotal)) {
							node.setTextContent(newSubTotal);
						}

					}
				} catch (final XPathExpressionException e) {
					logger.debug("An exception occured when processing node with xpath: {}", xref.getXpath(), e);
				}

			});
			ecout3 = CVUtil.getXmlStringFromDocument(document);
		} catch (final Exception e) {
			logger.debug("An exception occured when obtaining document from xml string", e);
		}

		return ecout3;
	}

	@Override
	public Document makeRequiredChangesToECOUTForLender(final CreditContractVO creditContractVO, final Document document)
			throws Exception {
		logger.debug("Entered makeRequiredChangesToECOUTForLender() of CVDocumentManipulationServiceImpl class");
		ILenderBO lenderBO = lenderBOFactory.createLenderBO(creditContractVO.getPartnerInfo().getLenderId());
		/*if lender requires changes to STAR schema ECOUT*/
		if (lenderBO.isEcoutChangesRequired()) {
			//Document document = cvRequestXmlParser.getDocument(inEcout);
			Document modifiedDocument = lenderBO.makeChangesToEcout(creditContractVO, document,
					getMapOfWebServiceFeaturesForLender(iProductConfigurationLookupService.getWebServiceFeatures()));
			//return CVUtil.getXmlStringFromDocument(document);
			return modifiedDocument;
		}
		/*lender does not require any changes to STAR schema ECOUT. Return document as is*/
		return document;
	}
	
	/**
	 * @return
	 */
	private Map<String, String> getMapOfWebServiceFeaturesForLender(
			final List<FeatureConfigurationVO> listOfWebServiceFeatures) {
		logger.debug(
				"Entered getMapOfWebServiceFeaturesForLender method of CVDocumentManipulationServiceImpl class. listOfWebServiceFeatures contains {} items",
				listOfWebServiceFeatures.size());
		Map<String, String> map = listOfWebServiceFeatures.stream().collect(
				Collectors.toMap(FeatureConfigurationVO::getFeatureName, FeatureConfigurationVO::getFeatureValue));
		return map;

	}

}
