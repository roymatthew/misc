/**
 * 
 */
package com.ode.cv.service;

import java.math.BigInteger;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.EncryptionException;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.service.AuditJournalRepoService;
import com.ode.persistence.service.CreditJournalRepoService;
import com.ode.persistence.vo.AuditJournalVO;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
@Service
public class CVJournalServiceImpl implements ICVJournalService {

	private static final Logger logger = LogManager.getLogger(CVJournalServiceImpl.class);

	@Autowired
	CreditContractServiceImpl creditContractServiceImpl;
	@Autowired
	private CreditJournalRepoService creditJournalRepoService;
	@Autowired
	private AuditJournalRepoService auditJournalRepoService;

	@Override
	public Boolean addJournal(final CreditContractVO creditContractVO) throws Exception {
		
		logger.debug("Entered addJournal(creditContractVO) method of CVJournalServiceImpl class");

		if(creditContractVO.getListOfJournalObjects() != null && !creditContractVO.getListOfJournalObjects().isEmpty()) {
			creditContractVO.getListOfJournalObjects().stream().forEach(journalObject -> {
				try {
					addSingleJournalObject(creditContractVO, journalObject);
				} catch (EncryptionException e) {
					logger.error(e);
				} catch (Exception e) {
					logger.error(e);
				}
	
			});
		} else {
			logger.debug("No journals to save in list");
		}
		return Boolean.TRUE;
	}
	
	@Override
	public Boolean addJournal(final CreditContractVO creditContractVO, final JournalObjectVO journalObject) throws Exception {
		
		logger.debug("Entered addJournal(creditContractVO, journalObject) method of CVJournalServiceImpl class");
		try {
			addSingleJournalObject(creditContractVO, journalObject);
		} catch (EncryptionException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		return Boolean.TRUE;
	}

	@Override
	@Transactional(value = "transactionManager")
	public void addSingleJournalObject(final CreditContractVO creditContractVO, final JournalObjectVO journalObject) throws Exception {
		logger.debug("Processing Journal for transType: " + journalObject.getTransType());
		CreditJournalVO creditJournalVO = JournalFactory.createCreditJournal(journalObject, creditContractVO);
		creditJournalVO.setDealId(creditContractVO.getDeal().getDeDealId());
		creditJournalVO.setSequenceId(creditContractVO.getDeal().getCvSequenceId());
		logger.debug("Adding CreditJournal of transType: {}, dealId: {}, lenderId: {}", creditJournalVO.getTransType(), creditJournalVO.getDealId(), creditJournalVO.getPartnerId());
		creditJournalRepoService.saveOrUpdate(creditJournalVO);
		AuditJournalVO auditJournalVO = JournalFactory.createAuditJournal(journalObject, creditContractVO);
		logger.debug("Adding AuditJournal of transType: {}, dealId: {}, lenderId: {}", auditJournalVO.getTransType(), auditJournalVO.getDeDealId(), auditJournalVO.getPartnerId());
		auditJournalRepoService.saveOrUpdate(auditJournalVO);
	}

	@Override
	@Transactional(value = "transactionManager")
	public Boolean addSingleJournal(final CreditJournalVO creditJournalVO)
			throws Exception {
		logger.debug("Entered addSingleJournal() method of CVJournalServiceImpl class");
			try {
				logger.debug("Processing Journal for transType: " + creditJournalVO.getTransType());
				creditJournalRepoService.saveOrUpdate(creditJournalVO);
			} catch (EncryptionException e) {
				logger.error(e);
			} catch (Exception e) {
				logger.error(e);
			}
		return Boolean.TRUE;
	}
	
	
	public void addToListOfJournalObjects(final JournalObjectVO journalObject, final CreditContractVO creditContractVO)
	{
		logger.debug("Entered addToListOfJournalObjects() method of CVJournalServiceImpl class. TransType: " + journalObject.getTransType());
		creditContractVO.addToListOfJournalObjects(journalObject);
	}

	@Override
	@Transactional(value = "transactionManager")
	public CreditJournalVO getJournalForTransType(final DeDealVO deDealVO, final String transType)
			throws Exception {
		logger.debug("Entered getJournalForTransType() method of CVJournalServiceImpl class");
		CreditJournalVO creditJournalVO = null;
		creditJournalVO = creditJournalRepoService.getCreditJournalByDealAndTransType(deDealVO.getDeDealId(), deDealVO.getCvSequenceId(), transType);
		return creditJournalVO;
	}

	@Override
	@Transactional(value = "transactionManager")
	public Boolean addListOfJournals(final List<CreditJournalVO> listOfCreditJournals) {
		
		listOfCreditJournals.stream().forEach(creditJournalVO -> {
			try {
				logger.debug("Adding CreditJournal of transType: {}, dealId: {}, lenderId: {}", creditJournalVO.getTransType(), creditJournalVO.getDealId(), creditJournalVO.getPartnerId());
				creditJournalRepoService.saveOrUpdate(creditJournalVO);
				AuditJournalVO auditJournalVO = JournalFactory.createAuditJournal(creditJournalVO);
				logger.debug("Adding AuditJournal of transType: {}, dealId: {}, lenderId: {}", auditJournalVO.getTransType(), auditJournalVO.getDeDealId(), auditJournalVO.getPartnerId());
				auditJournalRepoService.saveOrUpdate(auditJournalVO);
			} catch (EncryptionException e) {
				logger.error(e);
			} catch (Exception e) {
				logger.error(e);
			}

		});
		return Boolean.TRUE;
	}


	@Override
	public String getCreditJournalXmlByLenderIdBodIdAndTrasType(final AccrVO accrVO, final String transType) throws Exception {
		logger.debug("Entered getCreditJournalXmlByLenderIdBodIdAndTrasType() method of CVJournalServiceImpl class");
		CreditJournalVO creditJournalVO = null;
		String xml = null;
		creditJournalVO = creditJournalRepoService.getMostRecentRecordByPartnerIdAndTransactionId(accrVO.getLenderId(), accrVO.getBodId(), transType);
		if (null != creditJournalVO) {
			logger.debug("Found credit journal for {}", transType);
			xml = EncryptionUtils.decryptText(creditJournalVO.getCrDataXml(), creditJournalVO.getEncryptionKeyId());
		}
		return xml;
	}
	
	@Override
	@Transactional(value = "transactionManager")
	public CreditJournalVO getCreditJournalByKey(final BigInteger cjKey) throws Exception {
		logger.debug("Entered getCreditJournalByKey() method of CVJournalServiceImpl class");
		
		CreditJournalVO creditJournalVO = creditJournalRepoService.findById(cjKey);
		if (null != creditJournalVO) {
			logger.debug("Found credit journal for key: {}", cjKey);
		} else {
			logger.debug("No credit journal found for key: {}", cjKey);
		}

		return creditJournalVO;
	}
}
