/**
 * 
 */
package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.cv.util.Constants;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.service.DeContractValidationRepoService;
import com.ode.persistence.service.DeDealRepoService;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
@Service
public class CVPersistenceServiceImpl implements ICVPersistenceService {

	private static final Logger logger = LogManager.getLogger(CVPersistenceServiceImpl.class);
	@Autowired
	private DeDealRepoService deDealRepoService;
	@Autowired
	private DeContractValidationRepoService deContractValidationRepoService;

	/**
	 * {@inheritDoc}
	 */
	@Transactional(value = "transactionManager")
	@Override
	public void saveCVData(final CreditContractVO creditContractVO, final DeDealVO dealVO, final DeContractValidationVO deContractValidationVO) {
		
		logger.debug("Entered saveCVDataAndJournals() method of CVPersistenceServiceImpl class");
		
		creditContractVO.getDeal().setDeDealId(dealVO.getDeDealId());
		creditContractVO.getDeal().setCvSequenceId(deContractValidationVO.getSequenceId());
		
		try {
			if(creditContractVO.getListOfJournalObjects() != null && !creditContractVO.getListOfJournalObjects().isEmpty()) {
				creditContractVO.getListOfJournalObjects().stream().forEach(journalObject -> {
	
					if (journalObject != null && journalObject.getTransType().equals(Constants.TRANS_TYPE_EC_ACK_IN)) {
						// contractVal record should have been set in CreditContractResponse.handle()
						if (deContractValidationVO != null) {
							// Set the account number from the ACCR to update the database
							if (null != creditContractVO.getAccr().getAccountNumber()) {
								logger.debug("Account Number is: {}", creditContractVO.getAccr().getAccountNumber());
								deContractValidationVO.setAccountNum(creditContractVO.getAccr().getAccountNumber());
								dealVO.setAccountNum(creditContractVO.getAccr().getAccountNumber());
							}
							if (null != creditContractVO.getAccr().getLenderSequenceNumber()) {
								logger.debug("Lender Seq Num is: {}", creditContractVO.getAccr().getLenderSequenceNumber());
								deContractValidationVO.setLenderSeqNum(creditContractVO.getAccr().getLenderSequenceNumber());
								dealVO.setLenderSeqNum(creditContractVO.getAccr().getLenderSequenceNumber());
							}
							
						}
					}
				});
			} else {
				logger.debug("No journals in list");
			}
			dealVO.setLenderDealerId(creditContractVO.getDeal().getLenderDealerId());
			dealVO.setCvSequenceId(deContractValidationVO.getSequenceId());
			deDealRepoService.saveOrUpdate(dealVO);
			deContractValidationRepoService.saveOrUpdate(deContractValidationVO);

		} catch (final Exception e) {
			logger.error(e);
		}

	}

}
