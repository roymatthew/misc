/**
 *
 */
package com.ode.cv.service;

import com.ode.cv.context.GenericCommonObjectBuilder;
import com.ode.cv.context.StarCommonObjectBuilder;
import com.ode.cv.data.translator.GcvToStarProductTranslator;
import com.ode.cv.normalizer.util.XmlNormalizer;
import com.ode.cv.util.ApplpTransformer;
import com.ode.cv.util.Constants;
import com.ode.cv.util.LpTransformerTemplateFactory;
import com.ode.cv.util.MessageProcessingUtil;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.entity.DeDmsDestination;
import com.ode.persistence.service.DeLenderRepoService;
import com.ode.persistence.vo.DeLenderVO;
import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.TimeZone;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author snimma
 *
 */
@Service
public class CVRequestTranslationServiceImpl extends ApplpTransformer
implements ICVRequestTranslationService, Constants {

	private static final Logger logger = LogManager.getLogger(CVRequestTranslationServiceImpl.class);

	private final static String XML_START = "<data>";
	private final static String XML_END = "</data>";

	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;
	@Autowired
	private GcvToStarProductTranslator gcvToStarProductTranslator;
	@Autowired
	private XmlNormalizer xmlNormalizer;

	@Autowired
	CVTransmitClient cvTransmitClient;

	@Autowired
	private LpTransformerTemplateFactory appXSLFactory;

	@Autowired
	private GenericCommonObjectBuilder genericCommonObjectBuilder;

	@Autowired
	private StarCommonObjectBuilder starCommonObjectBuilder;

	@Autowired
	private DeLenderRepoService deLenderRepoService;
	
	@Autowired
	private IDmsService dmsService;

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void createContractout(final CreditContractVO creditContractVO, final String stylesheetId,
			final String ecinXml) throws Exception {
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("Entered createContractout() with stylesheetId: " + stylesheetId);
		String Temp_XML_Data = null;

		String stylesheetKey = getXslCreditContract(creditContractVO, stylesheetId, Constants.PRODUCT_CV);
		if (productConfigurationLookupService.cvMessageProcessingContainsValue(saxon)) {
			stylesheetKey = saxon + stylesheetKey;
		}
		logger.debug("Trying to obtain transformer with stylesheetKey: " + stylesheetKey);
		Transformer transformer = getTransformer(stylesheetKey);
		if (null != transformer) {
			logger.debug("Obtained Transformer");
		}

		transformer.clearParameters();

		transformer.setParameter("environment", getEnvironment());

		//let's disable static and message processing params
		/*		// Add any static parms to be passed to style sheet
		addStaticParmsToTransformer(creditContractVO, transformer);
		// Add any message processing parms to be passed to style sheet
		addMessageProcessingParmsToTransformer(creditContractVO, Temp_XML_Data, transformer, ecinXml);*/


		boolean doGcvProductTranslation = false;
		if (productConfigurationLookupService.isFeatureConfigurationAvailable("gcvProductTranslation", creditContractVO.getDealerInfo().getDspId()))
		{
			doGcvProductTranslation = true;
		}
		if (null == Temp_XML_Data) {
			Temp_XML_Data = XML_START + ecinXml + XML_END;
		}
		/* set dealer party id */
		String dealerPartyId = null;
		try {
			dealerPartyId = dmsService.getDealerPartyId(creditContractVO);	
		} catch (Exception e) {
			logger.debug("Exception occured trying to fetch dealerPartyId");
		}		
		if (StringUtils.isNotBlank(dealerPartyId)) {
			transformer.setParameter(Constants.ACCOUNT_ID, dealerPartyId);
			logger.debug("accountId parameter was set on transformer with value: {}", dealerPartyId);
		}
		else
		{
			logger.debug("Could not find dealer party id for dealerId: {} and lenderId: {}",
					creditContractVO.getDealerInfo().getDealerId(), creditContractVO.getPartnerInfo().getLenderId());
		}
		// Form Translation Needs for rr-vci-cv & rr-mb-cv, ERA only
		if (null != creditContractVO.getContractFormNumber()) {
			transformer.setParameter("contractFormNumber", creditContractVO.getContractFormNumber());
		}
		if (null != creditContractVO.getContractFormRevisionDate()) {
			transformer.setParameter("contractFormRevisionDate",
					STAR_DATE_FORMAT.format(creditContractVO.getContractFormRevisionDate()));
		}

		if (null != creditContractVO.getVehicleModelDescription()) {
			transformer.setParameter("vehicleModelDescription", creditContractVO.getVehicleModelDescription());
		}

		// State Group required for adp-mb
		if (null != creditContractVO.getStateGroup()) {
			transformer.setParameter("StateGroup", creditContractVO.getStateGroup());
		}

		// Set the CG Datatimestamp
		if (null != creditContractVO.getTransformerDateTime()) {

			dfWithT.setTimeZone(TimeZone.getTimeZone("GMT"));
			transformer.setParameter("dateTime", dfWithT.format(new Date()));
		} else {
			transformer.setParameter("dateTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date()));
		}

		// Set the tranId
		transformer.setParameter("tranId", creditContractVO.getDocumentId());

		// Set the lenderName
		logger.debug(
				"LenderId to get lendername from DeLender table: " + creditContractVO.getPartnerInfo().getLenderId());
		DeLenderVO deLenderVO = deLenderRepoService.getByLenderId(creditContractVO.getPartnerInfo().getLenderId());
		if (null != deLenderVO) {
			transformer.setParameter("lenderName", deLenderVO.getLenderName());
		} else {
			logger.debug("Could not find lenderId in DeLender table.");
		}
		
		/*Destination Name Code based on Lender/RouteOneFlag set in CVDataTranslationService*/
		transformer.setParameter("destinationNameCode", creditContractVO.getDestinationNameCode());

		if (null != creditContractVO.getAttachmentZip()) {
			transformer.setParameter("attachmentZip", creditContractVO.getAttachmentZip());
			transformer.setParameter("attachmentFileName", creditContractVO.getAttachmentFileName());
		}

		if (null != creditContractVO.getAttachmentFileName()) {
			Document doc = getNamespaceAwareDocument(Temp_XML_Data);
			NodeList contentList = doc.getElementsByTagNameNS(
					"http://www.starstandards.org/webservices/2005/10/transport", CV_PCC_CONTENT_ELEMENT);
			if (null != contentList && contentList.getLength() > 0) {
				for (int j = 0; j < contentList.getLength(); j++) {
					Node node = contentList.item(j);
					Element el = (org.w3c.dom.Element) node;
					if (el.hasAttribute(EDOCS_PCC_CONTENT_ELEMENT_ATTRIBUTE_ID)
							&& el.getAttribute(EDOCS_PCC_CONTENT_ELEMENT_ATTRIBUTE_ID)
							.equals(EDOCS_ATTACHMENT_CONTENT_ELEMENT)) {
						node.getParentNode().removeChild(node);
					}
				}
			}
			Temp_XML_Data = getStringFromDocument(doc);
		}

		if (null == creditContractVO.getAttachmentZip()) {
			// do not normalize for distributions
			Temp_XML_Data = xmlNormalizer.normalizeEcin(Temp_XML_Data, creditContractVO.getCcvInputVO());
			if (null != Temp_XML_Data && logger.isDebugEnabled()) {
				logger.debug("Successfuly normalized ECIN. Lenght of xml string: {}", Temp_XML_Data.length());
			}
		} else {
			logger.debug("Data Translation not required for distribution (ECEDOCIN)");
		}

		buildCommonObjectFromDocument(creditContractVO, ecinXml);
		// call transformer
		StringWriter xmlOutSW = new StringWriter();
		StreamResult outputResult = new StreamResult(xmlOutSW);
		logger.debug("Calling transformer to transform Temp_XML_Data to lenderRequestXml");
		transformer.transform(new StreamSource(new ByteArrayInputStream(Temp_XML_Data.getBytes())), outputResult);

		String lenderRequestXml = xmlOutSW.toString();
		if (null == lenderRequestXml || lenderRequestXml.length() == 0) {
			logger.debug("lenderRequestXml is null/empty");
		}

		logger.debug("doGcvProductTranslation: {}, dspId: {}", doGcvProductTranslation, creditContractVO.getDealerInfo().getDspId());
		if (doGcvProductTranslation && creditContractVO.getDealerInfo().getDspId().equalsIgnoreCase("AD")) {
			// String dealerId = creditContractVO.getDealerInfo().getDealerId();
			// String financeType = creditContractVO.getFinanceType();
			logger.debug("Calling GcvToStarProductTranslator..");
			lenderRequestXml = gcvToStarProductTranslator.translateGcvToStarProducts(creditContractVO, ecinXml,
					lenderRequestXml);
		}
		logger.debug("Setting lenderRequestXml to creditContractVO");
		creditContractVO.setLenderRequestXml(lenderRequestXml);

		final LocalDateTime end = LocalDateTime.now();
		logger.debug(
				"Translation of CV to lender format took " + ChronoUnit.MILLIS.between(start, end) + " milliseconds");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public void createContractConfOut(final CreditContractVO creditContractVO) throws Exception {
		logger.debug("Entered createContractConfOut()");
		boolean checkHttpStatus = false;
		String temp_Xml_Data = "";

		if (MessageProcessingUtil.containsValue(creditContractVO.getMessageProcessing(), "checkHttpStatus")) {
			checkHttpStatus = true;
		}

		if (!checkHttpStatus && null != creditContractVO.getLenderResponseXml()
				&& !creditContractVO.getLenderResponseXml().equals("")
				&& creditContractVO.getLenderResponseXml().startsWith("<")
				&& creditContractVO.getLenderResponseMessage().getStatusCode() == 200) {
			Document document = getDocument(creditContractVO.getLenderResponseXml());
			creditContractVO.getCaContext().getConfirmBod()
			.setSourceConfBod(XPathAPI.eval(document, getXPath_SourceConfBod()).toString());
		}

		Transformer confBodTransformer = getTransformer(getXslCreditContractConfirmationBod(creditContractVO));
		confBodTransformer.clearParameters();

		// When DMS=='AD', add these parameters to stylesheet: username, password, locationId, serviceId
		if (Constants.CDK_DMS_ID.equalsIgnoreCase(creditContractVO.getDeal().getDmsId())) {
			DeDmsDestination deDmsDestination = productConfigurationLookupService.getDeDmsDestination(
					Constants.CDK_DMS_ID, Constants.APPLICATION_CV, Constants.PRODUCT_CV);
			String locationId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
					Constants.CDK_DMS_ID, Constants.ACCR, Constants.LOCATION_ID);
			String serviceId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
					Constants.CDK_DMS_ID, Constants.ACCR, Constants.SERVICE_ID);

			confBodTransformer.setParameter("username", null == deDmsDestination || null == deDmsDestination.getWsUsername() ?
					"" : deDmsDestination.getWsUsername());
			confBodTransformer.setParameter("password", null == deDmsDestination || null == deDmsDestination.getWsPassword() ?
					"" : deDmsDestination.getWsPassword());
			confBodTransformer.setParameter("locationId", null == locationId ? "" : locationId);
			confBodTransformer.setParameter("serviceId", null == serviceId ? "" : serviceId);
		}

		confBodTransformer.setParameter("dealerId", null == creditContractVO.getDealerInfo().getDealerId() ? ""
				: creditContractVO.getDealerInfo().getDealerId());
		confBodTransformer.setParameter("lenderId", null == creditContractVO.getPartnerInfo().getLenderId() ? ""
				: creditContractVO.getPartnerInfo().getLenderId());
		confBodTransformer.setParameter("documentId",
				null == creditContractVO.getDocumentId() ? "" : creditContractVO.getDocumentId());
		confBodTransformer.setParameter("systemId", null == creditContractVO.getDealerInfo().getSystemId() ? ""
				: creditContractVO.getDealerInfo().getSystemId());

		if (checkHttpStatus) {
			confBodTransformer.setParameter("checkHttpStatus", "true");
			if (null != creditContractVO.getLenderResponseMessage()) {
				if (creditContractVO.getLenderResponseMessage().getStatusCode() == 200) {
					confBodTransformer.setParameter("errorCode", Constants.APP_SUCCESS_MSG_ID);
					confBodTransformer.setParameter("errorMessage", Constants.Event_Success);
				}
				confBodTransformer.setParameter("httpStatusCode",
						String.valueOf(creditContractVO.getLenderResponseMessage().getStatusCode()));
				if (null != creditContractVO.getLenderResponseMessage().getResponseXml()) {
					confBodTransformer.setParameter("httpStatusMessage",
							creditContractVO.getLenderResponseMessage().getResponseXml());
				} else {
					confBodTransformer.setParameter("httpStatusMessage", "Unknown");
				}
			}
		}

		if (!checkHttpStatus) {

			if (!(null == creditContractVO.getSoapFaultMessage()
					|| creditContractVO.getSoapFaultMessage().equals(""))) {

				confBodTransformer.setParameter("errorCode", creditContractVO.getSoapFaultCode());

				// MB Specific confOut errors
				if (MessageProcessingUtil.containsValue(creditContractVO.getMessageProcessing(),
						"lenderSpecificConfOutErrorsv1")) {

					if (creditContractVO.getSoapFaultMessage().indexOf(MBFVALIDATION_CONSTANT) > 0) {
						confBodTransformer.setParameter("errorMessage",
								creditContractVO.getSoapFaultMessage().substring(MBFVALIDATION_CONSTANT.length(),
										creditContractVO.getSoapFaultMessage().length()));
						creditContractVO.getCaContext().getConfirmBod()
						.setSourceConfBod(creditContractVO.getPartnerInfo().getLenderId());

					} else {
						confBodTransformer.setParameter("errorMessage", creditContractVO.getSoapFaultMessage());
						creditContractVO.getCaContext().getConfirmBod().setSourceConfBod("OD");
					}

				} else {
					confBodTransformer.setParameter("errorMessage", creditContractVO.getSoapFaultMessage());
					creditContractVO.getCaContext().getConfirmBod().setSourceConfBod("OD");
				}

			} else if (null != creditContractVO.getAppMsg()) {
				confBodTransformer.setParameter("errorCode", creditContractVO.getAppMsg().getMessageID());
				confBodTransformer.setParameter("errorMessage",
						null != creditContractVO.getAppMsg().getMessage() ? creditContractVO.getAppMsg().getMessage()
								: "Message sent to Lender");
				creditContractVO.getCaContext().getConfirmBod()
				.setSourceConfBod(creditContractVO.getAppMsg().getMessageID().equalsIgnoreCase("I0000")
						? creditContractVO.getPartnerInfo().getLenderId()
								: "OD");

				// if the lender is configured with eDocsDistribution and
				// ValMessageCode/ValMessageDesc have values, send those.
				String messageCode = creditContractVO.getValMessageCode();
				String messageDesc = creditContractVO.getValMessageDesc();
				boolean eDocsDistributionIsConfigured = productConfigurationLookupService
						.cvMessageProcessingContainsValue("eDocsDistribution");
				if (null != messageCode && !messageCode.isEmpty() && null != messageDesc && !messageDesc.isEmpty()
						&& eDocsDistributionIsConfigured) {
					confBodTransformer.setParameter("errorCode", creditContractVO.getValMessageCode());
					confBodTransformer.setParameter("errorMessage", creditContractVO.getValMessageDesc());
				}

			} else {
				confBodTransformer.setParameter("errorCode", "Unknown");
				confBodTransformer.setParameter("errorMessage", "Unknown");
				creditContractVO.getCaContext().getConfirmBod().setSourceConfBod("OD");
			}
		}

		creditContractVO.getCaContext().getConfirmBod()
		.setStatusCode((String) confBodTransformer.getParameter("errorCode"));
		creditContractVO.getCaContext().getConfirmBod()
		.setMessageDescription((String) confBodTransformer.getParameter("errorMessage"));
		confBodTransformer.setParameter("dateTime",
				new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date()));

		buildCommonObjectFromDocument(creditContractVO, creditContractVO.getLenderResponseXml());

		String lenderResponse = creditContractVO.getLenderResponseXml();
		String requestXml = creditContractVO.getRequestXML().trim();
		if (null != lenderResponse && lenderResponse.indexOf("<ConfirmBOD") > 0) {
			int start = lenderResponse.indexOf("<ConfirmBOD");
			int end = lenderResponse.indexOf("</ConfirmBOD>") + 13;
			temp_Xml_Data = XML_START + requestXml + lenderResponse.substring(start, end) + XML_END;
		} else if (null != lenderResponse && lenderResponse.indexOf("<ProcessBDKTransResponse") > 0) {
			int start = lenderResponse.indexOf("<ProcessBDKTransResponse");
			int end = lenderResponse.indexOf("</ProcessBDKTransResponse>");
			if (end == -1) {
				// ending tag not found. look for end of opening tag
				end = lenderResponse.indexOf("/>", start) + 2;
				if (end == -1) {
					// end of opening tag not found either, set end position at the very end
					end = lenderResponse.length();
				}
			} else {
				// move ending position to account for length of ending tag
				end += 26;
			}
			temp_Xml_Data = XML_START + requestXml + lenderResponse.substring(start, end) + XML_END;
		} else {
			temp_Xml_Data = XML_START + requestXml + XML_END;
		}
		StringWriter strWriter = new StringWriter();
		StreamResult streamResult = new StreamResult(strWriter);
		confBodTransformer.transform(new StreamSource(new ByteArrayInputStream(temp_Xml_Data.getBytes())),
				streamResult);
		creditContractVO.setConfoutXml(strWriter.toString());
	}

	/**
	 * @param creditContractVO
	 * @param stylesheetId
	 * @return
	 */
	private String getXslCreditContract(final CreditContractVO creditContractVO, final String stylesheetId, final String productId) {
		logger.debug("Entered getXslCreditContract() for styleSheetId: " + stylesheetId);
		String stylesheet = productConfigurationLookupService.getDmsFeatureConfigurationValue(
				creditContractVO.getDealerInfo().getDspId(), productId, Constants.STYLESHEET);
		if (null == stylesheet) {
			logger.warn("stylesheet with id:{} not found", stylesheetId);
		}
		return stylesheet;
	}

	@SuppressWarnings("rawtypes")
	private String getXslCreditContractConfirmationBod(final CreditContractVO creditContractVO) {
		logger.debug("Entered getXslCreditContractConfirmationBod() ");
		String stylesheet = productConfigurationLookupService.getDmsFeatureConfigurationValue(
				creditContractVO.getDealerInfo().getDspId(), Constants.ACCR, Constants.STYLESHEET);
		return stylesheet;
	}

	/**
	 * @param creditContractVO
	 * @param ecinXml
	 * @throws Exception
	 */
	private void buildCommonObjectFromDocument(final CreditContractVO creditContractVO, final String ecinXml)
			throws Exception {
		logger.debug("Entered buildCommonObjectFromDocument() method of CVRequestTranslationServiceImpl class");
		Document document = getDocument(ecinXml);
		if (creditContractVO.isGenericCreditContract() == true) {
			genericCommonObjectBuilder.buildCommonObject(creditContractVO, document);
		} else {
			starCommonObjectBuilder.buildCommonObject(creditContractVO, document);
		}
	}

	/**
	 * @param doc
	 * @return
	 */
	public String getStringFromDocument(final Document doc) {
		logger.debug("Entered getStringFromDocument() ");
		try {
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
					org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (TransformerException ex) {
			logger.error("Exception in getStringFromDocument() method of CVRequestTranslationServiceImpl class", ex);
			return null;
		}
	}

	/**
	 * @param stylesheetKey
	 * @return
	 * @throws Exception
	 */
	protected Transformer getTransformer(String stylesheetKey) throws Exception {
		logger.debug(
				"Entered getTransformer of CVRequestTranslationServiceImpl class. stylesheetKey: " + stylesheetKey);
		return appXSLFactory.getTransformer(stylesheetKey);
	}
	
	/* (non-Javadoc)
	 * @see com.ode.cv.service.ICVRequestTranslationService#createContractoutRE(com.ode.cv.vo.CreditContractVO, java.lang.String, java.lang.String)
	 */
	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void createContractoutRE(final CreditContractVO creditContractVO, final String stylesheetId,
			final String ecinXml) throws Exception {
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("Entered createContractoutRE() with stylesheetId: " + stylesheetId);
		String Temp_XML_Data = null;

		String stylesheetKey = getXslCreditContract(creditContractVO, stylesheetId, Constants.PRODUCT_RE);
		if (productConfigurationLookupService.cvMessageProcessingContainsValue(saxon)) {
			stylesheetKey = saxon + stylesheetKey;
		}
		logger.debug("Trying to obtain transformer with stylesheetKey: " + stylesheetKey);
		Transformer transformer = getTransformer(stylesheetKey);
		if (null != transformer) {
			logger.debug("Obtained Transformer");
		}

		transformer.clearParameters();
		transformer.setParameter("environment", getEnvironment());		
		transformer.setParameter("destinationNameCode", Constants.DESTINATION_CODE_VCF);
		if (Constants.LENDER_VCF.equalsIgnoreCase(creditContractVO.getPartnerInfo().getLenderId())
				|| Constants.LENDER_VOL.equalsIgnoreCase(creditContractVO.getPartnerInfo().getLenderId())) {
			transformer.setParameter(Constants.PARM_NAME_FIN_COMP_PARTY_ID, Constants.LENDER_VCF);
		} else {
			transformer.setParameter(Constants.PARM_NAME_FIN_COMP_PARTY_ID, creditContractVO.getPartnerInfo().getLenderId());
		}

		//let's disable static and message processing params
		/*		// Add any static parms to be passed to style sheet
		addStaticParmsToTransformer(creditContractVO, transformer);
		// Add any message processing parms to be passed to style sheet
		addMessageProcessingParmsToTransformer(creditContractVO, Temp_XML_Data, transformer, ecinXml);*/


		boolean doGcvProductTranslation = false;
		if (productConfigurationLookupService.isFeatureConfigurationAvailable("gcvProductTranslation", creditContractVO.getDealerInfo().getDspId()))
		{
			doGcvProductTranslation = true;
		}
		if (null == Temp_XML_Data) {
			Temp_XML_Data = XML_START + ecinXml + XML_END;
		}

		String dealerPartyId = null;
		try {
			dealerPartyId = dmsService.getDealerPartyId(creditContractVO);	
		} catch (Exception e) {
			logger.debug("Exception occured trying to fetch dealerPartyId");
		}		
		if (StringUtils.isNotBlank(dealerPartyId)) {
			transformer.setParameter(Constants.ACCOUNT_ID, dealerPartyId);
			logger.debug("accountId parameter was set on transformer with value: {}", dealerPartyId);
		}
		else
		{
			logger.debug("Could not find dealer party id for dealerId: {} and lenderId: {}",
					creditContractVO.getDealerInfo().getDealerId(), creditContractVO.getPartnerInfo().getLenderId());
		}

		// Form Translation Needs for rr-vci-cv & rr-mb-cv, ERA only
		if (null != creditContractVO.getContractFormNumber()) {
			transformer.setParameter("contractFormNumber", creditContractVO.getContractFormNumber());
		}
		if (null != creditContractVO.getContractFormRevisionDate()) {
			transformer.setParameter("contractFormRevisionDate",
					STAR_DATE_FORMAT.format(creditContractVO.getContractFormRevisionDate()));
		}

		if (null != creditContractVO.getVehicleModelDescription()) {
			transformer.setParameter("vehicleModelDescription", creditContractVO.getVehicleModelDescription());
		}

		// State Group required for adp-mb
		if (null != creditContractVO.getStateGroup()) {
			transformer.setParameter("StateGroup", creditContractVO.getStateGroup());
		}

		// Set the CG Datatimestamp
		if (null != creditContractVO.getTransformerDateTime()) {

			dfWithT.setTimeZone(TimeZone.getTimeZone("GMT"));
			transformer.setParameter("dateTime", dfWithT.format(new Date()));
		} else {
			transformer.setParameter("dateTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date()));
		}

		// Set the tranId
		transformer.setParameter("tranId", creditContractVO.getDocumentId());

		// Set the lenderName
		logger.debug(
				"LenderId to get lendername from DeLender table: " + creditContractVO.getPartnerInfo().getLenderId());
		DeLenderVO deLenderVO = deLenderRepoService.getByLenderId(creditContractVO.getPartnerInfo().getLenderId());
		if (null != deLenderVO) {
			transformer.setParameter("lenderName", deLenderVO.getLenderName());
		} else {
			logger.debug("Could not find lenderId in DeLender table.");
		}

		// do not normalize for distributions
		Temp_XML_Data = xmlNormalizer.normalizeEcin(Temp_XML_Data, creditContractVO.getCcvInputVO());
		if (null != Temp_XML_Data) {
			logger.debug("Successfuly normalized ECIN. Lenght of xml string: {}", Temp_XML_Data.length());
		}

		buildCommonObjectFromDocument(creditContractVO, ecinXml);
		// call transformer
		StringWriter xmlOutSW = new StringWriter();
		StreamResult outputResult = new StreamResult(xmlOutSW);
		logger.debug("Calling transformer to transform Temp_XML_Data to lenderRequestXml");
		transformer.transform(new StreamSource(new ByteArrayInputStream(Temp_XML_Data.getBytes())), outputResult);

		String lenderRequestXml = xmlOutSW.toString();
		if (null == lenderRequestXml || lenderRequestXml.length() == 0) {
			logger.debug("lenderRequestXml is null/empty");
		}
		else
		{
			logger.debug("ECOUT after stylesheet translation: {}", lenderRequestXml);
		}

		logger.debug("doGcvProductTranslation: {}, dspId: {}", doGcvProductTranslation, creditContractVO.getDealerInfo().getDspId());
		if (doGcvProductTranslation && creditContractVO.getDealerInfo().getDspId().equalsIgnoreCase("AD")) {
			logger.debug("Calling GcvToStarProductTranslator..");
			lenderRequestXml = gcvToStarProductTranslator.translateGcvToStarProducts(creditContractVO, ecinXml,
					lenderRequestXml);
		}
		logger.debug("Setting lenderRequestXml to creditContractVO");
		creditContractVO.setLenderRequestXml(lenderRequestXml);
		logger.debug("CV_OLDRE_ECOUT: {}", lenderRequestXml);
		final LocalDateTime end = LocalDateTime.now();
		logger.debug(
				"Translation of VCF ECIN to CV_OLDRE_ECOUT " + ChronoUnit.MILLIS.between(start, end) + " milliseconds");
	}

}
