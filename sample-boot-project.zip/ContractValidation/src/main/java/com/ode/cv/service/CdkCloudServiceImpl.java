package com.ode.cv.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ode.cv.entity.DigitalDealJacket;
import com.ode.cv.factory.JournalFactory;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.messaging.CdkCloudRequestMessageProducer;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import com.ode.cv.vo.DirectRenderResponseQueueMessageVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.ExpressionVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.service.CreditJournalRepoService;
import com.ode.persistence.service.DeCdkCloudCvXrefRepoService;
import com.ode.persistence.service.DeContractValidationRepoService;
import com.ode.persistence.service.DealerPpNvpRepoService;
import com.ode.persistence.service.DealerRepoService;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeCdkCloudCvXrefVO;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.DealerPpNvpVO;
import com.ode.persistence.vo.DealerVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import javax.jms.JMSException;
import java.io.File;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author rmathew
 *
 */
@Service
public class CdkCloudServiceImpl implements ICdkCloudService {

	private static final Logger logger = LogManager.getLogger(CdkCloudServiceImpl.class);

	@Autowired
	private CdkCloudRequestMessageProducer cdkCloudRequestMessageProducer;

	@Autowired
	private CreditJournalRepoService creditJournalRepoService;
	
	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;

	@Autowired
	private PCCXmlParser pccXmlParser;
	
	@Autowired
	private IDealService dealService;

	@Autowired
	private IErrorLogService errorLogService;
	
	@Autowired
	private DeCdkCloudCvXrefRepoService deCdkCloudCvXrefRepoService;

	@Autowired
	private ICVDocumentManipulationService cvDocumentManipulationService;

	@Autowired
	private IRouteOneService routeOneService;

	@Autowired
	private ILenderService lenderService;

	@Autowired
	private DealerRepoService dealerRepoService;

	@Autowired
	private DeContractValidationRepoService deContractValidationRepoService;

	@Autowired
	private DealerPpNvpRepoService dealerPpNvpRepoService;

	@Autowired
	private ApplpEventHandler appCVEventHandler;
	
	@Autowired
	private IAccrService accrService;
	
	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;

	@Autowired
	private IDmsService dmsService;

	@Autowired
	private CVTransmitClient cvTransmitClient;

	private static final String XML_PROLOG = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

	@Override
	public void prepareAndSendCdkCloudRequest(final String ecout2Xml, final DeDealVO deDealVO, CreditContractVO creditContractVO) throws JMSException, Exception {

		logger.debug(
				"Entered prepareAndSendCdkCloudRequest() method of CdkCloudServiceImpl.class. DealId: {}, DealerId: {}, LenderId: {}",
				deDealVO.getDmsDealNum(), deDealVO.getDmsDealerId(), deDealVO.getLenderId());
		final StringBuilder cdkCloudRequestXmlBuilder = new StringBuilder();
		Document ecoutDocument = null;
		if (Constants.DESTINATION_CODE_ROUTE_ONE.equals(creditContractVO.getDestinationNameCode()))  {
			ecoutDocument = CVUtil.generateDocumentFromElement(cvRequestXmlParser.getDocument(ecout2Xml),
					"RouteOneProcessCreditContract", "ProcessCreditContract");
		} else {
			ecoutDocument = CVUtil.restructureCVDocumentForLenderCdkCloudRequest(cvRequestXmlParser.getDocument(ecout2Xml));
		}		
		String reformattedEcoutXml = CVUtil.getXmlStringFromDocument(ecoutDocument);
		String ecoutXmlWithoutProlog = reformattedEcoutXml.replace(XML_PROLOG, "");
		cdkCloudRequestXmlBuilder.append("<ContractValidation>").append("<DeDealId>").append(deDealVO.getDeDealId())
				.append("</DeDealId>").append("<ECOUT>").append(ecoutXmlWithoutProlog).append("</ECOUT>")
				.append("</ContractValidation>");
		logger.debug("Message being written to CDK.CLOUD.REQ.QUEUE: {}", cdkCloudRequestXmlBuilder.toString());
		cdkCloudRequestMessageProducer.sendMessage(cdkCloudRequestXmlBuilder.toString());
	}
	
	@Override
	public String notifyCDKCloudService(final DeDealVO deDealVO) throws JMSException, Exception {
		
		logger.debug(
				"Entered notifyCDKCloudService() method of CdkCloudServiceImpl.class. DealId: {}, DealerId: {}, LenderId: {}",
				deDealVO.getDmsDealNum(), deDealVO.getDmsDealerId(), deDealVO.getLenderId());
		String validationResults = deDealVO.getCvStatus();
		if (Constants.PASSED.equalsIgnoreCase(validationResults)) {
			CreditJournalVO ecOut2 = cvJournalService.getJournalForTransType(deDealVO, Constants.TRANS_TYPE_EC_OUT2);
			DigitalDealJacket digitalDealJacket = new DigitalDealJacket();
			digitalDealJacket.setKey(ecOut2.getCjKey());
			digitalDealJacket.setMessageType("DDJ-TRIGGER");
			String message = CVUtil.getJsonForObject(digitalDealJacket);
			cdkCloudRequestMessageProducer.sendMessage(message);
			return message;
		} else {
			logger.debug("ValidationResults are not Passed. So, message is not written to the CDKCloudRequestMessageProducer");
			removeContractPackageFile(deDealVO);
			return null;
		}
	}

	@Override
	public void processCdkCloudJsonResponse(final String queueMsg) {
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("Entered processCdkCloudJsonResponse method of CdkCloudServiceImpl.class");
		logger.debug("***** Start CDK Cloud Response Json processing at: {} *****", start);
		DeDealVO deDealVO = null;
		DirectRenderResponseQueueMessageVO directRenderResponseQueueMessage = null;
		String transactionId = null;
		try {
			logger.debug("Response queue for trans type {} acquired, marshalling json...",
					Constants.TRANS_TYPE_CV_CLOUDQIN);			
			directRenderResponseQueueMessage = new ObjectMapper().readValue(queueMsg,
					DirectRenderResponseQueueMessageVO.class);
			// GetECOUT2 and DeDeal
			BigInteger cjKey = directRenderResponseQueueMessage.getEcout2Key();
			logger.debug("CreditJournal CJ Key found in json: {}", cjKey);
			CreditJournalVO ecOut2CreditJournalVO = creditJournalRepoService.findById(cjKey);
			transactionId = ecOut2CreditJournalVO.getTransactionId();
			logger.debug("DeDealId determined for message: {}", ecOut2CreditJournalVO.getDealId());
			String ecout2Xml = EncryptionUtils.decryptText(ecOut2CreditJournalVO.getCrDataXml(),
					ecOut2CreditJournalVO.getEncryptionKeyId());
			deDealVO = dealService.findDeDealById(ecOut2CreditJournalVO.getDealId());
			String lenderId = deDealVO.getLenderId();
			logger.debug("lenderId: {}", lenderId);
			productConfigurationLookupService.loadConfigurations(lenderId);
			// Find dealer
			DealerVO deDealer = null;
			String dealerId = deDealVO.getDmsDealerId();
			deDealer = dealerRepoService.getByDealerId(dealerId);
			DealerPpNvpVO dealerPpNvpVO = new DealerPpNvpVO();
			dealerPpNvpVO.setDealerId(dealerId);
			dealerPpNvpVO.setPartnerId(lenderId);
			dealerPpNvpVO.setProductId("CV");
			dealerPpNvpVO.setParmName("ACCOUNTID1");
			String dealerPartyId = dealerPpNvpRepoService.getParmValueByParmNameLenderDealerAndProduct(dealerPpNvpVO);
			logger.error("dealerPartyId: {}", dealerPartyId);
			// get DE_CONTRACT_VALIDATION
			DeContractValidationVO deContractValidationVO = null;
			try {
				deContractValidationVO = deContractValidationRepoService
						.selectDeContractValidation(deDealVO.getDeDealId(), ecOut2CreditJournalVO.getSequenceId());
			} catch (final Exception e) {
				logger.error("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}",
						deDealVO.getDeDealId(), ecOut2CreditJournalVO.getSequenceId(), e.getMessage());
			}
			if (null != deContractValidationVO) {
				deContractValidationVO.setStatusTs((new java.sql.Timestamp(new Date().getTime())));
			} else {
				logger.debug("Could not find DeContractValidationVO with dealId: {}, sequenceId: {}",
						deDealVO.getDeDealId(), ecOut2CreditJournalVO.getSequenceId());
			}
			CreditContractVO creditContractVO = VOFactory
					.createCreditContractFromExistingCreditJournal(ecOut2CreditJournalVO);
			if (null != deDealer) {
				creditContractVO.getDealerInfo().setDealerId(deDealer.getDealerId());
				creditContractVO.getDealerInfo().setSystemId(deDealer.getSystemId());
				creditContractVO.getDealerInfo()
						.setStoreNumber(deDealer.getStoreId() == null ? deDealer.getDealerId() : deDealer.getStoreId());
				creditContractVO.getDealerInfo().setDealerPartyId(dealerPartyId);
				creditContractVO.getDealerInfo().setDspId(deDealer.getDspId());
			}
			creditContractVO.setDeal(new DeDealBo());
			creditContractVO.getDeal().setDmsDealerId(deDealVO.getDmsDealerId());
			creditContractVO.getDeal().setLenderId(lenderId);
			creditContractVO.getDeal().setDeDealId(deDealVO.getDeDealId());
			creditContractVO.getDeal().setCvSequenceId(deDealVO.getCvSequenceId());
			creditContractVO.getPartnerInfo().setLenderId(lenderId);
			// Find authorization id
			String authorizationId = pccXmlParser.getAuthorizationIdFromEcout2(ecout2Xml);
			logger.debug("authorizationId from ecout2 xml: {}", authorizationId);
			DeContractValidationBo contractValidationBO = new DeContractValidationBo();
			contractValidationBO.setAuthorizationId(authorizationId);
			creditContractVO.setContractValidation(contractValidationBO);
			creditContractVO.setDocumentId(transactionId);
			creditContractVO.setFinanceType(deDealVO.getFinanceType());
			creditContractVO.setUserId(ecOut2CreditJournalVO.getUserId());
			creditContractVO.setApplicationSource(ecOut2CreditJournalVO.getApplicationSource());
			creditContractVO.setDeliverySource(ecOut2CreditJournalVO.getDeliverySource());		
			AppMessage successAppMessage = appCVEventHandler.handleEvents(Constants.Event_Success);		
			JournalObjectVO cdkCloudQInJournalObject = JournalFactory
					.createJournalObject(Constants.TRANS_TYPE_CV_CLOUDQIN, successAppMessage, queueMsg);
			creditContractVO.addToListOfJournalObjects(cdkCloudQInJournalObject);
			// confirm sub-total sections exist in the json
			if (directRenderResponseQueueMessage == null
					|| directRenderResponseQueueMessage.getDirectRenderResponseList() == null
					|| directRenderResponseQueueMessage.getDirectRenderResponseList().isEmpty()) {
				errorLogService.addErrorLog(deDealVO, transactionId, Constants.TRANS_TYPE_CV_CLOUDQIN,
						Constants.CDKCLOUD_RESPONSE_QUEUE_EMPTY_DR_CODE,
						Constants.CDKCLOUD_RESPONSE_QUEUE_EMPTY_DR_MESSAGE);
			} else {
				logger.debug("Full Json message recieved successfully");
				List<DeCdkCloudCvXrefVO> listOfXrefsForSubTotal = deCdkCloudCvXrefRepoService
						.getByStateOrDefault(deDealVO.getDealExecutionState());
				Map<String, ExpressionVO> mapOfExpressions = CVUtil
						.extractExpressionsFromJson(directRenderResponseQueueMessage);
				Map<String, String> subTotalsMap = CVUtil.filterOutSubTotalsFromJson(mapOfExpressions,
						listOfXrefsForSubTotal);
				String ecout3 = cvDocumentManipulationService.updateSubTotals(ecout2Xml, subTotalsMap,
						listOfXrefsForSubTotal);
				// Add ECOUT3 record to creditJournal
				JournalObjectVO ecout3JournalObject = JournalFactory
						.createJournalObject(Constants.TRANS_TYPE_EC_OUT3, successAppMessage, ecout3);
				creditContractVO.addToListOfJournalObjects(ecout3JournalObject);
				logger.debug("ecout3 after updating subtotals: {}", ecout3);

				boolean isRouteOne = cvTransmitClient.getRouteOneFlag(dealerId, lenderId, Constants.APPLICATION_CV);
				String destination;
				ECConfinVO ecConfinVO;
				if (isRouteOne) {
					destination = "RouteOne";
					ecConfinVO = routeOneService.postECOUT3ToRouteOne(creditContractVO, ecout3);
					// cvPersistenceService.saveCVData(creditContractVO, dealVO,
					// deContractValidationVO);
					// Add ECCONFIN2 record to creditJournal
				} else {
					destination = lenderId;
					CVTransmitVO cvTransmitVO = getCvTransmitVoForLender(deDealVO, creditContractVO);
					ecConfinVO = lenderService.sendProcessCreditContract(creditContractVO, new ECConfinVO(), lenderId, ecout3, cvTransmitVO);
				}
				AppMessage appMessage = null;
				if (null != ecConfinVO.getStatusMessage()
						&& ecConfinVO.getStatusMessage().contains(Constants.OPERATION_SUCCESS_MESSSAGE)) {
					appMessage = successAppMessage;

				} else {
					logger.debug("Posting ECOUT3 to {} failed! Message: {}", destination, ecConfinVO.getStatusMessage());
					if (HttpStatus.INTERNAL_SERVER_ERROR.value() == ecConfinVO.getStatusCode() || HttpStatus.NOT_FOUND.value() == ecConfinVO.getStatusCode()) {
						appMessage = appCVEventHandler.handleEvents(Constants.Event_Http_Exception);
					} else {
						if (CVUtil.isR1ConfInXml(ecConfinVO.getEcConfinMessage())) {
							//Override default error message for r1 rest error in XML format
							appMessage = appCVEventHandler.handleR1NegConfBod(ecConfinVO, Constants.MESSAGE_FORMAT_XML);
						} else if (CVUtil.isR1ConfInJson(ecConfinVO.getEcConfinMessage())) {
							//Override default error message for r1 rest error in JSON formats
							appMessage = appCVEventHandler.handleR1NegConfBod(ecConfinVO, Constants.MESSAGE_FORMAT_JSON);
						} else {
							appMessage = appCVEventHandler.handleEvents(Constants.Event_Partner_Validation_Exception);
						}
					}

					//send confirmBOD to DMS to let them know that posting CV to R1 failed.
					creditContractVO.setAppMsg(appMessage);
					CreditJournalVO ecinCreditJournalVO = creditJournalRepoService.getMostRecentRecordByPartnerIdAndTransactionId(
							lenderId, creditContractVO.getDocumentId(), Constants.TRANS_TYPE_CV_EC_IN);
					String ecInXml = EncryptionUtils.decryptText(ecinCreditJournalVO.getCrDataXml(),
							ecinCreditJournalVO.getEncryptionKeyId());
					creditContractVO.setLenderRequestXml(ecInXml);
					dmsService.prepareAndSendNegativeConfirmBOD2Dms(creditContractVO, ecConfinVO.getEcConfinMessage());
				}
				JournalObjectVO ecconfin2JournalObject = JournalFactory
						.createJournalObject(Constants.TRANS_TYPE_EC_CONF_IN2, appMessage, ecConfinVO.getStatusMessage());
				creditContractVO.addToListOfJournalObjects(ecconfin2JournalObject);
				cvJournalService.addJournal(creditContractVO);

			}
		} catch (final Exception e) {
			if (null != deDealVO) {
				logger.debug("Exception occurred.", e);
				errorLogService.addErrorLog(deDealVO, transactionId, Constants.TRANS_TYPE_CV_CLOUDQIN,
						Constants.CDKCLOUD_RESPONSE_QUEUE_ERROR_CODE, Constants.CDKCLOUD_RESPONSE_QUEUE_ERROR_MESSAGE);
			} else {
				logger.error(
						"Critical error occurred while processing DirectRenderMessage from the CDKCloudResponseQueue.",
						e);
			}
		}

		final LocalDateTime end = LocalDateTime.now();
		logger.debug("***** End processing CDK Cloud Response Json at: {} *****", end);
		logger.debug("CDK Cloud Response Json processing took {} seconds ", ChronoUnit.SECONDS.between(start, end));
	}

	private CVTransmitVO getCvTransmitVoForLender(DeDealVO deDealVO, CreditContractVO creditContractVO) {
		CVTransmitVO cvTransmitVO = VOFactory.createCVTransmitVO(creditContractVO);
		cvTransmitVO.setDealVO(deDealVO);
		cvTransmitVO.setCdkCloudEnabled(true);
		return cvTransmitVO;
	}

	private boolean removeContractPackageFile(DeDealVO deDeal) {
		logger.debug("Entered removeContractPackageFile, DeDeal: {}", deDeal);
		boolean result = false;
		try {
			String fileName = deDeal.getDeDealId() + "_" + deDeal.getCvSequenceId() + ".pdf";
			String fullPath = Constants.CONTRACT_PDF_DIRECTORY + fileName;
			logger.debug("full contract path: {}", fullPath);
			File file = new File(fullPath);
			result = file.exists() && file.delete();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return result;
	}
}
