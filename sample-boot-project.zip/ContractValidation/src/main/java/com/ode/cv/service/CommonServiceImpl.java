package com.ode.cv.service;

import com.ode.cv.util.Constants;
import com.ode.persistence.service.ApplicationPropertiesRepoService;
import com.ode.persistence.vo.ApplicationPropertiesVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class CommonServiceImpl implements ICommonService {

	private static final Logger logger = LogManager.getLogger(CommonServiceImpl.class);

	@Autowired
	private ApplicationPropertiesRepoService applicationPropertiesRepoService;

	@Override
	public boolean isCdkCloudEnabled(final String lenderId, final String dealerId, final String dmsId) {
		logger.debug("Entered isCdkCloudEnabled, lenderId:{}, dealerId:{}, dmsId:{}", lenderId, dealerId, dmsId);

		boolean isCloudEnabled = false;

		try {
			ApplicationPropertiesVO applicationProperties = applicationPropertiesRepoService
					.getByApplicationNameAndPropertyName(Constants.VAULTWS_PROP_APP_NAME, Constants.COMMON_SERVICE_URL_PROP_NAME);
			String url = applicationProperties.getPropertyValue() + Constants.COMMON_SERVICE_CLOUD_FLAG_URL_APPEND;

			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
					.queryParam("lenderId", lenderId)
					.queryParam("dealerId", dealerId)
					.queryParam("dmsId", dmsId);

			logger.debug("CommonServices hasCdkCloudFlag URL > " + builder.build().encode().toUri());

			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(), Boolean.class);
			isCloudEnabled = response.getBody().booleanValue();
			logger.debug("CdkCloud is " + (isCloudEnabled ? "" : "*not*") + " enabled for lenderId: {}, dealerId: {}, dmsId: {}", lenderId, dealerId, dmsId);
		} catch(Exception e) {
			logger.error("Cannot determine if CdkCloud integration enabled for this lender, dealer, and dms", e);
			throw e;
		}

		return isCloudEnabled;
	}

	@Override

	public boolean getStandardDSPFlag(final String dmsId) {

		logger.debug("Entered getStandardDSPFlag, dmsId:{}", dmsId);
		boolean getStandardDSPFlag = false;
		try {
			ApplicationPropertiesVO applicationProperties = applicationPropertiesRepoService
					.getByApplicationNameAndPropertyName(Constants.VAULTWS_PROP_APP_NAME,
							Constants.COMMON_SERVICE_URL_PROP_NAME);

			String url = applicationProperties.getPropertyValue() + Constants.COMMON_SERVICE_STANDARD_FLAG_URL_APPEND;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("dmsId", dmsId);
			logger.debug("CommonServices standardDSPFlag URL > " + builder.build().encode().toUri());
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(),
					Boolean.class);
			getStandardDSPFlag = response.getBody().booleanValue();
			logger.debug("StandardDSPFlag is " + (response.getBody().booleanValue() ? "" : "*not*")
					+ " enabled for, dmsId: {}", dmsId);

		} catch (Exception e) {
			logger.error("Cannot determine if this is a standard dms", e);
			throw e;
		}
		return getStandardDSPFlag;
	}
}