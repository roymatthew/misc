/**
 * 
 */
package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;

import com.ode.cv.factory.VOFactory;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.persistence.service.DeContractValidationRepoService;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
@Service
public class ContractValidationServiceImpl implements IContractValidationService {

	private static final Logger logger = LogManager.getLogger(ContractValidationServiceImpl.class);

	@Autowired
	private CVRequestXMLParser cvRequestXMLParser;
	
	@Autowired
	private DeContractValidationRepoService deContractValidationRepoService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	@Transactional(value = "transactionManager")
	public DeContractValidationVO getContractValidation(String deDealId, String cvSequenceId) {
		logger.debug("Enter getContractValidationBo() method of ContractValidationServiceImpl class - deDealId:{}, cvSequenceId:{}", deDealId, cvSequenceId);
		
		DeContractValidationVO cv = deContractValidationRepoService.selectDeContractValidation(deDealId, cvSequenceId);
		
		logger.debug("DeContractValidationVO found: {}", cv);
		return cv;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DeContractValidationBo createContractValidationBOFromDocument(final CreditContractVO creditContractVO,
			final Document document, final String transType) {
		
		logger.debug("Enter createContractValidationBOFromDocument() method of ContractValidationServiceImpl class");

		DeContractValidationBo cvFromDocument = null;

		if (creditContractVO.isGenericCreditContract()) {
			cvFromDocument = cvRequestXMLParser.populateContractValForNVP(transType, document,
					creditContractVO.getPartnerInfo().getLenderId());
		} else {
			cvFromDocument = cvRequestXMLParser.populateContractValForSTAR(transType, document,
					creditContractVO.getPartnerInfo().getLenderId());
		}
		cvFromDocument.setFromPf(creditContractVO.getFromPF());
		cvFromDocument.setLenderId(creditContractVO.getPartnerInfo().getLenderId());
		
		logger.debug("DeContractValidation created: {}", cvFromDocument);
		
		return cvFromDocument;
	}
	
	/**
	 * {@inheritDoc}
	 * @throws Exception 
	 */
	@Transactional(value = "transactionManager")
	public DeContractValidationVO saveContractValidation(final CreditContractVO creditContractVO, final DeDealVO deDealVO) throws Exception
	{		
		logger.debug("Enter saveContractValidation() method of ContractValidationServiceImpl class");
		
		DeContractValidationBo deContractValidationBo = creditContractVO.getContractValidation();
		if (null == deContractValidationBo)
		{
			logger.debug("CV from document is null. Creating brand new CV");
			//create a brand new contract validation
			deContractValidationBo = VOFactory.createNewContractVal(deDealVO);
			deDealVO.setCvSequenceId(deContractValidationBo.getSequenceId());
		}
		else
		{
			VOFactory.updateCVSequenceId(deContractValidationBo, deDealVO);
		}
		deDealVO.setCvSequenceId(deContractValidationBo.getSequenceId());
		logger.debug("Updated Deal with new CV sequenceId: " + deDealVO.getCvSequenceId());
		
		DeContractValidationVO contractValidationToPersist = modelMapper.map(deContractValidationBo, DeContractValidationVO.class);
		contractValidationToPersist.setDealId(deDealVO.getDeDealId());
		if(contractValidationToPersist.getStatus() != null && contractValidationToPersist.getStatus().length() > 10){
			contractValidationToPersist.setStatus(contractValidationToPersist.getStatus().substring(0, 10));
		}
		
		/*
		 * final String contractId = CVUtil.generateContractId(creditContractVO);
		 * logger.debug("Generated ContractId: " + contractId);
		 * deContractValidationBo.setContractId(contractId);
		 * contractValidationToPersist.setContractId(contractId);
		 */
		contractValidationToPersist.setContractId(deContractValidationBo.getContractId());
		logger.debug("Creating new CV with sequenceId: " + deContractValidationBo.getSequenceId());
		
		if(creditContractVO.getDeal() != null) {
			creditContractVO.getDeal().setCvSequenceId(deContractValidationBo.getSequenceId());
			logger.debug("creditContractVO.deDeal updated with CV sequence: {}", deContractValidationBo.getSequenceId());
		}
	
		return deContractValidationRepoService.saveOrUpdate(contractValidationToPersist);		
	}

}
