/**
 *
 */
package com.ode.cv.service;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.DeLenderRepoService;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.DeLenderVO;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

/**
 * @author snimma
 *
 */
@Service
public class CreditContractServiceImpl implements ICreditContractService {

	private static final Logger logger = LogManager.getLogger(CreditContractServiceImpl.class);

	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;

	@Autowired
	private DeLenderRepoService deLenderRepoService;

	@Autowired
	private ICVRequestTranslationService cvRequestTranslationService;

	@Autowired
	private PCCXmlParser pccXmlParser;

	@Autowired
	private ICVDataTranslationService cvDataTranslationService;

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private CVTransmitClient transmitClient;

	@Autowired
	private ApplpEventHandler appCVEventHandler;

	@Autowired
	private CVRequestXMLParser cvRequestXMLParser;

	@Autowired
	private IDealService dealService;

	@Autowired
	private IContractValidationService contractValidationService;

	@Autowired
	private IAccrService accrService;

	@Autowired
	private ICVPersistenceService cvPersistenceService;

	@Autowired
	private ICdkCloudService cdkCloudService;

	@Autowired
	private CVTransmitClient cvTransmitClient;

	@Autowired
	private ICommonService commonService;

	@Autowired
	private IOldREValidationService oldREValidationService;

	@Autowired
	private IDmsService dmsService;

	@Override
	public void processCreditContract(final CreditContractVO creditContractVO) throws Exception {
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("Entered processCreditContract()");
		logger.debug("***** Start processing CV at: " + start + " *****");
		DeContractValidationBo cvFromDocument = null;
		DeDealBo dealFromDocument = null;
		Boolean proceedToLTE = Boolean.TRUE;
		ECConfinVO reResponse = null;

		String cvEcinXml = creditContractVO.getRequestXML();
		String deDealId = pccXmlParser.getDeDealIdFromCvEcin(cvEcinXml);
		String cvSequenceId = pccXmlParser.getCvSeqIdFromCvEcin(cvEcinXml);

		String xmlString = pccXmlParser.getEcinFromCvEcin(cvEcinXml);
		creditContractVO.setRequestXML(xmlString); //Continue to use ECIN here since it's accessed throughout this class.
		Boolean isAdvent = cvTransmitClient.getAdventFlag(pccXmlParser.getSenderNameCode(xmlString));

		// use common service to determine if dsp is standard
		Boolean isStandard = commonService.getStandardDSPFlag(pccXmlParser.getSenderNameCode(xmlString));

		Document document = cvRequestXMLParser.getDocument(creditContractVO.getRequestXML());
		pccXmlParser.parseInput(document, creditContractVO);
		logger.debug(creditContractVO.getDealerInfo());
		logger.debug(creditContractVO.getPartnerInfo());
		productConfigurationLookupService.loadConfigurations(creditContractVO.getPartnerInfo().getLenderId());

		// use common service to determine if deal is RO
		boolean isR1Enabled = false;

		try {
			isR1Enabled = cvTransmitClient.getRouteOneFlag(creditContractVO.getDealerInfo().getDealerId(),
					creditContractVO.getPartnerInfo().getLenderId(), Constants.PRODUCT_CV);
		} catch (Exception e) {
			logger.debug("Cannot determine if the deal is R1 or not ", e);
		}

		cvFromDocument = contractValidationService.createContractValidationBOFromDocument(creditContractVO, document,
				Constants.TRANS_TYPE_EC_IN);

		if (null != cvFromDocument) {
			logger.debug("Extracted ContractValidation from document");
			creditContractVO.setContractValidation(cvFromDocument);
			CVUtil.generateVaultDocIdForEcin(creditContractVO);
			dealFromDocument = dealService.createDealBOFromDocumentCV(cvFromDocument, document,
					Constants.TRANS_TYPE_EC_IN);
			dealFromDocument.setDealerName(creditContractVO.getDealerInfo().getDealerName());
			creditContractVO.setDeal(dealFromDocument);
		} else {
			logger.debug("Extracting ContractValidation from document failed!");
		}

		String ecinXml = creditContractVO.getRequestXML().replaceAll("&amp;#39;", "&apos;");
		cvEcinXml = cvEcinXml.replaceAll("&amp;#39;", "&apos;");
		creditContractVO.setRequestXML(ecinXml);
		String lenderId = creditContractVO.getPartnerInfo().getGlobalLenderId();
		// creditContractVO.setFiConfig(financeInstitutionConfig.getFinanceInstitution(lenderId));
		if (null == lenderId || lenderId.isEmpty()) {
			lenderId = creditContractVO.getPartnerInfo().getLenderId();
		}

		DeLenderVO deLenderVO = deLenderRepoService.findById(lenderId);
		if (null != deLenderVO && null != deLenderVO.getRulesEngineFlag()
				&& deLenderVO.getRulesEngineFlag().equalsIgnoreCase("Y")) {
			creditContractVO.setRulesEngine(true);
		}

		String responseDestinationId = creditContractVO.getDealerInfo().getDspId(); // by default, send to DSP

		cvDataTranslationService.translateData(creditContractVO);

		logger.debug("Destination Name Code: {}", creditContractVO.getDestinationNameCode());
		logger.debug("RulesEngine Enabled? {}", creditContractVO.getOldREValidationRequired());

		// determine destination and stylesheet to be used
		String stylesheetId = creditContractVO.getDealerInfo().getDspId();

		DeDealVO dealVO = null;
		if(deDealId != null && !deDealId.isEmpty()) {
			dealVO = dealService.updateDeDeal(creditContractVO, deDealId);
		} else {
			dealVO = dealService.saveDeal(creditContractVO, Constants.TRANS_TYPE_EC_IN);
		}

		if(cvSequenceId == null || cvSequenceId.isEmpty()) {
			cvSequenceId = dealVO.getCvSequenceId();
		}

		DeContractValidationVO deContractValidationVO = contractValidationService.getContractValidation(deDealId, cvSequenceId);
		creditContractVO.getContractValidation().setSequenceId(cvSequenceId);
		creditContractVO.getContractValidation().setDealId(deDealId);
		creditContractVO.getContractValidation().setAutoFundingIndicator(deContractValidationVO.getAutoFundingIndicator());

		AppMessage sappMsg = appCVEventHandler.handleEvents("Success");
		JournalObjectVO journalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_CV_EC_IN, sappMsg,
				cvEcinXml);
		cvJournalService.addJournal(creditContractVO, journalObject);
		if (creditContractVO.getOldREValidationRequired()) {
			logger.debug("Starting Old RE rules validation");

			reResponse = oldREValidationService.validateCVAgainstOldRE(creditContractVO, dealVO);
			if (Constants.FAILED.equalsIgnoreCase(reResponse.getStatusMessage()))
			{
				proceedToLTE = Boolean.FALSE;
			}

			logger.debug("Finished Old RE rules validation. proceedToLTE: {}", proceedToLTE);
		}

		if (proceedToLTE) {

			if (isStandard && isR1Enabled) {
				// change destination name code and set xmlstring
				String addRODestination = xmlString.replaceAll("<DestinationNameCode>.*</DestinationNameCode>",
						"<DestinationNameCode>RO</DestinationNameCode>");

				addRODestination = addLTEWrapper(addRODestination);

				creditContractVO.setLenderRequestXml(addRODestination);
			} else if (isStandard || isAdvent) {
				if (isStandard) {
					xmlString = addLTEWrapper(xmlString);
				}
				// set xml string
				creditContractVO.setLenderRequestXml(xmlString);
			} else {
				logger.debug("About to start stylesheet translation with stylesheet: " + stylesheetId);
				// Transform the message to lender format
				cvRequestTranslationService.createContractout(creditContractVO, stylesheetId, ecinXml);
			}
			logger.debug("CV-ECOUT after stylesheet and data translation: " + creditContractVO.getLenderRequestXml());

			sappMsg = appCVEventHandler.handleEvents("Success");
			journalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_CV_EC_OUT, sappMsg,
					creditContractVO.getLenderRequestXml());
			cvJournalService.addJournal(creditContractVO, journalObject);

			try {
				String contractId = null;
				if (StringUtils.isBlank(dealVO.getContractId())) {
					logger.debug("About to generate ContractId");
					contractId = CVUtil.generateContractId(creditContractVO);
					dealVO.setContractId(contractId);
				} else {
					contractId = dealVO.getContractId();
					logger.debug("ContractId: {}", contractId);
				}
				deContractValidationVO.setContractId(contractId);
				creditContractVO.getContractValidation().setContractId(contractId);
				CVTransmitVO cvTransmitVO = VOFactory.createCVTransmitVO(creditContractVO);
				cvTransmitVO.setDealVO(dealVO);

				logger.debug("Checking if cdkCloudService should be invoked..");
				boolean isCdkCloudEnabled = false;
				try {
					isCdkCloudEnabled = commonService.isCdkCloudEnabled(dealVO.getLenderId(), dealVO.getDmsDealerId(),
							dealVO.getDmsId());
					cvTransmitVO.setCdkCloudEnabled(isCdkCloudEnabled);
				} catch (Exception e) {
					logger.debug("Unable to determine if lender/dealer/dms is cdkCloud enabled");
				}

				transmitClient.sendTranslatedXMLToLTE(cvTransmitVO, creditContractVO, responseDestinationId);
				if (Constants.LENDER_VCF.equalsIgnoreCase(lenderId) && creditContractVO.getOldREValidationRequired())
				{
					cvTransmitVO.setEcConfinVO(reResponse);
				}
				accrService.processAccrFromLTE(cvTransmitVO, creditContractVO, isStandard);

				dealVO = cvTransmitVO.getDealVO();

				if (creditContractVO != null && creditContractVO.getContractValidation() != null) {
					if (creditContractVO.getContractValidation().getStatus() != null) {
						logger.debug("Setting contract validation status to {}",
								creditContractVO.getContractValidation().getStatus());
						deContractValidationVO.setStatus(creditContractVO.getContractValidation().getStatus());
					}
					if (creditContractVO.getContractValidation().getStatusTs() != null) {
						deContractValidationVO.setStatusTs(
								new Timestamp(creditContractVO.getContractValidation().getStatusTs().getTime()));
					}
				}



				if (null != cvTransmitVO.getEcConfinVO()) {
					AppMessage appMessage = null;
					ECConfinVO ecConfinVO = cvTransmitVO.getEcConfinVO();
					logger.debug("ecConfinVO.getStatusCode(): {}" , ecConfinVO.getStatusCode());
					if (isCdkCloudEnabled && null != ecConfinVO.getStatusMessage()
							&& ecConfinVO.getStatusMessage().contains(Constants.OPERATION_SUCCESS_MESSSAGE)) {
						cdkCloudService.prepareAndSendCdkCloudRequest(ecConfinVO.getRequestXML(), dealVO,
								creditContractVO);
					} else if (HttpStatus.OK.value() != ecConfinVO.getStatusCode()) {

						// send confirmBOD to DMS to let them know that posting CV to R1 failed.
						if(CVUtil.isR1ConfInXml(ecConfinVO.getEcConfinMessage())) {
							//Override default error message for r1 rest error in XML format
							appMessage = appCVEventHandler.handleR1NegConfBod(ecConfinVO, Constants.MESSAGE_FORMAT_XML);
						} else if (CVUtil.isR1ConfInJson(ecConfinVO.getEcConfinMessage())) {
							//Override default error message for r1 rest error in JSON formats
							appMessage = appCVEventHandler.handleR1NegConfBod(ecConfinVO, Constants.MESSAGE_FORMAT_JSON);
						} else {
							appMessage = CVUtil.traslateErroCodeToStandardMessage(appCVEventHandler, ecConfinVO);
						}

						creditContractVO.setAppMsg(appMessage);
						creditContractVO.setLenderRequestXml(creditContractVO.getRequestXML());
						dmsService.prepareAndSendNegativeConfirmBOD2Dms(creditContractVO, ecConfinVO.getRequestXML());
					}
				}
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}

		}
		cvPersistenceService.saveCVData(creditContractVO, dealVO, deContractValidationVO);
		cvJournalService.addJournal(creditContractVO);
		final LocalDateTime end = LocalDateTime.now();
		logger.debug("***** End processing CV at: " + end + " *****");
		logger.debug("CV processing took " + ChronoUnit.SECONDS.between(start, end) + " seconds");
	}

	public String addLTEWrapper(String requestXML) {
		requestXML = requestXML.replace(
				"<payload xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\">",
				"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:proc=\"http://www.starstandards.org/STAR/processcreditcontract\" xmlns:trans=\"http://www.starstandards.org/webservices/2005/10/transport\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://www.starstandards.org/STAR\" xmlns:xalan=\"http://xml.apache.org/xslt\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:s=\"http://www.starstandards.org/STAR\" xmlns:p=\"http://CreditGateWay/Ecommerce/Services/CreditApps\"><soap:Header><payloadManifest xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\"><manifest contentID=\"Content0\" namespaceURI=\"http://www.starstandards.org/STAR\" element=\"ProcessCreditContract\" version=\"2.01\"/></payloadManifest></soap:Header><soap:Body><ProcessMessage xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\"><payload>");
		requestXML = requestXML.replace("</payload>", "</payload></ProcessMessage></soap:Body></soap:Envelope>");

		requestXML = requestXML.replaceFirst(
				"<ProcessCreditContract xmlns=\"http://www.starstandards.org/STAR\".* xsi:schemaLocation=\"http://www.starstandards.org/STAR \\\\Star\\\\Rev.*\\\\BODs\\\\Standalone\\\\ProcessCreditContract.xsd\">",
				"<ProcessCreditContract xmlns=\"http://www.starstandards.org/STAR\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\\\STAR\\\\Rev4.4.4\\\\BODs\\\\Standalone\\\\ProcessCreditContract.xsd\" release=\"8.1-Lite\" environment=\"Production\" revision=\"3.0.2\" lang=\"en-US\">");

		return requestXML;
	}
}
