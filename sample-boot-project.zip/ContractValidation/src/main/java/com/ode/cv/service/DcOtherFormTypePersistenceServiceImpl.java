package com.ode.cv.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.persistence.service.DcOtherFormTypeRepoService;
import com.ode.persistence.vo.DcOtherFormTypeVO;

@Service
public class DcOtherFormTypePersistenceServiceImpl implements IDcOtherFormTypePersistenceService {
	
	private static final Logger logger = LogManager.getLogger(DcOtherFormTypePersistenceServiceImpl.class);

	@Autowired
	private DcOtherFormTypeRepoService dcOtherFormTypeRepoService;
	
	@Override
	@Transactional(value = "transactionManager")
	public List<DcOtherFormTypeVO> findByDeDealId(String deDealId) throws Exception {
		logger.debug("Entered findByDeDealId, deDealId: {}", deDealId);
		return dcOtherFormTypeRepoService.findByDeDealId(deDealId);
	}
	
	@Override
	@Transactional(value = "transactionManager")
	public List<DcOtherFormTypeVO> saveOrUpdateAll(List<DcOtherFormTypeVO> dcOtherFormTypeVOList) throws Exception {
		logger.debug("Entered saveOrUpdateAll, number of records to save: {}", dcOtherFormTypeVOList.size());
		return dcOtherFormTypeRepoService.saveOrUpdateAll(dcOtherFormTypeVOList);
	}
	
	@Override
	@Transactional(value = "transactionManager")
	public int deleteForDeDealId(String deDealId) throws Exception {
		logger.debug("Entered deleteForDeDealId, deDealId: {}", deDealId);
		return dcOtherFormTypeRepoService.deleteForDeDealId(deDealId);
	}
}
