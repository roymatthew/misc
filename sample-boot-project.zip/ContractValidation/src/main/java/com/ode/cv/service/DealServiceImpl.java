/**
 *
 */
package com.ode.cv.service;

import com.ode.cv.dao.DealDao;
import com.ode.cv.exception.CVFromDocumentException;
import com.ode.cv.exception.DocumentException;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import com.ode.persistence.service.DeDealRepoService;
import com.ode.persistence.vo.DeDealVO;
import java.sql.Timestamp;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;

/**
 * @author rmathew
 *
 */
@Service
public class DealServiceImpl implements IDealService {

	private static final Logger logger = LogManager.getLogger(DealServiceImpl.class);

	@Autowired
	private CVRequestXMLParser cvRequestXMLParser;

	@Autowired
	private DeDealRepoService deDealRepoService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private DealDao dealDao;

	/**
	 * {@inheritDoc}
	 * @throws CVFromDocumentException
	 * @throws DocumentException
	 */
	@Override
	public DeDealBo createDealBOFromDocumentCV(final DeContractValidationBo cvFromDocument, final Document document,
			final String transType) throws CVFromDocumentException, DocumentException {

		if (null == cvFromDocument)
		{
			throw new CVFromDocumentException("cvFromDocument was null");
		}

		if (null == document)
		{
			throw new DocumentException("document was null");
		}

		DeDealBo dealFromDocument = cvRequestXMLParser.populateDealFromCV(cvFromDocument);
		dealFromDocument = cvRequestXMLParser.populateDealFromDocument(dealFromDocument, document, transType);

		logger.debug("DeDeal created: {}", dealFromDocument);
		
		return dealFromDocument;
	}

	@Override
	public String getNextDeDealId(final int nextDeDealId) {

		// deDealRepoService.
		return null;

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@Transactional(transactionManager = "transactionManager")
	public DeDealVO saveDeal(final CreditContractVO creditContractVO, final String transType) {

		logger.debug("Entered saveDeal() method of DealServiceImpl class");

		DeDealBo dealFromDocument = creditContractVO.getDeal();

		logger.debug("looking up DeDealVO by dmsDealNum: " + creditContractVO.getAdpDealNo() + " and dmsDealerId: " + creditContractVO.getDealerInfo().getDealerId()
				+ " and lenderId: " + creditContractVO.getPartnerInfo().getLenderId());
		DeDealVO dealVO = deDealRepoService.findDeDealByDmsDealId(creditContractVO.getAdpDealNo(),
				creditContractVO.getDealerInfo().getDealerId(), creditContractVO.getPartnerInfo().getLenderId());


		if (null == dealVO) {//if deal in DB is missing, create a brand new deal
			logger.debug("Deal not found in DB. System will attempt to insert a new DeDeal record in DB.");
			DeDealBo newDeal = VOFactory.createNewDealBo(creditContractVO, transType, dealDao.getNextNumericValueForPrimaryKey());
			newDeal.updateWith(dealFromDocument);
			dealVO = modelMapper.map(newDeal, DeDealVO.class);
			dealVO.setCreatedBy(Constants.APP_CV_CODE);
			dealVO.setCreatedTs(new Timestamp(System.currentTimeMillis()));
		} else {
			logger.debug("Deal found in DB. System will update DeDeal record in DB with deal info from document.");
			// update existing Deal in DB with data from deal from document//
			VOFactory.updateDealWithDealFromDocument(dealVO, dealFromDocument);
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			dealVO.setModifiedBy(Constants.APP_CV_CODE);
			dealVO.setModifiedTs(currentTime);
			dealVO.setLastModifiedTs(currentTime);
		}
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		String dealerName = creditContractVO.getDealerInfo().getDealerName();
		if (StringUtils.isNotBlank(dealerName) && dealerName.length() > 45) {
			dealerName = dealerName.substring(0, 45);
		}
		dealVO.setDealerName(dealerName);
		dealVO.setDealExecutionState(creditContractVO.getContractExecutionState());
		dealVO.setDmsDealerId(creditContractVO.getDealerInfo().getDealerId());
		dealVO.setLenderDealerId(creditContractVO.getDeal().getLenderDealerId());
		dealVO.setLastModifiedTs(currentTime);

		try {
			logger.debug("Saving DeDeal record in DB with deDealId: " + dealVO.getDeDealId() + " LenderID: " + dealVO.getLenderId() + " DMS ID: " + dealVO.getDmsId());
			dealVO = deDealRepoService.saveOrUpdate(dealVO);
			creditContractVO.setDeal(modelMapper.map(dealVO, DeDealBo.class));
			logger.debug("creditContractVO.deDeal updated with new DeDeal info.");
			return dealVO;
		} catch (final Exception e) {
			logger.error(e);
		}

		logger.debug("Return null.");
		return null;
	}
	
	@Override
	public DeDealVO updateDeDeal(final CreditContractVO creditContractVO, final String deDealId) throws Exception {
		logger.debug("Entered updateDeDeal() method of DealServiceImpl class: {}", deDealId);
		
		DeDealVO dealVO = findDeDealById(deDealId);
		
		if(dealVO != null) {
			VOFactory.updateDealWithDealFromDocument(dealVO, creditContractVO.getDeal());
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			dealVO.setModifiedBy(Constants.APP_CV_CODE);
			dealVO.setModifiedTs(currentTime);
			dealVO.setLastModifiedTs(currentTime);
			String dealerName = creditContractVO.getDealerInfo().getDealerName();
			if (StringUtils.isNotBlank(dealerName) && dealerName.length() > 45) {
				dealerName = dealerName.substring(0, 45);
			}
			dealVO.setDealerName(dealerName);
			dealVO.setDealExecutionState(creditContractVO.getContractExecutionState());
			dealVO.setDmsDealerId(creditContractVO.getDealerInfo().getDealerId());
			dealVO.setLenderDealerId(creditContractVO.getDeal().getLenderDealerId());
			dealVO.setLastModifiedTs(currentTime);
		} else {
			logger.debug("No deal fund in table. Return null.");
			return null;
		}
		
		try {
			logger.debug("Saving DeDeal record in DB with deDealId: " + dealVO.getDeDealId() + " LenderID: " + dealVO.getLenderId() + " DMS ID: " + dealVO.getDmsId());
			dealVO = deDealRepoService.saveOrUpdate(dealVO);
			creditContractVO.setDeal(modelMapper.map(dealVO, DeDealBo.class));
			logger.debug("creditContractVO.deDeal updated with new DeDeal info.");
			return dealVO;
		} catch (final Exception e) {
			logger.error(e);
		}

		logger.debug("Return null.");
		return null;
	}

	@Override
	@Transactional(transactionManager = "transactionManager")
	public DeDealVO findDeDealById(final String deDealId) throws Exception {
		logger.debug("Entered findDeDealById() method of DealServiceImpl class: {}", deDealId);
		
		DeDealVO dealVO = deDealRepoService.findDeDealByDealId(deDealId);
		if (null != dealVO) {
			logger.debug("Found deDeal for key: {}", deDealId);
		} else {
			logger.debug("No deDeal found for key: {}", deDealId);
		}
		
		return dealVO;
	}

}
