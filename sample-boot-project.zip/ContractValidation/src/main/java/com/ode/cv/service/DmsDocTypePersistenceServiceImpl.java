package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.persistence.service.DmsDocTypeRepoService;
import com.ode.persistence.vo.DmsDocTypeVO;

@Service
public class DmsDocTypePersistenceServiceImpl implements IDmsDocTypePersistenceService {
	
	private static final Logger logger = LogManager.getLogger(DmsDocTypePersistenceServiceImpl.class);
	
	@Autowired
	private DmsDocTypeRepoService dmsDocTypeRepoService;

	@Override
	@Transactional(value = "transactionManager")
	public DmsDocTypeVO getDmsDocType(String docName, String lenderId, String dmsId) {
		logger.debug("Entered getDmsDocType, docName: {}, lenderId: {}, dmsId: {}", docName, lenderId, dmsId);
		return dmsDocTypeRepoService.getDmsDocType(docName, lenderId, dmsId);
	}
}
