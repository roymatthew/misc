package com.ode.cv.service;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.DealerPpNvpRepoService;
import com.ode.persistence.vo.DealerPpNvpVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DmsServiceImpl implements IDmsService {

    private static final Logger logger = LogManager.getLogger(DmsServiceImpl.class);

    @Autowired
    private CVResponseXMLParser cvResponseXmlParser;

    @Autowired
    private DealerPpNvpRepoService dealerPpNvpRepoService;

    @Autowired
    private IProductConfigurationLookupService productConfigurationLookupService;

    @Autowired
    private IAccrRequestTranslationService accrRequestTranslationService;

    @Autowired
    private ApplpEventHandler applpEventHandler;

    @Autowired
    private CVTransmitClient cvTransmitClient;

    @Autowired
    private ICVJournalService cvJournalService;

    //Update to Interface
    @Autowired
    private ILenderResponseService lenderResponseService;

    /**
     * @param cvTransmitVO
     * @param creditContractVO
     * @throws Exception
     */
    @Override
    public void sendAccrToDMS(final CVTransmitVO cvTransmitVO,
                                   final CreditContractVO creditContractVO) throws Exception {
        logger.debug("Enter sendAccrToDMS() method of DmsServiceImpl class");
        AccrVO accrVOInput = VOFactory.createAccrVOFromCreditContract(creditContractVO);
        accrVOInput.setAccrRequestXml(cvTransmitVO.getEcConfinVO().getRequestXML());
        AccrVO accrVO = cvResponseXmlParser.populateAccrDetailsFromInput(accrVOInput);        
        cvResponseXmlParser.populateAccrDetailsFromEcin(creditContractVO.getRequestXML(), accrVO, creditContractVO.getDealerInfo().getDspId());
        accrVO.setBodId(creditContractVO.getDocumentId());
        String dealerPartyId = getDealerPartyId(creditContractVO);
        logger.debug("dealerPartyId: {}", dealerPartyId);
        creditContractVO.getDealerInfo().setDealerPartyId(dealerPartyId);
        creditContractVO.setAccr(accrVO);
        cvTransmitVO.setAccrContext(accrVO);
        cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
        cvTransmitVO.setAccrResponseXml(cvTransmitVO.getEcConfinVO().getRequestXML());
        lenderResponseService.updateDealFromLenderResponse(cvTransmitVO, creditContractVO);

        String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
                creditContractVO.getDealerInfo().getDspId(), Constants.ACCR, Constants.STYLESHEET);
        accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);

        AppMessage sappMsg = applpEventHandler.handleEvents("Success");
        if (StringUtils.isNotBlank(cvTransmitVO.getAccroutXml()))
        {
            JournalObjectVO cvReEcoutjournalObject = JournalFactory
                    .createJournalObject(Constants.TRANS_TYPE_EC_ACK_OUT, sappMsg, cvTransmitVO.getAccroutXml());
            cvJournalService.addJournal(creditContractVO, cvReEcoutjournalObject);
        }
        // call cvTransmitClient to send ECACKOUT to DMS
        cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, creditContractVO.getDealerInfo().getDspId());
        if (StringUtils.isNotBlank(cvTransmitVO.getResponseXml()))
        {
            // Journal ECACKCONFIN from DMS
            JournalObjectVO cvReEcoutjournalObject = JournalFactory
                    .createJournalObject(Constants.TRANS_TYPE_EC_ACK_CONF_IN, sappMsg, cvTransmitVO.getResponseXml());
            cvJournalService.addJournal(creditContractVO, cvReEcoutjournalObject);
        }


    }

    /**
     * @param creditContractVO
     * @return
     * @throws Exception
     */
    public String getDealerPartyId(final CreditContractVO creditContractVO) throws Exception {
        DealerPpNvpVO dealerPpNvpVO = new DealerPpNvpVO();
        dealerPpNvpVO.setDealerId(creditContractVO.getDealerInfo().getDealerId());
        dealerPpNvpVO.setPartnerId(creditContractVO.getPartnerInfo().getLenderId());
        dealerPpNvpVO.setProductId("CV");
        dealerPpNvpVO.setParmName("ACCOUNTID1");
        String dealerPartyId = dealerPpNvpRepoService.getParmValueByParmNameLenderDealerAndProduct(dealerPpNvpVO);
        return dealerPartyId;
    }

    @Override
    public void prepareAndSendNegativeConfirmBOD2Dms(final CreditContractVO creditContractVO, final String xml) throws Exception {
        logger.debug("Enter prepareAndSendNegativeConfirmBOD2Dms() method of DmsServiceImpl class");
        CVTransmitVO cvTransmitVO = new CVTransmitVO();
        cvTransmitVO.setAccrResponseXml(creditContractVO.getLenderRequestXml());
        if (creditContractVO.getAccr() == null) {
            AccrVO accrVO = new AccrVO();
            accrVO.setBodId(creditContractVO.getDocumentId());
            creditContractVO.setAccr(accrVO);
        } else {
            creditContractVO.getAccr().setBodId(creditContractVO.getDocumentId());
        }
        cvTransmitVO.setAccrContext(creditContractVO.getAccr());
        cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
        // Journal ECCONFIN from finance partner. It could be empty if the communication to them failed.
        JournalObjectVO ecConfInJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_IN,
                creditContractVO.getAppMsg(), xml);
        cvJournalService.addJournal(creditContractVO, ecConfInJournalObject);

        String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
                creditContractVO.getDealerInfo().getDspId(), Constants.CONFIRMBOD, Constants.STYLESHEET);
        accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
        // Journal CONFOUT to DMS
        AppMessage ecConfOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
        JournalObjectVO ecConfOutJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_OUT,
                ecConfOutAppMsg, cvTransmitVO.getAccroutXml());
        creditContractVO.addToListOfJournalObjects(ecConfOutJournalObject);
        // call cvTransmitClient to send Output to DMS
        cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, creditContractVO.getDealerInfo().getDspId());
        logger.debug("Exit prepareAndSendNegativeConfirmBOD2Dms() method of AccrServiceImpl class");

    }
}
