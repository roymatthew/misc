package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.persistence.service.ErrorLogRepoService;
import com.ode.persistence.vo.ErrorLogVO;

@Service
public class ErrorLogPersistenceServiceImpl implements IErrorLogPersistenceService {
	
	private static final Logger logger = LogManager.getLogger(ErrorLogPersistenceServiceImpl.class);

	@Autowired
	private ErrorLogRepoService errorLogRepoService;
	
	@Override
	@Transactional(value = "transactionManager")
	public ErrorLogVO saveOrUpdate(ErrorLogVO errorLogVO) {
		logger.debug("Entered saveOrUpdate, errorLog: {}", errorLogVO);
		return errorLogRepoService.saveOrUpdate(errorLogVO);
	}
}
