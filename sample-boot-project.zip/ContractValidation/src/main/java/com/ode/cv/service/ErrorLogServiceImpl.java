package com.ode.cv.service;

import java.sql.Timestamp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.ErrorLogVO;

@Service
public class ErrorLogServiceImpl implements IErrorLogService {

	private static final Logger log = LogManager.getLogger(ErrorLogServiceImpl.class);
	
	@Autowired
	private IErrorLogPersistenceService errorLogPersistenceService;
	
	public ErrorLogVO addErrorLog(final DeDealVO deDeal, final String transactionId, final String transactionType, final String errorCode, final String errorMessage) {
		log.debug("Entered addErrorLog");
		
		ErrorLogVO errorLog = new ErrorLogVO();
		errorLog.setCreatedBy("ContractValidation");
		errorLog.setCreatedTs(new Timestamp(System.currentTimeMillis()));
		errorLog.setDealId(deDeal.getDeDealId());
		errorLog.setDmsDealerId(deDeal.getDmsDealerId());
		errorLog.setDmsDealNum(deDeal.getDmsDealNum());
		errorLog.setLenderId(deDeal.getLenderId());
		errorLog.setSequenceId(deDeal.getCvSequenceId());
		
		errorLog.setTransactionId(transactionId);
		errorLog.setTransactionType(transactionType);
		errorLog.setErrorCode(errorCode);
		errorLog.setErrorMessage(errorMessage);
		
		ErrorLogVO savedErrorLog = errorLogPersistenceService.saveOrUpdate(errorLog);
		
		return savedErrorLog;
	}
}
