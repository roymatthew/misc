/**
 * 
 */
package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import com.ode.cv.messaging.GenerateEformMessageProducer;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
@Service
public class GenerateEformServiceImpl implements IGenerateEformService {

	private static final Logger logger = LogManager.getLogger(GenerateEformServiceImpl.class);

	@Autowired
	private GenerateEformMessageProducer generateEformMessageProducer;

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;

	@Autowired
	private CVResponseXMLParser cvResponseXmlParser;

	private static final String XML_PROLOG = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

	@Override
	public void generateEForm(final String ecAckinXml, final DeDealVO deDealVO) throws Exception {

		logger.debug("Entered generateEform() method of GenerateEformServiceImpl.class");
		Document ecAckinDocument = CVUtil.generateDocumentFromElement(cvRequestXmlParser.getDocument(ecAckinXml),
				"AcknowledgeCreditContractResponse", null);
		String reformattedEcAckinXml = CVUtil.getXmlStringFromDocument(ecAckinDocument);
		reformattedEcAckinXml = cvResponseXmlParser.removeSchemaPrefixIfAny(reformattedEcAckinXml);
		String ecAckinXmlWithoutProlog = reformattedEcAckinXml.replace(XML_PROLOG, "");
		final StringBuilder generateEFormXmlBuilder = new StringBuilder();
		CreditJournalVO cjEcin = cvJournalService.getJournalForTransType(deDealVO, Constants.TRANS_TYPE_EC_IN);
		String decrptedEcin = EncryptionUtils.decryptText(cjEcin.getCrDataXml(), cjEcin.getEncryptionKeyId());
		CreditJournalVO cjEcout2 = cvJournalService.getJournalForTransType(deDealVO, Constants.TRANS_TYPE_EC_OUT2);
		String decryptedEcout = EncryptionUtils.decryptText(cjEcout2.getCrDataXml(), cjEcout2.getEncryptionKeyId());
		Document ecoutDocument = CVUtil.generateDocumentFromElement(cvRequestXmlParser.getDocument(decryptedEcout),
				"RouteOneProcessCreditContract", "ProcessCreditContract");
		String reformattedEcoutXml = CVUtil.getXmlStringFromDocument(ecoutDocument);
		String ecoutXmlWithoutProlog = reformattedEcoutXml.replace(XML_PROLOG, "");
		generateEFormXmlBuilder.append("<ContractValidation>").append("<DeDealId>").append(deDealVO.getDeDealId())
				.append("</DeDealId>").append("<ECIN>").append(decrptedEcin).append("</ECIN>").append("<ECOUT>")
				.append(ecoutXmlWithoutProlog).append("</ECOUT>").append("<ECACKIN>").append(ecAckinXmlWithoutProlog)
				.append("</ECACKIN></ContractValidation>");
		logger.debug("Message being written to LP.DW.QUEUE: {}", generateEFormXmlBuilder.toString());
		generateEformMessageProducer.sendMessage(generateEFormXmlBuilder.toString());
	}

}
