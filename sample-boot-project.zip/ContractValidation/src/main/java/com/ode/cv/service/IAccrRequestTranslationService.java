package com.ode.cv.service;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;

public interface IAccrRequestTranslationService {

	void createDMSOut(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO,
			final String stylesheetId) throws Exception;
	
}
