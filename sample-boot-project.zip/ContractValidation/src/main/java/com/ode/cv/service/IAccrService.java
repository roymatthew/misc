/**
 * 
 */
package com.ode.cv.service;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CreditContractVO;

/**
 * @author rmathew
 *
 */
public interface IAccrService {
	
	/**
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws Exception
	 */
	void processAccrFromLTE(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO, final Boolean isStandard) throws ParserConfigurationException, SAXException, IOException, Exception;
	AccrVO processAccrFromRouteOne(final AccrVO accrVO) throws ParserConfigurationException, SAXException, IOException, Exception;
    AccrVO processAsyncResponseFromLender(String lenderResponseXml) throws Exception;
}
