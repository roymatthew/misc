/**
 * 
 */
package com.ode.cv.service;

import com.ode.cv.vo.CreditContractVO;

/**
 * @author rmathew
 *
 */
public interface ICVDataTranslationService {
	
	/**
	 * @param inputXML
	 * @return String
	 * @throws Exception 
	 */
	void translateData(final CreditContractVO creditContractVO) throws Exception;

}
