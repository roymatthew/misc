package com.ode.cv.service;

import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;

import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.DeCdkCloudCvXrefVO;

public interface ICVDocumentManipulationService {
	
	/**
	 * @param creditContractVO
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	Document makeRequiredChangesToECOUTForLender(final CreditContractVO creditContractVO, final Document xml) throws Exception;
	
	/**
	 * This method makes required XML changes to output XML, that goes to RouteOne.
	 * This is to conform to RouteOne's web service contract.
	 * @param creditContractVO
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	Document manipulateCVDocument(final CreditContractVO creditContractVO, final String xml) throws Exception;

	/**
	 * @param crDataXml
	 * @param subTotalsMap
	 * @param listOfXrefsForSubTotal
	 * @return
	 * @throws Exception
	 */
	String updateSubTotals(final String crDataXml, final Map<String, String> subTotalsMap,
			final List<DeCdkCloudCvXrefVO> listOfXrefsForSubTotal) throws Exception;

}
