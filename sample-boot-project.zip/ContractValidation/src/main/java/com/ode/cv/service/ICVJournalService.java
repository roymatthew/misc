/**
 * 
 */
package com.ode.cv.service;

import java.math.BigInteger;
import java.util.List;

import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.cv.vo.JournalObjectVO;

public interface ICVJournalService {

	Boolean addJournal(final CreditContractVO creditContractVO) throws Exception;
	
	Boolean addJournal(final CreditContractVO creditContractVO, final JournalObjectVO journalObject) throws Exception;
	
	void addToListOfJournalObjects(final JournalObjectVO journalObject, final CreditContractVO creditContractVO);
	
	CreditJournalVO getJournalForTransType(final DeDealVO deDealVO, final String transType) throws Exception;

	void addSingleJournalObject(CreditContractVO creditContractVO, JournalObjectVO journalObject) throws Exception;

	Boolean addSingleJournal(final CreditJournalVO creditJournalVO) throws Exception;

	Boolean addListOfJournals(final List<CreditJournalVO> listOfCreditJournals);
	
	String getCreditJournalXmlByLenderIdBodIdAndTrasType(final AccrVO accrVO, final String transType) throws Exception;

	CreditJournalVO getCreditJournalByKey(final BigInteger cjKey) throws Exception;
}
