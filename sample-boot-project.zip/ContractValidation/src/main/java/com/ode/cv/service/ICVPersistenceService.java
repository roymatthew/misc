/**
 * 
 */
package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public interface ICVPersistenceService {

	/**
	 * @param creditContractVO
	 */
	void saveCVData(final CreditContractVO creditContractVO, final DeDealVO dealVO,
			final DeContractValidationVO deContractValidationVO);

}
