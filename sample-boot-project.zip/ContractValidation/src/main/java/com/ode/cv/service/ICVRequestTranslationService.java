package com.ode.cv.service;

import com.ode.cv.vo.CreditContractVO;

/**
 * @author rmathew
 *
 */
public interface ICVRequestTranslationService {

	/**
	 * @param creditContractVO
	 * @param stylesheetId
	 * @param ecinXml
	 * @throws Exception
	 */
	void createContractout(final CreditContractVO creditContractVO, final String stylesheetId, final String ecinXml)
			throws Exception;

	/**
	 * @param creditContractVO
	 * @throws Exception
	 */
	void createContractConfOut(final CreditContractVO creditContractVO) throws Exception;
	
	/**
	 * @param creditContractVO
	 * @param stylesheetId
	 * @param ecinXml
	 * @throws Exception
	 */
	void createContractoutRE(final CreditContractVO creditContractVO, final String stylesheetId, final String ecinXml)
			throws Exception;
	
}
