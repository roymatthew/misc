package com.ode.cv.service;

import javax.jms.JMSException;

import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public interface ICdkCloudService {
	
	void prepareAndSendCdkCloudRequest(final String ecoutXml, final DeDealVO deDealVO, CreditContractVO creditContractVO) throws JMSException, Exception;

	void processCdkCloudJsonResponse(final String message);

	String notifyCDKCloudService(DeDealVO deDealVO) throws JMSException, Exception;
}