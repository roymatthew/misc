package com.ode.cv.service;

public interface ICommonService {

	public boolean isCdkCloudEnabled(final String lenderId, final String dealerId, final String dmsId);

	/**
	 * @param dmsId
	 * @return
	 */
	boolean getStandardDSPFlag(String dmsId);

}