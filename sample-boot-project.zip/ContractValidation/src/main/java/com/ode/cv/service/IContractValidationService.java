/**
 * 
 */
package com.ode.cv.service;

import org.w3c.dom.Document;

import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public interface IContractValidationService {
	
	/**
	 * @param creditContractVO
	 * @param document
	 * @param lenderId
	 * @param transType
	 * @return
	 */
	DeContractValidationBo createContractValidationBOFromDocument(final CreditContractVO creditContractVO, final Document document, final String transType);
	
	DeContractValidationVO saveContractValidation(final CreditContractVO creditContractVO, final DeDealVO deDealVO) throws Exception;
	
	public DeContractValidationVO getContractValidation(String deDealId, String cvSequenceId);

}
