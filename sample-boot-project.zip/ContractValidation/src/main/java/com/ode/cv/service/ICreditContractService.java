/**
 * 
 */
package com.ode.cv.service;

import com.ode.cv.vo.CreditContractVO;

/**
 * @author snimma
 *
 */
public interface ICreditContractService {

	public void processCreditContract(CreditContractVO creditContractVO) throws Exception;
}
