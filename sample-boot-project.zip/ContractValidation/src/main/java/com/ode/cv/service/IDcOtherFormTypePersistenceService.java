package com.ode.cv.service;

import java.util.List;

import com.ode.persistence.vo.DcOtherFormTypeVO;

public interface IDcOtherFormTypePersistenceService {

	public List<DcOtherFormTypeVO> findByDeDealId(String deDealId) throws Exception;
	
	public List<DcOtherFormTypeVO> saveOrUpdateAll(List<DcOtherFormTypeVO> dcOtherFormTypeVOList) throws Exception;
	
	public int deleteForDeDealId(String deDealId) throws Exception;
}
