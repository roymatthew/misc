/**
 * 
 */
package com.ode.cv.service;

import org.w3c.dom.Document;

import com.ode.cv.exception.CVFromDocumentException;
import com.ode.cv.exception.DocumentException;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public interface IDealService {
	
	/**
	 * @param cvFromDocument
	 * @param document
	 * @param transType
	 * @return
	 * @throws CVFromDocumentException 
	 * @throws DocumentException 
	 */
	DeDealBo createDealBOFromDocumentCV(final DeContractValidationBo cvFromDocument, final Document document, final String transType) throws CVFromDocumentException, DocumentException;
	
	/**
	 * @param nextDeDealId
	 * @return
	 */
	String getNextDeDealId(final int nextDeDealId);
	
	/**
	 * @param creditContractVO
	 * @return
	 */
	DeDealVO saveDeal(final CreditContractVO creditContractVO, final String transType);
	
	DeDealVO findDeDealById(final String deDealId) throws Exception;
	
	public DeDealVO updateDeDeal(final CreditContractVO creditContractVO, final String deDealId) throws Exception;

}
