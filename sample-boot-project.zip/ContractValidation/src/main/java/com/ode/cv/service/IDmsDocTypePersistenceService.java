package com.ode.cv.service;

import com.ode.persistence.vo.DmsDocTypeVO;

public interface IDmsDocTypePersistenceService {

	public DmsDocTypeVO getDmsDocType(String docName, String lenderId, String dmsId);
}
