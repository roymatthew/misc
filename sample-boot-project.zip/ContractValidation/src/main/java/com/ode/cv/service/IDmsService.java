package com.ode.cv.service;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;

public interface IDmsService {
    /**
     *
     * @param cvTransmitVO
     * @param creditContractVO
     * @throws Exception
     */
    void sendAccrToDMS(CVTransmitVO cvTransmitVO,
                       CreditContractVO creditContractVO) throws Exception;

    /**
     * Use this method to send ConfirmBOD to DMS when there is an internal error or-
     * communication to finance partner fails.
     * @param creditContractVO
     * @param xml
     * @throws Exception
     */
    void prepareAndSendNegativeConfirmBOD2Dms(final CreditContractVO creditContractVO, final String xml) throws Exception;
    
    /**
     * @param creditContractVO
     * @return
     * @throws Exception
     */
    String getDealerPartyId(final CreditContractVO creditContractVO) throws Exception;

}
