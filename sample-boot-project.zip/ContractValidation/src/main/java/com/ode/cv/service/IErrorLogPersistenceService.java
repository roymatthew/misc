package com.ode.cv.service;

import com.ode.persistence.vo.ErrorLogVO;

public interface IErrorLogPersistenceService {

	public ErrorLogVO saveOrUpdate(ErrorLogVO errorLogVO);
}
