package com.ode.cv.service;

import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.ErrorLogVO;

public interface IErrorLogService {

	ErrorLogVO addErrorLog(final DeDealVO deDeal, final String transactionId, final String transactionType, final String errorCode, final String errorMessage);

}
