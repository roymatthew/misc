/**
 * 
 */
package com.ode.cv.service;

import javax.jms.JMSException;

import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public interface IGenerateEformService {
	
	/**
	 * @param eformXml
	 * @param deDealVO
	 * @throws JMSException
	 * @throws Exception 
	 */
	public void generateEForm(final String ecAckinXml, final DeDealVO deDealVO) throws JMSException, Exception;

}
