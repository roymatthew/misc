package com.ode.cv.service;

import com.ode.persistence.vo.LenDocTypeVO;

public interface ILenDocTypePersistenceService {

	public LenDocTypeVO getLenDocType(String docName, String lenderId);
}
