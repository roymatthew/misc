/**
 * 
 */
package com.ode.cv.service;

import com.ode.persistence.vo.DeLenderVO;

/**
 * @author rmathew
 *
 */
public interface ILenderLookupService {
	
	/**
	 * @param lookupId
	 * @return
	 */
	DeLenderVO lookupLenderById(final String lookupId);

}
