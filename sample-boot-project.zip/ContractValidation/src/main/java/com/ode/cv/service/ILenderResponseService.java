package com.ode.cv.service;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.DeDealVO;

public interface ILenderResponseService {
    DeDealVO updateDealFromLenderResponse(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO) throws Exception;

    void processSyncAccrFromLender(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO) throws Exception;

    void processConfirmBodFromLender(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO)
            throws Exception;
}
