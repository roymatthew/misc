/**
 * 
 */
package com.ode.cv.service;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;


public interface ILenderService {
 
	/**
	 *
     * @param cvTransmitVO
     * @param creditContractVO
     * @param xml
     * @throws Exception
	 */
	ECConfinVO prepareAndPostCVToLender(CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO, final String xml, final Boolean isStandard) throws Exception;

	ECConfinVO sendProcessCreditContract(CreditContractVO creditContractVO, ECConfinVO ecConfinVO, String lenderId, String lenderRequestXml, CVTransmitVO cvTransmitVO) throws Exception;
}
