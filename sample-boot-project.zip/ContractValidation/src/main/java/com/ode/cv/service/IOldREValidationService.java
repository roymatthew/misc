/**
 * 
 */
package com.ode.cv.service;

import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public interface IOldREValidationService {
	
	ECConfinVO validateCVAgainstOldRE(final CreditContractVO creditContractVO, final DeDealVO dealVO) throws Exception;

}
