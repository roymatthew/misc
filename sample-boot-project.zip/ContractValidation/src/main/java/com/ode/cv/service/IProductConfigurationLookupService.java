package com.ode.cv.service;

import java.util.List;

import com.ode.commons.util.vo.CommonsUtilNvpVO;
import com.ode.persistence.entity.DeDmsDestination;
import com.ode.persistence.vo.DeLenderDestinationVO;
import com.ode.persistence.vo.FeatureConfigurationVO;

/**
 * @author rmathew
 *
 */
public interface IProductConfigurationLookupService {
	
	
	/**
	 * @param lenderId
	 */
	void loadConfigurations(final String lenderId);	
	/**
	 * @param lenderId
	 */
	void loadFeatureConfigurationsForLender(final String lenderId);
	/**
	 * @param lenderId
	 */
	void loadLenderDestinations(final String lenderId);
	void loadDmsFeatureConfigurations();

	/**
	 * @param dmsId String
	 * @param product String
	 * @param featureName String
	 * @return
	 */
	String getDmsFeatureConfigurationValue(final String dmsId, final String product, final String featureName);

	/**
	 * @param productId String (product).
	 * @param lenderId String
	 * @return
	 */
	DeLenderDestinationVO getCVDestination(final String productId, final String lenderId);

	/**
	 * @param dmsId
	 * @param application
	 * @param product
	 * @return
	 */
	DeDmsDestination getDeDmsDestination(final String dmsId, final String application, final String product);

	/**
	 * @param value
	 * @return
	 */
	boolean cvMessageProcessingContainsValue(final String value);

	/**
	 * @param value
	 * @param dmsId
	 * @return
	 */
	boolean cvMessageProcessingContainsValue(final String value, final String dmsId);

	/**
	 * @param value
	 * @return
	 */
	boolean cvMessageProcessingStartsWithValue(final String value);
	
	/**
	 * @param featureName
	 * @param dmsId
	 * @return
	 */
	boolean isFeatureConfigurationAvailable(final String featureName, final String dmsId);
	
	/**
	 * @return
	 */
	boolean isRFLFeatureEnabled();
	
	/**
	 * @param featureName
	 * @param dmsId
	 * @return
	 */
	String getFeatureValue(String featureName, String dmsId);
	
	/**
	 * @return
	 */
	List<FeatureConfigurationVO> getWebServiceFeatures();
	

}
