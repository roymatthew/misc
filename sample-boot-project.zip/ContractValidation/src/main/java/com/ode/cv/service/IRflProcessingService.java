package com.ode.cv.service;

import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;

/**
 * @author rmathew
 *
 */
public interface IRflProcessingService {
	
	/**
	 * @param cvTransmitVO
	 */
	void processRfl(final CVTransmitVO cvTransmitVO, final AccrVO accrVO);

}
