/**
 * 
 */
package com.ode.cv.service;

import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;

/**
 * @author snimma
 *
 */
public interface IRouteOneService {
 
	/**
	 * @param creditContractVO
	 * @param xml
	 * @throws Exception
	 */
	ECConfinVO prepareAndPostCVToRouteOne(CreditContractVO creditContractVO, String xml, boolean isCdkCloudEnabled) throws Exception;

	/**
	 * @param parmName
	 * @param partnerId
	 * @param dealerId
	 * @param productId
	 * @return
	 */
	String findRouteOneDealerId(final String parmName, final String partnerId, final String dealerId, final String productId);

	/**
	 * @param creditContractVO
	 * @param ecout3
	 * @return ECConfinVO
	 * @throws Exception
	 */
	ECConfinVO postECOUT3ToRouteOne(CreditContractVO creditContractVO, String ecout3) throws Exception;

}
