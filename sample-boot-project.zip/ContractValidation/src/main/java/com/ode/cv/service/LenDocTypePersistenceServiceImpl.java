package com.ode.cv.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ode.persistence.service.LenDocTypeRepoService;
import com.ode.persistence.vo.LenDocTypeVO;

@Service
public class LenDocTypePersistenceServiceImpl implements ILenDocTypePersistenceService {

	private static final Logger logger = LogManager.getLogger(LenDocTypePersistenceServiceImpl.class);
	
	@Autowired
	private LenDocTypeRepoService lenDocTypeRepoService;
	
	@Override
	@Transactional(value = "transactionManager")
	public LenDocTypeVO getLenDocType(String docName, String lenderId) {
		logger.debug("Entered getLenDocType, docName: {}, lenderId: {}", docName, lenderId);
		return lenDocTypeRepoService.getLenDocType(docName, lenderId);
	}
}
