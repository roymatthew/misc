/**
 *
 */
package com.ode.cv.service;

import com.ode.persistence.service.DeLenderPartnerRepoService;
import com.ode.persistence.service.DeLenderRepoService;
import com.ode.persistence.vo.DeLenderPartnerVO;
import com.ode.persistence.vo.DeLenderVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author rmathew
 *
 */
@Service
public class LenderLookupServiceImpl implements ILenderLookupService {

	private static final Logger logger = LogManager.getLogger(LenderLookupServiceImpl.class);

	@Autowired
	private DeLenderRepoService deLenderRepoService;
	@Autowired
	private DeLenderPartnerRepoService deLenderPartnerRepoService;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DeLenderVO lookupLenderById(final String lookupId) {
		logger.debug("Entered lookupLenderById() method of LenderLookupServiceImpl class. lookupId: {}", lookupId);

		DeLenderVO deLenderVO = deLenderRepoService.getByLenderId(lookupId);
		if (null == deLenderVO) {
			logger.debug("Lender not found for lenderId: {}", lookupId);
			// try getting lender partner and use partner lender id to fetch DeLenderVO
			logger.debug("Looking up partner by partnerId: {}", lookupId);
			DeLenderPartnerVO deLenderPartnerVO = deLenderPartnerRepoService.getByPartnerId(lookupId);
			if (null != deLenderPartnerVO) {
				deLenderVO = deLenderRepoService.getByLenderId(deLenderPartnerVO.getLenderId());
			} else {
				logger.debug("LenderPartner not found for partnerId: {}", lookupId);
			}
		}
		return deLenderVO;
	}

}
