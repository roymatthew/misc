package com.ode.cv.service;

import com.ode.cv.context.ErrorLogError;
import com.ode.cv.factory.JournalFactory;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.DeDealRepoService;
import com.ode.persistence.vo.DeDealVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class LenderResponseServiceImpl implements ILenderResponseService{

    private static final Logger logger = LogManager.getLogger(LenderResponseServiceImpl.class);

    @Autowired
    private DeDealRepoService deDealRepoService;

    @Autowired
    private CVTransmitClient cvTransmitClient;

    @Autowired
    private CVResponseXMLParser cvResponseXmlParser;

    @Autowired
    private IProductConfigurationLookupService productConfigurationLookupService;

    @Autowired
    private IAccrRequestTranslationService accrRequestTranslationService;

    @Autowired
    private IErrorLogService errorLogService;

    @Autowired
    private ApplpEventHandler applpEventHandler;

    /**
     * @param cvTransmitVO
     * @param creditContractVO
     * @return
     * @throws Exception
     */
    @Override
    public DeDealVO updateDealFromLenderResponse(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO) throws Exception {
        logger.debug("Enter updateDealFromLenderResponse() method of LenderResponseService class");
        DeDealVO deDealVO = deDealRepoService.findDeDealByDmsDealId(creditContractVO.getDeal().getDmsDealNum(), creditContractVO.getDealerInfo().getDealerId(),
                creditContractVO.getPartnerInfo().getLenderId());
        deDealVO.setCvStatus(creditContractVO.getAccr().getValidationResults());
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        deDealVO.setCvStatusTs(currentTime);
        deDealVO.setModifiedTs(currentTime);
        deDealVO.setLastModifiedTs(currentTime);
        creditContractVO.getContractValidation().setStatus(creditContractVO.getAccr().getValidationResults());
        creditContractVO.getContractValidation().setStatusTs(currentTime);
        deDealVO.setModifiedBy(Constants.APP_CV_CODE);
        deDealVO.setCvSequenceId(creditContractVO.getContractValidation().getSequenceId());
        cvTransmitVO.setDealVO(deDealRepoService.saveOrUpdate(deDealVO));
        logger.debug("Finished Saving Deal from Lender Response");
        return deDealVO;
    }

    @Override
    public void processSyncAccrFromLender(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO) throws Exception {
        logger.debug("Entered processSyncAccrFromLender() Method of AccrServiceImpl class");
        ECConfinVO ecConfinVO = cvTransmitVO.getEcConfinVO();
        AccrVO accrInput = new AccrVO();
        accrInput.setAccrRequestXml(cvTransmitVO.getAccrResponseXml());
        AccrVO accrVO = cvResponseXmlParser.populateAccrDetailsFromInput(accrInput);
        accrVO.setBodId(creditContractVO.getDocumentId());
        creditContractVO.setAccr(accrVO);
        cvTransmitVO.setAccrContext(accrVO);
        cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
        updateDealFromLenderResponse(cvTransmitVO, creditContractVO);

        String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
                ecConfinVO.getDmsId(), Constants.ACCR, Constants.STYLESHEET);
        accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);

        String accrOut = cvTransmitVO.getAccroutXml();
        logger.debug("Accr to DMS: {}", accrOut);
        JournalObjectVO ecConfInJournalObject = JournalFactory.createJournalObject(
                Constants.TRANS_TYPE_EC_ACK_OUT, creditContractVO.getAppMsg(), accrOut);
        creditContractVO.addToListOfJournalObjects(ecConfInJournalObject);
        cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, ecConfinVO.getDmsId());
    }

    /**
     * @param cvTransmitVO
     * @param creditContractVO
     * @throws Exception
     */
    @Override
    public void processConfirmBodFromLender(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO)
            throws Exception {
        logger.debug("Enter processConfirmBodFromLender() method of AccrServiceImpl class");

        AccrVO accrVo = new AccrVO();
        accrVo.setAccrRequestXml(cvTransmitVO.getAccrResponseXml());
        cvResponseXmlParser.populateAccrDetailsFromEcout2(creditContractVO.getLenderRequestXml(), accrVo);
        accrVo.setBodId(creditContractVO.getDocumentId());
        accrVo.setValidationResults(Constants.FAILED);
        creditContractVO.setAccr(accrVo);
        cvTransmitVO.setAccrContext(accrVo);
        cvTransmitVO.setDealerInfoVO(creditContractVO.getDealerInfo());
        DeDealVO deDealVO = updateDealFromLenderResponse(cvTransmitVO, creditContractVO);

        List<ErrorLogError> errors = cvResponseXmlParser.extractErrorsFromEcout2(creditContractVO.getLenderResponseXml());
        for (ErrorLogError error : errors) {
            logger.debug("Adding error to ERROR_LOG table {}", error);
            errorLogService.addErrorLog(deDealVO, null, creditContractVO.getTransType(), error.getErrorCode(), error.getErrorMessage());
        }

        String stylesheetId = productConfigurationLookupService.getDmsFeatureConfigurationValue(
                creditContractVO.getDealerInfo().getDspId(), Constants.CONFIRMBOD, Constants.STYLESHEET);
        accrRequestTranslationService.createDMSOut(cvTransmitVO, creditContractVO, stylesheetId);
        AppMessage ecConfOutAppMsg = applpEventHandler.handleEvents(Constants.Event_Success);
        JournalObjectVO ecConfOutJournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_CONF_OUT,
                ecConfOutAppMsg, cvTransmitVO.getAccroutXml());
        creditContractVO.addToListOfJournalObjects(ecConfOutJournalObject);
        cvTransmitClient.sendXmlOutputToDms(cvTransmitVO, creditContractVO.getDealerInfo().getDspId());
    }
}
