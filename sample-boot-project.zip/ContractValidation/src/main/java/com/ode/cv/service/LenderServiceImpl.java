package com.ode.cv.service;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.ResponseMessage;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.DeLenderDestinationRepoServiceImpl;
import com.ode.persistence.vo.DeLenderDestinationVO;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilderFactory;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class LenderServiceImpl implements ILenderService {

	private static final Logger logger = LogManager.getLogger(LenderServiceImpl.class);

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;
	
	@Autowired
	DeLenderDestinationRepoServiceImpl deLenderDestinationRepoServiceImpl;

	@Autowired
	private CVTransmitClient cvTransmitClient;

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private ApplpEventHandler appCVEventHandler;

	@Autowired 
	private IDmsService dmsService;
	
	@Autowired
	private ICVDocumentManipulationService cvDocumentManipulationService;

	@Autowired
	private ILenderResponseService lenderResponseService;

	@Override
	public ECConfinVO prepareAndPostCVToLender(CVTransmitVO cvTransmitVO, CreditContractVO creditContractVO, String xml,
											   Boolean isStandard) throws Exception {
		logger.debug("Enter prepareAndPostCVToLender() method of LenderServiceImpl class. Deal: {}",
				creditContractVO.getDeal());
		ECConfinVO ecConfinVO = new ECConfinVO();
		String lenderId = null;
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("***** Start posting Lender CV request at: {} *****", start);

		if (null != creditContractVO && null != creditContractVO.getDeal()) {
			if (null != creditContractVO.getDealerInfo()) {
				ecConfinVO.setDmsId(creditContractVO.getDealerInfo().getDspId());
			}
			if (null != creditContractVO.getPartnerInfo()) {
				lenderId = creditContractVO.getPartnerInfo().getLenderId();
				ecConfinVO.setLenderId(lenderId);
			}
		}

		Document document = cvRequestXmlParser.getDocument(xml);

		if (StringUtils.isEmpty(creditContractVO.getDocumentId())) {
			String documentId =  XPathAPI.eval(document, "//payload/content/ProcessCreditContract/DataArea/CreditContract/Header/DocumentId").toString();
			logger.debug("Request Document ID: {}",documentId);
			creditContractVO.setDocumentId(documentId);
		}
		if (StringUtils.isEmpty(creditContractVO.getDeal().getLenderDealerId())) {
			String lenderDealerId = XPathAPI.eval(document, "//ProcessCreditContract/DataArea/CreditContract/Dealer/PartyId").toString();
			creditContractVO.getDeal().setLenderDealerId(lenderDealerId);
		}

		Document modifiedDocument = null;
		/*
		 * @TODO.
		 * Do we need to remove 'revision' and 'schemaLocation' attributes from
		 * PCC element of Advent CV ??
		 */
		if (Constants.ADVENT_DMS_ID.equalsIgnoreCase(creditContractVO.getDealerInfo().getDspId())) {
			modifiedDocument = CVUtil.restructureCVDocumentForLender(document);
		} else {
			modifiedDocument = cvDocumentManipulationService.makeRequiredChangesToECOUTForLender(creditContractVO,
					document);
		}

		String lenderRequestXml = CVUtil.getXmlStringFromDocument(modifiedDocument);
		logger.debug("Lender CV Request: {}", lenderRequestXml);

		AppMessage cvAppMsg	= appCVEventHandler.handleEvents("Success");;
		JournalObjectVO ecout2JournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_OUT2, cvAppMsg,
				lenderRequestXml);
		cvJournalService.addJournal(creditContractVO, ecout2JournalObject);

		if (cvTransmitVO.isCdkCloudEnabled()) {
			logger.debug("Lender is CdkCloudEnabled. Skipping posting CV request to lender.");
			ecConfinVO.setRequestXML(lenderRequestXml);
			ecConfinVO.setStatusMessage(Constants.OPERATION_SUCCESS_MESSSAGE);
			return ecConfinVO;
		}

		Boolean isLenderIntegrated = cvTransmitClient.getVolvoIntegration(lenderId, creditContractVO.getDealerInfo().getDealerId());
		if (Constants.ADVENT_DMS_ID.equalsIgnoreCase(creditContractVO.getDealerInfo().getDspId()) ||
				isLenderIntegrated || isStandard) {
			sendProcessCreditContract(creditContractVO, ecConfinVO, lenderId, lenderRequestXml, cvTransmitVO);
		} else {
			logger.debug("Lender is not integrated - Sending ACCR to DMS");
			dmsService.sendAccrToDMS(cvTransmitVO, creditContractVO);
			ecConfinVO = cvTransmitVO.getEcConfinVO();
			logger.debug("HttpStatusCode from DMS: {}", ecConfinVO.getStatusCode());
		}

		final LocalDateTime end = LocalDateTime.now();

		logger.debug("***** End posting Lender CV request at: {} *****", end);
		logger.debug("Posting CV to Lender took {} milliseconds", ChronoUnit.MILLIS.between(start, end));

		return ecConfinVO;
	}

	@Override
	public ECConfinVO sendProcessCreditContract(CreditContractVO creditContractVO, ECConfinVO ecConfinVO, String lenderId, String lenderRequestXml, CVTransmitVO cvTransmitVO) throws Exception {
		logger.debug("Entered sendProcessCreditContract() method of LenderServiceImpl class. LenderId: {}", lenderId);

		logger.debug("Getting Lender Destination using LenderId: {} and ApplicationId: {}.", lenderId, Constants.APP_CV_CODE);
		String destinationLenderId = CVUtil.getDestinationLender(creditContractVO, lenderId);
		List<DeLenderDestinationVO> lenderDestinationList = deLenderDestinationRepoServiceImpl.getByLenderId(destinationLenderId, Constants.APP_CV_CODE);
		DeLenderDestinationVO lenderDestination = null;
		if (null != lenderDestinationList && !lenderDestinationList.isEmpty()) {
			logger.debug("Received {} results from DE_LENDER_DESTINATION", lenderDestinationList.size());
			lenderDestination = lenderDestinationList.get(0);
		} else {
			logger.error("Unable to determine Lender Destination for LenderID: {}", lenderId);
		}

		ecConfinVO.setRequestXML(lenderRequestXml);
		creditContractVO.setLenderRequestXml(lenderRequestXml);
		ResponseMessage responseMessage = null;
		if (StringUtils.isNotBlank(lenderRequestXml)) {
			try {
				MultiValueMap<String, String> headers = getLenderSpecificHeaders(lenderDestination);
				responseMessage = cvTransmitClient.postCVToLender(lenderRequestXml, lenderDestination.getDestinationUrl(), headers);
				if (null != responseMessage) {
					ecConfinVO.setStatusCode(responseMessage.getStatusCode());
				}
			} catch (Exception e) {
				logger.error("Exception Posting to Lender");
				ecConfinVO.setEcConfinMessage(Constants.OPERATION_FAILED_MESSSAGE);
				ecConfinVO.setStatusMessage(Constants.OPERATION_FAILED_MESSSAGE);
			}
		} else {
			logger.debug("Lender CV Request was blank");
			creditContractVO.setLenderRequestXml("<xml>Error - Blank Request</xml>");
		}
		processLenderResponse(ecConfinVO, creditContractVO, responseMessage, cvTransmitVO);

		return ecConfinVO;
	}

	/**
	 * @param ecConfinVO
	 * @param creditContractVO
	 * @param responseMessage
	 * @throws Exception
	 */
	private void processLenderResponse(ECConfinVO ecConfinVO, CreditContractVO creditContractVO, ResponseMessage responseMessage, CVTransmitVO cvTransmitVO) throws Exception {
        logger.debug("Entered processLenderResponse() method of LenderServiceImpl");
        AppMessage cvAppMsg;


        if (null != responseMessage && (HttpStatus.SC_OK == responseMessage.getStatusCode())) {
            cvAppMsg = appCVEventHandler.handleEvents("Success");
            ecConfinVO.setStatusMessage(Constants.OPERATION_SUCCESS_MESSSAGE);
            ecConfinVO.setEcConfinMessage(responseMessage.getResponseXml());
            String lenderResponseXml = "";
            if (StringUtils.isNotEmpty(responseMessage.getResponseXml())) {
            	lenderResponseXml = responseMessage.getResponseXml();
			}
            creditContractVO.setLenderResponseXml(lenderResponseXml);
            creditContractVO.setLenderResponseMessage(responseMessage);
			cvTransmitVO.setEcConfinVO(ecConfinVO);
			cvTransmitVO.setAccrResponseXml(creditContractVO.getLenderResponseXml());
            if (lenderResponseXml.contains(Constants.CONFIRM_BOD)) {
                logger.debug("Processing Lender ConfirmBod");
                JournalObjectVO ecConfInJournalObject = JournalFactory.createJournalObject(
                        Constants.TRANS_TYPE_EC_CONF_IN, cvAppMsg, responseMessage.getResponseXml());
				cvJournalService.addJournal(creditContractVO, ecConfInJournalObject);
				lenderResponseService.processConfirmBodFromLender(cvTransmitVO, creditContractVO);
            } else if (lenderResponseXml.contains(Constants.LENDER_RESPONSE_ACCR)) {
                logger.debug("Processing Lender Accr");
                JournalObjectVO ecAckIn2JournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_ACK_IN, cvAppMsg, responseMessage.getResponseXml());
                cvJournalService.addJournal(creditContractVO, ecAckIn2JournalObject);
                creditContractVO.addToListOfJournalObjects(ecAckIn2JournalObject);
                creditContractVO.setAppMsg(cvAppMsg);
				lenderResponseService.processSyncAccrFromLender(cvTransmitVO, creditContractVO);
            } else {
				logger.debug("No Lender Accr or ConfirmBod - Assuming asynchronous response");
				JournalObjectVO ecconfin2JournalObject = JournalFactory
						.createJournalObject(Constants.TRANS_TYPE_EC_CONF_IN2, cvAppMsg, responseMessage.getResponseXml());
				cvJournalService.addJournal(creditContractVO, ecconfin2JournalObject);
			}
        } else {
            ecConfinVO.setStatusMessage(Constants.OPERATION_FAILED_MESSSAGE);
			cvTransmitVO.setEcConfinVO(ecConfinVO);
        }

	}

	/**
	 * @param lenderDestination
	 * @return
	 */
	private MultiValueMap<String, String> getLenderSpecificHeaders(DeLenderDestinationVO lenderDestination) {
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		if (Constants.AUTH_TYPE_LDAP.equals(lenderDestination.getWsAuthType())) {
			String base64LdapAuth = new String(Base64.encodeBase64(lenderDestination.getWsUsername().getBytes()));
			headers.add(Constants.HEADER_AUTH_LABEL, Constants.AUTH_HEADER_TYPE_BASIC + base64LdapAuth);
			headers.add(Constants.HEADER_COOKIE_LABEL, lenderDestination.getWsPassword());
		} else if (Constants.AUTH_TYPE_OAUTH2.equals(lenderDestination.getWsAuthType())) {
			String token = cvTransmitClient.getOauth2Token(lenderDestination.getDeLenderId());
			headers.add(Constants.HEADER_AUTH_LABEL, Constants.AUTH_HEADER_TYPE_BEARER + token);
		}

		if (StringUtils.isNotEmpty(lenderDestination.getWsContentType())) {
			String contentType = lenderDestination.getWsContentType();
			headers.add(Constants.HTTP_HEADERS_CONTENT_TYPE_LABEL, contentType);
			logger.debug("Added Content-Type header with value of {}", contentType);
		}

		if (StringUtils.isNotEmpty(lenderDestination.getWsSoapAction())) {
			String soapAction = lenderDestination.getWsSoapAction();
			headers.add(Constants.HTTP_HEADERS_SOAP_ACTION_LABEL, soapAction);
			logger.debug("Added SOAPAction header with value of {}", soapAction);
		}

		return headers;
	}

}
