/**
 *
 */
package com.ode.cv.service;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.vo.DeDealVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

/**
 * @author rmathew
 *
 */
@Service
public class OldREValidationServiceImpl implements IOldREValidationService {

	private static final Logger logger = LogManager.getLogger(OldREValidationServiceImpl.class);

	@Autowired
	private IAccrService accrService;

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private ICVRequestTranslationService cvRequestTranslationService;

	@Autowired
	private ApplpEventHandler appCVEventHandler;

	@Autowired
	private CVResponseXMLParser cvResponseXMLParser;

	@Autowired
	private CVTransmitClient transmitClient;

	@Autowired
	private IDmsService dmsService;
	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ode.cv.service.IOldREValidationService#validateCVAgainstOldRE(com.ode.cv.
	 * vo.CreditContractVO)
	 */
	@Override
	public ECConfinVO validateCVAgainstOldRE(final CreditContractVO creditContractVO, final DeDealVO dealVO) throws Exception {
		logger.debug("Entered validateCVAgainstOldRE() method of OldREValidationServiceImpl class");
		cvRequestTranslationService.createContractoutRE(creditContractVO, creditContractVO.getDealerInfo().getDspId(),
				creditContractVO.getRequestXML());
		AppMessage sappMsg = appCVEventHandler.handleEvents("Success");
		JournalObjectVO cvReEcoutjournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_CV_OLDRE_ECOUT,
				sappMsg, creditContractVO.getLenderRequestXml());
		cvJournalService.addJournal(creditContractVO, cvReEcoutjournalObject);
		ECConfinVO reResponse = transmitClient.sendTranslatedXMLToRE(creditContractVO,
				creditContractVO.getDealerInfo().getDspId());
		// if there is a 500 or 404 error we need to handle that
		reResponse.setRequestXML(cvResponseXMLParser.removeSchemaPrefixIfAny(reResponse.getRequestXML()));
		if (HttpStatus.OK.value() == reResponse.getStatusCode()) {
			String validationResults = cvResponseXMLParser
					.getValidationResultsFromOldREResponse(reResponse.getRequestXML());
			logger.debug("Validation results from Old RE: {}", validationResults);
			JournalObjectVO rECBODjournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_CV_OLDRE_ECACKIN,
					sappMsg, reResponse.getRequestXML());
			cvJournalService.addJournal(creditContractVO, rECBODjournalObject);
			if (Constants.FAILED.equalsIgnoreCase(validationResults)) {
				creditContractVO.setLenderRequestXml(reResponse.getRequestXML());
				CVTransmitVO cvTransmitVO = VOFactory.createCVTransmitVO(creditContractVO);
				cvTransmitVO.setDealVO(dealVO);
				cvTransmitVO.setEcConfinVO(reResponse);
				/*send failed ACCR to DMS*/
				dmsService.sendAccrToDMS(cvTransmitVO, creditContractVO);
				reResponse.setStatusMessage(validationResults);
			}
		} else {
			reResponse.setStatusMessage(Constants.FAILED);
			AppMessage appMessage = CVUtil.traslateErroCodeToStandardMessage(appCVEventHandler, reResponse);
			creditContractVO.setAppMsg(appMessage);
			creditContractVO.setLenderRequestXml(creditContractVO.getRequestXML());
			/* send confirmBOD to DMS to let them know that OLD RE validation failed. */
			dmsService.prepareAndSendNegativeConfirmBOD2Dms(creditContractVO, reResponse.getRequestXML());
			dealVO.setCvStatus(creditContractVO.getAccr().getValidationResults());
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			dealVO.setCvStatusTs(currentTime);
			dealVO.setModifiedTs(currentTime);
			dealVO.setLastModifiedTs(currentTime);
			creditContractVO.getContractValidation().setStatus(creditContractVO.getAccr().getValidationResults());
			creditContractVO.getContractValidation().setStatusTs(currentTime);
			dealVO.setModifiedBy(Constants.APP_CV_CODE);
		}

		return reResponse;
	}

}
