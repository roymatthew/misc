/**
 * 
 */
package com.ode.cv.service;

import com.ode.cv.util.Constants;
import com.ode.persistence.entity.DeDmsDestination;
import com.ode.persistence.repository.DeDmsDestinationRepo;
import com.ode.persistence.service.DeLenderDestinationRepoService;
import com.ode.persistence.service.DmsFeatureConfigurationRepoService;
import com.ode.persistence.service.FeatureConfigurationRepoService;
import com.ode.persistence.vo.DeLenderDestinationVO;
import com.ode.persistence.vo.DmsFeatureConfigurationVO;
import com.ode.persistence.vo.FeatureConfigurationVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author rmathew
 *
 */
@Service
public class ProductConfigurationLookupServiceImpl implements IProductConfigurationLookupService {

	private static final Logger logger = LogManager.getLogger(ProductConfigurationLookupServiceImpl.class);

	@Autowired
	private FeatureConfigurationRepoService featureConfigurationRepoService;

	@Autowired
	private DeLenderDestinationRepoService lenderDestinationRepoService;

	@Autowired
	private DmsFeatureConfigurationRepoService dmsFeatureConfigurationRepoService;

	@Autowired
	private DeDmsDestinationRepo deDmsDestinationRepoService;

	private Map<String, FeatureConfigurationVO> mapOfFeatureConfigurations = new HashMap<>();
	private List<DmsFeatureConfigurationVO> listOfDmsFeatureConfigurations = new ArrayList<>();
	private Map<String, DeLenderDestinationVO> mapOfCVDestinations = new HashMap<>();
	private List<FeatureConfigurationVO> listOfWebServiceFeatures = new ArrayList<>();

	private static final String DMS = "DMS";
	private static final String APPLICATION = "CV";
	private static String COMPARISON_OPERATION_EQUALS = "COMPARISON_OPERATION_EQUALS";
	private static String COMPARISON_OPERATION_STARTS_WITH = "COMPARISON_OPERATION_STARTS_WITH";

	@Override
	public void loadConfigurations(final String lenderId) {

		if (!mapOfFeatureConfigurations.isEmpty()) {
			mapOfFeatureConfigurations.clear();
		}

		if (!mapOfCVDestinations.isEmpty()) {
			mapOfCVDestinations.clear();
		}
		
		if (!listOfWebServiceFeatures.isEmpty()) {
			listOfWebServiceFeatures.clear();
		}

		if (!listOfDmsFeatureConfigurations.isEmpty()) {
			listOfDmsFeatureConfigurations.clear();
		}

		loadFeatureConfigurationsForLender(lenderId);
		loadLenderDestinations(lenderId);
		loadDmsFeatureConfigurations();
	}

	@Override
	public void loadFeatureConfigurationsForLender(final String lenderId) {
		logger.debug(
				"Entered loadFeatureConfigurationsForLender() method of ProductConfigurationLookupServiceImpl class. lenderId: {}",
				lenderId);
		List<FeatureConfigurationVO> listOfFeatureConfigurations = null;

		try {
			listOfFeatureConfigurations = featureConfigurationRepoService.getByLenderId(lenderId);

		} catch (final Exception e) {
			logger.error(e);
		}

		if (null != listOfFeatureConfigurations && !listOfFeatureConfigurations.isEmpty()) {

			listOfFeatureConfigurations.stream().forEach(featureConf -> {

				String dms = DMS;

				if (StringUtils.isNotEmpty(featureConf.getDmsId())) {
					dms = featureConf.getDmsId();
				}

				String key = dms + "-" + featureConf.getProduct() + "-" + featureConf.getFeatureName();
				key = key.toUpperCase();
				logger.debug("Adding featureConf with key: " + key);

				mapOfFeatureConfigurations.put(key, featureConf);
				
				if (StringUtils.isNotBlank(featureConf.getProduct()) && Constants.PRODUCT_WEBSVC.equalsIgnoreCase(featureConf.getProduct()))
				{
					listOfWebServiceFeatures.add(featureConf);
				}

			});
		} else {
			logger.debug("Could not find feature configurations for lender: " + lenderId);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ode.cv.service.IProductConfigurationLookupService#loadDestinations(java.
	 * lang.String)
	 */
	@Override
	public void loadLenderDestinations(final String lenderId) {
		logger.debug("Entered loadLenderDestinations() method of ProductConfigurationLookupServiceImpl class. lenderId: {}",
				lenderId);

		List<DeLenderDestinationVO> listOfLenderDestinations = null;

		try {
			listOfLenderDestinations = lenderDestinationRepoService.getByLenderId(lenderId, APPLICATION);
		} catch (Exception e) {
			logger.error(e);
		}

		if (null != listOfLenderDestinations && !listOfLenderDestinations.isEmpty()) {

			listOfLenderDestinations.stream().forEach(cvDestination -> {

				String key = cvDestination.getDeLenderId() + "-" + cvDestination.getApplication() + "-"
						+ cvDestination.getProduct();
				key = key.toUpperCase();
				logger.debug("Adding cvDestination with key: " + key);
				mapOfCVDestinations.put(key, cvDestination);

			});
		} else {
			logger.debug("Could not find lender destinations for lender: " + lenderId);
		}
	}

	@Override
	public void loadDmsFeatureConfigurations() {
		logger.debug("Entered loadDmsFeatureConfigurations() method of ProductConfigurationLookupServiceImpl class.");
		listOfDmsFeatureConfigurations = dmsFeatureConfigurationRepoService.findAll();
	}

	@Override
	public String getDmsFeatureConfigurationValue(final String dmsId, final String product, final String featureName) {
		logger.debug("Entered getDmsFeatureConfigurationValue() method of ProductConfigurationLookupServiceImpl class. " +
						"dmsId: {}, product: {}, featureName: {}", dmsId, product, featureName);
		List<DmsFeatureConfigurationVO> matches = listOfDmsFeatureConfigurations.stream().filter(dmsFeatureConfigurationVO ->
				dmsId.equalsIgnoreCase(dmsFeatureConfigurationVO.getDmsId()) &&
						product.equalsIgnoreCase(dmsFeatureConfigurationVO.getProduct()) &&
						featureName.equalsIgnoreCase(dmsFeatureConfigurationVO.getFeatureName()))
				.sorted(Collections.reverseOrder())
				.collect(Collectors.toList());
		String result = matches.isEmpty() ? null : matches.get(0).getFeatureValue();
		if (null == result) {
			logger.warn("Unable to find DMS_FEATURE_CONFIGURATION entry with dmsId: {}, product: {}, featureName: {}",
					dmsId, product, featureName);
		} else {
			logger.debug("Found DMS_FEATURE_CONFIGURATION value: {}", result);
		}
		return result;
	}

	@Override
	public DeLenderDestinationVO getCVDestination(final String productId, final String lenderId) {

		logger.debug(
				"Entered getCVDestination() method of ProductConfigurationLookupServiceImpl class. productId: {}, lenderId: {}",
				productId, lenderId);
		String key = lenderId + "-" + APPLICATION + "-" + productId;
		key = key.toUpperCase();
		logger.debug("Lookup key: " + key);
		DeLenderDestinationVO deLenderDestinationVO = mapOfCVDestinations.get(key);
		return deLenderDestinationVO;
	}

	@Override
	public DeDmsDestination getDeDmsDestination(final String dmsId, final String application, final String product) {
		logger.debug("Entered getDeDmsDestination() method in ProductConfigurationLookupServiceImpl class. " +
				"dmsId: {}; application: {}; product: {}.", dmsId, application, product);
		List<DeDmsDestination> deDmsDestinations = deDmsDestinationRepoService.selectSpecificDmsDestination(dmsId,
				application, product);
		return (null != deDmsDestinations && !deDmsDestinations.isEmpty()) ? deDmsDestinations.get(0) : null;
	}

	/**
	 * @param value
	 * @return
	 */
	public boolean cvMessageProcessingContainsValue(final String value) {
		logger.debug(
				"Entered cvMessageProcessingContainsValue() method of ProductConfigurationLookupServiceImpl class. value: {}",
				value);
		return cvMessageProcessingHasValue(value, COMPARISON_OPERATION_EQUALS, null);
	}

	/**
	 * @param value
	 * @param dmsId
	 * @return
	 */
	public boolean cvMessageProcessingContainsValue(final String value, final String dmsId) {
		logger.debug(
				"Entered cvMessageProcessingContainsValue() method of ProductConfigurationLookupServiceImpl class. value = {}, dmsId = {}",
				value, dmsId);
		return cvMessageProcessingHasValue(value, COMPARISON_OPERATION_EQUALS, dmsId);
	}

	/**
	 * @param value
	 * @return
	 */
	public boolean cvMessageProcessingStartsWithValue(final String value) {
		logger.debug(
				"Entered cvMessageProcessingStartsWithValue() method of ProductConfigurationLookupServiceImpl class. value = {}",
				value);
		return cvMessageProcessingHasValue(value, COMPARISON_OPERATION_STARTS_WITH, null);
	}

	/**
	 * @param value
	 * @param comparisonOperation
	 * @param dmsId
	 * @return
	 */
	private boolean cvMessageProcessingHasValue(final String value, final String comparisonOperation,
			final String dmsId) {
		logger.debug(
				"Entered cvMessageProcessingHasValue() method of ProductConfigurationLookupServiceImpl class. value: {}",
				value);
		boolean containsValue = false;
		String dms = DMS;
		if (StringUtils.isNotEmpty(dmsId)) {
			dms = dmsId;
		}
		String key = dms + "-CV-" + value;
		key = key.toUpperCase();
		logger.debug("Lookup key: " + key);
		FeatureConfigurationVO featureConfig = mapOfFeatureConfigurations.get(key);
		if (null != featureConfig && COMPARISON_OPERATION_EQUALS.equals(comparisonOperation)) {
			if (null != featureConfig.getFeatureValue()) {
				containsValue = true;
			}
		} else if (null != featureConfig && COMPARISON_OPERATION_STARTS_WITH.equals(comparisonOperation)) {
			if (featureConfig.getFeatureValue().startsWith(value)) {
				containsValue = true;
			}
		}
		return containsValue;
	}

	/**
	 * @param featureName
	 * @param dmsId
	 * @return
	 */
	public boolean isFeatureConfigurationAvailable(final String featureName, final String dmsId) {
		logger.debug(
				"Entered isFeatureConfigurationAvailable() method of ProductConfigurationLookupServiceImpl class. featureName: {}, dmsId: {}",
				featureName, dmsId);
		boolean featureAvailable = false;
		String dms = DMS;
		if (StringUtils.isNotEmpty(dmsId)) {
			dms = dmsId;
		}
		String key = dms + "-CV-" + featureName;
		key = key.toUpperCase();
		logger.debug("Lookup key: {}", key);
		FeatureConfigurationVO featureConfig = mapOfFeatureConfigurations.get(key);
		if (null != featureConfig) {
			featureAvailable = true;
		} else {
			logger.debug("Could not find FeatureConfigurationVO with key: {}", key);
		}
		return featureAvailable;
	}

	@Override
	public boolean isRFLFeatureEnabled() {
		logger.debug("Entered isRFLFeatureEnabled() method of ProductConfigurationLookupServiceImpl class");
		boolean rfFeatureEnabled = mapOfFeatureConfigurations.keySet().stream().anyMatch(key -> key.contains("RFLV"));
		logger.debug("Exit isRFLFeatureEnabled() method of ProductConfigurationLookupServiceImpl class: {}",
				rfFeatureEnabled);
		return rfFeatureEnabled;
	}

	/**
	 * 
	 * @param featureName
	 * @param dmsId
	 * @return
	 */
	@Override
	public String getFeatureValue(final String featureName, final String dmsId) {
		logger.debug("Entered getFeatureValue() method of ProductConfigurationLookupServiceImpl class. featureName: {}",
				featureName);
		String dms = DMS;
		if (StringUtils.isNotEmpty(dmsId)) {
			dms = dmsId;
		}
		String key = dms + "-CV-" + featureName;
		key = key.toUpperCase();
		logger.debug("Lookup key: {}", key);
		String featureValue = "";
		FeatureConfigurationVO featureConfig = mapOfFeatureConfigurations.get(key);
		if (null != featureConfig) {
			logger.debug("Found FeatureConfigurationVO with key: {}, Feature Value: {}", key,
					featureConfig.getFeatureValue());
			featureValue = featureConfig.getFeatureValue();
		} else {
			logger.debug("Could not find FeatureConfigurationVO with key: {}", key);
		}
		return featureValue;
	}
	
	@Override
	public List<FeatureConfigurationVO> getWebServiceFeatures()
	{
		return listOfWebServiceFeatures;
		
	}

}
