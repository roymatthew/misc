package com.ode.cv.service;

import com.ode.cv.persistence.ILteResponseXmlRepoService;
import com.ode.cv.util.CVResponseXMLParser;
import com.ode.cv.util.Constants;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.LteResponseXmlVO;
import com.ode.persistence.service.DmsDocTypeRepoService;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DmsDocTypeVO;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author rmathew
 *
 */
@Service
public class RflProcessingServiceImpl implements IRflProcessingService {

	private static final Logger logger = LogManager.getLogger(RflProcessingServiceImpl.class);

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private ILteResponseXmlRepoService lteResponseXmlRepoService;

	@Autowired
	private PCCXmlParser pccXmlParser;

	@Autowired
	private CVResponseXMLParser cvResponseXmlParser;

	@Autowired
	private DmsDocTypeRepoService dmsDocTypeRepoService;

	@Override
	public void processRfl(final CVTransmitVO cvTransmitVO, final AccrVO accrVO) {

		logger.debug("Enter processRfl() method of RflProcessingServiceImpl class. isStaticRFLEnabled? {}",
				cvTransmitVO.isStaticRFLEnabled());

		String lteCbodXml = null;

		if (cvTransmitVO.isStaticRFLEnabled()) {
			logger.debug("Processing RFL from LTE ACCR");
			try {

				// extract LTE ConfirmationBOD XML from credit journal
				lteCbodXml = cvJournalService.getCreditJournalXmlByLenderIdBodIdAndTrasType(accrVO,
						Constants.TRANS_TYPE_LTE_CONFIRM_BOD);
				// extract xmlId
				Integer xmlId = pccXmlParser.getResponseXmlId(lteCbodXml);
				// use xmlId to fetch ACCR stored in ResponseXML table in sqlserver DB.
				LteResponseXmlVO lteResponseXmlVO = lteResponseXmlRepoService.getByXmlId(xmlId);
				logger.debug("***** LTE ACCR xml: {} *************", lteResponseXmlVO.getAccrXml());
				List<String> listOfDocNames = cvResponseXmlParser
						.extractRequiredFormsList(lteResponseXmlVO.getAccrXml());
				listOfDocNames.forEach(docName -> {
					Optional<DcFormVO> dcFormVO = createDcFormFromDocName(docName, cvTransmitVO);
					if (dcFormVO.isPresent()) {
						cvTransmitVO.getListOfDcForms().add(dcFormVO.get());
					}
					logger.debug("cvTransmitVO list of dcforms: {}", cvTransmitVO.getListOfDcForms());
				});
			} catch (final Exception e) {
				logger.debug("Exception caught when fetching lteCbodXml", e);
			}
		}
	}

	/**
	 * @param docName
	 * @param cvTransmitVO
	 * @return
	 */
	private Optional<DcFormVO> createDcFormFromDocName(final String docName, final CVTransmitVO cvTransmitVO) {
		logger.debug("Enter createFormFromDocName() method of RflProcessingServiceImpl class. DocName: {}", docName);

		DcFormVO dcFormVO = null;
		String lenderId = cvTransmitVO.getPartnerInfoVO().getLenderId();
		String formId = null;

		if (StringUtils.isNotBlank(cvTransmitVO.getPartnerInfoVO().getGlobalLenderId())) {
			lenderId = cvTransmitVO.getPartnerInfoVO().getGlobalLenderId();
		}
		DmsDocTypeVO dmsDocTypeVO = dmsDocTypeRepoService.getDmsDocType(docName, cvTransmitVO.getDealerInfoVO().getDspId());
		if (null != dmsDocTypeVO) {
			dcFormVO = new DcFormVO();
			formId = dmsDocTypeVO.getDmsFormId();
			dcFormVO.setFormName(dmsDocTypeVO.getDocName());
			dcFormVO.setFormId(formId);
			dcFormVO.setLenderReceivedDate(new Timestamp(new Date().getTime()));
			return Optional.of(dcFormVO);
		} else {
			logger.debug("Could not find DmsDocTypeVO/LenDocTypeVO for docName: {}, lenderId: {}, dspId: {}", docName,
					lenderId, cvTransmitVO.getDealerInfoVO().getDspId());
		}
		return Optional.empty();
	}
}
