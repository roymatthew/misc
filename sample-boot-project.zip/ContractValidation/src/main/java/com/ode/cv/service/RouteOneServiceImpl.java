/**
 * 
 */
package com.ode.cv.service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import com.ode.cv.factory.JournalFactory;
import com.ode.cv.factory.VOFactory;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.ContractPackageVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.DePartnerDestinationRepoService;
import com.ode.persistence.service.DealerPpNvpRepoService;
import com.ode.persistence.service.FormsRepoService;
import com.ode.persistence.vo.DePartnerDestinationVO;
import com.ode.persistence.vo.DealerPpNvpVO;
import com.ode.persistence.vo.FormsVO;

/**
 * @author snimma
 *
 */
@Service
public class RouteOneServiceImpl implements IRouteOneService {

	private static final Logger logger = LogManager.getLogger(RouteOneServiceImpl.class);

	@Autowired
	private FormsRepoService formsRepoService;

	@Autowired
	private DePartnerDestinationRepoService dePartnerDestinationRepoService;

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;

	@Autowired
	private CVTransmitClient cvTransmitClient;

	@Autowired
	private ICVJournalService cvJournalService;

	@Autowired
	private ICVDocumentManipulationService cvDocumentManipulationService;

	@Autowired
	private DealerPpNvpRepoService dealerPpNvpRepoService;

	@Autowired
	private ApplpEventHandler appCVEventHandler;

	@Value("${routeone.hmacid}")
	private String routeOneHmacId;

	@Value("${routeone.dealerid}")
	private String routeOneDealerId;

	/**
	 * {@inheritDoc}
	 * 
	 * @return
	 */
	@Override
	public ECConfinVO prepareAndPostCVToRouteOne(final CreditContractVO creditContractVO, final String xml,
			final boolean isCdkCloudEnabled) throws Exception {
		logger.debug("Enter prepareAndPostCVToRouteOne() method of RouteOneServiceImpl class. Deal: {}",
				creditContractVO.getDeal());
		ECConfinVO ecConfinVO = new ECConfinVO();
		String routeOneDealerId = findRouteOneDealerId(Constants.ROUTE_ONE_DEALERID_PARM_NAME,
				creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDealerId(),
				Constants.PRODUCT_CV);
		if (null == routeOneDealerId || routeOneDealerId.isEmpty()) {
			logger.debug("Could not find RouteOneDealerId/LenderDealerId for Lender: {}, DealerId: {}, Product: {}",
					creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDealerId(),
					Constants.PRODUCT_CV);
		}
		if (null != creditContractVO && null != creditContractVO.getDeal()) {
			if (null != creditContractVO.getDealerInfo()) {
				ecConfinVO.setDmsId(creditContractVO.getDealerInfo().getDspId());
			}
			if (null != creditContractVO.getPartnerInfo()) {
				ecConfinVO.setLenderId(creditContractVO.getPartnerInfo().getLenderId());
			}
			creditContractVO.getDeal().setLenderDealerId(routeOneDealerId);

		}
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("***** Start posting RouteOne CV request at: {} *****", start);
		Document document = cvDocumentManipulationService.manipulateCVDocument(creditContractVO, xml);
		creditContractVO.setConversationId(CVUtil.getRouteOneConversationId(document));
		ContractPackageVO contractPackageVO = VOFactory.createContractPackageVO(creditContractVO);
		logger.debug("contractPackageVO: {}", contractPackageVO);
		Document restructuredDocument = CVUtil.restructureAndAddContractPackageToCVDocument(document,
				contractPackageVO);
		String routeOneRequestXml = CVUtil.getXmlStringFromDocument(restructuredDocument);
		routeOneRequestXml = routeOneRequestXml.trim().replaceFirst("^([\\t|\\n|\\r]+)<", "<");
		logger.debug("RouteOne CV Request: {}", routeOneRequestXml);
		DePartnerDestinationVO dePartnerDestinationVO = null;
		dePartnerDestinationVO = dePartnerDestinationRepoService.getByPartnerAndProduct(Constants.ROUTEONE_PARTNER,
				Constants.PRODUCT_CV);
		String responseMessage = null;
		ecConfinVO.setRequestXML(routeOneRequestXml);
		AppMessage sappMsg = null;
		if (StringUtils.isNotBlank(routeOneRequestXml)) {
			if (isCdkCloudEnabled) {
				logger.debug("Deal is for CDKCloud, skipping R1 CV post and setting statuses to Success");
				sappMsg = appCVEventHandler.handleEvents("Success");
				JournalObjectVO ecout2JournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_OUT2,
						sappMsg, routeOneRequestXml);
				cvJournalService.addJournal(creditContractVO, ecout2JournalObject);
				ecConfinVO.setStatusMessage(Constants.OPERATION_SUCCESS_MESSSAGE);
			} else if (null != routeOneDealerId && !routeOneDealerId.isEmpty()) {
				responseMessage = cvTransmitClient.postCVToRouteOneWithDynamicHeaders(creditContractVO,
						routeOneRequestXml, dePartnerDestinationVO,
						creditContractVO.getContractValidation().getAuthorizationId(), ecConfinVO);
				logger.debug("Response from RouteOne: {}", responseMessage);
				if (null != responseMessage && responseMessage.contains(Constants.OPERATION_SUCCESS_MESSSAGE)) {
					sappMsg = appCVEventHandler.handleEvents("Success");
					ecConfinVO.setStatusMessage(responseMessage);
				} else {
					sappMsg = appCVEventHandler.handleEvents(Constants.Event_Runtime_Exception);
					ecConfinVO.setStatusMessage(Constants.OPERATION_FAILED_MESSSAGE);
				}
				JournalObjectVO ecout2JournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_OUT2,
						sappMsg, routeOneRequestXml);
				cvJournalService.addJournal(creditContractVO, ecout2JournalObject);
				JournalObjectVO ecconfin2JournalObject = JournalFactory
						.createJournalObject(Constants.TRANS_TYPE_EC_CONF_IN2, sappMsg, responseMessage);
				cvJournalService.addJournal(creditContractVO, ecconfin2JournalObject);
			} else {
				sappMsg = appCVEventHandler.handleEvents(Constants.Event_Partner_Config_Exception);
				ecConfinVO.setStatusCode(3300);
				ecConfinVO.setStatusMessage(Constants.OPERATION_FAILED_MESSSAGE);
				JournalObjectVO ecout2JournalObject = JournalFactory.createJournalObject(Constants.TRANS_TYPE_EC_OUT2,
						sappMsg, routeOneRequestXml);
				cvJournalService.addJournal(creditContractVO, ecout2JournalObject);
			}
		}

		final LocalDateTime end = LocalDateTime.now();
		logger.debug("***** End posting RouteOne CV request at: {} *****", end);
		logger.debug("Posting CV to RouteOne took {} milliseconds", ChronoUnit.MILLIS.between(start, end));
		return ecConfinVO;
	}

	@Override
	public String findRouteOneDealerId(final String parmName, final String partnerId, final String dealerId,
			final String productId) {
		logger.debug(
				"Entered findRouteOneDealerId() method of RouteOneServiceImpl class. DealerId: {}, ProductId: {}, partnerId: {}",
				dealerId, productId, partnerId);
		String lenderDealerId = null;
		DealerPpNvpVO dealerPpNvpVO = new DealerPpNvpVO();
		try {
			dealerPpNvpVO.setParmName(parmName);
			dealerPpNvpVO.setPartnerId(partnerId);
			dealerPpNvpVO.setDealerId(dealerId);
			dealerPpNvpVO.setProductId(productId);
			lenderDealerId = dealerPpNvpRepoService.getParmValueByParmNameLenderDealerAndProduct(dealerPpNvpVO);
		} catch (final Exception e) {
			logger.debug("Error getting RouteOneDealerId/LenderDealerId from DB. ", e);
		}
		return lenderDealerId;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @return
	 */
	@Override
	public ECConfinVO postECOUT3ToRouteOne(final CreditContractVO creditContractVO, final String ecout3)
			throws Exception {
		logger.debug("Entered postECOUT3ToRouteOne() method of RouteOneServiceImpl class");
		ECConfinVO ecConfinVO = new ECConfinVO();
		String routeOneDealerId = findRouteOneDealerId(Constants.ROUTE_ONE_DEALERID_PARM_NAME,
				creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDealerId(),
				Constants.PRODUCT_CV);
		if (null == routeOneDealerId || routeOneDealerId.isEmpty()) {
			logger.debug("Could not find RouteOneDealerId/LenderDealerId for Lender: {}, DealerId: {}, Product: {}",
					creditContractVO.getPartnerInfo().getLenderId(), creditContractVO.getDealerInfo().getDealerId(),
					Constants.PRODUCT_CV);
		}
		if (null != creditContractVO && null != creditContractVO.getDeal()) {
			if (null != creditContractVO.getDealerInfo()) {
				ecConfinVO.setDmsId(creditContractVO.getDealerInfo().getDspId());
			}
			if (null != creditContractVO.getPartnerInfo()) {
				ecConfinVO.setLenderId(creditContractVO.getPartnerInfo().getLenderId());
			}
			creditContractVO.getDeal().setLenderDealerId(routeOneDealerId);

		}
		final LocalDateTime start = LocalDateTime.now();
		logger.debug("***** Start posting ECOUT3 to RouteOneat: {} *****", start);
		logger.debug("RouteOne CV Request: {}", ecout3);
		DePartnerDestinationVO dePartnerDestinationVO = null;
		dePartnerDestinationVO = dePartnerDestinationRepoService.getByPartnerAndProduct(Constants.ROUTEONE_PARTNER,
				Constants.PRODUCT_CV);
		String responseMessage = null;
		if (StringUtils.isNotBlank(ecout3)) {
			responseMessage = cvTransmitClient.postCVToRouteOneWithDynamicHeaders(creditContractVO, ecout3,
					dePartnerDestinationVO, creditContractVO.getContractValidation().getAuthorizationId(), ecConfinVO);
			logger.debug("Response from RouteOne: {}", responseMessage);
			ecConfinVO.setEcConfinMessage(responseMessage);
		}
		ecConfinVO.setRequestXML(ecout3);
		if (null != responseMessage && responseMessage.contains(Constants.OPERATION_SUCCESS_MESSSAGE)) {
			ecConfinVO.setStatusMessage(responseMessage);
		} else {
			ecConfinVO.setStatusMessage(Constants.OPERATION_FAILED_MESSSAGE);
		}

		final LocalDateTime end = LocalDateTime.now();
		logger.debug("***** End posting ECOUT3 to RouteOne at: {} *****", end);
		logger.debug("Posting ECOUT3 to RouteOne took {} milliseconds", ChronoUnit.MILLIS.between(start, end));
		return ecConfinVO;
	}

}
