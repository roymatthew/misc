/*
 * Created on Mar 6, 2009
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.adp.dealerservices.loanprocessing.Connection;
import com.adp.dealerservices.loanprocessing.Header;
import com.ode.cv.exception.AppException;
import com.ode.cv.exception.AppHttpException;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.DeDealRepoService;

/**
 * @author biswass
 *
 *         This class is copied over from LP application and refactored.
 */
@Component
public class AppHttpUtility {

	private static final Logger logger = LogManager.getLogger(AppHttpUtility.class);

	@Autowired
	private DeDealRepoService deDealRepoService;

	private String creditAppUpdateUsername;
	private String creditAppUpdatePassword;

	public void processHttpStatusCodeAndMessage(final CVTransmitVO cvTransmitVO,
			final ResponseMessage responseMessage) {
		logger.debug("Enter processHttpStatusCodeAndMessage() method of AppHttpUtility class");
		logger.debug("Response XML from postMessage() " + responseMessage.getResponseXml());
		AppMessage appMsg = new AppMessage("", "", "", "", true, true, true);
		if (responseMessage.getStatusCode() == HttpStatus.SC_OK) {
			appMsg.setMessage(Constants.OPERATION_SUCCESS_MESSSAGE);
			appMsg.setMessageID(Constants.APP_SUCCESS_MSG_ID);
		} else if (responseMessage.getStatusCode() >= 300) {
			appMsg.setMessage(Constants.OPERATION_FAILED_MESSSAGE);
			appMsg.setMessageID(new Integer(responseMessage.getStatusCode()).toString());
		}
		cvTransmitVO.setAppMessage(appMsg);
		if (null == cvTransmitVO.getEcConfinVO())
		{
			cvTransmitVO.setEcConfinVO(new ECConfinVO());
		}
		cvTransmitVO.getEcConfinVO().setStatusCode(responseMessage.getStatusCode());
		cvTransmitVO.getEcConfinVO().setStatusMessage(appMsg.getMessage());

	}

	/**
	 * Send message to destination for Message Processing and getting
	 * ResponseMessage back.
	 */
	public ResponseMessage sendMsgToDestinationAndGetResponseMsg(final Connection connection, final String msgToSend)
			throws AppException {

		logger.debug("Enter sendMsgToDestinationAndGetResponseMsg() of AppHttpUtility class");
		RequestMessage requestMessage = null;
		ResponseMessage responseMessage = null;
		try {
			requestMessage = new RequestMessage();
			requestMessage.setRequestXml(msgToSend);
			// Setting Destination URL in RequestMessage
			requestMessage.setDestinationURL(getDestinationURL(connection));
			// Creating RequestHeader and setting it to RequestMessage
			requestMessage.setRequestHeader(getRequestHeader(connection));
			// calling sendMesgToDestination to send message
			responseMessage = sendMsgToDestination(requestMessage);
		} catch (AppException ae) {
			throw ae;
		}
		return responseMessage;
	}

	/**
	 * creating RequestEntity by taking input message
	 * 
	 * @param msgToSend
	 * @return
	 */
	private InputStreamRequestEntity getRequestEntity(final String msgToSend) {
		InputStreamRequestEntity requestentity = null;
		if (msgToSend != null && msgToSend.trim().length() != 0) {
			ByteArrayInputStream bais = new ByteArrayInputStream(msgToSend.getBytes());
			requestentity = new InputStreamRequestEntity(bais, InputStreamRequestEntity.CONTENT_LENGTH_AUTO, null);
		}
		return requestentity;
	}

	/**
	 * Return Destination URL from connection
	 * 
	 * @param requestMessage
	 * @return
	 */
	private String getDestinationURL(final Connection connection) {
		return connection.getUrl();
	}

	/**
	 * Send message to destination
	 * 
	 * @param requestMessage
	 * @param className
	 * @param refValue
	 * @return
	 * @throws AppException
	 */
	private ResponseMessage sendMsgToDestination(final RequestMessage requestMessage) throws AppException {
		logger.debug("Enter sendMsgToDestination() of AppHttpUtility class");
		String destUrl = null;
		PostMethod mPost = null;
		HttpClient httpClient;
		byte[] responseBody = null;
		int statusCode = 0;
		ResponseMessage responseMessage = null;
		try {

			httpClient = new HttpClient();
			destUrl = requestMessage.getDestinationURL();
			logger.info("Destination URL: {}", destUrl);
			responseMessage = new ResponseMessage();
			mPost = new PostMethod(destUrl);
			// Setting RequestEntity if RequestXml is not null
			if (requestMessage.getRequestXml() != null && requestMessage.getRequestXml().trim().length() != 0) {
				mPost.setRequestEntity(getRequestEntity(requestMessage.getRequestXml()));
			}
			// Setting RequestHeader
			if (requestMessage.getRequestHeader() != null) {
				int length = requestMessage.getRequestHeader().length;
				for (int i = 0; i < length; i++) {
					mPost.setRequestHeader(requestMessage.getRequestHeader()[i]);
				}
			}
			// Executing send request
			statusCode = httpClient.executeMethod(mPost);
			logger.debug("statusCode:{}", statusCode);
			// Setting Status code in ResponseMessage
			responseMessage.setStatusCode(statusCode);

			// Read the response body.
			if (mPost.getResponseBody() != null) {
				responseBody = mPost.getResponseBody();
				responseMessage.setResponseXml(new String(responseBody));
			}

			// if (statusCode != HttpStatus.SC_OK) {

			// throw new Exception("Exception to connect
			// destination:"+statusCode+":"+mPost.getStatusLine());

			// }

			// Read Cookies
			if (httpClient.getState() != null && httpClient.getState().getCookies() != null) {
				responseMessage.setCookies(httpClient.getState().getCookies());
			}
		} catch (final Exception e) {
			logger.debug("Exception caught in sendMsgToDestination", e);
			String requestText = "";
			if (requestMessage != null) {
				requestText = requestMessage.getRequestXml();
			}
			String traceMsg = " HTTP IO Exception Destination =" + destUrl + " Message= " + requestText;
			String responseText = "";
			if (responseBody != null) {
				responseText = new String(responseBody);
			}
			AppHttpException ahe = new AppHttpException(e.getMessage(), e, "sendMsgToDestination",
					this.getClass().getName(), traceMsg, responseText);
			ahe.setStatusCode(statusCode);
			throw ahe;
		} finally {
			try {
				if (mPost != null)
					mPost.releaseConnection();
			} catch (Exception exp) {
				logger.error("", exp);
			}
		}
		return responseMessage;
	}

	/**
	 * @param destUrl
	 * @param is
	 * @return
	 * @throws Exception
	 */
	public String postMessage(final String destUrl, final InputStream is) throws Exception {

		logger.debug("Enter postMessage() of AppHttpUtility class");

		PostMethod mPost = null;
		HttpClient httpClient;
		byte[] responseBody = null;
		int statusCode = 0;
		String response = "";
		try {
			httpClient = new HttpClient();
			mPost = new PostMethod(destUrl);

			// Setting RequestEntity if InputStream is not null
			if (is != null) {
				InputStreamRequestEntity requestentity = new InputStreamRequestEntity(is,
						InputStreamRequestEntity.CONTENT_LENGTH_AUTO, null);
				mPost.setRequestEntity(requestentity);
			}

			// Executing send request
			statusCode = httpClient.executeMethod(mPost);

			// Read the response body.
			if (mPost.getResponseBody() != null) {
				responseBody = mPost.getResponseBody();
				response = new String(responseBody);
			}

			if (statusCode != HttpStatus.SC_OK) {
				throw new Exception("Exception to connect destination:" + statusCode + ":" + mPost.getStatusLine());
			}

			return response;
		} catch (Exception e) {
			throw new Exception("Exception while sending message to destination: " + e.getMessage());
		} finally {
			try {
				if (mPost != null) {

					mPost.releaseConnection();
				}
			} catch (Exception exp) {
				logger.error("", exp);
			}
		}
	}

	/**
	 * Creating httpclient Header for Http Base64 Auth by taking Connection
	 * 
	 * @param connection
	 * @return
	 */
	private org.apache.commons.httpclient.Header[] getRequestHeader(final Connection connection) {
		logger.debug("Entered getRequestHeader method of AppHttpUtility class");
		List<Header> list = connection.getHeader();
		ListIterator<Header> li = list.listIterator();
		org.apache.commons.httpclient.Header[] requestHeaderArray = null;
		int length = list.size();
		if (length > 0) {
			requestHeaderArray = new org.apache.commons.httpclient.Header[length];
		}
		for (int i = 0; i < length; i++) {
			Header header = (Header) li.next();
			if (header.getType().equals("LDAP")) {
				String base64LdapAuth = new String(Base64.encodeBase64(header.getValue().getBytes()));
				requestHeaderArray[i] = new org.apache.commons.httpclient.Header("Authorization",
						"Basic " + base64LdapAuth);
			} else {
				requestHeaderArray[i] = new org.apache.commons.httpclient.Header(header.getName(), header.getValue());
			}
			logger.debug("Header: {}, -> Value: {}", i, requestHeaderArray[i]);
		}
		return requestHeaderArray;
	}

	/**
	 * @param statusCode
	 * @return
	 */
	private boolean isHttpSuccess(int statusCode) {
		if (Arrays.asList(Constants.HTTP_SUCCESS_CODES).contains(new Integer(statusCode).toString())) {
			return true;
		}
		return false;
	}

	public String getCreditAppUpdateUsername() {
		return creditAppUpdateUsername;
	}

	public void setCreditAppUpdateUsername(String creditAppUpdateUsername) {
		this.creditAppUpdateUsername = creditAppUpdateUsername;
	}

	public String getCreditAppUpdatePassword() {
		return creditAppUpdatePassword;
	}

	public void setCreditAppUpdatePassword(String creditAppUpdatePassword) {
		this.creditAppUpdatePassword = creditAppUpdatePassword;
	}
}
