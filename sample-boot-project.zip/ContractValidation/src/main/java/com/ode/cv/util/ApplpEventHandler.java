/*
 * Created on Apr 20, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util;

/**
 * @author krishnab
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;

import com.ode.cv.exception.AppException;
import com.ode.cv.rest.entity.RouteOneErrorResponse;
import com.ode.cv.vo.ECConfinVO;
import com.ode.dlr.util.AppMessage;
import com.ode.dlr.util.AppSQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author rmathew
 *
 */
@Component
public class ApplpEventHandler implements EventHandler {

	private static final Logger logger = LogManager.getLogger(ApplpEventHandler.class);

	private ApplpMsgHolder msgHolder = new ApplpMsgHolder();
	//private ApplpMsgHolder msgHolder;

	/**
	 * @param refvalue
	 * @param e
	 * @param tracemsg
	 * @return
	 */
	public AppMessage handleException(String refvalue, Throwable e, String tracemsg) {
		AppMessage msg = msgHolder.getAppMessage(e);
		logger.error("", e);
		return msg;
	}

	/**
	 * @param e
	 * @return
	 */
	public AppMessage handleException(final Throwable e) {

		String detailMsg = null;
		String excepTraceMsg = "N/A";
		Throwable causeException = null;
		String tracemsg = null;

		AppMessage msg = msgHolder.getAppMessage(e);

		if (e instanceof AppException) {

			excepTraceMsg = ((AppException) e).getTraceMsg();
			causeException = e.getCause();
			if (e instanceof AppSQLException) {
				detailMsg = detailMsg + "\r\n<SQLErrorCode>" + ((AppSQLException) e).getSqlCode() + "</SQLErrorCode>"
						+ "\r\n<SQLState>" + ((AppSQLException) e).getSqlState() + "</SQLState>";
			}
		}

		if (msg.isTraceind()) {
			if (e instanceof AppSQLException) {
				SQLException sq = (SQLException) e.getCause();
				logger.trace(detailMsg);
				logger.trace(tracemsg);
				SQLException sqe1 = null;
				while ((sqe1 = sq.getNextException()) != null) {
					logger.trace(detailMsg);
					logger.trace(tracemsg);
					sq = sqe1;
				}
			} else {
				logger.trace(detailMsg);
				logger.trace(tracemsg);
				if (causeException != null) {
					// ApplpLogger.totrace(detailMsg + DOT + "\n Application Trace" +tracemsg + "\n
					// Root Exception Trace"+ DOT+ excepTraceMsg,causeException);
					logger.trace(detailMsg);
					logger.trace(tracemsg);
					logger.trace("", causeException);
				}
			}
		}
		if (msg.isEventvieweron()) {
			logger.debug(detailMsg);
			logger.debug("", e);
		}
		if (msg.getLoggingtype().equalsIgnoreCase("error")) {
			logger.error(detailMsg);
			logger.error(tracemsg);
		} else {
			if (msg.getLoggingtype().equalsIgnoreCase("info")) {
				logger.info(detailMsg);
				logger.info(tracemsg);
			}
		} // else-if
		return msg;

	}

	/*
	 * This is a dummy function need to be removed once the EventHandler is adjusted
	 */
	public AppMessage handleEvents(String refvalue, String context, String eventname, String tracemsg) {
		AppMessage msg = msgHolder.getAppMessage(eventname);
		return msg;
	}

	/**
	 * @param eventname
	 * @return
	 */
	public AppMessage handleEvents(String eventname) {
		return msgHolder.getAppMessage(eventname);
	}
	
	/**
	 * @param ecConfinVO
	 * @return
	 */
	public AppMessage handleR1NegConfBod(ECConfinVO ecConfinVO, String format) { 
		logger.debug("Entered handleR1NegConfBod, format: {}", format);
		
		String errorMsg = "";
		String devMsg = "";
		String r1ErrorCode = "";

		if(format.equalsIgnoreCase(Constants.MESSAGE_FORMAT_XML)) {
			errorMsg = CVUtil.getStringValueFromXmlElement(ecConfinVO.getEcConfinMessage(), Constants.RESTERROR_ERRORMESSAGE);
			devMsg = CVUtil.getStringValueFromXmlElement(ecConfinVO.getEcConfinMessage(), Constants.RESTERROR_DEVELOPERMESSAGE);
			r1ErrorCode = CVUtil.getStringValueFromXmlElement(ecConfinVO.getEcConfinMessage(), Constants.RESTERROR_ERRORCODE);
		} else {
			RouteOneErrorResponse routeOneErrorResponse = CVUtil.getObjectForRouteOneErrorResponse(ecConfinVO.getEcConfinMessage());
			errorMsg = routeOneErrorResponse.getErrorMessage();
			devMsg =  routeOneErrorResponse.getDeveloperMessage();
			r1ErrorCode = routeOneErrorResponse.getRouteOneErrorCode().toString();
		}
		
		String code = "E" + r1ErrorCode;
		String message = errorMsg + " - " + devMsg;
		
		return new AppMessage(code, message, message, "trace", true, true, true);
	}

	/**
	 * Returns the IP of Local Host
	 * 
	 * @return String
	 */
	public String getSystemIp() {
		String localHostIP = "";
		try {
			localHostIP = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException uhe) {
			// NOP
		}
		return localHostIP;
	}

	/**
	 * @param msgHolder The msgHolder to set.
	 */
	public void setMsgHolder(final ApplpMsgHolder msgHolder) {
		this.msgHolder = msgHolder;
	}
}