/*
 * Created on Apr 19, 2006
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.ode.dlr.util.AppMessage;

/**
 * @author rmathew
 * This class is copied frm LPWebService application.
 * @author krishnab
 */
public class ApplpMsgHolder extends AppMsgHolder {

	private static final Logger logger = LogManager.getLogger(ApplpMsgHolder.class);

	public ApplpMsgHolder(String location) {
		this.initializeme(location);
	}

	private void initializeme(String location) {
		try {
			FileInputStream fs = new FileInputStream(location);
			super.initialize(fs);
		} catch (Exception exp) {
			logger.fatal("", exp);
		}

	}

	public AppMessage getAppMessage(Throwable msgID) {

		return super.getAppMessage(msgID);
	}

	public AppMessage getAppMessage(String msgID) {

		return super.getAppMessage(msgID);
	}

	public ApplpMsgHolder() {
		init();
	}

	/**
	 * This method is called from constructor to load all canned messages from XML.
	 */
	private void init() {
		logger.debug("Entered init() method to load all canned LP messages from XML");
		FileSystemResource fileSystemResource = new FileSystemResource("/data/ode/cv/config/lpMessages.xml");
		FileInputStream fIS = null;
		try {
			fIS = new FileInputStream(fileSystemResource.getFile());
			super.initialize(fIS);
		} catch (final Exception e) {
			logger.error(e);
		} finally {
			try {
				fIS.close();
			} catch (final IOException e) {
				logger.error(e);
			}
		}

	}

}
