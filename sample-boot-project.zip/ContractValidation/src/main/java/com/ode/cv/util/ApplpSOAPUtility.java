package com.ode.cv.util;

import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;


public class ApplpSOAPUtility {
	
	private DocumentBuilder docBuilder;
	
	public String getSOAPDetail(Document doc, String strTag)throws Exception{
		String soapDetail=null;
		String res = XPathAPI.eval(doc,"/Envelope/Body/Fault/" + strTag).toString();
		if(res !=null)soapDetail = res;
		
		return soapDetail;
	}
	
	public Document getSOAPDocument(String msg)throws Exception{
		
		docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document document = docBuilder.parse(new InputSource(new StringReader(msg)));
		document.getDocumentElement().normalize();
		
		
		return document;
	}

}
