/**
 * 
 */
package com.ode.cv.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.service.FormsRepoService;

/**
 * @author rmathew
 *
 */
@Component
public class CVDataTranslationUtil {

	private static final Logger logger = LogManager.getLogger(CVDataTranslationUtil.class);

	@Autowired
	private FormsRepoService formRepoService;

	/**
	 * @param creditContractVO
	 * @return
	 */
	public boolean isContractFormTranslationRequired(final CreditContractVO creditContractVO) {
		if (null != creditContractVO.getContractFormNumber() && null != creditContractVO.getContractFormRevisionDate()
				&& null != creditContractVO.getPartnerInfo().getLenderId()) {
			return true;
		}
		return false;
	}

	/**
	 * @param creditContractVO
	 * @return
	 * @throws Exception
	 */
	public String selectStateGroup(final CreditContractVO creditContractVO) throws Exception {
		logger.debug("Enter selectStateGroup() method");
		String stateGroup = "NULL";
		try {
			if (!((creditContractVO.getContractFormNumber() == null)
					|| (creditContractVO.getContractFormRevisionDate() == null)
					|| (creditContractVO.getContractExecutionState()) == null)) {

				formRepoService.getStateGroup(creditContractVO.getContractFormNumber(),
						creditContractVO.getContractFormRevisionDate(), creditContractVO.getContractExecutionState());

				if (stateGroup == "NULL") {
					stateGroup = creditContractVO.getContractExecutionState();
				}
			}
		} catch (Exception e) {
			logger.error("", e.getMessage());
		}
		return stateGroup;

	}

}
