package com.ode.cv.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.transform.TransformerException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.apache.xpath.objects.XNodeSet;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author rmathew
 *
 */
@Component
public class CVRequestXMLParser extends AppXMLParser {

	private static final Logger logger = LogManager.getLogger(CVRequestXMLParser.class);

	private static DateFormat xmlTimestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	private static DateTimeFormatter nvpXmlTimestampFormat = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ssZ");
	private static SimpleDateFormat xmlDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	@Value("classpath:removeNameSpace.xslt")
	private Resource removeNameSpaceStyleSheet;

	public Document getDocument(final String inputXML) throws Exception {
		return (super.getDocument(inputXML));

	}

	/**
	 * @param transType
	 * @param document
	 * @param lenderId
	 * @return
	 */
	public DeContractValidationBo populateContractValForSTAR(final String transType, final Document document,
			final String lenderId) {

		logger.debug("Enter populateContractValForSTAR method of CVRequestXMLParser class. TransType: {}, LenderId: {}", transType, lenderId);
		DeContractValidationBo contractVal = new DeContractValidationBo();
		if (document != null) {
			try {
				logger.debug("transtype: " + transType);
				if (transType.equals(Constants.TRANS_TYPE_EC_IN)
						|| transType.equals(Constants.TRANS_TYPE_EC_IN_WITH_ATTACHMENT)) {
					contractVal.setDealerId(XPathAPI
							.eval(document, "//ProcessCreditContract/ApplicationArea/Sender/DealerNumber").toString());
					contractVal.setAuthorizationId(
							XPathAPI.eval(document, "//ProcessCreditContract/ApplicationArea/Sender/AuthorizationId")
									.toString());
					contractVal.setLenderId(XPathAPI
							.eval(document, "//ProcessCreditContract/DataArea/CreditContract/FinanceCompany/PartyId")
							.toString());
					contractVal.setDmsDealNum(
							XPathAPI.eval(document, "//ProcessCreditContract/DataArea/CreditContract/Header/DealId")
									.toString());
					contractVal.setVin(
							XPathAPI.eval(document, "//ProcessCreditContract/DataArea/CreditContract/CreditVehicle/VIN")
									.toString());

					boolean individualApplicantExists = new Boolean(
							XPathAPI.eval(document, "boolean(//IndividualApplicant)").toString()); // check to see if
																									// IndividualApplicant
																									// exists in the
																									// deal
					if (individualApplicantExists) {
						contractVal.setBuyerFirstName(
								XPathAPI.eval(document, "//IndividualApplicant/PersonName/GivenName").toString());
						contractVal.setBuyerLastName(
								XPathAPI.eval(document, "//IndividualApplicant/PersonName/FamilyName").toString());
					} else {
						contractVal
								.setBuyerLastName(XPathAPI.eval(document, "//OrganizationalApplicant/Name").toString());
					}

					boolean autoFundingIndicatorExists = new Boolean(
							XPathAPI.eval(document, "boolean(//AutoFundingInd)").toString()); // check to see if
																								// AutoFundingInd exists
																								// in the deal
					if (autoFundingIndicatorExists) {
						contractVal.setAutoFundingIndicator(XPathAPI
								.eval(document, "//ProcessCreditContract/DataArea/CreditContract/Header/AutoFundingInd")
								.toString());
					} else {
						contractVal.setAutoFundingIndicator("0");
					}

					contractVal.setApplicationNumber(XPathAPI.eval(document, "//Header/ApplicationNumber").toString());
					contractVal.setApplicationType(XPathAPI.eval(document, "//Header/ApplicationType").toString());
					contractVal.setSpotFlag(getSpotFlagFromDocument(document));
					String contractDate = XPathAPI.eval(document, "//Financing/ContractDate").toString();
					if (null != contractDate) {
						Date date = xmlDateFormat.parse(contractDate);
						java.sql.Date sql = new java.sql.Date(date.getTime());
						contractVal.setContractDate(sql);
					} else {
						logger.error("//Financing/ContractDate from document is null!");
					}
					String timestampString = XPathAPI
							.eval(document, "//ProcessCreditContract/ApplicationArea/CreationDateTime").toString();
					contractVal.setSubmittedTs(xmlTimestampFormat.parse(timestampString));

				} else if (transType.equals(Constants.TRANS_TYPE_EC_ACK_IN)) {
					contractVal.setStatus(
							XPathAPI.eval(document, "//CreditContractResponse/Header/ValidationResults").toString());
					Date now = new Date();
					contractVal.setStatusTs(now);
				} else if (transType.equals(Constants.TRANS_TYPE_EC_ACK_OUT)) {
					contractVal.setLenderSeqNum(
							XPathAPI.eval(document, "//CreditContractResponse/Header/DocumentId").toString());
				}
			} catch (final TransformerException e) {
				logger.error("error getting value from xml", e);
			} catch (ParseException e) {
				logger.error("error parsing date from xml", e);
			}
		}

		return contractVal;
	}

	/**
	 * @param transType
	 * @param document
	 * @param lenderId
	 * @return
	 */
	public DeContractValidationBo populateContractValForNVP(final String transType, Document document,
			String lenderId) {
		logger.debug("Enter populateContractValForNVP() method of CVRequestXMLParser class TransType: {}, LenderId: {}", transType, lenderId);
		DeContractValidationBo contractVal = new DeContractValidationBo();

		if (document != null) {
			try {
				logger.debug("transtype: " + transType);
				if (transType.equals(Constants.TRANS_TYPE_EC_IN)
						|| transType.equals(Constants.TRANS_TYPE_EC_IN_WITH_ATTACHMENT)) {
					contractVal.setDealerId(
							XPathAPI.eval(document, "//GenericCreditContract/clientInfo/dealerId").toString());
					contractVal.setAuthorizationId(
							XPathAPI.eval(document, "//GenericCreditContract/clientInfo/userId").toString());
					contractVal.setLenderId(
							XPathAPI.eval(document, "//GenericCreditContract/contractHeader/partnerId").toString());
					contractVal.setDmsDealNum(
							XPathAPI.eval(document, "//GenericCreditContract/clientInfo/dealNumber").toString());
					contractVal.setVin(XPathAPI
							.eval(document, "//GenericCreditContract/contractInfo/dmsData/nvp[name='VIN']/value")
							.toString());

					boolean individualApplicantExists = new Boolean(XPathAPI.eval(document,
							"boolean(//GenericCreditContract/contractInfo/adpCreditData/nvp[name='appFirstName']/value)")
							.toString()); // check to see if applicant name exists in the deal
					if (individualApplicantExists) {
						contractVal.setBuyerFirstName(XPathAPI.eval(document,
								"//GenericCreditContract/contractInfo/adpCreditData/nvp[name='appFirstName']/value")
								.toString());
						contractVal.setBuyerLastName(XPathAPI.eval(document,
								"//GenericCreditContract/contractInfo/adpCreditData/nvp[name='appLastName']/value")
								.toString());
					} else {
						contractVal.setBuyerLastName(XPathAPI
								.eval(document,
										"//GenericCreditContract/contractInfo/adpCreditData/nvp[name='busName']/value")
								.toString());
					}

					boolean autoFundingIndicatorExists = new Boolean(
							XPathAPI.eval(document, "boolean(//AutoFundingInd)").toString()); // check to see if
																								// AutoFundingInd exists
																								// in the deal
					if (autoFundingIndicatorExists) {
						contractVal.setAutoFundingIndicator(XPathAPI
								.eval(document, "//ProcessCreditContract/DataArea/CreditContract/Header/AutoFundingInd")
								.toString());
					} else {
						contractVal.setAutoFundingIndicator("0");
					}

					contractVal.setApplicationNumber(XPathAPI.eval(document,
							"//GenericCreditContract/contractInfo/adpCreditData/nvp[name='applicationNumber']/value")
							.toString());
					contractVal.setApplicationType(XPathAPI
							.eval(document, "//GenericCreditContract/contractHeader/applicationType").toString());
					String contractDate = XPathAPI
							.eval(document,
									"//GenericCreditContract/contractInfo/dmsData/nvp[name='ContractDate']/value")
							.toString();
					Date date = xmlDateFormat.parse(contractDate);
					java.sql.Date sql = new java.sql.Date(date.getTime());
					contractVal.setContractDate(sql);
					String timestampString = XPathAPI
							.eval(document, "//GenericCreditContract/contractHeader/creationDateTime").toString();
					DateTime dateTime_timeStamp = nvpXmlTimestampFormat.parseDateTime(timestampString);
					contractVal.setSubmittedTs(dateTime_timeStamp.toDate());
					contractVal.setDmsId(Constants.DMS_AD); //GCV NVP is CDK
				}
			} catch (TransformerException e) {
				logger.error("error getting value from xml", e);
			} catch (ParseException e) {
				logger.error("error parsing date from xml", e);
			}
		}
		return contractVal;
	}

	/**
	 * @param contractVal
	 * @return
	 */
	public DeDealBo populateDealFromCV(final DeContractValidationBo contractVal) {
		logger.debug("Enter populateDealFromCV method of CVRequestXMLParser class, CV: {}", contractVal);
		DeDealBo deal = new DeDealBo();

		deal.setLenderId(contractVal.getLenderId());
		deal.setDmsId(contractVal.getDmsId());
		deal.setDmsDealerId(contractVal.getDealerId());
		deal.setVin(contractVal.getVin());
		deal.setBuyerFirstName(contractVal.getBuyerFirstName());
		deal.setBuyerLastName(contractVal.getBuyerLastName());
		deal.setCvStatus(contractVal.getStatus());
		deal.setCvStatusTs(contractVal.getStatusTs());
		deal.setCvSubmittedTs(contractVal.getSubmittedTs());
		deal.setCvSequenceId(contractVal.getSequenceId());
		deal.setDmsDealNum(contractVal.getDmsDealNum());
		deal.setLenderSeqNum(contractVal.getLenderSeqNum());
		deal.setAccountNum(contractVal.getAccountNum());
		deal.setCaApplicationNum(contractVal.getApplicationNumber());
		deal.setApplicationType(contractVal.getApplicationType());
		deal.setContractDate(contractVal.getContractDate());
		deal.setSpotFlag(contractVal.getSpotFlag());

		return deal;
	}

	/**
	 * @param deal
	 * @param document
	 * @param transType
	 * @return
	 */
	public DeDealBo populateDealFromDocument(final DeDealBo deal, final Document document, final String transType) {
		logger.debug("Entered populateDealFromDocument method of CVRequestXMLParser class");
		if (null != document && null != transType) {
			try {
				if (transType.equalsIgnoreCase(Constants.TRANS_TYPE_EC_OUT)) {
					deal.setTerm(XPathAPI.eval(document, "//CreditContract/Financing/ContractTerm").toString());
					deal.setProductType(XPathAPI.eval(document, "//CreditContract/Header/ProductType").toString());
					deal.setVehicleCondition(
							XPathAPI.eval(document, "//CreditContract/CreditVehicle/SaleClass").toString());
				}
			} catch (final TransformerException e) {
				logger.error("In populateDealFromDocument() error getting value from document", e);
			}
		}
		return (deal);
	}

	private String getSpotFlagFromDocument(Document document) throws TransformerException {
		XNodeSet specialPrograms = (XNodeSet) XPathAPI.eval(document, "//CreditContract/Financing/ProgramsAndRates/SpecialProgramDetail/SpecialPrograms");
		NodeList specialProgramsList = specialPrograms.nodelist();
		if (specialProgramsList != null && specialProgramsList.getLength() > 0) {
			for (int i = 0; i < specialProgramsList.getLength(); i++) {
				if (specialProgramsList.item(i).getFirstChild().getNodeValue().toUpperCase().startsWith("XX")) {
					return(Constants.SPOT_FLAG_YES);
				}
			}
		}
		return(Constants.SPOT_FLAG_NO);
	}
}
