package com.ode.cv.util;

import com.ode.cv.context.ErrorLogError;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author rmathew
 *
 */
@Component
public class CVResponseXMLParser {

	private static final Logger logger = LogManager.getLogger(CVResponseXMLParser.class);

	@Value("classpath:removeNameSpace.xslt")
	private Resource removeNameSpaceStyleSheet;

	private static final String APPLICATION_AREA_ELEM = "ApplicationArea";
	private static final String DATA_AREA_ELEM = "DataArea";
	private static final String SENDER_ELEM = "Sender";
	private static final String CREDIT_CONTRACT_ELEM = "CreditContract";
	private static final String HEADER_ELEM = "Header";
	private static final String CONTRACT_HEADER = "contractHeader";
	private static final String BOD_ELEM = "BOD";
	private static final String NOUN_OUTCOME_ELEM = "NounOutcome";
	private static final String NOUN_FAILURE_ELEM = "NounFailure";
	private static final String ERROR_MESSAGE_ELEM = "ErrorMessage";
	private static final String APPLICATION_REASON_CODE_ELEM = "ApplicationReasonCode";
	private static final String DESCRIPTION_ELEM = "Description";
	private static final String FINANCING_ELEM = "Financing";

	/**
	 * This method would be called when processing Async ACCR from RouteOne.
	 * 
	 * @param accrVOInput
	 * @return
	 * @throws TransformerException
	 * @throws IOException
	 */
	public AccrVO populateAccrDetailsFromInput(final AccrVO accrVOInput) throws TransformerException, IOException {
		logger.debug("Entered populateAccrDetailsFromInput method of CVResponseXMLParser class");

		String accrXmlWithoutSchema = removeSchemaPrefixIfAny(accrVOInput.getAccrRequestXml());
		org.jsoup.nodes.Document doc = Jsoup.parse(accrXmlWithoutSchema, "", Parser.xmlParser());
		// populate data
		String lenderId = doc.select("FinanceCompany").select("PartyId").text();
		AccrVO accrVO = new AccrVO();
		accrVO.setAccrRequestXml(accrXmlWithoutSchema);
		accrVO.setLenderId(lenderId);
		String dealerId = doc.select("Destination").select("DealerNumber").text();
		accrVO.setDealerId(dealerId);
		accrVO.setBodId(doc.select(APPLICATION_AREA_ELEM).select("BODId").text());
		accrVO.setDocumentId(accrVO.getBodId());
		accrVO.setAdpDealNo(doc.select("ReferenceId").text());
		accrVO.setValidationResults(doc.select("ValidationResults").text());
		accrVO.setSequenceNumber(doc.select("ContractId").text());
		accrVO.setPaymentAmount(doc.select(DATA_AREA_ELEM).select(FINANCING_ELEM).select("PaymentAmount").text());
		accrVO.setNetAnnualPercentageRate(doc.select(DATA_AREA_ELEM).select(FINANCING_ELEM).select("NetAnnualPercentageRate").text());
		Elements senderElements = doc.select(APPLICATION_AREA_ELEM).select("Sender");		
		String senderNameCode = senderElements.select("SenderNameCode").text();
		String storeNumber = senderElements.select("StoreNumber").text();
		logger.debug("senderNameCode: {}, storeNumber: {}", senderNameCode, storeNumber);
		accrVO.setStoreNumber(storeNumber);
		accrVO.setSenderNameCode(senderNameCode);
		//accrVO.setStoreNumber(doc.select(APPLICATION_AREA_ELEM).select("Sender").select("StoreNumber").text());
		//accrVO.setSenderNameCode(doc.select(APPLICATION_AREA_ELEM).select("Sender").select("SenderNameCode").text());
		
		//get the account number from the ECACKIN
		String accountNumber = null;
		Elements accountDescriptionTags = doc.select(DATA_AREA_ELEM)
				.select("ValidationMessage")
				.select("Description");
		for(Element e : accountDescriptionTags) {
			if(e.ownText() != null && e.ownText().startsWith("Agreement Number for this Contract is")) {
				boolean endsInPeriod = e.ownText().endsWith(".");
				accountNumber = e.ownText().substring(e.ownText().lastIndexOf(" ") + 1, (endsInPeriod) ? (e.ownText().length() - 1) : e.ownText().length());
				break;
			}
		}

		accrVO.setAccountNumber(accountNumber);
		
		//get the lender sequence number from the ECACKIN
		String lenderSequenceNumber = null;
		Elements lenSeqDescriptionTags = doc.select(DATA_AREA_ELEM)
				.select("ValidationMessage")
				.select("Description");
		for(Element e : lenSeqDescriptionTags) {
			if(e.ownText() != null && e.ownText().startsWith("The sequence number is")) {
				boolean endsInPeriod = e.ownText().endsWith(".");
				lenderSequenceNumber = e.ownText().substring(e.ownText().lastIndexOf(" ") + 1, (endsInPeriod) ? (e.ownText().length() - 1) : e.ownText().length());
				break;
			}
		}

		accrVO.setLenderSequenceNumber(lenderSequenceNumber);
		
		accrVO.setDealerNumber(accrVOInput.getDealerNumber());
		accrVO.setReferenceId(accrVOInput.getReferenceId());
		accrVO.setAuthorizationId(accrVOInput.getAuthorizationId());
		accrVO.setContractFormNumber(accrVOInput.getContractFormNumber());
		return accrVO;

	}

	/**
	 * @param xmlString
	 * @return
	 * @throws TransformerException
	 * @throws IOException
	 */
	public String removeSchemaPrefixIfAny(final String xmlString) throws TransformerException, IOException {
		logger.debug("Entered removeSchemaPrefixIfAny method of CVResponseXMLParser class");
		Source transformerSource = new StreamSource(removeNameSpaceStyleSheet.getInputStream());
		StringReader reader = new StringReader(xmlString);
		Source xmlSource = new StreamSource(reader);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
				org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
		Transformer transformer = tf.newTransformer(transformerSource);
		transformer.transform(xmlSource, result);
		transformer = null;
		return writer.toString();
	}

	/**
	 * This method would be called when processing Async ACCR from RouteOne.
	 * 
	 * @param ecout2Xml
	 * @param accrVO
	 */
	public void populateAccrDetailsFromEcout2(final String ecout2Xml, final AccrVO accrVO) {
		logger.debug("Entered populateAccrDetailsFromEcout2 method of CVResponseXMLParser class", ecout2Xml);
		org.jsoup.nodes.Document doc = Jsoup.parse(ecout2Xml, "", Parser.xmlParser());
		// populate data
		String dealerNumber = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("DealerNumber").text();
		String storeNumber = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("StoreNumber").text();
		String referenceId = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("ReferenceId").text();
		String authorizationId = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("AuthorizationId").text();
		String contractId = doc.select("ContractPackage").select("ContractId").text();
		String contractFormNumber = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
				.select("ContractFormNumber").text();
		String documentVersionNumber = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
				.select("DocumentVersionNumber").text();
		String financeCompanyName = doc.select("FinanceCompany").select("Name").text();
		String dealerName = doc.select("Dealer").select("DealerName").text();

		String paymentAmount = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select("Financing")
				.select("FederalTILDisclosures").select("PaymentSchedule").select("PaymentAmount").first().text();
		String netAnnualPercentageRate = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select("Financing")
				.select("ProgramsAndRates").select("NetAnnualPercentageRate").text();
		accrVO.setBodId(doc.select(APPLICATION_AREA_ELEM).select("BODId").text());
		accrVO.setDocumentId(accrVO.getBodId());
		accrVO.setDealerNumber(dealerNumber);
		accrVO.setStoreNumber(storeNumber);
		accrVO.setReferenceId(referenceId);
		accrVO.setAuthorizationId(authorizationId);
		accrVO.setContractId(contractId);
		accrVO.setContractFormNumber(contractFormNumber);
		accrVO.setDocumentVersionNumber(documentVersionNumber);
		accrVO.setFinanceCompanyName(financeCompanyName);
		accrVO.setDealerName(dealerName);
		accrVO.setPaymentAmount(paymentAmount);
		accrVO.setNetAnnualPercentageRate(netAnnualPercentageRate);
		doc = null;
	}

	/**
	 * This method would be called when gathering errors from a Lender request.
	 *
	 * @param ecout2Xml
	 * @return
	 */
	public List<ErrorLogError> extractErrorsFromEcout2(final String ecout2Xml) {
		logger.debug("Entered extractErrorsFromEcout2 method of CVResponseXMLParser class");
		List<ErrorLogError> errors = new ArrayList<>();

		org.jsoup.nodes.Document doc = Jsoup.parse(ecout2Xml, "", Parser.xmlParser());
		Elements errorMessages = doc.select(DATA_AREA_ELEM).select(BOD_ELEM)
				.select(NOUN_OUTCOME_ELEM).select(NOUN_FAILURE_ELEM).select(ERROR_MESSAGE_ELEM);

		errorMessages.forEach(errorMessage -> {
			if (errorMessage.select(APPLICATION_REASON_CODE_ELEM).size() > 0 &&
					errorMessage.select(DESCRIPTION_ELEM).size() > 0) {
				errors.add(new ErrorLogError(errorMessage.select(APPLICATION_REASON_CODE_ELEM).text(),
						errorMessage.select(DESCRIPTION_ELEM).text()));
			}
		});

		return errors;
	}

	/**
	 * This method would be called when ODE RulesEngine validation fails.
	 * 
	 * @param cvTransmitVO
	 * @throws IOException
	 * @throws TransformerException
	 */
	public void populateDestinationInfoFromEcout(final CVTransmitVO cvTransmitVO)
			throws TransformerException, IOException {
		logger.debug("Entered populateDestinationInfoFromEcout method of CVResponseXMLParser class");
		String xmlWithoutSchemaPrefixes = removeSchemaPrefixIfAny(cvTransmitVO.getAccrResponseXml());
		// logger.debug("xmlWithoutSchemaPrefixes: {}", xmlWithoutSchemaPrefixes);
		org.jsoup.nodes.Document doc = Jsoup.parse(xmlWithoutSchemaPrefixes, "", Parser.xmlParser());
		// populate data
		String dealerNumber = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("DealerNumber").text();
		String storeNumber = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("StoreNumber").text();
		String bodId = doc.select(APPLICATION_AREA_ELEM).select("BODId").text();
		String referenceId = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("ReferenceId").text();
		String authorizationId = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("AuthorizationId").text();
		String contractId = null;
		if (null != doc.select("ContractPackage")) {
			contractId = doc.select("ContractPackage").select("ContractId").text();
		}

		String contractFormNumber = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
				.select("ContractFormNumber").text();
		String documentVersionNumber = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
				.select("DocumentVersionNumber").text();
		String financeCompanyName = doc.select("FinanceCompany").select("Name").text();
		String dealerName = doc.select("Dealer").select("DealerName").text();
		String paymentAmount = null;
		String netAnnualPercentageRate = null;

		try {
			paymentAmount = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select("Financing")
					.select("FederalTILDisclosures").select("PaymentSchedule").select("PaymentAmount").first().text();

		} catch (final Exception e) {

			logger.debug("Exception parsing PaymentSchedule information");
		}

		try {
			netAnnualPercentageRate = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select("Financing")
					.select("ProgramsAndRates").select("NetAnnualPercentageRate").text();
		} catch (final Exception e) {
			logger.debug("Exception parsing NetAnnualPercentageRate information");
		}
		cvTransmitVO.getAccrContext().setBodId(doc.select(APPLICATION_AREA_ELEM).select("BODId").text());
		cvTransmitVO.getAccrContext().setDocumentId(cvTransmitVO.getAccrContext().getBodId());
		cvTransmitVO.getAccrContext().setDealerNumber(dealerNumber);
		cvTransmitVO.getAccrContext().setStoreNumber(storeNumber);
		cvTransmitVO.getAccrContext().setBodId(bodId);
		cvTransmitVO.getAccrContext().setReferenceId(referenceId);
		cvTransmitVO.getAccrContext().setAuthorizationId(authorizationId);
		cvTransmitVO.getAccrContext().setContractId(contractId);
		cvTransmitVO.getAccrContext().setContractFormNumber(contractFormNumber);
		cvTransmitVO.getAccrContext().setDocumentVersionNumber(documentVersionNumber);
		cvTransmitVO.getAccrContext().setFinanceCompanyName(financeCompanyName);
		cvTransmitVO.getAccrContext().setDealerName(dealerName);
		cvTransmitVO.getAccrContext().setPaymentAmount(paymentAmount);
		cvTransmitVO.getAccrContext().setNetAnnualPercentageRate(netAnnualPercentageRate);
		doc = null;
	}

	/**
	 * This method would be called when ODE RulesEngine validation fails.
	 * 
	 * @param creditContractVO
	 * @param cvTransmitVO
	 * @throws IOException
	 * @throws TransformerException
	 */
	public void populateDestinationInfoFromEcin(final CreditContractVO creditContractVO,
			final CVTransmitVO cvTransmitVO) throws TransformerException, IOException {
		logger.debug("Entered populateDestinationInfoFromEcin method of CVResponseXMLParser class");
		String xmlWithoutSchemaPrefixes = removeSchemaPrefixIfAny(creditContractVO.getRequestXML());
		// logger.debug("xmlWithoutSchemaPrefixes: {}", xmlWithoutSchemaPrefixes);
		org.jsoup.nodes.Document doc = Jsoup.parse(xmlWithoutSchemaPrefixes, "", Parser.xmlParser());
		// populate data
		String destinationCode = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("CreatorNameCode").text();
		String applicationType = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
				.select("ApplicationType").text();
		String financeType = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
				.select("FinanceType").text();
		cvTransmitVO.getAccrContext().setDocumentId(cvTransmitVO.getAccrContext().getBodId());
		cvTransmitVO.getAccrContext().setDestinationCode(destinationCode);
		cvTransmitVO.getAccrContext().setApplicationType(applicationType);
		cvTransmitVO.getAccrContext().setFinanceType(financeType);
		doc = null;
	}

	/**
	 * This method would be called when processing Async ACCR from RouteOne.
	 * 
	 * @param ecinXml
	 * @param accrVO
	 * @param dspId 
	 * @throws IOException
	 * @throws TransformerException
	 */
	public void populateAccrDetailsFromEcin(final String ecinXml, final AccrVO accrVO, final String dspId)
			throws TransformerException, IOException {
		logger.debug("Entered populateAccrDetailsFromEcin method of CVResponseXMLParser class. dspId: {}", dspId);
		String xmlWithoutSchemaPrefixes = removeSchemaPrefixIfAny(ecinXml);
		org.jsoup.nodes.Document doc = Jsoup.parse(xmlWithoutSchemaPrefixes, "", Parser.xmlParser());
		String destinationCode = doc.select(APPLICATION_AREA_ELEM).select(SENDER_ELEM).select("CreatorNameCode").text();
		String applicationType = "";
		String financeType = "";
		String responseUrl = "";
		String locationId = "";
		String serviceId = "";
		if (Constants.CDK_DMS_ID.equals(dspId)) {
			applicationType = doc.select(CONTRACT_HEADER)
					.select("ApplicationType").text();
			financeType = doc.select(CONTRACT_HEADER)
					.select("FinanceType").text();
			responseUrl = doc.select("clientInfo")
					.select("responseUrl").text();
			int serviceIndex = responseUrl.indexOf("fieldtest");
			serviceId = responseUrl.substring(serviceIndex-1);
			locationId = responseUrl.substring(0, serviceIndex-1);
			logger.debug("serviceId from ECIN: {}, locationId from ECIN: {}", serviceId, locationId);
			
		} else {
			applicationType = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
					.select("ApplicationType").text();
			financeType = doc.select(DATA_AREA_ELEM).select(CREDIT_CONTRACT_ELEM).select(HEADER_ELEM)
					.select("FinanceType").text();
		}
		accrVO.setDestinationCode(destinationCode);
		accrVO.setApplicationType(applicationType);
		accrVO.setFinanceType(financeType);
		if (StringUtils.isNotBlank(serviceId))
		{
			accrVO.setServiceId(serviceId);
		}
		if (StringUtils.isNotBlank(locationId))
		{
			accrVO.setLocationId(locationId);
		}
		doc = null;
		logger.debug("FinanceType from ECIN: {}, ApplicationType from ECIN: {}", accrVO.getFinanceType(), accrVO.getApplicationType());
	}

	/**
	 * @param lteAccrXml
	 * @return
	 * @throws IOException
	 * @throws TransformerException
	 */
	public List<String> extractRequiredFormsList(final String lteAccrXml) throws TransformerException, IOException {
		logger.debug("Entered extractRequiredFormsList method of CVResponseXMLParser class");
		String lteAccrXmlWithoutSchemaPrefixes = removeSchemaPrefixIfAny(lteAccrXml);
		org.jsoup.nodes.Document doc = Jsoup.parse(lteAccrXmlWithoutSchemaPrefixes, "", Parser.xmlParser());
		Elements validationMessages = doc.select("ValidationMessage");
		final List<String> formsList = new ArrayList<>();
		validationMessages.forEach(valMsg -> {

			valMsg.children().forEach(child -> {
				if (child.nodeName().equals("Description")) {
					String formName = child.text();
					if (StringUtils.isNotBlank(formName))
					{
						if (formName.indexOf("-") > 0)
						{
							formName = formName.substring(formName.indexOf("-") + 1);
						}
						formsList.add(formName.trim());
					}
				}
			});
		});
		return formsList;

	}	
	
	/**
	 * @param xml
	 * @return
	 */
	public String getValidationResultsFromOldREResponse(final String xml) {
		logger.debug("Entered getValidationResults() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String validationResults = doc.select("ValidationResults").text();
		doc = null;
		return validationResults;
	}

	public AccrVO populateConfirmBodDetailsFromInput(String lenderResponseXml) throws TransformerException, IOException {
		logger.debug("Entered populateConfirmBodDetailsFromInput method of CVResponseXMLParser class");

		String accrXmlWithoutSchema = removeSchemaPrefixIfAny(lenderResponseXml);
		org.jsoup.nodes.Document doc = Jsoup.parse(accrXmlWithoutSchema, "", Parser.xmlParser());

		String lenderId = doc.select("ApplicationArea").select("Sender").select("CreatorNameCode").text();
		AccrVO accrVO = new AccrVO();
		accrVO.setAccrRequestXml(accrXmlWithoutSchema);
		accrVO.setLenderId(lenderId);
		String dealerId = doc.select("OriginalApplicationArea").select("Destination").select("DealerNumber").text();
		accrVO.setDealerId(dealerId);
		accrVO.setBodId(doc.select("OriginalApplicationArea").select("Sender").select("ReferenceId").text());
		accrVO.setDocumentId(accrVO.getBodId());
		accrVO.setValidationResults(doc.select("BODFailure").select("ErrorMessage").select("Description").text());
		return accrVO;
	}
}
