package com.ode.cv.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ode.cv.service.IProductConfigurationLookupService;

/**
 * @author rmathew
 *
 */
@Component
public class CVTransmitUtil {
	
	private static final Logger logger = LogManager.getLogger(CVTransmitUtil.class);
	
	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;
	
	/**
	 * @return
	 * @throws UnrecoverableKeyException
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws CertificateException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public RestTemplate getRestTemplate() throws UnrecoverableKeyException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException, CertificateException, FileNotFoundException, IOException
	{
		logger.debug("Entered getRestTemplate() method of CVTransmitUtil class");
		RestTemplate restTemplate = null;
		boolean isSecureTransmission = productConfigurationLookupService.isFeatureConfigurationAvailable(Constants.SECURE_TRANSMISSION, "");
		if (isSecureTransmission)
		{
			/* If the lender is configured for Secure Transmission, we need to create the appropriate RestTemplate. As of now
			 * we only have the requirement to created a RestTemplate with ClientCert. In the future if we require mutual auth or something, 
			 * we need to implement a more generic solution, to create the RestTemplate with the right parameters */
			String clientCert = productConfigurationLookupService.getFeatureValue(Constants.CLIENT_CERT, null);
			String protocolVersion = productConfigurationLookupService.getFeatureValue(Constants.PROTOCOL_VERSION, null);
			logger.debug("Creating RestTemplate with ClientCert and TLS protocol");
			restTemplate = restTemplateWithClientCert(clientCert, protocolVersion);
		}
		else
		{
			logger.debug("Creating the default RestTemplate");
			restTemplate = new RestTemplate();
		}
		logger.debug("Exit getRestTemplate() method of CVTransmitUtil class");
		return restTemplate;
		
	}
	
	/**
	 * @return
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws CertificateException
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws KeyManagementException
	 */
	public RestTemplate restTemplateWithClientCert(final String clientCert, final String protocolVersion) throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, FileNotFoundException, IOException, KeyManagementException {
		logger.debug("Entered restTemplateWithClientCert() method of CVTransmitUtil class");
	    KeyStore clientStore = KeyStore.getInstance(Constants.JKS_FORMAT);
	    clientStore.load(new FileInputStream(clientCert), Constants.PASSWORD_TEXT.toCharArray());
	    SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
	    sslContextBuilder.setProtocol(protocolVersion);
	    sslContextBuilder.loadKeyMaterial(clientStore, Constants.PASSWORD_TEXT.toCharArray());
	    //sslContextBuilder.loadTrustMaterial(new TrustSelfSignedStrategy());
	 
	    SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
	    CloseableHttpClient httpClient = HttpClients.custom()
	            .setSSLSocketFactory(sslConnectionSocketFactory)
	            .build();
	    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
	    requestFactory.setConnectTimeout(10000); // 10 seconds
	    requestFactory.setReadTimeout(10000); // 10 seconds
	    logger.debug("Exit restTemplateWithClientCert() method of CVTransmitUtil class");
	    return new RestTemplate(requestFactory);
	}

}
