/**
 * 
 */
package com.ode.cv.util;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.ode.cv.rest.entity.RouteOneErrorResponse;
import com.ode.cv.vo.ContractPackageVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DirectRenderResponseQueueMessageVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.ExpressionVO;
import com.ode.dlr.util.AppMessage;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.vo.CreditJournalVO;
import com.ode.persistence.vo.DeCdkCloudCvXrefVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public class CVUtil {

	private static final Logger logger = LogManager.getLogger(CVUtil.class);

	/**
	 * Private Constructor.
	 */
	private CVUtil() {
		super();
	}

	/**
	 * @param nextDeDealId
	 * @return
	 */
	public static String getNewDealId(final int nextDeDealId) {
		logger.debug("Entered getNewDealId()");
		String dealId = "0000000";
		String unpaddedDealId = Integer.toString(nextDeDealId);
		dealId = dealId.substring(0, 7 - unpaddedDealId.length()) + unpaddedDealId;
		return dealId;
	}

	/**
	 * @param firstName
	 * @param lastName
	 * @param dmsDealId
	 * @param store
	 * @return
	 */
	public static String generateVaultDocId(String firstName, String lastName, String dmsDealId, String store) {
		logger.debug("Entered generateVaultDocId()");
		String timestamp = new SimpleDateFormat("HH:mm:ss.SS").format(new Date());
		firstName = fixWidth(firstName, 8, "x");
		lastName = fixWidth(lastName, 8, "x");
		dmsDealId = fixWidth(dmsDealId, 6, "x");
		store = fixWidth(store, 15, "x");
		String vaultDocId = firstName + "_" + lastName + "_" + dmsDealId + "_xxxxxxxx_xxxxxx_" + store + "_"
				+ timestamp;
		return vaultDocId;
	}

	/**
	 * @param s
	 * @param width
	 * @param paddChar
	 * @return
	 */
	public static String fixWidth(String s, int width, String paddChar) {
		logger.debug("Entered fixWidth()");
		String result = "";
		if (s == null) {
			result = StringUtils.repeat(paddChar, width);
		} else if (s.length() == width) {
			result = s;
		} else if (s.length() < width) {
			result = s + StringUtils.repeat(paddChar, width - s.length());
		} else if (s.length() > width) {
			result = s.substring(0, width);
		}
		return result;
	}

	/**
	 * @param creditContractVO
	 */
	public static void generateVaultDocIdForEcin(final CreditContractVO creditContractVO) {
		if (Constants.TRANS_TYPE_EC_IN.equals(creditContractVO.getTransType())) {
			String store = "Dealer";
			if (creditContractVO.getContractValidation().getDmsId() != null
					&& creditContractVO.getContractValidation().getDmsId().equalsIgnoreCase("AD")) {
				store = "CDKDealer";
			}
			creditContractVO
					.setVaultDocId(generateVaultDocId(creditContractVO.getContractValidation().getBuyerFirstName(),
							creditContractVO.getContractValidation().getBuyerLastName(),
							creditContractVO.getContractValidation().getDmsDealNum(), store));
		}
	}

	/**
	 * Concat Dealer ID, DMS Deal Number and 6 digit alpha numeric random number.
	 * 
	 * @param creditContractVO
	 * @return
	 */
	public static String generateContractId(final CreditContractVO creditContractVO) {
		logger.debug("Entered generateContractId method in CVUtil.class");

		// 10 digit
		String dmsDealerId = creditContractVO.getDeal().getDmsDealerId();
		String finalDmsDealerId = null;
		if (dmsDealerId.length() > 10) {
			finalDmsDealerId = dmsDealerId.substring(0, 10);
		} else if (dmsDealerId.length() < 10) {
			finalDmsDealerId = StringUtils.leftPad(dmsDealerId, 10, '0');
		} else {
			finalDmsDealerId = dmsDealerId;
		}

		// 8 digit
		String dmsDealNum = creditContractVO.getDeal().getDmsDealNum();
		String finaldmsDealNum = null;
		if (dmsDealNum.length() > 8) {
			finaldmsDealNum = dmsDealNum.substring(0, 8);
		} else if (dmsDealNum.length() < 8) {
			finaldmsDealNum = StringUtils.leftPad(dmsDealNum, 8, '0');
		} else {
			finaldmsDealNum = dmsDealNum;
		}

		// lendeId

		String lenderId = creditContractVO.getDeal().getLenderId();

		// 6 digit
		String randomNum = RandomStringUtils.randomAlphanumeric(6).toUpperCase();

		String contractId = new StringBuilder().append(finaldmsDealNum).append(Constants.UNDER_SCORE)
				.append(finalDmsDealerId).append(Constants.UNDER_SCORE).append(lenderId).append(Constants.UNDER_SCORE)
				.append(randomNum).toString();
		logger.debug("Generated ContractId: " + contractId);

		return contractId;
	}

	/**
	 * @param creditContractVO
	 * @param routeOneDealerId
	 * @param hmacId
	 * @return
	 * @throws Exception
	 */
	public static Map<String, String> generateInputMapForRouteOneRequestHeaders(final CreditContractVO creditContractVO,
			final String routeOneHmacId, final String routeOneDealerId) throws Exception {
		logger.debug("Entered generateInputMapForRouteOneRequestHeaders() method of CVUtil.class");
		Map<String, String> input = new HashMap<>(); // Additional information for RouteOne request

		String contractId = creditContractVO.getContractValidation().getContractId();
		String partnerFSID = creditContractVO.getDealerInfo().getPartnerId();
		String authorizationId = creditContractVO.getContractValidation().getAuthorizationId();
		String applicationNumber = creditContractVO.getApplicationNumber();
		String dealerNumber = creditContractVO.getDealerInfo().getDealerId();

		logger.debug(creditContractVO.getDealerInfo());
		logger.debug(creditContractVO.getPartnerInfo());
		logger.debug(creditContractVO.getContractValidation());
		logger.debug(creditContractVO.getApplicationNumber());

		input.put("contractId", contractId);
		input.put("partnerFSID", partnerFSID);
		input.put("authorizationId", authorizationId);
		input.put("applicationNumber", applicationNumber);
		input.put("dealerNumber", dealerNumber);
		input.put("routeOneHmacId", routeOneHmacId);
		input.put("routeOneDealerId", routeOneDealerId);

		logger.debug("Additional Input Map: " + input);
		return input;

	}

	/**
	 * @param document
	 * @param contractPackageVO
	 * @return
	 * @throws ParserConfigurationException
	 */
	public static Document restructureAndAddContractPackageToCVDocument(final Document document,
			final ContractPackageVO contractPackageVO) throws ParserConfigurationException {
		logger.debug("Entered restructureAndAddContractPackageToCVDocument() method of CVUtil class");
		NodeList nodes = document.getElementsByTagName("ProcessCreditContract");
		if (null == nodes || nodes.getLength() == 0) {
			return null;
		}
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Document restructuredDoc = docBuilder.newDocument();

		Element contractPackage = restructuredDoc.createElement("ContractPackage");
		restructuredDoc.appendChild(contractPackage);
		Element contractId = restructuredDoc.createElement("ContractId");
		Text txtContractId = restructuredDoc.createTextNode(contractPackageVO.getContractId());
		contractId.appendChild(txtContractId);
		Element contractType = restructuredDoc.createElement("ContractType");
		Text txtContractType = restructuredDoc.createTextNode(contractPackageVO.getContractType());
		contractType.appendChild(txtContractType);
		Element partnerFSID = restructuredDoc.createElement("PartnerFSID");
		Text txtPartnerFSID = restructuredDoc.createTextNode(contractPackageVO.getPartnerFSID());
		partnerFSID.appendChild(txtPartnerFSID);
		Element conversationId = restructuredDoc.createElement("RouteOneCreditApplicationConversationID");
		Text txtConversationId = restructuredDoc.createTextNode(contractPackageVO.getConversationId());
		conversationId.appendChild(txtConversationId);

		contractPackage.appendChild(contractId);
		contractPackage.appendChild(contractType);
		contractPackage.appendChild(partnerFSID);
		contractPackage.appendChild(conversationId);

		Node importedNode = null;
		for (int i = 0; i < nodes.getLength(); i++) {

			if (nodes.item(i) instanceof Element) {
				Element elem = (Element) nodes.item(i);
				elem.removeAttribute("xmlns");
				elem.removeAttribute("environment");
				elem.removeAttribute("lang");
				elem.removeAttribute("release");
				elem.removeAttribute("revision");
				elem.removeAttribute("xsi:schemaLocation");
				importedNode = restructuredDoc.importNode(elem, true);
				break;
			}

		}

		contractPackage.appendChild(importedNode);
		restructuredDoc.renameNode(importedNode, null, "RouteOneProcessCreditContract");

		return restructuredDoc;
	}

	/**
	 * @param document
	 * @param elementName
	 * @return
	 * @throws ParserConfigurationException
	 */
	public static Document generateDocumentFromElement(final Document document, final String elementName,
			final String newElementName) throws ParserConfigurationException {
		logger.debug("Entered generateDocumentFromElement() method of CVUtil class. elementName: {}", elementName);

		NodeList nodes = document.getElementsByTagName(elementName);
		if (null == nodes || nodes.getLength() == 0) {
			return null;
		}

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Document newDocument = docBuilder.newDocument();

		Node importedNode = null;
		for (int i = 0; i < nodes.getLength(); i++) {

			if (nodes.item(i) instanceof Element) {
				Element elem = (Element) nodes.item(i);
				if (elementName.equals(elem.getNodeName())) {
					importedNode = newDocument.importNode(elem, true);
					break;
				}
			}
		}
		newDocument.appendChild(importedNode);
		if (StringUtils.isNotBlank(newElementName)) {
			newDocument.renameNode(importedNode, null, newElementName);
			logger.debug("Renamed element name from {} to {}", elementName, newElementName);
		}
		logger.debug("Exit generateDocumentFromElement() method of CVUtil class. elementName: {}", elementName);

		return newDocument;
	}

	/**
	 * @param document
	 * @param creditContractVO
	 * @return
	 * @throws ParserConfigurationException
	 */
	public static Document removeTradeInsFromCVDocument(final Document document,
			final CreditContractVO creditContractVO) throws ParserConfigurationException {
		logger.debug("Entered removeTradeInsFromCVDocument() method of CVUtil class");
		NodeList nodeList = document.getElementsByTagName("TradeIn");

		if (null == nodeList || nodeList.getLength() == 0) {
			return document;
		} else if (nodeList.getLength() > 1) {
			int numTradeIns = nodeList.getLength();
			logger.debug("No. of TradeIns: {}", numTradeIns);
			List<Node> nodesToBeRemoved = new ArrayList<>();
			BigDecimal summaryGrossTradeIn;

			Node firstChild = nodeList.item(0);
			Node financingNode = firstChild.getParentNode();

			NodeList grossTradeInList = null;
			if (financingNode instanceof Element) {
				Element financingElement = (Element) financingNode;
				grossTradeInList = financingElement.getElementsByTagName("GrossTradeIn");
			}

			if (grossTradeInList.getLength() > 0) {
				List<BigDecimal> grossTradeInAmounts = new ArrayList<>();
				for (int i = 0; i < grossTradeInList.getLength(); i++) {
					grossTradeInAmounts.add(new BigDecimal(grossTradeInList.item(i).getTextContent()));
				}
				Collections.sort(grossTradeInAmounts, Collections.reverseOrder());
				summaryGrossTradeIn = grossTradeInAmounts.get(0);
				logger.debug("summaryGrossTradeIn: {}", summaryGrossTradeIn);

				boolean foundTradeInToKeep = false;

				for (int i = 0; i < numTradeIns; i++) {
					Node tradeIn = nodeList.item(i);
					BigDecimal grossTradeIn = getGrossTradinFromNode(tradeIn);
					if (grossTradeIn.compareTo(summaryGrossTradeIn) == 0 && !foundTradeInToKeep) {
						foundTradeInToKeep = true;
						continue;
					}
					nodesToBeRemoved.add(nodeList.item(i));
					logger.debug("Added node with grossTradeIn: {} to be removed", grossTradeIn);
				}

			} else {
				for (int i = 1; i < numTradeIns; i++) {
					nodesToBeRemoved.add(nodeList.item(i));
				}
			}
			nodesToBeRemoved.forEach(node -> {
				financingNode.removeChild(node);
			});

		}
		NodeList nodeListAfter = document.getElementsByTagName("TradeIn");
		if (null != nodeList || nodeList.getLength() > 0) {
			logger.debug("Number of TradeIns: {}", nodeList.getLength());
		}
		logger.debug("Exit removeTradeInsFromCVDocument() method of CVUtil class");
		return document;
	}

	/**
	 * @param document
	 * @param creditContractVO
	 * @return
	 */
	public static Document addApplicantPartyIDs(final Document document, final CreditContractVO creditContractVO) {
		logger.debug("Entered addApplicantPartyIDs() method of CVUtil class");
		String cvSequenceId = creditContractVO.getContractValidation().getSequenceId();
		NodeList iANodeList = document.getElementsByTagName("IndividualApplicant");
		int nextPartyIdNumber = 1;
		if (null != iANodeList && iANodeList.getLength() > 0) {
			Node iANode = iANodeList.item(0);
			String partyId = getNewPartyId(cvSequenceId, nextPartyIdNumber);
			addPartyIdToNode(document, iANode, partyId);
			nextPartyIdNumber++;
		}

		NodeList coAppNodeList = document.getElementsByTagName("Co-Applicant");
		if (null != coAppNodeList && coAppNodeList.getLength() > 0) {

			int len = coAppNodeList.getLength();
			for (int i = 0; i < len; i++) {
				Node aNode = coAppNodeList.item(i);
				String partyId = getNewPartyId(cvSequenceId, nextPartyIdNumber);
				addPartyIdToNode(document, aNode, partyId);
				nextPartyIdNumber++;
			}

		}

		NodeList orgAppNodeList = document.getElementsByTagName("OrganizationalApplicant");
		if (null != orgAppNodeList && orgAppNodeList.getLength() > 0) {

			int len = orgAppNodeList.getLength();
			for (int i = 0; i < len; i++) {
				Node aNode = orgAppNodeList.item(i);
				String partyId = getNewPartyId(cvSequenceId, nextPartyIdNumber);
				addPartyIdToNode(document, aNode, partyId);
				nextPartyIdNumber++;
			}

		}

		NodeList guarantorNodeList = document.getElementsByTagName("Guarantor");
		if (null != guarantorNodeList && guarantorNodeList.getLength() > 0) {

			int len = guarantorNodeList.getLength();
			for (int i = 0; i < len; i++) {
				Node aNode = guarantorNodeList.item(i);
				String partyId = getNewPartyId(cvSequenceId, nextPartyIdNumber);
				addPartyIdToNode(document, aNode, partyId);
				nextPartyIdNumber++;
			}

		}
		logger.debug("Exit addApplicantPartyIDs() method of CVUtil class");
		return document;
	}

	/**
	 * @param document
	 * @param targetNode
	 * @param partyId
	 */
	private static void addPartyIdToNode(final Document document, final Node targetNode, final String partyId) {
		logger.debug("Entered addPartyIdToNode() method of CVUtil class");
		if (targetNode instanceof Element) {
			Element element = (Element) targetNode;
			NodeList nodeList = element.getElementsByTagName("PartyId");
			if (null != nodeList && nodeList.getLength() > 0) {
				Element partyIdElement = null;
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node aNode = nodeList.item(i);
					if (aNode instanceof Element) {
						partyIdElement = (Element) aNode;
						break;
					}
				}
				if (null != partyIdElement) {
					partyIdElement.setTextContent(partyId);
				}
			} else {
				Element partyIdElement = document.createElement("PartyId");
				Text txtPartyId = document.createTextNode(partyId);
				partyIdElement.appendChild(txtPartyId);
				element.insertBefore(partyIdElement, element.getFirstChild());
			}
		}
		logger.debug("Exit addPartyIdToNode() method of CVUtil class");
	}

	/**
	 * @param nexPartyId
	 * @return
	 */
	public static String getNewPartyId(final String cvSequenceId, final int nextPartyIdNumber) {
		logger.debug("Entered getNewPartyId()");
		String partyId = "000000";
		String unpaddedPartyId = String.valueOf(nextPartyIdNumber);
		String cvSequenceIdNumberPart = cvSequenceId.substring(2);
		partyId = cvSequenceIdNumberPart + partyId.substring(cvSequenceIdNumberPart.length());
		partyId = partyId.substring(0, 6 - unpaddedPartyId.length()) + unpaddedPartyId;
		return partyId;
	}

	/**
	 * @param tradeIn
	 * @return GrossTradeIn amount
	 */
	private static BigDecimal getGrossTradinFromNode(final Node tradeInNode) {
		if (tradeInNode instanceof Element) {
			Element tradeInElement = (Element) tradeInNode;
			Node node = tradeInElement.getElementsByTagName("GrossTradeIn").item(0);
			String amount = node.getTextContent();
			if (StringUtils.isNotBlank(amount)) {
				return new BigDecimal(amount);
			}
		}
		return null;
	}

	/**
	 * @param doc
	 * @return
	 * @throws TransformerException
	 */
	public static String getXmlStringFromDocument(final Document doc) throws TransformerException {
		logger.debug("Entered getXmlStringFromDocument() method of CVUtil class");
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
				org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
		Transformer transformer = tf.newTransformer();
		if (transformer != null) {
			transformer.transform(domSource, result);
		} else {
			logger.debug("transformer is null");
		}
		return writer.toString();
	}

	/**
	 * @param newDocument
	 * @param creditContractVO
	 */
	public static void addDealerPartyId(final Document newDocument, final CreditContractVO creditContractVO) {
		logger.debug("Entered addDealerPartyId() method of CVUtil class");
		String xpath = "//payload/content/ProcessCreditContract/DataArea/CreditContract/Dealer/PartyId";
		Node dealerPartyIdNode = null;
		try {
			if (null != creditContractVO.getDeal()
					&& StringUtils.isNotBlank(creditContractVO.getDeal().getLenderDealerId())) {
				dealerPartyIdNode = getNode(newDocument, xpath);
				if (null != dealerPartyIdNode) {
					logger.debug("Found node at xpath: {}", xpath);
					dealerPartyIdNode.setTextContent(creditContractVO.getDeal().getLenderDealerId());
					logger.debug("Dealer PartyId was set to value: {}", creditContractVO.getDeal().getLenderDealerId());
				}
			}

		} catch (final XPathExpressionException e) {
			logger.debug("Exception occured within addDealerPartyId() method of CVUtil class", e);
		}
	}

	/**
	 * @param document
	 * @param ruleXpath
	 * @return
	 * @throws XPathExpressionException
	 */
	public static Node getNode(final Document document, final String nodeXpath) throws XPathExpressionException {

		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile(nodeXpath);
		return (Node) expr.evaluate(document, XPathConstants.NODE);
	}

	/**
	 * @param document
	 * @return
	 * @throws ParserConfigurationException
	 */
	public static Document restructureCVDocumentForLender(final Document document) throws ParserConfigurationException {
		logger.debug("Entered restructureCVDocumentForLender() method of CVUtil class");

		NodeList nodes = document.getElementsByTagName("ProcessCreditContract");
		if (null == nodes || nodes.getLength() == 0) {
			return null;
		}

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Document restructuredDoc = docBuilder.newDocument();
		Node importedNode = null;
		for (int i = 0; i < nodes.getLength(); i++) {

			if (nodes.item(i) instanceof Element) {
				Element elem = (Element) nodes.item(i);
				elem.removeAttribute("revision");
				elem.removeAttribute("xsi:schemaLocation");
				importedNode = restructuredDoc.importNode(elem, true);
				break;
			}
		}
		restructuredDoc.appendChild(importedNode);
		return restructuredDoc;
	}

	/**
	 * @param document
	 * @return
	 * @throws ParserConfigurationException
	 */
	public static Document restructureCVDocumentForLenderCdkCloudRequest(final Document document) throws ParserConfigurationException {
		logger.debug("Entered restructureCVDocumentForLenderCdkCloudRequest() method of CVUtil class");

		NodeList nodes = document.getElementsByTagName("ProcessCreditContract");
		if (null == nodes || nodes.getLength() == 0) {
			return null;
		}

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Document restructuredDoc = docBuilder.newDocument();
		Node importedNode = null;
		for (int i = 0; i < nodes.getLength(); i++) {

			if (nodes.item(i) instanceof Element) {
				Element elem = (Element) nodes.item(i);
				elem.removeAttribute("revision");
				elem.removeAttribute("xsi:schemaLocation");
				elem.removeAttribute("xmlns");
				elem.removeAttribute("xmlns:fn");
				importedNode = restructuredDoc.importNode(elem, true);
				break;
			}
		}
		restructuredDoc.appendChild(importedNode);
		return restructuredDoc;
	}

	public static CreditJournalVO createCreditJournalRecord(final String crData, final String transactionId,
			final String userId, final DeDealVO deDeal, final String transType) throws Exception {
		logger.debug("Enter createCreditJournalRecord");

		CreditJournalVO creditJournalVO = new CreditJournalVO();
		String keyId = "";
		List<String> encryptedItems = EncryptionUtils.encryptText(crData);
		keyId = encryptedItems.get(0);
		String encryptedXML = encryptedItems.get(1);
		String auditData = Constants.APP_SUCCESS_MSG_ID + " - " + Constants.OPERATION_SUCCESS_MESSSAGE;

		String deliverySource = ""; // if AD, WC. If RR, CG
		if (deDeal.getDmsId().equalsIgnoreCase(Constants.DMS_AD)) {
			deliverySource = Constants.DELIVERY_SOURCE_AD;
		} else if (deDeal.getDmsId().equalsIgnoreCase(Constants.DMS_RR)) {
			deliverySource = Constants.DELIVERY_SOURCE_RR;
		}

		String applicationSource = ""; // if AD, 0N. If RR, RE
		if (deDeal.getDmsId().equalsIgnoreCase(Constants.DMS_AD)) {
			applicationSource = Constants.APPLICATION_SOURCE_AD;
		} else if (deDeal.getDmsId().equalsIgnoreCase(Constants.DMS_RR)) {
			applicationSource = Constants.APPLICATION_SOURCE_RR;
		}

		creditJournalVO.setSystemId(deDeal.getDmsDealerId());
		creditJournalVO.setDealerId(deDeal.getDmsDealerId());
		creditJournalVO.setPartnerId(deDeal.getLenderId());
		creditJournalVO.setTransDateTime(new Timestamp(System.currentTimeMillis()));
		creditJournalVO.setTransType(transType);
		creditJournalVO.setTransFlag(Constants.TRANS_FLAG_N);
		creditJournalVO.setPartnerDealNo("");
		creditJournalVO.setCrDataXml(encryptedXML);
		creditJournalVO.setAccountId(null);
		creditJournalVO.setTransactionId(transactionId);
		creditJournalVO.setUserId(userId);
		// delivery source
		creditJournalVO.setDeliverySource(deliverySource);
		// application source
		creditJournalVO.setApplicationSource(applicationSource);
		// finance type
		creditJournalVO.setApplType(deDeal.getFinanceType());
		// finance institution
		creditJournalVO.setFinanceInstitution(deDeal.getFinanceType());
		// adp deal no
		creditJournalVO.setAdpDealNo(deDeal.getDmsDealNum());
		// dspid
		creditJournalVO.setDspId(deDeal.getDmsId());
		// sequence no
		creditJournalVO.setSequenceNo("");
		// dealid
		creditJournalVO.setDealId(deDeal.getDeDealId());
		// sequence id
		creditJournalVO.setSequenceId(deDeal.getCvSequenceId());
		//
		creditJournalVO.setAuditData(auditData);
		// keyid
		creditJournalVO.setEncryptionKeyId(keyId);

		return creditJournalVO;
	}

	/**
	 * @param document
	 * @return
	 */
	public static String getRouteOneConversationId(final Document document) {
		logger.debug("Entered getRouteOneConversationId() method of CVUtil class");
		NodeList nodes = document.getElementsByTagName("ApplicationNumber");
		if (null == nodes || nodes.getLength() == 0) {
			return null;
		}
		String conversationId = "";
		String attributeValue = "";

		for (int i = 0; i < nodes.getLength(); i++) {
			if (nodes.item(i) instanceof Element) {
				Element elem = (Element) nodes.item(i);
				attributeValue = elem.getAttribute("desc");
				if (StringUtils.isNotBlank(attributeValue)
						&& attributeValue.equalsIgnoreCase("Retail System Provider")) {
					conversationId = elem.getTextContent();
					break;
				}

			}
		}
		logger.debug("Exit getRouteOneConversationId() method of CVUtil class. conversationId: {}", conversationId);
		return conversationId;
	}

	/**
	 * @param contentToEncode
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public static String calculateMD5(final String contentToEncode) throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("MD5");
		digest.update(contentToEncode.getBytes());
		String result = new String(Base64.encodeBase64(digest.digest()));
		return result;
	}

	/**
	 * @param creditContractVO
	 * @return
	 */
	public static boolean isTestCV(CreditContractVO creditContractVO) {
		if (creditContractVO != null && creditContractVO.getContractValidation() != null
				&& creditContractVO.getContractValidation().getApplicationNumber() != null) {
			String appNum = creditContractVO.getContractValidation().getApplicationNumber();
			if (Constants.TEST_APP_NUM.equalsIgnoreCase(appNum)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param creditContractVO
	 * @param lenderId
	 * @return
	 */
	public static String getDestinationLender(CreditContractVO creditContractVO, String lenderId) {
		if (isTestCV(creditContractVO)) {
			logger.debug("CV is a test (ODETest1234), diverting CV call to MockLenderSystem");
			return Constants.MOCK_LENDER_ID;
		} else {
			return lenderId;
		}
	}

	/**
	 * @param mapOfExpressions
	 * @param listOfXrefsForSubTotal
	 * @return
	 */
	public static Map<String, String> filterOutSubTotalsFromJson(Map<String, ExpressionVO> mapOfExpressions,
			List<DeCdkCloudCvXrefVO> listOfXrefsForSubTotal) {
		logger.debug("Entered extractSubTotalsFromJson() method of CVUtil class");
		Map<String, String> mapOfSubTotals = new HashMap();
		if (null != mapOfExpressions && mapOfExpressions.size() > 0) {
			logger.debug("Here are the contents of Expression Set");
			mapOfExpressions.values().forEach(expressionVO->{
				logger.debug("key:{}, value: {}", expressionVO.getName(), expressionVO.getValue());
			});
			listOfXrefsForSubTotal.stream().forEach(xref -> {
				ExpressionVO subTotalExpressionVO = mapOfExpressions.get(xref.getJsonSourceField());
				if (null != subTotalExpressionVO) {
					if (Constants.EXPR_TOTAL_DOWN_PAYMENT.equals(xref.getJsonSourceField().trim()))
					{
						BigDecimal amount = new BigDecimal(subTotalExpressionVO.getValue());
						if (amount.compareTo(BigDecimal.ZERO) < 0)
						{
							logger.debug("Value of {} received from CDK Clound: {}", xref.getJsonSourceField(), subTotalExpressionVO.getValue());
							subTotalExpressionVO.setValue("0.00");
							logger.debug("Value of {} going out to RouteOne: {}", xref.getJsonSourceField(), subTotalExpressionVO.getValue());
						}
					}
					mapOfSubTotals.put(subTotalExpressionVO.getName(), subTotalExpressionVO.getValue());
				} else {
					logger.debug("Could not find ExpressionVO by looking up: {}", xref.getJsonSourceField());
				}
			});
		}
		logger.debug("Exit extractSubTotalsFromJson() method of CVUtil class. Size of subTotals: {}",
				mapOfSubTotals.size());
		return mapOfSubTotals;
	}

	/**
	 * @param directRenderResponseQueueMessage
	 * @return
	 */
	public static Map<String, ExpressionVO> extractExpressionsFromJson(
			DirectRenderResponseQueueMessageVO directRenderResponseQueueMessage) {
		logger.debug("Entered extractExpressionsFromJson() method of CVUtil class");

		Map<String, ExpressionVO> mapOfExpressions = new HashMap();
		if (directRenderResponseQueueMessage != null
				&& !directRenderResponseQueueMessage.getDirectRenderResponseList().isEmpty()) {

			directRenderResponseQueueMessage.getDirectRenderResponseList().stream().forEach(drrVO -> {
				drrVO.getExpressions().stream().forEach(expVO -> {
					mapOfExpressions.put(expVO.getName(), expVO);
				});
			});
		}
		logger.debug("Exit extractExpressionsFromJson() method of CVUtil class. Size of expressions: {}",
				mapOfExpressions.size());
		return mapOfExpressions;
	}
	
	/**
	 * @param pojo
	 * @return
	 */
	public static String getJsonForObject(final Object pojo) {
		logger.debug("Entered getJsonForObject");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        String content = "";
        try {
            content = mapper.writeValueAsString(pojo);
        } catch (JsonProcessingException e) {
        	logger.error("Error occurred while transforming object to json.", e);
        }
        return content;
    }

	/**
	 * @param appCVEventHandler
	 * @param reResponse
	 * @return
	 */
	public static AppMessage traslateErroCodeToStandardMessage(final ApplpEventHandler appCVEventHandler,
			final ECConfinVO reResponse) {
		logger.debug("Entered traslateErroCodeToStandardMessage() method of CVUtil class");
		AppMessage appMessage = null;
		if (HttpStatus.INTERNAL_SERVER_ERROR.value() == reResponse.getStatusCode()
				|| HttpStatus.NOT_FOUND.value() == reResponse.getStatusCode()) {
			appMessage = appCVEventHandler.handleEvents(Constants.Event_Http_Exception);
		} else if (HttpStatus.UNPROCESSABLE_ENTITY.value() == reResponse.getStatusCode()) {
			appMessage = appCVEventHandler.handleEvents(Constants.Event_Partner_Validation_Exception);
		} else if (3300 == reResponse.getStatusCode()) {
			appMessage = appCVEventHandler.handleEvents(Constants.Event_Partner_Config_Exception);
		} else if (null == reResponse.getStatusMessage() || StringUtils.isNotBlank(reResponse.getStatusMessage())
				&& Constants.Event_Runtime_Exception.equals(reResponse.getStatusMessage())) {
			appMessage = appCVEventHandler.handleEvents(Constants.Event_Runtime_Exception);
		}
		return appMessage;
	}
	
	/**
	 * @param xml
	 * @param element
	 * @return
	 */
	public static String getStringValueFromXmlElement(String xml, String element) {
		String beginElement = "<" + element + ">";
		String endElement = "</" + element + ">";
		int beginIndex = xml.indexOf(beginElement) + beginElement.length();
		int endIndex = xml.indexOf(endElement);
		return xml.substring(beginIndex, endIndex);
	}
	
	public static RouteOneErrorResponse getObjectForRouteOneErrorResponse(String routeOneErrorResponseString) {
		logger.debug("Entered getObjectForRouteOneErrorResponse: {}", routeOneErrorResponseString);
		
		RouteOneErrorResponse routeOneErrorResponse = new RouteOneErrorResponse();
		try {
			routeOneErrorResponse = new ObjectMapper().readValue(routeOneErrorResponseString, RouteOneErrorResponse.class);
		} catch(Exception e) {
			logger.error("Error occured while transforming json string to object.", e);
		}
		
		logger.debug("Object from message: {}", routeOneErrorResponse);
		return routeOneErrorResponse;
	}
	
	/**
	 * R1 Error XML will have a resterror tag that we can look for
	 * 
	 * @param message
	 * @return
	 */
	public static boolean isR1ConfInXml(String message) {
		logger.debug("Entered isR1ConfInXml");
		
		if(message != null && message.toLowerCase().contains(Constants.ROUTEONE_RESTERROR)) {
			logger.debug("true");
			return true;
		}
		
		logger.debug("false");
		return false;
	}
	
	/**
	 * R1 error JSON will NOT have a resterror tag and WILL have a routeOneErrorCode field
	 * 
	 * @param message
	 * @return
	 */
	public static boolean isR1ConfInJson(String message) {
		logger.debug("Entered isR1ConfInXml");
		
		if(message != null && !message.toLowerCase().contains(Constants.ROUTEONE_RESTERROR) && message.toLowerCase().contains(Constants.RESTERROR_ERRORCODE.toLowerCase())) {
			logger.debug("true");
			return true;
		}
		
		logger.debug("false");
		return false;
	}
}