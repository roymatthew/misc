/*
 * Created on Apr 6, 2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author mariappba
 *
 *         To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Style - Code Templates
 */
public interface Constants {
	//	 Application Constant
	public static final String loadConfigContext = "LOADAPPCONFIG";
	public static final String InsertContext = "INSERT";
	public static final String UpdateContext = "UPDATE";
	public static final String SelectContext = "SELECT";
	public static final String CmfNumber_String = "CMFNUMBER";
	public static final String Partner_Account_Id_String = "Partner_Account_Id";
	public static final String Event_Success = "Success";
	public static final String Event_Runtime_Exception = "AppException";
	public static final String Event_Http_Exception = "AppHttpException";
	public static final String Event_Partner_Validation_Exception = "PartnerValidationException";
	public static final String Event_Partner_Config_Exception = "PartnerConfigurationException";
	public static final String Transaction_Started = "TransactionStarted";
	public static final String Transaction_Ended = "TransactionEnded";
	public static final String Process_Started = "ProcessStarted";
	public static final String Process_Ended = "ProcessEnded";
	public static final String Process_Info = "ProcessInfo";
	public static final String Dealer_Id = "Dealer_Id";
	public static final String System_Id = "System_Id";
	public static final String APP_SUCCESS_MSG_ID = "I0000";
	public static final String XPath_LenderId = "XPath_LenderId";
	public static final String XPath_CreatorNameCode = "XPath_CreatorNameCode";
	public static final String XPath_UserId = "XPath_UserId";
	public static final String XPath_ContractValidation_LenderId = "XPath_ContractValidation_LenderId";
	public static final String XPath_ContractValidation_CreatorNameCode = "XPath_ContractValidation_CreatorNameCode";
	public static final String XPath_ContractValidation_UserId = "XPath_ContractValidation_UserId";

	// -- Dealer/Lender Validation
	public static final String TRANS_TYPE_VALDAT = "VALDAT";

	public static final String SSN_ENCODING_TYPE = "ISO-8859-1";

	public static final String LP_PRODUCT_TYPE_CREDIT_APPLICATION = "CA";
	public static final String LP_PRODUCT_TYPE_CREDIT_APPLICATION_RESPONSE = "ApplicationResponse";
	public static final String LP_PRODUCT_TYPE_CONTRACT_VALIDATION = "CV";
	public static final String LP_PRODUCT_TYPE_CONTRACT_VALIDATION_RESPONSE = "ValidationResponse";
	public static final String LP_PRODUCT_TYPE_CONTRACT_DISTRIBUTION = "eDoc";
	public static final String LENDER_VCF = "VCF";
	public static final String LENDER_VOL = "VOL";

	// -- Credit Application Transaction Types
	public static final String TRANS_TYPE_APP_IN = "APPIN"; // -- Incoming Messages
	public static final String TRANS_TYPE_APP_OUT = "APPOUT"; // -- Outgoing Messages
	public static final String TRANS_TYPE_APP_CONF_IN = "APPCONFIN"; // -- Confirmation Received
	public static final String TRANS_TYPE_APP_CONF_OUT = "APPCONFOUT"; // -- Confirmation Sent
	public static final String TRANS_TYPE_APP_CONF_IN2 = "APPCONFIN2"; // -- Confirmation Received 2
	public static final String TRANS_TYPE_APP_CONF_OUT2 = "APPCONFOUT2"; // -- Confirmation Sent 2
	public static final List<String> APP_TRANS_TYPES = new ArrayList<String>(
			Arrays.asList(TRANS_TYPE_APP_IN, TRANS_TYPE_APP_OUT, TRANS_TYPE_APP_CONF_IN, TRANS_TYPE_APP_CONF_OUT,
					TRANS_TYPE_APP_CONF_IN2, TRANS_TYPE_APP_CONF_OUT2));

	// -- Insert Deal Transaction Types
	public static final String TRANS_TYPE_ID_IN = "IDIN"; // -- Incoming Messages
	public static final String TRANS_TYPE_ID_OUT = "IDOUT"; // -- Outgoing Messages
	public static final String TRANS_TYPE_ID_CONF_IN = "IDCONFIN"; // -- Synchronous Confirmation Received
	public static final String TRANS_TYPE_ID_CONF_OUT = "IDCONFOUT"; // -- Synchronous Confirmation Sent
	public static final List<String> ID_TRANS_TYPES = new ArrayList<String>(
			Arrays.asList(TRANS_TYPE_ID_IN, TRANS_TYPE_ID_OUT, TRANS_TYPE_ID_CONF_IN, TRANS_TYPE_ID_CONF_OUT));

	// -- Credit Decision Transaction Types
	public static final String TRANS_TYPE_DEC_IN = "DECIN"; // -- Incoming Messages
	public static final String TRANS_TYPE_DEC_OUT = "DECOUT"; // -- Outgoing Messages
	public static final String TRANS_TYPE_DEC_CONF_IN = "DECCONFIN"; // -- Confirmation Received
	public static final String TRANS_TYPE_DEC_CONF_OUT = "DECCONFOUT"; // -- Confirmation Sent
	public static final List<String> DEC_TRANS_TYPES = new ArrayList<String>(
			Arrays.asList(TRANS_TYPE_DEC_IN, TRANS_TYPE_DEC_OUT, TRANS_TYPE_DEC_CONF_IN, TRANS_TYPE_DEC_CONF_OUT));

	// -- Credit Contract Transaction Types
	public static final String TRANS_TYPE_EC_IN = "ECIN"; // -- Incoming Contract Messages from ADP Credit
	public static final String TRANS_TYPE_EC_OUT = "ECOUT"; // -- Outgoing Messages to Finance Partner
	public static final String TRANS_TYPE_CV_EC_IN = "CV-ECIN"; // --Incoming CV transaction from LP
	public static final String TRANS_TYPE_CV_EC_OUT = "CV-ECOUT"; // -- Outgoing messages to Finance Partner from CV
	// Module
	public static final String TRANS_TYPE_CV_OLDRE_ECOUT = "CV-OLDRE-ECOUT"; // -- Outgoing messages to RE from CV
	public static final String TRANS_TYPE_EC_OUT2 = "ECOUT2"; // -- Outgoing Message to lender partner (RouteOne)
	public static final String TRANS_TYPE_EC_OUT3 = "ECOUT3"; // -- Outgoing Message to lender partner (RouteOne) with
	// sub totals from CDK CLoud.
	public static final String TRANS_TYPE_LTE_CONFIRM_BOD = "LTECBOD"; // Incoming ConfirmBOD from LTE
	public static final String TRANS_TYPE_CV_OLDRE_ECACKIN = "CV-OLDRE-ACCR";	// Incoming ConfirmBOD from RE

	public static final String TRANS_TYPE_EC_IN_WITH_ATTACHMENT = "ECEDOCIN"; // -- Incoming Contract Messages with
	// Attachment from RR
	public static final String TRANS_TYPE_EC_OUT_WITH_ATTACHMENT = "ECEDOCOUT"; // -- Incoming Contract Messages with
	// Attachment from RR
	public static final String TRANS_TYPE_EC_TRANS = "ECTRANS"; // -- Internal translation using database values
	public static final String TRANS_TYPE_EC_CONF_IN = "ECCONFIN"; // -- ConfBOD from Finance Partner
	public static final String TRANS_TYPE_EC_CONF_IN2 = "ECCONFIN2"; // -- Async ConfBOD from Finance Partner
	public static final String TRANS_TYPE_EC_CONF_OUT = "ECCONFOUT"; // -- ConfBOD sent to ADP Credit
	public static final String TRANS_TYPE_EC_CONF_OUT2 = "ECCONFOUT2";// --Async ConfBOD sent to ADP Credit
	public static final String TRANS_TYPE_EC_ACK_IN = "ECACKIN"; // -- AcknowledgeCreditContract message from Finance
	// Partner
	public static final String TRANS_TYPE_EC_ACK_OUT = "ECACKOUT";// -- AcknowledgeCreditContract message sent to ADP
	// Credit
	public static final String TRANS_TYPE_EC_ACK_CONF_IN = "ECACKCONFIN";// ConfirmBOD received from DMS for
	// AcknowledgeCreditContract
	public static final String TRANS_TYPE_EC_ACK_CONF_OUT = "ECACKCONFOUT";// ConfirmBOD sent to Lender from ADP Credit
	// for AcknowledgeCreditContract
	public static final String TRANS_TYPE_CV_CLOUDQIN = "CV-CLOUDQIN"; // Json message posted by CDK Cloud Service to
	// the CDK Cloud Response Queue
	public static final String TRANS_TYPE_CV_CLOUDQOUT = "CV-CLOUDQOUT"; // Json message posted by CV to
	// the CDK Cloud Response Queue

	public static final List<String> EC_TRANS_TYPES = new ArrayList<String>(Arrays.asList(TRANS_TYPE_EC_IN,
			TRANS_TYPE_EC_OUT, TRANS_TYPE_EC_TRANS, TRANS_TYPE_EC_CONF_IN, TRANS_TYPE_EC_CONF_OUT, TRANS_TYPE_EC_ACK_IN,
			TRANS_TYPE_EC_ACK_OUT, TRANS_TYPE_EC_ACK_CONF_IN, TRANS_TYPE_EC_ACK_CONF_OUT));

	// -- Distribution Transaction Types
	public static final String TRANS_TYPE_EDOC_IN = "EDOCIN"; // -- Incoming Distribution (to eDocs application)
	public static final String TRANS_TYPE_EDOC_OUT = "EDOCOUT"; // -- Outgoing Distribution (from eDocs application)
	public static final List<String> EDOC_TRANS_TYPES = new ArrayList<String>(
			Arrays.asList(TRANS_TYPE_EDOC_IN, TRANS_TYPE_EC_IN_WITH_ATTACHMENT, TRANS_TYPE_EC_OUT_WITH_ATTACHMENT));

	// -- Vault Transaction Types
	public static final String TRANS_TYPE_VAULT_ACCEPT_REQUEST = "ECARQ";
	public static final String TRANS_TYPE_VAULT_ACCEPT_RESPONSE = "ECARS";
	public static final String TRANS_TYPE_VAULT_REJECT_REQUEST = "ECRRQ";
	public static final String TRANS_TYPE_VAULT_REJECT_RESPONSE = "ECRRS";
	public static final String TRANS_TYPE_VAULT_SEARCH_REQUEST = "ECSRQ";
	public static final String TRANS_TYPE_VAULT_SEARCH_RESPONSE = "ECSRS";

	// -- Vault response codes
	public static final String VAULT_ACCEPT_SUCCESSFUL = "I0700";
	public static final String VAULT_REJECT_SUCCESSFUL = "I0800";
	public static final String VAULT_SEARCH_SUCCESSFUL = "I0400";
	public static final String VAULT_LOGIN_SUCCESSFUL = "I0100";
	public static final String VAULT_LOGOUT_SUCCESSFUL = "I0200";

	// -- Billing Transaction Types
	public static final String TRANS_TYPE_BILLING_APP = "CGAP";
	public static final String TRANS_TYPE_BILLING_DEC = "CGDE";
	public static final String TRANS_TYPE_BILLING_EC = "CGEC";
	public static final String TRANS_TYPE_BILLING_CB = "CGCB";
	public static final String TRANS_TYPE_BILLING_CC = "CGCC";

	public static final String IS_SYNC = "IS_SYNC";
	public static final String ASYNCHRONOUS_PROCESS = "asyn";
	public static final String SYNCHRONOUS_PROCESS = "syn";

	// -- Credit Contract Transaction Types
	public static final String TRANS_TYPE_CCS_IN = "CCSIN"; // -- Incoming Messages
	public static final String TRANS_TYPE_CCS_OUT = "CCSOUT"; // -- Outgoing Messages
	public static final String TRANS_TYPE_CCS_CONF_IN = "CCSCONFIN"; // -- Confirmation Received
	public static final String TRANS_TYPE_CCS_CONF_OUT = "CCSCONFOUT"; // -- Confirmation Sent

	// -- Text Message

	public static final String TRANS_TYPE_TXM_IN = "DLRCMTIN";
	public static final String TRANS_TYPE_TXM_OUT = "DLRCMTOUT";

	public static final String TRANS_TYPE_TXMLNDR_IN = "LNDRCMTIN";
	public static final String TRANS_TYPE_TXMLNDR_OUT = "LNDRCMTOUT";

	public SimpleDateFormat dfWithT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	public SimpleDateFormat STAR_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

	public static final String FAULT_STRING = "faultstring";

	public static final String FAULT_CODE = "faultcode";

	public static final String DETAIL = "detail";

	public static final String DEFAULT_STATUS = "Pending";

	public static final String MBFVALIDATION_CONSTANT = "https://mbfevaluate-stage.fs-nafta.daimler.com:443/MBFEvaluate/DSP/validationservice: cvc-simple-type 1: element {http://www.starstandards.org/STAR}";

	public static final String MBF_ACCOUNT_NUMBER_PREFIX_TEXT = "Agreement Number for this Contract is";

	public static final String MBF_SEQUENCE_NUMBER_PREFIX_TEXT = "The sequence number is";

	public static final long numberOfAttempt = 1;

	public static final String REPL = "REPL";
	public static final String GETLENDER = "GETLENDER";

	public static final String EQUAL = "=";

	public static final String BLANK = "";
	public static final String SPACE = " ";
	public static final String COMMA = ",";
	public static final String OPEN_PAREN = "(";
	public static final String CLOSE_PAREN = ")";
	public static final String AND = "and";
	public static final String OR = "or";
	public static final String IS_NULL = "IS NULL";
	public static final String LESS_THAN_OR_EQUAL_TO = "<=";
	public static final String SECONDS = "seconds";
	public static final String MINUTES = "minutes";
	public static final String GUID = "GUID";
	public static final String DOCID = "DOCID";
	public static final String ALL = "ALL";
	public static final String UNHANDLED_LP_EXCEPTION = "E9999";
	public static final String[] UNHANDLED_LP_EXCEPTION_MESSAGE = new String[] { "Unhandled Exception" };
	public static final String SOAP_FAULT_RECEIVED = "E2200";
	public static final String[] SOAP_FAULT_RECEIVED_MESSAGE = new String[] { "SOAP Fault" };
	public static final String constantXpath = "/payload/content";
	public static final String constantXpath_rules = "/Envelope/Body/ProcessMessageResponse/payload/content";
	public static final String ecoutUpdate = "CreditContractResponse";
	public static final String transformerFactory = "net.sf.saxon.TransformerFactoryImpl";
	public static final String saxon = "saxon";
	public static final String DEC_OUT_ONLY = "decOutOnly";
	public static final String DEC_IN_ONLY = "decInOnly";
	public static final String PERSIST_DEC = "persistDecision";
	public static final String CV_OR_CA_PRODUCT = "CVorCAProduct";
	public static final String OPERATION_SUCCESS_MESSSAGE = "Operation Successful";
	public static final String OPERATION_FAILED_MESSSAGE = "Operation Failure";

	// -- Application Types
	public static final String APPTYPE_INDIVIDUAL = "IN";
	public static final String APPTYPE_INDIVIDUAL_COBUYER = "IC";
	public static final String APPTYPE_BUSINESS = "BU";
	public static final String APPTYPE_BUSINESS_COBUYER = "BC";
	public static final String APPTYPE_BUSINESS_GUARANTOR = "BG";

	// -- XML Normalizer constants
	public static final String CONTAINS_CONDITION = "contains";
	public static final String NOT_CONTAINS_CONDITIONS = "not contains";
	public static final String STARTS_WITH_CONDITION = "starts with";
	public static final String NOT_STARTS_WITH_CONDITION = "not starts with";
	public static final String EQUALS_CONDITION = "equals";
	public static final String NOT_EQUALS_CONDITION = "not equals";

	// -- Insert Deal constants
	public static final String REGEX_REMOVE_XML_TAG = "<\\?xml .*?\\?>";
	public static final String CREDIT_APP_UPDATE_JSON_BODY_START = "{\"status\": \"Submitted\",\"financeProvider\": \"";
	public static final String CREDIT_APP_UPDATE_JSON_BODY_END = "\"}";
	public static final String DEALER_ID_HEADER = "X-DEALER-ID";
	public static final String SYSTEM_ID_HEADER = "X-SYSTEM-ID";
	public static final String CONTENT_TYPE_HEADER = "Content-Type";
	public static final String JSON_CONTENT_TYPE_HEADER = "application/json";
	public static final String CREDIT_APP_UPDATE_DEST_ID = "AD-CreditAppUpdate";
	public static final String APPLICATION_TAG_START = "<application>";
	public static final String APPLICATION_TAG_END = "</application>";

	// -- Auto Re-Cv constants
	public static final String RE_CV_DELAY = "autoReCvDelay";
	public static final String RE_CV_KEY_TERM1 = "we are unable to process this deal";
	public static final String RE_CV_KEY_TERM2 = "structure";
	public static final String RE_CV_KEY_TERM3 = "customer information";
	public static final String RE_CV_KEY_TERM4 = "collateral";
	public static final String RE_CV_KEY_TERM5 = "truth in lending";
	public static final String DELAYED_QUEUE_DELIVER_PROPERTY = "_DeliverAfter_";
	public static final String RE_CV_ECACKOUT_MESSAGE_START = "Your Relationship Manager is working on this deal.  Please wait ";
	public static final String RE_CV_ECACKOUT_MESSAGE_END = " for an update";
	public static final String EDOCS_INVALID_FILE = "invalidFile";
	public static final String EDOCS_FILE_INVALID_ERROR_MESSAGE1 = " file exceeds the required limit of ";
	public static final String EDOCS_FILE_INVALID_ERROR_MESSAGE2 = " MB. Please rescan and resend the document within limits.";
	public static final String EDOCS_FILE_INVALID_FILE_RESOLUTION1 = " does not meet the minimum resolution of ";
	public static final String EDOCS_FILE_INVALID_FILE_RESOLUTION2 = "dpi. Please rescan the document and resend the Digital Deal Jacket.";
	public static final String ATTACHMENT_DATA_ELEMENT = "attachmentData";
	public static final String XML_HEADER_REGEX = "\\<\\?xml(.+?)\\?\\>";
	public static final String EDOCS_ATTACHMENT_LOCATION_MESSAGE = " Retrieved and stored the zip file under file system";
	public static final String EDOCS_FILE_EXTENSION_PDF = ".pdf";
	public static final String CV_PCC_CONTENT_ELEMENT = "content";
	public static final String EDOCS_ATTACHMENT_CONTENT_ELEMENT = "content1";
	public static final String EDOCS_PCC_CONTENT_ELEMENT_ATTRIBUTE_ID = "id";
	public static final String EDOCS_PCC_FUNDING_STATUS_RECEIVED = "RECEIVED";
	public static final String EDOCS_PCC_FUNDING_STATUS_REJECTED = "REJECTED";
	public static final String EDOCS_PCC_FUNDING_STATUS_HELD = "HELD";
	public static final String EDOCS_PCC_FUNDING_STATUS_BOOKED = "BOOKED";
	public static final String EDOCS_PCC_FUNDING_STATUS_ACCEPTED = "ACCEPTED";

	public static final String ACCR_VALIDATION_MESSAGE_REASON_CODE_00001 = "00001";
	public static final String ACCR_SPOT_APPLICATION_NUMBER = "SPOT000000000";
	public static final String SPOT_FLAG_YES = "Y";
	public static final String SPOT_FLAG_NO = "N";

	// STAR constants
	public static final String STAR_TAG_TAX = "Tax";
	public static final String STAR_TAG_FEE = "Fee";
	public static final String STAR_TAG_DEALER_PRODUCTS = "DealerProducts";
	public static final String STAR_TAG_SERVICE_CONTRACT = "ServiceContract";
	public static final String STAR_TAG_INSURANCE = "Insurance";
	public static final Object STAR_TAG_OTHER_CHARGES = "OtherCharges";
	public static final String STAR_PRODUCT_TYPE_ONE_PAY = "O";
	public static final String STAR_PRODUCT_TYPE_STANDARD_PAY = "S";
	public static final String STAR_CAP_IND_CAP = "1";
	public static final String STAR_CAP_IND_UPF = "0";
	public static final String STAR_TAX_TYPE_TOTAL_MONTHLY_USE = "Total Monthly/Use";
	public static final String STAR_TAX_TYPE_MONTHLY_USE = "Monthly/Use";
	public static final String STAR_FINANCE_TYPE_LEASE = "L";
	public static final String STAR_FINANCE_TYPE_RETAIL = "R";

	// Messages for http codes
	public static final String MESSAGE_FOR_HTTP_CODE_100 = "Informational";
	public static final String MESSAGE_FOR_HTTP_CODE_200 = "Success";
	public static final String MESSAGE_FOR_HTTP_CODE_300 = "Redirection";
	public static final String MESSAGE_FOR_HTTP_CODE_400 = "Client Error";
	public static final String MESSAGE_FOR_HTTP_CODE_500 = "Server Error";

	// ACCR
	public static final String VALID = "Valid";
	public static final String PASSED = "Passed";
	public static final String FAILED = "Failed";

	public static final String REPLACE_EXISTING_CONTRACT_YES = "Yes";
	public static final String ECONTRACT_STATUS_ASSIGNED = "Assigned";
	public static final String ECONTRACT_STATUS_BOOKED = "Booked";
	public static final String ECONTRACT_ERROR_CODE_ASSIGNED = "EC001";
	public static final String ECONTRACT_ERROR_CODE_BOOKED = "EC002";
	public static final String ECONTRACT_ERROR_CODE_SIGNED = "EC003";
	public static final String ECONTRACT_ERROR_MESSAGE_SIGNED = "An eContract already exists in the vault for this deal. If you want to re-Validate or replace the original contract, please void the original eContract.";
	public static final String ECONTRACT_ERROR_MESSAGE_ASSIGNED = "A contract has already been sent to lender for funding.  Contact lender to reject the contract.";
	public static final String ECONTRACT_ERROR_MESSAGE_BOOKED = "A contract has already been booked.  Contract Validation is no longer available.";

	public static final String DISTRIBUTION_ERROR_CODE = "DS001";
	public static final String DISTRIBUTION_ERROR_MESSAGE = "There is no eContract currently Assigned for this deal. Please Assign the eContract and resend eDocs.";
	public static final String INTERNAL_RE_SENDERNAMECODE = "OD";

	// VCI to Deal Exchange
	public static final List<String> VCI_LENDER_IDS = new ArrayList<String>(Arrays.asList("VCI", "AFS", "BFS"));
	public static final String DESTINATION_ID_EDOCS = "eDocs";
	public static final String DESTINATION_ID_RFLUPDATES = "RFLUpdates";
	public static final String STYLESHEET_ID_EDOCS = "eDocs";
	public static final String STYLESHEET_ID_RFLUPDATES = "RFLUpdates";
	public static final String RULES_ENGINE_DESTINATION_ID = "RULES";

	public static final List<String> REYNOLDS_DSP_IDS = new ArrayList<String>(Arrays.asList("RE", "RP"));
	public static final List<String> CDK_DSP_IDS = new ArrayList<String>(Arrays.asList("AD", "CDK"));
	public static final String REYNOLDS_DMS_ID = "RR";
	public static final String CDK_DMS_ID = "AD";
	public static final String MOCK_LENDER_ID = "MOCK";

	public static final String TEST_APP_NUM = "ODETest1234";

	// FundingAutomation / FromPF
	public static final String FUNDING_AUTOMATION_1 = "1";
	public static final String FUNDING_AUTOMATION_0 = "0";
	public static final String FROM_PF_YES = "Y";
	public static final String FROM_PF_NO = "N";
	public static final String BLOCK_NON_PF_CV_ERROR_CODE = "E-PF100";
	public static final String BLOCK_NON_PF_CV_ERROR_MESSAGE = "A contract already exists. If the deal has changed and you would like to create a new contract, you will need to print again in the PF window.";
	public static final List<String> CV_STATUSES_PASSED = new ArrayList<String>(Arrays.asList("Valid", "Passed"));

	// CA Statuses
	public static final String CA_STATUS_RECEIVED = "Received";
	public static final String CA_STATUS_SUBMITTED = "Submitted";
	public static final String CV_DESTINATION_PRODUCT_ID = "RULES";
	public static final String APP_CV_CODE = "CV";

	// Keystores
	// TODO: make this sendMsgToDestinationWithTwoWaySSL reusable for lenders other
	// than CHASE:
	// these values need to be externally configurable on a per lender basis.
	public static String TRUST_KEY_STORE_TYPE = "JKS";
	public static String TRUST_KEY_STORE_FILE = "/data/ode/keystores/trust_keystore.jks";
	public static String TRUST_KEY_STORE_PASS = "password";
	public static String CERT_ALIAS = "chase.stage.opendlrex.com";
	public static String IDENTITY_KEY_STORE_TYPE = "JKS";
	public static String IDENTITY_KEY_STORE_FILE = "/data/ode/keystores/identity_keystore.jks";
	public static String IDENTITY_KEY_STORE_PASS = "ode123";

	public static String RULES_ENGINE_SUCESS_MESSAGE = "<response>Success</response>";
	public static String CONFIRM_BOD = "ConfirmBOD";
	public static String RESPONSE_MESSAGE_DEAL_NOT_FOUND = "Deal information not found";
	public static String RESPONSE_MESSAGE_LENDER_NOT_FOUND = "Lender information not found";
	public static String LENDER_RESPONSE_ACCR = "AcknowledgeCreditContractResponse";

	public static final String[] HTTP_SUCCESS_CODES = new String[] { "200", "202" };

	// RouteOne
	public final static String HMAC_SHA256_ALGORITHM = "HmacSHA256";
	public final static String DATE_FORMAT = "EEE, dd MMM yyyy HH:mm:ss zzz";
	// public final static String ROUTE_ONE_DEALER_ID = "QJ5XL";
	// public final static String ROUTE_ONE_USER_ID = "gmuser";
	// public final static String ROUTE_ONE_EMAIL_ID = "gmuser@cdkdealer.com";
	// public final static String ROUTE_ONE_FIRST_NAME = "john";
	// public final static String ROUTE_ONE_LAST_NAME = "foo";
	// public final static String AUTH_ACCESS_KEY = "RouteOne F00ODE";
	public final static String MESSAGE_DIGEST_MD5 = "MD5";

	// public final static String HEADER_DEALER_ID = "X-RouteOne-Act-As-Dealership";
	// public final static String HEADER_USER_ID = "X-RouteOne-Audit-User-ID";
	// public final static String HEADER_EMAIL_ID = "X-RouteOne-Audit-User-Email";
	// public final static String HEADER_FIRST_NAME =
	// "X-RouteOne-Audit-User-FirstName";
	// public final static String HEADER_LAST_NAME =
	// "X-RouteOne-Audit-User-LastName";
	public final static String HEADER_DATE_LABEL = "Date";
	public final static String HEADER_AUTH_LABEL = "Authorization";
	public final static String HEADER_DIGEST_LABEL = "Content-MD5";
	public final static String HEADER_CONTENT_LABEL = "Content-Type";

	public final static String HEADER_CONTRACT_ID = "ContractId";
	public final static String HEADER_CONTRACT_TYPE = "ContractType";
	public final static String HEADER_PARTNER_FSID = "PartnerFSID";

	public static final String URL_APPENDAGE_VALIDATE = "validate";
	public static final String DISTRIBUTE_FAILURE_CODE = "E9090";
	public static final String DISTRIBUTION_STATUS_LENDER_FAILURE = "Lender Failure";
	public static final String PRODUCT_CV = "CV";
	public static final String PRODUCT_RE = "RE";
	public static final String PRODUCT_WEBSVC = "WEBSVC";
	public static final String ROUTEONE_PARTNER = "RO";
	public static final String APPLICATION_CV = "CV";
	public static final String LENDER_DESTINATION_FAILURE_CODE = "E9097";
	public static final String FILE_EXTN_PDF = ".pdf";
	public static final String FEATURE_CONFIG_EDOCS_DISTRIBUTION = "eDocsDistribution";
	public static final String STATIC_RFL_FLAG = "SRFL";
	public static final String ADVENT_DMS_ID = "AR";
	public static final Object UNDER_SCORE = "_";
	public static final String LTE_ENDPOINT = "LTE_ENDPOINT";
	public static final String RE_ENDPOINT = "RE_ENDPOINT";
	public static final String RE_LENDERS = "RE_LENDERS";
	public static final String CDK_ECACKOUT_ENDPOINT_PROPS = "CDK_ECACKOUT_ENDPOINT";
	public static final String RR_ECACKOUT_ENDPOINT_PROPS = "RR_ECACKOUT_ENDPOINT";

	public static final String APPLICATION_AREA_ELEM = "ApplicationArea";
	public static final String DATA_AREA_ELEM = "DataArea";
	public static final String SENDER_ELEM = "Sender";
	public static final String CREDIT_CONTRACT_ELEM = "CreditContract";
	public static final String CREDIT_CONTRACT_RESPONSE_ELEM = "CreditContractResponse";
	public static final String HEADER_ELEM = "Header";
	public static final String DESTINATION_CODE_ROUTE_ONE = "RO";
	public static final String DESTINATION_CODE_VCF = "VCF";
	public static final String PIPE = "|";
	public static final String ROUTE_ONE_DEALERID_PARM_NAME = "ACCOUNTID1";
	public static final String ACCOUNT_ID = "accountId";

	public static final String DMS_AD = "AD";
	public static final String DMS_RR = "RR";
	public static final String TRANS_FLAG_N = "N";

	public static final String AUTH_TYPE_LDAP = "LDAP";
	public static final String AUTH_HEADER_TYPE_BASIC = "Basic ";
	public static final String AUTH_TYPE_OAUTH2 = "OAuth2";
	public static final String AUTH_HEADER_TYPE_BEARER = "Bearer ";
	public static final String HEADER_COOKIE_LABEL = "Cookie";

	public static final String CDKCLOUD_RESPONSE_QUEUE_EMPTY_DR_CODE = "E9670";
	public static final String CDKCLOUD_RESPONSE_QUEUE_EMPTY_DR_MESSAGE = "Direct Render response from CDK Cloud is empty upon entering CV.";

	public static final String CDKCLOUD_RESPONSE_QUEUE_ERROR_CODE = "E9660";
	public static final String CDKCLOUD_RESPONSE_QUEUE_ERROR_MESSAGE = "Error occured while processing CDK Cloud Response Queue message.";

	public static final String RFL_OTHER_FORM_DB_ERROR_CODE = "E9820";
	public static final String RFL_OTHER_FORM_DB_ERROR_MSG = "Error while saving Other Form Type RFL info to table.";

	public static final String RFL_OTHER_FORM_PROC_ERROR_CODE = "E9810";
	public static final String RFL_OTHER_FORM_PROC_ERROR_MSG = "Error while processing Other Form Type RFL's.";

	public static final String RFL_V1_PROC_ERROR_CODE = "E9811";
	public static final String RFL_V1_PROC_ERROR_MSG = "Error while processing RFLv1 forms on ACCR.";

	public static final String RFL_V2_PROC_ERROR_CODE = "E9812";
	public static final String RFL_V2_PROC_ERROR_MSG = "Error while processing RFLv2 forms on ACCR.";

	public static final String RFL_V3_PROC_ERROR_CODE = "E9813";
	public static final String RFL_V3_PROC_ERROR_MSG = "Error while processing RFLv3 forms on ACCR.";

	public static final String RFL_V4_PROC_ERROR_CODE = "E9814";
	public static final String RFL_V4_PROC_ERROR_MSG = "Error while processing RFLv4 forms on ACCR.";

	public static final String RFL_V5_PROC_ERROR_CODE = "E9815";
	public static final String RFL_V5_PROC_ERROR_MSG = "Error while processing RFLv5 forms on ACCR.";

	//RFL Constants
	public static final String OTHER_DOC_TYPE_PREFIX = "007";

	// Source Constants
	public static final String DELIVERY_SOURCE_AD = "WC";
	public static final String DELIVERY_SOURCE_RR = "CG";
	public static final String APPLICATION_SOURCE_AD = "0N";
	public static final String APPLICATION_SOURCE_RR = "RE";

	public static final String COMMON_SERVICE_URL_PROP_NAME = "commonServiceUrl";
	public static final String COMMON_SERVICE_CLOUD_FLAG_URL_APPEND = "/cdkCloudFlag";
	public static final String VAULTWS_PROP_APP_NAME = "VaultWS";

	public static final String COMMON_SERVICE_STANDARD_FLAG_URL_APPEND = "/standardDSPFlag";

	// File System Constants
	public final static String CONTRACT_PDF_DIRECTORY = "/data/ode/cdkcloudservice/pdf/";
	public static final String SECURE_TRANSMISSION = "SecureTransmission";
	public static final String CLIENT_CERT = "ClientCert";
	public static final String PROTOCOL_VERSION = "Protocol";
	public static final String JKS_FORMAT = "JKS";
	public static final String PASSWORD_TEXT = "password";
	public static final String XML_PROLOG = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	public static final String PARM_NAME_FIN_COMP_PARTY_ID = "financeCompanyPartyId";
	public static final String EXPR_TOTAL_DOWN_PAYMENT = "TotalDownPaymentAmountExp";

	public static final String HTTP_HEADERS_SOAP_ACTION_LABEL = "SOAPAction";
	public static final String HTTP_HEADERS_CONTENT_TYPE_LABEL = "Content-Type";


	/**
	 * Web Service headers for Lenders
	 */
	public static final String SOAP_HEADER_MSG_LANG_CODE = "MessageLanguageCode";
	public static final String SOAP_HEADER_SENDER_ID = "SenderID";
	public static final String SOAP_HEADER_TARGET_ID = "TargetID";
	public static final String SOAP_HEADER_MESSAGE_TYPE = "MessageType";
	public static final String SOAP_HEADER_FA_SVC_CNTRL = "h:FASServiceControl";
	public static final String SOAP_HEADER_SENT_TS = "SentTimeStamp";
	public static final String SOAP_HEADER_CORRELATION_ID = "CorrelationID";
	public static final String TAG_NAME_SOAP_BODY = "soap:Body";
	public static final String TAG_NAME_PUT_REQUEST = "PutRequest";
	public static final String TAG_NAME_PAYLOAD_MANIFEST = "payloadManifest";
	public static final String TAG_NAME_PROCESS_MESSAGE = "ProcessMessage";
	public static final String TAG_NAME_PCC = "ProcessCreditContract";
	public static final String NS_PREFIX_XMLNS_NAME = "xmlns";
	public static final String PUT_REQUEST_XMLNS = "PutRequestXmlns";
	public static final String NS_PREFIX_XMLNS_H_NAME = "xmlns:h";
	public static final String NS_XMLNS_H_VALUE = "urn:com:Fiserv:AutoSolutions:2008:07";
	public static final String NS_PREFIX_XMLNS_XSD_NAME = "xmlns:xsd";
	public static final String NS_XMLNS_XSD_VALUE = "http://www.w3.org/2001/XMLSchema";
	public static final String NS_PREFIX_XMLNS_XSI_NAME = "xmlns:xsi";
	public static final String NS_XMLNS_XSI_VALUE = "http://www.w3.org/2001/XMLSchema-instance";

	/**
	 * RESTError Elements
	 */
	public static final String ROUTEONE_RESTERROR = "resterror";
	public static final String RESTERROR_ERRORCODE = "routeOneErrorCode";
	public static final String RESTERROR_ERRORMESSAGE = "errorMessage";
	public static final String RESTERROR_DEVELOPERMESSAGE = "developerMessage";

	public static final String MESSAGE_FORMAT_JSON = "json";
	public static final String MESSAGE_FORMAT_XML = "xml";

	/**
	 * Database Constants
	 */
	public static final String STYLESHEET = "stylesheet";
	public static final String ACCR = "ACCR";
	public static final String CONFIRMBOD = "confirmbod";
	public static final String SERVICE_ID = "serviceId";
	public static final String LOCATION_ID = "locationId";
	
	/* GCV Product Translations */
	public static final String GCV_CASH_PRICE_INCLUSION_TAG_NAME = "CashPriceInclusion";
	public static final String GCV_CASH_PRICE_INCLUSION_TYPE_TOTAL = "Total";
	public static final String GCV_OPTION_DISCLOSURE_OTHER = "Other";
	
}