/**
 * 
 */
package com.ode.cv.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.message.BasicHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ode.persistence.vo.DePartnerDestinationVO;

/**
 * @author snimma
 *
 */
public class HttpTransmitUtil {

	private static final Logger logger = LogManager.getLogger(HttpTransmitUtil.class);

	private HttpTransmitUtil() {
	}

	/**
	 * @param key
	 * @param data
	 * @return
	 */
	public static String calculateHMAC(final String key, final String data) {
		logger.debug("Entered calculateHMAC() method of HttpTransmitUtil class. key: " + key);
		Mac hMacSHA256;
		byte[] res = null;

		try {
			hMacSHA256 = Mac.getInstance(Constants.HMAC_SHA256_ALGORITHM);
			byte[] hmacKeyBytes = key.getBytes();
			final SecretKeySpec secretKey = new SecretKeySpec(hmacKeyBytes, Constants.HMAC_SHA256_ALGORITHM);
			hMacSHA256.init(secretKey);
			byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
			res = hMacSHA256.doFinal(dataBytes);
		} catch (Exception e) {
			logger.error("Error encountered while calculating HMAC", e);
		}

		return Base64.encodeBase64String(res);
		//return Base64.getEncoder().encodeToString(res);
	}

	/**
	 * @param contentToEncode
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public static String calculateMD5(String contentToEncode) throws NoSuchAlgorithmException {
		logger.debug("Entered calculateMD5()");
		MessageDigest digest = MessageDigest.getInstance(Constants.MESSAGE_DIGEST_MD5);
		digest.update(contentToEncode.getBytes());
		String result = new String(Base64.encodeBase64(digest.digest()));
		logger.debug("contentMd5 after calculateMD5 is : " + result);
		return result;
	}

	public static String getCurrentDate() {
		return new SimpleDateFormat(Constants.DATE_FORMAT).format(new Date());
	}

	public static String getFinalRouteOneURL(String baseURL, String contractId) {
		return baseURL + contractId + Constants.URL_APPENDAGE_VALIDATE;
	}
}
