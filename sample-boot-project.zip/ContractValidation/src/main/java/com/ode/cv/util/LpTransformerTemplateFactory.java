/**
 * 
 */
package com.ode.cv.util;

import java.io.File;
import java.util.Hashtable;

import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.ode.dlr.util.AppException;

/**
 * @author snimma
 *
 */
@Component
public class LpTransformerTemplateFactory implements Constants {

	private static final Logger log = LogManager.getLogger(LpTransformerTemplateFactory.class);

	private Hashtable templatesHash;
	@Value("${StyleSheetDir}")
	private String xslDir;

	// to make it singleton class
	public LpTransformerTemplateFactory() {
		templatesHash = new Hashtable();
	}

	/**
	 * getTransformer - creates new transformer template object for the first time
	 * 
	 * @param styleSheetKey
	 * @return
	 * @throws AppException
	 */
	public synchronized Transformer getTransformer(String styleSheetKey) throws AppException {

		log.debug("Entered getTransformer() of LpTransformerTemplateFactory class");
		FileSystemResource fileSystemResource = null;
		try {
			TransformerFactory factory = null;
			styleSheetKey = styleSheetKey.trim();
			if (styleSheetKey.startsWith(saxon)) {
				factory = new net.sf.saxon.TransformerFactoryImpl();
				styleSheetKey = styleSheetKey.substring(saxon.length(), styleSheetKey.length());
			} else {
				factory = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl", org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
			}
			if (factory != null) {
				log.debug("Instantiated TransformerFactory");
			}
			String xslFileName = this.xslDir + styleSheetKey;

			log.debug("StyleSheet File for obtaining transformer: " + xslFileName);
			
			File file = new File(xslFileName);
			if (file != null && file.exists() && file.canRead())
			{
				log.debug("Stylesheet file is ready!");
			}
			else
			{
				log.debug("Stylesheet file is NOT ready!");
			}
			StreamSource streamSource = new StreamSource(file);
			if (streamSource != null)
			{
				log.debug("StreamSource is ready!");
			}
			else
			{
				log.debug("StreamSource is NOT ready!");
			}
			Transformer transformer = null;
			Templates template = factory.newTemplates(streamSource);
			if (template != null) {
				log.debug("Template for transformer created successfully");
				transformer = template.newTransformer();
			} else {
				log.debug("Could not create Template for transformer");
				transformer = factory.newTransformer(streamSource);
			}
			return transformer;
		} catch (Exception e) {
			log.error("Exception caught when trying to obtain transformer. Exception: ", e);
			throw new AppException(e, "getTransformer", getClass().getName());
		} /*
			 * finally { try { if (fileSystemResource.getInputStream() != null) {
			 * fileSystemResource.getInputStream().close(); } } catch (final IOException e)
			 * {
			 * 
			 * log.
			 * error("Exception caught when trying to close fileSystemResource.getInputStream"
			 * , e); } }
			 */
	}

	/**
	 * @param styleSheetKey
	 * @throws AppException Reloads a particular stylesheet to the Hashmap. In case
	 *                      the provided stylesheet is not existing then a new key
	 *                      gets added to the hashmap
	 */
	@SuppressWarnings("unchecked")
	public synchronized void reloadTransformer(String styleSheetKey) throws AppException {
		try {
			Templates template = (Templates) templatesHash.get(styleSheetKey);

			String xslFileName = this.xslDir + styleSheetKey;
			if (null != xslFileName) {
				template = TransformerFactory.newInstance().newTemplates(new StreamSource(new File(xslFileName)));
				templatesHash.put(styleSheetKey, template);
			}
		} catch (Exception e) {
			throw new AppException(e, "getTransformer", getClass().getName());
		}
	}

}
