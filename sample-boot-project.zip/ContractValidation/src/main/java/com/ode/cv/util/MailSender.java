package com.ode.cv.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.ode.cv.vo.CVInputVO;

/**
 * @author rmathew
 *
 */
public class MailSender {

	private static final Logger logger = LogManager.getLogger(MailSender.class);

	private JavaMailSenderImpl mailSender;
	private String from = "";
	private String supportEmail = "";
	private String environment = "";

	/**
	 * @param email
	 * @param lenderDealerId
	 * @param userId
	 * @param dealNumber
	 * @param applicationNumber
	 * @param validationResults
	 * @param validationMessage
	 */
	public void sendEcackoutStatus(String email, String lenderDealerId, String userId, String dealNumber,
			String applicationNumber, String validationResults, String validationMessage) {
		StringBuilder sb = new StringBuilder();
		sb.append(lenderDealerId);
		sb.append(" / ");
		sb.append(userId);
		sb.append(" / ");
		sb.append(dealNumber);
		String subject = sb.toString();

		sb.setLength(0); // clear the buffer
		sb.append("Deal: ");
		sb.append(dealNumber);
		sb.append("\n App: ");
		sb.append(applicationNumber);
		sb.append("\n ");
		sb.append(validationResults);
		sb.append("\n ");
		sb.append(validationMessage);
		String body = sb.toString();

		sendEmail(subject, body, email);
	}

	public void sendEmail(String subject, String body, String email) {
		logger.entry();
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(email);
		message.setFrom(from);
		message.setSubject(getEnvironment() + ": " + subject);
		message.setText(body);
		try {
			mailSender.send(message);
		} catch (Exception e) {
			logger.error("could not send email", e);
		}
		logger.exit();
	}

	public void sendVaultEmail(final String message, final String documentId, final CVInputVO cvInputVO) {
		String subject = getEnvironment() + ": vault accept/reject failed";
		String lender = cvInputVO.getPartnerInfoVO().getLenderId();
		String dealer = cvInputVO.getDealerInfoVO().getDealerId();
		String contractApplicationNumber = cvInputVO.getAccr().getContractApplicationNumber();

		String body = "An error occured when attempting to accept / reject a vaulted document on behalf of a lender. \n\n"
				+ "Lender: " + lender + "\n" + "Dealer: " + dealer + "\n" + "DocumentId: " + documentId + "\n"
				+ "Contract Application Number: " + contractApplicationNumber + "\n\n" + message;

		sendEmail(subject, body, supportEmail);
	}

	public void sendVaultEmail(final String messageIn, final String documentId, final CVInputVO cvInputVO,
			Exception e) {

		String message = "";
		Writer writer = new StringWriter();
		PrintWriter printWriter = new PrintWriter(writer);
		e.printStackTrace(printWriter);
		String stackTrace = writer.toString();

		message += "\n" + stackTrace;

		sendVaultEmail(message, documentId, cvInputVO);
	}

	public void sendEncryptionEmail(String message) {
		String subject = environment + ": alert for key rotation";

		String body = "An error occured with keys.xml file. \n" + message;

		sendEmail(subject, body, supportEmail);
	}

	public JavaMailSenderImpl getMailSender() {
		return mailSender;
	}

	public void setMailSender(JavaMailSenderImpl mailSender) {
		this.mailSender = mailSender;
	}

	public String getSupportEmail() {
		return supportEmail;
	}

	public void setSupportEmail(String supportEmail) {
		this.supportEmail = supportEmail;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getEnvironment() {
		if ("development".equals(environment))
			return "DEV";
		if ("staging".equals(environment))
			return "STAGE";
		if ("qa".equals(environment))
			return "QA";
		if ("production".equals(environment))
			return "PROD";
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

}
