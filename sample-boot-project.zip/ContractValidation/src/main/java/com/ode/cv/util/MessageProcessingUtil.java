/**
 * 
 */
package com.ode.cv.util;

import java.util.List;

import com.adp.dealerservices.loanprocessing.MessageProcessing;


/**
 * @author snimma
 *
 */
public class MessageProcessingUtil {

	public static MessageProcessing getMessageProcessingWithId(List<MessageProcessing> messageProcessing, String id) {
		if (null != messageProcessing) {
			for (MessageProcessing mp : messageProcessing) {
				if (null != mp && null != mp.getId()) {
					if (mp.getId().equalsIgnoreCase(id)) {
						return mp;
					}
				}
			}
		}
		return null;
	}

	public static boolean containsId(List<MessageProcessing> messageProcessing, String id) {
		MessageProcessing mp = getMessageProcessingWithId(messageProcessing, id);
		if (null != mp) {
			return true;
		}
		return false;
	}

	public static MessageProcessing getMessageProcessingWithValue(List<MessageProcessing> messageProcessing,
			String value) {
		if (null != messageProcessing) {
			for (MessageProcessing mp : messageProcessing) {
				if (null != mp && null != mp.getValue()) {
					if (mp.getValue().equalsIgnoreCase(value)) {
						return mp;
					}
				}
			}
		}
		return null;
	}

	public static MessageProcessing getMessageProcessingStartsWithValue(List<MessageProcessing> messageProcessing,
			String value) {
		if (null != messageProcessing) {
			for (MessageProcessing mp : messageProcessing) {
				if (null != mp && null != mp.getValue()) {
					if (mp.getValue().startsWith(value)) {
						return mp;
					}
				}
			}
		}
		return null;
	}

	public static boolean containsValue(List<MessageProcessing> messageProcessing, String value) {
		MessageProcessing mp = getMessageProcessingWithValue(messageProcessing, value);
		if (null != mp) {
			return true;
		}
		return false;
	}

	public static boolean containsValueWithId(List<MessageProcessing> messageProcessing, String value, String id) {
		MessageProcessing mp = getMessageProcessingWithValue(messageProcessing, value);
		if (null != mp && null != mp.getId() && mp.getId().equals(id)) {
			return true;
		}
		return false;
	}

	public static boolean startsWithValue(List<MessageProcessing> messageProcessing, String value) {
		MessageProcessing mp = getMessageProcessingStartsWithValue(messageProcessing, value);
		if (null != mp) {
			return true;
		}
		return false;
	}

}
