/*
 * Created on Oct 17, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util;

import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.jsoup.Jsoup;
import org.jsoup.parser.Parser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.adp.dealerservices.loanprocessing.FinanceInstitution;
import com.ode.cv.exception.CVFromDocumentException;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.dlr.util.AppException;

/**
 * @author rmathew
 *
 */
@Component
public class PCCXmlParser extends AppXMLParser {

	private static final Logger logger = LogManager.getLogger(PCCXmlParser.class);

	private String className = getClass().getName();
	private RFLUtil eDocsUtil;

	@Value("${XPath_ContractValidation_FundingAutomation}")
	private String XPath_ContractValidation_FundingAutomation;
	@Value("${XPath_ContractValidation_LenderId}")
	private String XPath_LenderId;
	@Value("${Exceptional_Processing_PCC}")
	private String exceptional_Processing;
	@Value("${XPath_ContractValidation_CreatorNameCode}")
	private String XPath_CreatorNameCode;
	@Value("${XPath_ContractValidation_SenderNameCode}")
	private String XPath_SenderNameCode;
	@Value("${XPath_ContractValidation_UserId}")
	private String XPath_UserId;
	@Value("${XPath_PCC_Task}")
	private String XPath_Task;
	@Value("${XPath_ProcessCreditContract_SystemId}")
	private String XPath_ProcessCreditContract_SystemId;
	@Value("${XPath_ProcessCreditContract_DealerId}")
	private String XPath_ProcessCreditContract_DealerId;
	@Value("${XPath_ProcessCreditContract_ContractExecutionState}")
	private String XPath_ProcessCreditContract_ContractExecutionState;
	@Value("${XPath_ProcessCreditContract_DocumentId}")
	private String XPath_ProcessCreditContract_DocumentId;
	@Value("${XPath_ProcessCreditContract_ADPDealNo}")
	private String XPath_ProcessCreditContract_ADPDealNo;
	@Value("${XPath_ProcessCreditContract_ServiceId}")
	private String XPath_ProcessCreditContract_ServiceId;
	@Value("${XPath_ProcessCreditContract_LocationId}")
	private String XPath_ProcessCreditContract_LocationId;
	@Value("${XPath_ProcessCreditContract_DealerName}")
	private String XPath_ProcessCreditContract_DealerName;
	@Value("${XPath_ProcessCreditContract_VehicleYear}")
	private String XPath_ProcessCreditContract_VehicleYear;
	@Value("${XPath_ProcessCreditContract_VehicleMake}")
	private String XPath_ProcessCreditContract_VehicleMake;
	@Value("${XPath_ProcessCreditContract_VehicleModel}")
	private String XPath_ProcessCreditContract_VehicleModel;
	@Value("${XPath_ProcessCreditContract_ContractFormNumber}")
	private String XPath_ProcessCreditContract_ContractFormNumber;
	@Value("${XPath_ProcessCreditContract_ContractFormRevisionDate}")
	private String XPath_ProcessCreditContract_ContractFormRevisionDate;

	// GenericCreditContract
	@Value("${XPath_GenericCreditContract_LenderId}")
	private String XPath_GenericCreditContract_LenderId;
	@Value("${XPath_GenericCreditContract_FundingAutomation}")
	private String XPath_GenericCreditContract_FundingAutomation;
	@Value("${XPath_GenericCreditContract_UserId}")
	private String XPath_GenericCreditContract_UserId;
	@Value("${XPath_GenericCreditContract_contractFormNumber}")
	private String XPath_GenericCreditContract_contractFormNumber;
	// Replacement xpath properties for xpaths from lpConfig
	@Value("${XPath_GenericCreditContract_SystemId}")
	private String XPath_GenericCreditContract_SystemId;
	@Value("${XPath_GenericCreditContract_DealerId}")
	private String XPath_GenericCreditContract_DealerId;
	@Value("${XPath_GenericCreditContract_dealerName}")
	private String XPath_GenericCreditContract_dealerName;
	@Value("${XPath_GenericCreditContract_FinanceType}")
	private String XPath_GenericCreditContract_FinanceType;
	@Value("${XPath_GenericCreditContract_contractExecState}")
	private String XPath_GenericCreditContract_contractExecState;
	@Value("${XPath_GenericCreditContract_DocumentId}")
	private String XPath_GenericCreditContract_DocumentId;
	@Value("${XPath_GenericCreditContract_ADPDealNo}")
	private String XPath_GenericCreditContract_ADPDealNo;
	@Value("${XPath_GenericCreditContract_ResponseURL}")
	private String XPath_GenericCreditContract_ResponseURL;
	@Value("${XPath_GenericCreditContract_VehicleYear}")
	private String XPath_GenericCreditContract_VehicleYear;
	@Value("${XPath_GenericCreditContract_VehicleMake}")
	private String XPath_GenericCreditContract_VehicleMake;
	@Value("${XPath_GenericCreditContract_VehicleModel}")
	private String XPath_GenericCreditContract_VehicleModel;
	@Value("${XPath_ProcessCreditContract_FinanceType}")
	private String XPath_ProcessCreditContract_FinanceType;
	@Value("${XPath_CreditContract_DealId}")
	private String XPath_CreditContract_DealId;

	private static final String GENERIC_CREDIT_CONTRACT = "GenericCreditContract";

	private static final String PATH_TO_CONTRACT_ELEMENT = "/payload/content";
	private static final String MERCEDES_DESTINATION_NAME_CODE = "DF";
	private static final String MERCEDES_LENDER_ID = "MB";
	
	/**
	 * @param document
	 * @param creditContractVO
	 * @throws Exception
	 */
	public void parseInput(final Document document, final CreditContractVO creditContractVO) throws Exception {

		logger.debug("Enter parseInput() method of PCCXmlParser class");

		DeContractValidationBo cvFromDocument = null;

		Node node = XPathAPI.selectSingleNode(document, PATH_TO_CONTRACT_ELEMENT);
		String operationName = node.getChildNodes().item(1).getNodeName();

		if (GENERIC_CREDIT_CONTRACT.equalsIgnoreCase(operationName)) {
			creditContractVO.setGenericCreditContract(true);
		}

		String xpath = "";
		String lenderId = "";
		creditContractVO.setProductId("CV");
		String userid = XPathAPI.eval(document, getXPath_UserId()).toString();
		FinanceInstitution financeInstitutionForLender = null;

		if (creditContractVO.isGenericCreditContract() == true) {
			logger.debug("Starting GenericCreditContract block in parseInput() method of PCCXmlParser class");
			xpath = getXPath_GenericCreditContract_LenderId();
			lenderId = XPathAPI.eval(document, xpath).toString();
			creditContractVO.getPartnerInfo().setLenderId(lenderId);
			creditContractVO.setApplicationSource("0N");
			creditContractVO.getDealerInfo().setDspId("AD");

			xpath = XPath_GenericCreditContract_SystemId;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.getDealerInfo().setSystemId(XPathAPI.eval(document, xpath).toString());
			}

			xpath = XPath_GenericCreditContract_DealerId;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.getDealerInfo().setDealerId(XPathAPI.eval(document, xpath).toString());
			}

			xpath = XPath_GenericCreditContract_dealerName;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.getDealerInfo().setDealerName(XPathAPI.eval(document, xpath).toString());
			}

			xpath = XPath_GenericCreditContract_FinanceType;
			if (StringUtils.isNotBlank(xpath)) {

				String financetype = XPathAPI.eval(document, xpath).toString();
				if (financetype.length() > 0 && financetype != null) {
					creditContractVO.setFinanceType(financetype);
				}
			}

			xpath = XPath_GenericCreditContract_contractExecState;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.setContractExecutionState(XPathAPI.eval(document, xpath).toString());
			}
			
			xpath = getXPath_GenericCreditContract_contractFormNumber();
			String contractFormString = XPathAPI.eval(document, xpath).toString();
			if (StringUtils.isBlank(contractFormString)) {
				contractFormString = XPathAPI.eval(document,
						"/payload/content/GenericCreditContract/contractInfo/adpCreditData/nvp[name='ContractForm']/value")
						.toString();
			}
			logger.debug("contractFormString: {}", contractFormString);
			if (StringUtils.isNotEmpty(contractFormString) && contractFormString.contains(Constants.COMMA)) {
				String[] contractFormTokens = contractFormString.split(Constants.COMMA);
				String contractFormNumber = contractFormTokens[0].trim();
				String contractRevisionDate = contractFormTokens[1].trim();
				if (contractRevisionDate.length() > 10 && contractRevisionDate.toLowerCase().contains("version")) {
					contractRevisionDate = contractRevisionDate.substring(contractRevisionDate.length() - 10);
				}
				creditContractVO.setContractFormNumber(contractFormNumber);
				creditContractVO.setContractFormRevisionDate(STAR_DATE_FORMAT.parse(contractRevisionDate));
				logger.debug("contractFormNumber: {}", creditContractVO.getContractFormNumber());
				logger.debug("contractRevisionDate: {}", creditContractVO.getContractFormRevisionDate());
			} else {
				logger.error("Missing mandatory contract form/revision date! contractFormString: {}",
						contractFormString);
			}

			xpath = XPath_GenericCreditContract_DocumentId;
			creditContractVO.setDocumentId(XPathAPI.eval(document, xpath).toString());

			xpath = XPath_GenericCreditContract_ADPDealNo;
			creditContractVO.setAdpDealNo(XPathAPI.eval(document, xpath).toString());

			xpath = XPath_GenericCreditContract_ResponseURL;
			if (StringUtils.isNotBlank(xpath)) {

				creditContractVO.setServiceId(XPathAPI.eval(document, xpath).toString());
				String responseURL = creditContractVO.getServiceId();
				int locationIdIndex = 0;
				int serviceIdIndex = 0;
				String locationId = responseURL;
				for (int i = 0; i < 3; i++) {
					locationIdIndex = locationId.indexOf("/") + 1;
					locationId = locationId.substring(locationIdIndex);
					serviceIdIndex = serviceIdIndex + locationIdIndex;
				}
				String serviceId = responseURL.substring(0, serviceIdIndex - 1);
				creditContractVO.setServiceId(serviceId);
				creditContractVO.setLocationId("/" + locationId);
			}

			xpath = XPath_GenericCreditContract_VehicleYear;
			if (StringUtils.isNotBlank(xpath)) {

				creditContractVO.setVehicleYear(XPathAPI.eval(document, xpath).toString());
				if (StringUtils.isBlank(creditContractVO.getVehicleYear())) {
					String xPathVehicleYear = XPath_GenericCreditContract_VehicleYear;
					xPathVehicleYear = xPathVehicleYear.replaceAll("adpCreditData", "dmsData");
					xpath = xPathVehicleYear;
					creditContractVO.setVehicleYear(XPathAPI.eval(document, xpath).toString());
				}
			}

			xpath = XPath_GenericCreditContract_VehicleMake;
			if (StringUtils.isNotBlank(xpath)) {

				creditContractVO.setVehicleMake(XPathAPI.eval(document, xpath).toString());
				if (StringUtils.isBlank(creditContractVO.getVehicleMake())) {
					String xPathVehicleMake = XPath_GenericCreditContract_VehicleMake;
					xPathVehicleMake = xPathVehicleMake.replaceAll("adpCreditData", "dmsData");
					creditContractVO.setVehicleMake(XPathAPI.eval(document, xPathVehicleMake).toString());
				}
			}

			if (null != financeInstitutionForLender && financeInstitutionForLender.isMultifranchise()) {
				creditContractVO.getPartnerInfo().setGlobalLenderId(financeInstitutionForLender.getId());
			}

			xpath = XPath_GenericCreditContract_VehicleModel;
			if (StringUtils.isNotBlank(xpath)) {

				creditContractVO.setVehicleModel(XPathAPI.eval(document, xpath).toString());
				if (StringUtils.isBlank(creditContractVO.getVehicleModel())) {
					String xPathVehicleModel = XPath_GenericCreditContract_VehicleModel;
					xPathVehicleModel = xPathVehicleModel.replaceAll("adpCreditData", "dmsData");
					creditContractVO.setVehicleModel(XPathAPI.eval(document, xPathVehicleModel).toString());
				}
			}

			if (getXPath_GenericCreditContract_FundingAutomation() != null) {
				xpath = getXPath_GenericCreditContract_FundingAutomation();
				String fundingAutomation = XPathAPI.eval(document, xpath).toString();
				creditContractVO.setFromPF(null);
				if (fundingAutomation != null && fundingAutomation.equals(FUNDING_AUTOMATION_0)) {
					creditContractVO.setFromPF(FROM_PF_NO);
				} else if (fundingAutomation != null && fundingAutomation.equals(FUNDING_AUTOMATION_1)) {
					creditContractVO.setFromPF(FROM_PF_YES);
				}
			}

			creditContractVO.setTaskName("CreditContract");
			userid = XPathAPI.eval(document, getXPath_GenericCreditContract_UserId()).toString();

			logger.debug("Finished GenericCreditContract block in parseInput() method of PCCXmlParser class");
		} else { // ProcessCreditContract
			logger.debug("Starting ProcessCreditContract block in parseInput() method of PCCXmlParser class");
			lenderId = getLenderId(document, creditContractVO.getRequestXML()); 
			creditContractVO.getPartnerInfo().setLenderId(lenderId);
			creditContractVO.setExceptionLenders(exceptionalProcessing(lenderId));

			if (getXPath_CreatorNameCode() != null) {
				xpath = getXPath_CreatorNameCode();
				creditContractVO.setApplicationSource(XPathAPI.eval(document, xpath).toString());
			}
			if (getXPath_SenderNameCode() != null) {
				xpath = getXPath_SenderNameCode();
				String senderNameCode = XPathAPI.eval(document, xpath).toString();
				creditContractVO.getDealerInfo().setDspId(senderNameCode);
			}

			xpath = XPath_ProcessCreditContract_SystemId;
			if (StringUtils.isNotBlank(xpath))
				creditContractVO.getDealerInfo().setSystemId(XPathAPI.eval(document, xpath).toString());

			xpath = XPath_ProcessCreditContract_DealerId;
			if (StringUtils.isNotBlank(xpath))
				creditContractVO.getDealerInfo().setDealerId(XPathAPI.eval(document, xpath).toString());

			xpath = XPath_ProcessCreditContract_FinanceType;
			if (StringUtils.isNotBlank(xpath)) {
				String financetype = XPathAPI.eval(document, xpath).toString();
				if (financetype.length() > 0 && financetype != null) {
					creditContractVO.setFinanceType(financetype);
				}
			}

			// Required for ADP-MB State Group variable
			xpath = XPath_ProcessCreditContract_ContractExecutionState;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.setContractExecutionState(XPathAPI.eval(document, xpath).toString());
			}

			xpath = XPath_ProcessCreditContract_DocumentId;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.setDocumentId(XPathAPI.eval(document, xpath).toString());
			}
			if (StringUtils.isEmpty(creditContractVO.getDocumentId())) {
				String documentId =  XPathAPI.eval(document, "//payload/content/ProcessCreditContract/DataArea/CreditContract/Header/DocumentId").toString();
				logger.debug("Request Document ID: {}",documentId);
				creditContractVO.setDocumentId(documentId);
			}

			String dealId = null;
			xpath = XPath_CreditContract_DealId;
			if (StringUtils.isNotBlank(xpath)) {
				dealId = XPathAPI.eval(document, xpath).toString();
			}

			xpath = XPath_ProcessCreditContract_ADPDealNo;
			if (StringUtils.isNotBlank(xpath)) {
				String dealno = XPathAPI.eval(document, xpath).toString();
				if (dealno.length() > 0 && dealno != null) {
					creditContractVO.setAdpDealNo(dealno);
				} else {
					if (StringUtils.isNotBlank(dealId)) {
						creditContractVO.setAdpDealNo(dealId);
					} else {
						creditContractVO.setAdpDealNo(creditContractVO.getDocumentId());
					}
				}
			} else {
				creditContractVO.setAdpDealNo(creditContractVO.getDocumentId());
			}

			creditContractVO.setProductId("CV");

			xpath = XPath_ProcessCreditContract_ServiceId;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.setServiceId(XPathAPI.eval(document, xpath).toString());
			}
			xpath = XPath_ProcessCreditContract_LocationId;
			if (StringUtils.isNotBlank(xpath)) {
				creditContractVO.setLocationId(XPathAPI.eval(document, xpath).toString());
			}
			xpath = XPath_ProcessCreditContract_DealerName;
			if (StringUtils.isNotBlank(xpath)) {
				String dealerName = XPathAPI.eval(document, xpath).toString();
				creditContractVO.setDealerName(dealerName);
				creditContractVO.getDealerInfo().setDealerName(dealerName);
			}

			if (getXPath_ContractValidation_FundingAutomation() != null) {
				String fundingAutomation = XPathAPI.eval(document, getXPath_ContractValidation_FundingAutomation())
						.toString();
				creditContractVO.setFromPF(null);
				if (fundingAutomation != null && fundingAutomation.equals(FUNDING_AUTOMATION_0)) {
					creditContractVO.setFromPF(FROM_PF_NO);
				} else if (fundingAutomation != null && fundingAutomation.equals(FUNDING_AUTOMATION_1)) {
					creditContractVO.setFromPF(FROM_PF_YES);
				}
			}

			creditContractVO.setTaskName(XPathAPI.eval(document, getXPath_Task()).toString());
			xpath = XPath_ProcessCreditContract_VehicleYear;
			if (StringUtils.isNotBlank(xpath))
				creditContractVO.setVehicleYear(XPathAPI.eval(document, xpath).toString());
			xpath = XPath_ProcessCreditContract_VehicleMake;
			if (StringUtils.isNotBlank(xpath))
				creditContractVO.setVehicleMake(XPathAPI.eval(document, xpath).toString());
			xpath = XPath_ProcessCreditContract_VehicleModel;
			if (StringUtils.isNotBlank(xpath))
				creditContractVO.setVehicleModel(XPathAPI.eval(document, xpath).toString());
			logger.debug("Finished ProcessCreditContract block in parseInput() method of PCCXmlParser class");
		}

		if (userid.length() > 0 && userid != null) {
			creditContractVO.setUserId(userid);
		}

		if (creditContractVO.getDealerInfo().getDspId().equalsIgnoreCase("AD")
				|| creditContractVO.getDealerInfo().getDspId().equalsIgnoreCase("AR")) {
			// creditContractVO.setApplication_source(creatorcode);
			creditContractVO.setDeliverySource("WC");
		} else {
			// creditContractVO.setApplication_source(creatorcode);
			creditContractVO.setDeliverySource("CG");
		} // IF CREATOR NAME CODE not equal to L2

		// The next 2 items will only hit for vci-cv and mb-cv, both ERA
		String contractFormNumberXpath = XPath_ProcessCreditContract_ContractFormNumber;
		if (!StringUtils.isEmpty(contractFormNumberXpath)
				&& StringUtils.isEmpty(creditContractVO.getContractFormNumber())) {

			String contractFormNumber = XPathAPI.eval(document, contractFormNumberXpath).toString();
			creditContractVO.setContractFormNumber(contractFormNumber);
		}
		xpath = XPath_ProcessCreditContract_ContractFormRevisionDate;
		if (StringUtils.isNotBlank(xpath)) {
			String revisionDate = XPathAPI.eval(document, xpath).toString();
			logger.debug("Value of contractFormRevisionDate from document: " + revisionDate);
			if (null != revisionDate && !revisionDate.isEmpty()) {
				creditContractVO.setContractFormRevisionDate(STAR_DATE_FORMAT.parse(revisionDate));
			}
		}

		logger.debug("Finished parseInput() method of PCCXmlParser class");
		
	}// parse Input

	/**
	 * @param document
	 * @param requestXml
	 * @return
	 * @throws TransformerException
	 * @throws CVFromDocumentException
	 */
	private String getLenderId(final Document document, String requestXml) throws TransformerException, CVFromDocumentException {
		logger.debug("Entered getLenderId() method");
		String xpath;
		String lenderId;
		xpath = getXPath_LenderId();
		lenderId = XPathAPI.eval(document, xpath).toString();
		if (StringUtils.isEmpty(lenderId)) {
			logger.debug("PartyId was empty, attempting to use DestinationNameCode");
			String destinationNameCode = this.getDestinationNameCode(requestXml);
			if (MERCEDES_DESTINATION_NAME_CODE.equals(destinationNameCode)) {
				lenderId = MERCEDES_LENDER_ID;
			} else {
				logger.error("DestinationNameCode {} not suported for missing PartyID", destinationNameCode);
				throw new CVFromDocumentException("LenderID could not be determined");
			}
		}
		logger.debug("Exiting getLenderId() method with a lenderId of {}", lenderId);
		return lenderId;
	}

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	public Integer getResponseXmlId(final String xml) throws Exception {
		logger.debug("Entered getResponseXmlId() method of PCCXmlParser class");
		Integer xmlId = null;
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String strXmlId = doc.select("OriginalApplicationArea").select("BODId").text();
		xmlId = Integer.valueOf(strXmlId);
		return xmlId;
	}
	
	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	public String getRouteOneConversationId(final String xml) throws Exception {
		logger.debug("Entered getRouteOneConversationId() method of PCCXmlParser class");
		String conversationId = null;
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		conversationId = doc.select("ApplicationArea").select("BODId").text();
		return conversationId;
	}

	public RFLUtil geteDocsUtil() {
		return eDocsUtil;
	}

	public void seteDocsUtil(RFLUtil eDocsUtil) {
		this.eDocsUtil = eDocsUtil;
	}

	public String getXPath_GenericCreditContract_LenderId() {
		return XPath_GenericCreditContract_LenderId;
	}

	public void setXPath_GenericCreditContract_LenderId(String xPath_GenericCreditContract_LenderId) {
		XPath_GenericCreditContract_LenderId = xPath_GenericCreditContract_LenderId;
	}

	public String getXPath_GenericCreditContract_FundingAutomation() {
		return XPath_GenericCreditContract_FundingAutomation;
	}

	public void setXPath_GenericCreditContract_FundingAutomation(String xPath_GenericCreditContract_FundingAutomation) {
		XPath_GenericCreditContract_FundingAutomation = xPath_GenericCreditContract_FundingAutomation;
	}

	public String getXPath_LenderId() {
		return XPath_LenderId;
	}

	public void setXPath_LenderId(String xPath_LenderId) {
		XPath_LenderId = xPath_LenderId;
	}

	public String getXPath_CreatorNameCode() {
		return XPath_CreatorNameCode;
	}

	public void setXPath_CreatorNameCode(String xPath_CreatorNameCode) {
		XPath_CreatorNameCode = xPath_CreatorNameCode;
	}

	public String getXPath_SenderNameCode() {
		return XPath_SenderNameCode;
	}

	public void setXPath_SenderNameCode(String xPath_SenderNameCode) {
		XPath_SenderNameCode = xPath_SenderNameCode;
	}

	public String getXPath_ContractValidation_FundingAutomation() {
		return XPath_ContractValidation_FundingAutomation;
	}

	public void setXPath_ContractValidation_FundingAutomation(String xPath_ContractValidation_FundingAutomation) {
		XPath_ContractValidation_FundingAutomation = xPath_ContractValidation_FundingAutomation;
	}

	public String getXPath_UserId() {
		return XPath_UserId;
	}

	public void setXPath_UserId(String xPath_UserId) {
		XPath_UserId = xPath_UserId;
	}

	public String getXPath_GenericCreditContract_UserId() {
		return XPath_GenericCreditContract_UserId;
	}

	public void setXPath_GenericCreditContract_UserId(String xPath_GenericCreditContract_UserId) {
		XPath_GenericCreditContract_UserId = xPath_GenericCreditContract_UserId;
	}

	public String getXPath_Task() {
		return XPath_Task;
	}

	public void setXPath_Task(String xPath_Task) {
		XPath_Task = xPath_Task;
	}

	public String getXPath_GenericCreditContract_contractFormNumber() {
		return XPath_GenericCreditContract_contractFormNumber;
	}

	public void setXPath_GenericCreditContract_contractFormNumber(
			String xPath_GenericCreditContract_contractFormNumber) {
		XPath_GenericCreditContract_contractFormNumber = xPath_GenericCreditContract_contractFormNumber;
	}

	/**
	 * @param inputLenderId
	 * @return
	 * @throws Exception
	 */
	public String[] exceptionalProcessing(final String inputLenderId) throws Exception {

		logger.debug("Entered exceptionalProcessing() method. inputLenderId = " + inputLenderId);
		String[] exceptionalArray = exceptional_Processing.split(Constants.COMMA);

		for (int i = 0; i < exceptionalArray.length; i++) {

			if ((exceptionalArray[i].contains(Constants.GETLENDER)) && exceptionalArray[i]
					.substring(0, exceptionalArray[i].indexOf(Constants.GETLENDER)).equalsIgnoreCase(inputLenderId)) {
				exceptionalArray[i] = Constants.GETLENDER;
			} else if ((exceptionalArray[i].contains(Constants.EQUAL)) && exceptionalArray[i]
					.substring(0, exceptionalArray[i].indexOf(Constants.EQUAL)).equalsIgnoreCase(inputLenderId)) {

				exceptionalArray[i] = exceptionalArray[i].substring(exceptionalArray[i].indexOf(Constants.EQUAL) + 1)
						+ Constants.REPL;
			} else if ((exceptionalArray[i].contains(Constants.EQUAL)) && (!(inputLenderId.equalsIgnoreCase(
					exceptionalArray[i].substring(0, exceptionalArray[i].indexOf(Constants.EQUAL)))))) {
				exceptionalArray[i] = null;
			}

		}

		return exceptionalArray;
	}

	/**
	 * @param xml
	 * @return
	 */
	public String getDestinationNameCode(final String xml) {
		logger.debug("Entered getDestinationNameCode() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String destinationCode = doc.select(APPLICATION_AREA_ELEM).select("Destination").select("DestinationNameCode")
				.text();
		return destinationCode;
	}

	/**
	 * @param xml
	 * @return
	 */
	public String getSenderNameCode(final String xml) {
		logger.debug("Entered getSenderNameCode() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String senderNameCode = doc.select(APPLICATION_AREA_ELEM).select("Sender").select("SenderNameCode").text();
		doc = null;
		return senderNameCode;
	}
	
	/**
	 * @param xml
	 * @return
	 */
	public String getEcinFromCvEcin(final String xml) {
		logger.debug("Entered getEcinFromCvEcin() method of PCCXmlParser class");
		int start =  xml.indexOf("<ECIN>") + 6;
		int end =  xml.indexOf("</ECIN>");
		String ecin = xml.substring(start, end).trim();
		if(ecin != null && !ecin.isEmpty()) {
			logger.debug("ECIN found.");
		}
		return ecin;
	}
	
	/**
	 * @param xml
	 * @return
	 */
	public String getDeDealIdFromCvEcin(final String xml) {
		logger.debug("Entered getDeDealIdFromCvEcin() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String deDealId = doc.select("CV-ECIN").select("Header").select("DeDealId").text();
		doc = null;
		logger.debug("Value found: {}", deDealId);
		return deDealId;
	}
	
	/**
	 * @param xml
	 * @return
	 */
	public String getCvSeqIdFromCvEcin(final String xml) {
		logger.debug("Entered getCvSeqIdFromCvEcin() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String cvSeqId = doc.select("CV-ECIN").select("Header").select("SequenceId").text();
		doc = null;
		logger.debug("Value found: {}", cvSeqId);
		return cvSeqId;
	}

	/**
	 * @param xml
	 * @return
	 */
	public String getLenderIdFromEcout2(final String xml) {
		logger.debug("Entered getLenderIdFromEcout2() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String lenderId = doc.select("PartnerFSID").text();
		doc = null;
		return lenderId;
	}

	public String getAuthorizationIdFromEcout2(final String xml) {
		logger.debug("Entered getAuthorizationIdFromEcout2() method of PCCXmlParser class");
		org.jsoup.nodes.Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
		String authorizationId = doc.select(APPLICATION_AREA_ELEM).select("AuthorizationId").text();
		doc = null;
		return authorizationId;
	}

}
