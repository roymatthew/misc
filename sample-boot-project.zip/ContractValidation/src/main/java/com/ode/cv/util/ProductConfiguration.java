package com.ode.cv.util;

import java.io.Serializable;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.adp.dealerservices.loanprocessing.Connection;
import com.adp.dealerservices.loanprocessing.Destination;
import com.adp.dealerservices.loanprocessing.FinanceInstitution;
import com.adp.dealerservices.loanprocessing.Header;
import com.adp.dealerservices.loanprocessing.MessageProcessing;
import com.adp.dealerservices.loanprocessing.StyleSheetName;
import com.ode.persistence.service.DeLenderDestinationRepoServiceImpl;
import com.ode.persistence.service.FeatureConfigurationRepoServiceImpl;
import com.ode.persistence.vo.DeLenderDestinationVO;
import com.ode.persistence.vo.FeatureConfigurationVO;

/**
 * @author snimma
 *
 */
public class ProductConfiguration implements Serializable {

	@Autowired
	FeatureConfigurationRepoServiceImpl featureConfigurationRepoServiceImpl;

	@Autowired
	DeLenderDestinationRepoServiceImpl deLenderDestinationRepoServiceImpl;

	private static final long serialVersionUID = -3714678417551840571L;
	private static final Logger logger = LogManager.getLogger(ProductConfiguration.class);

	private String lenderId;
	private List<MessageProcessing> creditContractMessageProcessing;
	private Boolean creditContractMessageProcessingIsDbDriven;
	private List<StyleSheetName> creditContractStylesheets;
	private Boolean creditContractStylesheetIsDbDriven;
	private List<StyleSheetName> accrStylesheets;
	private Boolean accrStylesheetIsDbDriven;
	private List<Destination> creditContractDestinations;
	private Boolean creditContractDestinationIsDbDriven;
	private List<FeatureConfigurationVO> featureConfiguration;
	private List<DeLenderDestinationVO> lenderDestination;

	private static String COMPARISON_OPERATION_EQUALS = "COMPARISON_OPERATION_EQUALS";
	private static String COMPARISON_OPERATION_STARTS_WITH = "COMPARISON_OPERATION_STARTS_WITH";

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public void loadFinanceInstitution(FinanceInstitution fi) {
		logger.debug("Entered loadFinanceInstitution() ");
		if (null != fi.getId()) {
			logger.debug("loading lender id:{} into ProductConfiguration", fi.getId());
			setLenderId(fi.getId());
		}
		if (null != fi.getCreditContract() && null != fi.getCreditContract().getMessageProcessing()) {
			logger.debug("loading credit contract message processing into ProductConfiguration");
			creditContractMessageProcessing = fi.getCreditContract().getMessageProcessing();
		}
		if (null != fi.getCreditContract() && null != fi.getCreditContract().getStyleSheetName()) {
			logger.debug("loading credit contract stylesheets into ProductConfiguration");
			creditContractStylesheets = fi.getCreditContract().getStyleSheetName();
		}
		if (null != fi.getAckContractResp()  && null != fi.getAckContractResp().getStyleSheetName()) {
			logger.debug("loading accr stylesheets into ProductConfiguration");
			accrStylesheets = fi.getAckContractResp().getStyleSheetName();
		}
		if (null != fi.getCreditContract()  && null != fi.getCreditContract().getDestination()) {
			logger.debug("loading credit contract destinations into ProductConfiguration");
			creditContractDestinations = fi.getCreditContract().getDestination();
		}
	}
	
	public boolean cvMessageProcessingContainsValue(String value){
		logger.debug(value);
		return cvMessageProcessingHasValue(value, COMPARISON_OPERATION_EQUALS, null);
	}

	public boolean cvMessageProcessingContainsValue(String value, String dmsId) {
		logger.debug("Entered cvMessageProcessingContainsValue() " + value, dmsId);
		return cvMessageProcessingHasValue(value, COMPARISON_OPERATION_EQUALS, dmsId);
	}

	public boolean cvMessageProcessingStartsWithValue(String value) {
		logger.debug("Entered cvMessageProcessingStartsWithValue() " + value);
		return cvMessageProcessingHasValue(value, COMPARISON_OPERATION_STARTS_WITH, null);
	}

	private boolean cvMessageProcessingHasValue(String value, String comparisonOperation, String dmsId) {
		logger.debug("Entered cvMessageProcessingHasValue() " + value, comparisonOperation, dmsId);
		boolean containsValue = false;
		if (isCreditContractMessageProcessingDbDriven()) {
			List<FeatureConfigurationVO> featureConfigurations = getFeatureConfigurationRecords();
			if (null != featureConfiguration && !featureConfiguration.isEmpty()) {
				for (FeatureConfigurationVO featureConfiguration : featureConfigurations) {
					if (null != featureConfiguration) {
						if (comparisonOperation.equals(COMPARISON_OPERATION_EQUALS)) {
							if (null != dmsId) {
								if (null != featureConfiguration.getFeatureName()
										&& featureConfiguration.getFeatureName().equalsIgnoreCase(value)
										&& null != featureConfiguration.getDmsId()
										&& featureConfiguration.getDmsId().equalsIgnoreCase(dmsId)) {
									containsValue = true;
									break;
								}
							} else {
								if (null != featureConfiguration.getFeatureName()
										&& featureConfiguration.getFeatureName().equalsIgnoreCase(value)) {
									containsValue = true;
									break;
								}
							}
						} else if (comparisonOperation.equals(COMPARISON_OPERATION_STARTS_WITH)) {
							if (null != featureConfiguration.getFeatureName()
									&& featureConfiguration.getFeatureName().startsWith(value)) {
								containsValue = true;
								break;
							}
						}
					}
				}
			}
		} else {
			if (null != creditContractMessageProcessing) {
				if (comparisonOperation.equals(COMPARISON_OPERATION_EQUALS)) {
					if (null != dmsId) {
						containsValue = MessageProcessingUtil.containsValueWithId(creditContractMessageProcessing,
								value, dmsId);
					} else {
						containsValue = MessageProcessingUtil.containsValue(creditContractMessageProcessing, value);
					}
				} else if (comparisonOperation.equals(COMPARISON_OPERATION_STARTS_WITH)) {
					containsValue = MessageProcessingUtil.startsWithValue(creditContractMessageProcessing, value);
				}
			}
		}
		return containsValue;
	}

	public String getCvStylesheet(String id) {
		logger.debug("Entered getCvStylesheet() " + id);

		if (isCreditContractStylesheetDbDriven()) {
			List<FeatureConfigurationVO> featureConfigurations = getFeatureConfigurationRecords();
			if (null != featureConfiguration && !featureConfiguration.isEmpty()) {
				for (FeatureConfigurationVO featureConfiguration : featureConfigurations) {
					if (null != featureConfiguration) {
						if (null != id && id.equalsIgnoreCase(Constants.STYLESHEET_ID_EDOCS)) {
							// get stylesheet by product(eDocs)
							if (null != featureConfiguration.getFeatureName()
									&& featureConfiguration.getFeatureName().equalsIgnoreCase("stylesheet")
									&& null != featureConfiguration.getProduct()
									&& featureConfiguration.getProduct().equalsIgnoreCase("eDocs")
									&& null != featureConfiguration.getFeatureValue()) {
								return featureConfiguration.getFeatureValue();
							}
						} else {
							// get stylesheet by Dms Id
							if (null != featureConfiguration.getFeatureName()
									&& featureConfiguration.getFeatureName().equalsIgnoreCase("stylesheet")
									&& null != featureConfiguration.getProduct()
									&& featureConfiguration.getProduct().equalsIgnoreCase("CV")
									&& null != featureConfiguration.getDmsId()
									&& featureConfiguration.getDmsId().equalsIgnoreCase(id)
									&& null != featureConfiguration.getFeatureValue()) {
								return featureConfiguration.getFeatureValue();
							}
						}
					}
				}
			}
		} else {
			if (null != creditContractStylesheets) {
				for (StyleSheetName stylesheet : creditContractStylesheets) {
					if (stylesheet.getId().equalsIgnoreCase(id)) {
						return stylesheet.getValue();
					}
				}
			}
		}
		return null;
	}

	public String getAccrStylesheet(String id) {
		logger.debug("Entered getAccrStylesheet() " + id);

		if (isAccrStylesheetDbDriven()) {
			List<FeatureConfigurationVO> featureConfigurations = getFeatureConfigurationRecords();
			if (null != featureConfiguration && !featureConfiguration.isEmpty()) {
				for (FeatureConfigurationVO featureConfiguration : featureConfigurations) {
					if (null != featureConfiguration) {
						// get stylesheet by Dms Id
						if (null != featureConfiguration.getFeatureName()
								&& featureConfiguration.getFeatureName().equalsIgnoreCase("stylesheet")
								&& null != featureConfiguration.getProduct()
								&& featureConfiguration.getProduct().equalsIgnoreCase("ACCR")
								&& null != featureConfiguration.getDmsId()
								&& featureConfiguration.getDmsId().equalsIgnoreCase(id)
								&& null != featureConfiguration.getFeatureValue()) {
							return featureConfiguration.getFeatureValue();
						}
					}
				}
			}
		} else {
			if (null != accrStylesheets) {
				for (StyleSheetName stylesheet : accrStylesheets) {
					if (stylesheet.getId().equalsIgnoreCase(id)) {
						return stylesheet.getValue();
					}
				}
			}
		}
		return null;
	}

	public Destination getCvDestination(final String id, final boolean testDealer) {
		logger.debug("Entered getCvDestination() " + id);
		Destination destType = null;
		String product = "CV";
		boolean rulesLender = false;
		List<DeLenderDestinationVO> destinations = null;
		if (id.equalsIgnoreCase(Constants.RULES_ENGINE_DESTINATION_ID)) {
			rulesLender = true;
		}

		// get CV destination
		if (testDealer) {
			product = "TEST_CV";
			destinations = getMockLenderDestination(Constants.MOCK_LENDER_ID);
			for (DeLenderDestinationVO destination : destinations) {
				if (null != destination.getProduct() && destination.getProduct().equalsIgnoreCase(product)
						&& null != destination.getDestinationUrl()) {
					destType = createDestination(destination.getDestinationUrl(), destination.getWsContentType(),
							destination.getWsSoapAction());
					return destType;
				}
			}
		}

		if (isCreditContractDestinationDbDriven()) {
			destinations = getLenderDestinationRecords(testDealer, rulesLender);

			if (null != destinations && !destinations.isEmpty()) {
				for (DeLenderDestinationVO destination : destinations) {
					if (null != destination) {
						if (null != id && id.equalsIgnoreCase(Constants.DESTINATION_ID_EDOCS)) {
							// get destination by product(eDocs)
							if (null != destination.getProduct() && destination.getProduct().equalsIgnoreCase("eDocs")
									&& null != destination.getDestinationUrl()) {
								return createDestination(destination.getDestinationUrl(),
										destination.getWsContentType(), destination.getWsSoapAction());
							}
						} else if (null != id && id.equalsIgnoreCase(Constants.RULES_ENGINE_DESTINATION_ID)) {
							// get destination by product(Rules)
							if (null != destination.getProduct() && destination.getProduct().equalsIgnoreCase("RULES")
									&& null != destination.getDestinationUrl()) {
								return createDestination(destination.getDestinationUrl(),
										destination.getWsContentType(), destination.getWsSoapAction());
							}
						} else {
							// get destination by product(default product CV)
							if (null != destination.getProduct() && destination.getProduct().equalsIgnoreCase(product)
									&& null != destination.getDestinationUrl()) {
								destType = createDestination(destination.getDestinationUrl(),
										destination.getWsContentType(), destination.getWsSoapAction());
								return destType;
							}
						}
					}
				}
			}
		} else {
			if (null != id && id.equalsIgnoreCase(Constants.RULES_ENGINE_DESTINATION_ID)) {
				// get destination by product(Rules)
				for (DeLenderDestinationVO dest : destinations) {
					if (null != dest) {
						if (null != dest.getProduct()
								&& dest.getProduct().equalsIgnoreCase(Constants.RULES_ENGINE_DESTINATION_ID)
								&& null != dest.getDestinationUrl()) {
							return createDestination(dest.getDestinationUrl(), dest.getWsContentType(),
									dest.getWsSoapAction());
						}
					}
				}
			}
			if (null != creditContractDestinations) {
				for (Destination destination : creditContractDestinations) {
					if (destination.getId().equalsIgnoreCase(id)) {
						return destination;
					}
				}
				// destination not found for destinationId
				// retrieve first destination in configuration
				return creditContractDestinations.get(0);
			}
		}
		return null;
	}

	private Destination createDestination(String url, String contentType, String soapAction) {
		logger.debug("Entered createDestination() ");
		Connection connection = new Connection();
		if(url!=null && !url.isEmpty()){
			connection.setUrl(url);
		}
		if(contentType!=null && !contentType.isEmpty()){
			Header header = new Header();
			header.setName("Content-Type");
			header.setType("Content-Type");
			header.setValue(contentType);
			connection.getHeader().add(header);
		}
		if(soapAction!=null && !soapAction.isEmpty()){
			Header header = new Header();
			header.setName("SOAPAction");
			header.setType("SOAPAction");
			header.setValue(soapAction);
			connection.getHeader().add(header);
		}
		Destination destination = new Destination();
		destination.setConnection(connection);
		return destination;
	}

	private boolean isCreditContractMessageProcessingDbDriven() {
		logger.debug("Entered isCreditContractMessageProcessingDbDriven() ");
		if (null == creditContractMessageProcessingIsDbDriven) {
			creditContractMessageProcessingIsDbDriven = false;
			if (null != creditContractMessageProcessing) {
				for (MessageProcessing messageProcessing : creditContractMessageProcessing) {
					if (null != messageProcessing
							&& messageProcessing.getValue().equalsIgnoreCase("featureConfiguration")) {
						creditContractMessageProcessingIsDbDriven = true;
					}
				}
			}
		}
		return creditContractMessageProcessingIsDbDriven;
	}

	private boolean isCreditContractStylesheetDbDriven() {
		logger.debug("Entered isCreditContractStylesheetDbDriven() ");
		if (null == creditContractStylesheetIsDbDriven) {
			creditContractStylesheetIsDbDriven = false;
			if (null != creditContractStylesheetIsDbDriven) {
				for (StyleSheetName stylesheet : creditContractStylesheets) {
					if (null != stylesheet && stylesheet.getValue().equalsIgnoreCase("featureConfiguration")) {
						creditContractStylesheetIsDbDriven = true;
					}
				}
			}
		}
		return creditContractStylesheetIsDbDriven;
	}

	private boolean isAccrStylesheetDbDriven() {
		logger.debug("Entered isAccrStylesheetDbDriven() ");

		if (null == accrStylesheetIsDbDriven) {
			accrStylesheetIsDbDriven = false;
			if (null != accrStylesheetIsDbDriven) {
				for (StyleSheetName stylesheet : accrStylesheets) {
					if (null != stylesheet && stylesheet.getValue().equalsIgnoreCase("featureConfiguration")) {
						accrStylesheetIsDbDriven = true;
					}
				}
			}
		}
		return accrStylesheetIsDbDriven;
	}

	private boolean isCreditContractDestinationDbDriven() {
		logger.debug("Entered isCreditContractDestinationDbDriven() ");
		if (null == creditContractDestinationIsDbDriven) {
			creditContractDestinationIsDbDriven = false;
			if (null != creditContractDestinationIsDbDriven) {
				for (Destination destination : creditContractDestinations) {
					if (null != destination && destination.getId().equalsIgnoreCase("featureConfiguration")) {
						creditContractDestinationIsDbDriven = true;
					}
				}
			}
		}
		return creditContractDestinationIsDbDriven;
	}

	private List<FeatureConfigurationVO> getFeatureConfigurationRecords() {
		logger.debug("Entered getFeatureConfigurationRecords() ");
		if (null == featureConfiguration) {
			if (null != lenderId) {
				featureConfiguration = featureConfigurationRepoServiceImpl.getByLenderId(lenderId);
			}
		}
		return featureConfiguration;
	}

	private List<DeLenderDestinationVO> getLenderDestinationRecords(boolean testDealer, boolean rulesLender) {
		logger.debug("Entered getLenderDestinationRecords() ");
		if (testDealer)
			lenderId = Constants.MOCK_LENDER_ID;
		if (rulesLender)
			lenderId = Constants.RULES_ENGINE_DESTINATION_ID;
		if (null == lenderDestination) {
			if (null != lenderId) {
				lenderDestination = deLenderDestinationRepoServiceImpl.getByLenderId(lenderId, Constants.APP_CV_CODE);
			}
		}
		return lenderDestination;
	}

	private List<DeLenderDestinationVO> getMockLenderDestination(String lenderId) {
		logger.debug("Entered getMockLenderDestination() ");
		lenderDestination = deLenderDestinationRepoServiceImpl.getByLenderId(lenderId, Constants.APP_CV_CODE);
		return lenderDestination;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ProductConfiguration [lenderId=");
		builder.append(lenderId);
		builder.append(", creditContractMessageProcessing=");
		builder.append(creditContractMessageProcessing);
		builder.append(", creditContractMessageProcessingIsDbDriven=");
		builder.append(creditContractMessageProcessingIsDbDriven);
		builder.append(", creditContractStylesheets=");
		builder.append(creditContractStylesheets);
		builder.append(", creditContractStylesheetIsDbDriven=");
		builder.append(creditContractStylesheetIsDbDriven);
		builder.append(", accrStylesheets=");
		builder.append(accrStylesheets);
		builder.append(", accrStylesheetIsDbDriven=");
		builder.append(accrStylesheetIsDbDriven);
		builder.append(", creditContractDestinations=");
		builder.append(creditContractDestinations);
		builder.append(", creditContractDestinationIsDbDriven=");
		builder.append(creditContractDestinationIsDbDriven);
		builder.append(", featureConfiguration=");
		builder.append(featureConfiguration);
		builder.append(", lenderDestination=");
		builder.append(lenderDestination);
		builder.append("]");
		return builder.toString();
	}

}
