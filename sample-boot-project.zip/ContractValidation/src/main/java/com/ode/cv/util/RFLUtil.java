package com.ode.cv.util;

import com.ode.cv.bo.IDmsBO;
import com.ode.cv.dao.DcRflDao;
import com.ode.cv.factory.DmsBOFactory;
import com.ode.cv.service.IDcOtherFormTypePersistenceService;
import com.ode.cv.service.IDmsDocTypePersistenceService;
import com.ode.cv.service.IErrorLogService;
import com.ode.cv.service.IProductConfigurationLookupService;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.service.DcFormRepoService;
import com.ode.persistence.service.DcRFLRepoService;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DcOtherFormTypeVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.DmsDocTypeVO;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

@Component
@EnableTransactionManagement
public class RFLUtil {

	private static final Logger logger = LogManager.getLogger(RFLUtil.class);

	private String attachmentLocation;
	private String maxFileSizeInMB;
	private String maxFileSizeErrorCode;
	private int requiredResolution;
	private String resolutionErrorCode;
	private String retailFormList;
	private String leaseFormList;
	private SimpleDateFormat xmlDateFormat = new SimpleDateFormat("MM-dd-yyyy");

	@Value("${retail.rfl.forms.list}")
	private String retailRFLFormsList;

	@Value("${lease.rfl.forms.list}")
	private String leaseRFLFormsList;

	@Autowired
	private IDmsDocTypePersistenceService dmsDocTypePersistenceService;

	@Autowired
	private DcFormRepoService dcFormRepoService;

	@Autowired
	DcRFLRepoService dcRFLRepoService;

	@Autowired
	private DmsBOFactory dmsBOFactory;

	@Autowired
	private IErrorLogService errorLogService;

	@Autowired
	private IDcOtherFormTypePersistenceService dcOtherFormTypePersistenceService;

	@Autowired
	private DcRflDao dcRflDao;

	@Autowired
	private IProductConfigurationLookupService productConfigurationLookupService;

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	protected Document getDocument(String xml) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));
		return docBuilder.parse(is);
	}

	/**
	 * @param doc
	 * @return
	 */
	public String getStringFromDocument(Document doc) {
		try {
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance("org.apache.xalan.processor.TransformerFactoryImpl",
					org.apache.xalan.processor.TransformerFactoryImpl.class.getClassLoader());
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (TransformerException ex) {
			logger.error("Exception in FrontEndPCCXmlParserImpl.getStringFromDocument()", ex);
			return null;
		}
	}

	/**
	 * In this method DmsBO implementations are generated based on the DSP ID from
	 * incoming request. For example, if DSP ID is AD, an implementation of
	 * CdkDmsBOImpl is created using DmsBOFactory. The implementation class exposes
	 * polymorphic behavior on busniness rules.
	 *
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @throws Exception
	 */
	public void processRflInAccr(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO)
			throws Exception {
		logger.debug("Entered processRFLinAccr() of RFLUtil class");

		List<DcFormVO> formList = new ArrayList<DcFormVO>();
		String dmsId = cvTransmitVO.getDealVO().getDmsId();

		if (productConfigurationLookupService.isFeatureConfigurationAvailable("RFLv1", dmsId)) {
			formList = getFormListForRFLv1(cvTransmitVO);

		} else if (productConfigurationLookupService.isFeatureConfigurationAvailable("RFLv2", dmsId)) {
			formList = getFormListForRFLv2(cvTransmitVO);

		} else if (productConfigurationLookupService.isFeatureConfigurationAvailable("RFLv3", dmsId)) {
			formList = getFormListForRFLv3(cvTransmitVO);

		} else if (productConfigurationLookupService.isFeatureConfigurationAvailable("RFLv4", dmsId)) {
			formList = getFormListForRFLv4(cvTransmitVO);

		} else if (productConfigurationLookupService.isFeatureConfigurationAvailable("RFLv5", dmsId)) {
			formList = getFormListForRFLv5(cvTransmitVO);
		}

		if (cvTransmitVO.isStaticRFLEnabled()) {
			logger.debug("Static RFL flag is enabled. Adding ODE RFL to the list.");
			if (cvTransmitVO.getListOfDcForms() != null && !cvTransmitVO.getListOfDcForms().isEmpty()) {
				logger.debug("Number of Static RFL: {}", cvTransmitVO.getListOfDcForms().size());
				formList.addAll(cvTransmitVO.getListOfDcForms());
			} else {
				logger.debug("Could not find RFL from ODE RulesEngine validation results.");
			}
		}

		logger.debug("Total number of RFL: {}", formList.size());

		if (null != formList && !formList.isEmpty()) {
			createRFLforDeDeal(formList, null, cvTransmitVO);
			IDmsBO dmsBO = dmsBOFactory.createDMS(cvTransmitVO.getDealerInfoVO().getDspId());
			logger.debug("Saving formlist: {}", formList);
			dmsBO.saveRFL(formList, dcFormRepoService, cvTransmitVO);
			cvTransmitVO.getAccrContext().setFormList(formList);
		}
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private List<DcFormVO> getFormListForRFLv1(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered getFormListForRFLv1() ");
		List<DcFormVO> formList = new ArrayList<DcFormVO>();

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(cvTransmitVO.getAccrResponseXml())));

			NodeList flowList = document.getElementsByTagNameNS("http://www.starstandards.org/STAR", "ValidationMessage");
			if(flowList == null || flowList.getLength() == 0) {
				//R1 doesn't always send STAR namespace
				flowList = document.getElementsByTagName("ValidationMessage");
			}
			if(flowList != null && flowList.getLength() != 0) {
				logger.debug("Parsable ValidationMessage nodes found: {}", flowList.getLength());
			} else {
				logger.debug("No parsable ValidationMessage nodes found.");
				return formList;
			}

			for (int i = 0; i < flowList.getLength(); i++) {
				DcFormVO form = new DcFormVO();
				NodeList childList = flowList.item(i).getChildNodes();

				for (int j = 0; j < childList.getLength(); j++) {
					Node childNode = childList.item(j);
					String nodeName = childNode.getNodeName();

					// remove namespace from tag name
					if (nodeName.contains(":")) {
						int colonLocation = nodeName.indexOf(":");
						nodeName = nodeName.substring(colonLocation + 1);
					}
					if (nodeName.equals("Description")) {
						form.setFormComment(childNode.getTextContent().trim());
					}
					if (nodeName.equals("ReasonCode")) {
						form.setFormId(childNode.getTextContent().trim());
					}
					if (nodeName.equals("ReferenceName")) {
						form.setFormName(childNode.getTextContent().trim());
					}
				}

				if (null != form.getFormId() && !form.getFormId().equals("") && !isAStip(form.getFormComment())) {
					formList.add(form);
					logger.debug("dcForm added to list: {}", form);
				}
			}

			List<DcFormVO> stipList = getFormListForStips(cvTransmitVO, flowList);
			if(stipList != null && stipList.isEmpty()) {
				formList.addAll(stipList);
			}

		} catch (Exception e) {
			logger.error("Error occurred during processing RFLv1 forms", e);
			errorLogService.addErrorLog(cvTransmitVO.getDealVO(), cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_V1_PROC_ERROR_CODE,
					Constants.RFL_V1_PROC_ERROR_MSG);
		}
		return formList;
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private List<DcFormVO> getFormListForRFLv2(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered getFormListForRFLv2() method of RFLUtil class");
		List<DcFormVO> formList = new ArrayList<DcFormVO>();

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(cvTransmitVO.getAccrResponseXml())));

			NodeList flowList = document.getElementsByTagNameNS("http://www.starstandards.org/STAR", "ValidationMessage");
			if(flowList == null || flowList.getLength() == 0) {
				//R1 doesn't always send STAR namespace
				flowList = document.getElementsByTagName("ValidationMessage");
			}
			if(flowList != null && flowList.getLength() != 0) {
				logger.debug("Parsable ValidationMessage nodes found: {}", flowList.getLength());
			} else {
				logger.debug("No parsable ValidationMessage nodes found.");
				return formList;
			}

			int dealerProductIterator = 1;

			for (int i = 0; i < flowList.getLength(); i++) {
				String formId = "";
				String description = "";
				NodeList childList = flowList.item(i).getChildNodes();

				for (int j = 0; j < childList.getLength(); j++) {
					Node childNode = childList.item(j);
					String nodeName = childNode.getNodeName();

					// remove namespace from tag name
					if (nodeName.contains(":")) {
						int colonLocation = nodeName.indexOf(":");
						nodeName = nodeName.substring(colonLocation + 1);
					}
					if (nodeName.equals("Description")) {
						description = childNode.getTextContent().trim();
					}
					if (nodeName.equals("ReasonCode")) {
						formId = childNode.getTextContent().trim();
					}
				}

				if (null != formId && formId.startsWith("8") && formId.length() == 5 && !isAStip(description)) {
					DcFormVO dcForm = parseDescriptionIntoDcForm(description);
					dcForm.setFormId(formId);
					if (null != dcForm.getFormName() && dcForm.getFormName().length() > 0) {
						if (dcForm.getFormName().trim().equals("Dealer Product")) {
							dcForm.setFormName("Dealer Product " + dealerProductIterator);
							dealerProductIterator++;
						}
						DmsDocTypeVO dmsDocTypes = dmsDocTypePersistenceService.getDmsDocType(dcForm.getFormName().trim(),
								cvTransmitVO.getPartnerInfoVO().getLenderId(),
								cvTransmitVO.getDealerInfoVO().getDspId());
						logger.debug("dmsDocTypes found: {}", dmsDocTypes);
						setNameAndIdInForm(dcForm, dmsDocTypes);
					}

					formList.add(dcForm);
					logger.debug("dcForm added to list: {}", dcForm);

					for (int j = 0; j < childList.getLength(); j++) {
						Node childNode = childList.item(j);
						String nodeName = childNode.getNodeName();

						// remove namespace from tag name
						if (nodeName.contains(":")) {
							int colonLocation = nodeName.indexOf(":");
							nodeName = nodeName.substring(colonLocation + 1);
						}
						if (nodeName.equals("Description")) {
							description = childNode.getTextContent().trim();
							if (description.startsWith("Dealer Product")) {
								String amount = "";
								if (description.contains("$")) {
									String[] docNameArray = description.split("\\$");
									amount = "$" + docNameArray[1].trim();
								}
								childNode.setTextContent(dcForm.getFormName() + " " + amount);
							}
						}
						if (nodeName.equals("ReasonCode")) {
							childNode.setTextContent(dcForm.getFormId());
						}
					}

					Node rflReferenceNameNode = document.createElement("ReferenceName");
					rflReferenceNameNode.setTextContent("RFL");
					flowList.item(i).appendChild(rflReferenceNameNode);
				}
			}
			String rflXml = CVUtil.getXmlStringFromDocument(document);
			cvTransmitVO.setAccrResponseXml(rflXml);

			List<DcFormVO> stipList = getFormListForStips(cvTransmitVO, flowList);
			if(stipList != null && !stipList.isEmpty()) {
				formList.addAll(stipList);
			}

		} catch (Exception e) {
			logger.error("Error occurred during processing RFLv2 forms", e);
			errorLogService.addErrorLog(cvTransmitVO.getDealVO(), cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_V2_PROC_ERROR_CODE,
					Constants.RFL_V2_PROC_ERROR_MSG);
		}

		return formList;
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private List<DcFormVO> getFormListForRFLv3(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered getFormListForRFLv3() method of RFLUtil class");
		List<DcFormVO> formList = new ArrayList<DcFormVO>();

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(cvTransmitVO.getAccrResponseXml())));

			NodeList flowList = document.getElementsByTagNameNS("http://www.starstandards.org/STAR", "ValidationMessage");
			if(flowList == null || flowList.getLength() == 0) {
				//R1 doesn't always send STAR namespace
				flowList = document.getElementsByTagName("ValidationMessage");
			}
			if(flowList != null && flowList.getLength() != 0) {
				logger.debug("Parsable ValidationMessage nodes found: {}", flowList.getLength());
			} else {
				logger.debug("No parsable ValidationMessage nodes found.");
				return formList;
			}

			for (int i = 0; i < flowList.getLength(); i++) {
				String referenceName = "";
				String description = "";
				String reasonCode = "";
				NodeList childList = flowList.item(i).getChildNodes();

				for (int j = 0; j < childList.getLength(); j++) {
					Node childNode = childList.item(j);

					if (childNode.getNodeName().equals("ReferenceName")) {
						referenceName = childList.item(j).getTextContent().trim();
					}
					if (childNode.getNodeName().equals("Description")) {
						description = childList.item(j).getTextContent().trim();
					}
					if (childNode.getNodeName().equals("ReasonCode")) {
						reasonCode = childList.item(j).getTextContent().trim();
					}
				}

				if (null != referenceName && referenceName.equalsIgnoreCase("RFL") && !isAStip(description)) {
					DcFormVO dcForm = new DcFormVO();

					dcForm.setFormId(reasonCode);
					dcForm.setFormName(description);
					formList.add(dcForm);
					logger.debug("dcForm added to list: {}", dcForm);
				}
			}

			List<DcFormVO> stipList = getFormListForStips(cvTransmitVO, flowList);
			if(stipList != null && !stipList.isEmpty()) {
				formList.addAll(stipList);
			}

		} catch (Exception e) {
			logger.error("Error occurred during processing RFLv3 forms", e);
			errorLogService.addErrorLog(cvTransmitVO.getDealVO(), cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_V3_PROC_ERROR_CODE,
					Constants.RFL_V3_PROC_ERROR_MSG);
		}

		return formList;
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private List<DcFormVO> getFormListForRFLv4(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered getFormListForRFLv4() of RFLUtil class");
		List<DcFormVO> formList = new ArrayList<DcFormVO>();
		String partnerId = cvTransmitVO.getPartnerInfoVO().getLenderId();
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(cvTransmitVO.getAccrResponseXml())));

			NodeList flowList = document.getElementsByTagNameNS("http://www.starstandards.org/STAR", "ValidationMessage");
			if(flowList == null || flowList.getLength() == 0) {
				//R1 doesn't always send STAR namespace
				flowList = document.getElementsByTagName("ValidationMessage");
			}
			if(flowList != null && flowList.getLength() != 0) {
				logger.debug("Parsable ValidationMessage nodes found: {}", flowList.getLength());
			} else {
				logger.debug("No parsable ValidationMessage nodes found.");
				return formList;
			}

			for (int i = 0; i < flowList.getLength(); i++) {
				String description = "";
				String reasonCode = "";
				boolean isRFL = false;
				NodeList childList = flowList.item(i).getChildNodes();

				for (int j = 0; j < childList.getLength(); j++) {
					Node childNode = childList.item(j);

					if (childNode.getLocalName().equals("Description")) {
						description = childList.item(j).getTextContent().trim();
						if (description.startsWith("Required Form-")) {
							isRFL = true;
							description = description.substring(14);
						}
					} else if (childNode.getLocalName().equals("ReasonCode")) {
						reasonCode = childList.item(j).getTextContent().trim();
						reasonCode = reasonCode.substring(reasonCode.length() - 5);
					}
				}

				if (isRFL && !isAStip(description)) {
					if (null != cvTransmitVO.getPartnerInfoVO().getGlobalLenderId()) {
						partnerId = cvTransmitVO.getPartnerInfoVO().getGlobalLenderId();
					}
					DmsDocTypeVO dmsDocTypes = dmsDocTypePersistenceService.getDmsDocType(description,
							cvTransmitVO.getDealerInfoVO().getDspId(), partnerId);
					logger.debug("dmsDocTypes found: {}", dmsDocTypes);
					DcFormVO form = new DcFormVO();
					setNameAndIdInForm(form, dmsDocTypes);
					formList.add(form);
					logger.debug("dcForm added to list: {}", form);
				}

			}

			List<DcFormVO> stipList = getFormListForStips(cvTransmitVO, flowList);
			if(stipList != null && !stipList.isEmpty()) {
				formList.addAll(stipList);
			}

		} catch (Exception e) {
			logger.error("Error occurred during processing RFLv4 forms", e);
			errorLogService.addErrorLog(cvTransmitVO.getDealVO(), cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_V4_PROC_ERROR_CODE,
					Constants.RFL_V4_PROC_ERROR_MSG);
		}
		return formList;
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private List<DcFormVO> getFormListForRFLv5(final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered getFormListForRFLv5() ");
		List<DcFormVO> formList = new ArrayList<DcFormVO>();
		String partnerId = cvTransmitVO.getPartnerInfoVO().getLenderId();

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(cvTransmitVO.getAccrResponseXml())));

			NodeList validationMessageNodes = document.getElementsByTagNameNS("http://www.starstandards.org/STAR", "ValidationMessage");
			if(validationMessageNodes == null || validationMessageNodes.getLength() == 0) {
				//R1 doesn't always send STAR namespace
				validationMessageNodes = document.getElementsByTagName("ValidationMessage");
			}
			if(validationMessageNodes != null && validationMessageNodes.getLength() != 0) {
				logger.debug("Parsable ValidationMessage nodes found: {}", validationMessageNodes.getLength());
			} else {
				logger.debug("No parsable ValidationMessage nodes found.");
				return formList;
			}

			for (int i = 0; i < validationMessageNodes.getLength(); i++) {
				String description = "";
				String referenceName = "";
				NodeList childNodes = validationMessageNodes.item(i).getChildNodes();

				for (int j = 0; j < childNodes.getLength(); j++) {
					Node childNode = childNodes.item(j);
					String localName = childNode.getLocalName();
					logger.debug("localName:{}", localName);
					String nodeName = childNode.getNodeName();
					logger.debug("nodeName:{}", nodeName);

					// remove namespace from tag name
					if (nodeName.contains(":")) {
						int colonLocation = nodeName.indexOf(":");
						nodeName = nodeName.substring(colonLocation + 1);
					}
					if (nodeName.equals("Description")) {
						description = childNode.getTextContent().trim();
					}
					if (nodeName.equals("ReferenceName")) {
						referenceName = childNode.getTextContent().trim();
					}
				}

				if (null != referenceName && referenceName.equalsIgnoreCase("RFL") && !isAStip(description)) {
					// Parse the lender doc name, comment and revision date from
					// the description
					DcFormVO dcForm = parseDescriptionIntoDcForm(description);
					if (null != cvTransmitVO.getPartnerInfoVO().getGlobalLenderId()) {
						partnerId = cvTransmitVO.getPartnerInfoVO().getGlobalLenderId();
					}
					if (null != dcForm.getFormName() && dcForm.getFormName().length() > 0) {
						DmsDocTypeVO dmsDocTypes = dmsDocTypePersistenceService.getDmsDocType(dcForm.getFormName().trim(),
								partnerId, cvTransmitVO.getDealerInfoVO().getDspId());
						logger.debug("dmsDocTypes found: {}", dmsDocTypes);
						setNameAndIdInForm(dcForm, dmsDocTypes);
					}

					//Story 5899 - If dms form Id is not found for certain lender document name, send a random form Id.
					if(StringUtils.isEmpty(dcForm.getFormId())){
						dcForm.setFormId(Constants.OTHER_DOC_TYPE_PREFIX + String.format("%02d", i));
					}
					formList.add(dcForm);
					logger.debug("dcForm added to list: {}", dcForm);
				}
			}

			List<DcFormVO> stipList = getFormListForStips(cvTransmitVO, validationMessageNodes);
			if(stipList != null && !stipList.isEmpty()) {
				formList.addAll(stipList);
			}


		} catch (Exception e) {
			logger.error("Error occurred during processing RFLv5 forms", e);
			errorLogService.addErrorLog(cvTransmitVO.getDealVO(), cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_V5_PROC_ERROR_CODE,
					Constants.RFL_V5_PROC_ERROR_MSG);
		}

		return formList;
	}

	private void storeStipMapping(List<DcOtherFormTypeVO> otherFormList, CVTransmitVO cvTransmitVO) {
		logger.debug("Enter storeStipMapping, deDeal: {}", cvTransmitVO.getDealVO());
		DeDealVO deDeal = cvTransmitVO.getDealVO();

		if(otherFormList != null && !otherFormList.isEmpty()) {
			logger.debug("DcOtherFormType data to insert: {}", otherFormList);
			try {
				//Check for and delete existing stip entries for deal first
				List<DcOtherFormTypeVO> existingEntriesForDeal = dcOtherFormTypePersistenceService.findByDeDealId(deDeal.getDeDealId());
				if(existingEntriesForDeal != null && !existingEntriesForDeal.isEmpty()) {
					logger.debug("Existing OtherFormTypes records found for DeDeal {}, deleting them and storing new records.", deDeal.getDeDealId());
					dcOtherFormTypePersistenceService.deleteForDeDealId(deDeal.getDeDealId());
				}
				//Save to table
				logger.debug("Saving OtherFormTypes: {}", otherFormList);
				dcOtherFormTypePersistenceService.saveOrUpdateAll(otherFormList);
			} catch(Exception e) {
				errorLogService.addErrorLog(deDeal, cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_OTHER_FORM_DB_ERROR_CODE,
						Constants.RFL_OTHER_FORM_DB_ERROR_MSG);
				logger.error("Error occurred while saving DcOtherFormType entries to table.", e);
			}
		} else {
			logger.debug("No DcOtherFormType data to insert.");
		}
	}

	public List<DcFormVO> getFormListForStips(final CVTransmitVO cvTransmitVO, NodeList validationMsgList) {
		logger.debug("Entered getFormListForR1Stips() ");
		List<DcFormVO> formList = new ArrayList<DcFormVO>();

		try {
			List<DcOtherFormTypeVO> otherFormList = new ArrayList<DcOtherFormTypeVO>();
			int otherFormCount = 1;

			for (int i = 0; i < validationMsgList.getLength(); i++) {
				String refName = "";
				String otherFormDesc = "";
				NodeList validationMsgChildList = validationMsgList.item(i).getChildNodes();

				for (int j = 0; j < validationMsgChildList.getLength(); j++) {
					Node childNode = validationMsgChildList.item(j);
					String nodeName = childNode.getNodeName();

					// remove namespace from tag name
					if (nodeName.contains(":")) {
						int colonLocation = nodeName.indexOf(":");
						nodeName = nodeName.substring(colonLocation + 1);
					}
					if (nodeName.equals("Description")) {
						otherFormDesc = childNode.getTextContent().trim();
					}
					if (nodeName.equals("ReferenceName")) {
						refName = childNode.getTextContent().trim();
					}
				}
				logger.debug("Parsing ValidationMessage node - Description:{}, ReferenceName:{}", otherFormDesc, refName);

				if ("RFL".equalsIgnoreCase(refName) && isAStip(otherFormDesc)) {

					logger.debug("Stip found - Description:{}, ReferenceName:{}", otherFormDesc, refName);

					String[] otherFormDescArray = otherFormDesc.split("@");
					String formId = "";
					String lenDocName = otherFormDescArray[1].trim();
					String dmsDocName = "Other" + otherFormCount;

					if (null != lenDocName && lenDocName.length() > 0) {
						logger.debug("DocType Mapping Search - docName:{}, lenderId:{}, dmsId:{}", dmsDocName, cvTransmitVO.getPartnerInfoVO().getLenderId(),
								cvTransmitVO.getDealerInfoVO().getDspId());
						DmsDocTypeVO dmsDocTypes = dmsDocTypePersistenceService.getDmsDocType(dmsDocName,
								cvTransmitVO.getPartnerInfoVO().getLenderId(),
								cvTransmitVO.getDealerInfoVO().getDspId());
						if(null == dmsDocTypes) {
							logger.warn("No DocType mapping for {}, ReasonCode formId will be blank.", dmsDocName);
						} else {
							logger.debug("dmsDocTypes found: {}", dmsDocTypes);
							formId = dmsDocTypes.getDmsFormId();
							logger.debug("DMS Form Id found:{}", formId);
						}
					}

					DcOtherFormTypeVO otherForm = new DcOtherFormTypeVO();
					otherForm.setDeDealId(cvTransmitVO.getDealVO().getDeDealId());
					otherForm.setLenDocName(lenDocName);
					otherForm.setDmsDocName(dmsDocName);
					otherForm.setFormId(formId);
					otherForm.setCreatedBy("CV");
					otherForm.setCreatedTs(new Timestamp(System.currentTimeMillis()));
					otherFormList.add(otherForm);
					logger.debug("DcOtherFormType entry created: {}", otherForm);

					DcFormVO dcForm = new DcFormVO();
					dcForm.setFormId(formId);
					dcForm.setFormName(dmsDocName);
					dcForm.setFormComment(lenDocName);
					formList.add(dcForm);
					logger.debug("DcForm entry created: {}", dcForm);

					otherFormCount++;
				}
			}
			storeStipMapping(otherFormList, cvTransmitVO);
		} catch (Exception e) {
			logger.error("Error while processing stips.", e);
			errorLogService.addErrorLog(cvTransmitVO.getDealVO(), cvTransmitVO.getAccrContext().getBodId(), Constants.TRANS_TYPE_EC_ACK_IN, Constants.RFL_OTHER_FORM_PROC_ERROR_CODE,
					Constants.RFL_OTHER_FORM_PROC_ERROR_MSG);
		}

		return formList;
	}

	/**
	 * @param formList
	 * @param lenderSeqNum
	 * @param cvTransmitVO
	 */
	private void createRFLforDeDeal(final List<DcFormVO> formList, final String lenderSeqNum,
			final CVTransmitVO cvTransmitVO) {
		logger.debug("Entered createRFLforDeDeal(). Size of formList: {}", formList.size());
		String dmsId = cvTransmitVO.getDealerInfoVO().getDspId();
		if ("AD".equals(dmsId)) {
			dmsId = "CDK";
		}
		Timestamp currentTs = new Timestamp(System.currentTimeMillis());
		if (null != formList) {
			// get the RFL sequenceid from the DC_FORM table
			String rflSequenceId = dcFormRepoService.getDcFormRFLSequenceIdSql(cvTransmitVO.getDealVO().getDeDealId());
			if (null != rflSequenceId && rflSequenceId.length() >= 3) {
				// Determine the next rfl sequence id
				Integer largestSequence = 0;
				int sequence = Integer.parseInt(rflSequenceId.substring(2));
				if (sequence > largestSequence) {
					logger.debug("larger sequence found:{}", sequence);
					largestSequence = sequence;
				}
				largestSequence = largestSequence + 1;
				String seqIdNum = "";
				if (largestSequence < 10) {
					seqIdNum = "0" + largestSequence.toString();
				} else {
					seqIdNum = largestSequence.toString();
				}
				rflSequenceId = "RF" + seqIdNum;
			} else {
				rflSequenceId = "RF00";
			}


			try {
				/*Add a new DC_RFL record if one with the DE_DEAL_ID and RFL_SEQ_ID does not exist*/
				Boolean dcRflResult = dcRflDao.addDcRfl(cvTransmitVO, rflSequenceId, currentTs);
				if (!dcRflResult.TRUE) {
					logger.debug(
							"There was an error saving DC_RFL entry with Deal ID ({}) and Sequence ID ({})."
									+ " addDcRfl() returned: {}.",
									cvTransmitVO.getDealVO().getDeDealId(), rflSequenceId, dcRflResult);
				}
			} catch (Exception e1) {
				logger.debug("Exception caught trying to insert DC_RFL record", e1);
			}
			for (int i = 0; i < formList.size(); i++) {
				try {
					if(null != formList.get(i)) {
						DcFormVO form = formList.get(i);
						try {
							form.setDeDealId(cvTransmitVO.getDealVO().getDeDealId());
							form.setRflSequenceId(rflSequenceId);
							form.setLenderSeqNum(lenderSeqNum);
							form.setLenderReceivedDate(currentTs);
							form.setCreatedTs(currentTs);
							form.setCreatedBy(Constants.APP_CV_CODE);
						} catch (Exception exp) {
							logger.error(exp);
						}
					}
				} catch (Exception e) {// catch for loop
					logger.error(e);
				}
			} // end for loop
		}
	}

	/**
	 * @param form
	 * @param dmsDocTypes
	 */
	private void setNameAndIdInForm(final DcFormVO form, final DmsDocTypeVO dmsDocTypes) {
		logger.debug("Entered setNameAndIdInForm() " + form);

		if (null != dmsDocTypes) {
			if(null != dmsDocTypes.getDocName() && !dmsDocTypes.getDocName().isEmpty()) {
				form.setFormName(dmsDocTypes.getDocName());
			} else {
				logger.warn("No value in Table for dmsDocTypes.getDocName()! DB entry:{}", dmsDocTypes);
				form.setFormName(""); //Prevent null pointers in the flow
			}

			if(null != dmsDocTypes.getDmsFormId() && !dmsDocTypes.getDmsFormId().isEmpty()) {
				form.setFormId(dmsDocTypes.getDmsFormId());
			} else {
				logger.warn("No value in Table for dmsDocTypes.getDmsFormId()! DB entry:{}", dmsDocTypes);
				form.setFormId(""); //Prevent null pointers in the flow
			}
		}
	}

	/**
	 * @return
	 */
	public List<DcFormVO> getStaticRFLList(final CreditContractVO creditContractVO) {
		logger.debug("Entered getStaticRFLList(financeType) method of RFLUtil class. financeType: {}",
				creditContractVO.getFinanceType());
		List<DcFormVO> listOfDcForms = new ArrayList<>();
		String strRfLFormsList;
		if (Constants.STAR_FINANCE_TYPE_RETAIL.equals(creditContractVO.getFinanceType())) {
			strRfLFormsList = retailRFLFormsList;
		} else {
			strRfLFormsList = leaseRFLFormsList;
		}
		String[] rflFormsArray = null != strRfLFormsList ? strRfLFormsList.split(",") : new String[0];
		int rflFormsArraySize = rflFormsArray.length;
		for (int i = 0; i < rflFormsArraySize; i++) {
			String[] formDetailArray = rflFormsArray[i].split(":");
			DcFormVO dcFormBO = new DcFormVO();
			dcFormBO.setFormId(formDetailArray[0]);
			dcFormBO.setFormName(formDetailArray[1]);
			listOfDcForms.add(dcFormBO);
		}
		return listOfDcForms;

	}

	/**
	 * @param formList
	 * @return
	 */
	public String createRFLXmlFromLenderFormsList(final List<DcFormVO> formList) {
		logger.debug("Entered createRFLXmlFromLenderFormsList() method of RFLUtil class. Size of formList: {}",
				formList.size());
		logger.debug("FormList to process: {}", formList);
		StringBuilder rflXml = new StringBuilder();
		rflXml.append("<RequiredFormList>");

		final Comparator<DcFormVO> comparator = new Comparator<DcFormVO>() {
			@Override
			public int compare(DcFormVO vo1, DcFormVO vo2) {
				return vo1.getFormId().compareTo(vo2.getFormId());
			}
		};

		final List<DcFormVO> sortedFormList = formList.stream().sorted(comparator).collect(Collectors.toList());

		for (DcFormVO dcFormVO : sortedFormList) {
			if (dcFormVO != null) {
				rflXml.append("<ValidationMessage><Description>");

				if (dcFormVO.getFormComment() != null) {
					rflXml.append(dcFormVO.getFormComment().trim());
				}
				rflXml.append("</Description>");
				rflXml.append("<ReferenceName>");
				if (dcFormVO.getFormName() != null) {
					rflXml.append(dcFormVO.getFormName().trim());
				}
				rflXml.append("</ReferenceName>");
				rflXml.append("<ReasonCode>");
				if (dcFormVO.getFormId() != null) {
					rflXml.append(dcFormVO.getFormId().trim());
				}
				rflXml.append("</ReasonCode></ValidationMessage>");
			}
		}
		rflXml.append("</RequiredFormList>");
		logger.debug("RequiredFormList string: {}", rflXml.toString());
		return rflXml.toString();
	}

	/**
	 * @param description
	 * @return
	 */
	private DcFormVO parseDescriptionIntoDcForm(String description) {
		logger.debug("Entered parseDescriptionIntoDcForm() " + description);
		Date date;
		String comment = "";
		DcFormVO form = new DcFormVO();
		form.setRequiredFormFlag("Y");
		try {
			if (description.contains("|")) {
				String[] descriptionArray = description.split("\\|");
				if (descriptionArray[0].contains("$")) {
					logger.info("Form Description: {} ", description);
					String[] docNameArray = descriptionArray[0].split("\\$");
					comment = "$" + docNameArray[1].trim();
					form.setFormName(docNameArray[0]);
				} else {
					form.setFormName(descriptionArray[0]);
				}
				if (descriptionArray.length > 1) {
					if (descriptionArray[1].contains(":")) {// check if the form number has revision date
						String[] productFormArray = descriptionArray[1].split(":");
						form.setProductFormName(productFormArray[0].trim());
						if (comment.startsWith("$")) {
							comment = comment + ". " + productFormArray[0].trim();// Adding form number after the amount
							// to the comment
						} else {
							comment = productFormArray[0].trim();
						}
						if (productFormArray.length > 1) {
							try {
								date = xmlDateFormat.parse(productFormArray[1]);
								java.sql.Date sql = new java.sql.Date(date.getTime());
								form.setProductFormVersionDate(sql);
							} catch (ParseException e) {
								logger.error(e);
							}
						}
					} else {
						// set the form number
						form.setProductFormName(descriptionArray[1].trim());
						comment = descriptionArray[1].trim();
					}
				}
				form.setFormComment(comment);
				// if no pipe delimiter found
			} else if (description.contains("$")) {
				String[] docNameArray = description.split("\\$");
				form.setFormComment("$" + docNameArray[1].trim());
				form.setFormName(docNameArray[0]);
				// if no delimiter found
			} else {
				form.setFormName(description.trim());
			}
		} catch (Exception e) {
			logger.error(e);
		}
		return form;
	}

	private static boolean isAStip(String description) {
		if(null != description && description.contains("@")) {
			logger.debug("Stip found for description: {}", description);
			return true;
		}
		logger.debug("Not a stip: {}", description);
		return false;
	}

	public String getAttachmentLocation() {
		return attachmentLocation;
	}

	public void setAttachmentLocation(String attachmentLocation) {
		this.attachmentLocation = attachmentLocation;
	}

	public String getMaxFileSizeInMB() {
		return maxFileSizeInMB;
	}

	public void setMaxFileSizeInMB(String maxFileSizeInMB) {
		this.maxFileSizeInMB = maxFileSizeInMB;
	}

	public String getMaxFileSizeErrorCode() {
		return maxFileSizeErrorCode;
	}

	public void setMaxFileSizeErrorCode(String maxFileSizeErrorCode) {
		this.maxFileSizeErrorCode = maxFileSizeErrorCode;
	}

	public String getResolutionErrorCode() {
		return resolutionErrorCode;
	}

	public void setResolutionErrorCode(String resolutionErrorCode) {
		this.resolutionErrorCode = resolutionErrorCode;
	}

	public int getRequiredResolution() {
		return requiredResolution;
	}

	public void setRequiredResolution(int requiredResolution) {
		this.requiredResolution = requiredResolution;
	}

	public String getRetailFormList() {
		return retailFormList;
	}

	public void setRetailFormList(String retailFormList) {
		this.retailFormList = retailFormList;
	}

	public String getLeaseFormList() {
		return leaseFormList;
	}

	public void setLeaseFormList(String leaseFormList) {
		this.leaseFormList = leaseFormList;
	}

}