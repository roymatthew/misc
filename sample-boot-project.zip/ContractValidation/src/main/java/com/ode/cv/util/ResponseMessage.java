/*
 * Created on Mar 5, 2009
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.methods.RequestEntity;

import com.ode.dlr.lp.util.schema.config.ConnectionType;

/**
 * @author biswass
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ResponseMessage {
	
	private ConnectionType conTypeConfig = null;
	private String responseXml = null;
	private Cookie[] cookies = null;
	private String messageProcessing = null;
	private RequestEntity requestentity = null;
	private Header responseHeader = null;
	private int statusCode = 0;

	/**
	 * @return Returns the cookie.
	 */
	public Cookie[] getCookies() {
		return cookies;
	}
	/**
	 * @param cookie The cookie to set.
	 */
	public void setCookies(Cookie[] cookies) {
		this.cookies = cookies;
	}
	/**
	 * @return Returns the messageProcessing.
	 */
	public String getMessageProcessing() {
		return messageProcessing;
	}
	/**
	 * @param messageProcessing The messageProcessing to set.
	 */
	public void setMessageProcessing(String messageProcessing) {
		this.messageProcessing = messageProcessing;
	}
	/**
	 * @return Returns the requestentity.
	 */
	public RequestEntity getRequestentity() {
		return requestentity;
	}
	/**
	 * @param requestentity The requestentity to set.
	 */
	public void setRequestentity(RequestEntity requestentity) {
		this.requestentity = requestentity;
	}
	/**
	 * @return Returns the responseHeader.
	 */
	public Header getResponseHeader() {
		return responseHeader;
	}
	/**
	 * @param responseHeader The responseHeader to set.
	 */
	public void setResponseHeader(Header responseHeader) {
		this.responseHeader = responseHeader;
	}
	/**
	 * @return Returns the responseXml.
	 */
	public String getResponseXml() {
		return responseXml;
	}
	/**
	 * @param responseXml The responseXml to set.
	 */
	public void setResponseXml(String responseXml) {
		this.responseXml = responseXml;
	}
	/**
	 * @return Returns the conTypeConfig.
	 */
	public ConnectionType getConTypeConfig() {
		return conTypeConfig;
	}
	/**
	 * @param conTypeConfig The conTypeConfig to set.
	 */
	public void setConTypeConfig(ConnectionType conTypeConfig) {
		this.conTypeConfig = conTypeConfig;
	}
	/**
	 * @return Returns the statusCode.
	 */
	public int getStatusCode() {
		return statusCode;
	}
	/**
	 * @param statusCode The statusCode to set.
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseMessage [statusCode=");
		builder.append(statusCode);
		builder.append(", ");
		if (responseXml != null) {
			builder.append("responseXml=");
			builder.append(responseXml.replaceAll("[\r\n]+", " "));
		}
		builder.append("]");
		return builder.toString();
	}
	
}
