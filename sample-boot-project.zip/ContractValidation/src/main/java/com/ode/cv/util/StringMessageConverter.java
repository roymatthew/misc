package com.ode.cv.util;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

public class StringMessageConverter implements MessageConverter {
	
	private  final String pgm = getClass().getName();

	public Message toMessage(Object arg0, Session session) throws JMSException, MessageConversionException {
		String input = (String)arg0;
		ObjectMessage message = session.createObjectMessage();
		//input.setNumberOfAttempt(input.getNumberOfAttempt() + 1);
		message.setObject(input);
		//message.setLongProperty("TranId",input.getTranId());
		//message.setLongProperty("NumberOfAttempt",input.getNumberOfAttempt());
		return message;
	}

	public Object fromMessage(Message arg0) throws JMSException,
			MessageConversionException {
		ObjectMessage message = (ObjectMessage)arg0;
		return message;		
		
	}

}
