/*
 * Created on Apr 8, 2010
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ode.cv.util.transmit.client;

import com.ode.cv.vo.CVInputVO;

/**
 * @author rmathew
 * Originally from LP application code base.
 *
 */
public interface AppHttpClient {
	public void sendMsgToDestination(final CVInputVO cvInputVO, final String transType) throws Exception;
}
