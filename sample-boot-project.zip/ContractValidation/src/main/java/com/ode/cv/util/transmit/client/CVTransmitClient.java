package com.ode.cv.util.transmit.client;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBException;

import com.ode.cv.vo.OdeTokenResponseVO;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.w3c.dom.Document;

import com.adp.dealerservices.loanprocessing.Connection;
import com.adp.dealerservices.loanprocessing.Destination;
import com.adp.dealerservices.loanprocessing.Header;
import com.ode.commons.util.security.SecureTransmissionUtil;
import com.ode.commons.util.vo.CommonsUtilNvpVO;
import com.ode.cv.exception.AppHttpException;
import com.ode.cv.factory.JournalFactory;
import com.ode.cv.service.ICVJournalService;
import com.ode.cv.service.IProductConfigurationLookupService;
import com.ode.cv.util.AppHttpUtility;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.ApplpSOAPUtility;
import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.util.HttpTransmitUtil;
import com.ode.cv.util.ResponseMessage;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.JournalObjectVO;
import com.ode.cv.vo.RouteOneHeaderRequest;
import com.ode.cv.vo.RouteOneHeaderResponse;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.service.ApplicationPropertiesRepoService;
import com.ode.persistence.service.DeDmsDestinationRepoService;
import com.ode.persistence.vo.ApplicationPropertiesVO;
import com.ode.persistence.vo.DeDmsDestinationVO;
import com.ode.persistence.vo.DeLenderDestinationVO;
import com.ode.persistence.vo.DePartnerDestinationVO;

/**
 * @author rmathew
 *
 */
@Profile({ "dev", "qa", "stage", "prod" })
@Component
public class CVTransmitClient implements Constants {

	private static final Logger logger = LogManager.getLogger(CVTransmitClient.class);
	@Autowired
	private AppHttpUtility httpUtil;
	@Autowired
	private ApplpEventHandler appeventHandler;
	@Autowired
	private IProductConfigurationLookupService iProductConfigurationLookupService;
	@Autowired
	private ICVJournalService cvJournalService;
	@Autowired
	private ApplicationPropertiesRepoService applicationPropertiesRepoService;
	@Value("${commonServiceBaseURL}")
	private String commonServiceBaseUrl;
	@Value("${uriPathForRouteOneFlag}")
	private String uriPathForRouteOneFlag;
	@Value("${commonServiceURLAdvent}")
	private String commonServiceURLAdvent;
	@Value("${commonServiceURLIntegrationFlag}")
	private String commonServiceURLIntegrationFlag;
	@Value("${commonServiceURLDefiToken}")
	private String commonServiceURLDefiToken;
	private RestTemplate restTemplate;

	@Autowired
	private DeDmsDestinationRepoService deDmsDestinationRepoService;

	public CVTransmitClient() {
		super();
	}

	/**
	 * @param cvTransmitVO
	 * @param destinationId
	 * @throws Exception
	 */
	public void sendTranslatedXMLToLTE(final CVTransmitVO cvTransmitVO, final CreditContractVO creditContractVO,
			final String destinationId) throws Exception {

		logger.debug("Enter sendTranslatedXMLToLTE() method in CVTransmitClient class");
		logger.debug(creditContractVO.getDealerInfo());
		logger.debug(creditContractVO.getPartnerInfo());
		Connection lteConnection = getLTEDestination(cvTransmitVO).getConnection();
		logger.debug("sendTranslatedXMLToLTE :: LTE Connection URL:" + lteConnection.getUrl());

		try {
			ResponseMessage responseMessage = httpUtil.sendMsgToDestinationAndGetResponseMsg(lteConnection,
					cvTransmitVO.getLenderRequestXml());
			cvTransmitVO.setAccrResponseXml(responseMessage.getResponseXml());
			cvTransmitVO.setAccrResponseMessage(responseMessage);
			logger.debug("AccrResponseXml from LTE: " + cvTransmitVO.getAccrResponseXml().replaceAll("[\r\n]+", " "));

		} catch (final Exception e) {
			logger.error("Exception caught when sending translated XML to LTE ", e);
			processPCCOutException(e, cvTransmitVO, creditContractVO, TRANS_TYPE_EC_OUT);
		}
	}

	/**
	 * @param cvTransmitVO
	 * @return Destination
	 */
	private Destination getLTEDestination(final CVTransmitVO cvTransmitVO) {
		logger.debug("Enter getLTEDestination() method of CVTransmitClient class");

		ApplicationPropertiesVO applicationPropertiesVO = applicationPropertiesRepoService
				.getByApplicationNameAndPropertyName(Constants.APP_CV_CODE, Constants.LTE_ENDPOINT);

		if (null != applicationPropertiesVO) {
			logger.debug("DestinationURL: {}", applicationPropertiesVO.getPropertyValue());
		} else {
			logger.debug("Could not load LTE ENDPOINT for CV");
		}
		return createDestination(applicationPropertiesVO.getPropertyValue(), "application/xml", null);
	}

	/**
	 * @param creditContractVO
	 * @param destinationId
	 * @throws Exception
	 */
	public ECConfinVO sendTranslatedXMLToRE(final CreditContractVO creditContractVO, final String destinationId)
			throws Exception {

		logger.debug("Enter sendTranslatedXMLToRE() method in CVTransmitClient class");
		logger.debug("DealerInfo: {}", creditContractVO.getDealerInfo());
		logger.debug("PartnerInfo: {}", creditContractVO.getPartnerInfo());
		logger.debug("FinanceType: {}", creditContractVO.getFinanceType());
		Connection reConnection = getREDestination().getConnection();
		ECConfinVO rEResponse = new ECConfinVO();

		try {
			ResponseMessage responseMessage = httpUtil.sendMsgToDestinationAndGetResponseMsg(reConnection,
					creditContractVO.getLenderRequestXml());
			logger.debug("Response message from Rules Engine: " + responseMessage);
			rEResponse.setStatusCode(responseMessage.getStatusCode());
			String reResponseXml = responseMessage.getResponseXml();
			if (!reResponseXml.startsWith(Constants.XML_PROLOG)) {
				reResponseXml = Constants.XML_PROLOG + reResponseXml;
			}
			rEResponse.setRequestXML(reResponseXml);

		} catch (final Exception e) {
			logger.error("Exception caught when sending translated XML to RE ", e);
		}
		return rEResponse;
	}

	/**
	 * @return
	 */
	private Destination getREDestination() {
		logger.debug("Entered getREDestination() method of CVTransmitClient class");

		ApplicationPropertiesVO applicationPropertiesVO = applicationPropertiesRepoService
				.getByApplicationNameAndPropertyName(Constants.APP_CV_CODE, Constants.RE_ENDPOINT);

		if (null != applicationPropertiesVO) {
			logger.debug("DestinationURL: {}", applicationPropertiesVO.getPropertyValue());
		} else {
			logger.debug("Could not load RE ENDPOINT for CV");
		}
		return createDestination(applicationPropertiesVO.getPropertyValue(), "application/xml", null);
	}

	/**
	 * @param cvTransmitVO
	 * @param destinationId
	 * @return
	 */
	private Destination getDestinationCreditContract(final CVTransmitVO cvTransmitVO, final String destinationId) {
		logger.debug("Enter getDestinationCreditContract() destinationId: " + destinationId);
		final DeLenderDestinationVO destinationVO = iProductConfigurationLookupService.getCVDestination(
				cvTransmitVO.getDestinationProductId(), cvTransmitVO.getPartnerInfoVO().getLenderId());

		if (null != destinationVO) {
			logger.debug("DestinationURL: " + destinationVO.getDestinationUrl());
		} else {
			logger.debug("Could not find DeLenderDestinationVO for product: " + cvTransmitVO.getDestinationProductId()
					+ " and lenderId: " + cvTransmitVO.getPartnerInfoVO().getLenderId());
		}
		return createDestination(destinationVO.getDestinationUrl(), destinationVO.getWsContentType(),
				destinationVO.getWsSoapAction());
	}

	/**
	 * @param url
	 * @param contentType
	 * @param soapAction
	 * @return
	 */
	private Destination createDestination(final String url, final String contentType, final String soapAction) {

		logger.debug("Entered createDestination() method of CVTransmitClient class");
		Connection connection = new Connection();
		if (url != null && !url.isEmpty()) {
			connection.setUrl(url);
		}
		if (contentType != null && !contentType.isEmpty()) {
			Header header = new Header();
			header.setName("Content-Type");
			header.setType("Content-Type");
			header.setValue(contentType);
			connection.getHeader().add(header);
		}
		if (soapAction != null && !soapAction.isEmpty()) {
			Header header = new Header();
			header.setName("SOAPAction");
			header.setType("SOAPAction");
			header.setValue(soapAction);
			connection.getHeader().add(header);
		}
		Destination destination = new Destination();
		destination.setConnection(connection);
		return destination;
	}

	/**
	 * @param appHttpException
	 * @param cvTransmitVO
	 * @param creditContractVO
	 * @param transType
	 * @throws Exception
	 */
	private void processPCCOutException(final Exception appHttpException, final CVTransmitVO cvTransmitVO,
			final CreditContractVO creditContractVO, final String transType) throws Exception {
		logger.debug("Entered processPCCOutException() method of CVTransmitClient class");
		String errorMessage = "Posting translated XML to Rules Engine failed: ";
		AppMessage appMsg;
		String soapFaultStr = " ";
		String soapFaultMsg = "";
		Document document = null;
		if (appHttpException instanceof AppHttpException) {

			if (null != ((AppHttpException) appHttpException).getSoapFaultMsg()) {
				soapFaultMsg = ((AppHttpException) appHttpException).getSoapFaultMsg();
				if (soapFaultMsg.indexOf(FAULT_STRING) > -1) {
					document = new ApplpSOAPUtility().getSOAPDocument(soapFaultMsg);
					soapFaultStr = new ApplpSOAPUtility().getSOAPDetail(document, FAULT_STRING);
					cvTransmitVO.setSoapFaultCode(new ApplpSOAPUtility().getSOAPDetail(document, FAULT_CODE));
					cvTransmitVO.setSoapFaultMessage(new ApplpSOAPUtility().getSOAPDetail(document, DETAIL));
					document = null;
				}

			} // if

			AppMessage temp = appeventHandler.handleEvents("AppHttpException");
			appMsg = new AppMessage(temp.getMessageID(), temp.getMessage(), null, temp.getLoggingtype(),
					temp.isOverrideron(), temp.isEventvieweron(), temp.isTraceind());
			// set AppMessage to the faultstring if overrideInd is true
			if (transType.equals(TRANS_TYPE_EC_OUT) && null != cvTransmitVO.getSoapFaultCode()
					&& cvTransmitVO.getSoapFaultCode().equalsIgnoreCase("XE9999")) {
				appMsg.setMessage(soapFaultStr);

			}

		} // if AppHttpException
		else {
			appMsg = appeventHandler.handleEvents("AppException");
		}

		cvTransmitVO.setAppMessage(appMsg);
		if (transType.equals(TRANS_TYPE_EC_OUT)) {
			if (!soapFaultMsg.equals("")) {
				JournalObjectVO journalObject = JournalFactory.createJournalObject(TRANS_TYPE_EC_CONF_IN, appMsg,
						soapFaultMsg);
				cvJournalService.addJournal(creditContractVO, journalObject);
			}
			cvTransmitVO.setLenderResponseXml(soapFaultMsg);
			logger.debug(errorMessage + cvTransmitVO.getLenderResponseXml());
		} else {
			cvTransmitVO.setResponseXml(soapFaultMsg);
			logger.debug(errorMessage + cvTransmitVO.getResponseXml());
		}
	}

	/**
	 * @param cvTransmitVO
	 * @param dmsId
	 * @throws Exception
	 */
	public void sendXmlOutputToDms(final CVTransmitVO cvTransmitVO, String dmsId) throws Exception {
		logger.debug("Entered sendXmlOutputToDms() method in CVTransmitClient class");

		try {
			sendToDMS(cvTransmitVO, dmsId);

		} catch (Exception exp) {
			logger.error("", exp);
			processDMSOutException(exp, cvTransmitVO);
		}
	}

	/**
	 * @param cvTransmitVO
	 * @param dmsId
	 * @throws Exception
	 */
	private void sendToDMS(final CVTransmitVO cvTransmitVO, final String dmsId) throws Exception {
		logger.debug("Entered sendToDMS() method in CVTransmitClient class. dmsId: {}", dmsId);
		Connection conTypeConfig = getDestinationDMS(cvTransmitVO, dmsId).getConnection();
		if (conTypeConfig != null) {
			ResponseMessage responseMessage = httpUtil.sendMsgToDestinationAndGetResponseMsg(conTypeConfig,
					cvTransmitVO.getAccroutXml());
			cvTransmitVO.setResponseXml(responseMessage.getResponseXml());
			httpUtil.processHttpStatusCodeAndMessage(cvTransmitVO, responseMessage);
			if (cvTransmitVO.getResponseXml() == null || cvTransmitVO.getResponseXml().equals("")) {
				cvTransmitVO
						.setResponseXml("<Response>Sent Credit Contract Acknowledgment to "
								+ (cvTransmitVO.getDealerInfoVO().getDspId().equalsIgnoreCase("AD") ? "ADP Credit"
										: cvTransmitVO.getDealerInfoVO().getDspId().equalsIgnoreCase("RR") ? "Reynolds"
												: cvTransmitVO.getDealerInfoVO().getDspId())
								+ " Successfully</Response>");
			}
		} else {
			logger.error("DMS Connection was null for DMS {}", dmsId);
		}
	}

	/**
	 * @param cvTransmitVO
	 * @param dmsId
	 * @return
	 * @throws FileNotFoundException
	 * @throws JAXBException
	 */
	@SuppressWarnings("rawtypes")
	private Destination getDestinationDMS(final CVTransmitVO cvTransmitVO, final String dmsId)
			throws FileNotFoundException, JAXBException {

		logger.debug("Entered getDestinationDMS() method in CVTransmitClient class. dmsId: {}", dmsId);
		List<DeDmsDestinationVO> deDmsDestinationVOS = deDmsDestinationRepoService.selectSpecificDmsDestination(dmsId,
				"CV", "CV");
		if (deDmsDestinationVOS != null) {
			DeDmsDestinationVO deDmsDestinationVO = deDmsDestinationVOS.get(0);
			return createDestination(deDmsDestinationVO.getDestinationUrl(), deDmsDestinationVO.getWsContentType(),
					deDmsDestinationVO.getWsSoapAction());
		}
		return null;
	}

	/**
	 * @param ex
	 * @param cvTransmitVO
	 * @throws Exception
	 */
	private void processDMSOutException(final Exception ex, final CVTransmitVO cvTransmitVO) throws Exception {
		logger.debug("Entered processDMSOutException() method in CVTransmitClient class");
		AppMessage appMsg;

		if (ex instanceof AppHttpException) {
			AppMessage temp = appeventHandler.handleEvents("AppHttpException");
			appMsg = new AppMessage(temp.getMessageID(), temp.getMessage(), null, temp.getLoggingtype(),
					temp.isOverrideron(), temp.isEventvieweron(), temp.isTraceind());
		} else {
			appMsg = appeventHandler.handleEvents("AppException");
		}

		cvTransmitVO.setAppMessage(appMsg);
		cvTransmitVO.setResponseXml(appMsg.getMessage());
		logger.debug(cvTransmitVO.getResponseXml());

		if (cvTransmitVO.getResponseXml() == null || appMsg.getMessageID()
				.equalsIgnoreCase(appeventHandler.handleEvents("AppHttpException").getMessageID())) {
			cvTransmitVO.setResponseXml("<Response>Failed to Send Credit Contract Acknowledgment to "
					+ (cvTransmitVO.getDealerInfoVO().getDspId().equalsIgnoreCase("AD") ? "ADP Credit"
							: cvTransmitVO.getDealerInfoVO().getDspId().equalsIgnoreCase("RR") ? "Reynolds"
									: cvTransmitVO.getDealerInfoVO().getDspId() + "</Response>"));
		}
		cvTransmitVO.setAppMessage(appMsg);

	}

	/**
	 * @param requestXml
	 * @param creditContractVO
	 * @param dePartnerDestinationVO
	 * @param authorizationId
	 * @return
	 * @throws Exception
	 */
	public String postCVToRouteOneWithDynamicHeaders(final CreditContractVO creditContractVO, final String requestXml,
			final DePartnerDestinationVO dePartnerDestinationVO, final String authorizationId,
			final ECConfinVO ecConfinVO) throws Exception {

		logger.debug("Entered postCVToRouteOneWithDynamicHeaders() method of CVTransmitClient class");

		String routeOneURL = "";
		int statusCode = 0;
		HttpPost post = null;
		String responseBody = "";
		try {
			String currentDate = HttpTransmitUtil.getCurrentDate();
			routeOneURL = dePartnerDestinationVO.getDestinationUrl() + URL_APPENDAGE_VALIDATE;
			post = new HttpPost(routeOneURL);
			StringEntity requestBody = new StringEntity(requestXml);
			post.setEntity(requestBody);
			// String canonicalizedHeaders =
			// HttpTransmitUtil.buildCanonicalizedHeaders(inputForRouteOneRequestHeader);
			String commonServiceURL = commonServiceBaseUrl + "/routeoneHMACHeaders";
			ParameterizedTypeReference<RouteOneHeaderResponse> typeRef = new ParameterizedTypeReference<RouteOneHeaderResponse>() {
			};

			// Request
			RouteOneHeaderRequest request = new RouteOneHeaderRequest();
			request.setXml(requestXml);
			request.setURL(post.getURI().getPath());
			request.setDealerId(creditContractVO.getDeal().getDmsDealerId());
			request.setPartnerId(creditContractVO.getDeal().getLenderId());
			request.setDealerProductId(Constants.PRODUCT_CV);
			// setting the partner product id below just to pass common service validation
			request.setPartnerProductId(Constants.PRODUCT_CV);
			request.setDmsId(creditContractVO.getDealerInfo().getDspId());
			request.setAuthorizationId(authorizationId);
			request.setVerb(post.getMethod());
			logger.debug("Getting HMAC headers from CommonService at: " + commonServiceURL);

			Map<String, String> hmacHeaders = null;
			ResponseEntity<RouteOneHeaderResponse> responseEntity = null;
			RouteOneHeaderResponse response = null;
			try {
				restTemplate = new RestTemplate();
				responseEntity = restTemplate.exchange(commonServiceURL, HttpMethod.POST, new HttpEntity<>(request),
						typeRef);
				response = responseEntity.getBody();
				hmacHeaders = response.getHeaders();
			} catch (Exception e) {
				logger.debug("Exception occured when submitting request to common service for RouteOne headers.", e);
			}

			if (null == responseEntity || HttpStatus.OK != responseEntity.getStatusCode() || null == hmacHeaders
					|| null == response || !response.isSuccess()) {
				logger.debug(
						"Failed to obtain hmacHeaders from common service for deal# {}, dealerId: {} and lenderId: {}",
						creditContractVO.getDeal().getDmsDealNum(), creditContractVO.getDeal().getDmsDealerId(),
						creditContractVO.getDeal().getLenderId());
				return null;
			}

			Set entrySet = hmacHeaders.entrySet();
			Iterator it = entrySet.iterator();
			String key = null;
			String value = null;
			String contentMD5FromHeader = "";
			while (it.hasNext()) {
				Map.Entry entry = (Map.Entry) it.next();
				key = (String) entry.getKey();
				value = (String) entry.getValue();
				logger.debug("--> " + key + " : " + value);
				if ("Content-MD5".equals(key)) {
					contentMD5FromHeader = value;
				}
				post.addHeader(new BasicHeader(key, value));
			}

			String contentMD5 = CVUtil.calculateMD5(requestXml.trim());
			logger.debug("..contentMD5FromHeader: {}", contentMD5FromHeader);
			logger.debug("............contentMD5: {}", contentMD5);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse httpResponse = client.execute(post);

			if (null != httpResponse) {

				statusCode = httpResponse.getStatusLine().getStatusCode();
				logger.debug("StatusCode: {}", statusCode);
				ecConfinVO.setStatusCode(statusCode);

				try (BufferedReader buffer = new BufferedReader(
						new InputStreamReader(httpResponse.getEntity().getContent()))) {
					responseBody = buffer.lines().collect(Collectors.joining(" "));
				}
				if (statusCode == HttpStatus.OK.value() || statusCode == HttpStatus.ACCEPTED.value()) {
					logger.debug("**** Successfully posted CV to RouteOne. statusCode: {} ****", statusCode);
					responseBody = Constants.OPERATION_SUCCESS_MESSSAGE;
				} else {
					if (StringUtils.isBlank(responseBody)) {
						responseBody = Constants.OPERATION_FAILED_MESSSAGE;
					}
					logger.error("HTTP Error when posting CV to routeOne at: {}, with statusCode: {}", routeOneURL,
							statusCode);
				}
			}

		} catch (Exception e) {
			logger.error("Error when posting CV to routeOne at: {}", routeOneURL, e);
			throw e;
		} finally {
			try {
				if (post != null) {
					post.releaseConnection();
				}
			} catch (Exception e) {
				logger.error("Error releasing PostMethod connection.", e);
			}
		}

		return responseBody;

	}

	/**
	 * @param dmsId
	 * @return
	 * @throws Exception
	 */
	public Boolean getAdventFlag(final String dmsId) throws Exception {
		logger.debug("Entered getAdventFlag method in CVTransmitClient. DmsId: {}", dmsId);
		try {
			RestTemplate restTemplate = new RestTemplate();
			String url = commonServiceURLAdvent;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("dmsId", dmsId);
			logger.debug("CommonServices URL For Advent> " + builder.build().encode().toUri());
			ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(),
					Boolean.class);

			logger.debug("Incoming request is " + (response.getBody().booleanValue() ? "" : "*not*") + " Advent");
			return response.getBody();
		} catch (Exception e) {
			logger.debug("Cannot determine if deal is Advent or not, ", e);
		}
		return Boolean.FALSE;
	}

	/**
	 * @param dealerId
	 * @param lenderId
	 * @param productId
	 * @return
	 * @throws Exception
	 */
	public Boolean getRouteOneFlag(final String dealerId, final String lenderId, final String productId)
			throws Exception {
		logger.debug("Entered getRouteOneFlag method in CVTransmitClient. dealerID: {}, lenderId: {}, productId: {}",
				dealerId, lenderId, productId);
		try {
			RestTemplate restTemplate = new RestTemplate();
			String url = commonServiceBaseUrl + "/" + uriPathForRouteOneFlag;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("dealerId", dealerId)
					.queryParam("lenderId", lenderId).queryParam("productId", productId);
			logger.debug("CommonServices URL for RouteOne flag: {}", builder.build().encode().toUri());
			ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(),
					Boolean.class);
			logger.debug("RouteOne Flag is " + (response.getBody().booleanValue() ? "" : "*not*")
					+ " enabled for lenderId: {}, dealerId: {}, productId: {}", lenderId, dealerId, productId);
			return response.getBody();
		} catch (final Exception e) {
			logger.debug("Exception occured trying to obtain RouteOneFlag from common service ", e);
		}
		return Boolean.FALSE;
	}

	/**
	 * @param requestXml
	 * @param lenderURL
	 * @param headers
	 * @return
	 * @throws Exception
	 */
	public ResponseMessage postCVToLender(final String requestXml, final String lenderURL,
			final MultiValueMap<String, String> headers) throws Exception {

		logger.debug("Entered postCVToLender() method of CVTransmitClient class");
		ResponseMessage response = new ResponseMessage();
		try {
			List<CommonsUtilNvpVO> listOfWebServiceFeatures = getWebServiceFeaturesForLender();
			restTemplate = SecureTransmissionUtil.getRestTemplate(listOfWebServiceFeatures);
			HttpHeaders httpHeaders = new HttpHeaders(headers);
			ResponseEntity<String> responseEntity = null;
			HttpEntity<String> requestEntity = new HttpEntity<>(requestXml, httpHeaders);
			responseEntity = restTemplate.exchange(lenderURL, HttpMethod.POST, requestEntity, String.class);

			if (null != responseEntity) {

				response.setStatusCode(responseEntity.getStatusCodeValue());
				logger.debug("StatusCode: {}", response.getStatusCode());

				response.setResponseXml(responseEntity.getBody());
				if (response.getStatusCode() == HttpStatus.OK.value()
						|| response.getStatusCode() == HttpStatus.ACCEPTED.value()) {
					logger.debug("**** Successfully posted CV to Lender. statusCode: {} ****",
							response.getStatusCode());
					logger.debug("Response from Lender: {} ", response.getResponseXml().replaceAll("[\r\n]+", " "));
				} else {
					if (StringUtils.isBlank(response.getResponseXml())) {
						response.setResponseXml(Constants.OPERATION_FAILED_MESSSAGE);
					}
					logger.error("HTTP Error when posting CV to Lender at: {}, with statusCode: {}", lenderURL,
							response.getStatusCode());
				}
			}
		} catch (Exception e) {
			logger.error("Error when posting CV to Lender at: {}", lenderURL, e);
			throw e;
		}
		return response;

	}

	/**
	 * @return
	 */
	private List<CommonsUtilNvpVO> getWebServiceFeaturesForLender() {
		List<CommonsUtilNvpVO> listOfWebServiceFeatures = new ArrayList<>();
		iProductConfigurationLookupService.getWebServiceFeatures().stream().forEach(featureConfig -> {
			CommonsUtilNvpVO nvpVO = new CommonsUtilNvpVO();
			nvpVO.setName(featureConfig.getFeatureName());
			nvpVO.setValue(featureConfig.getFeatureValue());
			listOfWebServiceFeatures.add(nvpVO);
		});
		logger.debug(
				"Exit getWebServiceFeaturesForLender method of CVTransmitClient. listOfWebServiceFeatures contains {} items",
				listOfWebServiceFeatures.size());
		return listOfWebServiceFeatures;
	}

	/**
	 *
	 * @param lenderId
	 * @param dealerId
	 * @return
	 * @throws Exception
	 */
	public Boolean getVolvoIntegration(final String lenderId, final String dealerId) throws Exception {
		logger.debug("Entered getVolvoIntegration method in CVTransmitClient. LenderID: {} & DealerId: {}", lenderId,
				dealerId);
		try {
			RestTemplate restTemplate = new RestTemplate();
			String url = commonServiceURLIntegrationFlag;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("lenderId", lenderId)
					.queryParam("dealerId", dealerId).queryParam("productId", Constants.APP_CV_CODE);
			logger.debug("CommonServices URL For Lender Integration Check> " + builder.build().encode().toUri());
			ResponseEntity<Boolean> response = restTemplate.getForEntity(builder.build().encode().toUri(),
					Boolean.class);

			logger.debug("Lender is " + (response.getBody().booleanValue() ? "" : "*not*") + " Integrated");
			return response.getBody();
		} catch (Exception e) {
			logger.debug("Cannot determine if Lender is Integrated or not, ", e);
		}
		return Boolean.FALSE;
	}

	/**
	 *
	 * @param lenderId
	 * @return
	 */
	public String getOauth2Token(String lenderId) {
		logger.debug("Entered getOauth2Token method in CVTransmitClient. LenderID: {}", lenderId);
		String tokenUrl = "";
		String token = "";
		if (Constants.LENDER_VOL.equals(lenderId) || Constants.LENDER_VCF.equals(lenderId)) {
			tokenUrl = commonServiceURLDefiToken;
		}
		try {
			RestTemplate restTemplate = new RestTemplate();
			logger.debug("URL to get Token for LenderId {} is {}",lenderId, tokenUrl);
			ResponseEntity<OdeTokenResponseVO> response = restTemplate.getForEntity(tokenUrl, OdeTokenResponseVO.class);
			token = response.getBody().getToken();
			logger.debug("Received token from Common Service");
		} catch (Exception e) {
			logger.debug("Could not retrieve token", e);
		}
		return token;
	}
}