package com.ode.cv.vo;

import java.util.List;
import com.ode.persistence.vo.DcFormVO;

public class AccrVO implements java.io.Serializable {

	/**
	 * Generated serial version id.
	 */
	private static final long serialVersionUID = -3781551818324245998L;
	private String validationResults;
	private String validationDescription;
	private String contractApplicationNumber;
	private String accountNumber;
	private String lenderSequenceNumber;
	private String funderComments;
	private String documentId;
	private String fundingStatus;
	private String sequenceNumber;
	private List<DcFormVO> formList;
	private String accrRequestXml;
	private String lenderId;
	private String dealerId;
	private String adpDealNo;
	private String bodId;
	private String responseMessage;
	private String responseCode;
	private String dealerNumber;
	private String storeNumber;
	private String referenceId;
	private String authorizationId;
	private String contractId;
	private String contractFormNumber;
	private String destinationCode;
	private String documentVersionNumber;
	private String financeCompanyName;
	private String dealerName;
	private String applicationType;
	private String financeType;
	private String paymentAmount;
	private String netAnnualPercentageRate;
	private String senderNameCode;
	private String locationId;
	private String serviceId;

	public String getValidationResults() {
		return validationResults;
	}

	public void setValidationResults(String validationResults) {
		this.validationResults = validationResults;
	}

	public String getValidationDescription() {
		return validationDescription;
	}

	public void setValidationDescription(String validationDescription) {
		this.validationDescription = validationDescription;
	}

	public String getContractApplicationNumber() {
		return contractApplicationNumber;
	}

	public void setContractApplicationNumber(String contractApplicationNumber) {
		this.contractApplicationNumber = contractApplicationNumber;
	}

	public String getFunderComments() {
		return funderComments;
	}

	public void setFunderComments(String funderComments) {
		this.funderComments = funderComments;
	}

	public String getFundingStatus() {
		return fundingStatus;
	}

	public void setFundingStatus(String fundingStatus) {
		this.fundingStatus = fundingStatus;
	}

	public List<DcFormVO> getFormList() {
		return formList;
	}

	public void setFormList(List<DcFormVO> formList) {
		this.formList = formList;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getLenderSequenceNumber() {
		return lenderSequenceNumber;
	}

	public void setLenderSequenceNumber(String lenderSequenceNumber) {
		this.lenderSequenceNumber = lenderSequenceNumber;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getAccrRequestXml() {
		return accrRequestXml;
	}

	public void setAccrRequestXml(String accrRequestXml) {
		this.accrRequestXml = accrRequestXml;
	}

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getAdpDealNo() {
		return adpDealNo;
	}

	public void setAdpDealNo(String adpDealNo) {
		this.adpDealNo = adpDealNo;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getBodId() {
		return bodId;
	}

	public void setBodId(String bodId) {
		this.bodId = bodId;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getDocumentId() {
		return documentId;
	}

	public String getDealerNumber() {
		return dealerNumber;
	}

	public String getStoreNumber() {
		return storeNumber;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public void setDealerNumber(String dealerNumber) {
		this.dealerNumber = dealerNumber;
	}

	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}	

	public String getReferenceId() {
		return referenceId;
	}

	public String getAuthorizationId() {
		return authorizationId;
	}

	public String getContractId() {
		return contractId;
	}

	public String getContractFormNumber() {
		return contractFormNumber;
	}

	public String getDestinationCode() {
		return destinationCode;
	}

	public String getDocumentVersionNumber() {
		return documentVersionNumber;
	}

	public String getFinanceCompanyName() {
		return financeCompanyName;
	}

	public String getDealerName() {
		return dealerName;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public void setAuthorizationId(String authorizationId) {
		this.authorizationId = authorizationId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public void setContractFormNumber(String contractFormNumber) {
		this.contractFormNumber = contractFormNumber;
	}

	public void setDestinationCode(String destinationCode) {
		this.destinationCode = destinationCode;
	}

	public void setDocumentVersionNumber(String documentVersionNumber) {
		this.documentVersionNumber = documentVersionNumber;
	}

	public void setFinanceCompanyName(String financeCompanyName) {
		this.financeCompanyName = financeCompanyName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}
	
	public String getPaymentAmount() {
		return paymentAmount;
	}

	public String getNetAnnualPercentageRate() {
		return netAnnualPercentageRate;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public void setNetAnnualPercentageRate(String netAnnualPercentageRate) {
		this.netAnnualPercentageRate = netAnnualPercentageRate;
	}

	public String getSenderNameCode() {
		return senderNameCode;
	}

	public void setSenderNameCode(String senderNameCode) {
		this.senderNameCode = senderNameCode;
	}	

	public String getLocationId() {
		return locationId;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AccrVO [validationResults=");
		builder.append(validationResults);
		builder.append(", validationDescription=");
		builder.append(validationDescription);
		builder.append(", contractApplicationNumber=");
		builder.append(contractApplicationNumber);
		builder.append(", accountNumber=");
		builder.append(accountNumber);
		builder.append(", lenderSequenceNumber=");
		builder.append(lenderSequenceNumber);
		builder.append(", funderComments=");
		builder.append(funderComments);
		builder.append(", documentId=");
		builder.append(documentId);
		builder.append(", fundingStatus=");
		builder.append(fundingStatus);
		builder.append(", sequenceNumber=");
		builder.append(sequenceNumber);
		builder.append(", formList=");
		builder.append(formList);
		builder.append(", accrRequestXml=");
		builder.append(accrRequestXml);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append(", adpDealNo=");
		builder.append(adpDealNo);
		builder.append(", bodId=");
		builder.append(bodId);
		builder.append(", responseMessage=");
		builder.append(responseMessage);
		builder.append(", responseCode=");
		builder.append(responseCode);
		builder.append(", dealerNumber=");
		builder.append(dealerNumber);
		builder.append(", storeNumber=");
		builder.append(storeNumber);
		builder.append(", referenceId=");
		builder.append(referenceId);
		builder.append(", authorizationId=");
		builder.append(authorizationId);
		builder.append(", contractId=");
		builder.append(contractId);
		builder.append(", contractFormNumber=");
		builder.append(contractFormNumber);
		builder.append(", destinationCode=");
		builder.append(destinationCode);
		builder.append(", documentVersionNumber=");
		builder.append(documentVersionNumber);
		builder.append(", financeCompanyName=");
		builder.append(financeCompanyName);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", applicationType=");
		builder.append(applicationType);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", paymentAmount=");
		builder.append(paymentAmount);
		builder.append(", netAnnualPercentageRate=");
		builder.append(netAnnualPercentageRate);
		builder.append(", senderNameCode=");
		builder.append(senderNameCode);
		builder.append("]");
		return builder.toString();

	}
}