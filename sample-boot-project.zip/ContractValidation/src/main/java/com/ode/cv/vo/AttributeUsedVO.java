package com.ode.cv.vo;

public class AttributeUsedVO {
	
	private String name;
	private String xsdPath;
	private String value;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getXsdPath() {
		return xsdPath;
	}
	
	public void setXsdPath(String xsdPath) {
		this.xsdPath = xsdPath;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AttributeUsed [name=");
		builder.append(name);
		builder.append(", xsdPath=");
		builder.append(xsdPath);
		builder.append(", value=");
		builder.append(value);
		builder.append("]");
		return builder.toString();
	}
}