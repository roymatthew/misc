/**
 * 
 */
package com.ode.cv.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * @author snimma
 *
 */
public class CVInputVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1582674222790983636L;

	private PartnerInfoVO partnerInfoVO;
	private DealerInfoVO dealerInfoVO;
	private String requestXML;
	private String applicationSource;
	private String applicationNumber;
	private String contractExecutionState;
	private String documentId;
	private String adpDealNo;
	private String serviceId;
	private String locationId;
	private String vehicleYear;
	private String vehicleMake;
	private String vehicleModel;
	private String vehicleModelDescription;
	private String fiConfig;
	private String productConfiguration;
	private String productId;
	private String creditContract;
	private String messageProcessing;
	private String fromPf;
	private String exceptionLenders;
	private String financeType;
	private String partnerDealNumber;
	private String attachmentFileName;
	private String attachmentZip;
	private String dealerName;
	private boolean isGenericCreditContract;
	private String TaskName;
	private String userId;
	private String deliverySource;
	private String contractFormNumber;
	private Date contractFormRevisionDate;
	private AccrVO accr = new AccrVO();

	public PartnerInfoVO getPartnerInfoVO() {
		return partnerInfoVO;
	}

	public void setPartnerInfoVO(PartnerInfoVO partnerInfoVO) {
		this.partnerInfoVO = partnerInfoVO;
	}

	public DealerInfoVO getDealerInfoVO() {
		return dealerInfoVO;
	}

	public void setDealerInfoVO(DealerInfoVO dealerInfoVO) {
		this.dealerInfoVO = dealerInfoVO;
	}

	public String getRequestXML() {
		return requestXML;
	}

	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}

	public String getApplicationSource() {
		return applicationSource;
	}

	public void setApplicationSource(String applicationSource) {
		this.applicationSource = applicationSource;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getContractExecutionState() {
		return contractExecutionState;
	}

	public void setContractExecutionState(String contractExecutionState) {
		this.contractExecutionState = contractExecutionState;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getAdpDealNo() {
		return adpDealNo;
	}

	public void setAdpDealNo(String adpDealNo) {
		this.adpDealNo = adpDealNo;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getVehicleYear() {
		return vehicleYear;
	}

	public void setVehicleYear(String vehicleYear) {
		this.vehicleYear = vehicleYear;
	}

	public String getVehicleMake() {
		return vehicleMake;
	}

	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

	public String getVehicleModelDescription() {
		return vehicleModelDescription;
	}

	public void setVehicleModelDescription(String vehicleModelDescription) {
		this.vehicleModelDescription = vehicleModelDescription;
	}

	public String getVehicleModel() {
		return vehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}

	public String getProductConfiguration() {
		return productConfiguration;
	}

	public void setProductConfiguration(String productConfiguration) {
		this.productConfiguration = productConfiguration;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCreditContract() {
		return creditContract;
	}

	public void setCreditContract(String creditContract) {
		this.creditContract = creditContract;
	}

	public String getMessageProcessing() {
		return messageProcessing;
	}

	public void setMessageProcessing(String messageProcessing) {
		this.messageProcessing = messageProcessing;
	}

	public String getFromPf() {
		return fromPf;
	}

	public void setFromPf(String fromPf) {
		this.fromPf = fromPf;
	}

	public String getExceptionLenders() {
		return exceptionLenders;
	}

	public void setExceptionLenders(String exceptionLenders) {
		this.exceptionLenders = exceptionLenders;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public String getPartnerDealNumber() {
		return partnerDealNumber;
	}

	public void setPartnerDealNumber(String partnerDealNumber) {
		this.partnerDealNumber = partnerDealNumber;
	}

	public String getAttachmentFileName() {
		return attachmentFileName;
	}

	public void setAttachmentFileName(String attachmentFileName) {
		this.attachmentFileName = attachmentFileName;
	}

	public String getAttachmentZip() {
		return attachmentZip;
	}

	public void setAttachmentZip(String attachmentZip) {
		this.attachmentZip = attachmentZip;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public boolean isGenericCreditContract() {
		return isGenericCreditContract;
	}

	public void setGenericCreditContract(boolean isGenericCreditContract) {
		this.isGenericCreditContract = isGenericCreditContract;
	}

	public String getTaskName() {
		return TaskName;
	}

	public void setTaskName(String taskName) {
		TaskName = taskName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeliverySource() {
		return deliverySource;
	}

	public void setDeliverySource(String deliverySource) {
		this.deliverySource = deliverySource;
	}

	public String getContractFormNumber() {
		return contractFormNumber;
	}

	public void setContractFormNumber(String contractFormNumber) {
		this.contractFormNumber = contractFormNumber;
	}

	public Date getContractFormRevisionDate() {
		return contractFormRevisionDate;
	}

	public void setContractFormRevisionDate(Date contractFormRevisionDate) {
		this.contractFormRevisionDate = contractFormRevisionDate;
	}

	public AccrVO getAccr() {
		return accr;
	}

	public void setAccr(AccrVO accr) {
		this.accr = accr;
	}

	public String getFiConfig() {
		return fiConfig;
	}

	public void setFiConfig(String fiConfig) {
		this.fiConfig = fiConfig;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CVInputVO [partnerInfoVO=");
		builder.append(partnerInfoVO);
		builder.append(", dealerInfoVO=");
		builder.append(dealerInfoVO);
		builder.append(", requestXML=");
		builder.append(requestXML);
		builder.append(", applicationSource=");
		builder.append(applicationSource);
		builder.append(", applicationNumber=");
		builder.append(applicationNumber);
		builder.append(", contractExecutionState=");
		builder.append(contractExecutionState);
		builder.append(", documentId=");
		builder.append(documentId);
		builder.append(", adpDealNo=");
		builder.append(adpDealNo);
		builder.append(", serviceId=");
		builder.append(serviceId);
		builder.append(", locationId=");
		builder.append(locationId);
		builder.append(", vehicleYear=");
		builder.append(vehicleYear);
		builder.append(", vehicleMake=");
		builder.append(vehicleMake);
		builder.append(", vehicleModel=");
		builder.append(vehicleModel);
		builder.append(", vehicleModelDescription=");
		builder.append(vehicleModelDescription);
		builder.append(", fiConfig=");
		builder.append(fiConfig);
		builder.append(", productConfiguration=");
		builder.append(productConfiguration);
		builder.append(", productId=");
		builder.append(productId);
		builder.append(", creditContract=");
		builder.append(creditContract);
		builder.append(", messageProcessing=");
		builder.append(messageProcessing);
		builder.append(", fromPf=");
		builder.append(fromPf);
		builder.append(", exceptionLenders=");
		builder.append(exceptionLenders);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", partnerDealNumber=");
		builder.append(partnerDealNumber);
		builder.append(", attachmentFileName=");
		builder.append(attachmentFileName);
		builder.append(", attachmentZip=");
		builder.append(attachmentZip);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", isGenericCreditContract=");
		builder.append(isGenericCreditContract);
		builder.append(", TaskName=");
		builder.append(TaskName);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", deliverySource=");
		builder.append(deliverySource);
		builder.append(", contractFormNumber=");
		builder.append(contractFormNumber);
		builder.append(", contractFormRevisionDate=");
		builder.append(contractFormRevisionDate);
		builder.append(", accr=");
		builder.append(accr);
		builder.append("]");
		return builder.toString();
	}

}
