package com.ode.cv.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.adp.dealerservices.loanprocessing.MessageProcessing;
import com.ode.cv.util.ProductConfiguration;
import com.ode.cv.util.ResponseMessage;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.vo.DcDigitalDealVO;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author rmathew
 *
 */
public class CVTransmitVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2050949698711036423L;
	private String lenderRequestXml;
	private String lenderResponseXml;
	private String accrResponseXml;
	private String responseXml = " ";
	private String adpDealno = " ";
	private ResponseMessage lenderResponseMessage;
	private ResponseMessage accrResponseMessage;
	private AppMessage appMessage;
	private String appStatus;
	private String soapFaultCode;
	private String soapFaultMessage;
	private List<JournalObjectVO> journalObjectList = new ArrayList<>();
	private ProductConfiguration productConfiguration;
	private PartnerInfoVO partnerInfoVO;
	private DealerInfoVO dealerInfoVO;
	private String attachmentZip;
	private String attachmentFileName;
	private String valMessageDesc = "";
	private String valMessageCode = "";
	private String ecTransXml;
	private String confoutXml;
	private String accroutXml;
	private List<MessageProcessing> messageProcessing;
	public AccrVO accrContext;
	private String requestXml;
	private DcDigitalDealVO dcDigitalDealVO;
	private String destinationProductId;
	private boolean staticRFLEnabled = false;
	private boolean cdkCloudEnabled = false;
	private DeDealVO dealVO;
	private List<DcFormVO> listOfDcForms = new ArrayList<>();
	private ECConfinVO ecConfinVO;

	public List<MessageProcessing> getMessageProcessing() {
		return messageProcessing;
	}

	public void setMessageProcessing(List<MessageProcessing> messageProcessing) {
		this.messageProcessing = messageProcessing;
	}

	public String getValMessageDesc() {
		return valMessageDesc;
	}

	public String getValMessageCode() {
		return valMessageCode;
	}

	public void setValMessageDesc(String valMessageDesc) {
		this.valMessageDesc = valMessageDesc;
	}

	public void setValMessageCode(String valMessageCode) {
		this.valMessageCode = valMessageCode;
	}

	public String getLenderRequestXml() {
		return lenderRequestXml;
	}

	public String getLenderResponseXml() {
		return lenderResponseXml;
	}

	public void setLenderRequestXml(String lenderRequestXml) {
		this.lenderRequestXml = lenderRequestXml;
	}

	public void setLenderResponseXml(String lenderResponseXml) {
		this.lenderResponseXml = lenderResponseXml;
	}

	public AppMessage getAppMessage() {
		return appMessage;
	}

	public void setAppMessage(AppMessage appMessage) {
		this.appMessage = appMessage;
	}

	public List<JournalObjectVO> getJournalObjectList() {
		return journalObjectList;
	}

	public void addJournalObject(final JournalObjectVO journalObject) {
		this.getJournalObjectList().add(journalObject);
	}

	public ProductConfiguration getProductConfiguration() {
		return productConfiguration;
	}

	public void setProductConfiguration(ProductConfiguration productConfiguration) {
		this.productConfiguration = productConfiguration;
	}

	public PartnerInfoVO getPartnerInfoVO() {
		return partnerInfoVO;
	}

	public DealerInfoVO getDealerInfoVO() {
		return dealerInfoVO;
	}

	public void setPartnerInfoVO(PartnerInfoVO partnerInfoVO) {
		this.partnerInfoVO = partnerInfoVO;
	}

	public void setDealerInfoVO(DealerInfoVO dealerInfoVO) {
		this.dealerInfoVO = dealerInfoVO;
	}

	public String getSoapFaultCode() {
		return soapFaultCode;
	}

	public String getSoapFaultMessage() {
		return soapFaultMessage;
	}

	public void setSoapFaultCode(String soapFaultCode) {
		this.soapFaultCode = soapFaultCode;
	}

	public void setSoapFaultMessage(String soapFaultMessage) {
		this.soapFaultMessage = soapFaultMessage;
	}

	public String getResponseXml() {
		return responseXml;
	}

	public ResponseMessage getLenderResponseMessage() {
		return lenderResponseMessage;
	}

	public void setResponseXml(String responseXml) {
		this.responseXml = responseXml;
	}

	public void setLenderResponseMessage(final ResponseMessage responseMessage) {
		this.lenderResponseMessage = responseMessage;
	}

	public String getAttachmentZip() {
		return attachmentZip;
	}

	public String getAttachmentFileName() {
		return attachmentFileName;
	}

	public void setAttachmentZip(final String attachmentZip) {
		this.attachmentZip = attachmentZip;
	}

	public void setAttachmentFileName(final String attachmentFileName) {
		this.attachmentFileName = attachmentFileName;
	}

	public String getEcTransXml() {
		return ecTransXml;
	}

	public String getConfoutXml() {
		return confoutXml;
	}

	public void setEcTransXml(String ecTransXml) {
		this.ecTransXml = ecTransXml;
	}

	public void setConfoutXml(String confoutXml) {
		this.confoutXml = confoutXml;
	}

	public String getAdpDealno() {
		return adpDealno;
	}

	public void setAdpDealno(String adpDealno) {
		this.adpDealno = adpDealno;
	}

	public String getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}

	public AccrVO getAccrContext() {
		return accrContext;
	}

	public void setAccrContext(AccrVO accrContext) {
		this.accrContext = accrContext;
	}

	public String getRequestXml() {
		return requestXml;
	}

	public void setRequestXml(String requestXml) {
		this.requestXml = requestXml;
	}
	
	public DcDigitalDealVO getDcDigitalDealVO() {
		return dcDigitalDealVO;
	}

	public void setDcDigitalDealVO(DcDigitalDealVO dcDigitalDealVO) {
		this.dcDigitalDealVO = dcDigitalDealVO;
	}
	
	public String getDestinationProductId() {
		return destinationProductId;
	}

	public void setDestinationProductId(String destinationProductId) {
		this.destinationProductId = destinationProductId;
	}

	public String getAccrResponseXml() {
		return accrResponseXml;
	}

	public void setAccrResponseXml(String accrResponseXml) {
		this.accrResponseXml = accrResponseXml;
	}
	
	public ResponseMessage getAccrResponseMessage() {
		return accrResponseMessage;
	}

	public void setAccrResponseMessage(ResponseMessage accrResponseMessage) {
		this.accrResponseMessage = accrResponseMessage;
	}

	public String getAccroutXml() {
		return accroutXml;
	}

	public void setAccroutXml(String accroutXml) {
		this.accroutXml = accroutXml;
	}	

	public boolean isStaticRFLEnabled() {
		return staticRFLEnabled;
	}

	public void setStaticRFLEnabled(boolean staticRFLEnabled) {
		this.staticRFLEnabled = staticRFLEnabled;
	}	

	public boolean isCdkCloudEnabled() {
		return cdkCloudEnabled;
	}

	public void setCdkCloudEnabled(boolean cdkCloudEnabled) {
		this.cdkCloudEnabled = cdkCloudEnabled;
	}

	public DeDealVO getDealVO() {
		return dealVO;
	}

	public void setDealVO(DeDealVO deDealVO) {
		this.dealVO = deDealVO;
	}
	
	public List<DcFormVO> getListOfDcForms() {
		return listOfDcForms;
	}

	public void setListOfDcForms(List<DcFormVO> listOfDcForms) {
		this.listOfDcForms = listOfDcForms;
	}	

	public ECConfinVO getEcConfinVO() {
		return ecConfinVO;
	}

	public void setEcConfinVO(ECConfinVO ecConfinVO) {
		this.ecConfinVO = ecConfinVO;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CVTransmitVO [lenderRequestXml=");
		builder.append(lenderRequestXml);
		builder.append(", lenderResponseXml=");
		builder.append(lenderResponseXml);
		builder.append(", responseXml=");
		builder.append(responseXml);
		builder.append(", adpDealno=");
		builder.append(adpDealno);
		builder.append(", lenderResponseMessage=");
		builder.append(lenderResponseMessage);
		builder.append(", appMessage=");
		builder.append(appMessage);
		builder.append(", appStatus=");
		builder.append(appStatus);
		builder.append(", soapFaultCode=");
		builder.append(soapFaultCode);
		builder.append(", soapFaultMessage=");
		builder.append(soapFaultMessage);
		builder.append(", journalObjectList=");
		builder.append(journalObjectList);
		builder.append(", productConfiguration=");
		builder.append(productConfiguration);
		builder.append(", partnerInfoVO=");
		builder.append(partnerInfoVO);
		builder.append(", dealerInfoVO=");
		builder.append(dealerInfoVO);
		builder.append(", attachmentZip=");
		builder.append(attachmentZip);
		builder.append(", attachmentFileName=");
		builder.append(attachmentFileName);
		builder.append(", valMessageDesc=");
		builder.append(valMessageDesc);
		builder.append(", valMessageCode=");
		builder.append(valMessageCode);
		builder.append(", ecTransXml=");
		builder.append(ecTransXml);
		builder.append(", confoutXml=");
		builder.append(confoutXml);
		builder.append(", accroutXml=");
		builder.append(accroutXml);
		builder.append(", messageProcessing=");
		builder.append(messageProcessing);
		builder.append(", accrContext=");
		builder.append(accrContext);
		builder.append(", requestXml=");
		builder.append(requestXml);
		builder.append(", dcDigitalDealVO=");
		builder.append(dcDigitalDealVO);
		builder.append(", staticRFLEnabled=");
		builder.append(staticRFLEnabled);
		builder.append(", dealVO=");
		builder.append(dealVO);
		builder.append("]");
		return builder.toString();
	}

}
