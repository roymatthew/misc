package com.ode.cv.vo;

import java.io.Serializable;
import java.util.List;

import com.ode.persistence.vo.CcvConditionSetVO;
import com.ode.persistence.vo.CcvConditionVO;
import com.ode.persistence.vo.CcvDataExceptionVO;
import com.ode.persistence.vo.CcvDataTranslationVO;
import com.ode.persistence.vo.CcvXpathVO;

public class CcvInputVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7402474682166305001L;

	private List<CcvDataTranslationVO> listOfDataTranslations;
	private List<CcvConditionVO> listOfCcvConditions;
	private List<CcvConditionSetVO> listOfCcvConditionSets;
	private List<CcvXpathVO> listOfCcvXpaths;
	private List<CcvDataExceptionVO> listOfDataExceptions;
	private String ecTransXML;

	public String getEcTransXML() {
		return ecTransXML;
	}

	public void setEcTransXML(final String ecTransXML) {
		this.ecTransXML = ecTransXML;
	}

	public List<CcvDataTranslationVO> getListOfDataTranslations() {
		return listOfDataTranslations;
	}

	public List<CcvConditionVO> getListOfCcvConditions() {
		return listOfCcvConditions;
	}

	public List<CcvConditionSetVO> getListOfCcvConditionSets() {
		return listOfCcvConditionSets;
	}

	public List<CcvXpathVO> getListOfCcvXpaths() {
		return listOfCcvXpaths;
	}

	public void setListOfDataTranslations(final List<CcvDataTranslationVO> listOfDataTranslations) {
		this.listOfDataTranslations = listOfDataTranslations;
	}

	public void setListOfCcvConditions(final List<CcvConditionVO> listOfCcvConditions) {
		this.listOfCcvConditions = listOfCcvConditions;
	}

	public void setListOfCcvConditionSets(final List<CcvConditionSetVO> listOfCcvConditionSets) {
		this.listOfCcvConditionSets = listOfCcvConditionSets;
	}

	public void setListOfCcvXpaths(final List<CcvXpathVO> listOfCcvXpaths) {
		this.listOfCcvXpaths = listOfCcvXpaths;
	}

	public List<CcvDataExceptionVO> getListOfDataExceptions() {
		return listOfDataExceptions;
	}

	public void setListOfDataExceptions(final List<CcvDataExceptionVO> listOfDataExceptions) {
		this.listOfDataExceptions = listOfDataExceptions;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CcvInputVO [listOfDataTranslations=");
		builder.append(listOfDataTranslations);
		builder.append(", listOfCcvConditions=");
		builder.append(listOfCcvConditions);
		builder.append(", listOfCcvConditionSets=");
		builder.append(listOfCcvConditionSets);
		builder.append(", listOfCcvXpaths=");
		builder.append(listOfCcvXpaths);
		builder.append(", listOfDataExceptions=");
		builder.append(listOfDataExceptions);
		builder.append(", ecTransXML=");
		builder.append(ecTransXML);
		builder.append("]");
		return builder.toString();
	}

}
