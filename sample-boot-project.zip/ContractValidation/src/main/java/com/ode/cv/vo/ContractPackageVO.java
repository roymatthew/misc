/**
 * 
 */
package com.ode.cv.vo;

import java.io.Serializable;

/**
 * @author rmathew
 *
 */
public class ContractPackageVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4844979831693399543L;
	
	private String contractId;
	private String contractType;
	private String partnerFSID;
	private String conversationId;
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getPartnerFSID() {
		return partnerFSID;
	}
	public void setPartnerFSID(String partnerFSID) {
		this.partnerFSID = partnerFSID;
	}
	public String getConversationId() {
		return conversationId;
	}
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	@Override
	public String toString() {
		return "ContractPackageVO [contractId=" + contractId + ", contractType=" + contractType + ", partnerFSID="
				+ partnerFSID + ", conversationId=" + conversationId + "]";
	}
	
	

}
