package com.ode.cv.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.adp.dealerservices.loanprocessing.CreditContract;
import com.adp.dealerservices.loanprocessing.FinanceInstitution;
import com.adp.dealerservices.loanprocessing.MessageProcessing;
import com.ode.cv.context.ContractValidationContext;
import com.ode.cv.context.CreditApplicationContext;
import com.ode.cv.util.ProductConfiguration;
import com.ode.cv.util.ResponseMessage;
import com.ode.dlr.util.AppMessage;
import com.ode.persistence.vo.CcvDataTranslationVO;
import com.ode.persistence.vo.DcDigitalDealVO;
import com.ode.persistence.vo.DeLenderDestinationVO;
import com.ode.persistence.vo.DePartnerDestinationVO;

public class CreditContractVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9114157442207828804L;

	private ProductConfiguration productConfiguration;
	private AppMessage appMsg;
	private PartnerInfoVO partnerInfo;
	private DealerInfoVO dealerInfo;
	private CVTransmitVO cvTransmitVO;
	private DcDigitalDealVO dcDigitalDealVO;
	private DePartnerDestinationVO dePartnerDestinationVO;
	private AccrVO accr = new AccrVO();
	private List<MessageProcessing> messageProcessing;
	private List<CcvDataTranslationVO> ccvDataTranslationResultsDB;
	private EformsInputVO eformsInputVO;
	private CcvInputVO ccvInputVO;
	private String billingTransType;
	private Timestamp timeStamp;
	private String requestXML;
	private boolean rulesEngine;
	private String attachmentZip;
	private String adpDealNo;
	private String valMessageDesc;
	private String valMessageCode;
	private String soapFaultMessage;
	private String soapFaultCode;
	private String confoutXml;
	private String accroutXml;
	private String fromPF;
	private String contractFormNumber;
	private Date contractFormRevisionDate;
	private String contractExecutionState;
	private String appStatus;
	private String vehicleMake;
	private boolean validationError;
	private String vaultDocId;
	private String lenderRequestXml;
	private String lenderResponseXml;
	private FinanceInstitution fiConfig;
	private String vehicleModelDescription;
	private String stateGroup;
	private String transformerDateTime;
	private String documentId;
	private String attachmentFileName;
	private CreditContract creditContract;
	private String financeType;
	private ResponseMessage lenderResponseMessage;
	private CreditApplicationContext caContext;
	private String serviceId;
	private String locationId;
	private String applicationSource;
	private String applicationNumber;
	private String vehicleYear;
	private String vehicleModel;
	private String productId;
	private String fromPf;
	private String partnerDealNumber;
	private String dealerName;
	private boolean isGenericCreditContract = false;
	private String TaskName;
	private String userId;
	private String deliverySource;
	private String confirmBod;
	private boolean docInvalidFlag;
	private String transType;
	private String roKey = null;
	private String operationName;
	private DeContractValidationBo contractValidation;
	private DeDealBo deal;
	private ContractValidationContext ecContext = new ContractValidationContext();
	private String conversationId;
	private String contractType;
	private String destinationNameCode;
	private Boolean oldREValidationRequired = Boolean.FALSE;

	private List<JournalObjectVO> listOfJournalObjects;

	private String[] exceptionLenders;

	public List<JournalObjectVO> getJournalObject() {
		return listOfJournalObjects;
	}

	public void setJournalObject(List<JournalObjectVO> journalObject) {
		this.listOfJournalObjects = journalObject;
	}

	public ProductConfiguration getProductConfiguration() {
		return productConfiguration;
	}

	public void setProductConfiguration(ProductConfiguration productConfiguration) {
		this.productConfiguration = productConfiguration;
	}

	public AppMessage getAppMsg() {
		return appMsg;
	}

	public void setAppMsg(AppMessage appMsg) {
		this.appMsg = appMsg;
	}

	public PartnerInfoVO getPartnerInfo() {
		return partnerInfo;
	}

	public void setPartnerInfo(final PartnerInfoVO partnerInfoVO) {
		this.partnerInfo = partnerInfoVO;
	}

	public DealerInfoVO getDealerInfo() {
		return dealerInfo;
	}

	public void setDealerInfo(final DealerInfoVO dealerInfoVO) {
		this.dealerInfo = dealerInfoVO;
	}

	public CVTransmitVO getCvTransmitVO() {
		return cvTransmitVO;
	}

	public void setCvTransmitVO(CVTransmitVO cvTransmitVO) {
		this.cvTransmitVO = cvTransmitVO;
	}

	public DcDigitalDealVO getDcDigitalDealVO() {
		return dcDigitalDealVO;
	}

	public void setDcDigitalDealVO(DcDigitalDealVO dcDigitalDealVO) {
		this.dcDigitalDealVO = dcDigitalDealVO;
	}

	public DePartnerDestinationVO getDePartnerDestinationVO() {
		return dePartnerDestinationVO;
	}

	public void setDePartnerDestinationVO(DePartnerDestinationVO dePartnerDestinationVO) {
		this.dePartnerDestinationVO = dePartnerDestinationVO;
	}

	public AccrVO getAccr() {
		return accr;
	}

	public void setAccr(AccrVO accr) {
		this.accr = accr;
	}

	public List<MessageProcessing> getMessageProcessing() {
		return messageProcessing;
	}

	public void setMessageProcessing(List<MessageProcessing> messageProcessing) {
		this.messageProcessing = messageProcessing;
	}

	public List<CcvDataTranslationVO> getCcvDataTranslationResultsDB() {
		return ccvDataTranslationResultsDB;
	}

	public void setCcvDataTranslationResultsDB(List<CcvDataTranslationVO> ccvDataTranslationResultsDB) {
		this.ccvDataTranslationResultsDB = ccvDataTranslationResultsDB;
	}

	public EformsInputVO getEformsInputVO() {
		return eformsInputVO;
	}

	public void setEformsInputVO(EformsInputVO eformsInputVO) {
		this.eformsInputVO = eformsInputVO;
	}

	public String getBillingTransType() {
		return billingTransType;
	}

	public void setBillingTransType(String billingTransType) {
		this.billingTransType = billingTransType;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getRequestXML() {
		return requestXML;
	}

	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}

	public boolean isRulesEngine() {
		return rulesEngine;
	}

	public void setRulesEngine(boolean rulesEngine) {
		this.rulesEngine = rulesEngine;
	}

	public String getAttachmentZip() {
		return attachmentZip;
	}

	public void setAttachmentZip(String attachmentZip) {
		this.attachmentZip = attachmentZip;
	}

	public String getAdpDealNo() {
		return adpDealNo;
	}

	public void setAdpDealNo(String adpDealNo) {
		this.adpDealNo = adpDealNo;
	}

	public String getValMessageDesc() {
		return valMessageDesc;
	}

	public void setValMessageDesc(String valMessageDesc) {
		this.valMessageDesc = valMessageDesc;
	}

	public String getValMessageCode() {
		return valMessageCode;
	}

	public void setValMessageCode(String valMessageCode) {
		this.valMessageCode = valMessageCode;
	}

	public String getSoapFaultMessage() {
		return soapFaultMessage;
	}

	public void setSoapFaultMessage(String soapFaultMessage) {
		this.soapFaultMessage = soapFaultMessage;
	}

	public String getSoapFaultCode() {
		return soapFaultCode;
	}

	public void setSoapFaultCode(String soapFaultCode) {
		this.soapFaultCode = soapFaultCode;
	}

	public String getConfoutXml() {
		return confoutXml;
	}

	public void setConfoutXml(String confoutXml) {
		this.confoutXml = confoutXml;
	}

	public String getFromPF() {
		return fromPF;
	}

	public void setFromPF(String fromPF) {
		this.fromPF = fromPF;
	}

	public String getContractFormNumber() {
		return contractFormNumber;
	}

	public void setContractFormNumber(String contractFormNumber) {
		this.contractFormNumber = contractFormNumber;
	}

	public Date getContractFormRevisionDate() {
		return contractFormRevisionDate;
	}

	public void setContractFormRevisionDate(Date date) {
		this.contractFormRevisionDate = date;
	}

	public String getContractExecutionState() {
		return contractExecutionState;
	}

	public void setContractExecutionState(String contractExecutionState) {
		this.contractExecutionState = contractExecutionState;
	}

	public String getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}

	public String getVehicleMake() {
		return vehicleMake;
	}

	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

	public boolean isValidationError() {
		return validationError;
	}

	public void setValidationError(boolean validationError) {
		this.validationError = validationError;
	}

	public String getVaultDocId() {
		return vaultDocId;
	}

	public void setVaultDocId(String vaultDocId) {
		this.vaultDocId = vaultDocId;
	}

	public String getLenderRequestXml() {
		return lenderRequestXml;
	}

	public void setLenderRequestXml(String lenderRequestXml) {
		this.lenderRequestXml = lenderRequestXml;
	}

	public String getLenderResponseXml() {
		return lenderResponseXml;
	}

	public void setLenderResponseXml(String lenderResponseXml) {
		this.lenderResponseXml = lenderResponseXml;
	}

	public FinanceInstitution getFiConfig() {
		return fiConfig;
	}

	public void setFiConfig(FinanceInstitution fiConfig) {
		this.fiConfig = fiConfig;
	}

	public String getVehicleModelDescription() {
		return vehicleModelDescription;
	}

	public void setVehicleModelDescription(String vehicleModelDescription) {
		this.vehicleModelDescription = vehicleModelDescription;
	}

	public String getStateGroup() {
		return stateGroup;
	}

	public void setStateGroup(String stateGroup) {
		this.stateGroup = stateGroup;
	}

	public String getTransformerDateTime() {
		return transformerDateTime;
	}

	public void setTransformerDateTime(String transformerDateTime) {
		this.transformerDateTime = transformerDateTime;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getAttachmentFileName() {
		return attachmentFileName;
	}

	public void setAttachmentFileName(String attachmentFileName) {
		this.attachmentFileName = attachmentFileName;
	}

	public CreditContract getCreditContract() {
		return creditContract;
	}

	public void setCreditContract(CreditContract creditContract) {
		this.creditContract = creditContract;
	}

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	public ResponseMessage getLenderResponseMessage() {
		return lenderResponseMessage;
	}

	public void setLenderResponseMessage(ResponseMessage lenderResponseMessage) {
		this.lenderResponseMessage = lenderResponseMessage;
	}

	public CreditApplicationContext getCaContext() {
		return caContext;
	}

	public void setCaContext(CreditApplicationContext caContext) {
		this.caContext = caContext;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getApplicationSource() {
		return applicationSource;
	}

	public void setApplicationSource(String applicationSource) {
		this.applicationSource = applicationSource;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getVehicleYear() {
		return vehicleYear;
	}

	public void setVehicleYear(String vehicleYear) {
		this.vehicleYear = vehicleYear;
	}

	public String getVehicleModel() {
		return vehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getFromPf() {
		return fromPf;
	}

	public void setFromPf(String fromPf) {
		this.fromPf = fromPf;
	}

	public String[] getExceptionLenders() {
		return exceptionLenders;
	}

	public void setExceptionLenders(String[] exceptionLenders) {
		this.exceptionLenders = exceptionLenders;
	}

	public String getPartnerDealNumber() {
		return partnerDealNumber;
	}

	public void setPartnerDealNumber(String partnerDealNumber) {
		this.partnerDealNumber = partnerDealNumber;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public boolean isGenericCreditContract() {
		return isGenericCreditContract;
	}

	public void setGenericCreditContract(boolean isGenericCreditContract) {
		this.isGenericCreditContract = isGenericCreditContract;
	}

	public String getTaskName() {
		return TaskName;
	}

	public void setTaskName(String taskName) {
		TaskName = taskName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeliverySource() {
		return deliverySource;
	}

	public void setDeliverySource(String deliverySource) {
		this.deliverySource = deliverySource;
	}

	public String getConfirmBod() {
		return confirmBod;
	}

	public void setConfirmBod(String confirmBod) {
		this.confirmBod = confirmBod;
	}

	public boolean isDocInvalidFlag() {
		return docInvalidFlag;
	}

	public void setDocInvalidFlag(boolean docInvalidFlag) {
		this.docInvalidFlag = docInvalidFlag;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getRoKey() {
		return roKey;
	}

	public void setRoKey(String roKey) {
		this.roKey = roKey;
	}

	public CcvInputVO getCcvInputVO() {
		return ccvInputVO;
	}

	public void setCcvInputVO(CcvInputVO ccvInputVO) {
		this.ccvInputVO = ccvInputVO;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public DeContractValidationBo getContractValidation() {
		return contractValidation;
	}

	public List<JournalObjectVO> getListOfJournalObjects() {
		return listOfJournalObjects;
	}

	public void setContractValidation(DeContractValidationBo contractValidation) {
		this.contractValidation = contractValidation;
	}

	public void setListOfJournalObjects(List<JournalObjectVO> listOfJournalObjects) {
		this.listOfJournalObjects = listOfJournalObjects;
	}
	
	public DeDealBo getDeal() {
		return deal;
	}

	public void setDeal(DeDealBo deal) {
		this.deal = deal;
	}

	public void addToListOfJournalObjects(final JournalObjectVO journalObject) {
		if (this.listOfJournalObjects == null) {
			this.listOfJournalObjects = new ArrayList<>();
		}
		this.listOfJournalObjects.add(journalObject);
	}
	
	public ContractValidationContext getEcContext() {
		return ecContext;
	}

	public void setEcContext(final ContractValidationContext eccontext) {
		this.ecContext = eccontext;
	}

	public String getAccroutXml() {
		return accroutXml;
	}

	public void setAccroutXml(String accroutXml) {
		this.accroutXml = accroutXml;
	}
	
	public String getConversationId() {
		return conversationId;
	}

	public void setConversationId(final String conversationId) {
		this.conversationId = conversationId;
	}	

	public String getContractType() {
		return contractType;
	}

	public void setContractType(final String contractType) {
		this.contractType = contractType;
	}	

	public String getDestinationNameCode() {
		return destinationNameCode;
	}

	public Boolean getOldREValidationRequired() {
		return oldREValidationRequired;
	}

	public void setDestinationNameCode(final String destinationNameCode) {
		this.destinationNameCode = destinationNameCode;
	}

	public void setOldREValidationRequired(final Boolean oldREValidationRequired) {
		this.oldREValidationRequired = oldREValidationRequired;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CreditContractVO [productConfiguration=");
		builder.append(productConfiguration);
		builder.append(", appMsg=");
		builder.append(appMsg);
		builder.append(", partnerInfo=");
		builder.append(partnerInfo);
		builder.append(", dealerInfo=");
		builder.append(dealerInfo);
		builder.append(", cvTransmitVO=");
		builder.append(cvTransmitVO);
		builder.append(", dcDigitalDealVO=");
		builder.append(dcDigitalDealVO);
		builder.append(", dePartnerDestinationVO=");
		builder.append(dePartnerDestinationVO);
		builder.append(", accr=");
		builder.append(accr);
		builder.append(", messageProcessing=");
		builder.append(messageProcessing);
		builder.append(", ccvDataTranslationResultsDB=");
		builder.append(ccvDataTranslationResultsDB);
		builder.append(", eformsInputVO=");
		builder.append(eformsInputVO);
		builder.append(", ccvInputVO=");
		builder.append(ccvInputVO);
		builder.append(", billingTransType=");
		builder.append(billingTransType);
		builder.append(", timeStamp=");
		builder.append(timeStamp);
		builder.append(", requestXML=");
		builder.append(requestXML);
		builder.append(", rulesEngine=");
		builder.append(rulesEngine);
		builder.append(", attachmentZip=");
		builder.append(attachmentZip);
		builder.append(", adpDealNo=");
		builder.append(adpDealNo);
		builder.append(", valMessageDesc=");
		builder.append(valMessageDesc);
		builder.append(", valMessageCode=");
		builder.append(valMessageCode);
		builder.append(", soapFaultMessage=");
		builder.append(soapFaultMessage);
		builder.append(", soapFaultCode=");
		builder.append(soapFaultCode);
		builder.append(", confoutXml=");
		builder.append(confoutXml);
		builder.append(", accroutXml=");
		builder.append(accroutXml);
		builder.append(", fromPF=");
		builder.append(fromPF);
		builder.append(", contractFormNumber=");
		builder.append(contractFormNumber);
		builder.append(", contractFormRevisionDate=");
		builder.append(contractFormRevisionDate);
		builder.append(", contractExecutionState=");
		builder.append(contractExecutionState);
		builder.append(", appStatus=");
		builder.append(appStatus);
		builder.append(", vehicleMake=");
		builder.append(vehicleMake);
		builder.append(", validationError=");
		builder.append(validationError);
		builder.append(", vaultDocId=");
		builder.append(vaultDocId);
		builder.append(", lenderRequestXml=");
		builder.append(lenderRequestXml);
		builder.append(", lenderResponseXml=");
		builder.append(lenderResponseXml);
		builder.append(", fiConfig=");
		builder.append(fiConfig);
		builder.append(", vehicleModelDescription=");
		builder.append(vehicleModelDescription);
		builder.append(", stateGroup=");
		builder.append(stateGroup);
		builder.append(", transformerDateTime=");
		builder.append(transformerDateTime);
		builder.append(", documentId=");
		builder.append(documentId);
		builder.append(", attachmentFileName=");
		builder.append(attachmentFileName);
		builder.append(", creditContract=");
		builder.append(creditContract);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", lenderResponseMessage=");
		builder.append(lenderResponseMessage);
		builder.append(", caContext=");
		builder.append(caContext);
		builder.append(", serviceId=");
		builder.append(serviceId);
		builder.append(", locationId=");
		builder.append(locationId);
		builder.append(", applicationSource=");
		builder.append(applicationSource);
		builder.append(", applicationNumber=");
		builder.append(applicationNumber);
		builder.append(", vehicleYear=");
		builder.append(vehicleYear);
		builder.append(", vehicleModel=");
		builder.append(vehicleModel);
		builder.append(", productId=");
		builder.append(productId);
		builder.append(", fromPf=");
		builder.append(fromPf);
		builder.append(", partnerDealNumber=");
		builder.append(partnerDealNumber);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", isGenericCreditContract=");
		builder.append(isGenericCreditContract);
		builder.append(", TaskName=");
		builder.append(TaskName);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", deliverySource=");
		builder.append(deliverySource);
		builder.append(", confirmBod=");
		builder.append(confirmBod);
		builder.append(", docInvalidFlag=");
		builder.append(docInvalidFlag);
		builder.append(", transType=");
		builder.append(transType);
		builder.append(", roKey=");
		builder.append(roKey);
		builder.append(", operationName=");
		builder.append(operationName);
		builder.append(", contractValidation=");
		builder.append(contractValidation);
		builder.append(", deal=");
		builder.append(deal);
		builder.append(", ecContext=");
		builder.append(ecContext);
		builder.append(", listOfJournalObjects=");
		builder.append(listOfJournalObjects);
		builder.append(", exceptionLenders=");
		builder.append(Arrays.toString(exceptionLenders));
		builder.append("]");
		return builder.toString();
	}



}
