package com.ode.cv.vo;

import java.io.Serializable;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.properties.source.ConfigurationPropertyName.Form;

/**
 * @author rmathew
 *
 */
public class DeContractValidationBo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1874780631874871559L;

	private static final Logger logger = LogManager.getLogger(DeContractValidationBo.class);

	private String dealId;
	private String lenderId;
	private String dmsId;
	private String sequenceId;
	private String status;
	private Date statusTs;
	private Date submittedTs;
	private String dmsDealNum;
	private String lenderSeqNum;
	private String accountNum;
	private String dealerId;
	private String vin;
	private String buyerFirstName;
	private String buyerLastName;
	private String applicationNumber;
	private String applicationType;
	private Date contractDate;
	private String vaultDocId;
	private String spotFlag;
	private String fromPf;
	private String authorizationId;
	private String autoFundingIndicator;
	private String contractId;

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getLenderId() {
		return lenderId;
	}

	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public String getDmsId() {
		return dmsId;
	}

	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}

	public String getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStatusTs() {
		return statusTs;
	}

	public void setStatusTs(Date statusTs) {
		this.statusTs = statusTs;
	}

	public String getDmsDealNum() {
		return dmsDealNum;
	}

	public void setDmsDealNum(String dmsDealNum) {
		this.dmsDealNum = dmsDealNum;
	}

	public String getLenderSeqNum() {
		return lenderSeqNum;
	}

	public void setLenderSeqNum(String lenderSeqNum) {
		this.lenderSeqNum = lenderSeqNum;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	public String getBuyerLastName() {
		return buyerLastName;
	}

	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public Date getSubmittedTs() {
		return submittedTs;
	}

	public void setSubmittedTs(Date submittedTs) {
		this.submittedTs = submittedTs;
	}

	public Date getContractDate() {
		return contractDate;
	}

	public void setContractDate(Date contractDate) {
		this.contractDate = contractDate;
	}

	public String getVaultDocId() {
		return vaultDocId;
	}

	public void setVaultDocId(String vaultDocId) {
		this.vaultDocId = vaultDocId;
	}

	public String getSpotFlag() {
		return spotFlag;
	}

	public void setSpotFlag(String spotFlag) {
		this.spotFlag = spotFlag;
	}

	public String getFromPf() {
		return fromPf;
	}

	public void setFromPf(String fromPf) {
		this.fromPf = fromPf;
	}

	public String getAuthorizationId() {
		return authorizationId;
	}

	public String getAutoFundingIndicator() {
		return autoFundingIndicator;
	}

	public void setAuthorizationId(String authorizationId) {
		this.authorizationId = authorizationId;
	}

	public void setAutoFundingIndicator(String autoFundingIndicator) {
		this.autoFundingIndicator = autoFundingIndicator;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public void updateWith(DeContractValidationBo from) {
		logger.debug("Entered updateWith()");
		if (from.getDealId() != null && !from.getDealId().isEmpty()) {
			setDealId(from.getDealId());
		}
		if (from.getLenderId() != null && !from.getLenderId().isEmpty()) {
			setLenderId(from.getLenderId());
		}
		if (from.getDmsId() != null && !from.getDmsId().isEmpty()) {
			setDmsId(from.getDmsId());
		}
		if (from.getSequenceId() != null && !from.getSequenceId().isEmpty()) {
			setSequenceId(from.getSequenceId());
		}
		if (from.getStatus() != null && !from.getStatus().isEmpty()) {
			setStatus(from.getStatus());
		}
		if (from.getStatusTs() != null) {
			setStatusTs(from.getStatusTs());
		}
		if (from.getSubmittedTs() != null) {
			setSubmittedTs(from.getSubmittedTs());
		}
		if (from.getDmsDealNum() != null && !from.getDmsDealNum().isEmpty()) {
			setDmsDealNum(from.getDmsDealNum());
		}
		if (from.getLenderSeqNum() != null && !from.getLenderSeqNum().isEmpty()) {
			setLenderSeqNum(from.getLenderSeqNum());
		}
		if (from.getAccountNum() != null && !from.getAccountNum().isEmpty()) {
			setAccountNum(from.getAccountNum());
		}
		if (from.getApplicationType() != null && !from.getApplicationType().isEmpty()) {
			setApplicationType(from.getApplicationType());
		}
		if (from.getDealerId() != null && !from.getDealerId().isEmpty()) {
			setDealerId(from.getDealerId());
		}
		if (from.getVin() != null && !from.getVin().isEmpty()) {
			setVin(from.getVin());
		}
		if (from.getBuyerFirstName() != null && !from.getBuyerFirstName().isEmpty()) {
			setBuyerFirstName(from.getBuyerFirstName());
		}
		if (from.getBuyerLastName() != null && !from.getBuyerLastName().isEmpty()) {
			setBuyerLastName(from.getBuyerLastName());
		}
		if (from.getBuyerLastName() != null && !from.getBuyerLastName().isEmpty()) {
			setBuyerLastName(from.getBuyerLastName());
		}
		if (from.getVaultDocId() != null && !from.getVaultDocId().isEmpty()) {
			setVaultDocId(from.getVaultDocId());
		}
		if (from.getFromPf() != null && !from.getFromPf().isEmpty()) {
			setFromPf(from.getFromPf());
		}
		if (from.getApplicationType() != null && !from.getApplicationType().isEmpty()) {
			setApplicationType(from.getApplicationType());
		}
		if (from.getContractId() != null && !from.getContractId().isEmpty()) {
			setContractId(from.getContractId());
		}
		logger.exit(this);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeContractValidationBo [dealId=");
		builder.append(dealId);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", dmsId=");
		builder.append(dmsId);
		builder.append(", sequenceId=");
		builder.append(sequenceId);
		builder.append(", status=");
		builder.append(status);
		builder.append(", statusTs=");
		builder.append(statusTs);
		builder.append(", submittedTs=");
		builder.append(submittedTs);
		builder.append(", dmsDealNum=");
		builder.append(dmsDealNum);
		builder.append(", lenderSeqNum=");
		builder.append(lenderSeqNum);
		builder.append(", accountNum=");
		builder.append(accountNum);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append(", vin=");
		builder.append(vin);
		builder.append(", buyerFirstName=");
		builder.append(buyerFirstName);
		builder.append(", buyerLastName=");
		builder.append(buyerLastName);
		builder.append(", applicationNumber=");
		builder.append(applicationNumber);
		builder.append(", applicationType=");
		builder.append(applicationType);
		builder.append(", contractDate=");
		builder.append(contractDate);
		builder.append(", vaultDocId=");
		builder.append(vaultDocId);
		builder.append(", spotFlag=");
		builder.append(spotFlag);
		builder.append(", fromPf=");
		builder.append(fromPf);
		builder.append(", authorizationId=");
		builder.append(authorizationId);
		builder.append(", autoFundingIndicator=");
		builder.append(autoFundingIndicator);
		builder.append(", contractId=");
		builder.append(contractId);
		builder.append("]");
		return builder.toString();
	}

}
