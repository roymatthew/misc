package com.ode.cv.vo;

import java.io.Serializable;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author rmathew
 *
 */
public class DeDealBo  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1192324091923850907L;

	private static final Logger logger = LogManager.getLogger(DeDealBo.class);	

	private String deDealId;
	private String lenderDealerId;
	private String dmsDealerId;
	private String dmsDealNum;
	private String dealerName;
	private String vaultDocId;
	private String lenderId;
	private String dmsId;
	private String financeType;
	private String dealExecutionState;
	private String vin;
	private String buyerFirstName;
	private String buyerLastName;
	private String caSequenceId;
	private String caApplicationNum;
	private String caStatus;
	private Date caStatusTs;	
	private Date caSubmittedTs;
	private String cvSequenceId;
	private String cvStatus;
	private Date cvStatusTs;
	private Date cvSubmittedTs;
	private String lenderSeqNum;
	private String accountNum;
	private String applicationType;
	private String fundingStatus;
	private Date fundingStatusTs;
	private Date distributionTs;	
	private String eConStatus;
	private Date eConStatusTs;
	private Date eConSubmittedTs;
	private Date contractDate;
	private String spotFlag;
	private String term;
	private String loanAmount;
	private String productType;
	private String vehicleCondition;
	
	public void updateWith(DeDealBo from) {
		logger.debug("Entered updateWith() method of DeDealBo class");
		
		if(from.getDeDealId() != null && !from.getDeDealId().isEmpty()){
			setDeDealId(from.getDeDealId());
		}
		if(from.getLenderDealerId() != null && !from.getLenderDealerId().isEmpty()){
			setLenderDealerId(from.getLenderDealerId());
		}
		if(from.getDmsDealerId() != null && !from.getDmsDealerId().isEmpty()){
			setDmsDealerId(from.getDmsDealerId());
		}
		if(from.getDmsDealNum() != null && !from.getDmsDealNum().isEmpty()){
			setDmsDealNum(from.getDmsDealNum());
		}
		if(from.getVaultDocId() != null && !from.getVaultDocId().isEmpty()){
			setVaultDocId(from.getVaultDocId());
		}
		if(from.getLenderId() != null && !from.getLenderId().isEmpty()){
			setLenderId(from.getLenderId());
		}
		if(from.getDmsId() != null && !from.getDmsId().isEmpty()){
			setDmsId(from.getDmsId());
		}
		if(from.getFinanceType() != null && !from.getFinanceType().isEmpty()){
			setFinanceType(from.getFinanceType());
		}
		if(from.getDealExecutionState() != null && !from.getDealExecutionState().isEmpty()){
			setDealExecutionState(from.getDealExecutionState());
		}
		if(from.getVin() != null && !from.getVin().isEmpty()){
			setVin(from.getVin());
		}
		if(from.getBuyerFirstName() != null && !from.getBuyerFirstName().isEmpty()){
			setBuyerFirstName(from.getBuyerFirstName());
		}
		if(from.getBuyerLastName() != null && !from.getBuyerLastName().isEmpty()){
			setBuyerLastName(from.getBuyerLastName());
		}
		if(from.getCaSequenceId() != null && !from.getCaSequenceId().isEmpty()){
			setCaSequenceId(from.getCaSequenceId());
		}
		if(from.getCaApplicationNum() != null && !from.getCaApplicationNum().isEmpty()){
			setCaApplicationNum(from.getCaApplicationNum());
		}
		if(from.getApplicationType() != null && !from.getApplicationType().isEmpty()) {
			setApplicationType(from.getApplicationType());
		}
		if(from.getCaStatus() != null && !from.getCaStatus().isEmpty()){
			setCaStatus(from.getCaStatus());
		}
		if(from.getCaStatusTs() != null){
			setCaStatusTs(from.getCaStatusTs());
		}
		if(from.getCaSubmittedTs() != null){
			setCaSubmittedTs(from.getCaSubmittedTs());
		}
		if(from.getCvSequenceId() != null && !from.getCvSequenceId().isEmpty()){
			setCvSequenceId(from.getCvSequenceId());
		}
		if(from.getCvStatus() != null && !from.getCvStatus().isEmpty()){
			setCvStatus(from.getCvStatus());
		}
		if(from.getCvStatusTs() != null){
			setCvStatusTs(from.getCvStatusTs());
		}
		if(from.getCvSubmittedTs() != null){
			setCvSubmittedTs(from.getCvSubmittedTs());
		}
		if(from.getLenderSeqNum() != null && !from.getLenderSeqNum().isEmpty()){
			setLenderSeqNum(from.getLenderSeqNum());
		}
		if(from.getAccountNum() != null && !from.getAccountNum().isEmpty()){
			setAccountNum(from.getAccountNum());
		}
		if(from.getFundingStatus() != null && !from.getFundingStatus().isEmpty()){
			setFundingStatus(from.getFundingStatus());
		}
		if(from.getFundingStatusTs() != null){
			setFundingStatusTs(from.getFundingStatusTs());
		}
		if(from.getDistributionTs() != null){
			setDistributionTs(from.getDistributionTs());
		}
		if(from.geteConStatus() != null && !from.geteConStatus().isEmpty()){
			seteConStatus(from.geteConStatus());
		}
		if(from.geteConStatusTs() != null){
			seteConStatusTs(from.geteConStatusTs());
		}
		if(from.geteConSubmittedTs() != null){
			seteConSubmittedTs(from.geteConSubmittedTs());
		}
		if(from.getContractDate() != null){
			setContractDate(from.getContractDate());
		}
		if(from.getSpotFlag() != null){
			setSpotFlag(from.getSpotFlag());
		}
		if(from.getTerm() != null){
			setTerm(from.getTerm());
		}
		if(from.getLoanAmount() != null){
			setLoanAmount(from.getLoanAmount());
		}
		if(from.getProductType() != null){
			setProductType(from.getProductType());
		}
		if(from.getVehicleCondition() != null){
			setVehicleCondition(from.getVehicleCondition());
		}
	}
	public String getDeDealId() {
		return deDealId;
	}
	public void setDeDealId(String deDealId) {
		this.deDealId = deDealId;
	}	
	public String getDealerName() {
		return dealerName;
	}
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}
	public String getLenderDealerId() {
		return lenderDealerId;
	}
	public void setLenderDealerId(String lenderDealerId) {
		this.lenderDealerId = lenderDealerId;
	}
	public String getDmsDealerId() {
		return dmsDealerId;
	}
	public void setDmsDealerId(String dmsDealerId) {
		this.dmsDealerId = dmsDealerId;
	}
	public String getDmsDealNum() {
		return dmsDealNum;
	}
	public void setDmsDealNum(String dmsDealNum) {
		this.dmsDealNum = dmsDealNum;
	}
	public String getVaultDocId() {
		return vaultDocId;
	}
	public void setVaultDocId(String vaultDocId) {
		this.vaultDocId = vaultDocId;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}
	public String getDmsId() {
		return dmsId;
	}
	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}
	public String getFinanceType() {
		return financeType;
	}
	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}
	public String getDealExecutionState() {
		return dealExecutionState;
	}
	public void setDealExecutionState(String dealExecutionState) {
		this.dealExecutionState = dealExecutionState;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getBuyerFirstName() {
		return buyerFirstName;
	}
	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}
	public String getBuyerLastName() {
		return buyerLastName;
	}
	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}
	public String getCaSequenceId() {
		return caSequenceId;
	}
	public void setCaSequenceId(String caSequenceId) {
		this.caSequenceId = caSequenceId;
	}
	public String getCaApplicationNum() {
		return caApplicationNum;
	}
	public void setCaApplicationNum(String caApplicationNum) {
		this.caApplicationNum = caApplicationNum;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getCaStatus() {
		return caStatus;
	}
	public void setCaStatus(String caStatus) {
		this.caStatus = caStatus;
	}
	public Date getCaStatusTs() {
		return caStatusTs;
	}
	public void setCaStatusTs(Date caStatusTs) {
		this.caStatusTs = caStatusTs;
	}
	public Date getCaSubmittedTs() {
		return caSubmittedTs;
	}
	public void setCaSubmittedTs(Date caSubmittedTs) {
		this.caSubmittedTs = caSubmittedTs;
	}
	public String getCvSequenceId() {
		return cvSequenceId;
	}
	public void setCvSequenceId(String cvSequenceId) {
		this.cvSequenceId = cvSequenceId;
	}
	public String getCvStatus() {
		return cvStatus;
	}
	public void setCvStatus(String cvStatus) {
		this.cvStatus = cvStatus;
	}
	public Date getCvStatusTs() {
		return cvStatusTs;
	}
	public void setCvStatusTs(Date cvStatusTs) {
		this.cvStatusTs = cvStatusTs;
	}
	public Date getCvSubmittedTs() {
		return cvSubmittedTs;
	}
	public void setCvSubmittedTs(Date cvSubmittedTs) {
		this.cvSubmittedTs = cvSubmittedTs;
	}
	public String getLenderSeqNum() {
		return lenderSeqNum;
	}
	public void setLenderSeqNum(String lenderSeqNum) {
		this.lenderSeqNum = lenderSeqNum;
	}
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getFundingStatus() {
		return fundingStatus;
	}
	public void setFundingStatus(String fundingStatus) {
		this.fundingStatus = fundingStatus;
	}
	public Date getFundingStatusTs() {
		return fundingStatusTs;
	}
	public void setFundingStatusTs(Date fundingStatusTs) {
		this.fundingStatusTs = fundingStatusTs;
	}
	public Date getDistributionTs() {
		return distributionTs;
	}
	public void setDistributionTs(Date distributionTs) {
		this.distributionTs = distributionTs;
	}
	public String geteConStatus() {
		return eConStatus;
	}
	public void seteConStatus(String eConStatus) {
		this.eConStatus = eConStatus;
	}
	public Date geteConStatusTs() {
		return eConStatusTs;
	}
	public void seteConStatusTs(Date eConStatusTs) {
		this.eConStatusTs = eConStatusTs;
	}
	public Date geteConSubmittedTs() {
		return eConSubmittedTs;
	}
	public void seteConSubmittedTs(Date eConSubmittedTs) {
		this.eConSubmittedTs = eConSubmittedTs;
	}
	public Date getContractDate() {
		return contractDate;
	}
	public void setContractDate(Date contractDate) {
		this.contractDate = contractDate;
	}
	public String getSpotFlag() {
		return spotFlag;
	}
	public void setSpotFlag(String spotFlag) {
		this.spotFlag = spotFlag;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getVehicleCondition() {
		return vehicleCondition;
	}
	public void setVehicleCondition(String vehicleCondition) {
		this.vehicleCondition = vehicleCondition;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeDealBo [deDealId=");
		builder.append(deDealId);
		builder.append(", lenderDealerId=");
		builder.append(lenderDealerId);
		builder.append(", dmsDealerId=");
		builder.append(dmsDealerId);
		builder.append(", dmsDealNum=");
		builder.append(dmsDealNum);
		builder.append(", vaultDocId=");
		builder.append(vaultDocId);
		builder.append(", lenderId=");
		builder.append(lenderId);
		builder.append(", dmsId=");
		builder.append(dmsId);
		builder.append(", financeType=");
		builder.append(financeType);
		builder.append(", dealExecutionState=");
		builder.append(dealExecutionState);
		builder.append(", vin=");
		builder.append(vin);
		builder.append(", buyerFirstName=");
		builder.append(buyerFirstName);
		builder.append(", buyerLastName=");
		builder.append(buyerLastName);
		builder.append(", caSequenceId=");
		builder.append(caSequenceId);
		builder.append(", caApplicationNum=");
		builder.append(caApplicationNum);
		builder.append(", applicationType=");
		builder.append(applicationType);
		builder.append(", caStatus=");
		builder.append(caStatus);
		builder.append(", caStatusTs=");
		builder.append(caStatusTs);
		builder.append(", caSubmittedTs=");
		builder.append(caSubmittedTs);
		builder.append(", cvSequenceId=");
		builder.append(cvSequenceId);
		builder.append(", cvStatus=");
		builder.append(cvStatus);
		builder.append(", cvStatusTs=");
		builder.append(cvStatusTs);
		builder.append(", cvSubmittedTs=");
		builder.append(cvSubmittedTs);
		builder.append(", lenderSeqNum=");
		builder.append(lenderSeqNum);
		builder.append(", accountNum=");
		builder.append(accountNum);
		builder.append(", fundingStatus=");
		builder.append(fundingStatus);
		builder.append(", fundingStatusTs=");
		builder.append(fundingStatusTs);
		builder.append(", distributionTs=");
		builder.append(distributionTs);
		builder.append(", eConStatus=");
		builder.append(eConStatus);
		builder.append(", eConStatusTs=");
		builder.append(eConStatusTs);
		builder.append(", eConSubmittedTs=");
		builder.append(eConSubmittedTs);
		builder.append(", contractDate=");
		builder.append(contractDate);
		builder.append(", spotFlag=");
		builder.append(spotFlag);
		builder.append(", term=");
		builder.append(term);
		builder.append(", loanAmount=");
		builder.append(loanAmount);
		builder.append(", productType=");
		builder.append(productType);
		builder.append(", vehicleCondition=");
		builder.append(vehicleCondition);
		builder.append("]");
		return builder.toString();
	}
	
}
