package com.ode.cv.vo;

import java.io.Serializable;

/**
 * @author snimma
 *
 */
public class DealerInfoVO implements Serializable {

	/**
	 * Generated serial version id.
	 */
	private static final long serialVersionUID = -5748079461435061969L;
	private String systemId;
	private String dealerId;
	private String dspId;
	private String dealerName;
	private String partnerId;
	private String storeNumber;
	private String dealerPartyId;

	/**
	 * @return the systemId
	 */
	public String getSystemId() {
		return systemId;
	}

	/**
	 * @param systemId the systemId to set
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	/**
	 * @return the dealerId
	 */
	public String getDealerId() {
		return dealerId;
	}

	/**
	 * @param dealerId the dealerId to set
	 */
	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	/**
	 * @return the dspId
	 */
	public String getDspId() {
		return dspId;
	}

	/**
	 * @param dspId the dspId to set
	 */
	public void setDspId(String dspId) {
		this.dspId = dspId;
	}

	/**
	 * @return the dealerName
	 */
	public String getDealerName() {
		return dealerName;
	}

	/**
	 * @param dealerName the dealerName to set
	 */
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	/**
	 * @return the partnerId
	 */
	public String getPartnerId() {
		return partnerId;
	}

	/**
	 * @param partnerId the partnerId to set
	 */
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}	

	public String getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}	

	public String getDealerPartyId() {
		return dealerPartyId;
	}

	public void setDealerPartyId(String dealerPartyId) {
		this.dealerPartyId = dealerPartyId;
	}

	public DealerInfoVO() {
		super();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DealerInfoVO [systemId=");
		builder.append(systemId);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append(", dspId=");
		builder.append(dspId);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", partnerId=");
		builder.append(partnerId);
		builder.append(", storeNumber=");
		builder.append(storeNumber);
		builder.append("]");
		return builder.toString();
	}

}
