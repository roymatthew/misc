package com.ode.cv.vo;

import java.math.BigInteger;
import java.util.List;

public class DirectRenderResponseQueueMessageVO {

	private BigInteger ecout2Key;
	private List<DirectRenderResponseVO> directRenderResponseList;
	
	public BigInteger getEcout2Key() {
		return ecout2Key;
	}
	
	public void setEcout2Key(BigInteger ecout2Key) {
		this.ecout2Key = ecout2Key;
	}
	
	public List<DirectRenderResponseVO> getDirectRenderResponseList() {
		return directRenderResponseList;
	}
	
	public void setDirectRenderResponseList(List<DirectRenderResponseVO> directRenderResponseList) {
		this.directRenderResponseList = directRenderResponseList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DirectRenderResponseQueueMessage [ecout2Key=");
		builder.append(ecout2Key);
		builder.append(", directRenderResponseList=");
		builder.append(directRenderResponseList);
		builder.append("]");
		return builder.toString();
	}
}