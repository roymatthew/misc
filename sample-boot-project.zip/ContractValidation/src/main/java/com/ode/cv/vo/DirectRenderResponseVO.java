package com.ode.cv.vo;

import java.util.List;

public class DirectRenderResponseVO {

	private Integer formId;
	private Integer subformId;
	private String printableForm;
	private String subformName;
	private String outputFormat;
	private Integer printOrder;
	private String paperType;
	private PageDetailsVO pageDetails;
	private List<SignatureCoordinatesVO> signatureCoordinates;
	private List<ExpressionVO> expressions;
	private Integer profileIdUsed;
	private String errorCode;
	private String status;
	private String errorMessage;
	private Boolean userEditable;
	
	public Integer getFormId() {
		return formId;
	}
	
	public void setFormId(Integer formId) {
		this.formId = formId;
	}
	
	public Integer getSubformId() {
		return subformId;
	}

	public void setSubformId(Integer subformId) {
		this.subformId = subformId;
	}

	public String getPrintableForm() {
		return printableForm;
	}
	
	public void setPrintableForm(String printableForm) {
		this.printableForm = printableForm;
	}
	
	public String getOutputFormat() {
		return outputFormat;
	}
	
	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}
	
	public Integer getPrintOrder() {
		return printOrder;
	}
	
	public void setPrintOrder(Integer printOrder) {
		this.printOrder = printOrder;
	}
	
	public String getPaperType() {
		return paperType;
	}
	
	public void setPaperType(String paperType) {
		this.paperType = paperType;
	}
	
	public List<SignatureCoordinatesVO> getSignatureCoordinates() {
		return signatureCoordinates;
	}
	
	public void setSignatureCoordinates(List<SignatureCoordinatesVO> signatureCoordinates) {
		this.signatureCoordinates = signatureCoordinates;
	}
	
	public List<ExpressionVO> getExpressions() {
		return expressions;
	}
	
	public void setExpressions(List<ExpressionVO> expressions) {
		this.expressions = expressions;
	}

	public PageDetailsVO getPageDetails() {
		return pageDetails;
	}

	public void setPageDetails(PageDetailsVO pageDetails) {
		this.pageDetails = pageDetails;
	}

	public Integer getProfileIdUsed() {
		return profileIdUsed;
	}

	public void setProfileIdUsed(Integer profileIdUsed) {
		this.profileIdUsed = profileIdUsed;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getSubformName() {
		return subformName;
	}

	public void setSubformName(String subformName) {
		this.subformName = subformName;
	}

	public Boolean getUserEditable() {
		return userEditable;
	}

	public void setUserEditable(Boolean userEditable) {
		this.userEditable = userEditable;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DirectRenderResponse [formId=");
		builder.append(formId);
		builder.append(", subformId=");
		builder.append(subformId);
		builder.append(", printableForm=");
		builder.append(printableForm);
		builder.append(", subformName=");
		builder.append(subformName);
		builder.append(", outputFormat=");
		builder.append(outputFormat);
		builder.append(", printOrder=");
		builder.append(printOrder);
		builder.append(", paperType=");
		builder.append(paperType);
		builder.append(", pageDetails=");
		builder.append(pageDetails);
		builder.append(", signatureCoordinates=");
		builder.append(signatureCoordinates);
		builder.append(", expressions=");
		builder.append(expressions);
		builder.append(", profileIdUsed=");
		builder.append(profileIdUsed);
		builder.append(", errorCode=");
		builder.append(errorCode);
		builder.append(", status=");
		builder.append(status);
		builder.append(", errorMessage=");
		builder.append(errorMessage);
		builder.append(", userEditable=");
		builder.append(userEditable);
		builder.append("]");
		return builder.toString();
	}
}