package com.ode.cv.vo;

import java.io.Serializable;

/**
 * @author rmathew
 *
 */
public class ECConfinVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4886060982721276067L;
	
	private String requestXML;
	private String ecConfinMessage;
	private int statusCode;
	private String statusMessage;
	private String dmsId;
	private String lenderId;	
	
	public ECConfinVO() {		
	}
	
	public ECConfinVO(String dspId, String lenderId) {
		this.dmsId = dspId;
		this.lenderId = lenderId;
	}
	
	public String getRequestXML() {
		return requestXML;
	}
	public String getEcConfinMessage() {
		return ecConfinMessage;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public String getDmsId() {
		return dmsId;
	}
	public String getLenderId() {
		return lenderId;
	}
	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	public void setEcConfinMessage(String ecConfinMessage) {
		this.ecConfinMessage = ecConfinMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public void setDmsId(String dmsId) {
		this.dmsId = dmsId;
	}
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}


}
