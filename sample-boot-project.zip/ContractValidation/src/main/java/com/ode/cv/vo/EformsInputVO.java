/**
 * 
 */
package com.ode.cv.vo;

import java.io.Serializable;

import com.ode.persistence.vo.DeContractValidationVO;
import com.ode.persistence.vo.DeCreditApplicationVO;
import com.ode.persistence.vo.DeDealVO;

/**
 * @author snimma
 *
 */
public class EformsInputVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4996990158728959640L;
	private DeDealVO deDealVO;
	private DeCreditApplicationVO deCreditApplicationVO;
	private DeContractValidationVO deContractValidationVO;

	/**
	 * @return the deDealVO
	 */
	public DeDealVO getDeDealVO() {
		return deDealVO;
	}

	/**
	 * @param deDealVO the deDealVO to set
	 */
	public void setDeDealVO(DeDealVO deDealVO) {
		this.deDealVO = deDealVO;
	}

	/**
	 * @return the deCreditApplicationVO
	 */
	public DeCreditApplicationVO getDeCreditApplicationVO() {
		return deCreditApplicationVO;
	}

	/**
	 * @param deCreditApplicationVO the deCreditApplicationVO to set
	 */
	public void setDeCreditApplicationVO(DeCreditApplicationVO deCreditApplicationVO) {
		this.deCreditApplicationVO = deCreditApplicationVO;
	}

	/**
	 * @return the deContractValidationVO
	 */
	public DeContractValidationVO getDeContractValidationVO() {
		return deContractValidationVO;
	}

	/**
	 * @param deContractValidationVO the deContractValidationVO to set
	 */
	public void setDeContractValidationVO(DeContractValidationVO deContractValidationVO) {
		this.deContractValidationVO = deContractValidationVO;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EformsInputVO [deDealVO=");
		builder.append(deDealVO);
		builder.append(", deCreditApplicationVO=");
		builder.append(deCreditApplicationVO);
		builder.append(", deContractValidationVO=");
		builder.append(deContractValidationVO);
		builder.append("]");
		return builder.toString();
	}

}
