package com.ode.cv.vo;

import java.util.List;

public class ExpressionVO {
	
	private String name; 
	private String value;
	private List<AttributeUsedVO> attributesUsed;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public List<AttributeUsedVO> getAttributesUsed() {
		return attributesUsed;
	}
	
	public void setAttributesUsed(List<AttributeUsedVO> attributesUsed) {
		this.attributesUsed = attributesUsed;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Expression [name=");
		builder.append(name);
		builder.append(", value=");
		builder.append(value);
		builder.append(", attributesUsed=");
		builder.append(attributesUsed);
		builder.append("]");
		return builder.toString();
	}
}