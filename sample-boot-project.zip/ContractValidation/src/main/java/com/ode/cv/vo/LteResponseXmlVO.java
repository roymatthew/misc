package com.ode.cv.vo;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author rmathew
 *
 */
public class LteResponseXmlVO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3101040515100754408L;
	
	private Integer xmlId;
	private String lteOutputXml;
	private String accrXml;
	private Timestamp createdDate;
	public Integer getXmlId() {
		return xmlId;
	}
	public void setXmlId(Integer xmlId) {
		this.xmlId = xmlId;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getLteOutputXml() {
		return lteOutputXml;
	}
	public String getAccrXml() {
		return accrXml;
	}
	public void setLteOutputXml(String lteOutputXml) {
		this.lteOutputXml = lteOutputXml;
	}
	public void setAccrXml(String accrXml) {
		this.accrXml = accrXml;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accrXml == null) ? 0 : accrXml.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((lteOutputXml == null) ? 0 : lteOutputXml.hashCode());
		result = prime * result + ((xmlId == null) ? 0 : xmlId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LteResponseXmlVO other = (LteResponseXmlVO) obj;
		if (accrXml == null) {
			if (other.accrXml != null)
				return false;
		} else if (!accrXml.equals(other.accrXml))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (lteOutputXml == null) {
			if (other.lteOutputXml != null)
				return false;
		} else if (!lteOutputXml.equals(other.lteOutputXml))
			return false;
		if (xmlId == null) {
			if (other.xmlId != null)
				return false;
		} else if (!xmlId.equals(other.xmlId))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "LteResponseXmlVO [xmlId=" + xmlId + ", lteOutputXml=" + lteOutputXml + ", accrXml=" + accrXml
				+ ", createdDate=" + createdDate + "]";
	}
	
	
	
	

}
