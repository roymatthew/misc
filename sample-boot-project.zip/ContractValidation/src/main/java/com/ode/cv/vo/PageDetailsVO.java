package com.ode.cv.vo;

import java.math.BigDecimal;

public class PageDetailsVO {

	private BigDecimal width;
	private BigDecimal height;
	private String measurementType;
	
	public BigDecimal getWidth() {
		return width;
	}
	
	public void setWidth(BigDecimal width) {
		this.width = width;
	}
	
	public BigDecimal getHeight() {
		return height;
	}
	
	public void setHeight(BigDecimal height) {
		this.height = height;
	}
	
	public String getMeasurementType() {
		return measurementType;
	}
	
	public void setMeasurementType(String measurementType) {
		this.measurementType = measurementType;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PageDetails [width=");
		builder.append(width);
		builder.append(", height=");
		builder.append(height);
		builder.append(", measurementType=");
		builder.append(measurementType);
		builder.append("]");
		return builder.toString();
	}
}