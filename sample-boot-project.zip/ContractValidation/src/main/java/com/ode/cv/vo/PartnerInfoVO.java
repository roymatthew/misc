package com.ode.cv.vo;

import java.io.Serializable;

/**
 * @author snimma
 *
 */
public class PartnerInfoVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1101215734646328640L;
	private String lenderId;
	private String lenderAccountId;
	private String dspId;
	private String systemId;
	private String globalLenderId;

	/**
	 * @return the lenderId
	 */
	public String getLenderId() {
		return lenderId;
	}

	/**
	 * @param lenderId the lenderId to set
	 */
	public void setLenderId(String lenderId) {
		this.lenderId = lenderId;
	}

	/**
	 * @return the lenderAccountId
	 */
	public String getLenderAccountId() {
		return lenderAccountId;
	}

	/**
	 * @param lenderAccountId the lenderAccountId to set
	 */
	public void setLenderAccountId(String lenderAccountId) {
		this.lenderAccountId = lenderAccountId;
	}

	/**
	 * @return the dspId
	 */
	public String getDspId() {
		return dspId;
	}

	/**
	 * @param dspId the dspId to set
	 */
	public void setDspId(String dspId) {
		this.dspId = dspId;
	}

	/**
	 * @return the systemId
	 */
	public String getSystemId() {
		return systemId;
	}

	/**
	 * @param systemId the systemId to set
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	/**
	 * @return the globalLenderId
	 */
	public String getGlobalLenderId() {
		return globalLenderId;
	}

	/**
	 * @param globalLenderId the globalLenderId to set
	 */
	public void setGlobalLenderId(String globalLenderId) {
		this.globalLenderId = globalLenderId;
	}

	public PartnerInfoVO() {
		super();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PartnerInfoVO [lenderId=");
		builder.append(lenderId);
		builder.append(", lenderAccountId=");
		builder.append(lenderAccountId);
		builder.append(", dspId=");
		builder.append(dspId);
		builder.append(", systemId=");
		builder.append(systemId);
		builder.append(", globalLenderId=");
		builder.append(globalLenderId);
		builder.append("]");
		return builder.toString();
	}

}
