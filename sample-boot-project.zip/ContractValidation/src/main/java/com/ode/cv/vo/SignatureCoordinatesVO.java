package com.ode.cv.vo;

import java.math.BigDecimal;

public class SignatureCoordinatesVO {
	
	private int pageNumber;
	private String fieldName;
	private BigDecimal positionFromLeft;
	private BigDecimal positionFromTop;
	private BigDecimal width;
	private BigDecimal height;
	private String measurementType;
	
	public int getPageNumber() {
		return pageNumber;
	}
	
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	
	public String getFieldName() {
		return fieldName;
	}
	
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	public BigDecimal getPositionFromLeft() {
		return positionFromLeft;
	}
	
	public void setPositionFromLeft(BigDecimal positionFromLeft) {
		this.positionFromLeft = positionFromLeft;
	}
	
	public BigDecimal getPositionFromTop() {
		return positionFromTop;
	}

	public void setPositionFromTop(BigDecimal positionFromTop) {
		this.positionFromTop = positionFromTop;
	}

	public BigDecimal getWidth() {
		return width;
	}
	
	public void setWidth(BigDecimal width) {
		this.width = width;
	}
	
	public String getMeasurementType() {
		return measurementType;
	}

	public void setMeasurementType(String measurementType) {
		this.measurementType = measurementType;
	}

	public BigDecimal getHeight() {
		return height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SignatureCoordinates [pageNumber=");
		builder.append(pageNumber);
		builder.append(", fieldName=");
		builder.append(fieldName);
		builder.append(", positionFromLeft=");
		builder.append(positionFromLeft);
		builder.append(", positionFromTop=");
		builder.append(positionFromTop);
		builder.append(", width=");
		builder.append(width);
		builder.append(", height=");
		builder.append(height);
		builder.append(", measurementType=");
		builder.append(measurementType);
		builder.append("]");
		return builder.toString();
	}
}