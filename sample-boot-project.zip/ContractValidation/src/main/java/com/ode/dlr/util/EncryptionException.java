package com.ode.dlr.util;

import com.ode.dlr.util.AppException;

/**
 * Exception that is throw by the EncryptionUtils class.
 * 
 * @author Robert Roeser
 * 
 */
public class EncryptionException extends AppException {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EncryptionException(String msg,Throwable t,String context,String pgm){
		super(msg,t,context,pgm);
	}

}
