package com.ode.dlr.util;

public class SignatureVerificationException extends Exception {	
	private static final long serialVersionUID = -530966204722759551L;
	private String message;
	
	public SignatureVerificationException(String message){
		this.setMessage(message);
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
