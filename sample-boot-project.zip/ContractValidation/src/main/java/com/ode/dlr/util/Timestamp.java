package com.ode.dlr.util;

/**
 * Timestamp class to create unique timestamp with microseconds to complement Java Timestamp which 
 * has only upto milliseconds
 * toString outputs in the format yyyy-mm-dd hh:mm:ss.ffffff where ffffff is the nanofield but outputs
 * upto microseconds only. Ex 2009-07-15 10:37:06.421019 
 * 
 */
public class Timestamp implements java.io.Serializable
{
   /**
	 * 
	 */
   private static final long serialVersionUID = 1L;
   private static int microCounter = 0;
   private final long timestamp;
   private static long lastMillis = 0L;

   /**
    * Constructs a unique current timestamp value upto micorseconds level
    */
   public Timestamp() 
   {
      synchronized (Timestamp.class) 
	  {
         long timeMillis = System.currentTimeMillis();
         if (lastMillis == timeMillis) {
            microCounter++;
            if (microCounter > 999 )
               System.out.println("Timestamp Counter overflow - Internal Error");
            
            this.timestamp = timeMillis*1000 + microCounter;
            return;
         }
         else
         {
            microCounter = 0; // rewind counter
            lastMillis = timeMillis;
            this.timestamp = timeMillis*1000;  //to get upto micorseconds
            return;
         }
      }
   }

   /**
    * @return The exact timestamp in nanoseconds
    */
   public final long getTimestamp() {
      return timestamp;
   }

   /**
    * The nano part only
    * @return The nano part with fffffffff format only
    */
   public final int getNanosOnly() {
      return ((int)(timestamp % 1000000))*1000;
   }

   /**
    * timestamp with millis 
    */
   public final long getMillis() {
      return timestamp / 1000;
   }

   /**
    * Timestamp in JDBC Timestamp escape format 
    * @return The Timestamp in JDBC Timestamp escape format: "2002-02-10 10:52:40.879456789"
    */
   public String toString() {
         return getJDBCTimestamp().toString();
   }

   /**
    * create java.sql.Timestamp 
    * @return java.sql.Timestamp
    */
   public java.sql.Timestamp getJDBCTimestamp()
   {
	    java.sql.Timestamp ts = new java.sql.Timestamp(getMillis());
	    ts.setNanos(getNanosOnly());
	   	return ts;
   }

   /**
    * to test 
    * @param args
    */
   public static void main(String[] args) 
   {
   	
   	System.out.println("Current Time: "+System.currentTimeMillis());
   	System.out.println("Current JDBC Time\nTimestamp: "+(new java.sql.Timestamp(System.currentTimeMillis())).toString());

   	for(int i=0; i < 11; i++)
   	{
   		System.out.println("Timestamp: "+(new com.ode.dlr.util.Timestamp()).toString());
   	}
   	System.out.println("JDBC Timestamp");
   	for(int i=0; i < 11; i++)
   	{
   		System.out.println("Timestamp: "+(new com.ode.dlr.util.Timestamp()).getJDBCTimestamp().toString());
   	}

   }
}