package com.ode.cv.bo;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Test;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.ode.cv.util.CVUtil;
import com.ode.cv.util.Constants;
import com.ode.cv.vo.CreditContractVO;

public class LenderBOTest {

	@Test
	public void testMakeChangesToEcout() throws ParserConfigurationException, SAXException, IOException, TransformerException {
		
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/VOL-ECOUT2.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		VolLenderBO volLenderBO = new VolLenderBO();
		volLenderBO.makeChangesToEcout(getMockCreditContractVO(), document, getWebServiceFeatures());
		String restructedEcout = CVUtil.getXmlStringFromDocument(document);
		assertTrue(restructedEcout.contains(Constants.SOAP_HEADER_FA_SVC_CNTRL));
		assertTrue(restructedEcout.contains(Constants.TAG_NAME_PUT_REQUEST));		
	}

	private Map<String, String> getWebServiceFeatures() {
		Map<String, String> map = new HashMap<>();
		map.put(Constants.SOAP_HEADER_MSG_LANG_CODE, "en-US");
		map.put(Constants.SOAP_HEADER_SENDER_ID, "VOL");		
		map.put(Constants.SOAP_HEADER_TARGET_ID, "QA03");
		map.put(Constants.SOAP_HEADER_MESSAGE_TYPE, "ODEContractValidation");
		map.put(Constants.PUT_REQUEST_XMLNS, "http://Fiserv.com/AutoSolutions/2008/07");
		return map;
	}

	private CreditContractVO getMockCreditContractVO() {
		CreditContractVO vo = new CreditContractVO();
		vo.setDocumentId("0713933d-05c0-4e8b-9320-80af44933bd");
		return vo;
	}

}
