/**
 * 
 */
package com.ode.cv.data.translator;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Parasoft Jtest UTA: Test class for GcvProductGroupingBO
 *
 * @see com.ode.cv.data.translator.GcvProductGroupingBO
 * @author rmathew
 */
public class GcvProductGroupingBOTest {
	
	
	private static String AMOUNT_1000 = "1000";
	private static String DEFAULT_PRODUCT = "DefaultProduct";
	
	GcvProductGroupingBO underTest = null;
	
	@Before
	public void setUp()
	{
		underTest = new GcvProductGroupingBO();
	}


	/**
	 * Parasoft Jtest UTA: Test for getAmount()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getAmount()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetAmount() throws Throwable {
		// When
		underTest.setAmount(AMOUNT_1000);
		String result = underTest.getAmount();
		// Then
		assertEquals(AMOUNT_1000, result);
	}
	
	/**
	 * Parasoft Jtest UTA: Test for getDefaultProduct()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getDefaultProduct()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetDefaultProduct() throws Throwable {
		// When
		underTest.setDefaultProduct(DEFAULT_PRODUCT);
		String result = underTest.getDefaultProduct();

		// Then
		assertEquals(DEFAULT_PRODUCT, result);
	}

	/**
	 * Parasoft Jtest UTA: Test for getDefaultType()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getDefaultType()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetDefaultType() throws Throwable {
		// When
		String result = underTest.getDefaultType();

		// Then
		// assertEquals("", result);
	}

	/**
	 * Parasoft Jtest UTA: Test for getDescription()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getDescription()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetDescription() throws Throwable {
		// When
		String result = underTest.getDescription();

		// Then
		// assertEquals("", result);
	}

	/**
	 * Parasoft Jtest UTA: Test for getIndicator()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getIndicator()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetIndicator() throws Throwable {
		// When
		String result = underTest.getIndicator();

		// Then
		// assertEquals("", result);
	}

	/**
	 * Parasoft Jtest UTA: Test for getLimit()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getLimit()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetLimit() throws Throwable {
		// When
		String result = underTest.getLimit();

		// Then
		// assertEquals("", result);
	}

	/**
	 * Parasoft Jtest UTA: Test for getRate()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getRate()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetRate() throws Throwable {
		// When
		String result = underTest.getRate();

		// Then
		// assertEquals("", result);
	}

	/**
	 * Parasoft Jtest UTA: Test for getTerm()
	 *
	 * @see com.ode.cv.data.translator.GcvProductGroupingBO#getTerm()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetTerm() throws Throwable {
		// When
		String result = underTest.getTerm();

		// Then
		// assertEquals("", result);
	}
}