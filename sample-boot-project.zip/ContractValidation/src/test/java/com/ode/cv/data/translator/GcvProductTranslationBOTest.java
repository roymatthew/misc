/**
 * 
 */
package com.ode.cv.data.translator;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for GcvProductTranslationBO
 *
 * @see com.ode.cv.data.translator.GcvProductTranslationBO
 * @author rmathew
 */
public class GcvProductTranslationBOTest {
	
	private static final String TEST_DEALER_ID = "TestDealer100";

	GcvProductTranslationBO underTest = null;

	@Before
	public void setup() {
		underTest = new GcvProductTranslationBO();
	}

	/**
	 * Parasoft Jtest UTA: Test for getDealerId()
	 *
	 * @see com.ode.cv.data.translator.GcvProductTranslationBO#getDealerId()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetDealerId() throws Throwable {
		// When
		underTest.setDealerId(TEST_DEALER_ID);
		String result = underTest.getDealerId();

		// Then
		assertEquals(TEST_DEALER_ID, result);
	}
}