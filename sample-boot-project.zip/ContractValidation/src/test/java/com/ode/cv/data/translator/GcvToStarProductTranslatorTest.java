/**
 * 
 */
package com.ode.cv.data.translator;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.util.ReflectionUtils;

/**
 * Parasoft Jtest UTA: Test class for GcvToStarProductTranslator
 *
 * @see com.ode.cv.data.translator.GcvToStarProductTranslator
 * @author rmathew
 */
public class GcvToStarProductTranslatorTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	GcvToStarProductTranslator underTest;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for rollupMonthlyTaxes(List, String, BigDecimal)
	 *
	 * @see com.ode.cv.data.translator.GcvToStarProductTranslator#rollupMonthlyTaxes(List, String, BigDecimal)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testRollupMonthlyTaxes() throws Throwable {
		// Given
		List<String> monthlyIndicatorListValue = new ArrayList<String>(); // UTA: default value
		String item = ""; // UTA: default value
		monthlyIndicatorListValue.add(item);
		Field monthlyIndicatorListField = ReflectionUtils.findField(GcvToStarProductTranslator.class,
				"monthlyIndicatorList", null);
		ReflectionUtils.makeAccessible(monthlyIndicatorListField);
		ReflectionUtils.setField(monthlyIndicatorListField, underTest, monthlyIndicatorListValue);

		// When
		List<Product> productsBeforeRollup = new ArrayList<Product>(); // UTA: default value
		Product item2 = mock(Product.class);
		productsBeforeRollup.add(item2);
		String productType = ""; // UTA: default value
		BigDecimal term = BigDecimal.ZERO; // UTA: default value
		List<Product> result = underTest.rollupMonthlyTaxes(productsBeforeRollup, productType, term);

		// Then
		// assertNotNull(result);
		// assertEquals(0, result.size());
		// assertTrue(result.contains(null));
	}
}