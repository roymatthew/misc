/**
 * 
 */
package com.ode.cv.data.translator;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for Product
 *
 * @see com.ode.cv.data.translator.Product
 * @author rmathew
 */
public class ProductTest {
	
	private static String AMOUNT_1000 = "1000";
	Product underTest = null;	

	@Before
	public void setup() {
		underTest = new Product();
	}

	/**
	 * Parasoft Jtest UTA: Test for getAmount()
	 *
	 * @see com.ode.cv.data.translator.Product#getAmount()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetAmount() throws Throwable {
		
		// When
		underTest.setAmount(AMOUNT_1000);
		String result = underTest.getAmount();

		// Then
		assertEquals(AMOUNT_1000, result);
	}
}