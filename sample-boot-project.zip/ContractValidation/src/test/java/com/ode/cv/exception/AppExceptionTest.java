package com.ode.cv.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for AppException
 *
 * @see com.ode.cv.exception.AppException
 * @author rmathew
 */
public class AppExceptionTest {


	AppException underTest = null;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setup() {
		underTest = new AppException(new Exception("TestException"), "test", "test");
	}

	/**
	 * Parasoft Jtest UTA: Test for getCause()
	 *
	 * @see com.ode.cv.exception.AppException#getCause()
	 * @author rmathew
	 */
	@Test
	public void testGetCause() throws Throwable {
		// When
		Throwable result = underTest.getCause();
		// Then
		assertNotNull(result);
	}
}