/**
 * 
 */
package com.ode.cv.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for AppHttpException
 *
 * @see com.ode.cv.exception.AppHttpException
 * @author rmathew
 */
public class AppHttpExceptionTest {

	// Parasoft Jtest UTA: Object under test
	private AppHttpException underTest = null;

	@Before
	public void setup() {
		underTest = new AppHttpException("", new Exception("Test Exception"), "", "", "");
	}

	/**
	 * Parasoft Jtest UTA: Test for getCause()
	 *
	 * @see com.ode.cv.exception.AppException#getCause()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetCause() throws Throwable {
		// When
		Throwable result = underTest.getCause();

		// Then
		assertNotNull(result);
	}
}