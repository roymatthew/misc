package com.ode.cv.exception;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CVFromDocumentExceptionTest {
	
	CVFromDocumentException underTest = null;
	
	
	@Before
	public void setup()
	{
		underTest = new CVFromDocumentException("Sample exception!");
	}

	@Test
	public void testGetMessage() {
		
		String result = underTest.getMessage();
		assertNotNull(result);
	}

}
