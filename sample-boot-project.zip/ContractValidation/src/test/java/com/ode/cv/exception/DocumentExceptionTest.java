package com.ode.cv.exception;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DocumentExceptionTest {
	
	private DocumentException underTest = null;
	
	@Before
	public void setup()
	{
		underTest = new DocumentException(new Exception("Test Exception"));
	}

	@Test
	public void testGetCause() {
		Throwable result = underTest.getCause();
		assertNotNull(result);
	}

}
