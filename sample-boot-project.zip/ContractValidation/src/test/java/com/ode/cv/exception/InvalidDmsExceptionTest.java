package com.ode.cv.exception;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InvalidDmsExceptionTest {
	
	private InvalidDmsException underTest = null;
	
	@Before
	public void setup()
	{
		underTest = new InvalidDmsException("test", new Exception("Test Exception"));
	}

	@Test
	public void testGetCause() {
		Throwable result = underTest.getCause();
		assertNotNull(result);
	}

}
