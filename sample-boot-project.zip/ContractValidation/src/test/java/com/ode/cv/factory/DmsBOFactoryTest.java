package com.ode.cv.factory;

import com.ode.cv.bo.IDmsBO;
import com.ode.cv.exception.InvalidDmsException;
import com.ode.cv.util.Constants;
import com.ode.persistence.service.DeDmsRepoService;
import com.ode.persistence.vo.DeDmsVO;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * @author rmathew
 *
 */
public class DmsBOFactoryTest {
	
	private DmsBOFactory dmsBOFactory = new DmsBOFactory();

	@Test
	public void testCreateExistingDMS() throws Exception {
		DeDmsRepoService deDmsRepoService = mock(DeDmsRepoService.class);
		dmsBOFactory.deDmsRepoService = deDmsRepoService;
		DeDmsVO deDmsVO = new DeDmsVO();

		deDmsVO.setDmsId(Constants.CDK_DMS_ID);
		Mockito.doReturn(deDmsVO).when(deDmsRepoService).findById(Constants.CDK_DMS_ID);
		IDmsBO dmsBO1 = dmsBOFactory.createDMS(Constants.CDK_DMS_ID);
		assertNotNull(dmsBO1);
		assertEquals(dmsBO1.getDmsId(), Constants.CDK_DMS_ID);

		deDmsVO.setDmsId(Constants.REYNOLDS_DMS_ID);
		Mockito.doReturn(deDmsVO).when(deDmsRepoService).findById(Constants.REYNOLDS_DMS_ID);
		IDmsBO dmsBO2 = dmsBOFactory.createDMS(Constants.REYNOLDS_DMS_ID);
		assertNotNull(dmsBO2);
		assertEquals(dmsBO2.getDmsId(), Constants.REYNOLDS_DMS_ID);

		deDmsVO.setDmsId(Constants.ADVENT_DMS_ID);
		Mockito.doReturn(deDmsVO).when(deDmsRepoService).findById(Constants.ADVENT_DMS_ID);
		IDmsBO dmsBO3 = dmsBOFactory.createDMS(Constants.ADVENT_DMS_ID);
		assertNotNull(dmsBO2);
		assertEquals(dmsBO2.getDmsId(), Constants.ADVENT_DMS_ID);
	}
	
	@Test(expected = InvalidDmsException.class)
	public void testCreateDmsExpectInvalidDmsException() throws Exception
	{
		String nonExistingDmsId = "ABC";
		DeDmsRepoService deDmsRepoService = mock(DeDmsRepoService.class);
		dmsBOFactory.deDmsRepoService = deDmsRepoService;
		Mockito.doReturn(null).when(deDmsRepoService).findById(nonExistingDmsId);
		IDmsBO dmsBO = dmsBOFactory.createDMS(nonExistingDmsId);
	}

	@Test()
	public void testCreateNewDmsThatExistsInDB() throws Exception
	{
		String newDmsId = "NU";
		DeDmsVO deDmsVO = new DeDmsVO();
		deDmsVO.setDmsId(newDmsId);
		DeDmsRepoService deDmsRepoService = mock(DeDmsRepoService.class);
		dmsBOFactory.deDmsRepoService = deDmsRepoService;
		Mockito.doReturn(deDmsVO).when(deDmsRepoService).findById(newDmsId);
		IDmsBO dmsBO = dmsBOFactory.createDMS(newDmsId);
		assertNotNull(dmsBO);
		assertEquals(dmsBO.getDmsId(), newDmsId);
	}
}
