package com.ode.cv.factory;


import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ode.cv.ContractValidationApplication;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.persistence.vo.DeDealVO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class VOFactoryTest {
	
	@Test
	public void testCreateNewContractVal() {
		DeDealVO dealVO = getMockDeal();
		DeContractValidationBo deContractValidationBo = VOFactory.createNewContractVal(dealVO);
		Assert.assertNotNull(deContractValidationBo);
		Assert.assertEquals("CV02", deContractValidationBo.getSequenceId());
	}

	@Test
	public void testUpdateCVSequenceId() {
		DeDealVO dealVO = getMockDeal();
		DeContractValidationBo deContractValidationBo = VOFactory.createNewContractVal(dealVO);
		VOFactory.updateCVSequenceId(deContractValidationBo, dealVO);
		Assert.assertEquals("CV02", deContractValidationBo.getSequenceId());
	}
	
	private DeDealVO getMockDeal() {
		DeDealVO deDealVO = new DeDealVO();
		deDealVO.setDeDealId("TEST12345");
		deDealVO.setCvSequenceId("CV01");
		return deDealVO;
	}

}
