/**
 * 
 */
package com.ode.cv.messaging;

import com.ode.cv.service.ICreditContractService;
import com.ode.cv.vo.CreditContractVO;

import javax.jms.Message;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

/**
 * Parasoft Jtest UTA: Test class for CVMessageListener
 *
 * @see com.ode.cv.messaging.CVMessageListener
 * @author rmathew
 */
public class CVMessageListenerTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	CVMessageListener underTest;

	// Parasoft Jtest UTA: Dependency generated for field creditContractService in CVMessageListener
	@Mock
	ICreditContractService creditContractService;
	
	@Mock
	private Message mockMessage;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for onMessage(Message)
	 *
	 * @see com.ode.cv.messaging.CVMessageListener#onMessage(Message)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testOnMessage() throws Throwable {
		// Given
		Mockito.doAnswer(new Answer<Void>() {
			public Void answer(InvocationOnMock invocation) {
				CreditContractVO creditContractVO = (CreditContractVO) invocation.getArguments()[0];
				// UTA: Auto-generated answer method
				return null;
			}
		}).when(creditContractService).processCreditContract((CreditContractVO) Matchers.any(CreditContractVO.class));

		// When
		Message message = mockMessage();
		underTest.onMessage(message);

	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of Message
	 */
	private Message mockMessage() throws Throwable {
		Message message = mockMessage;
		return message;
	}
}