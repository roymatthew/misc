/**
 * 
 */
package com.ode.cv.normalizer.bo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for CCVConditionBO
 *
 * @see com.ode.cv.normalizer.bo.CCVConditionBO
 * @author rmathew
 */
public class CCVConditionBOTest {

	// Parasoft Jtest UTA: Object under test
	CCVConditionBO underTest = null;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
		underTest = new CCVConditionBO();
	}

	/**
	 * Parasoft Jtest UTA: Test for getConditionId()
	 *
	 * @see com.ode.cv.normalizer.bo.CCVConditionBO#getConditionId()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetConditionId() throws Throwable {
		// When
		underTest.setConditionId(1000);
		int result = underTest.getConditionId();

		// Then
		assertEquals(1000, result);
	}
}