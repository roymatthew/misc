/**
 * 
 */
package com.ode.cv.normalizer.bo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for CCVDataExceptionBO
 *
 * @see com.ode.cv.normalizer.bo.CCVDataExceptionBO
 * @author rmathew
 */
public class CCVDataExceptionBOTest {

	// Parasoft Jtest UTA: Object under test
	CCVDataExceptionBO underTest = null;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
		underTest = new CCVDataExceptionBO();
	}

	/**
	 * Parasoft Jtest UTA: Test for getChild()
	 *
	 * @see com.ode.cv.normalizer.bo.CCVDataExceptionBO#getChild()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetChild() throws Throwable {
		// When
		underTest.setChild("test");
		String result = underTest.getChild();

		// Then
		assertEquals("test", result);
	}
}