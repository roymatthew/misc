/**
 * 
 */
package com.ode.cv.normalizer.bo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for CCVDataTranslationBO
 *
 * @see com.ode.cv.normalizer.bo.CCVDataTranslationBO
 * @author rmathew
 */
public class CCVDataTranslationBOTest {

	// Parasoft Jtest UTA: Object under test
	CCVDataTranslationBO underTest = null;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		underTest = new CCVDataTranslationBO();
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for getConditionSet()
	 *
	 * @see com.ode.cv.normalizer.bo.CCVDataTranslationBO#getConditionSet()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetConditionSet() throws Throwable {
		// When
		underTest.setConditionSet(100);
		int result = underTest.getConditionSet();

		// Then
		assertEquals(100, result);
	}
}