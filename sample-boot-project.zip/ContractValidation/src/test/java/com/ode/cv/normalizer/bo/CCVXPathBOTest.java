/**
 * 
 */
package com.ode.cv.normalizer.bo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for CCVXPathBO
 *
 * @see com.ode.cv.normalizer.bo.CCVXPathBO
 * @author rmathew
 */
public class CCVXPathBOTest {

	// Parasoft Jtest UTA: Object under test
	CCVXPathBO underTest = null;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
		underTest = new CCVXPathBO();
	}

	/**
	 * Parasoft Jtest UTA: Test for getParentXpath()
	 *
	 * @see com.ode.cv.normalizer.bo.CCVXPathBO#getParentXpath()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetParentXpath() throws Throwable {
		// When
		underTest.setParentXpath("testpath");
		String result = underTest.getParentXpath();

		// Then
		assertEquals("testpath", result);
	}
}