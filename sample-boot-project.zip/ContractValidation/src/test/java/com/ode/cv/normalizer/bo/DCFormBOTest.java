/**
 * 
 */
package com.ode.cv.normalizer.bo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for DCFormBO
 *
 * @see com.ode.cv.normalizer.bo.DCFormBO
 * @author rmathew
 */
public class DCFormBOTest {

	// Parasoft Jtest UTA: Object under test
	DCFormBO underTest = null;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
		underTest = new DCFormBO();
	}

	/**
	 * Parasoft Jtest UTA: Test for getCreatedBy()
	 *
	 * @see com.ode.cv.normalizer.bo.DCFormBO#getCreatedBy()
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetCreatedBy() throws Throwable {
		// When
		underTest.setCreatedBy("testuser");
		String result = underTest.getCreatedBy();

		// Then
		assertEquals("testuser", result);
	}
}