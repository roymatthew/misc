/**
 * 
 */
package com.ode.cv.normalizer.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

import com.ode.cv.normalizer.bo.CCVDataExceptionBO;
import com.ode.cv.vo.CcvInputVO;
import com.ode.persistence.vo.CcvDataExceptionVO;
import com.ode.persistence.vo.CcvXpathVO;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for DataTranslationMapper
 *
 * @see com.ode.cv.normalizer.util.DataTranslationMapper
 * @author rmathew
 */
public class DataTranslationMapperTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	DataTranslationMapper underTest;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for mapDataExceptions(CcvInputVO)
	 *
	 * @see com.ode.cv.normalizer.util.DataTranslationMapper#mapDataExceptions(CcvInputVO)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testMapDataExceptions() throws Throwable {
		// When
		CcvInputVO ccvInputVO = mockCcvInputVO();
		List<CCVDataExceptionBO> result = DataTranslationMapper.mapDataExceptions(ccvInputVO);

		// Then
		assertNotNull(result);
		// assertEquals(0, result.size());
		// assertTrue(result.contains(null));
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of CcvInputVO
	 */
	private static CcvInputVO mockCcvInputVO() throws Throwable {
		CcvInputVO ccvInputVO = mock(CcvInputVO.class);
		List<CcvXpathVO> getListOfCcvXpathsResult = new ArrayList<CcvXpathVO>(); // UTA: default value
		CcvXpathVO item = mock(CcvXpathVO.class);
		getListOfCcvXpathsResult.add(item);
		doReturn(getListOfCcvXpathsResult).when(ccvInputVO).getListOfCcvXpaths();

		List<CcvDataExceptionVO> getListOfDataExceptionsResult = new ArrayList<CcvDataExceptionVO>(); // UTA: default value
		CcvDataExceptionVO item2 = mock(CcvDataExceptionVO.class);
		getListOfDataExceptionsResult.add(item2);
		doReturn(getListOfDataExceptionsResult).when(ccvInputVO).getListOfDataExceptions();
		return ccvInputVO;
	}
}