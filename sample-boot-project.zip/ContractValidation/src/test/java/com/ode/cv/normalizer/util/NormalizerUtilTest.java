/**
 * 
 */
package com.ode.cv.normalizer.util;

import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ode.cv.normalizer.bo.CCVConditionBO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for NormalizerUtil
 *
 * @see com.ode.cv.normalizer.util.NormalizerUtil
 * @author rmathew
 */
public class NormalizerUtilTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	NormalizerUtil underTest;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for evaluateCondition(CCVConditionBO, String)
	 *
	 * @see com.ode.cv.normalizer.util.NormalizerUtil#evaluateCondition(CCVConditionBO, String)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testEvaluateCondition() throws Throwable {
		// When
		CCVConditionBO condition = mockCCVConditionBO();
		String ecinValueIn = ""; // UTA: default value
		boolean result = NormalizerUtil.evaluateCondition(condition, ecinValueIn);

		// Then
		// assertFalse(result);
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of CCVConditionBO
	 */
	private static CCVConditionBO mockCCVConditionBO() throws Throwable {
		CCVConditionBO condition = mock(CCVConditionBO.class);
		int getConditionIdResult = 0; // UTA: default value
		when(condition.getConditionId()).thenReturn(getConditionIdResult);

		String getOperationResult = ""; // UTA: default value
		when(condition.getOperation()).thenReturn(getOperationResult);

		String getValueResult = ""; // UTA: default value
		when(condition.getValue()).thenReturn(getValueResult);
		return condition;
	}
}