/**
 * 
 */
package com.ode.cv.normalizer.util;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ode.cv.normalizer.bo.CCVXPathBO;
import com.ode.cv.vo.CcvInputVO;
import com.ode.persistence.vo.CcvConditionSetVO;
import com.ode.persistence.vo.CcvConditionVO;
import com.ode.persistence.vo.CcvDataExceptionVO;
import com.ode.persistence.vo.CcvDataTranslationVO;
import com.ode.persistence.vo.CcvXpathVO;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.util.ReflectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Parasoft Jtest UTA: Test class for XmlNormalizer
 *
 * @see com.ode.cv.normalizer.util.XmlNormalizer
 * @author rmathew
 */
public class XmlNormalizerTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	XmlNormalizer underTest;

	// Parasoft Jtest UTA: Dependency generated for field ecinDoc in XmlNormalizer
	@Mock
	Document ecinDoc;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for normalizeEcin(String, CcvInputVO)
	 *
	 * @see com.ode.cv.normalizer.util.XmlNormalizer#normalizeEcin(String, CcvInputVO)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testNormalizeEcin() throws Throwable {
		// Given
		HashMap<CCVXPathBO, String> nodeCacheValue = new HashMap<CCVXPathBO, String>(); // UTA: default value
		CCVXPathBO key = mock(CCVXPathBO.class);
		String value = ""; // UTA: default value
		nodeCacheValue.put(key, value);
		Field nodeCacheField = ReflectionUtils.findField(XmlNormalizer.class, "nodeCache", null);
		ReflectionUtils.makeAccessible(nodeCacheField);
		ReflectionUtils.setField(nodeCacheField, underTest, nodeCacheValue);
		HashMap<String, String> childLoggerValue = new HashMap<String, String>(); // UTA: default value
		String key2 = ""; // UTA: default value
		String value2 = ""; // UTA: default value
		childLoggerValue.put(key2, value2);
		Field childLoggerField = ReflectionUtils.findField(XmlNormalizer.class, "childLogger", null);
		ReflectionUtils.makeAccessible(childLoggerField);
		ReflectionUtils.setField(childLoggerField, underTest, childLoggerValue);
		NodeList getChildNodesResult = mockNodeList2();
		when(ecinDoc.getChildNodes()).thenReturn(getChildNodesResult);

		String getNodeNameResult2 = ""; // UTA: default value
		when(ecinDoc.getNodeName()).thenReturn(getNodeNameResult2);

		String getTextContentResult2 = ""; // UTA: default value
		when(ecinDoc.getTextContent()).thenReturn(getTextContentResult2);

		String getXmlEncodingResult = ""; // UTA: default value
		when(ecinDoc.getXmlEncoding()).thenReturn(getXmlEncodingResult);

		doAnswer(new Answer<Void>() {
			public Void answer(InvocationOnMock invocation) {
				String arg0 = (String) invocation.getArguments()[0];
				// UTA: Auto-generated answer method
				return null;
			}
		}).when(ecinDoc).setTextContent(nullable(String.class));

		String toStringResult4 = ""; // UTA: default value
		when(ecinDoc.toString()).thenReturn(toStringResult4);

		// When
		String ecinXML = ""; // UTA: default value
		CcvInputVO ccvInputVO = mockCcvInputVO();
		String result = underTest.normalizeEcin(ecinXML, ccvInputVO);

		// Then
		// assertEquals("", result);
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of NodeList
	 */
	private static NodeList mockNodeList() throws Throwable {
		NodeList getChildNodesResult2 = mock(NodeList.class);
		int getLengthResult2 = 0; // UTA: default value
		when(getChildNodesResult2.getLength()).thenReturn(getLengthResult2);

		Node itemResult2 = mock(Node.class);
		when(getChildNodesResult2.item(anyInt())).thenReturn(itemResult2);

		String toStringResult = ""; // UTA: default value
		when(getChildNodesResult2.toString()).thenReturn(toStringResult);
		return getChildNodesResult2;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of Node
	 */
	private static Node mockNode() throws Throwable {
		Node itemResult = mock(Node.class);
		NodeList getChildNodesResult2 = mockNodeList();
		when(itemResult.getChildNodes()).thenReturn(getChildNodesResult2);

		String getNodeNameResult = ""; // UTA: default value
		when(itemResult.getNodeName()).thenReturn(getNodeNameResult);

		String getTextContentResult = ""; // UTA: default value
		when(itemResult.getTextContent()).thenReturn(getTextContentResult);

		String toStringResult2 = ""; // UTA: default value
		when(itemResult.toString()).thenReturn(toStringResult2);
		return itemResult;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of NodeList
	 */
	private static NodeList mockNodeList2() throws Throwable {
		NodeList getChildNodesResult = mock(NodeList.class);
		int getLengthResult = 0; // UTA: default value
		when(getChildNodesResult.getLength()).thenReturn(getLengthResult);

		Node itemResult = mockNode();
		when(getChildNodesResult.item(anyInt())).thenReturn(itemResult);

		String toStringResult3 = ""; // UTA: default value
		when(getChildNodesResult.toString()).thenReturn(toStringResult3);
		return getChildNodesResult;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of CcvInputVO
	 */
	private static CcvInputVO mockCcvInputVO() throws Throwable {
		CcvInputVO ccvInputVO = mock(CcvInputVO.class);
		List<CcvConditionSetVO> getListOfCcvConditionSetsResult = new ArrayList<CcvConditionSetVO>(); // UTA: default value
		CcvConditionSetVO item = mock(CcvConditionSetVO.class);
		getListOfCcvConditionSetsResult.add(item);
		doReturn(getListOfCcvConditionSetsResult).when(ccvInputVO).getListOfCcvConditionSets();

		List<CcvConditionVO> getListOfCcvConditionsResult = new ArrayList<CcvConditionVO>(); // UTA: default value
		CcvConditionVO item2 = mock(CcvConditionVO.class);
		getListOfCcvConditionsResult.add(item2);
		doReturn(getListOfCcvConditionsResult).when(ccvInputVO).getListOfCcvConditions();

		List<CcvXpathVO> getListOfCcvXpathsResult = new ArrayList<CcvXpathVO>(); // UTA: default value
		CcvXpathVO item3 = mock(CcvXpathVO.class);
		getListOfCcvXpathsResult.add(item3);
		doReturn(getListOfCcvXpathsResult).when(ccvInputVO).getListOfCcvXpaths();

		List<CcvDataExceptionVO> getListOfDataExceptionsResult = new ArrayList<CcvDataExceptionVO>(); // UTA: default value
		CcvDataExceptionVO item4 = mock(CcvDataExceptionVO.class);
		getListOfDataExceptionsResult.add(item4);
		doReturn(getListOfDataExceptionsResult).when(ccvInputVO).getListOfDataExceptions();

		List<CcvDataTranslationVO> getListOfDataTranslationsResult = new ArrayList<CcvDataTranslationVO>(); // UTA: default value
		CcvDataTranslationVO item5 = mock(CcvDataTranslationVO.class);
		getListOfDataTranslationsResult.add(item5);
		doReturn(getListOfDataTranslationsResult).when(ccvInputVO).getListOfDataTranslations();

		String toStringResult5 = ""; // UTA: default value
		when(ccvInputVO.toString()).thenReturn(toStringResult5);
		return ccvInputVO;
	}
}