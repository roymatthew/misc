/**
 * 
 */
package com.ode.cv.persistence;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.doReturn;

import com.ode.cv.vo.LteResponseXmlVO;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

/**
 * Parasoft Jtest UTA: Test class for LteResponseXmlRepoServiceImpl
 *
 * @see com.ode.cv.persistence.LteResponseXmlRepoServiceImpl
 * @author rmathew
 */
public class LteResponseXmlRepoServiceImplTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	LteResponseXmlRepoServiceImpl underTest;

	// Parasoft Jtest UTA: Dependency generated for field modelMapper in LteResponseXmlRepoServiceImpl
	@Mock
	ModelMapper modelMapper;

	// Parasoft Jtest UTA: Dependency generated for field iLteResponseXmlRepo in LteResponseXmlRepoServiceImpl
	@Mock
	ILteResponseXmlRepo iLteResponseXmlRepo;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for getByXmlId(Integer)
	 *
	 * @see com.ode.cv.persistence.LteResponseXmlRepoServiceImpl#getByXmlId(Integer)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testGetByXmlId() throws Throwable {
		// Given
		
		LteResponseXml LteResponseXml = new LteResponseXml();
		LteResponseXml.setAccrXml("test ACCR");
		LteResponseXml.setLteOutputXml("test LTE out");
		Optional<LteResponseXml> findByIdResult = Optional.of(LteResponseXml); // UTA: default value
		doReturn(findByIdResult).when(iLteResponseXmlRepo).findById(nullable(Integer.class));
		LteResponseXml mapResult = new LteResponseXml(); // UTA: default value
		doReturn(mapResult).when(modelMapper).map(nullable(Object.class), (Class) any());

		// When
		Integer xmlId = 0; // UTA: default value
		//LteResponseXmlVO result = underTest.getByXmlId(xmlId);

		// Then
		// assertNotNull(result);
	}
}