/**
 * 
 */
package com.ode.cv.persistence;

import static org.junit.Assert.assertFalse;

import java.sql.Timestamp;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * Parasoft Jtest UTA: Test class for LteResponseXml
 *
 * @see com.ode.cv.persistence.LteResponseXml
 * @author rmathew
 */
public class LteResponseXmlTest {

	// Parasoft Jtest UTA: Object under test
	@InjectMocks
	LteResponseXml underTest;

	// Parasoft Jtest UTA: Dependency generated for field createdDate in LteResponseXml
	@Mock
	Timestamp createdDate;

	// Parasoft Jtest UTA: Initialize object under test with mocked dependencies
	@Before
	public void setupMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Parasoft Jtest UTA: Test for equals(Object)
	 *
	 * @see com.ode.cv.persistence.LteResponseXml#equals(Object)
	 * @author rmathew
	 */
	@Test(timeout = 1000)
	public void testEquals() throws Throwable {
		// When
		Object obj = new Object(); // UTA: default value
		boolean result = underTest.equals(obj);

		// Then
		assertFalse(result);
	}
}