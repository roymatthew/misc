/**
 * 
 */
package com.ode.cv.rest.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.ode.cv.service.IAccrService;
import com.ode.cv.vo.AccrVO;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.annotation.DirtiesContext;

/**
 * Parasoft Jtest UTA: Test class for ContractValidationResponseController
 *
 * @see com.ode.cv.rest.api.ContractValidationResponseController
 * @author aseetharaman
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext // Parasoft Jtest UTA: Reset context for each test run
public class ContractValidationResponseControllerSpringTest {

	// Parasoft Jtest UTA: Component under test
	@Autowired
	ContractValidationResponseController restcontroller;

	// Parasoft Jtest UTA: Spring MVC test support class
	@Autowired
	MockMvc mockMvc;

	// Parasoft Jtest UTA: Dependency generated for autowired field "accrVO" in ContractValidationResponseController
	@MockBean
	AccrVO accrVO;

	// Parasoft Jtest UTA: Dependency generated for autowired field "accrService" in ContractValidationResponseController
	@MockBean
	IAccrService accrService;

	/**
	 * Parasoft Jtest UTA: Test for processCVResponse(String)
	 *
	 * @see com.ode.cv.rest.api.ContractValidationResponseController#processCVResponse(String)
	 * @author aseetharaman
	 */
	@Test(timeout = 1000)
	public void testProcessCVResponse() throws Throwable {
		// When
		setupAccrVO();
		setupAccrService();
		String payload = ""; // UTA: default value
		ResultActions actions = mockMvc.perform(post("/processResponse").content(payload));

		// Then
		// actions.andExpect(status().isOk());
		// actions.andExpect(header().string("", ""));
		// String response = ""; // UTA: Configure the expected response value
		// actions.andExpect(content().string(response));
	}

	/**
	 * Parasoft Jtest UTA: Helper method to configure mock of AccrVO
	 */
	private void setupAccrVO() throws Throwable {
		String getResponseMessageResult = ""; // UTA: default value
		when(accrVO.getResponseMessage()).thenReturn(getResponseMessageResult);

		doAnswer(new Answer<Void>() {
			public Void answer(InvocationOnMock invocation) {
				String accrRequestXml = (String) invocation.getArguments()[0];
				// UTA: Auto-generated answer method
				return null;
			}
		}).when(accrVO).setAccrRequestXml(nullable(String.class));
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of AccrVO
	 */
	private static AccrVO mockAccrVO() throws Throwable {
		AccrVO processAccrFromRouteOneResult = mock(AccrVO.class);
		String getResponseMessageResult2 = ""; // UTA: default value
		when(processAccrFromRouteOneResult.getResponseMessage()).thenReturn(getResponseMessageResult2);
		return processAccrFromRouteOneResult;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to configure mock of IAccrService
	 */
	private void setupAccrService() throws Throwable {
		AccrVO processAccrFromRouteOneResult = mockAccrVO();
		when(accrService.processAccrFromRouteOne(nullable(AccrVO.class))).thenReturn(processAccrFromRouteOneResult);
	}
}