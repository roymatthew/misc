package com.ode.cv.service;

import com.ode.cv.util.RFLUtil;
import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.persistence.vo.DcFormVO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

public class AccrRequestTranslationServiceTest {
	
	private static final Logger logger = LogManager.getLogger(AccrRequestTranslationServiceTest.class);
	
	private final static String XML_START = "<data>";
	private final static String XML_END = "</data>";

	@Test
	public void testTranslationWithNoRFL() throws TransformerException, IOException {
		
		String rulesEngineAccrResponse = getXml();
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		cvTransmitVO.setAccrResponseXml(rulesEngineAccrResponse);
		String translatedXml = getXmlData(cvTransmitVO);
		logger.debug("Translated ACCR: {}", translatedXml);
	}
	
	@Test
	public void testTranslationWithRFL() throws TransformerException, IOException {
		
		String rulesEngineAccrResponse = getXml();
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		cvTransmitVO.setAccrResponseXml(rulesEngineAccrResponse);
		cvTransmitVO.setAccrContext(getAccrContextWithRFL());
		String translatedXml = getXmlData(cvTransmitVO);
		logger.debug("Translated ACCR: {}", translatedXml);
	}
	
	private AccrVO getAccrContextWithRFL()
	{
		RFLUtil rflUtil = new RFLUtil();
		CreditContractVO creditContractVO = new CreditContractVO();
		List<DcFormVO> formsList = rflUtil.getStaticRFLList(creditContractVO);
		AccrVO accrVO = new AccrVO();
		accrVO.setFormList(formsList);
		return accrVO;
		
	}
	
	public String getXml() throws TransformerException, IOException {
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/routeone_accr_no_line_breaks.xml");
		Source xmlSource = new StreamSource(resource.getInputStream());
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(xmlSource, result);
		return writer.toString();
	}

	/**
	 * @param cvTransmitVO
	 * @return
	 */
	private String getXmlData(final CVTransmitVO cvTransmitVO) {

		logger.debug("Entered getXmlData() method of AccrRequestTranslationServiceImpl class");
		String tempXmlData;

		String requestXml = cvTransmitVO.getAccrResponseXml().trim();
		requestXml = requestXml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
		tempXmlData = XML_START;


		// If request is not VOL, remove incoming RFL messages
		if (!requestXml.contains("<SenderNameCode>OD</SenderNameCode>")) {
			requestXml = requestXml.replaceAll("<ValidationMessage>((?!<ValidationMessage).)*<ReferenceName>RFL<\\/ReferenceName>((?!<ValidationMessage).)*<\\/ValidationMessage>", "");
		}


		if (requestXml != null) {
			int start = 0;
			int end = 0;

			// for rules engine response only
			if (requestXml.indexOf("<ns3:AcknowledgeCreditContractResponse") > 0) {
				requestXml = requestXml.replaceAll("<ns3:", "<");
				requestXml = requestXml.replaceAll("</ns3:", "</");
			}

			if (requestXml.indexOf("<AcknowledgeCreditContractResponse") >= 0) {
				start = requestXml.indexOf("<AcknowledgeCreditContractResponse");
				end = requestXml.indexOf("</AcknowledgeCreditContractResponse>") + 36;
			} else if (requestXml.indexOf("<CreditContractResponse") > 0) {
				start = requestXml.indexOf("<CreditContractResponse");
				end = requestXml.indexOf("</CreditContractResponse>") + 25;
			} else if (requestXml.indexOf("<ProcessBDKTransResponse") > 0) {
				start = requestXml.indexOf("<ProcessBDKTransResponse");
				end = requestXml.indexOf("</ProcessBDKTransResponse>") + 26;
			}

			if (start == end) {
				tempXmlData += requestXml;
			} else {
				tempXmlData += requestXml.substring(start, end);
			}

			if (null != cvTransmitVO.getAccrContext() && null != cvTransmitVO.getAccrContext().getFormList()
					&& cvTransmitVO.getAccrContext().getFormList().size() > 0) {
				String formListXml = createRFLXmlFromLenderFormsList(cvTransmitVO.getAccrContext().getFormList());
				tempXmlData += formListXml;


			}
		}

		tempXmlData += XML_END;
		tempXmlData = tempXmlData.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
		return tempXmlData;
	}
	
	/**
	 * @param formList
	 * @return
	 */
	private String createRFLXmlFromLenderFormsList(final List<DcFormVO> formList) {

		logger.debug("Entered createRFLXmlFromLenderFormsList() method of AccrRequestTranslationServiceImpl class");
		StringBuilder rflXml = new StringBuilder();
		rflXml.append("<RequiredFormList xmlns=\"http://www.opendealerexchange.org/RFL\">");
		for (DcFormVO dcFormBO : formList) {
			if (dcFormBO != null) {
				rflXml.append("<ValidationMessage><ReferenceName>");
				if (dcFormBO.getFormName() != null) {
					rflXml.append(dcFormBO.getFormName().trim());
				}
				rflXml.append("</ReferenceName>");
				rflXml.append("<Description>");
				if (dcFormBO.getFormComment() != null) {
					rflXml.append(dcFormBO.getFormComment().trim());
				}
				rflXml.append("</Description>");
				rflXml.append("<ReasonCode>");
				if (dcFormBO.getFormId() != null) {
					rflXml.append(dcFormBO.getFormId().trim());
				}
				rflXml.append("</ReasonCode></ValidationMessage>");
			}
		}
		rflXml.append("</RequiredFormList>");
		System.out.println(rflXml.toString());
		return rflXml.toString();
	}

}
