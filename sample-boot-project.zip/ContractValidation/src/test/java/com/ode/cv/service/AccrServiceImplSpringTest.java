/**
 * 
 */
package com.ode.cv.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ode.cv.persistence.ILteResponseXmlRepoService;
import com.ode.cv.util.AppHttpUtility;
import com.ode.cv.util.ApplpEventHandler;
import com.ode.cv.util.CVRequestXMLParser;
import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.AccrVO;
import com.ode.persistence.service.DeDealRepoService;

/**
 * Parasoft Jtest UTA: Test class for AccrServiceImpl
 *
 * @see com.ode.cv.service.AccrServiceImpl
 * @author aseetharaman
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@DirtiesContext // Parasoft Jtest UTA: Reset context for each test run
public class AccrServiceImplSpringTest {

	// Parasoft Jtest UTA: Component under test
	@Autowired
	AccrServiceImpl service;

	// Parasoft Jtest UTA: Dependency generated for autowired field "iAccrRequestTranslationService" in AccrServiceImpl
	@MockBean
	IAccrRequestTranslationService iAccrRequestTranslationService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "cvTransmitClient" in AccrServiceImpl
	@MockBean
	CVTransmitClient cVTransmitClient;

	// Parasoft Jtest UTA: Dependency generated for autowired field "httpUtil" in CVTransmitClient
	@MockBean
	AppHttpUtility appHttpUtility;

	// Parasoft Jtest UTA: Dependency generated for autowired field "deDealRepoService" in AppHttpUtility
	@MockBean
	DeDealRepoService deDealRepoService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "appeventHandler" in CVTransmitClient
	@MockBean
	ApplpEventHandler applpEventHandler;

	// Parasoft Jtest UTA: Dependency generated for autowired field "iProductConfigurationLookupService" in CVTransmitClient
	@MockBean
	IProductConfigurationLookupService iProductConfigurationLookupService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "cvJournalService" in CVTransmitClient
	@MockBean
	ICVJournalService iCVJournalService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "iRouteOneService" in AccrServiceImpl
	@MockBean
	IRouteOneService routeOneService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "iCvPersistenceService" in AccrServiceImpl
	@MockBean
	ICVPersistenceService cVPersistenceService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "cvRequestXmlParser" in AccrServiceImpl
	@MockBean
	CVRequestXMLParser cVRequestXMLParser;

	// Parasoft Jtest UTA: Dependency generated for autowired field "pccXmlParser" in AccrServiceImpl
	@MockBean
	PCCXmlParser pCCXmlParser;

	// Parasoft Jtest UTA: Dependency generated for autowired field "iLteResponseXmlRepoService" in AccrServiceImpl
	@MockBean
	ILteResponseXmlRepoService iLteResponseXmlRepoService;

	/**
	 * Parasoft Jtest UTA: Test for processAccrFromRouteOne(AccrVO)
	 *
	 * @see com.ode.cv.service.AccrServiceImpl#processAccrFromRouteOne(AccrVO)
	 * @author aseetharaman
	 */
	@Test(timeout = 1000)
	public void testProcessAccrFromRouteOne() throws Throwable {
		// When
		AccrVO accrVO = mockAccrVO();
		AccrVO result = service.processAccrFromRouteOne(accrVO);

		// Then
		 assertNotNull(result);
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of AccrVO
	 */
	private static AccrVO mockAccrVO() throws Throwable {
		AccrVO accrVO = mock(AccrVO.class);
		String getAccrRequestXmlResult = ""; // UTA: default value
		when(accrVO.getAccrRequestXml()).thenReturn(getAccrRequestXmlResult);

		String getAdpDealNoResult = ""; // UTA: default value
		when(accrVO.getAdpDealNo()).thenReturn(getAdpDealNoResult);

		String getDealerIdResult = ""; // UTA: default value
		when(accrVO.getDealerId()).thenReturn(getDealerIdResult);

		String getLenderIdResult = ""; // UTA: default value
		when(accrVO.getLenderId()).thenReturn(getLenderIdResult);
		return accrVO;
	}
}