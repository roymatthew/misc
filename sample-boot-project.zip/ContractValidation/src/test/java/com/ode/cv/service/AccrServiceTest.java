package com.ode.cv.service;

import com.ode.cv.util.PCCXmlParser;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.LteResponseXmlVO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class AccrServiceTest {

	@Mock
	PCCXmlParser pCCXmlParser;

	@Mock
	LteResponseXmlVO lteResponseXmlVO;

	@Mock
	CVTransmitVO cvTransmitVO;

	@Mock
	IRouteOneService routeOneService;

	@Mock
	ILenderService lenderService;

	@InjectMocks
	AccrServiceImpl service;

	@Before
	public void init() {
		initMocks(this);
	}

	@Test
	public void testDestinationRoutOne() throws Exception {
		CreditContractVO creditContractVO = new CreditContractVO();
		when(lteResponseXmlVO.getLteOutputXml()).thenReturn("");
		when(pCCXmlParser.getDestinationNameCode(anyString())).thenReturn("RO");
		when(routeOneService.prepareAndPostCVToRouteOne(any(CreditContractVO.class), anyString(), anyBoolean()))
				.thenReturn(new ECConfinVO());
		doNothing().when(cvTransmitVO).setEcConfinVO(any(ECConfinVO.class));
		service.routeCV(cvTransmitVO, creditContractVO, lteResponseXmlVO, true);
		
		verify(routeOneService, times(1)).prepareAndPostCVToRouteOne(any(CreditContractVO.class), anyString(), anyBoolean());
	}

	@Test
	public void testDestinationLenderSpecific() throws Exception {
		CreditContractVO creditContractVO = new CreditContractVO();
		creditContractVO.setLenderResponseXml("");
		when(lteResponseXmlVO.getLteOutputXml()).thenReturn("");
		when(pCCXmlParser.getDestinationNameCode(anyString())).thenReturn("AR");
		when(lenderService.prepareAndPostCVToLender(any(CVTransmitVO.class), any(CreditContractVO.class), anyString(), anyBoolean())).thenReturn(new ECConfinVO());
		service.routeCV(cvTransmitVO, creditContractVO, lteResponseXmlVO, true);
		
		verify(lenderService, times(1)).prepareAndPostCVToLender(any(CVTransmitVO.class), any(CreditContractVO.class), anyString(), anyBoolean());
	}

}
