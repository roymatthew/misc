package com.ode.cv.service;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ode.cv.ContractValidationApplication;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.persistence.vo.DeContractValidationVO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class ContractValidationServiceTest {

	@Autowired
	private ModelMapper modelMapper;

	@Test
	public void testContractValidationVO() {
		final DeContractValidationBo deContractValidationBo = getMockDeContractValidationBo();
		final DeContractValidationVO deCvVo = modelMapper.map(deContractValidationBo, DeContractValidationVO.class);
		assertEquals("1233445646dagfgvfdvb", deCvVo.getContractId());
	}

	private DeContractValidationBo getMockDeContractValidationBo() {
		final DeContractValidationBo deBo = new DeContractValidationBo();
		deBo.setContractId("1233445646dagfgvfdvb");
		return deBo;
	}

}
