package com.ode.cv.service;

import junit.framework.TestCase;
import org.junit.Test;

public class CreditContractServiceImplTest extends TestCase {
    @Test
    public void testAddLTEWrapper() throws Exception {
        CreditContractServiceImpl creditContractService = new CreditContractServiceImpl();
        String result = creditContractService.addLTEWrapper(test);
        assertTrue(
                result.contains("<ProcessCreditContract xmlns=\"http://www.starstandards.org/STAR\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\STAR\\Rev4.4.4\\BODs\\Standalone\\ProcessCreditContract.xsd\" release=\"8.1-Lite\" environment=\"Production\" revision=\"3.0.2\" lang=\"en-US\">")
        );
    }

    String test =
            "    <soap:Envelope xmlns=\"http://www.starstandards.org/STAR\" xmlns:p=\"http://CreditGateWay/Ecommerce/Services/CreditApps\" xmlns:proc=\"http://www.starstandards.org/STAR/processcreditcontract\" xmlns:s=\"http://www.starstandards.org/STAR\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:trans=\"http://www.starstandards.org/webservices/2005/10/transport\" xmlns:xalan=\"http://xml.apache.org/xslt\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
            "        <soap:Header>\n" +
            "            <payloadManifest xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\">\n" +
            "                <manifest contentID=\"Content0\" element=\"ProcessCreditContract\" namespaceURI=\"http://www.starstandards.org/STAR\" version=\"2.01\"></manifest>\n" +
            "            </payloadManifest>\n" +
            "        </soap:Header>\n" +
            "        <soap:Body>\n" +
            "            <ProcessMessage xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\">\n" +
            "                <payload>\n" +
            "                    <content id=\"Content0\">\n" +
            "                        <ProcessCreditContract xmlns=\"http://www.starstandards.org/STAR\" xsi:schemaLocation=\"http://www.starstandards.org/STAR \\Star\\Rev4.2.4\\BODs\\Standalone\\ProcessCreditContract.xsd\">\n" +
            "                            <ApplicationArea>\n" +
            "                                <Sender>\n" +
            "                                    <LogicalId>www.reyrey.com</LogicalId>\n" +
            "                                    <Component>Contract Validation</Component>\n" +
            "                                    <Task>CreditContract</Task>\n" +
            "                                    <ReferenceId>0625210832</ReferenceId>\n" +
            "                                    <AuthorizationId>60002</AuthorizationId>\n" +
            "                                    <CreatorNameCode>QA</CreatorNameCode>\n" +
            "                                    <SenderNameCode>QA</SenderNameCode>\n" +
            "                                    <DealerNumber>013130090961115</DealerNumber>\n" +
            "                                    <StoreNumber>013130090961115</StoreNumber>\n" +
            "                                    <AreaNumber>01</AreaNumber>\n" +
            "                                </Sender>\n" +
            "                                <CreationDateTime>2021-06-25T08:32:43</CreationDateTime>\n" +
            "                                <BODId>ALY2021-06-25T08:32:43</BODId>\n" +
            "                                <Destination>\n" +
            "                                    <DestinationNameCode>RO</DestinationNameCode>\n" +
            "                                </Destination>\n" +
            "                            </ApplicationArea>\n" +
            "                            <DataArea>\n" +
            "                                <Process></Process>\n" +
            "                                <CreditContract>\n" +
            "                                    <Header>\n" +
            "                                        <DocumentDateTime>2021-06-25T08:32:43</DocumentDateTime>\n" +
            "                                        <DocumentId>0625210832</DocumentId>\n" +
            "                                        <ContractFormNumber>ELEASESTD0913XX</ContractFormNumber>\n" +
            "                                        <FinanceType>L</FinanceType>\n" +
            "                                        <ApplicationType>IC</ApplicationType>\n" +
            "                                        <ApplicationNumber desc=\"Finance Source\">01-1-0625210832</ApplicationNumber>\n" +
            "                                        <ContractExecutionState>TX</ContractExecutionState>\n" +
            "                                        <ContractNegotiationLanguage>en-US</ContractNegotiationLanguage>\n" +
            "                                        <ProductType>S</ProductType>\n" +
            "                                        <ContractFormRevisionDate>2013-09-01</ContractFormRevisionDate>\n" +
            "                                        <DealId>0625210832</DealId>\n" +
            "                                    </Header>\n" +
            "                                    <FinanceCompany>\n" +
            "                                        <PartyId>ALY</PartyId>\n" +
            "                                        <AlternatePartyIds>\n" +
            "                                            <Id>SSM</Id>\n" +
            "                                            <AssigningPartyId>Other</AssigningPartyId>\n" +
            "                                        </AlternatePartyIds>\n" +
            "                                        <Name>ALLY FINANCE</Name>\n" +
            "                                        <Address>\n" +
            "                                            <AddressLine>PO BOX 91300</AddressLine>\n" +
            "                                            <City>MOBILE</City>\n" +
            "                                            <StateOrProvince>AL</StateOrProvince>\n" +
            "                                            <Country>US</Country>\n" +
            "                                            <PostalCode>36691-1300</PostalCode>\n" +
            "                                        </Address>\n" +
            "                                        <CompanyCode>30817</CompanyCode>\n" +
            "                                    </FinanceCompany>\n" +
            "                                    <Dealer>\n" +
            "                                        <PartyId>013130090961115</PartyId>\n" +
            "                                        <DealerName>QA R1 Test Dealer new DSP</DealerName>\n" +
            "                                        <Address>\n" +
            "                                            <AddressLine>1 REYNOLDS WAY</AddressLine>\n" +
            "                                            <City>BRONX</City>\n" +
            "                                            <County>BRONX</County>\n" +
            "                                            <StateOrProvince>KY</StateOrProvince>\n" +
            "                                            <Country>US</Country>\n" +
            "                                            <PostalCode>10472</PostalCode>\n" +
            "                                        </Address>\n" +
            "                                        <PreferredLanguage>en-US</PreferredLanguage>\n" +
            "                                    </Dealer>\n" +
            "                                    <IndividualApplicant>\n" +
            "                                        <AlternatePartyIds>\n" +
            "                                            <Id>XXXXXXXX</Id>\n" +
            "                                            <AssigningPartyId>NationalId</AssigningPartyId>\n" +
            "                                        </AlternatePartyIds>\n" +
            "                                        <AlternatePartyIds>\n" +
            "                                            <Id>XXXXXXXX</Id>\n" +
            "                                            <AssigningPartyId>DriversLicense</AssigningPartyId>\n" +
            "                                            <ExpirationDate>2016-01-01</ExpirationDate>\n" +
            "                                        </AlternatePartyIds>\n" +
            "                                        <PersonName>\n" +
            "                                            <GivenName>HARRIS</GivenName>\n" +
            "                                            <MiddleName>JAKE</MiddleName>\n" +
            "                                            <FamilyName>JENNI</FamilyName>\n" +
            "                                            <Suffix>SR</Suffix>\n" +
            "                                        </PersonName>\n" +
            "                                        <Address qualifier=\"HomeAddress\">\n" +
            "                                            <AddressLine>XXXXXXXX</AddressLine>\n" +
            "                                            <AddressLine>XXXXXXXX</AddressLine>\n" +
            "                                            <City>BUFFALO</City>\n" +
            "                                            <County>ERIE</County>\n" +
            "                                            <StateOrProvince>NY</StateOrProvince>\n" +
            "                                            <Country>US</Country>\n" +
            "                                            <PostalCode>14223</PostalCode>\n" +
            "                                        </Address>\n" +
            "                                        <Address qualifier=\"Garage\">\n" +
            "                                            <AddressLine>XXXXXXXX</AddressLine>\n" +
            "                                            <City>HONOLULU</City>\n" +
            "                                            <County>Trempealeau</County>\n" +
            "                                            <StateOrProvince>KY</StateOrProvince>\n" +
            "                                            <Country>US</Country>\n" +
            "                                            <PostalCode>48034</PostalCode>\n" +
            "                                        </Address>\n" +
            "                                        <Contact>\n" +
            "                                            <Telephone desc=\"Evening Phone\">XXXXXXXX</Telephone>\n" +
            "                                            <Telephone desc=\"Day Phone\" exten=\"\">XXXXXXXX</Telephone>\n" +
            "                                            <Telephone desc=\"Cell Phone\">XXXXXXXX</Telephone>\n" +
            "                                            <EMailAddress desc=\"Home\">XXXXXXXX</EMailAddress>\n" +
            "                                        </Contact>\n" +
            "                                        <Demographics>\n" +
            "                                            <BirthDate>XXXXXXXX</BirthDate>\n" +
            "                                            <Age>34</Age>\n" +
            "                                        </Demographics>\n" +
            "                                    </IndividualApplicant>\n" +
            "                                    <Co-Applicant>\n" +
            "                                        <AlternatePartyIds>\n" +
            "                                            <Id>XXXXXXXX</Id>\n" +
            "                                            <AssigningPartyId>NationalId</AssigningPartyId>\n" +
            "                                        </AlternatePartyIds>\n" +
            "                                        <AlternatePartyIds>\n" +
            "                                            <Id>XXXXXXXX</Id>\n" +
            "                                            <AssigningPartyId>DriversLicense</AssigningPartyId>\n" +
            "                                            <ExpirationDate>2018-02-02</ExpirationDate>\n" +
            "                                        </AlternatePartyIds>\n" +
            "                                        <PersonName>\n" +
            "                                            <GivenName>JOHN</GivenName>\n" +
            "                                            <MiddleName>ELROY</MiddleName>\n" +
            "                                            <FamilyName>HARRIS</FamilyName>\n" +
            "                                            <Suffix>III</Suffix>\n" +
            "                                        </PersonName>\n" +
            "                                        <Address qualifier=\"HomeAddress\">\n" +
            "                                            <AddressLine>XXXXXXXX</AddressLine>\n" +
            "                                            <AddressLine>XXXXXXXX</AddressLine>\n" +
            "                                            <City>AMHERST</City>\n" +
            "                                            <County>ERIE</County>\n" +
            "                                            <StateOrProvince>NY</StateOrProvince>\n" +
            "                                            <Country>US</Country>\n" +
            "                                            <PostalCode>14226</PostalCode>\n" +
            "                                        </Address>\n" +
            "                                        <Contact>\n" +
            "                                            <Telephone desc=\"Evening Phone\">XXXXXXXX</Telephone>\n" +
            "                                            <Telephone desc=\"Day Phone\" exten=\"\">XXXXXXXX</Telephone>\n" +
            "                                            <EMailAddress desc=\"Home\">XXXXXXXX</EMailAddress>\n" +
            "                                        </Contact>\n" +
            "                                        <Demographics>\n" +
            "                                            <BirthDate>XXXXXXXX</BirthDate>\n" +
            "                                            <Age>33</Age>\n" +
            "                                        </Demographics>\n" +
            "                                    </Co-Applicant>\n" +
            "                                    <CreditVehicle>\n" +
            "                                        <Model>XC60T6</Model>\n" +
            "                                        <ModelYear>2015</ModelYear>\n" +
            "                                        <ModelDescription>XC60 T6 FWD DRIVE-E</ModelDescription>\n" +
            "                                        <Make>VOLVO</Make>\n" +
            "                                        <SaleClass>New</SaleClass>\n" +
            "                                        <VIN>5TESN92N74Z405804</VIN>\n" +
            "                                        <DeliveryMileage uom=\"M\">1501</DeliveryMileage>\n" +
            "                                        <VehicleStock>VOLVO1</VehicleStock>\n" +
            "                                        <BodyStyle>4 DR WAGON</BodyStyle>\n" +
            "                                        <ExteriorColor>ICE WHITE</ExteriorColor>\n" +
            "                                        <TransmissionType>A</TransmissionType>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">54534.22</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Net Cap Cost</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">60541.56</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Gross Cap Cost</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">144570.00</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Selling Price</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">43075.00</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Invoice</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">45375.00</VehiclePrice>\n" +
            "                                            <VehiclePricingType>MSRP</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">45375.00</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Base MSRP</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">45375.00</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Final MSRP</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">57993.50</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Adjusted Gross Cap Cost</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <Pricing>\n" +
            "                                            <VehiclePrice currency=\"USD\">51986.16</VehiclePrice>\n" +
            "                                            <VehiclePricingType>Adjusted Net Cap Cost</VehiclePricingType>\n" +
            "                                        </Pricing>\n" +
            "                                        <NumberOfEngineCylinders>4</NumberOfEngineCylinders>\n" +
            "                                        <VanConversionCost currency=\"USD\">0.00</VanConversionCost>\n" +
            "                                        <VehicleWeight>4251</VehicleWeight>\n" +
            "                                        <VehicleUse>Personal</VehicleUse>\n" +
            "                                        <EngineType>GAS</EngineType>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">99.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>ETCH</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">199.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>SCOTCHGUARD ETCH</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">299.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>SCOTCHGUARD PAINT PRO</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">399.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>COBRA ALARMS</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">499.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>LOJACK</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">85.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>LK IPOD INSTALL</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                        <DealerProducts>\n" +
            "                                            <DealerProductsType>Other</DealerProductsType>\n" +
            "                                            <DealerProductsAmount currency=\"USD\">22.00</DealerProductsAmount>\n" +
            "                                            <DealerProductsPaidFor>LK DVD PLAYER</DealerProductsPaidFor>\n" +
            "                                            <DealerProductsPaidTo>Dealer</DealerProductsPaidTo>\n" +
            "                                            <DealerProductsCapitalizedInd>1</DealerProductsCapitalizedInd>\n" +
            "                                        </DealerProducts>\n" +
            "                                    </CreditVehicle>\n" +
            "                                    <Financing>\n" +
            "                                        <ContractDate>2015-07-05</ContractDate>\n" +
            "                                        <ContractTerm length=\"Months\">36</ContractTerm>\n" +
            "                                        <BaseVehicleCashPrice currency=\"USD\">143075.00</BaseVehicleCashPrice>\n" +
            "                                        <TotalDownPaymentAmount currency=\"USD\">6007.34</TotalDownPaymentAmount>\n" +
            "                                        <CashDownPayment currency=\"USD\">7281.94</CashDownPayment>\n" +
            "                                        <ManufacturerRebateAmount currency=\"USD\">500.00</ManufacturerRebateAmount>\n" +
            "                                        <AnnualMilesAllowed uom=\"M\">18000</AnnualMilesAllowed>\n" +
            "                                        <ExcessMileageRate currency=\"USD\">0.25</ExcessMileageRate>\n" +
            "                                        <FederalTILDisclosures>\n" +
            "                                            <FinanceCharge currency=\"USD\">2974.68</FinanceCharge>\n" +
            "                                            <TotalOfPayments currency=\"USD\">43278.94</TotalOfPayments>\n" +
            "                                            <FirstPaymentDate>2015-06-05</FirstPaymentDate>\n" +
            "                                            <PaymentSchedule>\n" +
            "                                                <NumberOfPayments>1</NumberOfPayments>\n" +
            "                                                <PaymentAmount currency=\"USD\">1000</PaymentAmount>\n" +
            "                                                <PayTerms>15</PayTerms>\n" +
            "                                                <TimeBetweenPayments period=\"MO\">1</TimeBetweenPayments>\n" +
            "                                                <ScheduleStartDate>2015-06-05</ScheduleStartDate>\n" +
            "                                                <BasePaymentAmount currency=\"USD\">1000</BasePaymentAmount>\n" +
            "                                            </PaymentSchedule>\n" +
            "                                            <PaymentSchedule>\n" +
            "                                                <NumberOfPayments>35</NumberOfPayments>\n" +
            "                                                <PaymentAmount currency=\"USD\">1000</PaymentAmount>\n" +
            "                                                <PayTerms>15</PayTerms>\n" +
            "                                                <TimeBetweenPayments period=\"MO\">1</TimeBetweenPayments>\n" +
            "                                                <ScheduleStartDate>2015-07-05</ScheduleStartDate>\n" +
            "                                            </PaymentSchedule>\n" +
            "                                            <LeaseRateMoneyFactor>0.00110</LeaseRateMoneyFactor>\n" +
            "                                        </FederalTILDisclosures>\n" +
            "                                        <ProgramsAndRates>\n" +
            "                                            <NetAnnualPercentageRate>.00034</NetAnnualPercentageRate>\n" +
            "                                            <BalloonResidualPercentage>50.00</BalloonResidualPercentage>\n" +
            "                                            <UpfrontMiles uom=\"M\">9000</UpfrontMiles>\n" +
            "                                            <UpfrontMileageRate currency=\"USD\">0.20</UpfrontMileageRate>\n" +
            "                                            <UpfrontMilesAmount currency=\"USD\">1800.00</UpfrontMilesAmount>\n" +
            "                                            <ContractTermMileage uom=\"M\">54000</ContractTermMileage>\n" +
            "                                            <SpecialProgramDetail>\n" +
            "                                                <SpecialProgramDescription>Spot Program</SpecialProgramDescription>\n" +
            "                                                <SpecialPrograms>XX01</SpecialPrograms>\n" +
            "                                            </SpecialProgramDetail>\n" +
            "                                            <SpecialProgramDetail>\n" +
            "                                                <SpecialProgramDescription>Additional Security Deposits</SpecialProgramDescription>\n" +
            "                                                <SpecialPrograms>0</SpecialPrograms>\n" +
            "                                            </SpecialProgramDetail>\n" +
            "                                            <SpecialProgramDetail>\n" +
            "                                                <SpecialProgramDescription>Security Deposit Waiver</SpecialProgramDescription>\n" +
            "                                                <SpecialPrograms>SP</SpecialPrograms>\n" +
            "                                            </SpecialProgramDetail>\n" +
            "                                            <SpecialProgramDetail>\n" +
            "                                                <SpecialProgramDescription>Marketing Plan</SpecialProgramDescription>\n" +
            "                                                <SpecialPrograms>CG</SpecialPrograms>\n" +
            "                                            </SpecialProgramDetail>\n" +
            "                                            <LeaseBuyMoneyFactor>.00030</LeaseBuyMoneyFactor>\n" +
            "                                        </ProgramsAndRates>\n" +
            "                                        <Tax>\n" +
            "                                            <TaxType>Sales</TaxType>\n" +
            "                                            <TaxAmount currency=\"USD\">2187.62</TaxAmount>\n" +
            "                                            <TaxRate>6.00000</TaxRate>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                            <CapitalizedTaxInd>1</CapitalizedTaxInd>\n" +
            "                                        </Tax>\n" +
            "                                        <Tax>\n" +
            "                                            <TaxType>CapCostReduction</TaxType>\n" +
            "                                            <TaxDescription>CapCostReduction</TaxDescription>\n" +
            "                                            <TaxAmount currency=\"USD\">360.44</TaxAmount>\n" +
            "                                            <TaxRate>6.00000</TaxRate>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                            <CapitalizedTaxInd>1</CapitalizedTaxInd>\n" +
            "                                        </Tax>\n" +
            "                                        <Tax>\n" +
            "                                            <TaxType>Monthly/Use</TaxType>\n" +
            "                                            <TaxAmount currency=\"USD\">0</TaxAmount>\n" +
            "                                            <TaxRate>6.00000</TaxRate>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                            <CapitalizedTaxInd>1</CapitalizedTaxInd>\n" +
            "                                        </Tax>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>PurchaseOptionFee</FeeType>\n" +
            "                                            <FeeDescription>PurchaseOptionFee</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">350.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>0</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>DispositionFee</FeeType>\n" +
            "                                            <FeeDescription>DispositionFee</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">350.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>0</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>DocumentationFee</FeeType>\n" +
            "                                            <FeeDescription>DocumentationFee</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">39.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>AcquisitionFee</FeeType>\n" +
            "                                            <FeeDescription>AcquisitionFee</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">995.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>Other</FeeType>\n" +
            "                                            <FeeDescription>Title</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">68.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>Other</FeeType>\n" +
            "                                            <FeeDescription>Reg</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">69.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>Other</FeeType>\n" +
            "                                            <FeeDescription>Inspection</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">41.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>Other</FeeType>\n" +
            "                                            <FeeDescription>Elec Filing</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">43.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>RoadandBridgeFee</FeeType>\n" +
            "                                            <FeeDescription>ROAD & BRIDGE FEE</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">5.00</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>MobilityFee</FeeType>\n" +
            "                                            <FeeDescription>MOBILITY Fee</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">12.50</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Fee>\n" +
            "                                            <FeeType>Other</FeeType>\n" +
            "                                            <FeeDescription>Tire Fee</FeeDescription>\n" +
            "                                            <FeeAmount currency=\"USD\">12.50</FeeAmount>\n" +
            "                                            <CapitalizedFeeInd>1</CapitalizedFeeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Fee>\n" +
            "                                        <Insurance>\n" +
            "                                            <InsuranceType>Vehicle</InsuranceType>\n" +
            "                                            <InsuranceCompanyName>ACME INSURANCE COMPANY</InsuranceCompanyName>\n" +
            "                                            <InsuranceAgentName>WYLIE COYOTE</InsuranceAgentName>\n" +
            "                                            <Address>\n" +
            "                                                <AddressLine>XXXXXXXX</AddressLine>\n" +
            "                                                <City>SOUTHFIELD</City>\n" +
            "                                                <StateOrProvince>MI</StateOrProvince>\n" +
            "                                                <Country>US</Country>\n" +
            "                                                <PostalCode>48034</PostalCode>\n" +
            "                                            </Address>\n" +
            "                                            <Telephone desc=\"Day Phone\">5554443333</Telephone>\n" +
            "                                            <PolicyNumber>XXXXXXXX</PolicyNumber>\n" +
            "                                            <CoverageExpirationDate>2015-12-19</CoverageExpirationDate>\n" +
            "                                            <Term length=\"Months\">12</Term>\n" +
            "                                            <Premium currency=\"USD\">0.00</Premium>\n" +
            "                                            <FinancedInd>1</FinancedInd>\n" +
            "                                            <InsuranceEffectiveDate>2014-12-19</InsuranceEffectiveDate>\n" +
            "                                            <InsideCarrierTypeInd>0</InsideCarrierTypeInd>\n" +
            "                                            <TaxabilityInd>0</TaxabilityInd>\n" +
            "                                        </Insurance>\n" +
            "                                        <ServiceContract>\n" +
            "                                            <ContractCompanyName>SERVICE CONTRACT</ContractCompanyName>\n" +
            "                                            <ContractType>Warranty</ContractType>\n" +
            "                                            <ContractTermMileage uom=\"M\">24000</ContractTermMileage>\n" +
            "                                            <Term length=\"Months\">24</Term>\n" +
            "                                            <CustomerSalePrice currency=\"USD\">500.00</CustomerSalePrice>\n" +
            "                                            <FinancedInd>1</FinancedInd>\n" +
            "                                            <InsideCarrierTypeInd>0</InsideCarrierTypeInd>\n" +
            "                                            <TaxabilityInd>1</TaxabilityInd>\n" +
            "                                            <ServiceContractDescription>MBI</ServiceContractDescription>\n" +
            "                                        </ServiceContract>\n" +
            "                                        <ServiceContract>\n" +
            "                                            <ContractCompanyName>WARRANTY</ContractCompanyName>\n" +
            "                                            <ContractType>Dealer Warranty</ContractType>\n" +
            "                                            <ContractTermMileage uom=\"M\">36000</ContractTermMileage>\n" +
            "                                            <Term length=\"Months\">36</Term>\n" +
            "                                            <CustomerSalePrice currency=\"USD\">1600.00</CustomerSalePrice>\n" +
            "                                            <FinancedInd>1</FinancedInd>\n" +
            "                                            <InsideCarrierTypeInd>0</InsideCarrierTypeInd>\n" +
            "                                            <TaxabilityInd>1</TaxabilityInd>\n" +
            "                                            <ServiceContractDescription>VCFS EWU</ServiceContractDescription>\n" +
            "                                        </ServiceContract>\n" +
            "                                        <ServiceContract>\n" +
            "                                            <ContractCompanyName>WHEEL AND TIRE</ContractCompanyName>\n" +
            "                                            <ContractType>Maintenance</ContractType>\n" +
            "                                            <ContractTermMileage uom=\"M\">12000</ContractTermMileage>\n" +
            "                                            <Term length=\"Months\">12</Term>\n" +
            "                                            <CustomerSalePrice currency=\"USD\">249.00</CustomerSalePrice>\n" +
            "                                            <FinancedInd>1</FinancedInd>\n" +
            "                                            <InsideCarrierTypeInd>0</InsideCarrierTypeInd>\n" +
            "                                            <TaxabilityInd>1</TaxabilityInd>\n" +
            "                                            <ServiceContractDescription>Maintenance</ServiceContractDescription>\n" +
            "                                        </ServiceContract>\n" +
            "                                        <ServiceContract>\n" +
            "                                            <ContractCompanyName>MAINTENANCE</ContractCompanyName>\n" +
            "                                            <ContractType>Maintenance</ContractType>\n" +
            "                                            <ContractTermMileage uom=\"M\">30000</ContractTermMileage>\n" +
            "                                            <Term length=\"Months\">30</Term>\n" +
            "                                            <CustomerSalePrice currency=\"USD\">600.00</CustomerSalePrice>\n" +
            "                                            <FinancedInd>1</FinancedInd>\n" +
            "                                            <InsideCarrierTypeInd>0</InsideCarrierTypeInd>\n" +
            "                                            <TaxabilityInd>1</TaxabilityInd>\n" +
            "                                            <ServiceContractDescription>Maintenance</ServiceContractDescription>\n" +
            "                                        </ServiceContract>\n" +
            "                                        <MaturityDate>2018-06</MaturityDate>\n" +
            "                                        <SecurityDepositAmount currency=\"USD\">749.00</SecurityDepositAmount>\n" +
            "                                        <DepreciationAndAmortizedAmts currency=\"USD\">33946.92</DepreciationAndAmortizedAmts>\n" +
            "                                        <TotalAmtOfBaseMonthlyPayments currency=\"USD\">36921.60</TotalAmtOfBaseMonthlyPayments>\n" +
            "                                        <TotalEstimatedFeesAndTaxesAmt currency=\"USD\">2850.56</TotalEstimatedFeesAndTaxesAmt>\n" +
            "                                        <ResidualAmount currency=\"USD\">20587.30</ResidualAmount>\n" +
            "                                        <BaseResidualAmount currency=\"USD\">22687.50</BaseResidualAmount>\n" +
            "                                        <FinalPaymentDate>2018-05-05</FinalPaymentDate>\n" +
            "                                        <TaxExempt>0</TaxExempt>\n" +
            "                                        <TotalOfMonthlyPaymentsAmount currency=\"USD\">36921.60</TotalOfMonthlyPaymentsAmount>\n" +
            "                                        <TotalDueAtSigningAmount currency=\"USD\">7781.94</TotalDueAtSigningAmount>\n" +
            "                                        <MonthlyDepreciationAmount currency=\"USD\">942.97</MonthlyDepreciationAmount>\n" +
            "                                        <NetCapCostPlusResidualAmount currency=\"USD\">75121.52</NetCapCostPlusResidualAmount>\n" +
            "                                        <PurchaseOptionPrice currency=\"USD\">20587.30</PurchaseOptionPrice>\n" +
            "                                        <MinUnusedPurchaseDistance uom=\"M\">45000</MinUnusedPurchaseDistance>\n" +
            "                                        <MaxUnusedPurchaseDistance uom=\"M\">54000</MaxUnusedPurchaseDistance>\n" +
            "                                        <ServiceChargeAmount currency=\"USD\">2974.68</ServiceChargeAmount>\n" +
            "                                        <GrossProceedsAmount currency=\"USD\">52064.62</GrossProceedsAmount>\n" +
            "                                        <LeaseMaturityDate>2018-06-04</LeaseMaturityDate>\n" +
            "                                        <CapReductionCashDownpaymentAmt currency=\"USD\">6007.34</CapReductionCashDownpaymentAmt>\n" +
            "                                        <CapReductionMfgRebateAmt currency=\"USD\">0.00</CapReductionMfgRebateAmt>\n" +
            "                                        <CapReductNetTradeDownpymtAmt currency=\"USD\">0.00</CapReductNetTradeDownpymtAmt>\n" +
            "                                        <AdjDepreciationAndAmortizedAmt currency=\"USD\">31398.86</AdjDepreciationAndAmortizedAmt>\n" +
            "                                        <AdjMonthlyDepreciationAmt currency=\"USD\">872.19</AdjMonthlyDepreciationAmt>\n" +
            "                                        <AdjNetCapCostsPlusResidualAmt currency=\"USD\">72573.46</AdjNetCapCostsPlusResidualAmt>\n" +
            "                                        <DemoResidualAdjustmentRate>0.20</DemoResidualAdjustmentRate>\n" +
            "                                        <DemoResidualAdjustmentAmount currency=\"USD\">300.20</DemoResidualAdjustmentAmount>\n" +
            "                                        <DemoMileage uom=\"M\">1501</DemoMileage>\n" +
            "                                    </Financing>\n" +
            "                                </CreditContract>\n" +
            "                            </DataArea>\n" +
            "                        </ProcessCreditContract>\n" +
            "                    </content>\n" +
            "                </payload>\n" +
            "            </ProcessMessage>\n" +
            "        </soap:Body>\n" +
            "    </soap:Envelope>";
}