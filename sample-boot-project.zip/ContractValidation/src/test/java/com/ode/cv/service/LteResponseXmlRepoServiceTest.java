package com.ode.cv.service;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ode.cv.ContractValidationApplication;
import com.ode.cv.persistence.ILteResponseXmlRepo;
import com.ode.cv.persistence.ILteResponseXmlRepoService;
import com.ode.cv.persistence.LteResponseXml;
import com.ode.cv.vo.LteResponseXmlVO;

/*import io.hypersistence.optimizer.HypersistenceOptimizer;
import io.hypersistence.optimizer.core.config.JpaConfig;*/

/**
 * @author rmathew
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class LteResponseXmlRepoServiceTest {

	@Autowired
	private ILteResponseXmlRepoService iLteResponseXmlRepoService;
	
	@Autowired
	private ILteResponseXmlRepo iLteResponseXmlRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	
/*	@Before
	public void init() {
	    new HypersistenceOptimizer(
	        new JpaConfig(entityManagerFactory)
	    ).init();
	}*/

	@Test
	public void testInsertLteResponseXMLRecord() throws UnsupportedEncodingException, IOException {
		

		Resource resource = new FileSystemResource("/data/ode/cv/test/data/lteconfirmbod.xml");
		LteResponseXmlVO lteResponseXmlVO = new LteResponseXmlVO();
		lteResponseXmlVO.setXmlId(3);
		lteResponseXmlVO.setLteOutputXml(convertToString(resource.getInputStream()));
		lteResponseXmlVO.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		
		//LteResponseXmlVO savedVO = iLteResponseXmlRepoService.saveLteResponseXml(lteResponseXmlVO);
		LteResponseXml lteResponseXml = iLteResponseXmlRepo.save(modelMapper.map(lteResponseXmlVO, LteResponseXml.class));
		Assert.assertNotNull(lteResponseXml);
	}
	
	@Test
	public void testFetchLteResponseXMLRecord()
	{

		LteResponseXmlVO savedVO = iLteResponseXmlRepoService.getByXmlId(2);
		Assert.assertNotNull(savedVO);
		Assert.assertNotNull(savedVO.getLteOutputXml());
		Assert.assertTrue(savedVO.getXmlId().intValue() == 2);
	}

	private String convertToString(InputStream is) throws UnsupportedEncodingException, IOException {
		StringBuilder stringBuilder = new StringBuilder();
		String line = null;

		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
			}
		}

		return stringBuilder.toString();
	}

}
