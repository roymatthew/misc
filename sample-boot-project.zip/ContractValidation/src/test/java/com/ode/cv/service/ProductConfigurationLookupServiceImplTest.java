package com.ode.cv.service;

import com.ode.persistence.vo.DeLenderDestinationVO;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = ContractValidationApplication.class)
public class ProductConfigurationLookupServiceImplTest {
	
	private static final String CV_DESTINATION_SAF_RULES = "http://localhost:8080/DERulesEngine/process-cv";
	
	@Autowired
	private IProductConfigurationLookupService service;
	
	@Test
	public void testLoadCVDestinationsForLender() {
		service.loadLenderDestinations("SAF");
		DeLenderDestinationVO cvDestination = service.getCVDestination("RULES", "SAF");
		Assert.assertNotNull(cvDestination);
		Assert.assertEquals(CV_DESTINATION_SAF_RULES, cvDestination);
	}
	
	@Test
	public void testMessageProcessingValueForLender() {
		service.loadFeatureConfigurationsForLender("SAF");
		boolean formFlag = service.cvMessageProcessingContainsValue("formTranslation");
		Assert.assertFalse(formFlag);
	}

}
