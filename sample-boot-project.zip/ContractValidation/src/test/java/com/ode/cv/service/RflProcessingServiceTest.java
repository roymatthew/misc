package com.ode.cv.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.ode.cv.vo.AccrVO;
import com.ode.cv.vo.CVTransmitVO;

/**
 * @author rmathew
 *
 */
public class RflProcessingServiceTest {
	
	@InjectMocks
	private IRflProcessingService rflProcessingService = new RflProcessingServiceImpl();

	@Test
	public void testProcessingRfl() {
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		AccrVO accrVO = new AccrVO();
		rflProcessingService.processRfl(cvTransmitVO, accrVO);
		assertNotNull(cvTransmitVO.getAccrContext().getFormList());
	}

}
