/**
 * 
 */
package com.ode.cv.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ode.cv.vo.ECConfinVO;
import com.ode.dlr.util.AppMessage;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Parasoft Jtest UTA: Test class for ApplpEventHandler
 *
 * @see com.ode.cv.util.ApplpEventHandler
 * @author djenkins
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ApplpEventHandlerTest {

	// Parasoft Jtest UTA: Component under test
	ApplpEventHandler component = new ApplpEventHandler();

	/**
	 * Parasoft Jtest UTA: Test for handleR1NegConfBod(ECConfinVO)
	 *
	 * @see com.ode.cv.util.ApplpEventHandler#handleR1NegConfBod(ECConfinVO)
	 * @author djenkins
	 */
	@Test
	public void testHandleR1NegConfBod() throws Throwable {
		// When
		ECConfinVO ecConfinVO = new ECConfinVO();
		ecConfinVO.setEcConfinMessage("<RESTError><status>422</status><routeOneErrorCode>100101</routeOneErrorCode><errorMessage>The request was invalid.</errorMessage><developerMessage>Incorrect Contract Status for Validation</developerMessage><detailsLocation>http://econtract-service.testint/errors/100101</detailsLocation></RESTError>");

		AppMessage result = component.handleR1NegConfBod(ecConfinVO, "xml");

		// Then
		assertNotNull(result);
		assertEquals("E100101", result.getMessageID());
		assertEquals("The request was invalid. - Incorrect Contract Status for Validation", result.getMessage());
	}
	
	@Test
	public void testHandleR1NegConfBod2() throws Throwable {
		// When
		ECConfinVO ecConfinVO = new ECConfinVO();
		ecConfinVO.setEcConfinMessage("{\"status\":401,	\"routeOneErrorCode\":100000,	\"errorMessage\":\"The authenticity of the request could not be verified\",	\"developerMessage\":\"The HMAC-SHA256 headers encoded with the secret key associated with the Access Key Id provided did not match the encoded value provided in the request Authorization header\",	\"detailsLocation\":\"https://testint.r1dev.com/errors/100000\"}");

		AppMessage result = component.handleR1NegConfBod(ecConfinVO, "json");

		// Then
		assertNotNull(result);
		assertEquals("E100000", result.getMessageID());
		assertEquals("The authenticity of the request could not be verified - The HMAC-SHA256 headers encoded with the secret key associated with the Access Key Id provided did not match the encoded value provided in the request Authorization header", result.getMessage());
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of ECConfinVO
	 */
	private static ECConfinVO mockECConfinVO() throws Throwable {
		ECConfinVO ecConfinVO = mock(ECConfinVO.class);
		String getEcConfinMessageResult = ""; // UTA: default value
		when(ecConfinVO.getEcConfinMessage()).thenReturn(getEcConfinMessageResult);
		return ecConfinVO;
	}
}