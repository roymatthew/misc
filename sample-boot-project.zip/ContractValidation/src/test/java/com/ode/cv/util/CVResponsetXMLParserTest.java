package com.ode.cv.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.jsoup.Jsoup;
import org.jsoup.parser.Parser;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.ode.cv.vo.AccrVO;

public class CVResponsetXMLParserTest {

	@Mock
	private CVResponseXMLParser cvResponseXMLParser;

	private static final String ROUTEONE_ACCR_FILENAME = "/data/ode/cv/test/data/routeone_accr.xml";
	private static final String RE_ACCR_RFL_FILENAME = "/data/ode/cv/test/data/re_accr_with_rfl.xml";

	@Before
	public void setup() throws TransformerException, IOException {
		MockitoAnnotations.initMocks(this);
		Mockito.doReturn(getXml(ROUTEONE_ACCR_FILENAME)).when(cvResponseXMLParser)
				.removeSchemaPrefixIfAny(Mockito.anyString());
		Mockito.doCallRealMethod().when(cvResponseXMLParser).populateAccrDetailsFromInput(Mockito.any(AccrVO.class));
		Mockito.doCallRealMethod().when(cvResponseXMLParser).extractRequiredFormsList(Mockito.anyString());
	}

	@Test
	public void testJsoupXmlParsing()
			throws TransformerException, ParserConfigurationException, SAXException, IOException {

		String accrXml = getXml(ROUTEONE_ACCR_FILENAME);
		org.jsoup.nodes.Document doc = Jsoup.parse(accrXml, "", Parser.xmlParser());
		String lenderId = doc.select("FinanceCompany").select("PartyId").text();
		assertNotNull(lenderId);
		assertEquals("CHC", lenderId);
	}

	@Test
	public void testPopulateAccrDetailsFromInput()
			throws TransformerException, ParserConfigurationException, SAXException, IOException {

		String accrXml = getXml(ROUTEONE_ACCR_FILENAME);
		AccrVO accrVO = new AccrVO();
		accrVO.setAccrRequestXml(accrXml);
		accrVO = cvResponseXMLParser.populateAccrDetailsFromInput(accrVO);

		assertNotNull(accrVO.getLenderId());
		assertEquals("CHC", accrVO.getLenderId());
		assertEquals("999945", accrVO.getDealerId());
	}

	@Test
	public void testExtractRequiredFormsList()
			throws TransformerException, ParserConfigurationException, SAXException, IOException {

		Mockito.doReturn(getXml(RE_ACCR_RFL_FILENAME)).when(cvResponseXMLParser)
		.removeSchemaPrefixIfAny(Mockito.anyString());
		String accrXml = getXml(RE_ACCR_RFL_FILENAME);
		List<String> listOfForms = cvResponseXMLParser.extractRequiredFormsList(accrXml);
		assertFalse(listOfForms.isEmpty());
		assertTrue(listOfForms.contains("Contract"));

	}

	/**
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private Document getDocument() throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/routeone_accr.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		return document;
	}

	public String getStringFromDocument(Document doc) throws TransformerException, IOException {
		File file = ResourceUtils.getFile("classpath:removeNameSpace.xslt");
		Source source = new StreamSource(file);
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer(source);
		transformer.transform(domSource, result);
		return writer.toString();
	}

	public String getXml(final String fileName) throws TransformerException, IOException {
		File file = ResourceUtils.getFile("classpath:removeNameSpace.xslt");
		Source source = new StreamSource(file);
		Resource resource = new FileSystemResource(fileName);
		Source xmlSource = new StreamSource(resource.getInputStream());
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer(source);
		transformer.transform(xmlSource, result);
		return writer.toString();
	}

}
