package com.ode.cv.util;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;

import com.itextpdf.xmp.impl.Base64;
import com.ode.cv.ContractValidationApplication;
import com.ode.cv.persistence.ILteResponseXmlRepoService;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.ContractPackageVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeDealBo;
import com.ode.cv.vo.DealerInfoVO;
import com.ode.cv.vo.ECConfinVO;
import com.ode.cv.vo.LteResponseXmlVO;
import com.ode.persistence.service.DePartnerDestinationRepoService;
import com.ode.persistence.vo.DePartnerDestinationVO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class CVTransmitClientRouteOneTest {
	
	@Autowired
	private CVTransmitClient cvTransmitClient;

	@Autowired
	private DePartnerDestinationRepoService dePartnerDestinationRepoService;

	@Autowired
	private ILteResponseXmlRepoService lteResponseXmlRepoService;

	@Autowired
	private CVRequestXMLParser cvRequestXmlParser;

	/**
	 * @throws Exception
	 */
	@Test
	public void testPostCVToRouteOne() throws Exception {

		DePartnerDestinationVO dePartnerDestinationVO = dePartnerDestinationRepoService.getByPartnerAndProduct("RO",
				"CV");
		Assert.assertNotNull(dePartnerDestinationVO);
		Assert.assertEquals("}4j<Jyt#3y?-u.j3v^\\Q}d#+cm.8d<1\\cv`8g(aI-]+*Y:,t(eUB}O-b#yT06&_w",
				dePartnerDestinationVO.getWsPassword());
		LteResponseXmlVO lteResponseXmlVO = lteResponseXmlRepoService.getByXmlId(2);
		Assert.assertNotNull(lteResponseXmlVO);
		Assert.assertNotNull(lteResponseXmlVO.getLteOutputXml());
		String xml = lteResponseXmlVO.getLteOutputXml();
		Document document = cvRequestXmlParser.getDocument(xml);
		CVUtil.restructureAndAddContractPackageToCVDocument(document, getMockContractPackage());
		String requestXml = CVUtil.getXmlStringFromDocument(document);
		CreditContractVO creditContractVO = getMockCreditContractVO();
		String result = cvTransmitClient.postCVToRouteOneWithDynamicHeaders(creditContractVO , requestXml, dePartnerDestinationVO, "test", new ECConfinVO());
		Assert.assertNotNull(result);
	}

	private ContractPackageVO getMockContractPackage() {
		ContractPackageVO contractPackage = new ContractPackageVO();

		contractPackage.setContractId("01-73726253");
		contractPackage.setContractType("LAW");
		contractPackage.setPartnerFSID("GMF");
		contractPackage.setConversationId("01-1-23424675");
		return contractPackage;
	}

	@Test
	public void testDecodeSignature() {
		System.out.println("Decoded RouteOne Computed Signature: "
				+ Base64.decode("W21Cov42m9F25Gy9VfNKEWxOMlKYyCd5g1i3Uy97rEQ="));

	}

	private Map<String, String> getMockInput() {
		Map<String, String> input = new HashMap<>();
		input.put("authorizationId", "csr");
		input.put("contractId", "01-73726253");
		input.put("partnerFSID", "GMF");
		input.put("dealerNumber", "AY2OM");

		return input;
	}
	
	private CreditContractVO getMockCreditContractVO()
	{
		CreditContractVO creditContractVO = new CreditContractVO();
		DeDealBo deal = new DeDealBo();
		deal.setDmsDealerId("999852");
		deal.setLenderId("GMF");
		creditContractVO.setDeal(deal);
		DealerInfoVO dealerInfoVO = new DealerInfoVO();
		dealerInfoVO.setDspId("AD");
		creditContractVO.setDealerInfo(dealerInfoVO);
		return creditContractVO;
		
	}

}
