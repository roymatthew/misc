/**
 * 
 */
package com.ode.cv.util;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ode.cv.ContractValidationApplication;
import com.ode.cv.util.transmit.client.CVTransmitClient;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.PartnerInfoVO;

/**
 * @author rmathew
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class CVTransmitClientTest {
	
	@Autowired
	private CVTransmitClient client;

	@Test
	public void test() throws Exception {
		
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		PartnerInfoVO partnerInfoVO = new PartnerInfoVO();
		partnerInfoVO.setLenderId("CHC");
		cvTransmitVO.setPartnerInfoVO(partnerInfoVO );
		cvTransmitVO.setConfoutXml("<response>Success</response>");
		
		client.sendXmlOutputToDms(cvTransmitVO, "RR");
		
		Assert.assertNotNull(cvTransmitVO.getResponseXml());
		
	}

}
