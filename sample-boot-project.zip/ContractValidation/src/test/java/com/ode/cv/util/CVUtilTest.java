package com.ode.cv.util;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ode.cv.factory.VOFactory;
import com.ode.cv.vo.ContractPackageVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DeContractValidationBo;
import com.ode.cv.vo.DeDealBo;
import com.ode.cv.vo.DealerInfoVO;
import com.ode.cv.vo.ExpressionVO;
import com.ode.cv.vo.PartnerInfoVO;
import com.ode.persistence.vo.DeCdkCloudCvXrefVO;

@RunWith(SpringJUnit4ClassRunner.class)
public class CVUtilTest {
	
	private static final String TEST_CONVERSATION_ID = "01-1-92362491";

	@Test
	public void testContractId() {
		final CreditContractVO creditContractVO = getMockCreditContract();
		creditContractVO.getDeal().setLenderId("GMF");		
		String result = CVUtil.generateContractId(creditContractVO);
		assertNotNull(result);
		final String expectedContractId = "01234567_0000994949_GMF_CV03_";
		assertTrue(result.startsWith(expectedContractId));
	}

	private CreditContractVO getMockCreditContract() {
		final DeDealBo deal = new DeDealBo();
		deal.setCvSequenceId("CV03");
		deal.setDmsDealerId("994949");
		deal.setDmsDealNum("01234567890123");
		final CreditContractVO creditContractVO = new CreditContractVO();
		final DeContractValidationBo contractValidationBO = new DeContractValidationBo();
		contractValidationBO.setSequenceId("CV03");
		creditContractVO.setContractValidation(contractValidationBO);
		creditContractVO.setDeal(deal);
		return creditContractVO;
	}
	
	@Test
	public void testGenerateRouteOneRequest() throws ParserConfigurationException, UnsupportedEncodingException, IOException, SAXException, TransformerException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/re_accr.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		CreditContractVO creditContractVO = getMockCreditContract();
		creditContractVO.setConversationId(TEST_CONVERSATION_ID);
		creditContractVO.setContractType("LAW");
		DeContractValidationBo cvBO = new DeContractValidationBo();
		cvBO.setContractId("XYZ123455TEST");
		creditContractVO.setContractValidation(cvBO);
		PartnerInfoVO partnerInfoVO = new PartnerInfoVO();
		partnerInfoVO.setLenderId("CHC");
		DealerInfoVO dealerInfoVO = new DealerInfoVO();
		creditContractVO.setPartnerInfo(partnerInfoVO);
		creditContractVO.setDealerInfo(dealerInfoVO);
		dealerInfoVO.setPartnerId("TESTPARTNER");
		ContractPackageVO contractPackageVO = VOFactory.createContractPackageVO(creditContractVO);
	    Document doc2 = CVUtil.restructureAndAddContractPackageToCVDocument(document, contractPackageVO);
	    String r1Xml = CVUtil.getXmlStringFromDocument(doc2);
	    Assert.assertTrue(TEST_CONVERSATION_ID.equals(contractPackageVO.getConversationId()));
	    Assert.assertTrue(r1Xml.contains("RouteOneProcessCreditContract"));
	    Assert.assertTrue(r1Xml.contains("<RouteOneCreditApplicationConversationID>01-1-92362491</RouteOneCreditApplicationConversationID>"));
	}
	
	@Test
	public void testRemoveTradeIns() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/sample_ecout_with_tradeins.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		CreditContractVO creditContractVO = getMockCreditContract();
		creditContractVO.setAdpDealNo("test123");
		assertTrue(getNumberOfTradeIns(document) == 3);
		Document newDocument = CVUtil.removeTradeInsFromCVDocument(document, creditContractVO);
		//String newXml = CVUtil.getXmlStringFromDocument(newDocument);
		assertTrue(getNumberOfTradeIns(newDocument) == 1); 
	}

	private int getNumberOfTradeIns(Document document) {
		NodeList nodeList = document.getElementsByTagName("TradeIn");
		return nodeList.getLength();
	}
	
	@Test
	public void testGetNewPartyId()
	{
		String cvSequenceId = "CV56";
		int nextPartyIdNumber = 1;
		String partyId = CVUtil.getNewPartyId(cvSequenceId, nextPartyIdNumber);
		assertNotNull(partyId);
		assertEquals("560001", partyId);
		
		cvSequenceId = "CV0";
		nextPartyIdNumber = 1;
		partyId = CVUtil.getNewPartyId(cvSequenceId, nextPartyIdNumber);
		assertNotNull(partyId);
		assertEquals("000001", partyId);
		
		cvSequenceId = "CV1";
		nextPartyIdNumber = 1;
		partyId = CVUtil.getNewPartyId(cvSequenceId, nextPartyIdNumber);
		assertNotNull(partyId);
		assertEquals("100001", partyId);
		
		cvSequenceId = "CV10";
		nextPartyIdNumber = 10;
		partyId = CVUtil.getNewPartyId(cvSequenceId, nextPartyIdNumber);
		assertNotNull(partyId);
		assertEquals("100010", partyId);
		
		cvSequenceId = "CV999";
		nextPartyIdNumber = 999;
		partyId = CVUtil.getNewPartyId(cvSequenceId, nextPartyIdNumber);
		assertNotNull(partyId);
		assertEquals("999999", partyId);
	}
	
	@Test
	public void testAddPartyIds() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/sample_ecout_partyid.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		CreditContractVO creditContractVO = getMockCreditContract();
		creditContractVO.setAdpDealNo("test123");
		Document newDocument = CVUtil.addApplicantPartyIDs(document, creditContractVO);
		String newXml = CVUtil.getXmlStringFromDocument(newDocument);
	}
	
	@Test
	public void testGenerateAckCreditContract() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/routeone_accr.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		CreditContractVO creditContractVO = getMockCreditContract();
		creditContractVO.setAdpDealNo("test123");
		Document newDocument = CVUtil.generateDocumentFromElement(document, "AcknowledgeCreditContractResponse", null);
		String newXml = CVUtil.getXmlStringFromDocument(newDocument).replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
		assertNotNull(newXml);
		assertTrue(newXml.startsWith("<AcknowledgeCreditContractResponse"));
	}
	
	@Test
	public void testGenerateProcessCreditContract() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/ecout2.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		CreditContractVO creditContractVO = getMockCreditContract();
		creditContractVO.setAdpDealNo("test123");
		Document newDocument = CVUtil.generateDocumentFromElement(document, "RouteOneProcessCreditContract", "ProcessCreditContract");
		String newXml = CVUtil.getXmlStringFromDocument(newDocument).replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
		assertNotNull(newXml);
		assertTrue(newXml.startsWith("<ProcessCreditContract"));
	}
	
	@Test
	public void testGetRouteOneConversationId() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/ecout2.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		assertEquals("01-1-92362491", CVUtil.getRouteOneConversationId(document));
	}
	
	@Test
	public void testFilterSubTotals()
	{
		Map<String, ExpressionVO> mapOfExpressions = new HashMap<>();
		String[] expressionNames = {"TotalVehicleCashPriceExp", "TotalDownPaymentAmountExp", "UnpaidBalanceAmountExp", "TotalAmountsPaidOnYourBehalfExp" };
		String[] nodeNames = {"TotalVehicleCashPrice", "TotalDownPaymentAmount", "UnpaidBalance", "TotalAmountPaidOnYourBehalf" };
		String[] values = {"40000.0", "-1000.0", "39000.0", "1000.0" };
		List<DeCdkCloudCvXrefVO> listOfXrefsForSubTotal = new ArrayList<DeCdkCloudCvXrefVO>();
		for ( int i = 0; i < 4; i++)
		{
			ExpressionVO vo = new ExpressionVO();
			vo.setName(expressionNames[i]);
			vo.setValue(values[i]);
			mapOfExpressions.put(vo.getName(), vo);
			
			DeCdkCloudCvXrefVO xrefVO = new DeCdkCloudCvXrefVO();
			xrefVO.setJsonSourceField(expressionNames[i]);
			xrefVO.setXmlDestinationTag(nodeNames[i]);
			listOfXrefsForSubTotal.add(xrefVO);
		}
		
		CVUtil.filterOutSubTotalsFromJson(mapOfExpressions, listOfXrefsForSubTotal);
	}
	
	@Test
	public void testIsR1ConfInXml1() {
		String message = "<RESTError><status>422</status><routeOneErrorCode>100101</routeOneErrorCode><errorMessage>The request was invalid.</errorMessage><developerMessage>Incorrect Contract Status for Validation</developerMessage><detailsLocation>http://econtract-service.testint/errors/100101</detailsLocation></RESTError>";
		boolean isXml = CVUtil.isR1ConfInXml(message);
		assertTrue(isXml);
	}
	
	@Test
	public void testIsR1ConfInXml2s() {
		String message = "{\"status\":401,	\"routeOneErrorCode\":100000,	\"errorMessage\":\"The authenticity of the request could not be verified\",	\"developerMessage\":\"The HMAC-SHA256 headers encoded with the secret key associated with the Access Key Id provided did not match the encoded value provided in the request Authorization header\",	\"detailsLocation\":\"https://testint.r1dev.com/errors/100000\"}";
		boolean isXml = CVUtil.isR1ConfInXml(message);
		assertFalse(isXml);
	}
		
	@Test
	public void testIsR1ConfInJson1() {
		String message = "<RESTError><status>422</status><routeOneErrorCode>100101</routeOneErrorCode><errorMessage>The request was invalid.</errorMessage><developerMessage>Incorrect Contract Status for Validation</developerMessage><detailsLocation>http://econtract-service.testint/errors/100101</detailsLocation></RESTError>";
		boolean isJson = CVUtil.isR1ConfInJson(message);
		assertFalse(isJson);
	}
	
	@Test
	public void testIsR1ConfInJson2() {
		String message = "{\"status\":401,	\"routeOneErrorCode\":100000,	\"errorMessage\":\"The authenticity of the request could not be verified\",	\"developerMessage\":\"The HMAC-SHA256 headers encoded with the secret key associated with the Access Key Id provided did not match the encoded value provided in the request Authorization header\",	\"detailsLocation\":\"https://testint.r1dev.com/errors/100000\"}";
		boolean isJson = CVUtil.isR1ConfInJson(message);
		assertTrue(isJson);
	}
}
