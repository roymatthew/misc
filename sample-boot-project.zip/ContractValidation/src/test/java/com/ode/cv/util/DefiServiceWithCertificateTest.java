package com.ode.cv.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.httpclient.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.junit.Test;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.ode.cv.vo.CreditContractVO;

public class DefiServiceWithCertificateTest {
	
	private static final String VOL_ECOUT2_FILENAME = "/data/ode/cv/test/data/VOL-ECOUT2.xml";
	
	
	@Test
	public void testOdeClientCert() throws TransformerException, IOException, URISyntaxException, KeyStoreException, NoSuchAlgorithmException, CertificateException {
		String xmlString = getXml(VOL_ECOUT2_FILENAME);
		final String baseUrl = "https://localhost:8090/certapi/cert/user";
	    URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> request = new HttpEntity<>(xmlString, headers);
		KeyStore clientStore = KeyStore.getInstance("JKS");
	    clientStore.load(new FileInputStream("/data/ode/keystores/truststore.jks"), "ode0221".toCharArray());
	    final SSLContext sslContext;
	    TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
	        @Override
	        public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
	            return true;
	        }
	    };
	    try {
	      sslContext = SSLContexts.custom()
	          .loadTrustMaterial(clientStore, acceptingTrustStrategy)
	          .loadKeyMaterial(clientStore, "ode0221".toCharArray(), (aliases, socket) -> "odeClient")
	          .build();
	    } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException | UnrecoverableKeyException e) {
	      throw new RuntimeException("Failed to read keystore", e);
	    }
	      
	    //HttpResponse response = httpClient.execute(new HttpHost("https://localhost:8090/certapi/cert/user"));
	    //SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext);
	    //SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext);
	    SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
	    /*HttpClientBuilder builder = HttpClients.custom().setSSLContext(sslContext);
	    builder.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
	    final CloseableHttpClient httpClient = builder.build();*/
	    //HttpResponse response = httpClient.execute(new HttpPost(uri));
	    
	    CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();


	    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
	    requestFactory.setConnectTimeout(10000); // 10 seconds
	    requestFactory.setReadTimeout(10000); // 10 seconds
	    RestTemplate restTemplate =  new RestTemplate(requestFactory);
	    ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
	    System.out.println("result: " + result);
	
	}
	
	

	@Test
	public void test() {
		try {
			
			String xmlString = getXml(VOL_ECOUT2_FILENAME);
			System.out.println("Length of xmlString: " + xmlString.length());
			final String baseUrl = "https://localhost:8090/certapi/cert/user";
		    URI uri = new URI(baseUrl);
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<String> request = new HttpEntity<>(xmlString, headers);
			RestTemplate restTemplate = restTemplate();			    
			System.out.println(restTemplate.toString());
		    ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
		    System.out.println("result: " + result);
			
		} catch (UnrecoverableKeyException | KeyManagementException | NoSuchAlgorithmException | KeyStoreException
				| CertificateException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	

	/**
	 * @return
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws CertificateException
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws KeyManagementException
	 */
	public RestTemplate restTemplate() throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, FileNotFoundException, IOException, KeyManagementException {
	    KeyStore clientStore = KeyStore.getInstance("JKS");
	    clientStore.load(new FileInputStream("/data/ode/keystores/ode/clientkeystore.jks"), "password".toCharArray());
	    //clientStore.load(new FileInputStream("/data/ode/keystores/ode/stage_ui_gateway_opendlrex_com.pfx"), "^TFCxdr5".toCharArray());
	    //clientStore.load(new FileInputStream("/users/rmathew/keystore/keystore.jks"), "changeit".toCharArray());
	    
	   /* KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	    kmf.init(clientStore, "^TFCxdr5".toCharArray());
	    KeyManager[] kms = kmf.getKeyManagers();*/
	    
	   /* KeyStore trustStore = KeyStore.getInstance("JKS");
	    trustStore.load(new FileInputStream("/data/ode/keystores/ode/truststore.jks"), "changeit".toCharArray());
	    
	    TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
	    tmf.init(trustStore);
	    TrustManager[] tms = tmf.getTrustManagers();*/
	    
	    /*final SSLContext sslContext = SSLContext.getInstance("TLS");
	    sslContext.init(kms, null, new SecureRandom());
	    SSLContext.setDefault(sslContext);*/
	    
	    SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
	    sslContextBuilder.setProtocol("TLSV1.2");
	    sslContextBuilder.loadKeyMaterial(clientStore, "^TFCxdr5".toCharArray());
	    //sslContextBuilder.loadKeyMaterial(clientStore, "123456".toCharArray());
	    //sslContextBuilder.loadKeyMaterial(clientStore, "changeit".toCharArray());
	    //KeyStore trustStore = KeyStore.getInstance("JKS");
	    //trustStore.load(new FileInputStream("/data/ode/keystores/ode/stage_ui_gateway_opendlrex_com.pfx"), "^TFCxdr5".toCharArray());
	    //sslContextBuilder.loadTrustMaterial(trustStore, new TrustSelfSignedStrategy());
	    sslContextBuilder.loadTrustMaterial(new TrustSelfSignedStrategy());
	    SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
	    //SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext);
	    CloseableHttpClient httpClient = HttpClients.custom()
	            .setSSLSocketFactory(sslConnectionSocketFactory)
	            .build();
	    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
	    requestFactory.setConnectTimeout(10000); // 10 seconds
	    requestFactory.setReadTimeout(10000); // 10 seconds
	    return new RestTemplate(requestFactory);
	}
	
	
	@Test
	public void testWithPkcs12() {
		try {
			
			final String baseUrl = "https://localhost:8090/certapi/cert/user";
		    URI uri = new URI(baseUrl);
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<String> request = new HttpEntity<>(null, headers);
			RestTemplate restTemplate = restTemplateWithPks();
		    ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
		    System.out.println("result: " + result);
			
		} catch (UnrecoverableKeyException | KeyManagementException | NoSuchAlgorithmException | KeyStoreException
				| CertificateException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	public RestTemplate restTemplateWithPks() throws UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, FileNotFoundException, IOException, KeyManagementException {
		KeyStore clientStore = KeyStore.getInstance("JKS");
		clientStore.load(new FileInputStream("/users/rmathew/keystore/keystore.jks"), "changeit".toCharArray());

		SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
		sslContextBuilder.setProtocol("TLSV1.2");
		sslContextBuilder.loadKeyMaterial(clientStore, "changeit".toCharArray());
		sslContextBuilder.loadTrustMaterial(new TrustSelfSignedStrategy());

		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(
				sslContextBuilder.build());
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		requestFactory.setConnectTimeout(10000); // 10 seconds
		requestFactory.setReadTimeout(10000); // 10 seconds
		return new RestTemplate(requestFactory);
	}
	
	/**
	 * @param fileName
	 * @return
	 * @throws TransformerException
	 * @throws IOException
	 */
	public String getXml(final String fileName) throws TransformerException, IOException {
		File file = ResourceUtils.getFile("classpath:removeNameSpace.xslt");
		Source source = new StreamSource(file);
		Resource resource = new FileSystemResource(fileName);
		Source xmlSource = new StreamSource(resource.getInputStream());
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer(source);
		transformer.transform(xmlSource, result);
		return writer.toString();
	}
	
	@Test
	public void testStarDateFormat() throws ParseException {
		SimpleDateFormat STAR_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		String formString = "VCFS-MVLAe-Multi ODE, Version 2019-10-01";
		String[] contractFormTokens = formString.split(",");
		String contractFormNumber = contractFormTokens[0].trim();
		String contractRevisionDate = contractFormTokens[1].trim();
		CreditContractVO vo = new CreditContractVO();
		if (contractRevisionDate.length() > 10 && contractRevisionDate.toLowerCase().contains("version")) {
			System.out.println("contractRevisionDate before substring: " + contractRevisionDate + " length: " + contractRevisionDate.length());
			contractRevisionDate = contractRevisionDate.substring(contractRevisionDate.length() - 10);
			System.out.println("contractRevisionDate after substring: " + contractRevisionDate + " length: " + contractRevisionDate.length());
			vo.setContractFormRevisionDate(STAR_DATE_FORMAT.parse(contractRevisionDate));
		}
		System.out.println("revDate: " + vo.getContractFormRevisionDate());
		
	}

}
