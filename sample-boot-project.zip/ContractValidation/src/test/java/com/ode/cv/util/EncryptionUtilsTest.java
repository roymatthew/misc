/**
 * 
 */
package com.ode.cv.util;

import java.math.BigInteger;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ode.cv.ContractValidationApplication;
import com.ode.dlr.util.EncryptionUtils;
import com.ode.persistence.service.CreditJournalRepoService;
import com.ode.persistence.vo.CreditJournalVO;

/**
 * @author rmathew
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class EncryptionUtilsTest {

	@Autowired
	private CreditJournalRepoService creditJournalRepoService;

	/**
	 * Test method for
	 * {@link com.ode.edocs.util.EncryptionUtils#decryptText(java.lang.String, java.lang.String)}.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testECOUTRead() throws Exception {

		BigInteger creditJournalKey = new BigInteger("379718");
		String TRANS_TYPE = "EC";
		final CreditJournalVO creditJournal = creditJournalRepoService.findById(creditJournalKey);

		Assert.assertNotNull(creditJournal);
		Assert.assertNotNull(creditJournal.getCrDataXml());
		Assert.assertNotNull(creditJournal.getEncryptionKeyId());
		final String docString = getDocumentFromCreditJournal(creditJournal);
		Assert.assertNotNull(docString);

	}
	
	@Test
	public void testEncryptAndDecrypt() throws Exception {
		
		String textToEncrypt = "WelcometoODE";
		List<String> encryptedItems = EncryptionUtils.encryptText(textToEncrypt);
		String encryptedText = encryptedItems.get(1);
		Assert.assertNotNull(encryptedText);
		Assert.assertNotNull(encryptedItems.get(0));
		String decryptedText = EncryptionUtils.decryptText(encryptedText, encryptedItems.get(0));		
		Assert.assertNotNull(decryptedText);

	}

	private String getDocumentFromCreditJournal(CreditJournalVO creditJournal) throws Exception {
		String docString = "";
		try {
			docString = EncryptionUtils.decryptText(creditJournal.getCrDataXml(), creditJournal.getEncryptionKeyId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return docString;
	}

}
