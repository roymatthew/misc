package com.ode.cv.util;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.TimeZone;

import org.junit.Test;

public class OptionalTest {

	@Test
	public void test() {
		//Optional<String> someString = Optional.of("Test");
		Optional<String> someString = Optional.ofNullable(null);

		if (someString.isPresent())
		{
			System.out.println("Test");
		}
	}
	
	@Test
	void testVin()
	{
		String vin = "YV4102RK4M172304";
		System.out.println(vin.substring(9, 17));
		
	}

	
	
	@Test
	public void testDateTime() {
		SimpleDateFormat dfWithT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		dfWithT.setTimeZone(TimeZone.getTimeZone("GMT"));
		String dateTime = dfWithT.format(new Date());
		System.out.println("dateTime:" + dateTime);
		System.out.println("substring(dateTime, 0, 19):" + dateTime.substring(0, 19));
		System.out.println("substring(dateTime, 0, 23):" + dateTime.substring(0, 23));
		
		
	}

}
