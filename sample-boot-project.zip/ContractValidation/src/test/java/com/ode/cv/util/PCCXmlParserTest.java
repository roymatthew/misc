package com.ode.cv.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.is;

import java.io.IOException;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.CreditContractVO;
import com.ode.cv.vo.DealerInfoVO;
import com.ode.cv.vo.PartnerInfoVO;


@RunWith(SpringJUnit4ClassRunner.class)
public class PCCXmlParserTest {
	
	private PCCXmlParser pccXmlParser = new PCCXmlParser();
	
	private static final Integer INT_XML_ID_THREE = Integer.valueOf(3);	

	@Test
	public void testParseInput() throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/saf_payload.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		document.getTextContent();
		
		try {
			final String xml = getStringFromDocument(document);
			CreditContractVO vo = new CreditContractVO();
			vo.setPartnerInfo(new PartnerInfoVO());
			vo.setDealerInfo(new DealerInfoVO());
			vo.setGenericCreditContract(true);
			vo.setRequestXML(xml);
			pccXmlParser.parseInput(document, vo);
			//System.out.println("Input LenderId: " + vo.getPartnerInfo().getLenderId());
			//System.out.println(vo.getLenderRequestXml());
			
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//Assert.assertNotNull(pccXmlParser.getXPath_LenderId());
		//System.out.println(pccXmlParser.getXPath_LenderId());
	}
	

	
	public static String getStringFromDocument(Document doc) throws TransformerException {
	    DOMSource domSource = new DOMSource(doc);
	    StringWriter writer = new StringWriter();
	    StreamResult result = new StreamResult(writer);
	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer transformer = tf.newTransformer();
	    transformer.transform(domSource, result);
	    return writer.toString();
	}	

	@Test
	public void testGetResponseXmlId()
			throws ParserConfigurationException, SAXException, IOException, Exception {

		Document confirmBodDocument = getDocument();
		Assert.assertNotNull(confirmBodDocument);
		String xml = getStringFromDocument(confirmBodDocument);
		Integer xmlId = pccXmlParser.getResponseXmlId(xml);
		Assert.assertNotNull(xmlId);
		Assert.assertEquals(INT_XML_ID_THREE, xmlId);
	}
	
	@Test
	public void testGetSenderNameCode_isReturned_whenTagExists() {
		String xml = "<ProcessCreditContract xmlns=\"http://www.starstandards.org/STAR\" release=\"8.1-Lite\" environment=\"Production\" lang=\"en-US\" bodVersion=\"5.0\">\n" + 
				"	<ApplicationArea>\n" + 
				"		<Sender>\n" + 
				"			<Component>evalidate</Component>\n" + 
				"			<Task>CreditContract</Task>\n" +  
				"			<CreatorNameCode>DF</CreatorNameCode>\n" + 
				"			<SenderNameCode>AR</SenderNameCode>\n" +  
				"			<DealerNumber>70226</DealerNumber>\n" + 
				"		</Sender>\n" + 
				"		<CreationDateTime>2020-08-25T09:19:06</CreationDateTime>\n" + 
				"		<Destination>\n" + 
				"			<DestinationNameCode>DF</DestinationNameCode>\n" + 
				"			<DealerCountry>US</DealerCountry>\n" + 
				"		</Destination>\n" + 
				"	</ApplicationArea>" +
				"</ProcessCreditContract>"; 
		String result = pccXmlParser.getSenderNameCode(xml);
		assertThat(result, is("AR"));
	}
	
	@Test
	public void testGetSenderNameCode_isBlank_whenTagMissing() {
		String xml = "<payload xmlns=\"http://www.starstandards.org/webservices/2005/10/transport\">\n" + 
				"	<content id=\"Content0\">\n" + 
				"		<GenericCreditContract xmlns=\"http://www.adpcreditsolutions.com/gcv/genericcontract\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" + 
				"			<clientInfo>\n" + 
				"				<dealerId>999851</dealerId>\n" + 
				"				<systemId>999851</systemId>\n" + 
				"				<fiAccount>NEWYORK-FI</fiAccount>\n" + 
				"				<userId>csr</userId>\n" + 
				"				<dealNumber>LATSTANU</dealNumber>\n" + 
				"			</clientInfo>\n" + 
				"			<contractHeader>\n" + 
				"				<BODId>LTSTANU00446251</BODId>\n" + 
				"				<creationDateTime>2013-09-16T12:44:11-04:00</creationDateTime>\n" + 
				"				<partnerId>CHC</partnerId>\n" + 
				"				<financeType>R</financeType>\n" + 
				"			</contractHeader>\n" + 
				"			<contractInfo>\n" + 
				"			</contractInfo>\n" + 
				"		</GenericCreditContract>\n" + 
				"	</content>\n" + 
				"</payload>"; 
		String result = pccXmlParser.getSenderNameCode(xml);
		assertThat(result, is(""));		
	}
	
	/**
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private Document getDocument() throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/anantics_confirmbod.xml");
		final Document document = docBuilder.parse(resource.getInputStream());
		return document;
	}

}
