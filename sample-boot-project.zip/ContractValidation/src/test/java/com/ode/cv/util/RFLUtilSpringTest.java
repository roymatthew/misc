/**
 * 
 */
package com.ode.cv.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ode.cv.factory.DmsBOFactory;
import com.ode.cv.service.IDcOtherFormTypePersistenceService;
import com.ode.cv.service.IDmsDocTypePersistenceService;
import com.ode.cv.vo.CVTransmitVO;
import com.ode.cv.vo.DealerInfoVO;
import com.ode.cv.vo.PartnerInfoVO;
import com.ode.persistence.service.DcFormRepoService;
import com.ode.persistence.service.DcOtherFormTypeRepoService;
import com.ode.persistence.service.DmsDocTypeRepoService;
import com.ode.persistence.service.LenDocTypeRepoService;
import com.ode.persistence.vo.DcFormVO;
import com.ode.persistence.vo.DcOtherFormTypeVO;
import com.ode.persistence.vo.DeDealVO;
import com.ode.persistence.vo.DmsDocTypeVO;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Parasoft Jtest UTA: Test class for RFLUtil
 *
 * @see com.ode.cv.util.RFLUtil
 * @author djenkins
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class RFLUtilSpringTest {

	// Parasoft Jtest UTA: Component under test
	@InjectMocks
	RFLUtil underTest;

	// Parasoft Jtest UTA: Dependency generated for autowired field "lenDocTypeRepoService" in RFLUtil
	@Mock
	LenDocTypeRepoService lenDocTypeRepoService;

	@Mock
	IDmsDocTypePersistenceService dmsDocTypePersistenceService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "dcOtherFormTypeRepoService" in RFLUtil
	@Mock
	DcOtherFormTypeRepoService dcOtherFormTypeRepoService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "dcFormRepoService" in RFLUtil
	@Mock
	DcFormRepoService dcFormRepoService;

	// Parasoft Jtest UTA: Dependency generated for autowired field "dmsBOFactory" in RFLUtil
	@Mock
	DmsBOFactory dmsBOFactory;
	
	@Mock
	IDcOtherFormTypePersistenceService dcOtherFormTypePersistenceService;

	/**
	 * Parasoft Jtest UTA: Test for getFormListForR1Stips(CVTransmitVO)
	 *
	 * @see com.ode.cv.util.RFLUtil#getFormListForStips(CVTransmitVO)
	 * @author djenkins
	 */
	@Test
	public void testGetFormListForR1Stips() throws Throwable {
		// When
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		PartnerInfoVO partnerInfoVO = new PartnerInfoVO();
		DealerInfoVO dealerInfoVO = new DealerInfoVO();
		DeDealVO deDealVO = new DeDealVO();
		DmsDocTypeVO dmsDocTypes = new DmsDocTypeVO();
		
		String accr = "<Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">	<Header>		<payloadManifest xmlns=\"https://urldefense.com/v3/__http://www.starstandards.org/webservices/2005/10/transport__;!!CcpnlPiBfhjAOp0!gS0sREfWWW2QzRDVI87RY2Gl7V-VS54ODD2OeDN33VRMOm4whz95tZSxMbgLrzRm2RvJqYn4VcGC$ \">			<manifest contentID=\"Content0\" element=\"AcknowledgeCreditContractResponse\" namespaceURI=\"https://urldefense.com/v3/__http://www.starstandards.org/STAR__;!!CcpnlPiBfhjAOp0!gS0sREfWWW2QzRDVI87RY2Gl7V-VS54ODD2OeDN33VRMOm4whz95tZSxMbgLrzRm2RvJqTapmqmN$ \" version=\"2.01\"/>		</payloadManifest>	</Header>	<Body>		<PutMessage xmlns=\"https://urldefense.com/v3/__http://www.starstandards.org/webservices/2005/10/transport__;!!CcpnlPiBfhjAOp0!gS0sREfWWW2QzRDVI87RY2Gl7V-VS54ODD2OeDN33VRMOm4whz95tZSxMbgLrzRm2RvJqYn4VcGC$ \" xmlns:star=\"http://www.starstandards.org/STAR\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">			<payload>				<content id=\"Content0\">					<AcknowledgeCreditContractResponse bodVersion=\"5.0\" environment=\"Production\" lang=\"en-US\" revision=\"3.0.1\">						<ApplicationArea>							<Sender>								<Component>OD</Component>								<Task>AcknowledgeCreditContractResponse</Task>								<CreatorNameCode>GMF</CreatorNameCode>								<SenderNameCode>RO</SenderNameCode>							</Sender>							<CreationDateTime>2021-02-12T15:56:19.082Z</CreationDateTime>							<BODId>DISTFAULT_TEST_111</BODId>						</ApplicationArea>						<DataArea>							<CreditContractResponse>								<Header>									<VIN>KL4CJCSB0LB015756</VIN>									<ValidationResults>Passed</ValidationResults>									<ValidationMessage>										<Description>Form is ready to be generated.</Description>										<ErrorCriticality>Generate Form</ErrorCriticality>										<ReferenceName>Generate Form</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>String</Description>										<ErrorCriticality>I</ErrorCriticality>									</ValidationMessage>									<ValidationMessage>										<Description>CONTRACT @ Retail Installment Contract | 553-MI-ARB : 05/20</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>NOTICE TO CO-SIGNER @ Notice to CoSigner</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>Other @ Stips-Proof of phone</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>Bookout @ Used Vehicle Report</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ApplicationNumber desc=\"Finance Source\">01-1-28600422</ApplicationNumber>								</Header>								<FinanceCompany>									<PartyId>GMF</PartyId>								</FinanceCompany>								<Dealer>									<PartyId>AY2OM</PartyId>								</Dealer>								<IndividualApplicant>									<PersonName>										<GivenName>ELIZABETH</GivenName>										<MiddleName>T</MiddleName>										<FamilyName>XXXXXXXXXXX</FamilyName>									</PersonName>									<Contact>										<Telephone desc=\"Evening Phone\">7348957895</Telephone>										<PersonName>											<GivenName>ELIZABETH</GivenName>											<MiddleName>T</MiddleName>											<FamilyName>XXXXXXXXXXX</FamilyName>										</PersonName>									</Contact>								</IndividualApplicant>								<Financing>									<AmountFinanced currency=\"USD\">27696.96</AmountFinanced>									<ContractTerm length=\"Months\">60</ContractTerm>									<AnnualPercentageRate>12.00</AnnualPercentageRate>								</Financing>								<CreditVehicle>									<Model>ENCORE</Model>									<ModelYear>2020</ModelYear>									<Make>BUICK</Make>									<Pricing>										<VehiclePrice currency=\"USD\">21995.00</VehiclePrice>										<VehiclePricingType>Invoice</VehiclePricingType>									</Pricing>									<Pricing>										<VehiclePrice currency=\"USD\">21995.00</VehiclePrice>										<VehiclePricingType>Wholesale Price</VehiclePricingType>									</Pricing>								</CreditVehicle>							</CreditContractResponse>						</DataArea>					</AcknowledgeCreditContractResponse>				</content>			</payload>		</PutMessage>	</Body></Envelope>";
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new InputSource(new StringReader(accr)));
		NodeList flowList = document.getElementsByTagName("ValidationMessage");
		
		cvTransmitVO.setAccrResponseXml(accr);
		
		partnerInfoVO.setLenderId("ALY");
		cvTransmitVO.setPartnerInfoVO(partnerInfoVO);
		
		dealerInfoVO.setDspId("AD");
		cvTransmitVO.setDealerInfoVO(dealerInfoVO);
		
		deDealVO.setDeDealId("0000987665");
		cvTransmitVO.setDealVO(deDealVO);
		
		dmsDocTypes.setDmsFormId("00184");
		
		when(dmsDocTypePersistenceService.getDmsDocType(nullable(String.class), nullable(String.class), nullable(String.class))).thenReturn(dmsDocTypes);
		when(dcOtherFormTypePersistenceService.findByDeDealId(nullable(String.class))).thenReturn(new ArrayList<DcOtherFormTypeVO>());
		when(dcOtherFormTypePersistenceService.saveOrUpdateAll(nullable(ArrayList.class))).thenReturn(new ArrayList<DcOtherFormTypeVO>());
		
		List<DcFormVO> result = underTest.getFormListForStips(cvTransmitVO, flowList);

		// Then
		assertNotNull(result);
	}
	
	@Test
	public void testGetFormListForR1StipsNoDocType() throws Throwable {
		// When
		CVTransmitVO cvTransmitVO = new CVTransmitVO();
		PartnerInfoVO partnerInfoVO = new PartnerInfoVO();
		DealerInfoVO dealerInfoVO = new DealerInfoVO();
		DeDealVO deDealVO = new DeDealVO();
		DmsDocTypeVO dmsDocTypes = null;
		
		String accr = "<Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">	<Header>		<payloadManifest xmlns=\"https://urldefense.com/v3/__http://www.starstandards.org/webservices/2005/10/transport__;!!CcpnlPiBfhjAOp0!gS0sREfWWW2QzRDVI87RY2Gl7V-VS54ODD2OeDN33VRMOm4whz95tZSxMbgLrzRm2RvJqYn4VcGC$ \">			<manifest contentID=\"Content0\" element=\"AcknowledgeCreditContractResponse\" namespaceURI=\"https://urldefense.com/v3/__http://www.starstandards.org/STAR__;!!CcpnlPiBfhjAOp0!gS0sREfWWW2QzRDVI87RY2Gl7V-VS54ODD2OeDN33VRMOm4whz95tZSxMbgLrzRm2RvJqTapmqmN$ \" version=\"2.01\"/>		</payloadManifest>	</Header>	<Body>		<PutMessage xmlns=\"https://urldefense.com/v3/__http://www.starstandards.org/webservices/2005/10/transport__;!!CcpnlPiBfhjAOp0!gS0sREfWWW2QzRDVI87RY2Gl7V-VS54ODD2OeDN33VRMOm4whz95tZSxMbgLrzRm2RvJqYn4VcGC$ \" xmlns:star=\"http://www.starstandards.org/STAR\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">			<payload>				<content id=\"Content0\">					<AcknowledgeCreditContractResponse bodVersion=\"5.0\" environment=\"Production\" lang=\"en-US\" revision=\"3.0.1\">						<ApplicationArea>							<Sender>								<Component>OD</Component>								<Task>AcknowledgeCreditContractResponse</Task>								<CreatorNameCode>GMF</CreatorNameCode>								<SenderNameCode>RO</SenderNameCode>							</Sender>							<CreationDateTime>2021-02-12T15:56:19.082Z</CreationDateTime>							<BODId>DISTFAULT_TEST_111</BODId>						</ApplicationArea>						<DataArea>							<CreditContractResponse>								<Header>									<VIN>KL4CJCSB0LB015756</VIN>									<ValidationResults>Passed</ValidationResults>									<ValidationMessage>										<Description>Form is ready to be generated.</Description>										<ErrorCriticality>Generate Form</ErrorCriticality>										<ReferenceName>Generate Form</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>String</Description>										<ErrorCriticality>I</ErrorCriticality>									</ValidationMessage>									<ValidationMessage>										<Description>CONTRACT @ Retail Installment Contract | 553-MI-ARB : 05/20</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>NOTICE TO CO-SIGNER @ Notice to CoSigner</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>Other @ Stips-Proof of phone</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ValidationMessage>										<Description>Bookout @ Used Vehicle Report</Description>										<ReferenceName>RFL</ReferenceName>									</ValidationMessage>									<ApplicationNumber desc=\"Finance Source\">01-1-28600422</ApplicationNumber>								</Header>								<FinanceCompany>									<PartyId>GMF</PartyId>								</FinanceCompany>								<Dealer>									<PartyId>AY2OM</PartyId>								</Dealer>								<IndividualApplicant>									<PersonName>										<GivenName>ELIZABETH</GivenName>										<MiddleName>T</MiddleName>										<FamilyName>XXXXXXXXXXX</FamilyName>									</PersonName>									<Contact>										<Telephone desc=\"Evening Phone\">7348957895</Telephone>										<PersonName>											<GivenName>ELIZABETH</GivenName>											<MiddleName>T</MiddleName>											<FamilyName>XXXXXXXXXXX</FamilyName>										</PersonName>									</Contact>								</IndividualApplicant>								<Financing>									<AmountFinanced currency=\"USD\">27696.96</AmountFinanced>									<ContractTerm length=\"Months\">60</ContractTerm>									<AnnualPercentageRate>12.00</AnnualPercentageRate>								</Financing>								<CreditVehicle>									<Model>ENCORE</Model>									<ModelYear>2020</ModelYear>									<Make>BUICK</Make>									<Pricing>										<VehiclePrice currency=\"USD\">21995.00</VehiclePrice>										<VehiclePricingType>Invoice</VehiclePricingType>									</Pricing>									<Pricing>										<VehiclePrice currency=\"USD\">21995.00</VehiclePrice>										<VehiclePricingType>Wholesale Price</VehiclePricingType>									</Pricing>								</CreditVehicle>							</CreditContractResponse>						</DataArea>					</AcknowledgeCreditContractResponse>				</content>			</payload>		</PutMessage>	</Body></Envelope>";
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new InputSource(new StringReader(accr)));
		NodeList flowList = document.getElementsByTagName("ValidationMessage");
		
		cvTransmitVO.setAccrResponseXml(accr);
		
		partnerInfoVO.setLenderId("ALY");
		cvTransmitVO.setPartnerInfoVO(partnerInfoVO);
		
		dealerInfoVO.setDspId("AD");
		cvTransmitVO.setDealerInfoVO(dealerInfoVO);
		
		deDealVO.setDeDealId("0000987665");
		cvTransmitVO.setDealVO(deDealVO);
		
		when(dmsDocTypePersistenceService.getDmsDocType(nullable(String.class), nullable(String.class), nullable(String.class))).thenReturn(dmsDocTypes);
		when(dcOtherFormTypePersistenceService.findByDeDealId(nullable(String.class))).thenReturn(new ArrayList<DcOtherFormTypeVO>());
		when(dcOtherFormTypePersistenceService.saveOrUpdateAll(nullable(ArrayList.class))).thenReturn(new ArrayList<DcOtherFormTypeVO>());

		List<DcFormVO> result = underTest.getFormListForStips(cvTransmitVO, flowList);

		// Then
		assertNotNull(result);
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of DeDealVO
	 */
	private static DeDealVO mockDeDealVO() throws Throwable {
		DeDealVO getDealVOResult = mock(DeDealVO.class);
		String getDeDealIdResult = ""; // UTA: default value
		when(getDealVOResult.getDeDealId()).thenReturn(getDeDealIdResult);

		String toStringResult = ""; // UTA: default value
		when(getDealVOResult.toString()).thenReturn(toStringResult);
		return getDealVOResult;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of DealerInfoVO
	 */
	private static DealerInfoVO mockDealerInfoVO() throws Throwable {
		DealerInfoVO getDealerInfoVOResult = mock(DealerInfoVO.class);
		String getDspIdResult = ""; // UTA: default value
		when(getDealerInfoVOResult.getDspId()).thenReturn(getDspIdResult);

		String toStringResult2 = ""; // UTA: default value
		when(getDealerInfoVOResult.toString()).thenReturn(toStringResult2);
		return getDealerInfoVOResult;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of PartnerInfoVO
	 */
	private static PartnerInfoVO mockPartnerInfoVO() throws Throwable {
		PartnerInfoVO getPartnerInfoVOResult = mock(PartnerInfoVO.class);
		String getLenderIdResult = ""; // UTA: default value
		when(getPartnerInfoVOResult.getLenderId()).thenReturn(getLenderIdResult);

		String toStringResult3 = ""; // UTA: default value
		when(getPartnerInfoVOResult.toString()).thenReturn(toStringResult3);
		return getPartnerInfoVOResult;
	}

	/**
	 * Parasoft Jtest UTA: Helper method to generate and configure mock of CVTransmitVO
	 */
	private static CVTransmitVO mockCVTransmitVO() throws Throwable {
		CVTransmitVO cvTransmitVO = mock(CVTransmitVO.class);
		String getAccrResponseXmlResult = ""; // UTA: default value
		when(cvTransmitVO.getAccrResponseXml()).thenReturn(getAccrResponseXmlResult);

		DeDealVO getDealVOResult = mockDeDealVO();
		when(cvTransmitVO.getDealVO()).thenReturn(getDealVOResult);

		DealerInfoVO getDealerInfoVOResult = mockDealerInfoVO();
		when(cvTransmitVO.getDealerInfoVO()).thenReturn(getDealerInfoVOResult);

		PartnerInfoVO getPartnerInfoVOResult = mockPartnerInfoVO();
		when(cvTransmitVO.getPartnerInfoVO()).thenReturn(getPartnerInfoVOResult);

		String toStringResult4 = ""; // UTA: default value
		when(cvTransmitVO.toString()).thenReturn(toStringResult4);
		return cvTransmitVO;
	}
}