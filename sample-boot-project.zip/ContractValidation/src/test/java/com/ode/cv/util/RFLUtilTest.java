package com.ode.cv.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.ode.persistence.vo.DcFormVO;

public class RFLUtilTest {

	@Ignore
	public void testCreateRFLXmlFromLenderFormsList() {
		List<DcFormVO> unsortedList = getMockFormsList();
		RFLUtil rFLUtil = new RFLUtil();
		String xml = rFLUtil.createRFLXmlFromLenderFormsList(unsortedList);
		int index = xml.lastIndexOf("<ReasonCode>");
		String lastReasonCode = xml.substring(index + 12, index + 17);
		Assert.assertEquals("00094", lastReasonCode);
	}
	
	@Ignore
	public void testCreateRFLXmlFromLenderFormsList2() {
		List<DcFormVO> unsortedList = getMockFormsList2();
		RFLUtil rFLUtil = new RFLUtil();
		String xml = rFLUtil.createRFLXmlFromLenderFormsList(unsortedList);
		int index = xml.lastIndexOf("<ReasonCode>");
		String lastReasonCode = xml.substring(index + 12, index + 14);
		Assert.assertEquals("94", lastReasonCode);
	}

	private List<DcFormVO> getMockFormsList() {
		List<DcFormVO> unsortedList = new ArrayList<>();
		
		DcFormVO dcFormVO = new DcFormVO();
		dcFormVO.setFormId("00094");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		dcFormVO = new DcFormVO();
		dcFormVO.setFormId("00002");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		dcFormVO = new DcFormVO();
		dcFormVO.setFormId("00003");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		dcFormVO = new DcFormVO();
		dcFormVO.setFormId("00001");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		return unsortedList;
	}
	
	private List<DcFormVO> getMockFormsList2() {
		List<DcFormVO> unsortedList = new ArrayList<>();
		
		DcFormVO dcFormVO = new DcFormVO();
		dcFormVO.setFormId("94");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		dcFormVO = new DcFormVO();
		dcFormVO.setFormId("2");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		dcFormVO = new DcFormVO();
		dcFormVO.setFormId("3");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		dcFormVO = new DcFormVO();
		dcFormVO.setFormId("1");
		dcFormVO.setFormName("Name:" + dcFormVO.getFormId());
		dcFormVO.setFormComment("Comment:" + dcFormVO.getFormId());
		unsortedList.add(dcFormVO);
		return unsortedList;
	}

}
