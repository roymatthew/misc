package com.ode.cv.util;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;

import org.apache.xpath.XPathAPI;
import org.apache.xpath.objects.XObject;
import org.dom4j.io.SAXReader;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.ode.cv.ContractValidationApplication;
import com.ode.dlr.util.CVXpathUtil;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ContractValidationApplication.class)
public class TestXpathAPI4Operation {

	private static final String PATH_TO_OPERATION_HEADER = "/Envelope/Header/payloadManifest/manifest";
	private static final String PATH_TO_PARTYID = "/payload/content/ProcessCreditApplication/DataArea/CreditApplication/Header/FinanceCompany/PartyId";

	@Test
	public void test() throws ParserConfigurationException, SAXException, IOException, TransformerException, SOAPException {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/input.xml");
		final Document document = docBuilder.parse(resource.getInputStream());

		String operation = XPathAPI.eval(document, PATH_TO_OPERATION_HEADER).toString();
		Node node = XPathAPI.selectSingleNode(document, PATH_TO_OPERATION_HEADER);
		NamedNodeMap map = node.getAttributes();
		Node elementNode = map.getNamedItem("element");
		System.out.println("Node is  " + elementNode.getNodeValue());
		//System.out.println("Operation is " + operation);
		//String partyid = XPathAPI.eval(document, PATH_TO_PARTYID).toString();
		
/*		if (resource != null && resource.isReadable())
		{
			System.out.println("Resource is all good");
		}
		
		InputStream is = resource.getInputStream();
		String xml = convertToString(is);
		System.out.println("Length of Xml String is " + xml.length());
		System.out.println(xml);
		SOAPMessage soapMessage = MessageFactory.newInstance().createMessage(null, is);
		System.out.println("SoapMessage" + soapMessage.toString());
		SOAPHeader soapHeader = soapMessage.getSOAPHeader();
		SOAPBody soapBody = soapMessage.getSOAPBody();
		
		
		System.out.println(soapHeader);
		
		System.out.println(soapBody);*/
	}

	private String convertToString(InputStream is) throws UnsupportedEncodingException, IOException {
		StringBuilder stringBuilder = new StringBuilder();
		String line = null;
		
		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {	
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
			}
		}
	 
		return stringBuilder.toString();
	}
	
	@Test
	public void testCvXpathUtil() throws ParserConfigurationException, UnsupportedEncodingException, IOException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/jpm.xml");
		String xmlString = convertToString(resource.getInputStream());
		String operationName = CVXpathUtil.getOperationName(xmlString);
		
		System.out.println(operationName);
	}
	
	@Test
	public void testCvXpathUtil4ContractName() throws ParserConfigurationException, UnsupportedEncodingException, IOException
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		DocumentBuilder docBuilder = factory.newDocumentBuilder();
		Resource resource = new FileSystemResource("/data/ode/cv/test/data/saf_payload.xml");
		String xmlString = convertToString(resource.getInputStream());
		String operationName = CVXpathUtil.getContractName(xmlString);
		
		System.out.println(operationName);
	}

}
